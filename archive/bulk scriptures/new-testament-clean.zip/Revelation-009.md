# Revelation 9

Revelation 9 (summary): John also sees the wars and plagues poured out during the seventh seal and before the Lord comes.

Revelation 9:1 And the fifth angel sounded, and I saw a star fall from heaven unto the earth: and to him was given the key of the bottomless pit.

Revelation 9:2 And he opened the bottomless pit; and there arose a smoke out of the pit, as the smoke of a great furnace; and the sun and the air were darkened by reason of the smoke of the pit.

Revelation 9:3 And there came out of the smoke locusts upon the earth: and unto them was given power, as the scorpions of the earth have power.

Revelation 9:4 And it was commanded them that they should not hurt the grass of the earth, neither any green thing, neither any tree; but only those men which have not the seal of God in their foreheads.

Revelation 9:5 And to them it was given that they should not kill them, but that they should be tormented five months: and their torment was as the torment of a scorpion, when he striketh a man.

Revelation 9:6 And in those days shall men seek death, and shall not find it; and shall desire to die, and death shall flee from them.

Revelation 9:7 And the shapes of the locusts were like unto horses prepared unto battle; and on their heads were as it were crowns like gold, and their faces were as the faces of men.

Revelation 9:8 And they had hair as the hair of women, and their teeth were as the teeth of lions.

Revelation 9:9 And they had breastplates, as it were breastplates of iron; and the sound of their wings was as the sound of chariots of many horses running to battle.

Revelation 9:10 And they had tails like unto scorpions, and there were stings in their tails: and their power was to hurt men five months.

Revelation 9:11 And they had a king over them, which is the angel of the bottomless pit, whose name in the Hebrew tongue is Abaddon, but in the Greek tongue hath his name Apollyon.

Revelation 9:12 One woe is past; and, behold, there come two woes more hereafter.

Revelation 9:13 And the sixth angel sounded, and I heard a voice from the four horns of the golden altar which is before God,

Revelation 9:14 Saying to the sixth angel which had the trumpet, Loose the four angels which are bound in the great river Euphrates.

Revelation 9:15 And the four angels were loosed, which were prepared for an hour, and a day, and a month, and a year, for to slay the third part of men.

Revelation 9:16 And the number of the army of the horsemen were two hundred thousand thousand: and I heard the number of them.

Revelation 9:17 And thus I saw the horses in the vision, and them that sat on them, having breastplates of fire, and of jacinth, and brimstone: and the heads of the horses were as the heads of lions; and out of their mouths issued fire and smoke and brimstone.

Revelation 9:18 By these three was the third part of men killed, by the fire, and by the smoke, and by the brimstone, which issued out of their mouths.

Revelation 9:19 For their power is in their mouth, and in their tails: for their tails were like unto serpents, and had heads, and with them they do hurt.

Revelation 9:20 And the rest of the men which were not killed by these plagues yet repented not of the works of their hands, that they should not worship devils, and idols of gold, and silver, and brass, and stone, and of wood: which neither can see, nor hear, nor walk:

Revelation 9:21 Neither repented they of their murders, nor of their sorceries, nor of their fornication, nor of their thefts.
