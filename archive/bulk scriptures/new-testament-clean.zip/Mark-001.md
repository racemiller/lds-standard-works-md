# Mark 1

Mark 1 (summary): Jesus is baptized by John—He preaches the gospel, calls disciples, casts out devils, heals the sick, and cleanses a leper.

Mark 1:1 The beginning of the gospel of Jesus Christ, the Son of God;

Mark 1:2 As it is written in the prophets, Behold, I send my messenger before thy face, which shall prepare thy way before thee.

Mark 1:3 The voice of one crying in the wilderness, Prepare ye the way of the Lord, make his paths straight.

Mark 1:4 John did baptize in the wilderness, and preach the baptism of repentance for the remission of sins.

Mark 1:5 And there went out unto him all the land of Judæa, and they of Jerusalem, and were all baptized of him in the river of Jordan, confessing their sins.

Mark 1:6 And John was clothed with camel’s hair, and with a girdle of a skin about his loins; and he did eat locusts and wild honey;

Mark 1:7 And preached, saying, There cometh one mightier than I after me, the latchet of whose shoes I am not worthy to stoop down and unloose.

Mark 1:8 I indeed have baptized you with water: but he shall baptize you with the Holy Ghost.

Mark 1:9 And it came to pass in those days, that Jesus came from Nazareth of Galilee, and was baptized of John in Jordan.

Mark 1:10 And straightway coming up out of the water, he saw the heavens opened, and the Spirit like a dove descending upon him:

Mark 1:11 And there came a voice from heaven, saying, Thou art my beloved Son, in whom I am well pleased.

Mark 1:12 And immediately the Spirit driveth him into the wilderness.

Mark 1:13 And he was there in the wilderness forty days, tempted of Satan; and was with the wild beasts; and the angels ministered unto him.

Mark 1:14 Now after that John was put in prison, Jesus came into Galilee, preaching the gospel of the kingdom of God,

Mark 1:15 And saying, The time is fulfilled, and the kingdom of God is at hand: repent ye, and believe the gospel.

Mark 1:16 Now as he walked by the sea of Galilee, he saw Simon and Andrew his brother casting a net into the sea: for they were fishers.

Mark 1:17 And Jesus said unto them, Come ye after me, and I will make you to become fishers of men.

Mark 1:18 And straightway they forsook their nets, and followed him.

Mark 1:19 And when he had gone a little further thence, he saw James the son of Zebedee, and John his brother, who also were in the ship mending their nets.

Mark 1:20 And straightway he called them: and they left their father Zebedee in the ship with the hired servants, and went after him.

Mark 1:21 And they went into Capernaum; and straightway on the sabbath day he entered into the synagogue, and taught.

Mark 1:22 And they were astonished at his doctrine: for he taught them as one that had authority, and not as the scribes.

Mark 1:23 And there was in their synagogue a man with an unclean spirit; and he cried out,

Mark 1:24 Saying, Let us alone; what have we to do with thee, thou Jesus of Nazareth? art thou come to destroy us? I know thee who thou art, the Holy One of God.

Mark 1:25 And Jesus rebuked him, saying, Hold thy peace, and come out of him.

Mark 1:26 And when the unclean spirit had torn him, and cried with a loud voice, he came out of him.

Mark 1:27 And they were all amazed, insomuch that they questioned among themselves, saying, What thing is this? what new doctrine is this? for with authority commandeth he even the unclean spirits, and they do obey him.

Mark 1:28 And immediately his fame spread abroad throughout all the region round about Galilee.

Mark 1:29 And forthwith, when they were come out of the synagogue, they entered into the house of Simon and Andrew, with James and John.

Mark 1:30 But Simon’s wife’s mother lay sick of a fever, and anon they tell him of her.

Mark 1:31 And he came and took her by the hand, and lifted her up; and immediately the fever left her, and she ministered unto them.

Mark 1:32 And at even, when the sun did set, they brought unto him all that were diseased, and them that were possessed with devils.

Mark 1:33 And all the city was gathered together at the door.

Mark 1:34 And he healed many that were sick of divers diseases, and cast out many devils; and suffered not the devils to speak, because they knew him.

Mark 1:35 And in the morning, rising up a great while before day, he went out, and departed into a solitary place, and there prayed.

Mark 1:36 And Simon and they that were with him followed after him.

Mark 1:37 And when they had found him, they said unto him, All men seek for thee.

Mark 1:38 And he said unto them, Let us go into the next towns, that I may preach there also: for therefore came I forth.

Mark 1:39 And he preached in their synagogues throughout all Galilee, and cast out devils.

Mark 1:40 And there came a leper to him, beseeching him, and kneeling down to him, and saying unto him, If thou wilt, thou canst make me clean.

Mark 1:41 And Jesus, moved with compassion, put forth his hand, and touched him, and saith unto him, I will; be thou clean.

Mark 1:42 And as soon as he had spoken, immediately the leprosy departed from him, and he was cleansed.

Mark 1:43 And he straitly charged him, and forthwith sent him away;

Mark 1:44 And saith unto him, See thou say nothing to any man: but go thy way, shew thyself to the priest, and offer for thy cleansing those things which Moses commanded, for a testimony unto them.

Mark 1:45 But he went out, and began to publish it much, and to blaze abroad the matter, insomuch that Jesus could no more openly enter into the city, but was without in desert places: and they came to him from every quarter.
