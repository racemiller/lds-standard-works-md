# Hebrews 12

Hebrews 12 (summary): Whom the Lord loves He chastens—God is the Father of spirits—To see God, follow peace and holiness—Exalted Saints belong to the Church of the Firstborn.

Hebrews 12:1 Wherefore seeing we also are compassed about with so great a cloud of witnesses, let us lay aside every weight, and the sin which doth so easily beset us, and let us run with patience the race that is set before us,

Hebrews 12:2 Looking unto Jesus the author and finisher of our faith; who for the joy that was set before him endured the cross, despising the shame, and is set down at the right hand of the throne of God.

Hebrews 12:3 For consider him that endured such contradiction of sinners against himself, lest ye be wearied and faint in your minds.

Hebrews 12:4 Ye have not yet resisted unto blood, striving against sin.

Hebrews 12:5 And ye have forgotten the exhortation which speaketh unto you as unto children, My son, despise not thou the chastening of the Lord, nor faint when thou art rebuked of him:

Hebrews 12:6 For whom the Lord loveth he chasteneth, and scourgeth every son whom he receiveth.

Hebrews 12:7 If ye endure chastening, God dealeth with you as with sons; for what son is he whom the father chasteneth not?

Hebrews 12:8 But if ye be without chastisement, whereof all are partakers, then are ye bastards, and not sons.

Hebrews 12:9 Furthermore we have had fathers of our flesh which corrected us, and we gave them reverence: shall we not much rather be in subjection unto the Father of spirits, and live?

Hebrews 12:10 For they verily for a few days chastened us after their own pleasure; but he for our profit, that we might be partakers of his holiness.

Hebrews 12:11 Now no chastening for the present seemeth to be joyous, but grievous: nevertheless afterward it yieldeth the peaceable fruit of righteousness unto them which are exercised thereby.

Hebrews 12:12 Wherefore lift up the hands which hang down, and the feeble knees;

Hebrews 12:13 And make straight paths for your feet, lest that which is lame be turned out of the way; but let it rather be healed.

Hebrews 12:14 Follow peace with all men, and holiness, without which no man shall see the Lord:

Hebrews 12:15 Looking diligently lest any man fail of the grace of God; lest any root of bitterness springing up trouble you, and thereby many be defiled;

Hebrews 12:16 Lest there be any fornicator, or profane person, as Esau, who for one morsel of meat sold his birthright.

Hebrews 12:17 For ye know how that afterward, when he would have inherited the blessing, he was rejected: for he found no place of repentance, though he sought it carefully with tears.

Hebrews 12:18 For ye are not come unto the mount that might be touched, and that burned with fire, nor unto blackness, and darkness, and tempest,

Hebrews 12:19 And the sound of a trumpet, and the voice of words; which voice they that heard entreated that the word should not be spoken to them any more:

Hebrews 12:20 (For they could not endure that which was commanded, And if so much as a beast touch the mountain, it shall be stoned, or thrust through with a dart:

Hebrews 12:21 And so terrible was the sight, that Moses said, I exceedingly fear and quake:)

Hebrews 12:22 But ye are come unto mount Sion, and unto the city of the living God, the heavenly Jerusalem, and to an innumerable company of angels,

Hebrews 12:23 To the general assembly and church of the firstborn, which are written in heaven, and to God the Judge of all, and to the spirits of just men made perfect,

Hebrews 12:24 And to Jesus the mediator of the new covenant, and to the blood of sprinkling, that speaketh better things than that of Abel.

Hebrews 12:25 See that ye refuse not him that speaketh. For if they escaped not who refused him that spake on earth, much more shall not we escape, if we turn away from him that speaketh from heaven:

Hebrews 12:26 Whose voice then shook the earth: but now he hath promised, saying, Yet once more I shake not the earth only, but also heaven.

Hebrews 12:27 And this word, Yet once more, signifieth the removing of those things that are shaken, as of things that are made, that those things which cannot be shaken may remain.

Hebrews 12:28 Wherefore we receiving a kingdom which cannot be moved, let us have grace, whereby we may serve God acceptably with reverence and godly fear:

Hebrews 12:29 For our God is a consuming fire.
