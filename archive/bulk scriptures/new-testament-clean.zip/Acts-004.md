# Acts 4

Acts 4 (summary): Peter and John are arrested and brought before the council—Peter testifies that salvation comes because of Christ—The Sadducees strive to silence Peter and John—The Saints glory in the testimony of Jesus—They have all things in common.

Acts 4:1 And as they spake unto the people, the priests, and the captain of the temple, and the Sadducees, came upon them,

Acts 4:2 Being grieved that they taught the people, and preached through Jesus the resurrection from the dead.

Acts 4:3 And they laid hands on them, and put them in hold unto the next day: for it was now eventide.

Acts 4:4 Howbeit many of them which heard the word believed; and the number of the men was about five thousand.

Acts 4:5 And it came to pass on the morrow, that their rulers, and elders, and scribes,

Acts 4:6 And Annas the high priest, and Caiaphas, and John, and Alexander, and as many as were of the kindred of the high priest, were gathered together at Jerusalem.

Acts 4:7 And when they had set them in the midst, they asked, By what power, or by what name, have ye done this?

Acts 4:8 Then Peter, filled with the Holy Ghost, said unto them, Ye rulers of the people, and elders of Israel,

Acts 4:9 If we this day be examined of the good deed done to the impotent man, by what means he is made whole;

Acts 4:10 Be it known unto you all, and to all the people of Israel, that by the name of Jesus Christ of Nazareth, whom ye crucified, whom God raised from the dead, even by him doth this man stand here before you whole.

Acts 4:11 This is the stone which was set at nought of you builders, which is become the head of the corner.

Acts 4:12 Neither is there salvation in any other: for there is none other name under heaven given among men, whereby we must be saved.

Acts 4:13 Now when they saw the boldness of Peter and John, and perceived that they were unlearned and ignorant men, they marvelled; and they took knowledge of them, that they had been with Jesus.

Acts 4:14 And beholding the man which was healed standing with them, they could say nothing against it.

Acts 4:15 But when they had commanded them to go aside out of the council, they conferred among themselves,

Acts 4:16 Saying, What shall we do to these men? for that indeed a notable miracle hath been done by them is manifest to all them that dwell in Jerusalem; and we cannot deny it.

Acts 4:17 But that it spread no further among the people, let us straitly threaten them, that they speak henceforth to no man in this name.

Acts 4:18 And they called them, and commanded them not to speak at all nor teach in the name of Jesus.

Acts 4:19 But Peter and John answered and said unto them, Whether it be right in the sight of God to hearken unto you more than unto God, judge ye.

Acts 4:20 For we cannot but speak the things which we have seen and heard.

Acts 4:21 So when they had further threatened them, they let them go, finding nothing how they might punish them, because of the people: for all men glorified God for that which was done.

Acts 4:22 For the man was above forty years old, on whom this miracle of healing was shewed.

Acts 4:23 And being let go, they went to their own company, and reported all that the chief priests and elders had said unto them.

Acts 4:24 And when they heard that, they lifted up their voice to God with one accord, and said, Lord, thou art God, which hast made heaven, and earth, and the sea, and all that in them is:

Acts 4:25 Who by the mouth of thy servant David hast said, Why did the heathen rage, and the people imagine vain things?

Acts 4:26 The kings of the earth stood up, and the rulers were gathered together against the Lord, and against his Christ.

Acts 4:27 For of a truth against thy holy child Jesus, whom thou hast anointed, both Herod, and Pontius Pilate, with the Gentiles, and the people of Israel, were gathered together,

Acts 4:28 For to do whatsoever thy hand and thy counsel determined before to be done.

Acts 4:29 And now, Lord, behold their threatenings: and grant unto thy servants, that with all boldness they may speak thy word,

Acts 4:30 By stretching forth thine hand to heal; and that signs and wonders may be done by the name of thy holy child Jesus.

Acts 4:31 And when they had prayed, the place was shaken where they were assembled together; and they were all filled with the Holy Ghost, and they spake the word of God with boldness.

Acts 4:32 And the multitude of them that believed were of one heart and of one soul: neither said any of them that ought of the things which he possessed was his own; but they had all things common.

Acts 4:33 And with great power gave the apostles witness of the resurrection of the Lord Jesus: and great grace was upon them all.

Acts 4:34 Neither was there any among them that lacked: for as many as were possessors of lands or houses sold them, and brought the prices of the things that were sold,

Acts 4:35 And laid them down at the apostles’ feet: and distribution was made unto every man according as he had need.

Acts 4:36 And Joses, who by the apostles was surnamed Barnabas, (which is, being interpreted, The son of consolation,) a Levite, and of the country of Cyprus,

Acts 4:37 Having land, sold it, and brought the money, and laid it at the apostles’ feet.
