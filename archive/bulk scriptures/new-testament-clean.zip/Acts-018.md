# Acts 18

Acts 18 (summary): Being rejected by the Jews, Paul turns to the Gentiles—He preaches, ministers, and travels—Apollos also preaches with power.

Acts 18:1 After these things Paul departed from Athens, and came to Corinth;

Acts 18:2 And found a certain Jew named Aquila, born in Pontus, lately come from Italy, with his wife Priscilla; (because that Claudius had commanded all Jews to depart from Rome:) and came unto them.

Acts 18:3 And because he was of the same craft, he abode with them, and wrought: for by their occupation they were tentmakers.

Acts 18:4 And he reasoned in the synagogue every sabbath, and persuaded the Jews and the Greeks.

Acts 18:5 And when Silas and Timotheus were come from Macedonia, Paul was pressed in the spirit, and testified to the Jews that Jesus was Christ.

Acts 18:6 And when they opposed themselves, and blasphemed, he shook his raiment, and said unto them, Your blood be upon your own heads; I am clean: from henceforth I will go unto the Gentiles.

Acts 18:7 And he departed thence, and entered into a certain man’s house, named Justus, one that worshipped God, whose house joined hard to the synagogue.

Acts 18:8 And Crispus, the chief ruler of the synagogue, believed on the Lord with all his house; and many of the Corinthians hearing believed, and were baptized.

Acts 18:9 Then spake the Lord to Paul in the night by a vision, Be not afraid, but speak, and hold not thy peace:

Acts 18:10 For I am with thee, and no man shall set on thee to hurt thee: for I have much people in this city.

Acts 18:11 And he continued there a year and six months, teaching the word of God among them.

Acts 18:12 And when Gallio was the deputy of Achaia, the Jews made insurrection with one accord against Paul, and brought him to the judgment seat,

Acts 18:13 Saying, This fellow persuadeth men to worship God contrary to the law.

Acts 18:14 And when Paul was now about to open his mouth, Gallio said unto the Jews, If it were a matter of wrong or wicked lewdness, O ye Jews, reason would that I should bear with you:

Acts 18:15 But if it be a question of words and names, and of your law, look ye to it; for I will be no judge of such matters.

Acts 18:16 And he drave them from the judgment seat.

Acts 18:17 Then all the Greeks took Sosthenes, the chief ruler of the synagogue, and beat him before the judgment seat. And Gallio cared for none of those things.

Acts 18:18 And Paul after this tarried there yet a good while, and then took his leave of the brethren, and sailed thence into Syria, and with him Priscilla and Aquila; having shorn his head in Cenchrea: for he had a vow.

Acts 18:19 And he came to Ephesus, and left them there: but he himself entered into the synagogue, and reasoned with the Jews.

Acts 18:20 When they desired him to tarry longer time with them, he consented not;

Acts 18:21 But bade them farewell, saying, I must by all means keep this feast that cometh in Jerusalem: but I will return again unto you, if God will. And he sailed from Ephesus.

Acts 18:22 And when he had landed at Cæsarea, and gone up, and saluted the church, he went down to Antioch.

Acts 18:23 And after he had spent some time there, he departed, and went over all the country of Galatia and Phrygia in order, strengthening all the disciples.

Acts 18:24 And a certain Jew named Apollos, born at Alexandria, an eloquent man, and mighty in the scriptures, came to Ephesus.

Acts 18:25 This man was instructed in the way of the Lord; and being fervent in the spirit, he spake and taught diligently the things of the Lord, knowing only the baptism of John.

Acts 18:26 And he began to speak boldly in the synagogue: whom when Aquila and Priscilla had heard, they took him unto them, and expounded unto him the way of God more perfectly.

Acts 18:27 And when he was disposed to pass into Achaia, the brethren wrote, exhorting the disciples to receive him: who, when he was come, helped them much which had believed through grace:

Acts 18:28 For he mightily convinced the Jews, and that publickly, shewing by the scriptures that Jesus was Christ.
