# Acts 15

Acts 15 (summary): Great dissension arises at Antioch concerning circumcision—The Apostles at Jerusalem decide the issue—Paul chooses Silas as his companion.

Acts 15:1 And certain men which came down from Judæa taught the brethren, and said, Except ye be circumcised after the manner of Moses, ye cannot be saved.

Acts 15:2 When therefore Paul and Barnabas had no small dissension and disputation with them, they determined that Paul and Barnabas, and certain other of them, should go up to Jerusalem unto the apostles and elders about this question.

Acts 15:3 And being brought on their way by the church, they passed through Phenice and Samaria, declaring the conversion of the Gentiles: and they caused great joy unto all the brethren.

Acts 15:4 And when they were come to Jerusalem, they were received of the church, and of the apostles and elders, and they declared all things that God had done with them.

Acts 15:5 But there rose up certain of the sect of the Pharisees which believed, saying, That it was needful to circumcise them, and to command them to keep the law of Moses.

Acts 15:6 And the apostles and elders came together for to consider of this matter.

Acts 15:7 And when there had been much disputing, Peter rose up, and said unto them, Men and brethren, ye know how that a good while ago God made choice among us, that the Gentiles by my mouth should hear the word of the gospel, and believe.

Acts 15:8 And God, which knoweth the hearts, bare them witness, giving them the Holy Ghost, even as he did unto us;

Acts 15:9 And put no difference between us and them, purifying their hearts by faith.

Acts 15:10 Now therefore why tempt ye God, to put a yoke upon the neck of the disciples, which neither our fathers nor we were able to bear?

Acts 15:11 But we believe that through the grace of the Lord Jesus Christ we shall be saved, even as they.

Acts 15:12 Then all the multitude kept silence, and gave audience to Barnabas and Paul, declaring what miracles and wonders God had wrought among the Gentiles by them.

Acts 15:13 And after they had held their peace, James answered, saying, Men and brethren, hearken unto me:

Acts 15:14 Simeon hath declared how God at the first did visit the Gentiles, to take out of them a people for his name.

Acts 15:15 And to this agree the words of the prophets; as it is written,

Acts 15:16 After this I will return, and will build again the tabernacle of David, which is fallen down; and I will build again the ruins thereof, and I will set it up:

Acts 15:17 That the residue of men might seek after the Lord, and all the Gentiles, upon whom my name is called, saith the Lord, who doeth all these things.

Acts 15:18 Known unto God are all his works from the beginning of the world.

Acts 15:19 Wherefore my sentence is, that we trouble not them, which from among the Gentiles are turned to God:

Acts 15:20 But that we write unto them, that they abstain from pollutions of idols, and from fornication, and from things strangled, and from blood.

Acts 15:21 For Moses of old time hath in every city them that preach him, being read in the synagogues every sabbath day.

Acts 15:22 Then pleased it the apostles and elders, with the whole church, to send chosen men of their own company to Antioch with Paul and Barnabas; namely, Judas surnamed Barsabas, and Silas, chief men among the brethren:

Acts 15:23 And they wrote letters by them after this manner; The apostles and elders and brethren send greeting unto the brethren which are of the Gentiles in Antioch and Syria and Cilicia:

Acts 15:24 Forasmuch as we have heard, that certain which went out from us have troubled you with words, subverting your souls, saying, Ye must be circumcised, and keep the law: to whom we gave no such commandment:

Acts 15:25 It seemed good unto us, being assembled with one accord, to send chosen men unto you with our beloved Barnabas and Paul,

Acts 15:26 Men that have hazarded their lives for the name of our Lord Jesus Christ.

Acts 15:27 We have sent therefore Judas and Silas, who shall also tell you the same things by mouth.

Acts 15:28 For it seemed good to the Holy Ghost, and to us, to lay upon you no greater burden than these necessary things;

Acts 15:29 That ye abstain from meats offered to idols, and from blood, and from things strangled, and from fornication: from which if ye keep yourselves, ye shall do well. Fare ye well.

Acts 15:30 So when they were dismissed, they came to Antioch: and when they had gathered the multitude together, they delivered the epistle:

Acts 15:31 Which when they had read, they rejoiced for the consolation.

Acts 15:32 And Judas and Silas, being prophets also themselves, exhorted the brethren with many words, and confirmed them.

Acts 15:33 And after they had tarried there a space, they were let go in peace from the brethren unto the apostles.

Acts 15:34 Notwithstanding it pleased Silas to abide there still.

Acts 15:35 Paul also and Barnabas continued in Antioch, teaching and preaching the word of the Lord, with many others also.

Acts 15:36 And some days after Paul said unto Barnabas, Let us go again and visit our brethren in every city where we have preached the word of the Lord, and see how they do.

Acts 15:37 And Barnabas determined to take with them John, whose surname was Mark.

Acts 15:38 But Paul thought not good to take him with them, who departed from them from Pamphylia, and went not with them to the work.

Acts 15:39 And the contention was so sharp between them, that they departed asunder one from the other: and so Barnabas took Mark, and sailed unto Cyprus;

Acts 15:40 And Paul chose Silas, and departed, being recommended by the brethren unto the grace of God.

Acts 15:41 And he went through Syria and Cilicia, confirming the churches.
