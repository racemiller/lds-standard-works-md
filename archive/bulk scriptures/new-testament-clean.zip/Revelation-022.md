# Revelation 22

Revelation 22 (summary): The Saints will reign in celestial splendor—Christ will come, and men will be judged—Blessed are they who keep His commandments.

Revelation 22:1 And he shewed me a pure river of water of life, clear as crystal, proceeding out of the throne of God and of the Lamb.

Revelation 22:2 In the midst of the street of it, and on either side of the river, was there the tree of life, which bare twelve manner of fruits, and yielded her fruit every month: and the leaves of the tree were for the healing of the nations.

Revelation 22:3 And there shall be no more curse: but the throne of God and of the Lamb shall be in it; and his servants shall serve him:

Revelation 22:4 And they shall see his face; and his name shall be in their foreheads.

Revelation 22:5 And there shall be no night there; and they need no candle, neither light of the sun; for the Lord God giveth them light: and they shall reign for ever and ever.

Revelation 22:6 And he said unto me, These sayings are faithful and true: and the Lord God of the holy prophets sent his angel to shew unto his servants the things which must shortly be done.

Revelation 22:7 Behold, I come quickly: blessed is he that keepeth the sayings of the prophecy of this book.

Revelation 22:8 And I John saw these things, and heard them. And when I had heard and seen, I fell down to worship before the feet of the angel which shewed me these things.

Revelation 22:9 Then saith he unto me, See thou do it not: for I am thy fellowservant, and of thy brethren the prophets, and of them which keep the sayings of this book: worship God.

Revelation 22:10 And he saith unto me, Seal not the sayings of the prophecy of this book: for the time is at hand.

Revelation 22:11 He that is unjust, let him be unjust still: and he which is filthy, let him be filthy still: and he that is righteous, let him be righteous still: and he that is holy, let him be holy still.

Revelation 22:12 And, behold, I come quickly; and my reward is with me, to give every man according as his work shall be.

Revelation 22:13 I am Alpha and Omega, the beginning and the end, the first and the last.

Revelation 22:14 Blessed are they that do his commandments, that they may have right to the tree of life, and may enter in through the gates into the city.

Revelation 22:15 For without are dogs, and sorcerers, and whoremongers, and murderers, and idolaters, and whosoever loveth and maketh a lie.

Revelation 22:16 I Jesus have sent mine angel to testify unto you these things in the churches. I am the root and the offspring of David, and the bright and morning star.

Revelation 22:17 And the Spirit and the bride say, Come. And let him that heareth say, Come. And let him that is athirst come. And whosoever will, let him take the water of life freely.

Revelation 22:18 For I testify unto every man that heareth the words of the prophecy of this book, If any man shall add unto these things, God shall add unto him the plagues that are written in this book:

Revelation 22:19 And if any man shall take away from the words of the book of this prophecy, God shall take away his part out of the book of life, and out of the holy city, and from the things which are written in this book.

Revelation 22:20 He which testifieth these things saith, Surely I come quickly. Amen. Even so, come, Lord Jesus.

Revelation 22:21 The grace of our Lord Jesus Christ be with you all. Amen.
