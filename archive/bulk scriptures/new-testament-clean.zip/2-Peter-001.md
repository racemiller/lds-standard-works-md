# 2 Peter 1

2 Peter 1 (summary): Peter urges the Saints to make their calling and election sure—Prophecy comes by the power of the Holy Ghost.

2 Peter 1:1 Simon Peter, a servant and an apostle of Jesus Christ, to them that have obtained like precious faith with us through the righteousness of God and our Saviour Jesus Christ:

2 Peter 1:2 Grace and peace be multiplied unto you through the knowledge of God, and of Jesus our Lord,

2 Peter 1:3 According as his divine power hath given unto us all things that pertain unto life and godliness, through the knowledge of him that hath called us to glory and virtue:

2 Peter 1:4 Whereby are given unto us exceeding great and precious promises: that by these ye might be partakers of the divine nature, having escaped the corruption that is in the world through lust.

2 Peter 1:5 And beside this, giving all diligence, add to your faith virtue; and to virtue knowledge;

2 Peter 1:6 And to knowledge temperance; and to temperance patience; and to patience godliness;

2 Peter 1:7 And to godliness brotherly kindness; and to brotherly kindness charity.

2 Peter 1:8 For if these things be in you, and abound, they make you that ye shall neither be barren nor unfruitful in the knowledge of our Lord Jesus Christ.

2 Peter 1:9 But he that lacketh these things is blind, and cannot see afar off, and hath forgotten that he was purged from his old sins.

2 Peter 1:10 Wherefore the rather, brethren, give diligence to make your calling and election sure: for if ye do these things, ye shall never fall:

2 Peter 1:11 For so an entrance shall be ministered unto you abundantly into the everlasting kingdom of our Lord and Saviour Jesus Christ.

2 Peter 1:12 Wherefore I will not be negligent to put you always in remembrance of these things, though ye know them, and be established in the present truth.

2 Peter 1:13 Yea, I think it meet, as long as I am in this tabernacle, to stir you up by putting you in remembrance;

2 Peter 1:14 Knowing that shortly I must put off this my tabernacle, even as our Lord Jesus Christ hath shewed me.

2 Peter 1:15 Moreover I will endeavour that ye may be able after my decease to have these things always in remembrance.

2 Peter 1:16 For we have not followed cunningly devised fables, when we made known unto you the power and coming of our Lord Jesus Christ, but were eyewitnesses of his majesty.

2 Peter 1:17 For he received from God the Father honour and glory, when there came such a voice to him from the excellent glory, This is my beloved Son, in whom I am well pleased.

2 Peter 1:18 And this voice which came from heaven we heard, when we were with him in the holy mount.

2 Peter 1:19 We have also a more sure word of prophecy; whereunto ye do well that ye take heed, as unto a light that shineth in a dark place, until the day dawn, and the day star arise in your hearts:

2 Peter 1:20 Knowing this first, that no prophecy of the scripture is of any private interpretation.

2 Peter 1:21 For the prophecy came not in old time by the will of man: but holy men of God spake as they were moved by the Holy Ghost.
