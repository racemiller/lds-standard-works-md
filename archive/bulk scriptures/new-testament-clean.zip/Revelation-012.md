# Revelation 12

Revelation 12 (summary): John sees the imminent apostasy of the Church—He also sees the War in Heaven in the beginning when Satan was cast out—He sees the continuation of that war on earth.

Revelation 12:1 And there appeared a great wonder in heaven; a woman clothed with the sun, and the moon under her feet, and upon her head a crown of twelve stars:

Revelation 12:2 And she being with child cried, travailing in birth, and pained to be delivered.

Revelation 12:3 And there appeared another wonder in heaven; and behold a great red dragon, having seven heads and ten horns, and seven crowns upon his heads.

Revelation 12:4 And his tail drew the third part of the stars of heaven, and did cast them to the earth: and the dragon stood before the woman which was ready to be delivered, for to devour her child as soon as it was born.

Revelation 12:5 And she brought forth a man child, who was to rule all nations with a rod of iron: and her child was caught up unto God, and to his throne.

Revelation 12:6 And the woman fled into the wilderness, where she hath a place prepared of God, that they should feed her there a thousand two hundred and threescore days.

Revelation 12:7 And there was war in heaven: Michael and his angels fought against the dragon; and the dragon fought and his angels,

Revelation 12:8 And prevailed not; neither was their place found any more in heaven.

Revelation 12:9 And the great dragon was cast out, that old serpent, called the Devil, and Satan, which deceiveth the whole world: he was cast out into the earth, and his angels were cast out with him.

Revelation 12:10 And I heard a loud voice saying in heaven, Now is come salvation, and strength, and the kingdom of our God, and the power of his Christ: for the accuser of our brethren is cast down, which accused them before our God day and night.

Revelation 12:11 And they overcame him by the blood of the Lamb, and by the word of their testimony; and they loved not their lives unto the death.

Revelation 12:12 Therefore rejoice, ye heavens, and ye that dwell in them. Woe to the inhabiters of the earth and of the sea! for the devil is come down unto you, having great wrath, because he knoweth that he hath but a short time.

Revelation 12:13 And when the dragon saw that he was cast unto the earth, he persecuted the woman which brought forth the man child.

Revelation 12:14 And to the woman were given two wings of a great eagle, that she might fly into the wilderness, into her place, where she is nourished for a time, and times, and half a time, from the face of the serpent.

Revelation 12:15 And the serpent cast out of his mouth water as a flood after the woman, that he might cause her to be carried away of the flood.

Revelation 12:16 And the earth helped the woman, and the earth opened her mouth, and swallowed up the flood which the dragon cast out of his mouth.

Revelation 12:17 And the dragon was wroth with the woman, and went to make war with the remnant of her seed, which keep the commandments of God, and have the testimony of Jesus Christ.
