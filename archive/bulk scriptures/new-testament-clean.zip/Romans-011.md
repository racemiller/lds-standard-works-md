# Romans 11

Romans 11 (summary): Israel was chosen (foreordained) according to the election of grace—But some harden their hearts against it—The Gentiles are adopted into the house of Israel—The gospel goes preferentially to the Gentiles until the fulness of the Gentiles.

Romans 11:1 I say then, Hath God cast away his people? God forbid. For I also am an Israelite, of the seed of Abraham, of the tribe of Benjamin.

Romans 11:2 God hath not cast away his people which he foreknew. Wot ye not what the scripture saith of Elias? how he maketh intercession to God against Israel, saying,

Romans 11:3 Lord, they have killed thy prophets, and digged down thine altars; and I am left alone, and they seek my life.

Romans 11:4 But what saith the answer of God unto him? I have reserved to myself seven thousand men, who have not bowed the knee to the image of Baal.

Romans 11:5 Even so then at this present time also there is a remnant according to the election of grace.

Romans 11:6 And if by grace, then is it no more of works: otherwise grace is no more grace. But if it be of works, then is it no more grace: otherwise work is no more work.

Romans 11:7 What then? Israel hath not obtained that which he seeketh for; but the election hath obtained it, and the rest were blinded

Romans 11:8 (According as it is written, God hath given them the spirit of slumber, eyes that they should not see, and ears that they should not hear;) unto this day.

Romans 11:9 And David saith, Let their table be made a snare, and a trap, and a stumblingblock, and a recompence unto them:

Romans 11:10 Let their eyes be darkened, that they may not see, and bow down their back alway.

Romans 11:11 I say then, Have they stumbled that they should fall? God forbid: but rather through their fall salvation is come unto the Gentiles, for to provoke them to jealousy.

Romans 11:12 Now if the fall of them be the riches of the world, and the diminishing of them the riches of the Gentiles; how much more their fulness?

Romans 11:13 For I speak to you Gentiles, inasmuch as I am the apostle of the Gentiles, I magnify mine office:

Romans 11:14 If by any means I may provoke to emulation them which are my flesh, and might save some of them.

Romans 11:15 For if the casting away of them be the reconciling of the world, what shall the receiving of them be, but life from the dead?

Romans 11:16 For if the firstfruit be holy, the lump is also holy: and if the root be holy, so are the branches.

Romans 11:17 And if some of the branches be broken off, and thou, being a wild olive tree, wert grafted in among them, and with them partakest of the root and fatness of the olive tree;

Romans 11:18 Boast not against the branches. But if thou boast, thou bearest not the root, but the root thee.

Romans 11:19 Thou wilt say then, The branches were broken off, that I might be grafted in.

Romans 11:20 Well; because of unbelief they were broken off, and thou standest by faith. Be not highminded, but fear:

Romans 11:21 For if God spared not the natural branches, take heed lest he also spare not thee.

Romans 11:22 Behold therefore the goodness and severity of God: on them which fell, severity; but toward thee, goodness, if thou continue in his goodness: otherwise thou also shalt be cut off.

Romans 11:23 And they also, if they abide not still in unbelief, shall be grafted in: for God is able to graft them in again.

Romans 11:24 For if thou wert cut out of the olive tree which is wild by nature, and wert grafted contrary to nature into a good olive tree: how much more shall these, which be the natural branches, be grafted into their own olive tree?

Romans 11:25 For I would not, brethren, that ye should be ignorant of this mystery, lest ye should be wise in your own conceits; that blindness in part is happened to Israel, until the fulness of the Gentiles be come in.

Romans 11:26 And so all Israel shall be saved: as it is written, There shall come out of Sion the Deliverer, and shall turn away ungodliness from Jacob:

Romans 11:27 For this is my covenant unto them, when I shall take away their sins.

Romans 11:28 As concerning the gospel, they are enemies for your sakes: but as touching the election, they are beloved for the fathers’ sakes.

Romans 11:29 For the gifts and calling of God are without repentance.

Romans 11:30 For as ye in times past have not believed God, yet have now obtained mercy through their unbelief:

Romans 11:31 Even so have these also now not believed, that through your mercy they also may obtain mercy.

Romans 11:32 For God hath concluded them all in unbelief, that he might have mercy upon all.

Romans 11:33 O the depth of the riches both of the wisdom and knowledge of God! how unsearchable are his judgments, and his ways past finding out!

Romans 11:34 For who hath known the mind of the Lord? or who hath been his counsellor?

Romans 11:35 Or who hath first given to him, and it shall be recompensed unto him again?

Romans 11:36 For of him, and through him, and to him, are all things: to whom be glory for ever. Amen.
