# Acts 16

Acts 16 (summary): Paul is directed in a vision to preach in Macedonia—He casts an evil spirit out of a woman—He and Silas are imprisoned, and they convert the jailor—They admonish all to believe on the Lord Jesus and be saved.

Acts 16:1 Then came he to Derbe and Lystra: and, behold, a certain disciple was there, named Timotheus, the son of a certain woman, which was a Jewess, and believed; but his father was a Greek:

Acts 16:2 Which was well reported of by the brethren that were at Lystra and Iconium.

Acts 16:3 Him would Paul have to go forth with him; and took and circumcised him because of the Jews which were in those quarters: for they knew all that his father was a Greek.

Acts 16:4 And as they went through the cities, they delivered them the decrees for to keep, that were ordained of the apostles and elders which were at Jerusalem.

Acts 16:5 And so were the churches established in the faith, and increased in number daily.

Acts 16:6 Now when they had gone throughout Phrygia and the region of Galatia, and were forbidden of the Holy Ghost to preach the word in Asia,

Acts 16:7 After they were come to Mysia, they assayed to go into Bithynia: but the Spirit suffered them not.

Acts 16:8 And they passing by Mysia came down to Troas.

Acts 16:9 And a vision appeared to Paul in the night; There stood a man of Macedonia, and prayed him, saying, Come over into Macedonia, and help us.

Acts 16:10 And after he had seen the vision, immediately we endeavoured to go into Macedonia, assuredly gathering that the Lord had called us for to preach the gospel unto them.

Acts 16:11 Therefore loosing from Troas, we came with a straight course to Samothracia, and the next day to Neapolis;

Acts 16:12 And from thence to Philippi, which is the chief city of that part of Macedonia, and a colony: and we were in that city abiding certain days.

Acts 16:13 And on the sabbath we went out of the city by a river side, where prayer was wont to be made; and we sat down, and spake unto the women which resorted thither.

Acts 16:14 And a certain woman named Lydia, a seller of purple, of the city of Thyatira, which worshipped God, heard us: whose heart the Lord opened, that she attended unto the things which were spoken of Paul.

Acts 16:15 And when she was baptized, and her household, she besought us, saying, If ye have judged me to be faithful to the Lord, come into my house, and abide there. And she constrained us.

Acts 16:16 And it came to pass, as we went to prayer, a certain damsel possessed with a spirit of divination met us, which brought her masters much gain by soothsaying:

Acts 16:17 The same followed Paul and us, and cried, saying, These men are the servants of the most high God, which shew unto us the way of salvation.

Acts 16:18 And this did she many days. But Paul, being grieved, turned and said to the spirit, I command thee in the name of Jesus Christ to come out of her. And he came out the same hour.

Acts 16:19 And when her masters saw that the hope of their gains was gone, they caught Paul and Silas, and drew them into the marketplace unto the rulers,

Acts 16:20 And brought them to the magistrates, saying, These men, being Jews, do exceedingly trouble our city,

Acts 16:21 And teach customs, which are not lawful for us to receive, neither to observe, being Romans.

Acts 16:22 And the multitude rose up together against them: and the magistrates rent off their clothes, and commanded to beat them.

Acts 16:23 And when they had laid many stripes upon them, they cast them into prison, charging the jailor to keep them safely:

Acts 16:24 Who, having received such a charge, thrust them into the inner prison, and made their feet fast in the stocks.

Acts 16:25 And at midnight Paul and Silas prayed, and sang praises unto God: and the prisoners heard them.

Acts 16:26 And suddenly there was a great earthquake, so that the foundations of the prison were shaken: and immediately all the doors were opened, and every one’s bands were loosed.

Acts 16:27 And the keeper of the prison awaking out of his sleep, and seeing the prison doors open, he drew out his sword, and would have killed himself, supposing that the prisoners had been fled.

Acts 16:28 But Paul cried with a loud voice, saying, Do thyself no harm: for we are all here.

Acts 16:29 Then he called for a light, and sprang in, and came trembling, and fell down before Paul and Silas,

Acts 16:30 And brought them out, and said, Sirs, what must I do to be saved?

Acts 16:31 And they said, Believe on the Lord Jesus Christ, and thou shalt be saved, and thy house.

Acts 16:32 And they spake unto him the word of the Lord, and to all that were in his house.

Acts 16:33 And he took them the same hour of the night, and washed their stripes; and was baptized, he and all his, straightway.

Acts 16:34 And when he had brought them into his house, he set meat before them, and rejoiced, believing in God with all his house.

Acts 16:35 And when it was day, the magistrates sent the serjeants, saying, Let those men go.

Acts 16:36 And the keeper of the prison told this saying to Paul, The magistrates have sent to let you go: now therefore depart, and go in peace.

Acts 16:37 But Paul said unto them, They have beaten us openly uncondemned, being Romans, and have cast us into prison; and now do they thrust us out privily? nay verily; but let them come themselves and fetch us out.

Acts 16:38 And the serjeants told these words unto the magistrates: and they feared, when they heard that they were Romans.

Acts 16:39 And they came and besought them, and brought them out, and desired them to depart out of the city.

Acts 16:40 And they went out of the prison, and entered into the house of Lydia: and when they had seen the brethren, they comforted them, and departed.
