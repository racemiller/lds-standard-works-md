# Romans 3

Romans 3 (summary): Man is not justified by the law of Moses—He is justified through righteousness, which comes through faith in Christ, made possible through Christ’s atoning sacrifice.

Romans 3:1 What advantage then hath the Jew? or what profit is there of circumcision?

Romans 3:2 Much every way: chiefly, because that unto them were committed the oracles of God.

Romans 3:3 For what if some did not believe? shall their unbelief make the faith of God without effect?

Romans 3:4 God forbid: yea, let God be true, but every man a liar; as it is written, That thou mightest be justified in thy sayings, and mightest overcome when thou art judged.

Romans 3:5 But if our unrighteousness commend the righteousness of God, what shall we say? Is God unrighteous who taketh vengeance? (I speak as a man)

Romans 3:6 God forbid: for then how shall God judge the world?

Romans 3:7 For if the truth of God hath more abounded through my lie unto his glory; why yet am I also judged as a sinner?

Romans 3:8 And not rather, (as we be slanderously reported, and as some affirm that we say,) Let us do evil, that good may come? whose damnation is just.

Romans 3:9 What then? are we better than they? No, in no wise: for we have before proved both Jews and Gentiles, that they are all under sin;

Romans 3:10 As it is written, There is none righteous, no, not one:

Romans 3:11 There is none that understandeth, there is none that seeketh after God.

Romans 3:12 They are all gone out of the way, they are together become unprofitable; there is none that doeth good, no, not one.

Romans 3:13 Their throat is an open sepulchre; with their tongues they have used deceit; the poison of asps is under their lips:

Romans 3:14 Whose mouth is full of cursing and bitterness:

Romans 3:15 Their feet are swift to shed blood:

Romans 3:16 Destruction and misery are in their ways:

Romans 3:17 And the way of peace have they not known:

Romans 3:18 There is no fear of God before their eyes.

Romans 3:19 Now we know that what things soever the law saith, it saith to them who are under the law: that every mouth may be stopped, and all the world may become guilty before God.

Romans 3:20 Therefore by the deeds of the law there shall no flesh be justified in his sight: for by the law is the knowledge of sin.

Romans 3:21 But now the righteousness of God without the law is manifested, being witnessed by the law and the prophets;

Romans 3:22 Even the righteousness of God which is by faith of Jesus Christ unto all and upon all them that believe: for there is no difference:

Romans 3:23 For all have sinned, and come short of the glory of God;

Romans 3:24 Being justified freely by his grace through the redemption that is in Christ Jesus:

Romans 3:25 Whom God hath set forth to be a propitiation through faith in his blood, to declare his righteousness for the remission of sins that are past, through the forbearance of God;

Romans 3:26 To declare, I say, at this time his righteousness: that he might be just, and the justifier of him which believeth in Jesus.

Romans 3:27 Where is boasting then? It is excluded. By what law? of works? Nay: but by the law of faith.

Romans 3:28 Therefore we conclude that a man is justified by faith without the deeds of the law.

Romans 3:29 Is he the God of the Jews only? is he not also of the Gentiles? Yes, of the Gentiles also:

Romans 3:30 Seeing it is one God, which shall justify the circumcision by faith, and uncircumcision through faith.

Romans 3:31 Do we then make void the law through faith? God forbid: yea, we establish the law.
