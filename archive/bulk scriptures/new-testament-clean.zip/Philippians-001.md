# Philippians 1

Philippians 1 (summary): All that happened to Paul furthered the gospel cause—Our conduct should be worthy of the gospel.

Philippians 1:1 Paul and Timotheus, the servants of Jesus Christ, to all the saints in Christ Jesus which are at Philippi, with the bishops and deacons:

Philippians 1:2 Grace be unto you, and peace, from God our Father, and from the Lord Jesus Christ.

Philippians 1:3 I thank my God upon every remembrance of you,

Philippians 1:4 Always in every prayer of mine for you all making request with joy,

Philippians 1:5 For your fellowship in the gospel from the first day until now;

Philippians 1:6 Being confident of this very thing, that he which hath begun a good work in you will perform it until the day of Jesus Christ:

Philippians 1:7 Even as it is meet for me to think this of you all, because I have you in my heart; inasmuch as both in my bonds, and in the defence and confirmation of the gospel, ye all are partakers of my grace.

Philippians 1:8 For God is my record, how greatly I long after you all in the bowels of Jesus Christ.

Philippians 1:9 And this I pray, that your love may abound yet more and more in knowledge and in all judgment;

Philippians 1:10 That ye may approve things that are excellent; that ye may be sincere and without offence till the day of Christ;

Philippians 1:11 Being filled with the fruits of righteousness, which are by Jesus Christ, unto the glory and praise of God.

Philippians 1:12 But I would ye should understand, brethren, that the things which happened unto me have fallen out rather unto the furtherance of the gospel;

Philippians 1:13 So that my bonds in Christ are manifest in all the palace, and in all other places;

Philippians 1:14 And many of the brethren in the Lord, waxing confident by my bonds, are much more bold to speak the word without fear.

Philippians 1:15 Some indeed preach Christ even of envy and strife; and some also of good will:

Philippians 1:16 The one preach Christ of contention, not sincerely, supposing to add affliction to my bonds:

Philippians 1:17 But the other of love, knowing that I am set for the defence of the gospel.

Philippians 1:18 What then? notwithstanding, every way, whether in pretence, or in truth, Christ is preached; and I therein do rejoice, yea, and will rejoice.

Philippians 1:19 For I know that this shall turn to my salvation through your prayer, and the supply of the Spirit of Jesus Christ,

Philippians 1:20 According to my earnest expectation and my hope, that in nothing I shall be ashamed, but that with all boldness, as always, so now also Christ shall be magnified in my body, whether it be by life, or by death.

Philippians 1:21 For to me to live is Christ, and to die is gain.

Philippians 1:22 But if I live in the flesh, this is the fruit of my labour: yet what I shall choose I wot not.

Philippians 1:23 For I am in a strait betwixt two, having a desire to depart, and to be with Christ; which is far better:

Philippians 1:24 Nevertheless to abide in the flesh is more needful for you.

Philippians 1:25 And having this confidence, I know that I shall abide and continue with you all for your furtherance and joy of faith;

Philippians 1:26 That your rejoicing may be more abundant in Jesus Christ for me by my coming to you again.

Philippians 1:27 Only let your conversation be as it becometh the gospel of Christ: that whether I come and see you, or else be absent, I may hear of your affairs, that ye stand fast in one spirit, with one mind striving together for the faith of the gospel;

Philippians 1:28 And in nothing terrified by your adversaries: which is to them an evident token of perdition, but to you of salvation, and that of God.

Philippians 1:29 For unto you it is given in the behalf of Christ, not only to believe on him, but also to suffer for his sake;

Philippians 1:30 Having the same conflict which ye saw in me, and now hear to be in me.
