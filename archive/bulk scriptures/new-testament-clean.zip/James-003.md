# James 3

James 3 (summary): By governing the tongue, we gain perfection—Heavenly wisdom is pure, peaceable, and full of mercy.

James 3:1 My brethren, be not many masters, knowing that we shall receive the greater condemnation.

James 3:2 For in many things we offend all. If any man offend not in word, the same is a perfect man, and able also to bridle the whole body.

James 3:3 Behold, we put bits in the horses’ mouths, that they may obey us; and we turn about their whole body.

James 3:4 Behold also the ships, which though they be so great, and are driven of fierce winds, yet are they turned about with a very small helm, whithersoever the governor listeth.

James 3:5 Even so the tongue is a little member, and boasteth great things. Behold, how great a matter a little fire kindleth!

James 3:6 And the tongue is a fire, a world of iniquity: so is the tongue among our members, that it defileth the whole body, and setteth on fire the course of nature; and it is set on fire of hell.

James 3:7 For every kind of beasts, and of birds, and of serpents, and of things in the sea, is tamed, and hath been tamed of mankind:

James 3:8 But the tongue can no man tame; it is an unruly evil, full of deadly poison.

James 3:9 Therewith bless we God, even the Father; and therewith curse we men, which are made after the similitude of God.

James 3:10 Out of the same mouth proceedeth blessing and cursing. My brethren, these things ought not so to be.

James 3:11 Doth a fountain send forth at the same place sweet water and bitter?

James 3:12 Can the fig tree, my brethren, bear olive berries? either a vine, figs? so can no fountain both yield salt water and fresh.

James 3:13 Who is a wise man and endued with knowledge among you? let him shew out of a good conversation his works with meekness of wisdom.

James 3:14 But if ye have bitter envying and strife in your hearts, glory not, and lie not against the truth.

James 3:15 This wisdom descendeth not from above, but is earthly, sensual, devilish.

James 3:16 For where envying and strife is, there is confusion and every evil work.

James 3:17 But the wisdom that is from above is first pure, then peaceable, gentle, and easy to be entreated, full of mercy and good fruits, without partiality, and without hypocrisy.

James 3:18 And the fruit of righteousness is sown in peace of them that make peace.
