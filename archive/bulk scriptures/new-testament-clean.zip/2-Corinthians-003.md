# 2 Corinthians 3

2 Corinthians 3 (summary): The gospel surpasses the law of Moses—Where the Spirit of the Lord is, there is liberty.

2 Corinthians 3:1 Do we begin again to commend ourselves? or need we, as some others, epistles of commendation to you, or letters of commendation from you?

2 Corinthians 3:2 Ye are our epistle written in our hearts, known and read of all men:

2 Corinthians 3:3 Forasmuch as ye are manifestly declared to be the epistle of Christ ministered by us, written not with ink, but with the Spirit of the living God; not in tables of stone, but in fleshy tables of the heart.

2 Corinthians 3:4 And such trust have we through Christ to God-ward:

2 Corinthians 3:5 Not that we are sufficient of ourselves to think any thing as of ourselves; but our sufficiency is of God;

2 Corinthians 3:6 Who also hath made us able ministers of the new testament; not of the letter, but of the spirit: for the letter killeth, but the spirit giveth life.

2 Corinthians 3:7 But if the ministration of death, written and engraven in stones, was glorious, so that the children of Israel could not steadfastly behold the face of Moses for the glory of his countenance; which glory was to be done away:

2 Corinthians 3:8 How shall not the ministration of the spirit be rather glorious?

2 Corinthians 3:9 For if the ministration of condemnation be glory, much more doth the ministration of righteousness exceed in glory.

2 Corinthians 3:10 For even that which was made glorious had no glory in this respect, by reason of the glory that excelleth.

2 Corinthians 3:11 For if that which is done away was glorious, much more that which remaineth is glorious.

2 Corinthians 3:12 Seeing then that we have such hope, we use great plainness of speech:

2 Corinthians 3:13 And not as Moses, which put a veil over his face, that the children of Israel could not steadfastly look to the end of that which is abolished:

2 Corinthians 3:14 But their minds were blinded: for until this day remaineth the same veil untaken away in the reading of the old testament; which veil is done away in Christ.

2 Corinthians 3:15 But even unto this day, when Moses is read, the veil is upon their heart.

2 Corinthians 3:16 Nevertheless when it shall turn to the Lord, the veil shall be taken away.

2 Corinthians 3:17 Now the Lord is that Spirit: and where the Spirit of the Lord is, there is liberty.

2 Corinthians 3:18 But we all, with open face beholding as in a glass the glory of the Lord, are changed into the same image from glory to glory, even as by the Spirit of the Lord.
