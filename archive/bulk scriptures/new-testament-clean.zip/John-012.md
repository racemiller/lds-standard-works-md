# John 12

John 12 (summary): Mary anoints Jesus’ feet—His triumphal entry into Jerusalem is recounted—He foretells His death—To receive Christ is to receive the Father.

John 12:1 Then Jesus six days before the passover came to Bethany, where Lazarus was which had been dead, whom he raised from the dead.

John 12:2 There they made him a supper; and Martha served: but Lazarus was one of them that sat at the table with him.

John 12:3 Then took Mary a pound of ointment of spikenard, very costly, and anointed the feet of Jesus, and wiped his feet with her hair: and the house was filled with the odour of the ointment.

John 12:4 Then saith one of his disciples, Judas Iscariot, Simon’s son, which should betray him,

John 12:5 Why was not this ointment sold for three hundred pence, and given to the poor?

John 12:6 This he said, not that he cared for the poor; but because he was a thief, and had the bag, and bare what was put therein.

John 12:7 Then said Jesus, Let her alone: against the day of my burying hath she kept this.

John 12:8 For the poor always ye have with you; but me ye have not always.

John 12:9 Much people of the Jews therefore knew that he was there: and they came not for Jesus’ sake only, but that they might see Lazarus also, whom he had raised from the dead.

John 12:10 But the chief priests consulted that they might put Lazarus also to death;

John 12:11 Because that by reason of him many of the Jews went away, and believed on Jesus.

John 12:12 On the next day much people that were come to the feast, when they heard that Jesus was coming to Jerusalem,

John 12:13 Took branches of palm trees, and went forth to meet him, and cried, Hosanna: Blessed is the King of Israel that cometh in the name of the Lord.

John 12:14 And Jesus, when he had found a young ass, sat thereon; as it is written,

John 12:15 Fear not, daughter of Sion: behold, thy King cometh, sitting on an ass’s colt.

John 12:16 These things understood not his disciples at the first: but when Jesus was glorified, then remembered they that these things were written of him, and that they had done these things unto him.

John 12:17 The people therefore that was with him when he called Lazarus out of his grave, and raised him from the dead, bare record.

John 12:18 For this cause the people also met him, for that they heard that he had done this miracle.

John 12:19 The Pharisees therefore said among themselves, Perceive ye how ye prevail nothing? behold, the world is gone after him.

John 12:20 And there were certain Greeks among them that came up to worship at the feast:

John 12:21 The same came therefore to Philip, which was of Bethsaida of Galilee, and desired him, saying, Sir, we would see Jesus.

John 12:22 Philip cometh and telleth Andrew: and again Andrew and Philip tell Jesus.

John 12:23 And Jesus answered them, saying, The hour is come, that the Son of man should be glorified.

John 12:24 Verily, verily, I say unto you, Except a corn of wheat fall into the ground and die, it abideth alone: but if it die, it bringeth forth much fruit.

John 12:25 He that loveth his life shall lose it; and he that hateth his life in this world shall keep it unto life eternal.

John 12:26 If any man serve me, let him follow me; and where I am, there shall also my servant be: if any man serve me, him will my Father honour.

John 12:27 Now is my soul troubled; and what shall I say? Father, save me from this hour: but for this cause came I unto this hour.

John 12:28 Father, glorify thy name. Then came there a voice from heaven, saying, I have both glorified it, and will glorify it again.

John 12:29 The people therefore, that stood by, and heard it, said that it thundered: others said, An angel spake to him.

John 12:30 Jesus answered and said, This voice came not because of me, but for your sakes.

John 12:31 Now is the judgment of this world: now shall the prince of this world be cast out.

John 12:32 And I, if I be lifted up from the earth, will draw all men unto me.

John 12:33 This he said, signifying what death he should die.

John 12:34 The people answered him, We have heard out of the law that Christ abideth for ever: and how sayest thou, The Son of man must be lifted up? who is this Son of man?

John 12:35 Then Jesus said unto them, Yet a little while is the light with you. Walk while ye have the light, lest darkness come upon you: for he that walketh in darkness knoweth not whither he goeth.

John 12:36 While ye have light, believe in the light, that ye may be the children of light. These things spake Jesus, and departed, and did hide himself from them.

John 12:37 But though he had done so many miracles before them, yet they believed not on him:

John 12:38 That the saying of Esaias the prophet might be fulfilled, which he spake, Lord, who hath believed our report? and to whom hath the arm of the Lord been revealed?

John 12:39 Therefore they could not believe, because that Esaias said again,

John 12:40 He hath blinded their eyes, and hardened their heart; that they should not see with their eyes, nor understand with their heart, and be converted, and I should heal them.

John 12:41 These things said Esaias, when he saw his glory, and spake of him.

John 12:42 Nevertheless among the chief rulers also many believed on him; but because of the Pharisees they did not confess him, lest they should be put out of the synagogue:

John 12:43 For they loved the praise of men more than the praise of God.

John 12:44 Jesus cried and said, He that believeth on me, believeth not on me, but on him that sent me.

John 12:45 And he that seeth me seeth him that sent me.

John 12:46 I am come a light into the world, that whosoever believeth on me should not abide in darkness.

John 12:47 And if any man hear my words, and believe not, I judge him not: for I came not to judge the world, but to save the world.

John 12:48 He that rejecteth me, and receiveth not my words, hath one that judgeth him: the word that I have spoken, the same shall judge him in the last day.

John 12:49 For I have not spoken of myself; but the Father which sent me, he gave me a commandment, what I should say, and what I should speak.

John 12:50 And I know that his commandment is life everlasting: whatsoever I speak therefore, even as the Father said unto me, so I speak.
