# Acts 28

Acts 28 (summary): Paul is unharmed by a viper’s bite—He heals the sick in Melita—He preaches in Rome, first to the Jews and then to the Gentiles.

Acts 28:1 And when they were escaped, then they knew that the island was called Melita.

Acts 28:2 And the barbarous people shewed us no little kindness: for they kindled a fire, and received us every one, because of the present rain, and because of the cold.

Acts 28:3 And when Paul had gathered a bundle of sticks, and laid them on the fire, there came a viper out of the heat, and fastened on his hand.

Acts 28:4 And when the barbarians saw the venomous beast hang on his hand, they said among themselves, No doubt this man is a murderer, whom, though he hath escaped the sea, yet vengeance suffereth not to live.

Acts 28:5 And he shook off the beast into the fire, and felt no harm.

Acts 28:6 Howbeit they looked when he should have swollen, or fallen down dead suddenly: but after they had looked a great while, and saw no harm come to him, they changed their minds, and said that he was a god.

Acts 28:7 In the same quarters were possessions of the chief man of the island, whose name was Publius; who received us, and lodged us three days courteously.

Acts 28:8 And it came to pass, that the father of Publius lay sick of a fever and of a bloody flux: to whom Paul entered in, and prayed, and laid his hands on him, and healed him.

Acts 28:9 So when this was done, others also, which had diseases in the island, came, and were healed:

Acts 28:10 Who also honoured us with many honours; and when we departed, they laded us with such things as were necessary.

Acts 28:11 And after three months we departed in a ship of Alexandria, which had wintered in the isle, whose sign was Castor and Pollux.

Acts 28:12 And landing at Syracuse, we tarried there three days.

Acts 28:13 And from thence we fetched a compass, and came to Rhegium: and after one day the south wind blew, and we came the next day to Puteoli:

Acts 28:14 Where we found brethren, and were desired to tarry with them seven days: and so we went toward Rome.

Acts 28:15 And from thence, when the brethren heard of us, they came to meet us as far as Appii forum, and The three taverns: whom when Paul saw, he thanked God, and took courage.

Acts 28:16 And when we came to Rome, the centurion delivered the prisoners to the captain of the guard: but Paul was suffered to dwell by himself with a soldier that kept him.

Acts 28:17 And it came to pass, that after three days Paul called the chief of the Jews together: and when they were come together, he said unto them, Men and brethren, though I have committed nothing against the people, or customs of our fathers, yet was I delivered prisoner from Jerusalem into the hands of the Romans.

Acts 28:18 Who, when they had examined me, would have let me go, because there was no cause of death in me.

Acts 28:19 But when the Jews spake against it, I was constrained to appeal unto Cæsar; not that I had ought to accuse my nation of.

Acts 28:20 For this cause therefore have I called for you, to see you, and to speak with you: because that for the hope of Israel I am bound with this chain.

Acts 28:21 And they said unto him, We neither received letters out of Judæa concerning thee, neither any of the brethren that came shewed or spake any harm of thee.

Acts 28:22 But we desire to hear of thee what thou thinkest: for as concerning this sect, we know that every where it is spoken against.

Acts 28:23 And when they had appointed him a day, there came many to him into his lodging; to whom he expounded and testified the kingdom of God, persuading them concerning Jesus, both out of the law of Moses, and out of the prophets, from morning till evening.

Acts 28:24 And some believed the things which were spoken, and some believed not.

Acts 28:25 And when they agreed not among themselves, they departed, after that Paul had spoken one word, Well spake the Holy Ghost by Esaias the prophet unto our fathers,

Acts 28:26 Saying, Go unto this people, and say, Hearing ye shall hear, and shall not understand; and seeing ye shall see, and not perceive:

Acts 28:27 For the heart of this people is waxed gross, and their ears are dull of hearing, and their eyes have they closed; lest they should see with their eyes, and hear with their ears, and understand with their heart, and should be converted, and I should heal them.

Acts 28:28 Be it known therefore unto you, that the salvation of God is sent unto the Gentiles, and that they will hear it.

Acts 28:29 And when he had said these words, the Jews departed, and had great reasoning among themselves.

Acts 28:30 And Paul dwelt two whole years in his own hired house, and received all that came in unto him,

Acts 28:31 Preaching the kingdom of God, and teaching those things which concern the Lord Jesus Christ, with all confidence, no man forbidding him.
