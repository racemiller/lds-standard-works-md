# John 16

John 16 (summary): Jesus discourses on the mission of the Holy Ghost—He tells of His death and resurrection, announces that He is the Son of God, and says that He has overcome the world.

John 16:1 These things have I spoken unto you, that ye should not be offended.

John 16:2 They shall put you out of the synagogues: yea, the time cometh, that whosoever killeth you will think that he doeth God service.

John 16:3 And these things will they do unto you, because they have not known the Father, nor me.

John 16:4 But these things have I told you, that when the time shall come, ye may remember that I told you of them. And these things I said not unto you at the beginning, because I was with you.

John 16:5 But now I go my way to him that sent me; and none of you asketh me, Whither goest thou?

John 16:6 But because I have said these things unto you, sorrow hath filled your heart.

John 16:7 Nevertheless I tell you the truth; It is expedient for you that I go away: for if I go not away, the Comforter will not come unto you; but if I depart, I will send him unto you.

John 16:8 And when he is come, he will reprove the world of sin, and of righteousness, and of judgment:

John 16:9 Of sin, because they believe not on me;

John 16:10 Of righteousness, because I go to my Father, and ye see me no more;

John 16:11 Of judgment, because the prince of this world is judged.

John 16:12 I have yet many things to say unto you, but ye cannot bear them now.

John 16:13 Howbeit when he, the Spirit of truth, is come, he will guide you into all truth: for he shall not speak of himself; but whatsoever he shall hear, that shall he speak: and he will shew you things to come.

John 16:14 He shall glorify me: for he shall receive of mine, and shall shew it unto you.

John 16:15 All things that the Father hath are mine: therefore said I, that he shall take of mine, and shall shew it unto you.

John 16:16 A little while, and ye shall not see me: and again, a little while, and ye shall see me, because I go to the Father.

John 16:17 Then said some of his disciples among themselves, What is this that he saith unto us, A little while, and ye shall not see me: and again, a little while, and ye shall see me: and, Because I go to the Father?

John 16:18 They said therefore, What is this that he saith, A little while? we cannot tell what he saith.

John 16:19 Now Jesus knew that they were desirous to ask him, and said unto them, Do ye inquire among yourselves of that I said, A little while, and ye shall not see me: and again, a little while, and ye shall see me?

John 16:20 Verily, verily, I say unto you, That ye shall weep and lament, but the world shall rejoice: and ye shall be sorrowful, but your sorrow shall be turned into joy.

John 16:21 A woman when she is in travail hath sorrow, because her hour is come: but as soon as she is delivered of the child, she remembereth no more the anguish, for joy that a man is born into the world.

John 16:22 And ye now therefore have sorrow: but I will see you again, and your heart shall rejoice, and your joy no man taketh from you.

John 16:23 And in that day ye shall ask me nothing. Verily, verily, I say unto you, Whatsoever ye shall ask the Father in my name, he will give it you.

John 16:24 Hitherto have ye asked nothing in my name: ask, and ye shall receive, that your joy may be full.

John 16:25 These things have I spoken unto you in proverbs: but the time cometh, when I shall no more speak unto you in proverbs, but I shall shew you plainly of the Father.

John 16:26 At that day ye shall ask in my name: and I say not unto you, that I will pray the Father for you:

John 16:27 For the Father himself loveth you, because ye have loved me, and have believed that I came out from God.

John 16:28 I came forth from the Father, and am come into the world: again, I leave the world, and go to the Father.

John 16:29 His disciples said unto him, Lo, now speakest thou plainly, and speakest no proverb.

John 16:30 Now are we sure that thou knowest all things, and needest not that any man should ask thee: by this we believe that thou camest forth from God.

John 16:31 Jesus answered them, Do ye now believe?

John 16:32 Behold, the hour cometh, yea, is now come, that ye shall be scattered, every man to his own, and shall leave me alone: and yet I am not alone, because the Father is with me.

John 16:33 These things I have spoken unto you, that in me ye might have peace. In the world ye shall have tribulation: but be of good cheer; I have overcome the world.
