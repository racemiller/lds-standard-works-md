# 1 Timothy 1

1 Timothy 1 (summary): Counsel is given to teach true doctrine only—Christ came to save repentant sinners.

1 Timothy 1:1 Paul, an apostle of Jesus Christ by the commandment of God our Saviour, and Lord Jesus Christ, which is our hope;

1 Timothy 1:2 Unto Timothy, my own son in the faith: Grace, mercy, and peace, from God our Father and Jesus Christ our Lord.

1 Timothy 1:3 As I besought thee to abide still at Ephesus, when I went into Macedonia, that thou mightest charge some that they teach no other doctrine,

1 Timothy 1:4 Neither give heed to fables and endless genealogies, which minister questions, rather than godly edifying which is in faith: so do.

1 Timothy 1:5 Now the end of the commandment is charity out of a pure heart, and of a good conscience, and of faith unfeigned:

1 Timothy 1:6 From which some having swerved have turned aside unto vain jangling;

1 Timothy 1:7 Desiring to be teachers of the law; understanding neither what they say, nor whereof they affirm.

1 Timothy 1:8 But we know that the law is good, if a man use it lawfully;

1 Timothy 1:9 Knowing this, that the law is not made for a righteous man, but for the lawless and disobedient, for the ungodly and for sinners, for unholy and profane, for murderers of fathers and murderers of mothers, for manslayers,

1 Timothy 1:10 For whoremongers, for them that defile themselves with mankind, for menstealers, for liars, for perjured persons, and if there be any other thing that is contrary to sound doctrine;

1 Timothy 1:11 According to the glorious gospel of the blessed God, which was committed to my trust.

1 Timothy 1:12 And I thank Christ Jesus our Lord, who hath enabled me, for that he counted me faithful, putting me into the ministry;

1 Timothy 1:13 Who was before a blasphemer, and a persecutor, and injurious: but I obtained mercy, because I did it ignorantly in unbelief.

1 Timothy 1:14 And the grace of our Lord was exceeding abundant with faith and love which is in Christ Jesus.

1 Timothy 1:15 This is a faithful saying, and worthy of all acceptation, that Christ Jesus came into the world to save sinners; of whom I am chief.

1 Timothy 1:16 Howbeit for this cause I obtained mercy, that in me first Jesus Christ might shew forth all longsuffering, for a pattern to them which should hereafter believe on him to life everlasting.

1 Timothy 1:17 Now unto the King eternal, immortal, invisible, the only wise God, be honour and glory for ever and ever. Amen.

1 Timothy 1:18 This charge I commit unto thee, son Timothy, according to the prophecies which went before on thee, that thou by them mightest war a good warfare;

1 Timothy 1:19 Holding faith, and a good conscience; which some having put away concerning faith have made shipwreck:

1 Timothy 1:20 Of whom is Hymenæus and Alexander; whom I have delivered unto Satan, that they may learn not to blaspheme.
