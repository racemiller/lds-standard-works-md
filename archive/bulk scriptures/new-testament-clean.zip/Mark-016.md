# Mark 16

Mark 16 (summary): Christ is risen—He appears to Mary Magdalene, then to others—He sends the Apostles to preach and promises that signs will follow faith—He ascends into heaven.

Mark 16:1 And when the sabbath was past, Mary Magdalene, and Mary the mother of James, and Salome, had bought sweet spices, that they might come and anoint him.

Mark 16:2 And very early in the morning the first day of the week, they came unto the sepulchre at the rising of the sun.

Mark 16:3 And they said among themselves, Who shall roll us away the stone from the door of the sepulchre?

Mark 16:4 And when they looked, they saw that the stone was rolled away: for it was very great.

Mark 16:5 And entering into the sepulchre, they saw a young man sitting on the right side, clothed in a long white garment; and they were affrighted.

Mark 16:6 And he saith unto them, Be not affrighted: Ye seek Jesus of Nazareth, which was crucified: he is risen; he is not here: behold the place where they laid him.

Mark 16:7 But go your way, tell his disciples and Peter that he goeth before you into Galilee: there shall ye see him, as he said unto you.

Mark 16:8 And they went out quickly, and fled from the sepulchre; for they trembled and were amazed: neither said they any thing to any man; for they were afraid.

Mark 16:9 Now when Jesus was risen early the first day of the week, he appeared first to Mary Magdalene, out of whom he had cast seven devils.

Mark 16:10 And she went and told them that had been with him, as they mourned and wept.

Mark 16:11 And they, when they had heard that he was alive, and had been seen of her, believed not.

Mark 16:12 After that he appeared in another form unto two of them, as they walked, and went into the country.

Mark 16:13 And they went and told it unto the residue: neither believed they them.

Mark 16:14 Afterward he appeared unto the eleven as they sat at meat, and upbraided them with their unbelief and hardness of heart, because they believed not them which had seen him after he was risen.

Mark 16:15 And he said unto them, Go ye into all the world, and preach the gospel to every creature.

Mark 16:16 He that believeth and is baptized shall be saved; but he that believeth not shall be damned.

Mark 16:17 And these signs shall follow them that believe; In my name shall they cast out devils; they shall speak with new tongues;

Mark 16:18 They shall take up serpents; and if they drink any deadly thing, it shall not hurt them; they shall lay hands on the sick, and they shall recover.

Mark 16:19 So then after the Lord had spoken unto them, he was received up into heaven, and sat on the right hand of God.

Mark 16:20 And they went forth, and preached every where, the Lord working with them, and confirming the word with signs following. Amen.
