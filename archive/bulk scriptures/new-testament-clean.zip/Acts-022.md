# Acts 22

Acts 22 (summary): Paul recounts the story of his conversion and also tells of seeing Jesus in a vision—He is accorded some privileges as a Roman citizen.

Acts 22:1 Men, brethren, and fathers, hear ye my defence which I make now unto you.

Acts 22:2 (And when they heard that he spake in the Hebrew tongue to them, they kept the more silence: and he saith,)

Acts 22:3 I am verily a man which am a Jew, born in Tarsus, a city in Cilicia, yet brought up in this city at the feet of Gamaliel, and taught according to the perfect manner of the law of the fathers, and was zealous toward God, as ye all are this day.

Acts 22:4 And I persecuted this way unto the death, binding and delivering into prisons both men and women.

Acts 22:5 As also the high priest doth bear me witness, and all the estate of the elders: from whom also I received letters unto the brethren, and went to Damascus, to bring them which were there bound unto Jerusalem, for to be punished.

Acts 22:6 And it came to pass, that, as I made my journey, and was come nigh unto Damascus about noon, suddenly there shone from heaven a great light round about me.

Acts 22:7 And I fell unto the ground, and heard a voice saying unto me, Saul, Saul, why persecutest thou me?

Acts 22:8 And I answered, Who art thou, Lord? And he said unto me, I am Jesus of Nazareth, whom thou persecutest.

Acts 22:9 And they that were with me saw indeed the light, and were afraid; but they heard not the voice of him that spake to me.

Acts 22:10 And I said, What shall I do, Lord? And the Lord said unto me, Arise, and go into Damascus; and there it shall be told thee of all things which are appointed for thee to do.

Acts 22:11 And when I could not see for the glory of that light, being led by the hand of them that were with me, I came into Damascus.

Acts 22:12 And one Ananias, a devout man according to the law, having a good report of all the Jews which dwelt there,

Acts 22:13 Came unto me, and stood, and said unto me, Brother Saul, receive thy sight. And the same hour I looked up upon him.

Acts 22:14 And he said, The God of our fathers hath chosen thee, that thou shouldest know his will, and see that Just One, and shouldest hear the voice of his mouth.

Acts 22:15 For thou shalt be his witness unto all men of what thou hast seen and heard.

Acts 22:16 And now why tarriest thou? arise, and be baptized, and wash away thy sins, calling on the name of the Lord.

Acts 22:17 And it came to pass, that, when I was come again to Jerusalem, even while I prayed in the temple, I was in a trance;

Acts 22:18 And saw him saying unto me, Make haste, and get thee quickly out of Jerusalem: for they will not receive thy testimony concerning me.

Acts 22:19 And I said, Lord, they know that I imprisoned and beat in every synagogue them that believed on thee:

Acts 22:20 And when the blood of thy martyr Stephen was shed, I also was standing by, and consenting unto his death, and kept the raiment of them that slew him.

Acts 22:21 And he said unto me, Depart: for I will send thee far hence unto the Gentiles.

Acts 22:22 And they gave him audience unto this word, and then lifted up their voices, and said, Away with such a fellow from the earth: for it is not fit that he should live.

Acts 22:23 And as they cried out, and cast off their clothes, and threw dust into the air,

Acts 22:24 The chief captain commanded him to be brought into the castle, and bade that he should be examined by scourging; that he might know wherefore they cried so against him.

Acts 22:25 And as they bound him with thongs, Paul said unto the centurion that stood by, Is it lawful for you to scourge a man that is a Roman, and uncondemned?

Acts 22:26 When the centurion heard that, he went and told the chief captain, saying, Take heed what thou doest: for this man is a Roman.

Acts 22:27 Then the chief captain came, and said unto him, Tell me, art thou a Roman? He said, Yea.

Acts 22:28 And the chief captain answered, With a great sum obtained I this freedom. And Paul said, But I was free born.

Acts 22:29 Then straightway they departed from him which should have examined him: and the chief captain also was afraid, after he knew that he was a Roman, and because he had bound him.

Acts 22:30 On the morrow, because he would have known the certainty wherefore he was accused of the Jews, he loosed him from his bands, and commanded the chief priests and all their council to appear, and brought Paul down, and set him before them.
