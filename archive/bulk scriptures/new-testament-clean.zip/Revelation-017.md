# Revelation 17

Revelation 17 (summary): John is shown that Babylon the great, the mother of harlots and abominations, has become established throughout the earth.

Revelation 17:1 And there came one of the seven angels which had the seven vials, and talked with me, saying unto me, Come hither; I will shew unto thee the judgment of the great whore that sitteth upon many waters:

Revelation 17:2 With whom the kings of the earth have committed fornication, and the inhabitants of the earth have been made drunk with the wine of her fornication.

Revelation 17:3 So he carried me away in the spirit into the wilderness: and I saw a woman sit upon a scarlet coloured beast, full of names of blasphemy, having seven heads and ten horns.

Revelation 17:4 And the woman was arrayed in purple and scarlet colour, and decked with gold and precious stones and pearls, having a golden cup in her hand full of abominations and filthiness of her fornication:

Revelation 17:5 And upon her forehead was a name written, Mystery, Babylon the Great, the Mother of Harlots and Abominations of the Earth.

Revelation 17:6 And I saw the woman drunken with the blood of the saints, and with the blood of the martyrs of Jesus: and when I saw her, I wondered with great admiration.

Revelation 17:7 And the angel said unto me, Wherefore didst thou marvel? I will tell thee the mystery of the woman, and of the beast that carrieth her, which hath the seven heads and ten horns.

Revelation 17:8 The beast that thou sawest was, and is not; and shall ascend out of the bottomless pit, and go into perdition: and they that dwell on the earth shall wonder, whose names were not written in the book of life from the foundation of the world, when they behold the beast that was, and is not, and yet is.

Revelation 17:9 And here is the mind which hath wisdom. The seven heads are seven mountains, on which the woman sitteth.

Revelation 17:10 And there are seven kings: five are fallen, and one is, and the other is not yet come; and when he cometh, he must continue a short space.

Revelation 17:11 And the beast that was, and is not, even he is the eighth, and is of the seven, and goeth into perdition.

Revelation 17:12 And the ten horns which thou sawest are ten kings, which have received no kingdom as yet; but receive power as kings one hour with the beast.

Revelation 17:13 These have one mind, and shall give their power and strength unto the beast.

Revelation 17:14 These shall make war with the Lamb, and the Lamb shall overcome them: for he is Lord of lords, and King of kings: and they that are with him are called, and chosen, and faithful.

Revelation 17:15 And he saith unto me, The waters which thou sawest, where the whore sitteth, are peoples, and multitudes, and nations, and tongues.

Revelation 17:16 And the ten horns which thou sawest upon the beast, these shall hate the whore, and shall make her desolate and naked, and shall eat her flesh, and burn her with fire.

Revelation 17:17 For God hath put in their hearts to fulfil his will, and to agree, and give their kingdom unto the beast, until the words of God shall be fulfilled.

Revelation 17:18 And the woman which thou sawest is that great city, which reigneth over the kings of the earth.
