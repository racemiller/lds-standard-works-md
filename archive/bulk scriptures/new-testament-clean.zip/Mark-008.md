# Mark 8

Mark 8 (summary): Jesus feeds the four thousand—He counsels, Beware of the leaven of the Pharisees—He heals a blind man in Bethsaida—Peter testifies that Jesus is the Christ.

Mark 8:1 In those days the multitude being very great, and having nothing to eat, Jesus called his disciples unto him, and saith unto them,

Mark 8:2 I have compassion on the multitude, because they have now been with me three days, and have nothing to eat:

Mark 8:3 And if I send them away fasting to their own houses, they will faint by the way: for divers of them came from far.

Mark 8:4 And his disciples answered him, From whence can a man satisfy these men with bread here in the wilderness?

Mark 8:5 And he asked them, How many loaves have ye? And they said, Seven.

Mark 8:6 And he commanded the people to sit down on the ground: and he took the seven loaves, and gave thanks, and brake, and gave to his disciples to set before them; and they did set them before the people.

Mark 8:7 And they had a few small fishes: and he blessed, and commanded to set them also before them.

Mark 8:8 So they did eat, and were filled: and they took up of the broken meat that was left seven baskets.

Mark 8:9 And they that had eaten were about four thousand: and he sent them away.

Mark 8:10 And straightway he entered into a ship with his disciples, and came into the parts of Dalmanutha.

Mark 8:11 And the Pharisees came forth, and began to question with him, seeking of him a sign from heaven, tempting him.

Mark 8:12 And he sighed deeply in his spirit, and saith, Why doth this generation seek after a sign? verily I say unto you, There shall no sign be given unto this generation.

Mark 8:13 And he left them, and entering into the ship again departed to the other side.

Mark 8:14 Now the disciples had forgotten to take bread, neither had they in the ship with them more than one loaf.

Mark 8:15 And he charged them, saying, Take heed, beware of the leaven of the Pharisees, and of the leaven of Herod.

Mark 8:16 And they reasoned among themselves, saying, It is because we have no bread.

Mark 8:17 And when Jesus knew it, he saith unto them, Why reason ye, because ye have no bread? perceive ye not yet, neither understand? have ye your heart yet hardened?

Mark 8:18 Having eyes, see ye not? and having ears, hear ye not? and do ye not remember?

Mark 8:19 When I brake the five loaves among five thousand, how many baskets full of fragments took ye up? They say unto him, Twelve.

Mark 8:20 And when the seven among four thousand, how many baskets full of fragments took ye up? And they said, Seven.

Mark 8:21 And he said unto them, How is it that ye do not understand?

Mark 8:22 And he cometh to Bethsaida; and they bring a blind man unto him, and besought him to touch him.

Mark 8:23 And he took the blind man by the hand, and led him out of the town; and when he had spit on his eyes, and put his hands upon him, he asked him if he saw ought.

Mark 8:24 And he looked up, and said, I see men as trees, walking.

Mark 8:25 After that he put his hands again upon his eyes, and made him look up: and he was restored, and saw every man clearly.

Mark 8:26 And he sent him away to his house, saying, Neither go into the town, nor tell it to any in the town.

Mark 8:27 And Jesus went out, and his disciples, into the towns of Cæsarea Philippi: and by the way he asked his disciples, saying unto them, Whom do men say that I am?

Mark 8:28 And they answered, John the Baptist: but some say, Elias; and others, One of the prophets.

Mark 8:29 And he saith unto them, But whom say ye that I am? And Peter answereth and saith unto him, Thou art the Christ.

Mark 8:30 And he charged them that they should tell no man of him.

Mark 8:31 And he began to teach them, that the Son of man must suffer many things, and be rejected of the elders, and of the chief priests, and scribes, and be killed, and after three days rise again.

Mark 8:32 And he spake that saying openly. And Peter took him, and began to rebuke him.

Mark 8:33 But when he had turned about and looked on his disciples, he rebuked Peter, saying, Get thee behind me, Satan: for thou savourest not the things that be of God, but the things that be of men.

Mark 8:34 And when he had called the people unto him with his disciples also, he said unto them, Whosoever will come after me, let him deny himself, and take up his cross, and follow me.

Mark 8:35 For whosoever will save his life shall lose it; but whosoever shall lose his life for my sake and the gospel’s, the same shall save it.

Mark 8:36 For what shall it profit a man, if he shall gain the whole world, and lose his own soul?

Mark 8:37 Or what shall a man give in exchange for his soul?

Mark 8:38 Whosoever therefore shall be ashamed of me and of my words in this adulterous and sinful generation; of him also shall the Son of man be ashamed, when he cometh in the glory of his Father with the holy angels.
