# 1 Thessalonians 4

1 Thessalonians 4 (summary): The Saints are told to be holy, sanctify themselves, and love one another—The Lord will come, and the dead will rise.

1 Thessalonians 4:1 Furthermore then we beseech you, brethren, and exhort you by the Lord Jesus, that as ye have received of us how ye ought to walk and to please God, so ye would abound more and more.

1 Thessalonians 4:2 For ye know what commandments we gave you by the Lord Jesus.

1 Thessalonians 4:3 For this is the will of God, even your sanctification, that ye should abstain from fornication:

1 Thessalonians 4:4 That every one of you should know how to possess his vessel in sanctification and honour;

1 Thessalonians 4:5 Not in the lust of concupiscence, even as the Gentiles which know not God:

1 Thessalonians 4:6 That no man go beyond and defraud his brother in any matter: because that the Lord is the avenger of all such, as we also have forewarned you and testified.

1 Thessalonians 4:7 For God hath not called us unto uncleanness, but unto holiness.

1 Thessalonians 4:8 He therefore that despiseth, despiseth not man, but God, who hath also given unto us his holy Spirit.

1 Thessalonians 4:9 But as touching brotherly love ye need not that I write unto you: for ye yourselves are taught of God to love one another.

1 Thessalonians 4:10 And indeed ye do it toward all the brethren which are in all Macedonia: but we beseech you, brethren, that ye increase more and more;

1 Thessalonians 4:11 And that ye study to be quiet, and to do your own business, and to work with your own hands, as we commanded you;

1 Thessalonians 4:12 That ye may walk honestly toward them that are without, and that ye may have lack of nothing.

1 Thessalonians 4:13 But I would not have you to be ignorant, brethren, concerning them which are asleep, that ye sorrow not, even as others which have no hope.

1 Thessalonians 4:14 For if we believe that Jesus died and rose again, even so them also which sleep in Jesus will God bring with him.

1 Thessalonians 4:15 For this we say unto you by the word of the Lord, that we which are alive and remain unto the coming of the Lord shall not prevent them which are asleep.

1 Thessalonians 4:16 For the Lord himself shall descend from heaven with a shout, with the voice of the archangel, and with the trump of God: and the dead in Christ shall rise first:

1 Thessalonians 4:17 Then we which are alive and remain shall be caught up together with them in the clouds, to meet the Lord in the air: and so shall we ever be with the Lord.

1 Thessalonians 4:18 Wherefore comfort one another with these words.
