# James 5

James 5 (summary): Misery awaits the wanton rich—Await the Lord’s coming with patience—The elders are to anoint and heal the sick.

James 5:1 Go to now, ye rich men, weep and howl for your miseries that shall come upon you.

James 5:2 Your riches are corrupted, and your garments are motheaten.

James 5:3 Your gold and silver is cankered; and the rust of them shall be a witness against you, and shall eat your flesh as it were fire. Ye have heaped treasure together for the last days.

James 5:4 Behold, the hire of the labourers who have reaped down your fields, which is of you kept back by fraud, crieth: and the cries of them which have reaped are entered into the ears of the Lord of sabaoth.

James 5:5 Ye have lived in pleasure on the earth, and been wanton; ye have nourished your hearts, as in a day of slaughter.

James 5:6 Ye have condemned and killed the just; and he doth not resist you.

James 5:7 Be patient therefore, brethren, unto the coming of the Lord. Behold, the husbandman waiteth for the precious fruit of the earth, and hath long patience for it, until he receive the early and latter rain.

James 5:8 Be ye also patient; stablish your hearts: for the coming of the Lord draweth nigh.

James 5:9 Grudge not one against another, brethren, lest ye be condemned: behold, the judge standeth before the door.

James 5:10 Take, my brethren, the prophets, who have spoken in the name of the Lord, for an example of suffering affliction, and of patience.

James 5:11 Behold, we count them happy which endure. Ye have heard of the patience of Job, and have seen the end of the Lord; that the Lord is very pitiful, and of tender mercy.

James 5:12 But above all things, my brethren, swear not, neither by heaven, neither by the earth, neither by any other oath: but let your yea be yea; and your nay, nay; lest ye fall into condemnation.

James 5:13 Is any among you afflicted? let him pray. Is any merry? let him sing psalms.

James 5:14 Is any sick among you? let him call for the elders of the church; and let them pray over him, anointing him with oil in the name of the Lord:

James 5:15 And the prayer of faith shall save the sick, and the Lord shall raise him up; and if he have committed sins, they shall be forgiven him.

James 5:16 Confess your faults one to another, and pray one for another, that ye may be healed. The effectual fervent prayer of a righteous man availeth much.

James 5:17 Elias was a man subject to like passions as we are, and he prayed earnestly that it might not rain: and it rained not on the earth by the space of three years and six months.

James 5:18 And he prayed again, and the heaven gave rain, and the earth brought forth her fruit.

James 5:19 Brethren, if any of you do err from the truth, and one convert him;

James 5:20 Let him know, that he which converteth the sinner from the error of his way shall save a soul from death, and shall hide a multitude of sins.
