# Acts 7

Acts 7 (summary): Stephen recounts the history of Israel and names Moses as a prototype of Christ—He testifies of the apostasy in Israel—He sees Jesus on the right hand of God—Stephen’s testimony is rejected, and he is stoned to death.

Acts 7:1 Then said the high priest, Are these things so?

Acts 7:2 And he said, Men, brethren, and fathers, hearken; The God of glory appeared unto our father Abraham, when he was in Mesopotamia, before he dwelt in Charran,

Acts 7:3 And said unto him, Get thee out of thy country, and from thy kindred, and come into the land which I shall shew thee.

Acts 7:4 Then came he out of the land of the Chaldæans, and dwelt in Charran: and from thence, when his father was dead, he removed him into this land, wherein ye now dwell.

Acts 7:5 And he gave him none inheritance in it, no, not so much as to set his foot on: yet he promised that he would give it to him for a possession, and to his seed after him, when as yet he had no child.

Acts 7:6 And God spake on this wise, That his seed should sojourn in a strange land; and that they should bring them into bondage, and entreat them evil four hundred years.

Acts 7:7 And the nation to whom they shall be in bondage will I judge, said God: and after that shall they come forth, and serve me in this place.

Acts 7:8 And he gave him the covenant of circumcision: and so Abraham begat Isaac, and circumcised him the eighth day; and Isaac begat Jacob; and Jacob begat the twelve patriarchs.

Acts 7:9 And the patriarchs, moved with envy, sold Joseph into Egypt: but God was with him,

Acts 7:10 And delivered him out of all his afflictions, and gave him favour and wisdom in the sight of Pharaoh king of Egypt; and he made him governor over Egypt and all his house.

Acts 7:11 Now there came a dearth over all the land of Egypt and Chanaan, and great affliction: and our fathers found no sustenance.

Acts 7:12 But when Jacob heard that there was corn in Egypt, he sent out our fathers first.

Acts 7:13 And at the second time Joseph was made known to his brethren; and Joseph’s kindred was made known unto Pharaoh.

Acts 7:14 Then sent Joseph, and called his father Jacob to him, and all his kindred, threescore and fifteen souls.

Acts 7:15 So Jacob went down into Egypt, and died, he, and our fathers,

Acts 7:16 And were carried over into Sychem, and laid in the sepulchre that Abraham bought for a sum of money of the sons of Emmor the father of Sychem.

Acts 7:17 But when the time of the promise drew nigh, which God had sworn to Abraham, the people grew and multiplied in Egypt,

Acts 7:18 Till another king arose, which knew not Joseph.

Acts 7:19 The same dealt subtilly with our kindred, and evil entreated our fathers, so that they cast out their young children, to the end they might not live.

Acts 7:20 In which time Moses was born, and was exceeding fair, and nourished up in his father’s house three months:

Acts 7:21 And when he was cast out, Pharaoh’s daughter took him up, and nourished him for her own son.

Acts 7:22 And Moses was learned in all the wisdom of the Egyptians, and was mighty in words and in deeds.

Acts 7:23 And when he was full forty years old, it came into his heart to visit his brethren the children of Israel.

Acts 7:24 And seeing one of them suffer wrong, he defended him, and avenged him that was oppressed, and smote the Egyptian:

Acts 7:25 For he supposed his brethren would have understood how that God by his hand would deliver them: but they understood not.

Acts 7:26 And the next day he shewed himself unto them as they strove, and would have set them at one again, saying, Sirs, ye are brethren; why do ye wrong one to another?

Acts 7:27 But he that did his neighbour wrong thrust him away, saying, Who made thee a ruler and a judge over us?

Acts 7:28 Wilt thou kill me, as thou diddest the Egyptian yesterday?

Acts 7:29 Then fled Moses at this saying, and was a stranger in the land of Madian, where he begat two sons.

Acts 7:30 And when forty years were expired, there appeared to him in the wilderness of mount Sina an angel of the Lord in a flame of fire in a bush.

Acts 7:31 When Moses saw it, he wondered at the sight: and as he drew near to behold it, the voice of the Lord came unto him,

Acts 7:32 Saying, I am the God of thy fathers, the God of Abraham, and the God of Isaac, and the God of Jacob. Then Moses trembled, and durst not behold.

Acts 7:33 Then said the Lord to him, Put off thy shoes from thy feet: for the place where thou standest is holy ground.

Acts 7:34 I have seen, I have seen the affliction of my people which is in Egypt, and I have heard their groaning, and am come down to deliver them. And now come, I will send thee into Egypt.

Acts 7:35 This Moses whom they refused, saying, Who made thee a ruler and a judge? the same did God send to be a ruler and a deliverer by the hand of the angel which appeared to him in the bush.

Acts 7:36 He brought them out, after that he had shewed wonders and signs in the land of Egypt, and in the Red sea, and in the wilderness forty years.

Acts 7:37 This is that Moses, which said unto the children of Israel, A prophet shall the Lord your God raise up unto you of your brethren, like unto me; him shall ye hear.

Acts 7:38 This is he, that was in the church in the wilderness with the angel which spake to him in the mount Sina, and with our fathers: who received the lively oracles to give unto us:

Acts 7:39 To whom our fathers would not obey, but thrust him from them, and in their hearts turned back again into Egypt,

Acts 7:40 Saying unto Aaron, Make us gods to go before us: for as for this Moses, which brought us out of the land of Egypt, we wot not what is become of him.

Acts 7:41 And they made a calf in those days, and offered sacrifice unto the idol, and rejoiced in the works of their own hands.

Acts 7:42 Then God turned, and gave them up to worship the host of heaven; as it is written in the book of the prophets, O ye house of Israel, have ye offered to me slain beasts and sacrifices by the space of forty years in the wilderness?

Acts 7:43 Yea, ye took up the tabernacle of Moloch, and the star of your god Remphan, figures which ye made to worship them: and I will carry you away beyond Babylon.

Acts 7:44 Our fathers had the tabernacle of witness in the wilderness, as he had appointed, speaking unto Moses, that he should make it according to the fashion that he had seen.

Acts 7:45 Which also our fathers that came after brought in with Jesus into the possession of the Gentiles, whom God drave out before the face of our fathers, unto the days of David;

Acts 7:46 Who found favour before God, and desired to find a tabernacle for the God of Jacob.

Acts 7:47 But Solomon built him an house.

Acts 7:48 Howbeit the most High dwelleth not in temples made with hands; as saith the prophet,

Acts 7:49 Heaven is my throne, and earth is my footstool: what house will ye build me? saith the Lord: or what is the place of my rest?

Acts 7:50 Hath not my hand made all these things?

Acts 7:51 Ye stiffnecked and uncircumcised in heart and ears, ye do always resist the Holy Ghost: as your fathers did, so do ye.

Acts 7:52 Which of the prophets have not your fathers persecuted? and they have slain them which shewed before of the coming of the Just One; of whom ye have been now the betrayers and murderers:

Acts 7:53 Who have received the law by the disposition of angels, and have not kept it.

Acts 7:54 When they heard these things, they were cut to the heart, and they gnashed on him with their teeth.

Acts 7:55 But he, being full of the Holy Ghost, looked up steadfastly into heaven, and saw the glory of God, and Jesus standing on the right hand of God,

Acts 7:56 And said, Behold, I see the heavens opened, and the Son of man standing on the right hand of God.

Acts 7:57 Then they cried out with a loud voice, and stopped their ears, and ran upon him with one accord,

Acts 7:58 And cast him out of the city, and stoned him: and the witnesses laid down their clothes at a young man’s feet, whose name was Saul.

Acts 7:59 And they stoned Stephen, calling upon God, and saying, Lord Jesus, receive my spirit.

Acts 7:60 And he kneeled down, and cried with a loud voice, Lord, lay not this sin to their charge. And when he had said this, he fell asleep.
