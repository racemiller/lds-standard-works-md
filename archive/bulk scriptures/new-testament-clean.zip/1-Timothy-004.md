# 1 Timothy 4

1 Timothy 4 (summary): Paul describes the latter-day apostasy—Christ is the Savior of all men, especially of those who believe.

1 Timothy 4:1 Now the Spirit speaketh expressly, that in the latter times some shall depart from the faith, giving heed to seducing spirits, and doctrines of devils;

1 Timothy 4:2 Speaking lies in hypocrisy; having their conscience seared with a hot iron;

1 Timothy 4:3 Forbidding to marry, and commanding to abstain from meats, which God hath created to be received with thanksgiving of them which believe and know the truth.

1 Timothy 4:4 For every creature of God is good, and nothing to be refused, if it be received with thanksgiving:

1 Timothy 4:5 For it is sanctified by the word of God and prayer.

1 Timothy 4:6 If thou put the brethren in remembrance of these things, thou shalt be a good minister of Jesus Christ, nourished up in the words of faith and of good doctrine, whereunto thou hast attained.

1 Timothy 4:7 But refuse profane and old wives’ fables, and exercise thyself rather unto godliness.

1 Timothy 4:8 For bodily exercise profiteth little: but godliness is profitable unto all things, having promise of the life that now is, and of that which is to come.

1 Timothy 4:9 This is a faithful saying and worthy of all acceptation.

1 Timothy 4:10 For therefore we both labour and suffer reproach, because we trust in the living God, who is the Saviour of all men, specially of those that believe.

1 Timothy 4:11 These things command and teach.

1 Timothy 4:12 Let no man despise thy youth; but be thou an example of the believers, in word, in conversation, in charity, in spirit, in faith, in purity.

1 Timothy 4:13 Till I come, give attendance to reading, to exhortation, to doctrine.

1 Timothy 4:14 Neglect not the gift that is in thee, which was given thee by prophecy, with the laying on of the hands of the presbytery.

1 Timothy 4:15 Meditate upon these things; give thyself wholly to them; that thy profiting may appear to all.

1 Timothy 4:16 Take heed unto thyself, and unto the doctrine; continue in them: for in doing this thou shalt both save thyself, and them that hear thee.
