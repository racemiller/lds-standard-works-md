# 1 Peter 4

1 Peter 4 (summary): Peter explains why the gospel is preached to the dead—Saints should speak as the oracles of God—The righteous will be tried and tested in all things.

1 Peter 4:1 Forasmuch then as Christ hath suffered for us in the flesh, arm yourselves likewise with the same mind: for he that hath suffered in the flesh hath ceased from sin;

1 Peter 4:2 That he no longer should live the rest of his time in the flesh to the lusts of men, but to the will of God.

1 Peter 4:3 For the time past of our life may suffice us to have wrought the will of the Gentiles, when we walked in lasciviousness, lusts, excess of wine, revellings, banquetings, and abominable idolatries:

1 Peter 4:4 Wherein they think it strange that ye run not with them to the same excess of riot, speaking evil of you:

1 Peter 4:5 Who shall give account to him that is ready to judge the quick and the dead.

1 Peter 4:6 For for this cause was the gospel preached also to them that are dead, that they might be judged according to men in the flesh, but live according to God in the spirit.

1 Peter 4:7 But the end of all things is at hand: be ye therefore sober, and watch unto prayer.

1 Peter 4:8 And above all things have fervent charity among yourselves: for charity shall cover the multitude of sins.

1 Peter 4:9 Use hospitality one to another without grudging.

1 Peter 4:10 As every man hath received the gift, even so minister the same one to another, as good stewards of the manifold grace of God.

1 Peter 4:11 If any man speak, let him speak as the oracles of God; if any man minister, let him do it as of the ability which God giveth: that God in all things may be glorified through Jesus Christ, to whom be praise and dominion for ever and ever. Amen.

1 Peter 4:12 Beloved, think it not strange concerning the fiery trial which is to try you, as though some strange thing happened unto you:

1 Peter 4:13 But rejoice, inasmuch as ye are partakers of Christ’s sufferings; that, when his glory shall be revealed, ye may be glad also with exceeding joy.

1 Peter 4:14 If ye be reproached for the name of Christ, happy are ye; for the spirit of glory and of God resteth upon you: on their part he is evil spoken of, but on your part he is glorified.

1 Peter 4:15 But let none of you suffer as a murderer, or as a thief, or as an evildoer, or as a busybody in other men’s matters.

1 Peter 4:16 Yet if any man suffer as a Christian, let him not be ashamed; but let him glorify God on this behalf.

1 Peter 4:17 For the time is come that judgment must begin at the house of God: and if it first begin at us, what shall the end be of them that obey not the gospel of God?

1 Peter 4:18 And if the righteous scarcely be saved, where shall the ungodly and the sinner appear?

1 Peter 4:19 Wherefore let them that suffer according to the will of God commit the keeping of their souls to him in well doing, as unto a faithful Creator.
