# Revelation 15

Revelation 15 (summary): Exalted Saints praise God in celestial glory forever.

Revelation 15:1 And I saw another sign in heaven, great and marvellous, seven angels having the seven last plagues; for in them is filled up the wrath of God.

Revelation 15:2 And I saw as it were a sea of glass mingled with fire: and them that had gotten the victory over the beast, and over his image, and over his mark, and over the number of his name, stand on the sea of glass, having the harps of God.

Revelation 15:3 And they sing the song of Moses the servant of God, and the song of the Lamb, saying, Great and marvellous are thy works, Lord God Almighty; just and true are thy ways, thou King of saints.

Revelation 15:4 Who shall not fear thee, O Lord, and glorify thy name? for thou only art holy: for all nations shall come and worship before thee; for thy judgments are made manifest.

Revelation 15:5 And after that I looked, and, behold, the temple of the tabernacle of the testimony in heaven was opened:

Revelation 15:6 And the seven angels came out of the temple, having the seven plagues, clothed in pure and white linen, and having their breasts girded with golden girdles.

Revelation 15:7 And one of the four beasts gave unto the seven angels seven golden vials full of the wrath of God, who liveth for ever and ever.

Revelation 15:8 And the temple was filled with smoke from the glory of God, and from his power; and no man was able to enter into the temple, till the seven plagues of the seven angels were fulfilled.
