# Luke 12

Luke 12 (summary): Jesus teaches, Beware of hypocrisy; lay up treasures in heaven rather than on earth; prepare for the coming of the Lord; where much is given, much is required; preaching the gospel causes division.

Luke 12:1 In the mean time, when there were gathered together an innumerable multitude of people, insomuch that they trode one upon another, he began to say unto his disciples first of all, Beware ye of the leaven of the Pharisees, which is hypocrisy.

Luke 12:2 For there is nothing covered, that shall not be revealed; neither hid, that shall not be known.

Luke 12:3 Therefore whatsoever ye have spoken in darkness shall be heard in the light; and that which ye have spoken in the ear in closets shall be proclaimed upon the housetops.

Luke 12:4 And I say unto you my friends, Be not afraid of them that kill the body, and after that have no more that they can do.

Luke 12:5 But I will forewarn you whom ye shall fear: Fear him, which after he hath killed hath power to cast into hell; yea, I say unto you, Fear him.

Luke 12:6 Are not five sparrows sold for two farthings, and not one of them is forgotten before God?

Luke 12:7 But even the very hairs of your head are all numbered. Fear not therefore: ye are of more value than many sparrows.

Luke 12:8 Also I say unto you, Whosoever shall confess me before men, him shall the Son of man also confess before the angels of God:

Luke 12:9 But he that denieth me before men shall be denied before the angels of God.

Luke 12:10 And whosoever shall speak a word against the Son of man, it shall be forgiven him: but unto him that blasphemeth against the Holy Ghost it shall not be forgiven.

Luke 12:11 And when they bring you unto the synagogues, and unto magistrates, and powers, take ye no thought how or what thing ye shall answer, or what ye shall say:

Luke 12:12 For the Holy Ghost shall teach you in the same hour what ye ought to say.

Luke 12:13 And one of the company said unto him, Master, speak to my brother, that he divide the inheritance with me.

Luke 12:14 And he said unto him, Man, who made me a judge or a divider over you?

Luke 12:15 And he said unto them, Take heed, and beware of covetousness: for a man’s life consisteth not in the abundance of the things which he possesseth.

Luke 12:16 And he spake a parable unto them, saying, The ground of a certain rich man brought forth plentifully:

Luke 12:17 And he thought within himself, saying, What shall I do, because I have no room where to bestow my fruits?

Luke 12:18 And he said, This will I do: I will pull down my barns, and build greater; and there will I bestow all my fruits and my goods.

Luke 12:19 And I will say to my soul, Soul, thou hast much goods laid up for many years; take thine ease, eat, drink, and be merry.

Luke 12:20 But God said unto him, Thou fool, this night thy soul shall be required of thee: then whose shall those things be, which thou hast provided?

Luke 12:21 So is he that layeth up treasure for himself, and is not rich toward God.

Luke 12:22 And he said unto his disciples, Therefore I say unto you, Take no thought for your life, what ye shall eat; neither for the body, what ye shall put on.

Luke 12:23 The life is more than meat, and the body is more than raiment.

Luke 12:24 Consider the ravens: for they neither sow nor reap; which neither have storehouse nor barn; and God feedeth them: how much more are ye better than the fowls?

Luke 12:25 And which of you with taking thought can add to his stature one cubit?

Luke 12:26 If ye then be not able to do that thing which is least, why take ye thought for the rest?

Luke 12:27 Consider the lilies how they grow: they toil not, they spin not; and yet I say unto you, that Solomon in all his glory was not arrayed like one of these.

Luke 12:28 If then God so clothe the grass, which is to day in the field, and to morrow is cast into the oven; how much more will he clothe you, O ye of little faith?

Luke 12:29 And seek not ye what ye shall eat, or what ye shall drink, neither be ye of doubtful mind.

Luke 12:30 For all these things do the nations of the world seek after: and your Father knoweth that ye have need of these things.

Luke 12:31 But rather seek ye the kingdom of God; and all these things shall be added unto you.

Luke 12:32 Fear not, little flock; for it is your Father’s good pleasure to give you the kingdom.

Luke 12:33 Sell that ye have, and give alms; provide yourselves bags which wax not old, a treasure in the heavens that faileth not, where no thief approacheth, neither moth corrupteth.

Luke 12:34 For where your treasure is, there will your heart be also.

Luke 12:35 Let your loins be girded about, and your lights burning;

Luke 12:36 And ye yourselves like unto men that wait for their lord, when he will return from the wedding; that when he cometh and knocketh, they may open unto him immediately.

Luke 12:37 Blessed are those servants, whom the lord when he cometh shall find watching: verily I say unto you, that he shall gird himself, and make them to sit down to meat, and will come forth and serve them.

Luke 12:38 And if he shall come in the second watch, or come in the third watch, and find them so, blessed are those servants.

Luke 12:39 And this know, that if the goodman of the house had known what hour the thief would come, he would have watched, and not have suffered his house to be broken through.

Luke 12:40 Be ye therefore ready also: for the Son of man cometh at an hour when ye think not.

Luke 12:41 Then Peter said unto him, Lord, speakest thou this parable unto us, or even to all?

Luke 12:42 And the Lord said, Who then is that faithful and wise steward, whom his lord shall make ruler over his household, to give them their portion of meat in due season?

Luke 12:43 Blessed is that servant, whom his lord when he cometh shall find so doing.

Luke 12:44 Of a truth I say unto you, that he will make him ruler over all that he hath.

Luke 12:45 But and if that servant say in his heart, My lord delayeth his coming; and shall begin to beat the menservants and maidens, and to eat and drink, and to be drunken;

Luke 12:46 The lord of that servant will come in a day when he looketh not for him, and at an hour when he is not aware, and will cut him in sunder, and will appoint him his portion with the unbelievers.

Luke 12:47 And that servant, which knew his lord’s will, and prepared not himself, neither did according to his will, shall be beaten with many stripes.

Luke 12:48 But he that knew not, and did commit things worthy of stripes, shall be beaten with few stripes. For unto whomsoever much is given, of him shall be much required: and to whom men have committed much, of him they will ask the more.

Luke 12:49 I am come to send fire on the earth; and what will I, if it be already kindled?

Luke 12:50 But I have a baptism to be baptized with; and how am I straitened till it be accomplished!

Luke 12:51 Suppose ye that I am come to give peace on earth? I tell you, Nay; but rather division:

Luke 12:52 For from henceforth there shall be five in one house divided, three against two, and two against three.

Luke 12:53 The father shall be divided against the son, and the son against the father; the mother against the daughter, and the daughter against the mother; the mother in law against her daughter in law, and the daughter in law against her mother in law.

Luke 12:54 And he said also to the people, When ye see a cloud rise out of the west, straightway ye say, There cometh a shower; and so it is.

Luke 12:55 And when ye see the south wind blow, ye say, There will be heat; and it cometh to pass.

Luke 12:56 Ye hypocrites, ye can discern the face of the sky and of the earth; but how is it that ye do not discern this time?

Luke 12:57 Yea, and why even of yourselves judge ye not what is right?

Luke 12:58 When thou goest with thine adversary to the magistrate, as thou art in the way, give diligence that thou mayest be delivered from him; lest he hale thee to the judge, and the judge deliver thee to the officer, and the officer cast thee into prison.

Luke 12:59 I tell thee, thou shalt not depart thence, till thou hast paid the very last mite.
