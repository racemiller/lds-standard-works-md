# Acts 24

Acts 24 (summary): Paul is accused of sedition—He answers in defense of his life and doctrine—He teaches Felix of righteousness, temperance, and the judgment to come.

Acts 24:1 And after five days Ananias the high priest descended with the elders, and with a certain orator named Tertullus, who informed the governor against Paul.

Acts 24:2 And when he was called forth, Tertullus began to accuse him, saying, Seeing that by thee we enjoy great quietness, and that very worthy deeds are done unto this nation by thy providence,

Acts 24:3 We accept it always, and in all places, most noble Felix, with all thankfulness.

Acts 24:4 Notwithstanding, that I be not further tedious unto thee, I pray thee that thou wouldest hear us of thy clemency a few words.

Acts 24:5 For we have found this man a pestilent fellow, and a mover of sedition among all the Jews throughout the world, and a ringleader of the sect of the Nazarenes:

Acts 24:6 Who also hath gone about to profane the temple: whom we took, and would have judged according to our law.

Acts 24:7 But the chief captain Lysias came upon us, and with great violence took him away out of our hands,

Acts 24:8 Commanding his accusers to come unto thee: by examining of whom thyself mayest take knowledge of all these things, whereof we accuse him.

Acts 24:9 And the Jews also assented, saying that these things were so.

Acts 24:10 Then Paul, after that the governor had beckoned unto him to speak, answered, Forasmuch as I know that thou hast been of many years a judge unto this nation, I do the more cheerfully answer for myself:

Acts 24:11 Because that thou mayest understand, that there are yet but twelve days since I went up to Jerusalem for to worship.

Acts 24:12 And they neither found me in the temple disputing with any man, neither raising up the people, neither in the synagogues, nor in the city:

Acts 24:13 Neither can they prove the things whereof they now accuse me.

Acts 24:14 But this I confess unto thee, that after the way which they call heresy, so worship I the God of my fathers, believing all things which are written in the law and in the prophets:

Acts 24:15 And have hope toward God, which they themselves also allow, that there shall be a resurrection of the dead, both of the just and unjust.

Acts 24:16 And herein do I exercise myself, to have always a conscience void of offence toward God, and toward men.

Acts 24:17 Now after many years I came to bring alms to my nation, and offerings.

Acts 24:18 Whereupon certain Jews from Asia found me purified in the temple, neither with multitude, nor with tumult.

Acts 24:19 Who ought to have been here before thee, and object, if they had ought against me.

Acts 24:20 Or else let these same here say, if they have found any evil doing in me, while I stood before the council,

Acts 24:21 Except it be for this one voice, that I cried standing among them, Touching the resurrection of the dead I am called in question by you this day.

Acts 24:22 And when Felix heard these things, having more perfect knowledge of that way, he deferred them, and said, When Lysias the chief captain shall come down, I will know the uttermost of your matter.

Acts 24:23 And he commanded a centurion to keep Paul, and to let him have liberty, and that he should forbid none of his acquaintance to minister or come unto him.

Acts 24:24 And after certain days, when Felix came with his wife Drusilla, which was a Jewess, he sent for Paul, and heard him concerning the faith in Christ.

Acts 24:25 And as he reasoned of righteousness, temperance, and judgment to come, Felix trembled, and answered, Go thy way for this time; when I have a convenient season, I will call for thee.

Acts 24:26 He hoped also that money should have been given him of Paul, that he might loose him: wherefore he sent for him the oftener, and communed with him.

Acts 24:27 But after two years Porcius Festus came into Felix’ room: and Felix, willing to shew the Jews a pleasure, left Paul bound.
