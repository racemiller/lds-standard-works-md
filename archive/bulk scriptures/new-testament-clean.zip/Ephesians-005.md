# Ephesians 5

Ephesians 5 (summary): The Saints are exhorted to avoid uncleanness and walk uprightly—Husbands and wives should love each other.

Ephesians 5:1 Be ye therefore followers of God, as dear children;

Ephesians 5:2 And walk in love, as Christ also hath loved us, and hath given himself for us an offering and a sacrifice to God for a sweetsmelling savour.

Ephesians 5:3 But fornication, and all uncleanness, or covetousness, let it not be once named among you, as becometh saints;

Ephesians 5:4 Neither filthiness, nor foolish talking, nor jesting, which are not convenient: but rather giving of thanks.

Ephesians 5:5 For this ye know, that no whoremonger, nor unclean person, nor covetous man, who is an idolater, hath any inheritance in the kingdom of Christ and of God.

Ephesians 5:6 Let no man deceive you with vain words: for because of these things cometh the wrath of God upon the children of disobedience.

Ephesians 5:7 Be not ye therefore partakers with them.

Ephesians 5:8 For ye were sometimes darkness, but now are ye light in the Lord: walk as children of light:

Ephesians 5:9 (For the fruit of the Spirit is in all goodness and righteousness and truth;)

Ephesians 5:10 Proving what is acceptable unto the Lord.

Ephesians 5:11 And have no fellowship with the unfruitful works of darkness, but rather reprove them.

Ephesians 5:12 For it is a shame even to speak of those things which are done of them in secret.

Ephesians 5:13 But all things that are reproved are made manifest by the light: for whatsoever doth make manifest is light.

Ephesians 5:14 Wherefore he saith, Awake thou that sleepest, and arise from the dead, and Christ shall give thee light.

Ephesians 5:15 See then that ye walk circumspectly, not as fools, but as wise,

Ephesians 5:16 Redeeming the time, because the days are evil.

Ephesians 5:17 Wherefore be ye not unwise, but understanding what the will of the Lord is.

Ephesians 5:18 And be not drunk with wine, wherein is excess; but be filled with the Spirit;

Ephesians 5:19 Speaking to yourselves in psalms and hymns and spiritual songs, singing and making melody in your heart to the Lord;

Ephesians 5:20 Giving thanks always for all things unto God and the Father in the name of our Lord Jesus Christ;

Ephesians 5:21 Submitting yourselves one to another in the fear of God.

Ephesians 5:22 Wives, submit yourselves unto your own husbands, as unto the Lord.

Ephesians 5:23 For the husband is the head of the wife, even as Christ is the head of the church: and he is the saviour of the body.

Ephesians 5:24 Therefore as the church is subject unto Christ, so let the wives be to their own husbands in every thing.

Ephesians 5:25 Husbands, love your wives, even as Christ also loved the church, and gave himself for it;

Ephesians 5:26 That he might sanctify and cleanse it with the washing of water by the word,

Ephesians 5:27 That he might present it to himself a glorious church, not having spot, or wrinkle, or any such thing; but that it should be holy and without blemish.

Ephesians 5:28 So ought men to love their wives as their own bodies. He that loveth his wife loveth himself.

Ephesians 5:29 For no man ever yet hated his own flesh; but nourisheth and cherisheth it, even as the Lord the church:

Ephesians 5:30 For we are members of his body, of his flesh, and of his bones.

Ephesians 5:31 For this cause shall a man leave his father and mother, and shall be joined unto his wife, and they two shall be one flesh.

Ephesians 5:32 This is a great mystery: but I speak concerning Christ and the church.

Ephesians 5:33 Nevertheless let every one of you in particular so love his wife even as himself; and the wife see that she reverence her husband.
