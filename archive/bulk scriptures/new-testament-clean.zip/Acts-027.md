# Acts 27

Acts 27 (summary): Paul, in a perilous voyage, travels toward Rome—An angel comforts him—He uses the gift of seership—He is shipwrecked.

Acts 27:1 And when it was determined that we should sail into Italy, they delivered Paul and certain other prisoners unto one named Julius, a centurion of Augustus’ band.

Acts 27:2 And entering into a ship of Adramyttium, we launched, meaning to sail by the coasts of Asia; one Aristarchus, a Macedonian of Thessalonica, being with us.

Acts 27:3 And the next day we touched at Sidon. And Julius courteously entreated Paul, and gave him liberty to go unto his friends to refresh himself.

Acts 27:4 And when we had launched from thence, we sailed under Cyprus, because the winds were contrary.

Acts 27:5 And when we had sailed over the sea of Cilicia and Pamphylia, we came to Myra, a city of Lycia.

Acts 27:6 And there the centurion found a ship of Alexandria sailing into Italy; and he put us therein.

Acts 27:7 And when we had sailed slowly many days, and scarce were come over against Cnidus, the wind not suffering us, we sailed under Crete, over against Salmone;

Acts 27:8 And, hardly passing it, came unto a place which is called The fair havens; nigh whereunto was the city of Lasea.

Acts 27:9 Now when much time was spent, and when sailing was now dangerous, because the fast was now already past, Paul admonished them,

Acts 27:10 And said unto them, Sirs, I perceive that this voyage will be with hurt and much damage, not only of the lading and ship, but also of our lives.

Acts 27:11 Nevertheless the centurion believed the master and the owner of the ship, more than those things which were spoken by Paul.

Acts 27:12 And because the haven was not commodious to winter in, the more part advised to depart thence also, if by any means they might attain to Phenice, and there to winter; which is an haven of Crete, and lieth toward the south west and north west.

Acts 27:13 And when the south wind blew softly, supposing that they had obtained their purpose, loosing thence, they sailed close by Crete.

Acts 27:14 But not long after there arose against it a tempestuous wind, called Euroclydon.

Acts 27:15 And when the ship was caught, and could not bear up into the wind, we let her drive.

Acts 27:16 And running under a certain island which is called Clauda, we had much work to come by the boat:

Acts 27:17 Which when they had taken up, they used helps, undergirding the ship; and, fearing lest they should fall into the quicksands, strake sail, and so were driven.

Acts 27:18 And we being exceedingly tossed with a tempest, the next day they lightened the ship;

Acts 27:19 And the third day we cast out with our own hands the tackling of the ship.

Acts 27:20 And when neither sun nor stars in many days appeared, and no small tempest lay on us, all hope that we should be saved was then taken away.

Acts 27:21 But after long abstinence Paul stood forth in the midst of them, and said, Sirs, ye should have hearkened unto me, and not have loosed from Crete, and to have gained this harm and loss.

Acts 27:22 And now I exhort you to be of good cheer: for there shall be no loss of any man’s life among you, but of the ship.

Acts 27:23 For there stood by me this night the angel of God, whose I am, and whom I serve,

Acts 27:24 Saying, Fear not, Paul; thou must be brought before Cæsar: and, lo, God hath given thee all them that sail with thee.

Acts 27:25 Wherefore, sirs, be of good cheer: for I believe God, that it shall be even as it was told me.

Acts 27:26 Howbeit we must be cast upon a certain island.

Acts 27:27 But when the fourteenth night was come, as we were driven up and down in Adria, about midnight the shipmen deemed that they drew near to some country;

Acts 27:28 And sounded, and found it twenty fathoms: and when they had gone a little further, they sounded again, and found it fifteen fathoms.

Acts 27:29 Then fearing lest we should have fallen upon rocks, they cast four anchors out of the stern, and wished for the day.

Acts 27:30 And as the shipmen were about to flee out of the ship, when they had let down the boat into the sea, under colour as though they would have cast anchors out of the foreship,

Acts 27:31 Paul said to the centurion and to the soldiers, Except these abide in the ship, ye cannot be saved.

Acts 27:32 Then the soldiers cut off the ropes of the boat, and let her fall off.

Acts 27:33 And while the day was coming on, Paul besought them all to take meat, saying, This day is the fourteenth day that ye have tarried and continued fasting, having taken nothing.

Acts 27:34 Wherefore I pray you to take some meat: for this is for your health: for there shall not an hair fall from the head of any of you.

Acts 27:35 And when he had thus spoken, he took bread, and gave thanks to God in presence of them all: and when he had broken it, he began to eat.

Acts 27:36 Then were they all of good cheer, and they also took some meat.

Acts 27:37 And we were in all in the ship two hundred threescore and sixteen souls.

Acts 27:38 And when they had eaten enough, they lightened the ship, and cast out the wheat into the sea.

Acts 27:39 And when it was day, they knew not the land: but they discovered a certain creek with a shore, into the which they were minded, if it were possible, to thrust in the ship.

Acts 27:40 And when they had taken up the anchors, they committed themselves unto the sea, and loosed the rudder bands, and hoised up the mainsail to the wind, and made toward shore.

Acts 27:41 And falling into a place where two seas met, they ran the ship aground; and the forepart stuck fast, and remained unmoveable, but the hinder part was broken with the violence of the waves.

Acts 27:42 And the soldiers’ counsel was to kill the prisoners, lest any of them should swim out, and escape.

Acts 27:43 But the centurion, willing to save Paul, kept them from their purpose; and commanded that they which could swim should cast themselves first into the sea, and get to land:

Acts 27:44 And the rest, some on boards, and some on broken pieces of the ship. And so it came to pass, that they escaped all safe to land.
