# 1 Peter 2

1 Peter 2 (summary): Converts are newborn babes in Christ—He is the chief cornerstone—Saints hold a royal priesthood and are a peculiar people—Saints are in subjection to the laws of man.

1 Peter 2:1 Wherefore laying aside all malice, and all guile, and hypocrisies, and envies, and all evil speakings,

1 Peter 2:2 As newborn babes, desire the sincere milk of the word, that ye may grow thereby:

1 Peter 2:3 If so be ye have tasted that the Lord is gracious.

1 Peter 2:4 To whom coming, as unto a living stone, disallowed indeed of men, but chosen of God, and precious,

1 Peter 2:5 Ye also, as lively stones, are built up a spiritual house, an holy priesthood, to offer up spiritual sacrifices, acceptable to God by Jesus Christ.

1 Peter 2:6 Wherefore also it is contained in the scripture, Behold, I lay in Sion a chief corner stone, elect, precious: and he that believeth on him shall not be confounded.

1 Peter 2:7 Unto you therefore which believe he is precious: but unto them which be disobedient, the stone which the builders disallowed, the same is made the head of the corner,

1 Peter 2:8 And a stone of stumbling, and a rock of offence, even to them which stumble at the word, being disobedient: whereunto also they were appointed.

1 Peter 2:9 But ye are a chosen generation, a royal priesthood, an holy nation, a peculiar people; that ye should shew forth the praises of him who hath called you out of darkness into his marvellous light:

1 Peter 2:10 Which in time past were not a people, but are now the people of God: which had not obtained mercy, but now have obtained mercy.

1 Peter 2:11 Dearly beloved, I beseech you as strangers and pilgrims, abstain from fleshly lusts, which war against the soul;

1 Peter 2:12 Having your conversation honest among the Gentiles: that, whereas they speak against you as evildoers, they may by your good works, which they shall behold, glorify God in the day of visitation.

1 Peter 2:13 Submit yourselves to every ordinance of man for the Lord’s sake: whether it be to the king, as supreme;

1 Peter 2:14 Or unto governors, as unto them that are sent by him for the punishment of evildoers, and for the praise of them that do well.

1 Peter 2:15 For so is the will of God, that with well doing ye may put to silence the ignorance of foolish men:

1 Peter 2:16 As free, and not using your liberty for a cloak of maliciousness, but as the servants of God.

1 Peter 2:17 Honour all men. Love the brotherhood. Fear God. Honour the king.

1 Peter 2:18 Servants, be subject to your masters with all fear; not only to the good and gentle, but also to the froward.

1 Peter 2:19 For this is thankworthy, if a man for conscience toward God endure grief, suffering wrongfully.

1 Peter 2:20 For what glory is it, if, when ye be buffeted for your faults, ye shall take it patiently? but if, when ye do well, and suffer for it, ye take it patiently, this is acceptable with God.

1 Peter 2:21 For even hereunto were ye called: because Christ also suffered for us, leaving us an example, that ye should follow his steps:

1 Peter 2:22 Who did no sin, neither was guile found in his mouth:

1 Peter 2:23 Who, when he was reviled, reviled not again; when he suffered, he threatened not; but committed himself to him that judgeth righteously:

1 Peter 2:24 Who his own self bare our sins in his own body on the tree, that we, being dead to sins, should live unto righteousness: by whose stripes ye were healed.

1 Peter 2:25 For ye were as sheep going astray; but are now returned unto the Shepherd and Bishop of your souls.
