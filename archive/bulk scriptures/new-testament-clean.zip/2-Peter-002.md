# 2 Peter 2

2 Peter 2 (summary): False teachers among the Saints are damned—Lustful Saints will perish in their own corruption.

2 Peter 2:1 But there were false prophets also among the people, even as there shall be false teachers among you, who privily shall bring in damnable heresies, even denying the Lord that bought them, and bring upon themselves swift destruction.

2 Peter 2:2 And many shall follow their pernicious ways; by reason of whom the way of truth shall be evil spoken of.

2 Peter 2:3 And through covetousness shall they with feigned words make merchandise of you: whose judgment now of a long time lingereth not, and their damnation slumbereth not.

2 Peter 2:4 For if God spared not the angels that sinned, but cast them down to hell, and delivered them into chains of darkness, to be reserved unto judgment;

2 Peter 2:5 And spared not the old world, but saved Noah the eighth person, a preacher of righteousness, bringing in the flood upon the world of the ungodly;

2 Peter 2:6 And turning the cities of Sodom and Gomorrha into ashes condemned them with an overthrow, making them an ensample unto those that after should live ungodly;

2 Peter 2:7 And delivered just Lot, vexed with the filthy conversation of the wicked:

2 Peter 2:8 (For that righteous man dwelling among them, in seeing and hearing, vexed his righteous soul from day to day with their unlawful deeds;)

2 Peter 2:9 The Lord knoweth how to deliver the godly out of temptations, and to reserve the unjust unto the day of judgment to be punished:

2 Peter 2:10 But chiefly them that walk after the flesh in the lust of uncleanness, and despise government. Presumptuous are they, selfwilled, they are not afraid to speak evil of dignities.

2 Peter 2:11 Whereas angels, which are greater in power and might, bring not railing accusation against them before the Lord.

2 Peter 2:12 But these, as natural brute beasts, made to be taken and destroyed, speak evil of the things that they understand not; and shall utterly perish in their own corruption;

2 Peter 2:13 And shall receive the reward of unrighteousness, as they that count it pleasure to riot in the day time. Spots they are and blemishes, sporting themselves with their own deceivings while they feast with you;

2 Peter 2:14 Having eyes full of adultery, and that cannot cease from sin; beguiling unstable souls: an heart they have exercised with covetous practices; cursed children:

2 Peter 2:15 Which have forsaken the right way, and are gone astray, following the way of Balaam the son of Bosor, who loved the wages of unrighteousness;

2 Peter 2:16 But was rebuked for his iniquity: the dumb ass speaking with man’s voice forbad the madness of the prophet.

2 Peter 2:17 These are wells without water, clouds that are carried with a tempest; to whom the mist of darkness is reserved for ever.

2 Peter 2:18 For when they speak great swelling words of vanity, they allure through the lusts of the flesh, through much wantonness, those that were clean escaped from them who live in error.

2 Peter 2:19 While they promise them liberty, they themselves are the servants of corruption: for of whom a man is overcome, of the same is he brought in bondage.

2 Peter 2:20 For if after they have escaped the pollutions of the world through the knowledge of the Lord and Saviour Jesus Christ, they are again entangled therein, and overcome, the latter end is worse with them than the beginning.

2 Peter 2:21 For it had been better for them not to have known the way of righteousness, than, after they have known it, to turn from the holy commandment delivered unto them.

2 Peter 2:22 But it is happened unto them according to the true proverb, The dog is turned to his own vomit again; and the sow that was washed to her wallowing in the mire.
