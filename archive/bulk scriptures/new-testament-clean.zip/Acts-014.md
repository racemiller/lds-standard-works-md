# Acts 14

Acts 14 (summary): Persecution attends the spread of the gospel—Paul heals a crippled man; Paul and Barnabas are hailed as gods—Paul is stoned and revived; he preaches—Elders are ordained.

Acts 14:1 And it came to pass in Iconium, that they went both together into the synagogue of the Jews, and so spake, that a great multitude both of the Jews and also of the Greeks believed.

Acts 14:2 But the unbelieving Jews stirred up the Gentiles, and made their minds evil affected against the brethren.

Acts 14:3 Long time therefore abode they speaking boldly in the Lord, which gave testimony unto the word of his grace, and granted signs and wonders to be done by their hands.

Acts 14:4 But the multitude of the city was divided: and part held with the Jews, and part with the apostles.

Acts 14:5 And when there was an assault made both of the Gentiles, and also of the Jews with their rulers, to use them despitefully, and to stone them,

Acts 14:6 They were ware of it, and fled unto Lystra and Derbe, cities of Lycaonia, and unto the region that lieth round about:

Acts 14:7 And there they preached the gospel.

Acts 14:8 And there sat a certain man at Lystra, impotent in his feet, being a cripple from his mother’s womb, who never had walked:

Acts 14:9 The same heard Paul speak: who steadfastly beholding him, and perceiving that he had faith to be healed,

Acts 14:10 Said with a loud voice, Stand upright on thy feet. And he leaped and walked.

Acts 14:11 And when the people saw what Paul had done, they lifted up their voices, saying in the speech of Lycaonia, The gods are come down to us in the likeness of men.

Acts 14:12 And they called Barnabas, Jupiter; and Paul, Mercurius, because he was the chief speaker.

Acts 14:13 Then the priest of Jupiter, which was before their city, brought oxen and garlands unto the gates, and would have done sacrifice with the people.

Acts 14:14 Which when the apostles, Barnabas and Paul, heard of, they rent their clothes, and ran in among the people, crying out,

Acts 14:15 And saying, Sirs, why do ye these things? We also are men of like passions with you, and preach unto you that ye should turn from these vanities unto the living God, which made heaven, and earth, and the sea, and all things that are therein:

Acts 14:16 Who in times past suffered all nations to walk in their own ways.

Acts 14:17 Nevertheless he left not himself without witness, in that he did good, and gave us rain from heaven, and fruitful seasons, filling our hearts with food and gladness.

Acts 14:18 And with these sayings scarce restrained they the people, that they had not done sacrifice unto them.

Acts 14:19 And there came thither certain Jews from Antioch and Iconium, who persuaded the people, and, having stoned Paul, drew him out of the city, supposing he had been dead.

Acts 14:20 Howbeit, as the disciples stood round about him, he rose up, and came into the city: and the next day he departed with Barnabas to Derbe.

Acts 14:21 And when they had preached the gospel to that city, and had taught many, they returned again to Lystra, and to Iconium, and Antioch,

Acts 14:22 Confirming the souls of the disciples, and exhorting them to continue in the faith, and that we must through much tribulation enter into the kingdom of God.

Acts 14:23 And when they had ordained them elders in every church, and had prayed with fasting, they commended them to the Lord, on whom they believed.

Acts 14:24 And after they had passed throughout Pisidia, they came to Pamphylia.

Acts 14:25 And when they had preached the word in Perga, they went down into Attalia:

Acts 14:26 And thence sailed to Antioch, from whence they had been recommended to the grace of God for the work which they fulfilled.

Acts 14:27 And when they were come, and had gathered the church together, they rehearsed all that God had done with them, and how he had opened the door of faith unto the Gentiles.

Acts 14:28 And there they abode long time with the disciples.
