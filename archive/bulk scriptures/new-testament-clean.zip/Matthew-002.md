# Matthew 2

Matthew 2 (summary): The wise men are directed by a star to Jesus—Joseph takes the child to Egypt—Herod slays the children in Bethlehem—Jesus is taken to Nazareth to dwell.

Matthew 2:1 Now when Jesus was born in Bethlehem of Judæa in the days of Herod the king, behold, there came wise men from the east to Jerusalem,

Matthew 2:2 Saying, Where is he that is born King of the Jews? for we have seen his star in the east, and are come to worship him.

Matthew 2:3 When Herod the king had heard these things, he was troubled, and all Jerusalem with him.

Matthew 2:4 And when he had gathered all the chief priests and scribes of the people together, he demanded of them where Christ should be born.

Matthew 2:5 And they said unto him, In Bethlehem of Judæa: for thus it is written by the prophet,

Matthew 2:6 And thou Bethlehem, in the land of Juda, art not the least among the princes of Juda: for out of thee shall come a Governor, that shall rule my people Israel.

Matthew 2:7 Then Herod, when he had privily called the wise men, inquired of them diligently what time the star appeared.

Matthew 2:8 And he sent them to Bethlehem, and said, Go and search diligently for the young child; and when ye have found him, bring me word again, that I may come and worship him also.

Matthew 2:9 When they had heard the king, they departed; and, lo, the star, which they saw in the east, went before them, till it came and stood over where the young child was.

Matthew 2:10 When they saw the star, they rejoiced with exceeding great joy.

Matthew 2:11 And when they were come into the house, they saw the young child with Mary his mother, and fell down, and worshipped him: and when they had opened their treasures, they presented unto him gifts; gold, and frankincense, and myrrh.

Matthew 2:12 And being warned of God in a dream that they should not return to Herod, they departed into their own country another way.

Matthew 2:13 And when they were departed, behold, the angel of the Lord appeareth to Joseph in a dream, saying, Arise, and take the young child and his mother, and flee into Egypt, and be thou there until I bring thee word: for Herod will seek the young child to destroy him.

Matthew 2:14 When he arose, he took the young child and his mother by night, and departed into Egypt:

Matthew 2:15 And was there until the death of Herod: that it might be fulfilled which was spoken of the Lord by the prophet, saying, Out of Egypt have I called my son.

Matthew 2:16 Then Herod, when he saw that he was mocked of the wise men, was exceeding wroth, and sent forth, and slew all the children that were in Bethlehem, and in all the coasts thereof, from two years old and under, according to the time which he had diligently inquired of the wise men.

Matthew 2:17 Then was fulfilled that which was spoken by Jeremy the prophet, saying,

Matthew 2:18 In Rama was there a voice heard, lamentation, and weeping, and great mourning, Rachel weeping for her children, and would not be comforted, because they are not.

Matthew 2:19 But when Herod was dead, behold, an angel of the Lord appeareth in a dream to Joseph in Egypt,

Matthew 2:20 Saying, Arise, and take the young child and his mother, and go into the land of Israel: for they are dead which sought the young child’s life.

Matthew 2:21 And he arose, and took the young child and his mother, and came into the land of Israel.

Matthew 2:22 But when he heard that Archelaus did reign in Judæa in the room of his father Herod, he was afraid to go thither: notwithstanding, being warned of God in a dream, he turned aside into the parts of Galilee:

Matthew 2:23 And he came and dwelt in a city called Nazareth: that it might be fulfilled which was spoken by the prophets, He shall be called a Nazarene.
