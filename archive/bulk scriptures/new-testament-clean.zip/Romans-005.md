# Romans 5

Romans 5 (summary): Man is justified through the blood of Christ—Adam fell, and Christ atoned that man might be saved.

Romans 5:1 Therefore being justified by faith, we have peace with God through our Lord Jesus Christ:

Romans 5:2 By whom also we have access by faith into this grace wherein we stand, and rejoice in hope of the glory of God.

Romans 5:3 And not only so, but we glory in tribulations also: knowing that tribulation worketh patience;

Romans 5:4 And patience, experience; and experience, hope:

Romans 5:5 And hope maketh not ashamed; because the love of God is shed abroad in our hearts by the Holy Ghost which is given unto us.

Romans 5:6 For when we were yet without strength, in due time Christ died for the ungodly.

Romans 5:7 For scarcely for a righteous man will one die: yet peradventure for a good man some would even dare to die.

Romans 5:8 But God commendeth his love toward us, in that, while we were yet sinners, Christ died for us.

Romans 5:9 Much more then, being now justified by his blood, we shall be saved from wrath through him.

Romans 5:10 For if, when we were enemies, we were reconciled to God by the death of his Son, much more, being reconciled, we shall be saved by his life.

Romans 5:11 And not only so, but we also joy in God through our Lord Jesus Christ, by whom we have now received the atonement.

Romans 5:12 Wherefore, as by one man sin entered into the world, and death by sin; and so death passed upon all men, for that all have sinned:

Romans 5:13 (For until the law sin was in the world: but sin is not imputed when there is no law.

Romans 5:14 Nevertheless death reigned from Adam to Moses, even over them that had not sinned after the similitude of Adam’s transgression, who is the figure of him that was to come.

Romans 5:15 But not as the offence, so also is the free gift. For if through the offence of one many be dead, much more the grace of God, and the gift by grace, which is by one man, Jesus Christ, hath abounded unto many.

Romans 5:16 And not as it was by one that sinned, so is the gift: for the judgment was by one to condemnation, but the free gift is of many offences unto justification.

Romans 5:17 For if by one man’s offence death reigned by one; much more they which receive abundance of grace and of the gift of righteousness shall reign in life by one, Jesus Christ.)

Romans 5:18 Therefore as by the offence of one judgment came upon all men to condemnation; even so by the righteousness of one the free gift came upon all men unto justification of life.

Romans 5:19 For as by one man’s disobedience many were made sinners, so by the obedience of one shall many be made righteous.

Romans 5:20 Moreover the law entered, that the offence might abound. But where sin abounded, grace did much more abound:

Romans 5:21 That as sin hath reigned unto death, even so might grace reign through righteousness unto eternal life by Jesus Christ our Lord.
