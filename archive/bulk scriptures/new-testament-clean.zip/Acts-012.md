# Acts 12

Acts 12 (summary): The martyrdom of James is described—An angel frees Peter from prison—The Lord slays Herod by disease—The Church grows.

Acts 12:1 Now about that time Herod the king stretched forth his hands to vex certain of the church.

Acts 12:2 And he killed James the brother of John with the sword.

Acts 12:3 And because he saw it pleased the Jews, he proceeded further to take Peter also. (Then were the days of unleavened bread.)

Acts 12:4 And when he had apprehended him, he put him in prison, and delivered him to four quaternions of soldiers to keep him; intending after Easter to bring him forth to the people.

Acts 12:5 Peter therefore was kept in prison: but prayer was made without ceasing of the church unto God for him.

Acts 12:6 And when Herod would have brought him forth, the same night Peter was sleeping between two soldiers, bound with two chains: and the keepers before the door kept the prison.

Acts 12:7 And, behold, the angel of the Lord came upon him, and a light shined in the prison: and he smote Peter on the side, and raised him up, saying, Arise up quickly. And his chains fell off from his hands.

Acts 12:8 And the angel said unto him, Gird thyself, and bind on thy sandals. And so he did. And he saith unto him, Cast thy garment about thee, and follow me.

Acts 12:9 And he went out, and followed him; and wist not that it was true which was done by the angel; but thought he saw a vision.

Acts 12:10 When they were past the first and the second ward, they came unto the iron gate that leadeth unto the city; which opened to them of his own accord: and they went out, and passed on through one street; and forthwith the angel departed from him.

Acts 12:11 And when Peter was come to himself, he said, Now I know of a surety, that the Lord hath sent his angel, and hath delivered me out of the hand of Herod, and from all the expectation of the people of the Jews.

Acts 12:12 And when he had considered the thing, he came to the house of Mary the mother of John, whose surname was Mark; where many were gathered together praying.

Acts 12:13 And as Peter knocked at the door of the gate, a damsel came to hearken, named Rhoda.

Acts 12:14 And when she knew Peter’s voice, she opened not the gate for gladness, but ran in, and told how Peter stood before the gate.

Acts 12:15 And they said unto her, Thou art mad. But she constantly affirmed that it was even so. Then said they, It is his angel.

Acts 12:16 But Peter continued knocking: and when they had opened the door, and saw him, they were astonished.

Acts 12:17 But he, beckoning unto them with the hand to hold their peace, declared unto them how the Lord had brought him out of the prison. And he said, Go shew these things unto James, and to the brethren. And he departed, and went into another place.

Acts 12:18 Now as soon as it was day, there was no small stir among the soldiers, what was become of Peter.

Acts 12:19 And when Herod had sought for him, and found him not, he examined the keepers, and commanded that they should be put to death. And he went down from Judæa to Cæsarea, and there abode.

Acts 12:20 And Herod was highly displeased with them of Tyre and Sidon: but they came with one accord to him, and, having made Blastus the king’s chamberlain their friend, desired peace; because their country was nourished by the king’s country.

Acts 12:21 And upon a set day Herod, arrayed in royal apparel, sat upon his throne, and made an oration unto them.

Acts 12:22 And the people gave a shout, saying, It is the voice of a god, and not of a man.

Acts 12:23 And immediately the angel of the Lord smote him, because he gave not God the glory: and he was eaten of worms, and gave up the ghost.

Acts 12:24 But the word of God grew and multiplied.

Acts 12:25 And Barnabas and Saul returned from Jerusalem, when they had fulfilled their ministry, and took with them John, whose surname was Mark.
