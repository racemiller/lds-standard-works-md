# Ephesians 3

Ephesians 3 (summary): The Gentiles are fellow heirs with Israel—The love of Christ surpasses all understanding.

Ephesians 3:1 For this cause I Paul, the prisoner of Jesus Christ for you Gentiles,

Ephesians 3:2 If ye have heard of the dispensation of the grace of God which is given me to you-ward:

Ephesians 3:3 How that by revelation he made known unto me the mystery; (as I wrote afore in few words,

Ephesians 3:4 Whereby, when ye read, ye may understand my knowledge in the mystery of Christ)

Ephesians 3:5 Which in other ages was not made known unto the sons of men, as it is now revealed unto his holy apostles and prophets by the Spirit;

Ephesians 3:6 That the Gentiles should be fellowheirs, and of the same body, and partakers of his promise in Christ by the gospel:

Ephesians 3:7 Whereof I was made a minister, according to the gift of the grace of God given unto me by the effectual working of his power.

Ephesians 3:8 Unto me, who am less than the least of all saints, is this grace given, that I should preach among the Gentiles the unsearchable riches of Christ;

Ephesians 3:9 And to make all men see what is the fellowship of the mystery, which from the beginning of the world hath been hid in God, who created all things by Jesus Christ:

Ephesians 3:10 To the intent that now unto the principalities and powers in heavenly places might be known by the church the manifold wisdom of God,

Ephesians 3:11 According to the eternal purpose which he purposed in Christ Jesus our Lord:

Ephesians 3:12 In whom we have boldness and access with confidence by the faith of him.

Ephesians 3:13 Wherefore I desire that ye faint not at my tribulations for you, which is your glory.

Ephesians 3:14 For this cause I bow my knees unto the Father of our Lord Jesus Christ,

Ephesians 3:15 Of whom the whole family in heaven and earth is named,

Ephesians 3:16 That he would grant you, according to the riches of his glory, to be strengthened with might by his Spirit in the inner man;

Ephesians 3:17 That Christ may dwell in your hearts by faith; that ye, being rooted and grounded in love,

Ephesians 3:18 May be able to comprehend with all saints what is the breadth, and length, and depth, and height;

Ephesians 3:19 And to know the love of Christ, which passeth knowledge, that ye might be filled with all the fulness of God.

Ephesians 3:20 Now unto him that is able to do exceeding abundantly above all that we ask or think, according to the power that worketh in us,

Ephesians 3:21 Unto him be glory in the church by Christ Jesus throughout all ages, world without end. Amen.
