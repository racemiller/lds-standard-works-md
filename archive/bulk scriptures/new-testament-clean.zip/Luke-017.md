# Luke 17

Luke 17 (summary): Jesus speaks of offenses, forgiveness, and faith—Even the faithful are unprofitable servants—Ten lepers are healed—Jesus discourses on the Second Coming.

Luke 17:1 Then said he unto the disciples, It is impossible but that offences will come: but woe unto him, through whom they come!

Luke 17:2 It were better for him that a millstone were hanged about his neck, and he cast into the sea, than that he should offend one of these little ones.

Luke 17:3 Take heed to yourselves: If thy brother trespass against thee, rebuke him; and if he repent, forgive him.

Luke 17:4 And if he trespass against thee seven times in a day, and seven times in a day turn again to thee, saying, I repent; thou shalt forgive him.

Luke 17:5 And the apostles said unto the Lord, Increase our faith.

Luke 17:6 And the Lord said, If ye had faith as a grain of mustard seed, ye might say unto this sycamine tree, Be thou plucked up by the root, and be thou planted in the sea; and it should obey you.

Luke 17:7 But which of you, having a servant plowing or feeding cattle, will say unto him by and by, when he is come from the field, Go and sit down to meat?

Luke 17:8 And will not rather say unto him, Make ready wherewith I may sup, and gird thyself, and serve me, till I have eaten and drunken; and afterward thou shalt eat and drink?

Luke 17:9 Doth he thank that servant because he did the things that were commanded him? I trow not.

Luke 17:10 So likewise ye, when ye shall have done all those things which are commanded you, say, We are unprofitable servants: we have done that which was our duty to do.

Luke 17:11 And it came to pass, as he went to Jerusalem, that he passed through the midst of Samaria and Galilee.

Luke 17:12 And as he entered into a certain village, there met him ten men that were lepers, which stood afar off:

Luke 17:13 And they lifted up their voices, and said, Jesus, Master, have mercy on us.

Luke 17:14 And when he saw them, he said unto them, Go shew yourselves unto the priests. And it came to pass, that, as they went, they were cleansed.

Luke 17:15 And one of them, when he saw that he was healed, turned back, and with a loud voice glorified God,

Luke 17:16 And fell down on his face at his feet, giving him thanks: and he was a Samaritan.

Luke 17:17 And Jesus answering said, Were there not ten cleansed? but where are the nine?

Luke 17:18 There are not found that returned to give glory to God, save this stranger.

Luke 17:19 And he said unto him, Arise, go thy way: thy faith hath made thee whole.

Luke 17:20 And when he was demanded of the Pharisees, when the kingdom of God should come, he answered them and said, The kingdom of God cometh not with observation:

Luke 17:21 Neither shall they say, Lo here! or, lo there! for, behold, the kingdom of God is within you.

Luke 17:22 And he said unto the disciples, The days will come, when ye shall desire to see one of the days of the Son of man, and ye shall not see it.

Luke 17:23 And they shall say to you, See here; or, see there: go not after them, nor follow them.

Luke 17:24 For as the lightning, that lighteneth out of the one part under heaven, shineth unto the other part under heaven; so shall also the Son of man be in his day.

Luke 17:25 But first must he suffer many things, and be rejected of this generation.

Luke 17:26 And as it was in the days of Noe, so shall it be also in the days of the Son of man.

Luke 17:27 They did eat, they drank, they married wives, they were given in marriage, until the day that Noe entered into the ark, and the flood came, and destroyed them all.

Luke 17:28 Likewise also as it was in the days of Lot; they did eat, they drank, they bought, they sold, they planted, they builded;

Luke 17:29 But the same day that Lot went out of Sodom it rained fire and brimstone from heaven, and destroyed them all.

Luke 17:30 Even thus shall it be in the day when the Son of man is revealed.

Luke 17:31 In that day, he which shall be upon the housetop, and his stuff in the house, let him not come down to take it away: and he that is in the field, let him likewise not return back.

Luke 17:32 Remember Lot’s wife.

Luke 17:33 Whosoever shall seek to save his life shall lose it; and whosoever shall lose his life shall preserve it.

Luke 17:34 I tell you, in that night there shall be two men in one bed; the one shall be taken, and the other shall be left.

Luke 17:35 Two women shall be grinding together; the one shall be taken, and the other left.

Luke 17:36 Two men shall be in the field; the one shall be taken, and the other left.

Luke 17:37 And they answered and said unto him, Where, Lord? And he said unto them, Wheresoever the body is, thither will the eagles be gathered together.
