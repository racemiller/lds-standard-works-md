# 2 Corinthians 5

2 Corinthians 5 (summary): Saints walk by faith and seek tabernacles of immortal glory—The gospel reconciles man to God—God’s ministers carry the word of reconciliation to the world.

2 Corinthians 5:1 For we know that if our earthly house of this tabernacle were dissolved, we have a building of God, an house not made with hands, eternal in the heavens.

2 Corinthians 5:2 For in this we groan, earnestly desiring to be clothed upon with our house which is from heaven:

2 Corinthians 5:3 If so be that being clothed we shall not be found naked.

2 Corinthians 5:4 For we that are in this tabernacle do groan, being burdened: not for that we would be unclothed, but clothed upon, that mortality might be swallowed up of life.

2 Corinthians 5:5 Now he that hath wrought us for the selfsame thing is God, who also hath given unto us the earnest of the Spirit.

2 Corinthians 5:6 Therefore we are always confident, knowing that, whilst we are at home in the body, we are absent from the Lord:

2 Corinthians 5:7 (For we walk by faith, not by sight:)

2 Corinthians 5:8 We are confident, I say, and willing rather to be absent from the body, and to be present with the Lord.

2 Corinthians 5:9 Wherefore we labour, that, whether present or absent, we may be accepted of him.

2 Corinthians 5:10 For we must all appear before the judgment seat of Christ; that every one may receive the things done in his body, according to that he hath done, whether it be good or bad.

2 Corinthians 5:11 Knowing therefore the terror of the Lord, we persuade men; but we are made manifest unto God; and I trust also are made manifest in your consciences.

2 Corinthians 5:12 For we commend not ourselves again unto you, but give you occasion to glory on our behalf, that ye may have somewhat to answer them which glory in appearance, and not in heart.

2 Corinthians 5:13 For whether we be beside ourselves, it is to God: or whether we be sober, it is for your cause.

2 Corinthians 5:14 For the love of Christ constraineth us; because we thus judge, that if one died for all, then were all dead:

2 Corinthians 5:15 And that he died for all, that they which live should not henceforth live unto themselves, but unto him which died for them, and rose again.

2 Corinthians 5:16 Wherefore henceforth know we no man after the flesh: yea, though we have known Christ after the flesh, yet now henceforth know we him no more.

2 Corinthians 5:17 Therefore if any man be in Christ, he is a new creature: old things are passed away; behold, all things are become new.

2 Corinthians 5:18 And all things are of God, who hath reconciled us to himself by Jesus Christ, and hath given to us the ministry of reconciliation;

2 Corinthians 5:19 To wit, that God was in Christ, reconciling the world unto himself, not imputing their trespasses unto them; and hath committed unto us the word of reconciliation.

2 Corinthians 5:20 Now then we are ambassadors for Christ, as though God did beseech you by us: we pray you in Christ’s stead, be ye reconciled to God.

2 Corinthians 5:21 For he hath made him to be sin for us, who knew no sin; that we might be made the righteousness of God in him.
