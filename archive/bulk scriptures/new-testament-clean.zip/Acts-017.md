# Acts 17

Acts 17 (summary): Paul and Silas preach and are persecuted in Thessalonica and in Berea—Paul, in Athens, preaches from Mars’ Hill about the unknown god—He says, We are the offspring of God.

Acts 17:1 Now when they had passed through Amphipolis and Apollonia, they came to Thessalonica, where was a synagogue of the Jews:

Acts 17:2 And Paul, as his manner was, went in unto them, and three sabbath days reasoned with them out of the scriptures,

Acts 17:3 Opening and alleging, that Christ must needs have suffered, and risen again from the dead; and that this Jesus, whom I preach unto you, is Christ.

Acts 17:4 And some of them believed, and consorted with Paul and Silas; and of the devout Greeks a great multitude, and of the chief women not a few.

Acts 17:5 But the Jews which believed not, moved with envy, took unto them certain lewd fellows of the baser sort, and gathered a company, and set all the city on an uproar, and assaulted the house of Jason, and sought to bring them out to the people.

Acts 17:6 And when they found them not, they drew Jason and certain brethren unto the rulers of the city, crying, These that have turned the world upside down are come hither also;

Acts 17:7 Whom Jason hath received: and these all do contrary to the decrees of Cæsar, saying that there is another king, one Jesus.

Acts 17:8 And they troubled the people and the rulers of the city, when they heard these things.

Acts 17:9 And when they had taken security of Jason, and of the other, they let them go.

Acts 17:10 And the brethren immediately sent away Paul and Silas by night unto Berea: who coming thither went into the synagogue of the Jews.

Acts 17:11 These were more noble than those in Thessalonica, in that they received the word with all readiness of mind, and searched the scriptures daily, whether those things were so.

Acts 17:12 Therefore many of them believed; also of honourable women which were Greeks, and of men, not a few.

Acts 17:13 But when the Jews of Thessalonica had knowledge that the word of God was preached of Paul at Berea, they came thither also, and stirred up the people.

Acts 17:14 And then immediately the brethren sent away Paul to go as it were to the sea: but Silas and Timotheus abode there still.

Acts 17:15 And they that conducted Paul brought him unto Athens: and receiving a commandment unto Silas and Timotheus for to come to him with all speed, they departed.

Acts 17:16 Now while Paul waited for them at Athens, his spirit was stirred in him, when he saw the city wholly given to idolatry.

Acts 17:17 Therefore disputed he in the synagogue with the Jews, and with the devout persons, and in the market daily with them that met with him.

Acts 17:18 Then certain philosophers of the Epicureans, and of the Stoicks, encountered him. And some said, What will this babbler say? other some, He seemeth to be a setter forth of strange gods: because he preached unto them Jesus, and the resurrection.

Acts 17:19 And they took him, and brought him unto Areopagus, saying, May we know what this new doctrine, whereof thou speakest, is?

Acts 17:20 For thou bringest certain strange things to our ears: we would know therefore what these things mean.

Acts 17:21 (For all the Athenians and strangers which were there spent their time in nothing else, but either to tell, or to hear some new thing.)

Acts 17:22 Then Paul stood in the midst of Mars’ hill, and said, Ye men of Athens, I perceive that in all things ye are too superstitious.

Acts 17:23 For as I passed by, and beheld your devotions, I found an altar with this inscription, To the Unknown God. Whom therefore ye ignorantly worship, him declare I unto you.

Acts 17:24 God that made the world and all things therein, seeing that he is Lord of heaven and earth, dwelleth not in temples made with hands;

Acts 17:25 Neither is worshipped with men’s hands, as though he needed any thing, seeing he giveth to all life, and breath, and all things;

Acts 17:26 And hath made of one blood all nations of men for to dwell on all the face of the earth, and hath determined the times before appointed, and the bounds of their habitation;

Acts 17:27 That they should seek the Lord, if haply they might feel after him, and find him, though he be not far from every one of us:

Acts 17:28 For in him we live, and move, and have our being; as certain also of your own poets have said, For we are also his offspring.

Acts 17:29 Forasmuch then as we are the offspring of God, we ought not to think that the Godhead is like unto gold, or silver, or stone, graven by art and man’s device.

Acts 17:30 And the times of this ignorance God winked at; but now commandeth all men every where to repent:

Acts 17:31 Because he hath appointed a day, in the which he will judge the world in righteousness by that man whom he hath ordained; whereof he hath given assurance unto all men, in that he hath raised him from the dead.

Acts 17:32 And when they heard of the resurrection of the dead, some mocked: and others said, We will hear thee again of this matter.

Acts 17:33 So Paul departed from among them.

Acts 17:34 Howbeit certain men clave unto him, and believed: among the which was Dionysius the Areopagite, and a woman named Damaris, and others with them.
