# Titus 2

Titus 2 (summary): Saints should live righteously, deny ungodliness, and seek the Lord.

Titus 2:1 But speak thou the things which become sound doctrine:

Titus 2:2 That the aged men be sober, grave, temperate, sound in faith, in charity, in patience.

Titus 2:3 The aged women likewise, that they be in behaviour as becometh holiness, not false accusers, not given to much wine, teachers of good things;

Titus 2:4 That they may teach the young women to be sober, to love their husbands, to love their children,

Titus 2:5 To be discreet, chaste, keepers at home, good, obedient to their own husbands, that the word of God be not blasphemed.

Titus 2:6 Young men likewise exhort to be sober minded.

Titus 2:7 In all things shewing thyself a pattern of good works: in doctrine shewing uncorruptness, gravity, sincerity,

Titus 2:8 Sound speech, that cannot be condemned; that he that is of the contrary part may be ashamed, having no evil thing to say of you.

Titus 2:9 Exhort servants to be obedient unto their own masters, and to please them well in all things; not answering again;

Titus 2:10 Not purloining, but shewing all good fidelity; that they may adorn the doctrine of God our Saviour in all things.

Titus 2:11 For the grace of God that bringeth salvation hath appeared to all men,

Titus 2:12 Teaching us that, denying ungodliness and worldly lusts, we should live soberly, righteously, and godly, in this present world;

Titus 2:13 Looking for that blessed hope, and the glorious appearing of the great God and our Saviour Jesus Christ;

Titus 2:14 Who gave himself for us, that he might redeem us from all iniquity, and purify unto himself a peculiar people, zealous of good works.

Titus 2:15 These things speak, and exhort, and rebuke with all authority. Let no man despise thee.
