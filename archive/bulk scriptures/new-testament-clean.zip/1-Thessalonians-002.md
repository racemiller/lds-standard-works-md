# 1 Thessalonians 2

1 Thessalonians 2 (summary): True ministers preach in a godly manner—Converts are the glory and joy of missionaries.

1 Thessalonians 2:1 For yourselves, brethren, know our entrance in unto you, that it was not in vain:

1 Thessalonians 2:2 But even after that we had suffered before, and were shamefully entreated, as ye know, at Philippi, we were bold in our God to speak unto you the gospel of God with much contention.

1 Thessalonians 2:3 For our exhortation was not of deceit, nor of uncleanness, nor in guile:

1 Thessalonians 2:4 But as we were allowed of God to be put in trust with the gospel, even so we speak; not as pleasing men, but God, which trieth our hearts.

1 Thessalonians 2:5 For neither at any time used we flattering words, as ye know, nor a cloak of covetousness; God is witness:

1 Thessalonians 2:6 Nor of men sought we glory, neither of you, nor yet of others, when we might have been burdensome, as the apostles of Christ.

1 Thessalonians 2:7 But we were gentle among you, even as a nurse cherisheth her children:

1 Thessalonians 2:8 So being affectionately desirous of you, we were willing to have imparted unto you, not the gospel of God only, but also our own souls, because ye were dear unto us.

1 Thessalonians 2:9 For ye remember, brethren, our labour and travail: for labouring night and day, because we would not be chargeable unto any of you, we preached unto you the gospel of God.

1 Thessalonians 2:10 Ye are witnesses, and God also, how holily and justly and unblameably we behaved ourselves among you that believe:

1 Thessalonians 2:11 As ye know how we exhorted and comforted and charged every one of you, as a father doth his children,

1 Thessalonians 2:12 That ye would walk worthy of God, who hath called you unto his kingdom and glory.

1 Thessalonians 2:13 For this cause also thank we God without ceasing, because, when ye received the word of God which ye heard of us, ye received it not as the word of men, but as it is in truth, the word of God, which effectually worketh also in you that believe.

1 Thessalonians 2:14 For ye, brethren, became followers of the churches of God which in Judæa are in Christ Jesus: for ye also have suffered like things of your own countrymen, even as they have of the Jews:

1 Thessalonians 2:15 Who both killed the Lord Jesus, and their own prophets, and have persecuted us; and they please not God, and are contrary to all men:

1 Thessalonians 2:16 Forbidding us to speak to the Gentiles that they might be saved, to fill up their sins alway: for the wrath is come upon them to the uttermost.

1 Thessalonians 2:17 But we, brethren, being taken from you for a short time in presence, not in heart, endeavoured the more abundantly to see your face with great desire.

1 Thessalonians 2:18 Wherefore we would have come unto you, even I Paul, once and again; but Satan hindered us.

1 Thessalonians 2:19 For what is our hope, or joy, or crown of rejoicing? Are not even ye in the presence of our Lord Jesus Christ at his coming?

1 Thessalonians 2:20 For ye are our glory and joy.
