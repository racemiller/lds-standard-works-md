# Luke 15

Luke 15 (summary): Jesus gives the parables of the lost sheep, the piece of silver, and the prodigal son.

Luke 15:1 Then drew near unto him all the publicans and sinners for to hear him.

Luke 15:2 And the Pharisees and scribes murmured, saying, This man receiveth sinners, and eateth with them.

Luke 15:3 And he spake this parable unto them, saying,

Luke 15:4 What man of you, having an hundred sheep, if he lose one of them, doth not leave the ninety and nine in the wilderness, and go after that which is lost, until he find it?

Luke 15:5 And when he hath found it, he layeth it on his shoulders, rejoicing.

Luke 15:6 And when he cometh home, he calleth together his friends and neighbours, saying unto them, Rejoice with me; for I have found my sheep which was lost.

Luke 15:7 I say unto you, that likewise joy shall be in heaven over one sinner that repenteth, more than over ninety and nine just persons, which need no repentance.

Luke 15:8 Either what woman having ten pieces of silver, if she lose one piece, doth not light a candle, and sweep the house, and seek diligently till she find it?

Luke 15:9 And when she hath found it, she calleth her friends and her neighbours together, saying, Rejoice with me; for I have found the piece which I had lost.

Luke 15:10 Likewise, I say unto you, there is joy in the presence of the angels of God over one sinner that repenteth.

Luke 15:11 And he said, A certain man had two sons:

Luke 15:12 And the younger of them said to his father, Father, give me the portion of goods that falleth to me. And he divided unto them his living.

Luke 15:13 And not many days after the younger son gathered all together, and took his journey into a far country, and there wasted his substance with riotous living.

Luke 15:14 And when he had spent all, there arose a mighty famine in that land; and he began to be in want.

Luke 15:15 And he went and joined himself to a citizen of that country; and he sent him into his fields to feed swine.

Luke 15:16 And he would fain have filled his belly with the husks that the swine did eat: and no man gave unto him.

Luke 15:17 And when he came to himself, he said, How many hired servants of my father’s have bread enough and to spare, and I perish with hunger!

Luke 15:18 I will arise and go to my father, and will say unto him, Father, I have sinned against heaven, and before thee,

Luke 15:19 And am no more worthy to be called thy son: make me as one of thy hired servants.

Luke 15:20 And he arose, and came to his father. But when he was yet a great way off, his father saw him, and had compassion, and ran, and fell on his neck, and kissed him.

Luke 15:21 And the son said unto him, Father, I have sinned against heaven, and in thy sight, and am no more worthy to be called thy son.

Luke 15:22 But the father said to his servants, Bring forth the best robe, and put it on him; and put a ring on his hand, and shoes on his feet:

Luke 15:23 And bring hither the fatted calf, and kill it; and let us eat, and be merry:

Luke 15:24 For this my son was dead, and is alive again; he was lost, and is found. And they began to be merry.

Luke 15:25 Now his elder son was in the field: and as he came and drew nigh to the house, he heard musick and dancing.

Luke 15:26 And he called one of the servants, and asked what these things meant.

Luke 15:27 And he said unto him, Thy brother is come; and thy father hath killed the fatted calf, because he hath received him safe and sound.

Luke 15:28 And he was angry, and would not go in: therefore came his father out, and entreated him.

Luke 15:29 And he answering said to his father, Lo, these many years do I serve thee, neither transgressed I at any time thy commandment: and yet thou never gavest me a kid, that I might make merry with my friends:

Luke 15:30 But as soon as this thy son was come, which hath devoured thy living with harlots, thou hast killed for him the fatted calf.

Luke 15:31 And he said unto him, Son, thou art ever with me, and all that I have is thine.

Luke 15:32 It was meet that we should make merry, and be glad: for this thy brother was dead, and is alive again; and was lost, and is found.
