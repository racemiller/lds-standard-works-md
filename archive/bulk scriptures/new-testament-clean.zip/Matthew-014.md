# Matthew 14

Matthew 14 (summary): John the Baptist is beheaded—Jesus feeds the five thousand and walks on the sea—Those who touch the hem of His garment are made whole.

Matthew 14:1 At that time Herod the tetrarch heard of the fame of Jesus,

Matthew 14:2 And said unto his servants, This is John the Baptist; he is risen from the dead; and therefore mighty works do shew forth themselves in him.

Matthew 14:3 For Herod had laid hold on John, and bound him, and put him in prison for Herodias’ sake, his brother Philip’s wife.

Matthew 14:4 For John said unto him, It is not lawful for thee to have her.

Matthew 14:5 And when he would have put him to death, he feared the multitude, because they counted him as a prophet.

Matthew 14:6 But when Herod’s birthday was kept, the daughter of Herodias danced before them, and pleased Herod.

Matthew 14:7 Whereupon he promised with an oath to give her whatsoever she would ask.

Matthew 14:8 And she, being before instructed of her mother, said, Give me here John Baptist’s head in a charger.

Matthew 14:9 And the king was sorry: nevertheless for the oath’s sake, and them which sat with him at meat, he commanded it to be given her.

Matthew 14:10 And he sent, and beheaded John in the prison.

Matthew 14:11 And his head was brought in a charger, and given to the damsel: and she brought it to her mother.

Matthew 14:12 And his disciples came, and took up the body, and buried it, and went and told Jesus.

Matthew 14:13 When Jesus heard of it, he departed thence by ship into a desert place apart: and when the people had heard thereof, they followed him on foot out of the cities.

Matthew 14:14 And Jesus went forth, and saw a great multitude, and was moved with compassion toward them, and he healed their sick.

Matthew 14:15 And when it was evening, his disciples came to him, saying, This is a desert place, and the time is now past; send the multitude away, that they may go into the villages, and buy themselves victuals.

Matthew 14:16 But Jesus said unto them, They need not depart; give ye them to eat.

Matthew 14:17 And they say unto him, We have here but five loaves, and two fishes.

Matthew 14:18 He said, Bring them hither to me.

Matthew 14:19 And he commanded the multitude to sit down on the grass, and took the five loaves, and the two fishes, and looking up to heaven, he blessed, and brake, and gave the loaves to his disciples, and the disciples to the multitude.

Matthew 14:20 And they did all eat, and were filled: and they took up of the fragments that remained twelve baskets full.

Matthew 14:21 And they that had eaten were about five thousand men, beside women and children.

Matthew 14:22 And straightway Jesus constrained his disciples to get into a ship, and to go before him unto the other side, while he sent the multitudes away.

Matthew 14:23 And when he had sent the multitudes away, he went up into a mountain apart to pray: and when the evening was come, he was there alone.

Matthew 14:24 But the ship was now in the midst of the sea, tossed with waves: for the wind was contrary.

Matthew 14:25 And in the fourth watch of the night Jesus went unto them, walking on the sea.

Matthew 14:26 And when the disciples saw him walking on the sea, they were troubled, saying, It is a spirit; and they cried out for fear.

Matthew 14:27 But straightway Jesus spake unto them, saying, Be of good cheer; it is I; be not afraid.

Matthew 14:28 And Peter answered him and said, Lord, if it be thou, bid me come unto thee on the water.

Matthew 14:29 And he said, Come. And when Peter was come down out of the ship, he walked on the water, to go to Jesus.

Matthew 14:30 But when he saw the wind boisterous, he was afraid; and beginning to sink, he cried, saying, Lord, save me.

Matthew 14:31 And immediately Jesus stretched forth his hand, and caught him, and said unto him, O thou of little faith, wherefore didst thou doubt?

Matthew 14:32 And when they were come into the ship, the wind ceased.

Matthew 14:33 Then they that were in the ship came and worshipped him, saying, Of a truth thou art the Son of God.

Matthew 14:34 And when they were gone over, they came into the land of Gennesaret.

Matthew 14:35 And when the men of that place had knowledge of him, they sent out into all that country round about, and brought unto him all that were diseased;

Matthew 14:36 And besought him that they might only touch the hem of his garment: and as many as touched were made perfectly whole.
