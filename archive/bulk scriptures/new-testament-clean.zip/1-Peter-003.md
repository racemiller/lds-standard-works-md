# 1 Peter 3

1 Peter 3 (summary): Husbands and wives should honor each other—Saints should live by gospel standards—Christ preached to the spirits in prison.

1 Peter 3:1 Likewise, ye wives, be in subjection to your own husbands; that, if any obey not the word, they also may without the word be won by the conversation of the wives;

1 Peter 3:2 While they behold your chaste conversation coupled with fear.

1 Peter 3:3 Whose adorning let it not be that outward adorning of plaiting the hair, and of wearing of gold, or of putting on of apparel;

1 Peter 3:4 But let it be the hidden man of the heart, in that which is not corruptible, even the ornament of a meek and quiet spirit, which is in the sight of God of great price.

1 Peter 3:5 For after this manner in the old time the holy women also, who trusted in God, adorned themselves, being in subjection unto their own husbands:

1 Peter 3:6 Even as Sara obeyed Abraham, calling him lord: whose daughters ye are, as long as ye do well, and are not afraid with any amazement.

1 Peter 3:7 Likewise, ye husbands, dwell with them according to knowledge, giving honour unto the wife, as unto the weaker vessel, and as being heirs together of the grace of life; that your prayers be not hindered.

1 Peter 3:8 Finally, be ye all of one mind, having compassion one of another, love as brethren, be pitiful, be courteous:

1 Peter 3:9 Not rendering evil for evil, or railing for railing: but contrariwise blessing; knowing that ye are thereunto called, that ye should inherit a blessing.

1 Peter 3:10 For he that will love life, and see good days, let him refrain his tongue from evil, and his lips that they speak no guile:

1 Peter 3:11 Let him eschew evil, and do good; let him seek peace, and ensue it.

1 Peter 3:12 For the eyes of the Lord are over the righteous, and his ears are open unto their prayers: but the face of the Lord is against them that do evil.

1 Peter 3:13 And who is he that will harm you, if ye be followers of that which is good?

1 Peter 3:14 But and if ye suffer for righteousness’ sake, happy are ye: and be not afraid of their terror, neither be troubled;

1 Peter 3:15 But sanctify the Lord God in your hearts: and be ready always to give an answer to every man that asketh you a reason of the hope that is in you with meekness and fear:

1 Peter 3:16 Having a good conscience; that, whereas they speak evil of you, as of evildoers, they may be ashamed that falsely accuse your good conversation in Christ.

1 Peter 3:17 For it is better, if the will of God be so, that ye suffer for well doing, than for evil doing.

1 Peter 3:18 For Christ also hath once suffered for sins, the just for the unjust, that he might bring us to God, being put to death in the flesh, but quickened by the Spirit:

1 Peter 3:19 By which also he went and preached unto the spirits in prison;

1 Peter 3:20 Which sometime were disobedient, when once the longsuffering of God waited in the days of Noah, while the ark was a preparing, wherein few, that is, eight souls were saved by water.

1 Peter 3:21 The like figure whereunto even baptism doth also now save us (not the putting away of the filth of the flesh, but the answer of a good conscience toward God,) by the resurrection of Jesus Christ:

1 Peter 3:22 Who is gone into heaven, and is on the right hand of God; angels and authorities and powers being made subject unto him.
