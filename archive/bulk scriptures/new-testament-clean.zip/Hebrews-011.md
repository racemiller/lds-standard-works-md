# Hebrews 11

Hebrews 11 (summary): By faith we understand the word and work of God—The faith of the ancients was centered in Christ—By faith, men subdued kingdoms, wrought righteousness, and worked miracles.

Hebrews 11:1 Now faith is the substance of things hoped for, the evidence of things not seen.

Hebrews 11:2 For by it the elders obtained a good report.

Hebrews 11:3 Through faith we understand that the worlds were framed by the word of God, so that things which are seen were not made of things which do appear.

Hebrews 11:4 By faith Abel offered unto God a more excellent sacrifice than Cain, by which he obtained witness that he was righteous, God testifying of his gifts: and by it he being dead yet speaketh.

Hebrews 11:5 By faith Enoch was translated that he should not see death; and was not found, because God had translated him: for before his translation he had this testimony, that he pleased God.

Hebrews 11:6 But without faith it is impossible to please him: for he that cometh to God must believe that he is, and that he is a rewarder of them that diligently seek him.

Hebrews 11:7 By faith Noah, being warned of God of things not seen as yet, moved with fear, prepared an ark to the saving of his house; by the which he condemned the world, and became heir of the righteousness which is by faith.

Hebrews 11:8 By faith Abraham, when he was called to go out into a place which he should after receive for an inheritance, obeyed; and he went out, not knowing whither he went.

Hebrews 11:9 By faith he sojourned in the land of promise, as in a strange country, dwelling in tabernacles with Isaac and Jacob, the heirs with him of the same promise:

Hebrews 11:10 For he looked for a city which hath foundations, whose builder and maker is God.

Hebrews 11:11 Through faith also Sara herself received strength to conceive seed, and was delivered of a child when she was past age, because she judged him faithful who had promised.

Hebrews 11:12 Therefore sprang there even of one, and him as good as dead, so many as the stars of the sky in multitude, and as the sand which is by the sea shore innumerable.

Hebrews 11:13 These all died in faith, not having received the promises, but having seen them afar off, and were persuaded of them, and embraced them, and confessed that they were strangers and pilgrims on the earth.

Hebrews 11:14 For they that say such things declare plainly that they seek a country.

Hebrews 11:15 And truly, if they had been mindful of that country from whence they came out, they might have had opportunity to have returned.

Hebrews 11:16 But now they desire a better country, that is, an heavenly: wherefore God is not ashamed to be called their God: for he hath prepared for them a city.

Hebrews 11:17 By faith Abraham, when he was tried, offered up Isaac: and he that had received the promises offered up his only begotten son,

Hebrews 11:18 Of whom it was said, That in Isaac shall thy seed be called:

Hebrews 11:19 Accounting that God was able to raise him up, even from the dead; from whence also he received him in a figure.

Hebrews 11:20 By faith Isaac blessed Jacob and Esau concerning things to come.

Hebrews 11:21 By faith Jacob, when he was a dying, blessed both the sons of Joseph; and worshipped, leaning upon the top of his staff.

Hebrews 11:22 By faith Joseph, when he died, made mention of the departing of the children of Israel; and gave commandment concerning his bones.

Hebrews 11:23 By faith Moses, when he was born, was hid three months of his parents, because they saw he was a proper child; and they were not afraid of the king’s commandment.

Hebrews 11:24 By faith Moses, when he was come to years, refused to be called the son of Pharaoh’s daughter;

Hebrews 11:25 Choosing rather to suffer affliction with the people of God, than to enjoy the pleasures of sin for a season;

Hebrews 11:26 Esteeming the reproach of Christ greater riches than the treasures in Egypt: for he had respect unto the recompence of the reward.

Hebrews 11:27 By faith he forsook Egypt, not fearing the wrath of the king: for he endured, as seeing him who is invisible.

Hebrews 11:28 Through faith he kept the passover, and the sprinkling of blood, lest he that destroyed the firstborn should touch them.

Hebrews 11:29 By faith they passed through the Red sea as by dry land: which the Egyptians assaying to do were drowned.

Hebrews 11:30 By faith the walls of Jericho fell down, after they were compassed about seven days.

Hebrews 11:31 By faith the harlot Rahab perished not with them that believed not, when she had received the spies with peace.

Hebrews 11:32 And what shall I more say? for the time would fail me to tell of Gedeon, and of Barak, and of Samson, and of Jephthae; of David also, and Samuel, and of the prophets:

Hebrews 11:33 Who through faith subdued kingdoms, wrought righteousness, obtained promises, stopped the mouths of lions,

Hebrews 11:34 Quenched the violence of fire, escaped the edge of the sword, out of weakness were made strong, waxed valiant in fight, turned to flight the armies of the aliens.

Hebrews 11:35 Women received their dead raised to life again: and others were tortured, not accepting deliverance; that they might obtain a better resurrection:

Hebrews 11:36 And others had trial of cruel mockings and scourgings, yea, moreover of bonds and imprisonment:

Hebrews 11:37 They were stoned, they were sawn asunder, were tempted, were slain with the sword: they wandered about in sheepskins and goatskins; being destitute, afflicted, tormented;

Hebrews 11:38 (Of whom the world was not worthy:) they wandered in deserts, and in mountains, and in dens and caves of the earth.

Hebrews 11:39 And these all, having obtained a good report through faith, received not the promise:

Hebrews 11:40 God having provided some better thing for us, that they without us should not be made perfect.
