# Acts 26

Acts 26 (summary): Paul recounts his former persecution of the Saints as a Pharisee—He testifies of the appearance of Jesus on the Damascus road—Paul bears his testimony to King Agrippa.

Acts 26:1 Then Agrippa said unto Paul, Thou art permitted to speak for thyself. Then Paul stretched forth the hand, and answered for himself:

Acts 26:2 I think myself happy, king Agrippa, because I shall answer for myself this day before thee touching all the things whereof I am accused of the Jews:

Acts 26:3 Especially because I know thee to be expert in all customs and questions which are among the Jews: wherefore I beseech thee to hear me patiently.

Acts 26:4 My manner of life from my youth, which was at the first among mine own nation at Jerusalem, know all the Jews;

Acts 26:5 Which knew me from the beginning, if they would testify, that after the most straitest sect of our religion I lived a Pharisee.

Acts 26:6 And now I stand and am judged for the hope of the promise made of God unto our fathers:

Acts 26:7 Unto which promise our twelve tribes, instantly serving God day and night, hope to come. For which hope’s sake, king Agrippa, I am accused of the Jews.

Acts 26:8 Why should it be thought a thing incredible with you, that God should raise the dead?

Acts 26:9 I verily thought with myself, that I ought to do many things contrary to the name of Jesus of Nazareth.

Acts 26:10 Which thing I also did in Jerusalem: and many of the saints did I shut up in prison, having received authority from the chief priests; and when they were put to death, I gave my voice against them.

Acts 26:11 And I punished them oft in every synagogue, and compelled them to blaspheme; and being exceedingly mad against them, I persecuted them even unto strange cities.

Acts 26:12 Whereupon as I went to Damascus with authority and commission from the chief priests,

Acts 26:13 At midday, O king, I saw in the way a light from heaven, above the brightness of the sun, shining round about me and them which journeyed with me.

Acts 26:14 And when we were all fallen to the earth, I heard a voice speaking unto me, and saying in the Hebrew tongue, Saul, Saul, why persecutest thou me? it is hard for thee to kick against the pricks.

Acts 26:15 And I said, Who art thou, Lord? And he said, I am Jesus whom thou persecutest.

Acts 26:16 But rise, and stand upon thy feet: for I have appeared unto thee for this purpose, to make thee a minister and a witness both of these things which thou hast seen, and of those things in the which I will appear unto thee;

Acts 26:17 Delivering thee from the people, and from the Gentiles, unto whom now I send thee,

Acts 26:18 To open their eyes, and to turn them from darkness to light, and from the power of Satan unto God, that they may receive forgiveness of sins, and inheritance among them which are sanctified by faith that is in me.

Acts 26:19 Whereupon, O king Agrippa, I was not disobedient unto the heavenly vision:

Acts 26:20 But shewed first unto them of Damascus, and at Jerusalem, and throughout all the coasts of Judæa, and then to the Gentiles, that they should repent and turn to God, and do works meet for repentance.

Acts 26:21 For these causes the Jews caught me in the temple, and went about to kill me.

Acts 26:22 Having therefore obtained help of God, I continue unto this day, witnessing both to small and great, saying none other things than those which the prophets and Moses did say should come:

Acts 26:23 That Christ should suffer, and that he should be the first that should rise from the dead, and should shew light unto the people, and to the Gentiles.

Acts 26:24 And as he thus spake for himself, Festus said with a loud voice, Paul, thou art beside thyself; much learning doth make thee mad.

Acts 26:25 But he said, I am not mad, most noble Festus; but speak forth the words of truth and soberness.

Acts 26:26 For the king knoweth of these things, before whom also I speak freely: for I am persuaded that none of these things are hidden from him; for this thing was not done in a corner.

Acts 26:27 King Agrippa, believest thou the prophets? I know that thou believest.

Acts 26:28 Then Agrippa said unto Paul, Almost thou persuadest me to be a Christian.

Acts 26:29 And Paul said, I would to God, that not only thou, but also all that hear me this day, were both almost, and altogether such as I am, except these bonds.

Acts 26:30 And when he had thus spoken, the king rose up, and the governor, and Bernice, and they that sat with them:

Acts 26:31 And when they were gone aside, they talked between themselves, saying, This man doeth nothing worthy of death or of bonds.

Acts 26:32 Then said Agrippa unto Festus, This man might have been set at liberty, if he had not appealed unto Cæsar.
