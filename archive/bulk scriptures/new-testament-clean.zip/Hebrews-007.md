# Hebrews 7

Hebrews 7 (summary): The Melchizedek Priesthood brings exaltation and administers the gospel—It is received with an oath and covenant—The superiority of the Melchizedek Priesthood over the Aaronic Priesthood is explained—Salvation comes through the intercession of Christ.

Hebrews 7:1 For this Melchisedec, king of Salem, priest of the most high God, who met Abraham returning from the slaughter of the kings, and blessed him;

Hebrews 7:2 To whom also Abraham gave a tenth part of all; first being by interpretation King of righteousness, and after that also King of Salem, which is, King of peace;

Hebrews 7:3 Without father, without mother, without descent, having neither beginning of days, nor end of life; but made like unto the Son of God; abideth a priest continually.

Hebrews 7:4 Now consider how great this man was, unto whom even the patriarch Abraham gave the tenth of the spoils.

Hebrews 7:5 And verily they that are of the sons of Levi, who receive the office of the priesthood, have a commandment to take tithes of the people according to the law, that is, of their brethren, though they come out of the loins of Abraham:

Hebrews 7:6 But he whose descent is not counted from them received tithes of Abraham, and blessed him that had the promises.

Hebrews 7:7 And without all contradiction the less is blessed of the better.

Hebrews 7:8 And here men that die receive tithes; but there he receiveth them, of whom it is witnessed that he liveth.

Hebrews 7:9 And as I may so say, Levi also, who receiveth tithes, payed tithes in Abraham.

Hebrews 7:10 For he was yet in the loins of his father, when Melchisedec met him.

Hebrews 7:11 If therefore perfection were by the Levitical priesthood, (for under it the people received the law,) what further need was there that another priest should rise after the order of Melchisedec, and not be called after the order of Aaron?

Hebrews 7:12 For the priesthood being changed, there is made of necessity a change also of the law.

Hebrews 7:13 For he of whom these things are spoken pertaineth to another tribe, of which no man gave attendance at the altar.

Hebrews 7:14 For it is evident that our Lord sprang out of Juda; of which tribe Moses spake nothing concerning priesthood.

Hebrews 7:15 And it is yet far more evident: for that after the similitude of Melchisedec there ariseth another priest,

Hebrews 7:16 Who is made, not after the law of a carnal commandment, but after the power of an endless life.

Hebrews 7:17 For he testifieth, Thou art a priest for ever after the order of Melchisedec.

Hebrews 7:18 For there is verily a disannulling of the commandment going before for the weakness and unprofitableness thereof.

Hebrews 7:19 For the law made nothing perfect, but the bringing in of a better hope did; by the which we draw nigh unto God.

Hebrews 7:20 And inasmuch as not without an oath he was made priest:

Hebrews 7:21 (For those priests were made without an oath; but this with an oath by him that said unto him, The Lord sware and will not repent, Thou art a priest for ever after the order of Melchisedec:)

Hebrews 7:22 By so much was Jesus made a surety of a better testament.

Hebrews 7:23 And they truly were many priests, because they were not suffered to continue by reason of death:

Hebrews 7:24 But this man, because he continueth ever, hath an unchangeable priesthood.

Hebrews 7:25 Wherefore he is able also to save them to the uttermost that come unto God by him, seeing he ever liveth to make intercession for them.

Hebrews 7:26 For such an high priest became us, who is holy, harmless, undefiled, separate from sinners, and made higher than the heavens;

Hebrews 7:27 Who needeth not daily, as those high priests, to offer up sacrifice, first for his own sins, and then for the people’s: for this he did once, when he offered up himself.

Hebrews 7:28 For the law maketh men high priests which have infirmity; but the word of the oath, which was since the law, maketh the Son, who is consecrated for evermore.
