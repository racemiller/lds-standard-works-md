# 2 Peter 3

2 Peter 3 (summary): Some in the latter days will doubt the Second Coming—The elements will melt at the coming of the Lord.

2 Peter 3:1 This second epistle, beloved, I now write unto you; in both which I stir up your pure minds by way of remembrance:

2 Peter 3:2 That ye may be mindful of the words which were spoken before by the holy prophets, and of the commandment of us the apostles of the Lord and Saviour:

2 Peter 3:3 Knowing this first, that there shall come in the last days scoffers, walking after their own lusts,

2 Peter 3:4 And saying, Where is the promise of his coming? for since the fathers fell asleep, all things continue as they were from the beginning of the creation.

2 Peter 3:5 For this they willingly are ignorant of, that by the word of God the heavens were of old, and the earth standing out of the water and in the water:

2 Peter 3:6 Whereby the world that then was, being overflowed with water, perished:

2 Peter 3:7 But the heavens and the earth, which are now, by the same word are kept in store, reserved unto fire against the day of judgment and perdition of ungodly men.

2 Peter 3:8 But, beloved, be not ignorant of this one thing, that one day is with the Lord as a thousand years, and a thousand years as one day.

2 Peter 3:9 The Lord is not slack concerning his promise, as some men count slackness; but is longsuffering to us-ward, not willing that any should perish, but that all should come to repentance.

2 Peter 3:10 But the day of the Lord will come as a thief in the night; in the which the heavens shall pass away with a great noise, and the elements shall melt with fervent heat, the earth also and the works that are therein shall be burned up.

2 Peter 3:11 Seeing then that all these things shall be dissolved, what manner of persons ought ye to be in all holy conversation and godliness,

2 Peter 3:12 Looking for and hasting unto the coming of the day of God, wherein the heavens being on fire shall be dissolved, and the elements shall melt with fervent heat?

2 Peter 3:13 Nevertheless we, according to his promise, look for new heavens and a new earth, wherein dwelleth righteousness.

2 Peter 3:14 Wherefore, beloved, seeing that ye look for such things, be diligent that ye may be found of him in peace, without spot, and blameless.

2 Peter 3:15 And account that the longsuffering of our Lord is salvation; even as our beloved brother Paul also according to the wisdom given unto him hath written unto you;

2 Peter 3:16 As also in all his epistles, speaking in them of these things; in which are some things hard to be understood, which they that are unlearned and unstable wrest, as they do also the other scriptures, unto their own destruction.

2 Peter 3:17 Ye therefore, beloved, seeing ye know these things before, beware lest ye also, being led away with the error of the wicked, fall from your own steadfastness.

2 Peter 3:18 But grow in grace, and in the knowledge of our Lord and Saviour Jesus Christ. To him be glory both now and for ever. Amen.
