# Romans 14

Romans 14 (summary): Avoid quarreling about opinions and making unrighteous judgment of each other—Every knee will bow to Christ—The kingdom of God embraces righteousness, peace, and joy in the Holy Ghost.

Romans 14:1 Him that is weak in the faith receive ye, but not to doubtful disputations.

Romans 14:2 For one believeth that he may eat all things: another, who is weak, eateth herbs.

Romans 14:3 Let not him that eateth despise him that eateth not; and let not him which eateth not judge him that eateth: for God hath received him.

Romans 14:4 Who art thou that judgest another man’s servant? to his own master he standeth or falleth. Yea, he shall be holden up: for God is able to make him stand.

Romans 14:5 One man esteemeth one day above another: another esteemeth every day alike. Let every man be fully persuaded in his own mind.

Romans 14:6 He that regardeth the day, regardeth it unto the Lord; and he that regardeth not the day, to the Lord he doth not regard it. He that eateth, eateth to the Lord, for he giveth God thanks; and he that eateth not, to the Lord he eateth not, and giveth God thanks.

Romans 14:7 For none of us liveth to himself, and no man dieth to himself.

Romans 14:8 For whether we live, we live unto the Lord; and whether we die, we die unto the Lord: whether we live therefore, or die, we are the Lord’s.

Romans 14:9 For to this end Christ both died, and rose, and revived, that he might be Lord both of the dead and living.

Romans 14:10 But why dost thou judge thy brother? or why dost thou set at nought thy brother? for we shall all stand before the judgment seat of Christ.

Romans 14:11 For it is written, As I live, saith the Lord, every knee shall bow to me, and every tongue shall confess to God.

Romans 14:12 So then every one of us shall give account of himself to God.

Romans 14:13 Let us not therefore judge one another any more: but judge this rather, that no man put a stumblingblock or an occasion to fall in his brother’s way.

Romans 14:14 I know, and am persuaded by the Lord Jesus, that there is nothing unclean of itself: but to him that esteemeth any thing to be unclean, to him it is unclean.

Romans 14:15 But if thy brother be grieved with thy meat, now walkest thou not charitably. Destroy not him with thy meat, for whom Christ died.

Romans 14:16 Let not then your good be evil spoken of:

Romans 14:17 For the kingdom of God is not meat and drink; but righteousness, and peace, and joy in the Holy Ghost.

Romans 14:18 For he that in these things serveth Christ is acceptable to God, and approved of men.

Romans 14:19 Let us therefore follow after the things which make for peace, and things wherewith one may edify another.

Romans 14:20 For meat destroy not the work of God. All things indeed are pure; but it is evil for that man who eateth with offence.

Romans 14:21 It is good neither to eat flesh, nor to drink wine, nor any thing whereby thy brother stumbleth, or is offended, or is made weak.

Romans 14:22 Hast thou faith? have it to thyself before God. Happy is he that condemneth not himself in that thing which he alloweth.

Romans 14:23 And he that doubteth is damned if he eat, because he eateth not of faith: for whatsoever is not of faith is sin.
