# Luke 18

Luke 18 (summary): Jesus gives the parables of the unjust judge and the Pharisee and publican—He invites little children to come unto Him and teaches how to gain eternal life—He tells of His coming death and resurrection and gives sight to a blind man.

Luke 18:1 And he spake a parable unto them to this end, that men ought always to pray, and not to faint;

Luke 18:2 Saying, There was in a city a judge, which feared not God, neither regarded man:

Luke 18:3 And there was a widow in that city; and she came unto him, saying, Avenge me of mine adversary.

Luke 18:4 And he would not for a while: but afterward he said within himself, Though I fear not God, nor regard man;

Luke 18:5 Yet because this widow troubleth me, I will avenge her, lest by her continual coming she weary me.

Luke 18:6 And the Lord said, Hear what the unjust judge saith.

Luke 18:7 And shall not God avenge his own elect, which cry day and night unto him, though he bear long with them?

Luke 18:8 I tell you that he will avenge them speedily. Nevertheless when the Son of man cometh, shall he find faith on the earth?

Luke 18:9 And he spake this parable unto certain which trusted in themselves that they were righteous, and despised others:

Luke 18:10 Two men went up into the temple to pray; the one a Pharisee, and the other a publican.

Luke 18:11 The Pharisee stood and prayed thus with himself, God, I thank thee, that I am not as other men are, extortioners, unjust, adulterers, or even as this publican.

Luke 18:12 I fast twice in the week, I give tithes of all that I possess.

Luke 18:13 And the publican, standing afar off, would not lift up so much as his eyes unto heaven, but smote upon his breast, saying, God be merciful to me a sinner.

Luke 18:14 I tell you, this man went down to his house justified rather than the other: for every one that exalteth himself shall be abased; and he that humbleth himself shall be exalted.

Luke 18:15 And they brought unto him also infants, that he would touch them: but when his disciples saw it, they rebuked them.

Luke 18:16 But Jesus called them unto him, and said, Suffer little children to come unto me, and forbid them not: for of such is the kingdom of God.

Luke 18:17 Verily I say unto you, Whosoever shall not receive the kingdom of God as a little child shall in no wise enter therein.

Luke 18:18 And a certain ruler asked him, saying, Good Master, what shall I do to inherit eternal life?

Luke 18:19 And Jesus said unto him, Why callest thou me good? none is good, save one, that is, God.

Luke 18:20 Thou knowest the commandments, Do not commit adultery, Do not kill, Do not steal, Do not bear false witness, Honour thy father and thy mother.

Luke 18:21 And he said, All these have I kept from my youth up.

Luke 18:22 Now when Jesus heard these things, he said unto him, Yet lackest thou one thing: sell all that thou hast, and distribute unto the poor, and thou shalt have treasure in heaven: and come, follow me.

Luke 18:23 And when he heard this, he was very sorrowful: for he was very rich.

Luke 18:24 And when Jesus saw that he was very sorrowful, he said, How hardly shall they that have riches enter into the kingdom of God!

Luke 18:25 For it is easier for a camel to go through a needle’s eye, than for a rich man to enter into the kingdom of God.

Luke 18:26 And they that heard it said, Who then can be saved?

Luke 18:27 And he said, The things which are impossible with men are possible with God.

Luke 18:28 Then Peter said, Lo, we have left all, and followed thee.

Luke 18:29 And he said unto them, Verily I say unto you, There is no man that hath left house, or parents, or brethren, or wife, or children, for the kingdom of God’s sake,

Luke 18:30 Who shall not receive manifold more in this present time, and in the world to come life everlasting.

Luke 18:31 Then he took unto him the twelve, and said unto them, Behold, we go up to Jerusalem, and all things that are written by the prophets concerning the Son of man shall be accomplished.

Luke 18:32 For he shall be delivered unto the Gentiles, and shall be mocked, and spitefully entreated, and spitted on:

Luke 18:33 And they shall scourge him, and put him to death: and the third day he shall rise again.

Luke 18:34 And they understood none of these things: and this saying was hid from them, neither knew they the things which were spoken.

Luke 18:35 And it came to pass, that as he was come nigh unto Jericho, a certain blind man sat by the way side begging:

Luke 18:36 And hearing the multitude pass by, he asked what it meant.

Luke 18:37 And they told him, that Jesus of Nazareth passeth by.

Luke 18:38 And he cried, saying, Jesus, thou Son of David, have mercy on me.

Luke 18:39 And they which went before rebuked him, that he should hold his peace: but he cried so much the more, Thou Son of David, have mercy on me.

Luke 18:40 And Jesus stood, and commanded him to be brought unto him: and when he was come near, he asked him,

Luke 18:41 Saying, What wilt thou that I shall do unto thee? And he said, Lord, that I may receive my sight.

Luke 18:42 And Jesus said unto him, Receive thy sight: thy faith hath saved thee.

Luke 18:43 And immediately he received his sight, and followed him, glorifying God: and all the people, when they saw it, gave praise unto God.
