# Luke 21

Luke 21 (summary): Jesus foretells the destruction of the temple and of Jerusalem—He tells of the signs to precede His Second Coming and gives the parable of the fig tree.

Luke 21:1 And he looked up, and saw the rich men casting their gifts into the treasury.

Luke 21:2 And he saw also a certain poor widow casting in thither two mites.

Luke 21:3 And he said, Of a truth I say unto you, that this poor widow hath cast in more than they all:

Luke 21:4 For all these have of their abundance cast in unto the offerings of God: but she of her penury hath cast in all the living that she had.

Luke 21:5 And as some spake of the temple, how it was adorned with goodly stones and gifts, he said,

Luke 21:6 As for these things which ye behold, the days will come, in the which there shall not be left one stone upon another, that shall not be thrown down.

Luke 21:7 And they asked him, saying, Master, but when shall these things be? and what sign will there be when these things shall come to pass?

Luke 21:8 And he said, Take heed that ye be not deceived: for many shall come in my name, saying, I am Christ; and the time draweth near: go ye not therefore after them.

Luke 21:9 But when ye shall hear of wars and commotions, be not terrified: for these things must first come to pass; but the end is not by and by.

Luke 21:10 Then said he unto them, Nation shall rise against nation, and kingdom against kingdom:

Luke 21:11 And great earthquakes shall be in divers places, and famines, and pestilences; and fearful sights and great signs shall there be from heaven.

Luke 21:12 But before all these, they shall lay their hands on you, and persecute you, delivering you up to the synagogues, and into prisons, being brought before kings and rulers for my name’s sake.

Luke 21:13 And it shall turn to you for a testimony.

Luke 21:14 Settle it therefore in your hearts, not to meditate before what ye shall answer:

Luke 21:15 For I will give you a mouth and wisdom, which all your adversaries shall not be able to gainsay nor resist.

Luke 21:16 And ye shall be betrayed both by parents, and brethren, and kinsfolks, and friends; and some of you shall they cause to be put to death.

Luke 21:17 And ye shall be hated of all men for my name’s sake.

Luke 21:18 But there shall not an hair of your head perish.

Luke 21:19 In your patience possess ye your souls.

Luke 21:20 And when ye shall see Jerusalem compassed with armies, then know that the desolation thereof is nigh.

Luke 21:21 Then let them which are in Judæa flee to the mountains; and let them which are in the midst of it depart out; and let not them that are in the countries enter thereinto.

Luke 21:22 For these be the days of vengeance, that all things which are written may be fulfilled.

Luke 21:23 But woe unto them that are with child, and to them that give suck, in those days! for there shall be great distress in the land, and wrath upon this people.

Luke 21:24 And they shall fall by the edge of the sword, and shall be led away captive into all nations: and Jerusalem shall be trodden down of the Gentiles, until the times of the Gentiles be fulfilled.

Luke 21:25 And there shall be signs in the sun, and in the moon, and in the stars; and upon the earth distress of nations, with perplexity; the sea and the waves roaring;

Luke 21:26 Men’s hearts failing them for fear, and for looking after those things which are coming on the earth: for the powers of heaven shall be shaken.

Luke 21:27 And then shall they see the Son of man coming in a cloud with power and great glory.

Luke 21:28 And when these things begin to come to pass, then look up, and lift up your heads; for your redemption draweth nigh.

Luke 21:29 And he spake to them a parable; Behold the fig tree, and all the trees;

Luke 21:30 When they now shoot forth, ye see and know of your own selves that summer is now nigh at hand.

Luke 21:31 So likewise ye, when ye see these things come to pass, know ye that the kingdom of God is nigh at hand.

Luke 21:32 Verily I say unto you, This generation shall not pass away, till all be fulfilled.

Luke 21:33 Heaven and earth shall pass away: but my words shall not pass away.

Luke 21:34 And take heed to yourselves, lest at any time your hearts be overcharged with surfeiting, and drunkenness, and cares of this life, and so that day come upon you unawares.

Luke 21:35 For as a snare shall it come on all them that dwell on the face of the whole earth.

Luke 21:36 Watch ye therefore, and pray always, that ye may be accounted worthy to escape all these things that shall come to pass, and to stand before the Son of man.

Luke 21:37 And in the day time he was teaching in the temple; and at night he went out, and abode in the mount that is called the mount of Olives.

Luke 21:38 And all the people came early in the morning to him in the temple, for to hear him.
