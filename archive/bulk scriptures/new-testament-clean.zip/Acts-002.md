# Acts 2

Acts 2 (summary): The Spirit is poured out on the day of Pentecost—Peter testifies of Jesus’ resurrection—He tells how to gain salvation and speaks of the gift of the Holy Ghost—Many believe and are baptized.

Acts 2:1 And when the day of Pentecost was fully come, they were all with one accord in one place.

Acts 2:2 And suddenly there came a sound from heaven as of a rushing mighty wind, and it filled all the house where they were sitting.

Acts 2:3 And there appeared unto them cloven tongues like as of fire, and it sat upon each of them.

Acts 2:4 And they were all filled with the Holy Ghost, and began to speak with other tongues, as the Spirit gave them utterance.

Acts 2:5 And there were dwelling at Jerusalem Jews, devout men, out of every nation under heaven.

Acts 2:6 Now when this was noised abroad, the multitude came together, and were confounded, because that every man heard them speak in his own language.

Acts 2:7 And they were all amazed and marvelled, saying one to another, Behold, are not all these which speak Galilæans?

Acts 2:8 And how hear we every man in our own tongue, wherein we were born?

Acts 2:9 Parthians, and Medes, and Elamites, and the dwellers in Mesopotamia, and in Judæa, and Cappadocia, in Pontus, and Asia,

Acts 2:10 Phrygia, and Pamphylia, in Egypt, and in the parts of Libya about Cyrene, and strangers of Rome, Jews and proselytes,

Acts 2:11 Cretes and Arabians, we do hear them speak in our tongues the wonderful works of God.

Acts 2:12 And they were all amazed, and were in doubt, saying one to another, What meaneth this?

Acts 2:13 Others mocking said, These men are full of new wine.

Acts 2:14 But Peter, standing up with the eleven, lifted up his voice, and said unto them, Ye men of Judæa, and all ye that dwell at Jerusalem, be this known unto you, and hearken to my words:

Acts 2:15 For these are not drunken, as ye suppose, seeing it is but the third hour of the day.

Acts 2:16 But this is that which was spoken by the prophet Joel;

Acts 2:17 And it shall come to pass in the last days, saith God, I will pour out of my Spirit upon all flesh: and your sons and your daughters shall prophesy, and your young men shall see visions, and your old men shall dream dreams:

Acts 2:18 And on my servants and on my handmaidens I will pour out in those days of my Spirit; and they shall prophesy:

Acts 2:19 And I will shew wonders in heaven above, and signs in the earth beneath; blood, and fire, and vapour of smoke:

Acts 2:20 The sun shall be turned into darkness, and the moon into blood, before that great and notable day of the Lord come:

Acts 2:21 And it shall come to pass, that whosoever shall call on the name of the Lord shall be saved.

Acts 2:22 Ye men of Israel, hear these words; Jesus of Nazareth, a man approved of God among you by miracles and wonders and signs, which God did by him in the midst of you, as ye yourselves also know:

Acts 2:23 Him, being delivered by the determinate counsel and foreknowledge of God, ye have taken, and by wicked hands have crucified and slain:

Acts 2:24 Whom God hath raised up, having loosed the pains of death: because it was not possible that he should be holden of it.

Acts 2:25 For David speaketh concerning him, I foresaw the Lord always before my face, for he is on my right hand, that I should not be moved:

Acts 2:26 Therefore did my heart rejoice, and my tongue was glad; moreover also my flesh shall rest in hope:

Acts 2:27 Because thou wilt not leave my soul in hell, neither wilt thou suffer thine Holy One to see corruption.

Acts 2:28 Thou hast made known to me the ways of life; thou shalt make me full of joy with thy countenance.

Acts 2:29 Men and brethren, let me freely speak unto you of the patriarch David, that he is both dead and buried, and his sepulchre is with us unto this day.

Acts 2:30 Therefore being a prophet, and knowing that God had sworn with an oath to him, that of the fruit of his loins, according to the flesh, he would raise up Christ to sit on his throne;

Acts 2:31 He seeing this before spake of the resurrection of Christ, that his soul was not left in hell, neither his flesh did see corruption.

Acts 2:32 This Jesus hath God raised up, whereof we all are witnesses.

Acts 2:33 Therefore being by the right hand of God exalted, and having received of the Father the promise of the Holy Ghost, he hath shed forth this, which ye now see and hear.

Acts 2:34 For David is not ascended into the heavens: but he saith himself, The Lord said unto my Lord, Sit thou on my right hand,

Acts 2:35 Until I make thy foes thy footstool.

Acts 2:36 Therefore let all the house of Israel know assuredly, that God hath made that same Jesus, whom ye have crucified, both Lord and Christ.

Acts 2:37 Now when they heard this, they were pricked in their heart, and said unto Peter and to the rest of the apostles, Men and brethren, what shall we do?

Acts 2:38 Then Peter said unto them, Repent, and be baptized every one of you in the name of Jesus Christ for the remission of sins, and ye shall receive the gift of the Holy Ghost.

Acts 2:39 For the promise is unto you, and to your children, and to all that are afar off, even as many as the Lord our God shall call.

Acts 2:40 And with many other words did he testify and exhort, saying, Save yourselves from this untoward generation.

Acts 2:41 Then they that gladly received his word were baptized: and the same day there were added unto them about three thousand souls.

Acts 2:42 And they continued steadfastly in the apostles’ doctrine and fellowship, and in breaking of bread, and in prayers.

Acts 2:43 And fear came upon every soul: and many wonders and signs were done by the apostles.

Acts 2:44 And all that believed were together, and had all things common;

Acts 2:45 And sold their possessions and goods, and parted them to all men, as every man had need.

Acts 2:46 And they, continuing daily with one accord in the temple, and breaking bread from house to house, did eat their meat with gladness and singleness of heart,

Acts 2:47 Praising God, and having favour with all the people. And the Lord added to the church daily such as should be saved.
