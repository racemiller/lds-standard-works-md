# John 18

John 18 (summary): Jesus is betrayed and arrested—He is examined and maltreated first before Annas, then before Caiaphas—Peter denies knowing Jesus—Jesus is arraigned before Pilate.

John 18:1 When Jesus had spoken these words, he went forth with his disciples over the brook Cedron, where was a garden, into the which he entered, and his disciples.

John 18:2 And Judas also, which betrayed him, knew the place: for Jesus ofttimes resorted thither with his disciples.

John 18:3 Judas then, having received a band of men and officers from the chief priests and Pharisees, cometh thither with lanterns and torches and weapons.

John 18:4 Jesus therefore, knowing all things that should come upon him, went forth, and said unto them, Whom seek ye?

John 18:5 They answered him, Jesus of Nazareth. Jesus saith unto them, I am he. And Judas also, which betrayed him, stood with them.

John 18:6 As soon then as he had said unto them, I am he, they went backward, and fell to the ground.

John 18:7 Then asked he them again, Whom seek ye? And they said, Jesus of Nazareth.

John 18:8 Jesus answered, I have told you that I am he: if therefore ye seek me, let these go their way:

John 18:9 That the saying might be fulfilled, which he spake, Of them which thou gavest me have I lost none.

John 18:10 Then Simon Peter having a sword drew it, and smote the high priest’s servant, and cut off his right ear. The servant’s name was Malchus.

John 18:11 Then said Jesus unto Peter, Put up thy sword into the sheath: the cup which my Father hath given me, shall I not drink it?

John 18:12 Then the band and the captain and officers of the Jews took Jesus, and bound him,

John 18:13 And led him away to Annas first; for he was father in law to Caiaphas, which was the high priest that same year.

John 18:14 Now Caiaphas was he, which gave counsel to the Jews, that it was expedient that one man should die for the people.

John 18:15 And Simon Peter followed Jesus, and so did another disciple: that disciple was known unto the high priest, and went in with Jesus into the palace of the high priest.

John 18:16 But Peter stood at the door without. Then went out that other disciple, which was known unto the high priest, and spake unto her that kept the door, and brought in Peter.

John 18:17 Then saith the damsel that kept the door unto Peter, Art not thou also one of this man’s disciples? He saith, I am not.

John 18:18 And the servants and officers stood there, who had made a fire of coals; for it was cold: and they warmed themselves: and Peter stood with them, and warmed himself.

John 18:19 The high priest then asked Jesus of his disciples, and of his doctrine.

John 18:20 Jesus answered him, I spake openly to the world; I ever taught in the synagogue, and in the temple, whither the Jews always resort; and in secret have I said nothing.

John 18:21 Why askest thou me? ask them which heard me, what I have said unto them: behold, they know what I said.

John 18:22 And when he had thus spoken, one of the officers which stood by struck Jesus with the palm of his hand, saying, Answerest thou the high priest so?

John 18:23 Jesus answered him, If I have spoken evil, bear witness of the evil: but if well, why smitest thou me?

John 18:24 Now Annas had sent him bound unto Caiaphas the high priest.

John 18:25 And Simon Peter stood and warmed himself. They said therefore unto him, Art not thou also one of his disciples? He denied it, and said, I am not.

John 18:26 One of the servants of the high priest, being his kinsman whose ear Peter cut off, saith, Did not I see thee in the garden with him?

John 18:27 Peter then denied again: and immediately the cock crew.

John 18:28 Then led they Jesus from Caiaphas unto the hall of judgment: and it was early; and they themselves went not into the judgment hall, lest they should be defiled; but that they might eat the passover.

John 18:29 Pilate then went out unto them, and said, What accusation bring ye against this man?

John 18:30 They answered and said unto him, If he were not a malefactor, we would not have delivered him up unto thee.

John 18:31 Then said Pilate unto them, Take ye him, and judge him according to your law. The Jews therefore said unto him, It is not lawful for us to put any man to death:

John 18:32 That the saying of Jesus might be fulfilled, which he spake, signifying what death he should die.

John 18:33 Then Pilate entered into the judgment hall again, and called Jesus, and said unto him, Art thou the King of the Jews?

John 18:34 Jesus answered him, Sayest thou this thing of thyself, or did others tell it thee of me?

John 18:35 Pilate answered, Am I a Jew? Thine own nation and the chief priests have delivered thee unto me: what hast thou done?

John 18:36 Jesus answered, My kingdom is not of this world: if my kingdom were of this world, then would my servants fight, that I should not be delivered to the Jews: but now is my kingdom not from hence.

John 18:37 Pilate therefore said unto him, Art thou a king then? Jesus answered, Thou sayest that I am a king. To this end was I born, and for this cause came I into the world, that I should bear witness unto the truth. Every one that is of the truth heareth my voice.

John 18:38 Pilate saith unto him, What is truth? And when he had said this, he went out again unto the Jews, and saith unto them, I find in him no fault at all.

John 18:39 But ye have a custom, that I should release unto you one at the passover: will ye therefore that I release unto you the King of the Jews?

John 18:40 Then cried they all again, saying, Not this man, but Barabbas. Now Barabbas was a robber.
