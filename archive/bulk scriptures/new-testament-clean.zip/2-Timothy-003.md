# 2 Timothy 3

2 Timothy 3 (summary): Paul describes the apostasy and perilous times of the last days—The scriptures guide man to salvation.

2 Timothy 3:1 This know also, that in the last days perilous times shall come.

2 Timothy 3:2 For men shall be lovers of their own selves, covetous, boasters, proud, blasphemers, disobedient to parents, unthankful, unholy,

2 Timothy 3:3 Without natural affection, trucebreakers, false accusers, incontinent, fierce, despisers of those that are good,

2 Timothy 3:4 Traitors, heady, highminded, lovers of pleasures more than lovers of God;

2 Timothy 3:5 Having a form of godliness, but denying the power thereof: from such turn away.

2 Timothy 3:6 For of this sort are they which creep into houses, and lead captive silly women laden with sins, led away with divers lusts,

2 Timothy 3:7 Ever learning, and never able to come to the knowledge of the truth.

2 Timothy 3:8 Now as Jannes and Jambres withstood Moses, so do these also resist the truth: men of corrupt minds, reprobate concerning the faith.

2 Timothy 3:9 But they shall proceed no further: for their folly shall be manifest unto all men, as theirs also was.

2 Timothy 3:10 But thou hast fully known my doctrine, manner of life, purpose, faith, longsuffering, charity, patience,

2 Timothy 3:11 Persecutions, afflictions, which came unto me at Antioch, at Iconium, at Lystra; what persecutions I endured: but out of them all the Lord delivered me.

2 Timothy 3:12 Yea, and all that will live godly in Christ Jesus shall suffer persecution.

2 Timothy 3:13 But evil men and seducers shall wax worse and worse, deceiving, and being deceived.

2 Timothy 3:14 But continue thou in the things which thou hast learned and hast been assured of, knowing of whom thou hast learned them;

2 Timothy 3:15 And that from a child thou hast known the holy scriptures, which are able to make thee wise unto salvation through faith which is in Christ Jesus.

2 Timothy 3:16 All scripture is given by inspiration of God, and is profitable for doctrine, for reproof, for correction, for instruction in righteousness:

2 Timothy 3:17 That the man of God may be perfect, throughly furnished unto all good works.
