# Galatians 1

Galatians 1 (summary): Preachers of false gospels are accursed—Paul received the gospel by revelation—He believed, was taught, and preached to the Gentiles.

Galatians 1:1 Paul, an apostle, (not of men, neither by man, but by Jesus Christ, and God the Father, who raised him from the dead;)

Galatians 1:2 And all the brethren which are with me, unto the churches of Galatia:

Galatians 1:3 Grace be to you and peace from God the Father, and from our Lord Jesus Christ,

Galatians 1:4 Who gave himself for our sins, that he might deliver us from this present evil world, according to the will of God and our Father:

Galatians 1:5 To whom be glory for ever and ever. Amen.

Galatians 1:6 I marvel that ye are so soon removed from him that called you into the grace of Christ unto another gospel:

Galatians 1:7 Which is not another; but there be some that trouble you, and would pervert the gospel of Christ.

Galatians 1:8 But though we, or an angel from heaven, preach any other gospel unto you than that which we have preached unto you, let him be accursed.

Galatians 1:9 As we said before, so say I now again, If any man preach any other gospel unto you than that ye have received, let him be accursed.

Galatians 1:10 For do I now persuade men, or God? or do I seek to please men? for if I yet pleased men, I should not be the servant of Christ.

Galatians 1:11 But I certify you, brethren, that the gospel which was preached of me is not after man.

Galatians 1:12 For I neither received it of man, neither was I taught it, but by the revelation of Jesus Christ.

Galatians 1:13 For ye have heard of my conversation in time past in the Jews’ religion, how that beyond measure I persecuted the church of God, and wasted it:

Galatians 1:14 And profited in the Jews’ religion above many my equals in mine own nation, being more exceedingly zealous of the traditions of my fathers.

Galatians 1:15 But when it pleased God, who separated me from my mother’s womb, and called me by his grace,

Galatians 1:16 To reveal his Son in me, that I might preach him among the heathen; immediately I conferred not with flesh and blood:

Galatians 1:17 Neither went I up to Jerusalem to them which were apostles before me; but I went into Arabia, and returned again unto Damascus.

Galatians 1:18 Then after three years I went up to Jerusalem to see Peter, and abode with him fifteen days.

Galatians 1:19 But other of the apostles saw I none, save James the Lord’s brother.

Galatians 1:20 Now the things which I write unto you, behold, before God, I lie not.

Galatians 1:21 Afterwards I came into the regions of Syria and Cilicia;

Galatians 1:22 And was unknown by face unto the churches of Judæa which were in Christ:

Galatians 1:23 But they had heard only, That he which persecuted us in times past now preacheth the faith which once he destroyed.

Galatians 1:24 And they glorified God in me.
