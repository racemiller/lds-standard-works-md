# Mark 5

Mark 5 (summary): Jesus casts out a legion of devils, who then enter the swine—A woman is healed by touching Jesus’ clothes—He raises Jairus’s daughter from the dead.

Mark 5:1 And they came over unto the other side of the sea, into the country of the Gadarenes.

Mark 5:2 And when he was come out of the ship, immediately there met him out of the tombs a man with an unclean spirit,

Mark 5:3 Who had his dwelling among the tombs; and no man could bind him, no, not with chains:

Mark 5:4 Because that he had been often bound with fetters and chains, and the chains had been plucked asunder by him, and the fetters broken in pieces: neither could any man tame him.

Mark 5:5 And always, night and day, he was in the mountains, and in the tombs, crying, and cutting himself with stones.

Mark 5:6 But when he saw Jesus afar off, he ran and worshipped him,

Mark 5:7 And cried with a loud voice, and said, What have I to do with thee, Jesus, thou Son of the most high God? I adjure thee by God, that thou torment me not.

Mark 5:8 For he said unto him, Come out of the man, thou unclean spirit.

Mark 5:9 And he asked him, What is thy name? And he answered, saying, My name is Legion: for we are many.

Mark 5:10 And he besought him much that he would not send them away out of the country.

Mark 5:11 Now there was there nigh unto the mountains a great herd of swine feeding.

Mark 5:12 And all the devils besought him, saying, Send us into the swine, that we may enter into them.

Mark 5:13 And forthwith Jesus gave them leave. And the unclean spirits went out, and entered into the swine: and the herd ran violently down a steep place into the sea, (they were about two thousand;) and were choked in the sea.

Mark 5:14 And they that fed the swine fled, and told it in the city, and in the country. And they went out to see what it was that was done.

Mark 5:15 And they come to Jesus, and see him that was possessed with the devil, and had the legion, sitting, and clothed, and in his right mind: and they were afraid.

Mark 5:16 And they that saw it told them how it befell to him that was possessed with the devil, and also concerning the swine.

Mark 5:17 And they began to pray him to depart out of their coasts.

Mark 5:18 And when he was come into the ship, he that had been possessed with the devil prayed him that he might be with him.

Mark 5:19 Howbeit Jesus suffered him not, but saith unto him, Go home to thy friends, and tell them how great things the Lord hath done for thee, and hath had compassion on thee.

Mark 5:20 And he departed, and began to publish in Decapolis how great things Jesus had done for him: and all men did marvel.

Mark 5:21 And when Jesus was passed over again by ship unto the other side, much people gathered unto him: and he was nigh unto the sea.

Mark 5:22 And, behold, there cometh one of the rulers of the synagogue, Jairus by name; and when he saw him, he fell at his feet,

Mark 5:23 And besought him greatly, saying, My little daughter lieth at the point of death: I pray thee, come and lay thy hands on her, that she may be healed; and she shall live.

Mark 5:24 And Jesus went with him; and much people followed him, and thronged him.

Mark 5:25 And a certain woman, which had an issue of blood twelve years,

Mark 5:26 And had suffered many things of many physicians, and had spent all that she had, and was nothing bettered, but rather grew worse,

Mark 5:27 When she had heard of Jesus, came in the press behind, and touched his garment.

Mark 5:28 For she said, If I may touch but his clothes, I shall be whole.

Mark 5:29 And straightway the fountain of her blood was dried up; and she felt in her body that she was healed of that plague.

Mark 5:30 And Jesus, immediately knowing in himself that virtue had gone out of him, turned him about in the press, and said, Who touched my clothes?

Mark 5:31 And his disciples said unto him, Thou seest the multitude thronging thee, and sayest thou, Who touched me?

Mark 5:32 And he looked round about to see her that had done this thing.

Mark 5:33 But the woman fearing and trembling, knowing what was done in her, came and fell down before him, and told him all the truth.

Mark 5:34 And he said unto her, Daughter, thy faith hath made thee whole; go in peace, and be whole of thy plague.

Mark 5:35 While he yet spake, there came from the ruler of the synagogue’s house certain which said, Thy daughter is dead: why troublest thou the Master any further?

Mark 5:36 As soon as Jesus heard the word that was spoken, he saith unto the ruler of the synagogue, Be not afraid, only believe.

Mark 5:37 And he suffered no man to follow him, save Peter, and James, and John the brother of James.

Mark 5:38 And he cometh to the house of the ruler of the synagogue, and seeth the tumult, and them that wept and wailed greatly.

Mark 5:39 And when he was come in, he saith unto them, Why make ye this ado, and weep? the damsel is not dead, but sleepeth.

Mark 5:40 And they laughed him to scorn. But when he had put them all out, he taketh the father and the mother of the damsel, and them that were with him, and entereth in where the damsel was lying.

Mark 5:41 And he took the damsel by the hand, and said unto her, Talitha cumi; which is, being interpreted, Damsel, I say unto thee, arise.

Mark 5:42 And straightway the damsel arose, and walked; for she was of the age of twelve years. And they were astonished with a great astonishment.

Mark 5:43 And he charged them straitly that no man should know it; and commanded that something should be given her to eat.
