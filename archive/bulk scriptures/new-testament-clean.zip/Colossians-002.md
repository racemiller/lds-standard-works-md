# Colossians 2

Colossians 2 (summary): The fulness of the Godhead dwells in Christ—Beware of being deceived by the traditions of men—The handwriting against us was nailed to the cross of Christ.

Colossians 2:1 For I would that ye knew what great conflict I have for you, and for them at Laodicea, and for as many as have not seen my face in the flesh;

Colossians 2:2 That their hearts might be comforted, being knit together in love, and unto all riches of the full assurance of understanding, to the acknowledgement of the mystery of God, and of the Father, and of Christ;

Colossians 2:3 In whom are hid all the treasures of wisdom and knowledge.

Colossians 2:4 And this I say, lest any man should beguile you with enticing words.

Colossians 2:5 For though I be absent in the flesh, yet am I with you in the spirit, joying and beholding your order, and the steadfastness of your faith in Christ.

Colossians 2:6 As ye have therefore received Christ Jesus the Lord, so walk ye in him:

Colossians 2:7 Rooted and built up in him, and stablished in the faith, as ye have been taught, abounding therein with thanksgiving.

Colossians 2:8 Beware lest any man spoil you through philosophy and vain deceit, after the tradition of men, after the rudiments of the world, and not after Christ.

Colossians 2:9 For in him dwelleth all the fulness of the Godhead bodily.

Colossians 2:10 And ye are complete in him, which is the head of all principality and power:

Colossians 2:11 In whom also ye are circumcised with the circumcision made without hands, in putting off the body of the sins of the flesh by the circumcision of Christ:

Colossians 2:12 Buried with him in baptism, wherein also ye are risen with him through the faith of the operation of God, who hath raised him from the dead.

Colossians 2:13 And you, being dead in your sins and the uncircumcision of your flesh, hath he quickened together with him, having forgiven you all trespasses;

Colossians 2:14 Blotting out the handwriting of ordinances that was against us, which was contrary to us, and took it out of the way, nailing it to his cross;

Colossians 2:15 And having spoiled principalities and powers, he made a shew of them openly, triumphing over them in it.

Colossians 2:16 Let no man therefore judge you in meat, or in drink, or in respect of an holyday, or of the new moon, or of the sabbath days:

Colossians 2:17 Which are a shadow of things to come; but the body is of Christ.

Colossians 2:18 Let no man beguile you of your reward in a voluntary humility and worshipping of angels, intruding into those things which he hath not seen, vainly puffed up by his fleshly mind,

Colossians 2:19 And not holding the Head, from which all the body by joints and bands having nourishment ministered, and knit together, increaseth with the increase of God.

Colossians 2:20 Wherefore if ye be dead with Christ from the rudiments of the world, why, as though living in the world, are ye subject to ordinances,

Colossians 2:21 (Touch not; taste not; handle not;

Colossians 2:22 Which all are to perish with the using;) after the commandments and doctrines of men?

Colossians 2:23 Which things have indeed a shew of wisdom in will worship, and humility, and neglecting of the body; not in any honour to the satisfying of the flesh.
