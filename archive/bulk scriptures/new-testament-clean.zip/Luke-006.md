# Luke 6

Luke 6 (summary): Jesus heals on the Sabbath—He chooses the Twelve Apostles—He pronounces blessings upon the obedient and woes upon the wicked.

Luke 6:1 And it came to pass on the second sabbath after the first, that he went through the corn fields; and his disciples plucked the ears of corn, and did eat, rubbing them in their hands.

Luke 6:2 And certain of the Pharisees said unto them, Why do ye that which is not lawful to do on the sabbath days?

Luke 6:3 And Jesus answering them said, Have ye not read so much as this, what David did, when himself was an hungred, and they which were with him;

Luke 6:4 How he went into the house of God, and did take and eat the shewbread, and gave also to them that were with him; which it is not lawful to eat but for the priests alone?

Luke 6:5 And he said unto them, That the Son of man is Lord also of the sabbath.

Luke 6:6 And it came to pass also on another sabbath, that he entered into the synagogue and taught: and there was a man whose right hand was withered.

Luke 6:7 And the scribes and Pharisees watched him, whether he would heal on the sabbath day; that they might find an accusation against him.

Luke 6:8 But he knew their thoughts, and said to the man which had the withered hand, Rise up, and stand forth in the midst. And he arose and stood forth.

Luke 6:9 Then said Jesus unto them, I will ask you one thing; Is it lawful on the sabbath days to do good, or to do evil? to save life, or to destroy it?

Luke 6:10 And looking round about upon them all, he said unto the man, Stretch forth thy hand. And he did so: and his hand was restored whole as the other.

Luke 6:11 And they were filled with madness; and communed one with another what they might do to Jesus.

Luke 6:12 And it came to pass in those days, that he went out into a mountain to pray, and continued all night in prayer to God.

Luke 6:13 And when it was day, he called unto him his disciples: and of them he chose twelve, whom also he named apostles;

Luke 6:14 Simon, (whom he also named Peter,) and Andrew his brother, James and John, Philip and Bartholomew,

Luke 6:15 Matthew and Thomas, James the son of Alphæus, and Simon called Zelotes,

Luke 6:16 And Judas the brother of James, and Judas Iscariot, which also was the traitor.

Luke 6:17 And he came down with them, and stood in the plain, and the company of his disciples, and a great multitude of people out of all Judæa and Jerusalem, and from the sea coast of Tyre and Sidon, which came to hear him, and to be healed of their diseases;

Luke 6:18 And they that were vexed with unclean spirits: and they were healed.

Luke 6:19 And the whole multitude sought to touch him: for there went virtue out of him, and healed them all.

Luke 6:20 And he lifted up his eyes on his disciples, and said, Blessed be ye poor: for yours is the kingdom of God.

Luke 6:21 Blessed are ye that hunger now: for ye shall be filled. Blessed are ye that weep now: for ye shall laugh.

Luke 6:22 Blessed are ye, when men shall hate you, and when they shall separate you from their company, and shall reproach you, and cast out your name as evil, for the Son of man’s sake.

Luke 6:23 Rejoice ye in that day, and leap for joy: for, behold, your reward is great in heaven: for in the like manner did their fathers unto the prophets.

Luke 6:24 But woe unto you that are rich! for ye have received your consolation.

Luke 6:25 Woe unto you that are full! for ye shall hunger. Woe unto you that laugh now! for ye shall mourn and weep.

Luke 6:26 Woe unto you, when all men shall speak well of you! for so did their fathers to the false prophets.

Luke 6:27 But I say unto you which hear, Love your enemies, do good to them which hate you,

Luke 6:28 Bless them that curse you, and pray for them which despitefully use you.

Luke 6:29 And unto him that smiteth thee on the one cheek offer also the other; and him that taketh away thy cloak forbid not to take thy coat also.

Luke 6:30 Give to every man that asketh of thee; and of him that taketh away thy goods ask them not again.

Luke 6:31 And as ye would that men should do to you, do ye also to them likewise.

Luke 6:32 For if ye love them which love you, what thank have ye? for sinners also love those that love them.

Luke 6:33 And if ye do good to them which do good to you, what thank have ye? for sinners also do even the same.

Luke 6:34 And if ye lend to them of whom ye hope to receive, what thank have ye? for sinners also lend to sinners, to receive as much again.

Luke 6:35 But love ye your enemies, and do good, and lend, hoping for nothing again; and your reward shall be great, and ye shall be the children of the Highest: for he is kind unto the unthankful and to the evil.

Luke 6:36 Be ye therefore merciful, as your Father also is merciful.

Luke 6:37 Judge not, and ye shall not be judged: condemn not, and ye shall not be condemned: forgive, and ye shall be forgiven:

Luke 6:38 Give, and it shall be given unto you; good measure, pressed down, and shaken together, and running over, shall men give into your bosom. For with the same measure that ye mete withal it shall be measured to you again.

Luke 6:39 And he spake a parable unto them, Can the blind lead the blind? shall they not both fall into the ditch?

Luke 6:40 The disciple is not above his master: but every one that is perfect shall be as his master.

Luke 6:41 And why beholdest thou the mote that is in thy brother’s eye, but perceivest not the beam that is in thine own eye?

Luke 6:42 Either how canst thou say to thy brother, Brother, let me pull out the mote that is in thine eye, when thou thyself beholdest not the beam that is in thine own eye? Thou hypocrite, cast out first the beam out of thine own eye, and then shalt thou see clearly to pull out the mote that is in thy brother’s eye.

Luke 6:43 For a good tree bringeth not forth corrupt fruit; neither doth a corrupt tree bring forth good fruit.

Luke 6:44 For every tree is known by his own fruit. For of thorns men do not gather figs, nor of a bramble bush gather they grapes.

Luke 6:45 A good man out of the good treasure of his heart bringeth forth that which is good; and an evil man out of the evil treasure of his heart bringeth forth that which is evil: for of the abundance of the heart his mouth speaketh.

Luke 6:46 And why call ye me, Lord, Lord, and do not the things which I say?

Luke 6:47 Whosoever cometh to me, and heareth my sayings, and doeth them, I will shew you to whom he is like:

Luke 6:48 He is like a man which built an house, and digged deep, and laid the foundation on a rock: and when the flood arose, the stream beat vehemently upon that house, and could not shake it: for it was founded upon a rock.

Luke 6:49 But he that heareth, and doeth not, is like a man that without a foundation built an house upon the earth; against which the stream did beat vehemently, and immediately it fell; and the ruin of that house was great.
