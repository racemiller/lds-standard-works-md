# 1 Timothy 3

1 Timothy 3 (summary): Qualifications are given for bishops and deacons—Great is the mystery of godliness.

1 Timothy 3:1 This is a true saying, If a man desire the office of a bishop, he desireth a good work.

1 Timothy 3:2 A bishop then must be blameless, the husband of one wife, vigilant, sober, of good behaviour, given to hospitality, apt to teach;

1 Timothy 3:3 Not given to wine, no striker, not greedy of filthy lucre; but patient, not a brawler, not covetous;

1 Timothy 3:4 One that ruleth well his own house, having his children in subjection with all gravity;

1 Timothy 3:5 (For if a man know not how to rule his own house, how shall he take care of the church of God?)

1 Timothy 3:6 Not a novice, lest being lifted up with pride he fall into the condemnation of the devil.

1 Timothy 3:7 Moreover he must have a good report of them which are without; lest he fall into reproach and the snare of the devil.

1 Timothy 3:8 Likewise must the deacons be grave, not doubletongued, not given to much wine, not greedy of filthy lucre;

1 Timothy 3:9 Holding the mystery of the faith in a pure conscience.

1 Timothy 3:10 And let these also first be proved; then let them use the office of a deacon, being found blameless.

1 Timothy 3:11 Even so must their wives be grave, not slanderers, sober, faithful in all things.

1 Timothy 3:12 Let the deacons be the husbands of one wife, ruling their children and their own houses well.

1 Timothy 3:13 For they that have used the office of a deacon well purchase to themselves a good degree, and great boldness in the faith which is in Christ Jesus.

1 Timothy 3:14 These things write I unto thee, hoping to come unto thee shortly:

1 Timothy 3:15 But if I tarry long, that thou mayest know how thou oughtest to behave thyself in the house of God, which is the church of the living God, the pillar and ground of the truth.

1 Timothy 3:16 And without controversy great is the mystery of godliness: God was manifest in the flesh, justified in the Spirit, seen of angels, preached unto the Gentiles, believed on in the world, received up into glory.
