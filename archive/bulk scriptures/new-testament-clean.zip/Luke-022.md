# Luke 22

Luke 22 (summary): Jesus institutes the sacrament—He suffers in Gethsemane and is betrayed and arrested—Peter denies knowing Him—Jesus is smitten and mocked.

Luke 22:1 Now the feast of unleavened bread drew nigh, which is called the Passover.

Luke 22:2 And the chief priests and scribes sought how they might kill him; for they feared the people.

Luke 22:3 Then entered Satan into Judas surnamed Iscariot, being of the number of the twelve.

Luke 22:4 And he went his way, and communed with the chief priests and captains, how he might betray him unto them.

Luke 22:5 And they were glad, and covenanted to give him money.

Luke 22:6 And he promised, and sought opportunity to betray him unto them in the absence of the multitude.

Luke 22:7 Then came the day of unleavened bread, when the passover must be killed.

Luke 22:8 And he sent Peter and John, saying, Go and prepare us the passover, that we may eat.

Luke 22:9 And they said unto him, Where wilt thou that we prepare?

Luke 22:10 And he said unto them, Behold, when ye are entered into the city, there shall a man meet you, bearing a pitcher of water; follow him into the house where he entereth in.

Luke 22:11 And ye shall say unto the goodman of the house, The Master saith unto thee, Where is the guestchamber, where I shall eat the passover with my disciples?

Luke 22:12 And he shall shew you a large upper room furnished: there make ready.

Luke 22:13 And they went, and found as he had said unto them: and they made ready the passover.

Luke 22:14 And when the hour was come, he sat down, and the twelve apostles with him.

Luke 22:15 And he said unto them, With desire I have desired to eat this passover with you before I suffer:

Luke 22:16 For I say unto you, I will not any more eat thereof, until it be fulfilled in the kingdom of God.

Luke 22:17 And he took the cup, and gave thanks, and said, Take this, and divide it among yourselves:

Luke 22:18 For I say unto you, I will not drink of the fruit of the vine, until the kingdom of God shall come.

Luke 22:19 And he took bread, and gave thanks, and brake it, and gave unto them, saying, This is my body which is given for you: this do in remembrance of me.

Luke 22:20 Likewise also the cup after supper, saying, This cup is the new testament in my blood, which is shed for you.

Luke 22:21 But, behold, the hand of him that betrayeth me is with me on the table.

Luke 22:22 And truly the Son of man goeth, as it was determined: but woe unto that man by whom he is betrayed!

Luke 22:23 And they began to inquire among themselves, which of them it was that should do this thing.

Luke 22:24 And there was also a strife among them, which of them should be accounted the greatest.

Luke 22:25 And he said unto them, The kings of the Gentiles exercise lordship over them; and they that exercise authority upon them are called benefactors.

Luke 22:26 But ye shall not be so: but he that is greatest among you, let him be as the younger; and he that is chief, as he that doth serve.

Luke 22:27 For whether is greater, he that sitteth at meat, or he that serveth? is not he that sitteth at meat? but I am among you as he that serveth.

Luke 22:28 Ye are they which have continued with me in my temptations.

Luke 22:29 And I appoint unto you a kingdom, as my Father hath appointed unto me;

Luke 22:30 That ye may eat and drink at my table in my kingdom, and sit on thrones judging the twelve tribes of Israel.

Luke 22:31 And the Lord said, Simon, Simon, behold, Satan hath desired to have you, that he may sift you as wheat:

Luke 22:32 But I have prayed for thee, that thy faith fail not: and when thou art converted, strengthen thy brethren.

Luke 22:33 And he said unto him, Lord, I am ready to go with thee, both into prison, and to death.

Luke 22:34 And he said, I tell thee, Peter, the cock shall not crow this day, before that thou shalt thrice deny that thou knowest me.

Luke 22:35 And he said unto them, When I sent you without purse, and scrip, and shoes, lacked ye any thing? And they said, Nothing.

Luke 22:36 Then said he unto them, But now, he that hath a purse, let him take it, and likewise his scrip: and he that hath no sword, let him sell his garment, and buy one.

Luke 22:37 For I say unto you, that this that is written must yet be accomplished in me, And he was reckoned among the transgressors: for the things concerning me have an end.

Luke 22:38 And they said, Lord, behold, here are two swords. And he said unto them, It is enough.

Luke 22:39 And he came out, and went, as he was wont, to the mount of Olives; and his disciples also followed him.

Luke 22:40 And when he was at the place, he said unto them, Pray that ye enter not into temptation.

Luke 22:41 And he was withdrawn from them about a stone’s cast, and kneeled down, and prayed,

Luke 22:42 Saying, Father, if thou be willing, remove this cup from me: nevertheless not my will, but thine, be done.

Luke 22:43 And there appeared an angel unto him from heaven, strengthening him.

Luke 22:44 And being in an agony he prayed more earnestly: and his sweat was as it were great drops of blood falling down to the ground.

Luke 22:45 And when he rose up from prayer, and was come to his disciples, he found them sleeping for sorrow,

Luke 22:46 And said unto them, Why sleep ye? rise and pray, lest ye enter into temptation.

Luke 22:47 And while he yet spake, behold a multitude, and he that was called Judas, one of the twelve, went before them, and drew near unto Jesus to kiss him.

Luke 22:48 But Jesus said unto him, Judas, betrayest thou the Son of man with a kiss?

Luke 22:49 When they which were about him saw what would follow, they said unto him, Lord, shall we smite with the sword?

Luke 22:50 And one of them smote the servant of the high priest, and cut off his right ear.

Luke 22:51 And Jesus answered and said, Suffer ye thus far. And he touched his ear, and healed him.

Luke 22:52 Then Jesus said unto the chief priests, and captains of the temple, and the elders, which were come to him, Be ye come out, as against a thief, with swords and staves?

Luke 22:53 When I was daily with you in the temple, ye stretched forth no hands against me: but this is your hour, and the power of darkness.

Luke 22:54 Then took they him, and led him, and brought him into the high priest’s house. And Peter followed afar off.

Luke 22:55 And when they had kindled a fire in the midst of the hall, and were set down together, Peter sat down among them.

Luke 22:56 But a certain maid beheld him as he sat by the fire, and earnestly looked upon him, and said, This man was also with him.

Luke 22:57 And he denied him, saying, Woman, I know him not.

Luke 22:58 And after a little while another saw him, and said, Thou art also of them. And Peter said, Man, I am not.

Luke 22:59 And about the space of one hour after another confidently affirmed, saying, Of a truth this fellow also was with him: for he is a Galilæan.

Luke 22:60 And Peter said, Man, I know not what thou sayest. And immediately, while he yet spake, the cock crew.

Luke 22:61 And the Lord turned, and looked upon Peter. And Peter remembered the word of the Lord, how he had said unto him, Before the cock crow, thou shalt deny me thrice.

Luke 22:62 And Peter went out, and wept bitterly.

Luke 22:63 And the men that held Jesus mocked him, and smote him.

Luke 22:64 And when they had blindfolded him, they struck him on the face, and asked him, saying, Prophesy, who is it that smote thee?

Luke 22:65 And many other things blasphemously spake they against him.

Luke 22:66 And as soon as it was day, the elders of the people and the chief priests and the scribes came together, and led him into their council, saying,

Luke 22:67 Art thou the Christ? tell us. And he said unto them, If I tell you, ye will not believe:

Luke 22:68 And if I also ask you, ye will not answer me, nor let me go.

Luke 22:69 Hereafter shall the Son of man sit on the right hand of the power of God.

Luke 22:70 Then said they all, Art thou then the Son of God? And he said unto them, Ye say that I am.

Luke 22:71 And they said, What need we any further witness? for we ourselves have heard of his own mouth.
