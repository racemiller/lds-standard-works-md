# Mark 6

Mark 6 (summary): Jesus sends forth the Twelve—John the Baptist is beheaded by Herod—Our Lord feeds the five thousand, walks on the water, and heals multitudes.

Mark 6:1 And he went out from thence, and came into his own country; and his disciples follow him.

Mark 6:2 And when the sabbath day was come, he began to teach in the synagogue: and many hearing him were astonished, saying, From whence hath this man these things? and what wisdom is this which is given unto him, that even such mighty works are wrought by his hands?

Mark 6:3 Is not this the carpenter, the son of Mary, the brother of James, and Joses, and of Juda, and Simon? and are not his sisters here with us? And they were offended at him.

Mark 6:4 But Jesus said unto them, A prophet is not without honour, but in his own country, and among his own kin, and in his own house.

Mark 6:5 And he could there do no mighty work, save that he laid his hands upon a few sick folk, and healed them.

Mark 6:6 And he marvelled because of their unbelief. And he went round about the villages, teaching.

Mark 6:7 And he called unto him the twelve, and began to send them forth by two and two; and gave them power over unclean spirits;

Mark 6:8 And commanded them that they should take nothing for their journey, save a staff only; no scrip, no bread, no money in their purse:

Mark 6:9 But be shod with sandals; and not put on two coats.

Mark 6:10 And he said unto them, In what place soever ye enter into an house, there abide till ye depart from that place.

Mark 6:11 And whosoever shall not receive you, nor hear you, when ye depart thence, shake off the dust under your feet for a testimony against them. Verily I say unto you, It shall be more tolerable for Sodom and Gomorrha in the day of judgment, than for that city.

Mark 6:12 And they went out, and preached that men should repent.

Mark 6:13 And they cast out many devils, and anointed with oil many that were sick, and healed them.

Mark 6:14 And king Herod heard of him; (for his name was spread abroad:) and he said, That John the Baptist was risen from the dead, and therefore mighty works do shew forth themselves in him.

Mark 6:15 Others said, That it is Elias. And others said, That it is a prophet, or as one of the prophets.

Mark 6:16 But when Herod heard thereof, he said, It is John, whom I beheaded: he is risen from the dead.

Mark 6:17 For Herod himself had sent forth and laid hold upon John, and bound him in prison for Herodias’ sake, his brother Philip’s wife: for he had married her.

Mark 6:18 For John had said unto Herod, It is not lawful for thee to have thy brother’s wife.

Mark 6:19 Therefore Herodias had a quarrel against him, and would have killed him; but she could not:

Mark 6:20 For Herod feared John, knowing that he was a just man and an holy, and observed him; and when he heard him, he did many things, and heard him gladly.

Mark 6:21 And when a convenient day was come, that Herod on his birthday made a supper to his lords, high captains, and chief estates of Galilee;

Mark 6:22 And when the daughter of the said Herodias came in, and danced, and pleased Herod and them that sat with him, the king said unto the damsel, Ask of me whatsoever thou wilt, and I will give it thee.

Mark 6:23 And he sware unto her, Whatsoever thou shalt ask of me, I will give it thee, unto the half of my kingdom.

Mark 6:24 And she went forth, and said unto her mother, What shall I ask? And she said, The head of John the Baptist.

Mark 6:25 And she came in straightway with haste unto the king, and asked, saying, I will that thou give me by and by in a charger the head of John the Baptist.

Mark 6:26 And the king was exceeding sorry; yet for his oath’s sake, and for their sakes which sat with him, he would not reject her.

Mark 6:27 And immediately the king sent an executioner, and commanded his head to be brought: and he went and beheaded him in the prison,

Mark 6:28 And brought his head in a charger, and gave it to the damsel: and the damsel gave it to her mother.

Mark 6:29 And when his disciples heard of it, they came and took up his corpse, and laid it in a tomb.

Mark 6:30 And the apostles gathered themselves together unto Jesus, and told him all things, both what they had done, and what they had taught.

Mark 6:31 And he said unto them, Come ye yourselves apart into a desert place, and rest a while: for there were many coming and going, and they had no leisure so much as to eat.

Mark 6:32 And they departed into a desert place by ship privately.

Mark 6:33 And the people saw them departing, and many knew him, and ran afoot thither out of all cities, and outwent them, and came together unto him.

Mark 6:34 And Jesus, when he came out, saw much people, and was moved with compassion toward them, because they were as sheep not having a shepherd: and he began to teach them many things.

Mark 6:35 And when the day was now far spent, his disciples came unto him, and said, This is a desert place, and now the time is far passed:

Mark 6:36 Send them away, that they may go into the country round about, and into the villages, and buy themselves bread: for they have nothing to eat.

Mark 6:37 He answered and said unto them, Give ye them to eat. And they say unto him, Shall we go and buy two hundred pennyworth of bread, and give them to eat?

Mark 6:38 He saith unto them, How many loaves have ye? go and see. And when they knew, they say, Five, and two fishes.

Mark 6:39 And he commanded them to make all sit down by companies upon the green grass.

Mark 6:40 And they sat down in ranks, by hundreds, and by fifties.

Mark 6:41 And when he had taken the five loaves and the two fishes, he looked up to heaven, and blessed, and brake the loaves, and gave them to his disciples to set before them; and the two fishes divided he among them all.

Mark 6:42 And they did all eat, and were filled.

Mark 6:43 And they took up twelve baskets full of the fragments, and of the fishes.

Mark 6:44 And they that did eat of the loaves were about five thousand men.

Mark 6:45 And straightway he constrained his disciples to get into the ship, and to go to the other side before unto Bethsaida, while he sent away the people.

Mark 6:46 And when he had sent them away, he departed into a mountain to pray.

Mark 6:47 And when even was come, the ship was in the midst of the sea, and he alone on the land.

Mark 6:48 And he saw them toiling in rowing; for the wind was contrary unto them: and about the fourth watch of the night he cometh unto them, walking upon the sea, and would have passed by them.

Mark 6:49 But when they saw him walking upon the sea, they supposed it had been a spirit, and cried out:

Mark 6:50 For they all saw him, and were troubled. And immediately he talked with them, and saith unto them, Be of good cheer: it is I; be not afraid.

Mark 6:51 And he went up unto them into the ship; and the wind ceased: and they were sore amazed in themselves beyond measure, and wondered.

Mark 6:52 For they considered not the miracle of the loaves: for their heart was hardened.

Mark 6:53 And when they had passed over, they came into the land of Gennesaret, and drew to the shore.

Mark 6:54 And when they were come out of the ship, straightway they knew him,

Mark 6:55 And ran through that whole region round about, and began to carry about in beds those that were sick, where they heard he was.

Mark 6:56 And whithersoever he entered, into villages, or cities, or country, they laid the sick in the streets, and besought him that they might touch if it were but the border of his garment: and as many as touched him were made whole.
