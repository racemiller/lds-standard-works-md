# 2 Corinthians 10

2 Corinthians 10 (summary): Bring every thought into obedience—Paul glories in the Lord.

2 Corinthians 10:1 Now I Paul myself beseech you by the meekness and gentleness of Christ, who in presence am base among you, but being absent am bold toward you:

2 Corinthians 10:2 But I beseech you, that I may not be bold when I am present with that confidence, wherewith I think to be bold against some, which think of us as if we walked according to the flesh.

2 Corinthians 10:3 For though we walk in the flesh, we do not war after the flesh:

2 Corinthians 10:4 (For the weapons of our warfare are not carnal, but mighty through God to the pulling down of strong holds;)

2 Corinthians 10:5 Casting down imaginations, and every high thing that exalteth itself against the knowledge of God, and bringing into captivity every thought to the obedience of Christ;

2 Corinthians 10:6 And having in a readiness to revenge all disobedience, when your obedience is fulfilled.

2 Corinthians 10:7 Do ye look on things after the outward appearance? If any man trust to himself that he is Christ’s, let him of himself think this again, that, as he is Christ’s, even so are we Christ’s.

2 Corinthians 10:8 For though I should boast somewhat more of our authority, which the Lord hath given us for edification, and not for your destruction, I should not be ashamed:

2 Corinthians 10:9 That I may not seem as if I would terrify you by letters.

2 Corinthians 10:10 For his letters, say they, are weighty and powerful; but his bodily presence is weak, and his speech contemptible.

2 Corinthians 10:11 Let such an one think this, that, such as we are in word by letters when we are absent, such will we be also in deed when we are present.

2 Corinthians 10:12 For we dare not make ourselves of the number, or compare ourselves with some that commend themselves: but they measuring themselves by themselves, and comparing themselves among themselves, are not wise.

2 Corinthians 10:13 But we will not boast of things without our measure, but according to the measure of the rule which God hath distributed to us, a measure to reach even unto you.

2 Corinthians 10:14 For we stretch not ourselves beyond our measure, as though we reached not unto you: for we are come as far as to you also in preaching the gospel of Christ:

2 Corinthians 10:15 Not boasting of things without our measure, that is, of other men’s labours; but having hope, when your faith is increased, that we shall be enlarged by you according to our rule abundantly,

2 Corinthians 10:16 To preach the gospel in the regions beyond you, and not to boast in another man’s line of things made ready to our hand.

2 Corinthians 10:17 But he that glorieth, let him glory in the Lord.

2 Corinthians 10:18 For not he that commendeth himself is approved, but whom the Lord commendeth.
