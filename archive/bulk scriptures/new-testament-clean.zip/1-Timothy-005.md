# 1 Timothy 5

1 Timothy 5 (summary): Saints are to care for their worthy poor—Policies concerning elders are given.

1 Timothy 5:1 Rebuke not an elder, but entreat him as a father; and the younger men as brethren;

1 Timothy 5:2 The elder women as mothers; the younger as sisters, with all purity.

1 Timothy 5:3 Honour widows that are widows indeed.

1 Timothy 5:4 But if any widow have children or nephews, let them learn first to shew piety at home, and to requite their parents: for that is good and acceptable before God.

1 Timothy 5:5 Now she that is a widow indeed, and desolate, trusteth in God, and continueth in supplications and prayers night and day.

1 Timothy 5:6 But she that liveth in pleasure is dead while she liveth.

1 Timothy 5:7 And these things give in charge, that they may be blameless.

1 Timothy 5:8 But if any provide not for his own, and specially for those of his own house, he hath denied the faith, and is worse than an infidel.

1 Timothy 5:9 Let not a widow be taken into the number under threescore years old, having been the wife of one man,

1 Timothy 5:10 Well reported of for good works; if she have brought up children, if she have lodged strangers, if she have washed the saints’ feet, if she have relieved the afflicted, if she have diligently followed every good work.

1 Timothy 5:11 But the younger widows refuse: for when they have begun to wax wanton against Christ, they will marry;

1 Timothy 5:12 Having damnation, because they have cast off their first faith.

1 Timothy 5:13 And withal they learn to be idle, wandering about from house to house; and not only idle, but tattlers also and busybodies, speaking things which they ought not.

1 Timothy 5:14 I will therefore that the younger women marry, bear children, guide the house, give none occasion to the adversary to speak reproachfully.

1 Timothy 5:15 For some are already turned aside after Satan.

1 Timothy 5:16 If any man or woman that believeth have widows, let them relieve them, and let not the church be charged; that it may relieve them that are widows indeed.

1 Timothy 5:17 Let the elders that rule well be counted worthy of double honour, especially they who labour in the word and doctrine.

1 Timothy 5:18 For the scripture saith, Thou shalt not muzzle the ox that treadeth out the corn. And, The labourer is worthy of his reward.

1 Timothy 5:19 Against an elder receive not an accusation, but before two or three witnesses.

1 Timothy 5:20 Them that sin rebuke before all, that others also may fear.

1 Timothy 5:21 I charge thee before God, and the Lord Jesus Christ, and the elect angels, that thou observe these things without preferring one before another, doing nothing by partiality.

1 Timothy 5:22 Lay hands suddenly on no man, neither be partaker of other men’s sins: keep thyself pure.

1 Timothy 5:23 Drink no longer water, but use a little wine for thy stomach’s sake and thine often infirmities.

1 Timothy 5:24 Some men’s sins are open beforehand, going before to judgment; and some men they follow after.

1 Timothy 5:25 Likewise also the good works of some are manifest beforehand; and they that are otherwise cannot be hid.
