# Romans 13

Romans 13 (summary): Paul counsels, Be subject unto God’s ministers; keep the commandments; love one another; righteousness leads to salvation.

Romans 13:1 Let every soul be subject unto the higher powers. For there is no power but of God: the powers that be are ordained of God.

Romans 13:2 Whosoever therefore resisteth the power, resisteth the ordinance of God: and they that resist shall receive to themselves damnation.

Romans 13:3 For rulers are not a terror to good works, but to the evil. Wilt thou then not be afraid of the power? do that which is good, and thou shalt have praise of the same:

Romans 13:4 For he is the minister of God to thee for good. But if thou do that which is evil, be afraid; for he beareth not the sword in vain: for he is the minister of God, a revenger to execute wrath upon him that doeth evil.

Romans 13:5 Wherefore ye must needs be subject, not only for wrath, but also for conscience sake.

Romans 13:6 For for this cause pay ye tribute also: for they are God’s ministers, attending continually upon this very thing.

Romans 13:7 Render therefore to all their dues: tribute to whom tribute is due; custom to whom custom; fear to whom fear; honour to whom honour.

Romans 13:8 Owe no man any thing, but to love one another: for he that loveth another hath fulfilled the law.

Romans 13:9 For this, Thou shalt not commit adultery, Thou shalt not kill, Thou shalt not steal, Thou shalt not bear false witness, Thou shalt not covet; and if there be any other commandment, it is briefly comprehended in this saying, namely, Thou shalt love thy neighbour as thyself.

Romans 13:10 Love worketh no ill to his neighbour: therefore love is the fulfilling of the law.

Romans 13:11 And that, knowing the time, that now it is high time to awake out of sleep: for now is our salvation nearer than when we believed.

Romans 13:12 The night is far spent, the day is at hand: let us therefore cast off the works of darkness, and let us put on the armour of light.

Romans 13:13 Let us walk honestly, as in the day; not in rioting and drunkenness, not in chambering and wantonness, not in strife and envying.

Romans 13:14 But put ye on the Lord Jesus Christ, and make not provision for the flesh, to fulfil the lusts thereof.
