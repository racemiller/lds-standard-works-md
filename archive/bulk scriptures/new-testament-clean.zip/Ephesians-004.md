# Ephesians 4

Ephesians 4 (summary): There is one Lord, one faith, and one baptism—Apostles and prophets are essential to the Church—The Saints are exhorted to live righteously—They are sealed unto the day of redemption.

Ephesians 4:1 I therefore, the prisoner of the Lord, beseech you that ye walk worthy of the vocation wherewith ye are called,

Ephesians 4:2 With all lowliness and meekness, with longsuffering, forbearing one another in love;

Ephesians 4:3 Endeavouring to keep the unity of the Spirit in the bond of peace.

Ephesians 4:4 There is one body, and one Spirit, even as ye are called in one hope of your calling;

Ephesians 4:5 One Lord, one faith, one baptism,

Ephesians 4:6 One God and Father of all, who is above all, and through all, and in you all.

Ephesians 4:7 But unto every one of us is given grace according to the measure of the gift of Christ.

Ephesians 4:8 Wherefore he saith, When he ascended up on high, he led captivity captive, and gave gifts unto men.

Ephesians 4:9 (Now that he ascended, what is it but that he also descended first into the lower parts of the earth?

Ephesians 4:10 He that descended is the same also that ascended up far above all heavens, that he might fill all things.)

Ephesians 4:11 And he gave some, apostles; and some, prophets; and some, evangelists; and some, pastors and teachers;

Ephesians 4:12 For the perfecting of the saints, for the work of the ministry, for the edifying of the body of Christ:

Ephesians 4:13 Till we all come in the unity of the faith, and of the knowledge of the Son of God, unto a perfect man, unto the measure of the stature of the fulness of Christ:

Ephesians 4:14 That we henceforth be no more children, tossed to and fro, and carried about with every wind of doctrine, by the sleight of men, and cunning craftiness, whereby they lie in wait to deceive;

Ephesians 4:15 But speaking the truth in love, may grow up into him in all things, which is the head, even Christ:

Ephesians 4:16 From whom the whole body fitly joined together and compacted by that which every joint supplieth, according to the effectual working in the measure of every part, maketh increase of the body unto the edifying of itself in love.

Ephesians 4:17 This I say therefore, and testify in the Lord, that ye henceforth walk not as other Gentiles walk, in the vanity of their mind,

Ephesians 4:18 Having the understanding darkened, being alienated from the life of God through the ignorance that is in them, because of the blindness of their heart:

Ephesians 4:19 Who being past feeling have given themselves over unto lasciviousness, to work all uncleanness with greediness.

Ephesians 4:20 But ye have not so learned Christ;

Ephesians 4:21 If so be that ye have heard him, and have been taught by him, as the truth is in Jesus:

Ephesians 4:22 That ye put off concerning the former conversation the old man, which is corrupt according to the deceitful lusts;

Ephesians 4:23 And be renewed in the spirit of your mind;

Ephesians 4:24 And that ye put on the new man, which after God is created in righteousness and true holiness.

Ephesians 4:25 Wherefore putting away lying, speak every man truth with his neighbour: for we are members one of another.

Ephesians 4:26 Be ye angry, and sin not: let not the sun go down upon your wrath:

Ephesians 4:27 Neither give place to the devil.

Ephesians 4:28 Let him that stole steal no more: but rather let him labour, working with his hands the thing which is good, that he may have to give to him that needeth.

Ephesians 4:29 Let no corrupt communication proceed out of your mouth, but that which is good to the use of edifying, that it may minister grace unto the hearers.

Ephesians 4:30 And grieve not the holy Spirit of God, whereby ye are sealed unto the day of redemption.

Ephesians 4:31 Let all bitterness, and wrath, and anger, and clamour, and evil speaking, be put away from you, with all malice:

Ephesians 4:32 And be ye kind one to another, tenderhearted, forgiving one another, even as God for Christ’s sake hath forgiven you.
