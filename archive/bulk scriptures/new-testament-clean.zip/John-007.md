# John 7

John 7 (summary): Jesus’ kinsmen do not believe—He teaches His Father’s doctrine and proclaims His divine sonship—Truth may be known through obedience—Jesus offers living water to all people—The people have various opinions concerning Him.

John 7:1 After these things Jesus walked in Galilee: for he would not walk in Jewry, because the Jews sought to kill him.

John 7:2 Now the Jews’ feast of tabernacles was at hand.

John 7:3 His brethren therefore said unto him, Depart hence, and go into Judæa, that thy disciples also may see the works that thou doest.

John 7:4 For there is no man that doeth any thing in secret, and he himself seeketh to be known openly. If thou do these things, shew thyself to the world.

John 7:5 For neither did his brethren believe in him.

John 7:6 Then Jesus said unto them, My time is not yet come: but your time is alway ready.

John 7:7 The world cannot hate you; but me it hateth, because I testify of it, that the works thereof are evil.

John 7:8 Go ye up unto this feast: I go not up yet unto this feast; for my time is not yet full come.

John 7:9 When he had said these words unto them, he abode still in Galilee.

John 7:10 But when his brethren were gone up, then went he also up unto the feast, not openly, but as it were in secret.

John 7:11 Then the Jews sought him at the feast, and said, Where is he?

John 7:12 And there was much murmuring among the people concerning him: for some said, He is a good man: others said, Nay; but he deceiveth the people.

John 7:13 Howbeit no man spake openly of him for fear of the Jews.

John 7:14 Now about the midst of the feast Jesus went up into the temple, and taught.

John 7:15 And the Jews marvelled, saying, How knoweth this man letters, having never learned?

John 7:16 Jesus answered them, and said, My doctrine is not mine, but his that sent me.

John 7:17 If any man will do his will, he shall know of the doctrine, whether it be of God, or whether I speak of myself.

John 7:18 He that speaketh of himself seeketh his own glory: but he that seeketh his glory that sent him, the same is true, and no unrighteousness is in him.

John 7:19 Did not Moses give you the law, and yet none of you keepeth the law? Why go ye about to kill me?

John 7:20 The people answered and said, Thou hast a devil: who goeth about to kill thee?

John 7:21 Jesus answered and said unto them, I have done one work, and ye all marvel.

John 7:22 Moses therefore gave unto you circumcision; (not because it is of Moses, but of the fathers;) and ye on the sabbath day circumcise a man.

John 7:23 If a man on the sabbath day receive circumcision, that the law of Moses should not be broken; are ye angry at me, because I have made a man every whit whole on the sabbath day?

John 7:24 Judge not according to the appearance, but judge righteous judgment.

John 7:25 Then said some of them of Jerusalem, Is not this he, whom they seek to kill?

John 7:26 But, lo, he speaketh boldly, and they say nothing unto him. Do the rulers know indeed that this is the very Christ?

John 7:27 Howbeit we know this man whence he is: but when Christ cometh, no man knoweth whence he is.

John 7:28 Then cried Jesus in the temple as he taught, saying, Ye both know me, and ye know whence I am: and I am not come of myself, but he that sent me is true, whom ye know not.

John 7:29 But I know him: for I am from him, and he hath sent me.

John 7:30 Then they sought to take him: but no man laid hands on him, because his hour was not yet come.

John 7:31 And many of the people believed on him, and said, When Christ cometh, will he do more miracles than these which this man hath done?

John 7:32 The Pharisees heard that the people murmured such things concerning him; and the Pharisees and the chief priests sent officers to take him.

John 7:33 Then said Jesus unto them, Yet a little while am I with you, and then I go unto him that sent me.

John 7:34 Ye shall seek me, and shall not find me: and where I am, thither ye cannot come.

John 7:35 Then said the Jews among themselves, Whither will he go, that we shall not find him? will he go unto the dispersed among the Gentiles, and teach the Gentiles?

John 7:36 What manner of saying is this that he said, Ye shall seek me, and shall not find me: and where I am, thither ye cannot come?

John 7:37 In the last day, that great day of the feast, Jesus stood and cried, saying, If any man thirst, let him come unto me, and drink.

John 7:38 He that believeth on me, as the scripture hath said, out of his belly shall flow rivers of living water.

John 7:39 (But this spake he of the Spirit, which they that believe on him should receive: for the Holy Ghost was not yet given; because that Jesus was not yet glorified.)

John 7:40 Many of the people therefore, when they heard this saying, said, Of a truth this is the Prophet.

John 7:41 Others said, This is the Christ. But some said, Shall Christ come out of Galilee?

John 7:42 Hath not the scripture said, That Christ cometh of the seed of David, and out of the town of Bethlehem, where David was?

John 7:43 So there was a division among the people because of him.

John 7:44 And some of them would have taken him; but no man laid hands on him.

John 7:45 Then came the officers to the chief priests and Pharisees; and they said unto them, Why have ye not brought him?

John 7:46 The officers answered, Never man spake like this man.

John 7:47 Then answered them the Pharisees, Are ye also deceived?

John 7:48 Have any of the rulers or of the Pharisees believed on him?

John 7:49 But this people who knoweth not the law are cursed.

John 7:50 Nicodemus saith unto them, (he that came to Jesus by night, being one of them,)

John 7:51 Doth our law judge any man, before it hear him, and know what he doeth?

John 7:52 They answered and said unto him, Art thou also of Galilee? Search, and look: for out of Galilee ariseth no prophet.

John 7:53 And every man went unto his own house.
