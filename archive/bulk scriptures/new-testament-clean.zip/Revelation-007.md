# Revelation 7

Revelation 7 (summary): John also sees in the sixth seal the Restoration of the gospel, the sealing of the 144,000, and the hosts of the exalted from all nations.

Revelation 7:1 And after these things I saw four angels standing on the four corners of the earth, holding the four winds of the earth, that the wind should not blow on the earth, nor on the sea, nor on any tree.

Revelation 7:2 And I saw another angel ascending from the east, having the seal of the living God: and he cried with a loud voice to the four angels, to whom it was given to hurt the earth and the sea,

Revelation 7:3 Saying, Hurt not the earth, neither the sea, nor the trees, till we have sealed the servants of our God in their foreheads.

Revelation 7:4 And I heard the number of them which were sealed: and there were sealed an hundred and forty and four thousand of all the tribes of the children of Israel.

Revelation 7:5 Of the tribe of Juda were sealed twelve thousand. Of the tribe of Reuben were sealed twelve thousand. Of the tribe of Gad were sealed twelve thousand.

Revelation 7:6 Of the tribe of Aser were sealed twelve thousand. Of the tribe of Nepthalim were sealed twelve thousand. Of the tribe of Manasses were sealed twelve thousand.

Revelation 7:7 Of the tribe of Simeon were sealed twelve thousand. Of the tribe of Levi were sealed twelve thousand. Of the tribe of Issachar were sealed twelve thousand.

Revelation 7:8 Of the tribe of Zabulon were sealed twelve thousand. Of the tribe of Joseph were sealed twelve thousand. Of the tribe of Benjamin were sealed twelve thousand.

Revelation 7:9 After this I beheld, and, lo, a great multitude, which no man could number, of all nations, and kindreds, and people, and tongues, stood before the throne, and before the Lamb, clothed with white robes, and palms in their hands;

Revelation 7:10 And cried with a loud voice, saying, Salvation to our God which sitteth upon the throne, and unto the Lamb.

Revelation 7:11 And all the angels stood round about the throne, and about the elders and the four beasts, and fell before the throne on their faces, and worshipped God,

Revelation 7:12 Saying, Amen: Blessing, and glory, and wisdom, and thanksgiving, and honour, and power, and might, be unto our God for ever and ever. Amen.

Revelation 7:13 And one of the elders answered, saying unto me, What are these which are arrayed in white robes? and whence came they?

Revelation 7:14 And I said unto him, Sir, thou knowest. And he said to me, These are they which came out of great tribulation, and have washed their robes, and made them white in the blood of the Lamb.

Revelation 7:15 Therefore are they before the throne of God, and serve him day and night in his temple: and he that sitteth on the throne shall dwell among them.

Revelation 7:16 They shall hunger no more, neither thirst any more; neither shall the sun light on them, nor any heat.

Revelation 7:17 For the Lamb which is in the midst of the throne shall feed them, and shall lead them unto living fountains of waters: and God shall wipe away all tears from their eyes.
