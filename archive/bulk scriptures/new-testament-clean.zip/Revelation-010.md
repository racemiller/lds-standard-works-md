# Revelation 10

Revelation 10 (summary): John seals up many things relative to the last days—He is commissioned to participate in the restoration of all things.

Revelation 10:1 And I saw another mighty angel come down from heaven, clothed with a cloud: and a rainbow was upon his head, and his face was as it were the sun, and his feet as pillars of fire:

Revelation 10:2 And he had in his hand a little book open: and he set his right foot upon the sea, and his left foot on the earth,

Revelation 10:3 And cried with a loud voice, as when a lion roareth: and when he had cried, seven thunders uttered their voices.

Revelation 10:4 And when the seven thunders had uttered their voices, I was about to write: and I heard a voice from heaven saying unto me, Seal up those things which the seven thunders uttered, and write them not.

Revelation 10:5 And the angel which I saw stand upon the sea and upon the earth lifted up his hand to heaven,

Revelation 10:6 And sware by him that liveth for ever and ever, who created heaven, and the things that therein are, and the earth, and the things that therein are, and the sea, and the things which are therein, that there should be time no longer:

Revelation 10:7 But in the days of the voice of the seventh angel, when he shall begin to sound, the mystery of God should be finished, as he hath declared to his servants the prophets.

Revelation 10:8 And the voice which I heard from heaven spake unto me again, and said, Go and take the little book which is open in the hand of the angel which standeth upon the sea and upon the earth.

Revelation 10:9 And I went unto the angel, and said unto him, Give me the little book. And he said unto me, Take it, and eat it up; and it shall make thy belly bitter, but it shall be in thy mouth sweet as honey.

Revelation 10:10 And I took the little book out of the angel’s hand, and ate it up; and it was in my mouth sweet as honey: and as soon as I had eaten it, my belly was bitter.

Revelation 10:11 And he said unto me, Thou must prophesy again before many peoples, and nations, and tongues, and kings.
