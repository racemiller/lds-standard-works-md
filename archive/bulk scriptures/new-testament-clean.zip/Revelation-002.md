# Revelation 2

Revelation 2 (summary): He who overcomes will gain eternal life, avoid the second death, inherit the celestial kingdom, and rule many kingdoms.

Revelation 2:1 Unto the angel of the church of Ephesus write; These things saith he that holdeth the seven stars in his right hand, who walketh in the midst of the seven golden candlesticks;

Revelation 2:2 I know thy works, and thy labour, and thy patience, and how thou canst not bear them which are evil: and thou hast tried them which say they are apostles, and are not, and hast found them liars:

Revelation 2:3 And hast borne, and hast patience, and for my name’s sake hast laboured, and hast not fainted.

Revelation 2:4 Nevertheless I have somewhat against thee, because thou hast left thy first love.

Revelation 2:5 Remember therefore from whence thou art fallen, and repent, and do the first works; or else I will come unto thee quickly, and will remove thy candlestick out of his place, except thou repent.

Revelation 2:6 But this thou hast, that thou hatest the deeds of the Nicolaitans, which I also hate.

Revelation 2:7 He that hath an ear, let him hear what the Spirit saith unto the churches; To him that overcometh will I give to eat of the tree of life, which is in the midst of the paradise of God.

Revelation 2:8 And unto the angel of the church in Smyrna write; These things saith the first and the last, which was dead, and is alive;

Revelation 2:9 I know thy works, and tribulation, and poverty, (but thou art rich) and I know the blasphemy of them which say they are Jews, and are not, but are the synagogue of Satan.

Revelation 2:10 Fear none of those things which thou shalt suffer: behold, the devil shall cast some of you into prison, that ye may be tried; and ye shall have tribulation ten days: be thou faithful unto death, and I will give thee a crown of life.

Revelation 2:11 He that hath an ear, let him hear what the Spirit saith unto the churches; He that overcometh shall not be hurt of the second death.

Revelation 2:12 And to the angel of the church in Pergamos write; These things saith he which hath the sharp sword with two edges;

Revelation 2:13 I know thy works, and where thou dwellest, even where Satan’s seat is: and thou holdest fast my name, and hast not denied my faith, even in those days wherein Antipas was my faithful martyr, who was slain among you, where Satan dwelleth.

Revelation 2:14 But I have a few things against thee, because thou hast there them that hold the doctrine of Balaam, who taught Balac to cast a stumblingblock before the children of Israel, to eat things sacrificed unto idols, and to commit fornication.

Revelation 2:15 So hast thou also them that hold the doctrine of the Nicolaitans, which thing I hate.

Revelation 2:16 Repent; or else I will come unto thee quickly, and will fight against them with the sword of my mouth.

Revelation 2:17 He that hath an ear, let him hear what the Spirit saith unto the churches; To him that overcometh will I give to eat of the hidden manna, and will give him a white stone, and in the stone a new name written, which no man knoweth saving he that receiveth it.

Revelation 2:18 And unto the angel of the church in Thyatira write; These things saith the Son of God, who hath his eyes like unto a flame of fire, and his feet are like fine brass;

Revelation 2:19 I know thy works, and charity, and service, and faith, and thy patience, and thy works; and the last to be more than the first.

Revelation 2:20 Notwithstanding I have a few things against thee, because thou sufferest that woman Jezebel, which calleth herself a prophetess, to teach and to seduce my servants to commit fornication, and to eat things sacrificed unto idols.

Revelation 2:21 And I gave her space to repent of her fornication; and she repented not.

Revelation 2:22 Behold, I will cast her into a bed, and them that commit adultery with her into great tribulation, except they repent of their deeds.

Revelation 2:23 And I will kill her children with death; and all the churches shall know that I am he which searcheth the reins and hearts: and I will give unto every one of you according to your works.

Revelation 2:24 But unto you I say, and unto the rest in Thyatira, as many as have not this doctrine, and which have not known the depths of Satan, as they speak; I will put upon you none other burden.

Revelation 2:25 But that which ye have already hold fast till I come.

Revelation 2:26 And he that overcometh, and keepeth my works unto the end, to him will I give power over the nations:

Revelation 2:27 And he shall rule them with a rod of iron; as the vessels of a potter shall they be broken to shivers: even as I received of my Father.

Revelation 2:28 And I will give him the morning star.

Revelation 2:29 He that hath an ear, let him hear what the Spirit saith unto the churches.
