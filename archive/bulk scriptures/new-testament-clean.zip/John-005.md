# John 5

John 5 (summary): Jesus heals an invalid on the Sabbath—He explains why men must honor the Son—Jesus promises to take the gospel to the dead—Man is resurrected, judged, and assigned his glory by the Son—Jesus obeys the divine law of witnesses.

John 5:1 After this there was a feast of the Jews; and Jesus went up to Jerusalem.

John 5:2 Now there is at Jerusalem by the sheep market a pool, which is called in the Hebrew tongue Bethesda, having five porches.

John 5:3 In these lay a great multitude of impotent folk, of blind, halt, withered, waiting for the moving of the water.

John 5:4 For an angel went down at a certain season into the pool, and troubled the water: whosoever then first after the troubling of the water stepped in was made whole of whatsoever disease he had.

John 5:5 And a certain man was there, which had an infirmity thirty and eight years.

John 5:6 When Jesus saw him lie, and knew that he had been now a long time in that case, he saith unto him, Wilt thou be made whole?

John 5:7 The impotent man answered him, Sir, I have no man, when the water is troubled, to put me into the pool: but while I am coming, another steppeth down before me.

John 5:8 Jesus saith unto him, Rise, take up thy bed, and walk.

John 5:9 And immediately the man was made whole, and took up his bed, and walked: and on the same day was the sabbath.

John 5:10 The Jews therefore said unto him that was cured, It is the sabbath day: it is not lawful for thee to carry thy bed.

John 5:11 He answered them, He that made me whole, the same said unto me, Take up thy bed, and walk.

John 5:12 Then asked they him, What man is that which said unto thee, Take up thy bed, and walk?

John 5:13 And he that was healed wist not who it was: for Jesus had conveyed himself away, a multitude being in that place.

John 5:14 Afterward Jesus findeth him in the temple, and said unto him, Behold, thou art made whole: sin no more, lest a worse thing come unto thee.

John 5:15 The man departed, and told the Jews that it was Jesus, which had made him whole.

John 5:16 And therefore did the Jews persecute Jesus, and sought to slay him, because he had done these things on the sabbath day.

John 5:17 But Jesus answered them, My Father worketh hitherto, and I work.

John 5:18 Therefore the Jews sought the more to kill him, because he not only had broken the sabbath, but said also that God was his Father, making himself equal with God.

John 5:19 Then answered Jesus and said unto them, Verily, verily, I say unto you, The Son can do nothing of himself, but what he seeth the Father do: for what things soever he doeth, these also doeth the Son likewise.

John 5:20 For the Father loveth the Son, and sheweth him all things that himself doeth: and he will shew him greater works than these, that ye may marvel.

John 5:21 For as the Father raiseth up the dead, and quickeneth them; even so the Son quickeneth whom he will.

John 5:22 For the Father judgeth no man, but hath committed all judgment unto the Son:

John 5:23 That all men should honour the Son, even as they honour the Father. He that honoureth not the Son honoureth not the Father which hath sent him.

John 5:24 Verily, verily, I say unto you, He that heareth my word, and believeth on him that sent me, hath everlasting life, and shall not come into condemnation; but is passed from death unto life.

John 5:25 Verily, verily, I say unto you, The hour is coming, and now is, when the dead shall hear the voice of the Son of God: and they that hear shall live.

John 5:26 For as the Father hath life in himself; so hath he given to the Son to have life in himself;

John 5:27 And hath given him authority to execute judgment also, because he is the Son of man.

John 5:28 Marvel not at this: for the hour is coming, in the which all that are in the graves shall hear his voice,

John 5:29 And shall come forth; they that have done good, unto the resurrection of life; and they that have done evil, unto the resurrection of damnation.

John 5:30 I can of mine own self do nothing: as I hear, I judge: and my judgment is just; because I seek not mine own will, but the will of the Father which hath sent me.

John 5:31 If I bear witness of myself, my witness is not true.

John 5:32 There is another that beareth witness of me; and I know that the witness which he witnesseth of me is true.

John 5:33 Ye sent unto John, and he bare witness unto the truth.

John 5:34 But I receive not testimony from man: but these things I say, that ye might be saved.

John 5:35 He was a burning and a shining light: and ye were willing for a season to rejoice in his light.

John 5:36 But I have greater witness than that of John: for the works which the Father hath given me to finish, the same works that I do, bear witness of me, that the Father hath sent me.

John 5:37 And the Father himself, which hath sent me, hath borne witness of me. Ye have neither heard his voice at any time, nor seen his shape.

John 5:38 And ye have not his word abiding in you: for whom he hath sent, him ye believe not.

John 5:39 Search the scriptures; for in them ye think ye have eternal life: and they are they which testify of me.

John 5:40 And ye will not come to me, that ye might have life.

John 5:41 I receive not honour from men.

John 5:42 But I know you, that ye have not the love of God in you.

John 5:43 I am come in my Father’s name, and ye receive me not: if another shall come in his own name, him ye will receive.

John 5:44 How can ye believe, which receive honour one of another, and seek not the honour that cometh from God only?

John 5:45 Do not think that I will accuse you to the Father: there is one that accuseth you, even Moses, in whom ye trust.

John 5:46 For had ye believed Moses, ye would have believed me: for he wrote of me.

John 5:47 But if ye believe not his writings, how shall ye believe my words?
