# 1 Corinthians 4

1 Corinthians 4 (summary): Christ’s ministers must be faithful—The Apostles suffer, minister, and keep the faith—The kingdom of God is not in word but in power.

1 Corinthians 4:1 Let a man so account of us, as of the ministers of Christ, and stewards of the mysteries of God.

1 Corinthians 4:2 Moreover it is required in stewards, that a man be found faithful.

1 Corinthians 4:3 But with me it is a very small thing that I should be judged of you, or of man’s judgment: yea, I judge not mine own self.

1 Corinthians 4:4 For I know nothing by myself; yet am I not hereby justified: but he that judgeth me is the Lord.

1 Corinthians 4:5 Therefore judge nothing before the time, until the Lord come, who both will bring to light the hidden things of darkness, and will make manifest the counsels of the hearts: and then shall every man have praise of God.

1 Corinthians 4:6 And these things, brethren, I have in a figure transferred to myself and to Apollos for your sakes; that ye might learn in us not to think of men above that which is written, that no one of you be puffed up for one against another.

1 Corinthians 4:7 For who maketh thee to differ from another? and what hast thou that thou didst not receive? now if thou didst receive it, why dost thou glory, as if thou hadst not received it?

1 Corinthians 4:8 Now ye are full, now ye are rich, ye have reigned as kings without us: and I would to God ye did reign, that we also might reign with you.

1 Corinthians 4:9 For I think that God hath set forth us the apostles last, as it were appointed to death: for we are made a spectacle unto the world, and to angels, and to men.

1 Corinthians 4:10 We are fools for Christ’s sake, but ye are wise in Christ; we are weak, but ye are strong; ye are honourable, but we are despised.

1 Corinthians 4:11 Even unto this present hour we both hunger, and thirst, and are naked, and are buffeted, and have no certain dwellingplace;

1 Corinthians 4:12 And labour, working with our own hands: being reviled, we bless; being persecuted, we suffer it:

1 Corinthians 4:13 Being defamed, we entreat: we are made as the filth of the world, and are the offscouring of all things unto this day.

1 Corinthians 4:14 I write not these things to shame you, but as my beloved sons I warn you.

1 Corinthians 4:15 For though ye have ten thousand instructors in Christ, yet have ye not many fathers: for in Christ Jesus I have begotten you through the gospel.

1 Corinthians 4:16 Wherefore I beseech you, be ye followers of me.

1 Corinthians 4:17 For this cause have I sent unto you Timotheus, who is my beloved son, and faithful in the Lord, who shall bring you into remembrance of my ways which be in Christ, as I teach every where in every church.

1 Corinthians 4:18 Now some are puffed up, as though I would not come to you.

1 Corinthians 4:19 But I will come to you shortly, if the Lord will, and will know, not the speech of them which are puffed up, but the power.

1 Corinthians 4:20 For the kingdom of God is not in word, but in power.

1 Corinthians 4:21 What will ye? shall I come unto you with a rod, or in love, and in the spirit of meekness?
