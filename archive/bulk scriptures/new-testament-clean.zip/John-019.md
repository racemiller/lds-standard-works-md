# John 19

John 19 (summary): Jesus is scourged and crucified—He places His mother in John’s care—He dies and His side is pierced with a spear—He is buried in the tomb of Joseph of Arimathæa.

John 19:1 Then Pilate therefore took Jesus, and scourged him.

John 19:2 And the soldiers plaited a crown of thorns, and put it on his head, and they put on him a purple robe,

John 19:3 And said, Hail, King of the Jews! and they smote him with their hands.

John 19:4 Pilate therefore went forth again, and saith unto them, Behold, I bring him forth to you, that ye may know that I find no fault in him.

John 19:5 Then came Jesus forth, wearing the crown of thorns, and the purple robe. And Pilate saith unto them, Behold the man!

John 19:6 When the chief priests therefore and officers saw him, they cried out, saying, Crucify him, crucify him. Pilate saith unto them, Take ye him, and crucify him: for I find no fault in him.

John 19:7 The Jews answered him, We have a law, and by our law he ought to die, because he made himself the Son of God.

John 19:8 When Pilate therefore heard that saying, he was the more afraid;

John 19:9 And went again into the judgment hall, and saith unto Jesus, Whence art thou? But Jesus gave him no answer.

John 19:10 Then saith Pilate unto him, Speakest thou not unto me? knowest thou not that I have power to crucify thee, and have power to release thee?

John 19:11 Jesus answered, Thou couldest have no power at all against me, except it were given thee from above: therefore he that delivered me unto thee hath the greater sin.

John 19:12 And from thenceforth Pilate sought to release him: but the Jews cried out, saying, If thou let this man go, thou art not Cæsar’s friend: whosoever maketh himself a king speaketh against Cæsar.

John 19:13 When Pilate therefore heard that saying, he brought Jesus forth, and sat down in the judgment seat in a place that is called the Pavement, but in the Hebrew, Gabbatha.

John 19:14 And it was the preparation of the passover, and about the sixth hour: and he saith unto the Jews, Behold your King!

John 19:15 But they cried out, Away with him, away with him, crucify him. Pilate saith unto them, Shall I crucify your King? The chief priests answered, We have no king but Cæsar.

John 19:16 Then delivered he him therefore unto them to be crucified. And they took Jesus, and led him away.

John 19:17 And he bearing his cross went forth into a place called the place of a skull, which is called in the Hebrew Golgotha:

John 19:18 Where they crucified him, and two other with him, on either side one, and Jesus in the midst.

John 19:19 And Pilate wrote a title, and put it on the cross. And the writing was, Jesus of Nazareth the King of the Jews.

John 19:20 This title then read many of the Jews: for the place where Jesus was crucified was nigh to the city: and it was written in Hebrew, and Greek, and Latin.

John 19:21 Then said the chief priests of the Jews to Pilate, Write not, The King of the Jews; but that he said, I am King of the Jews.

John 19:22 Pilate answered, What I have written I have written.

John 19:23 Then the soldiers, when they had crucified Jesus, took his garments, and made four parts, to every soldier a part; and also his coat: now the coat was without seam, woven from the top throughout.

John 19:24 They said therefore among themselves, Let us not rend it, but cast lots for it, whose it shall be: that the scripture might be fulfilled, which saith, They parted my raiment among them, and for my vesture they did cast lots. These things therefore the soldiers did.

John 19:25 Now there stood by the cross of Jesus his mother, and his mother’s sister, Mary the wife of Cleophas, and Mary Magdalene.

John 19:26 When Jesus therefore saw his mother, and the disciple standing by, whom he loved, he saith unto his mother, Woman, behold thy son!

John 19:27 Then saith he to the disciple, Behold thy mother! And from that hour that disciple took her unto his own home.

John 19:28 After this, Jesus knowing that all things were now accomplished, that the scripture might be fulfilled, saith, I thirst.

John 19:29 Now there was set a vessel full of vinegar: and they filled a sponge with vinegar, and put it upon hyssop, and put it to his mouth.

John 19:30 When Jesus therefore had received the vinegar, he said, It is finished: and he bowed his head, and gave up the ghost.

John 19:31 The Jews therefore, because it was the preparation, that the bodies should not remain upon the cross on the sabbath day, (for that sabbath day was an high day,) besought Pilate that their legs might be broken, and that they might be taken away.

John 19:32 Then came the soldiers, and brake the legs of the first, and of the other which was crucified with him.

John 19:33 But when they came to Jesus, and saw that he was dead already, they brake not his legs:

John 19:34 But one of the soldiers with a spear pierced his side, and forthwith came there out blood and water.

John 19:35 And he that saw it bare record, and his record is true: and he knoweth that he saith true, that ye might believe.

John 19:36 For these things were done, that the scripture should be fulfilled, A bone of him shall not be broken.

John 19:37 And again another scripture saith, They shall look on him whom they pierced.

John 19:38 And after this Joseph of Arimathæa, being a disciple of Jesus, but secretly for fear of the Jews, besought Pilate that he might take away the body of Jesus: and Pilate gave him leave. He came therefore, and took the body of Jesus.

John 19:39 And there came also Nicodemus, which at the first came to Jesus by night, and brought a mixture of myrrh and aloes, about an hundred pound weight.

John 19:40 Then took they the body of Jesus, and wound it in linen clothes with the spices, as the manner of the Jews is to bury.

John 19:41 Now in the place where he was crucified there was a garden; and in the garden a new sepulchre, wherein was never man yet laid.

John 19:42 There laid they Jesus therefore because of the Jews’ preparation day; for the sepulchre was nigh at hand.
