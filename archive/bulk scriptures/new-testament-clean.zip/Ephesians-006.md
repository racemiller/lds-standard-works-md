# Ephesians 6

Ephesians 6 (summary): Children should honor their parents—Servants and masters are judged by the same law—Saints should put on the whole armor of God.

Ephesians 6:1 Children, obey your parents in the Lord: for this is right.

Ephesians 6:2 Honour thy father and mother; (which is the first commandment with promise;)

Ephesians 6:3 That it may be well with thee, and thou mayest live long on the earth.

Ephesians 6:4 And, ye fathers, provoke not your children to wrath: but bring them up in the nurture and admonition of the Lord.

Ephesians 6:5 Servants, be obedient to them that are your masters according to the flesh, with fear and trembling, in singleness of your heart, as unto Christ;

Ephesians 6:6 Not with eyeservice, as menpleasers; but as the servants of Christ, doing the will of God from the heart;

Ephesians 6:7 With good will doing service, as to the Lord, and not to men:

Ephesians 6:8 Knowing that whatsoever good thing any man doeth, the same shall he receive of the Lord, whether he be bond or free.

Ephesians 6:9 And, ye masters, do the same things unto them, forbearing threatening: knowing that your Master also is in heaven; neither is there respect of persons with him.

Ephesians 6:10 Finally, my brethren, be strong in the Lord, and in the power of his might.

Ephesians 6:11 Put on the whole armour of God, that ye may be able to stand against the wiles of the devil.

Ephesians 6:12 For we wrestle not against flesh and blood, but against principalities, against powers, against the rulers of the darkness of this world, against spiritual wickedness in high places.

Ephesians 6:13 Wherefore take unto you the whole armour of God, that ye may be able to withstand in the evil day, and having done all, to stand.

Ephesians 6:14 Stand therefore, having your loins girt about with truth, and having on the breastplate of righteousness;

Ephesians 6:15 And your feet shod with the preparation of the gospel of peace;

Ephesians 6:16 Above all, taking the shield of faith, wherewith ye shall be able to quench all the fiery darts of the wicked.

Ephesians 6:17 And take the helmet of salvation, and the sword of the Spirit, which is the word of God:

Ephesians 6:18 Praying always with all prayer and supplication in the Spirit, and watching thereunto with all perseverance and supplication for all saints;

Ephesians 6:19 And for me, that utterance may be given unto me, that I may open my mouth boldly, to make known the mystery of the gospel,

Ephesians 6:20 For which I am an ambassador in bonds: that therein I may speak boldly, as I ought to speak.

Ephesians 6:21 But that ye also may know my affairs, and how I do, Tychicus, a beloved brother and faithful minister in the Lord, shall make known to you all things:

Ephesians 6:22 Whom I have sent unto you for the same purpose, that ye might know our affairs, and that he might comfort your hearts.

Ephesians 6:23 Peace be to the brethren, and love with faith, from God the Father and the Lord Jesus Christ.

Ephesians 6:24 Grace be with all them that love our Lord Jesus Christ in sincerity. Amen.
