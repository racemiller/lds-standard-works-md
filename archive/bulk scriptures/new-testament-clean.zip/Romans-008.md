# Romans 8

Romans 8 (summary): The law of Christ brings life and peace—Those adopted as children of God become joint heirs with Christ—God’s elect are foreordained to eternal life—Christ makes intercession for man.

Romans 8:1 There is therefore now no condemnation to them which are in Christ Jesus, who walk not after the flesh, but after the Spirit.

Romans 8:2 For the law of the Spirit of life in Christ Jesus hath made me free from the law of sin and death.

Romans 8:3 For what the law could not do, in that it was weak through the flesh, God sending his own Son in the likeness of sinful flesh, and for sin, condemned sin in the flesh:

Romans 8:4 That the righteousness of the law might be fulfilled in us, who walk not after the flesh, but after the Spirit.

Romans 8:5 For they that are after the flesh do mind the things of the flesh; but they that are after the Spirit the things of the Spirit.

Romans 8:6 For to be carnally minded is death; but to be spiritually minded is life and peace.

Romans 8:7 Because the carnal mind is enmity against God: for it is not subject to the law of God, neither indeed can be.

Romans 8:8 So then they that are in the flesh cannot please God.

Romans 8:9 But ye are not in the flesh, but in the Spirit, if so be that the Spirit of God dwell in you. Now if any man have not the Spirit of Christ, he is none of his.

Romans 8:10 And if Christ be in you, the body is dead because of sin; but the Spirit is life because of righteousness.

Romans 8:11 But if the Spirit of him that raised up Jesus from the dead dwell in you, he that raised up Christ from the dead shall also quicken your mortal bodies by his Spirit that dwelleth in you.

Romans 8:12 Therefore, brethren, we are debtors, not to the flesh, to live after the flesh.

Romans 8:13 For if ye live after the flesh, ye shall die: but if ye through the Spirit do mortify the deeds of the body, ye shall live.

Romans 8:14 For as many as are led by the Spirit of God, they are the sons of God.

Romans 8:15 For ye have not received the spirit of bondage again to fear; but ye have received the Spirit of adoption, whereby we cry, Abba, Father.

Romans 8:16 The Spirit itself beareth witness with our spirit, that we are the children of God:

Romans 8:17 And if children, then heirs; heirs of God, and joint-heirs with Christ; if so be that we suffer with him, that we may be also glorified together.

Romans 8:18 For I reckon that the sufferings of this present time are not worthy to be compared with the glory which shall be revealed in us.

Romans 8:19 For the earnest expectation of the creature waiteth for the manifestation of the sons of God.

Romans 8:20 For the creature was made subject to vanity, not willingly, but by reason of him who hath subjected the same in hope,

Romans 8:21 Because the creature itself also shall be delivered from the bondage of corruption into the glorious liberty of the children of God.

Romans 8:22 For we know that the whole creation groaneth and travaileth in pain together until now.

Romans 8:23 And not only they, but ourselves also, which have the firstfruits of the Spirit, even we ourselves groan within ourselves, waiting for the adoption, to wit, the redemption of our body.

Romans 8:24 For we are saved by hope: but hope that is seen is not hope: for what a man seeth, why doth he yet hope for?

Romans 8:25 But if we hope for that we see not, then do we with patience wait for it.

Romans 8:26 Likewise the Spirit also helpeth our infirmities: for we know not what we should pray for as we ought: but the Spirit itself maketh intercession for us with groanings which cannot be uttered.

Romans 8:27 And he that searcheth the hearts knoweth what is the mind of the Spirit, because he maketh intercession for the saints according to the will of God.

Romans 8:28 And we know that all things work together for good to them that love God, to them who are the called according to his purpose.

Romans 8:29 For whom he did foreknow, he also did predestinate to be conformed to the image of his Son, that he might be the firstborn among many brethren.

Romans 8:30 Moreover whom he did predestinate, them he also called: and whom he called, them he also justified: and whom he justified, them he also glorified.

Romans 8:31 What shall we then say to these things? If God be for us, who can be against us?

Romans 8:32 He that spared not his own Son, but delivered him up for us all, how shall he not with him also freely give us all things?

Romans 8:33 Who shall lay any thing to the charge of God’s elect? It is God that justifieth.

Romans 8:34 Who is he that condemneth? It is Christ that died, yea rather, that is risen again, who is even at the right hand of God, who also maketh intercession for us.

Romans 8:35 Who shall separate us from the love of Christ? shall tribulation, or distress, or persecution, or famine, or nakedness, or peril, or sword?

Romans 8:36 As it is written, For thy sake we are killed all the day long; we are accounted as sheep for the slaughter.

Romans 8:37 Nay, in all these things we are more than conquerors through him that loved us.

Romans 8:38 For I am persuaded, that neither death, nor life, nor angels, nor principalities, nor powers, nor things present, nor things to come,

Romans 8:39 Nor height, nor depth, nor any other creature, shall be able to separate us from the love of God, which is in Christ Jesus our Lord.
