# John 3

John 3 (summary): Jesus tells Nicodemus that men must be born again—God so loved the world that He sent His Only Begotten Son to save men—John the Baptist testifies that he that believes on the Son has everlasting life.

John 3:1 There was a man of the Pharisees, named Nicodemus, a ruler of the Jews:

John 3:2 The same came to Jesus by night, and said unto him, Rabbi, we know that thou art a teacher come from God: for no man can do these miracles that thou doest, except God be with him.

John 3:3 Jesus answered and said unto him, Verily, verily, I say unto thee, Except a man be born again, he cannot see the kingdom of God.

John 3:4 Nicodemus saith unto him, How can a man be born when he is old? can he enter the second time into his mother’s womb, and be born?

John 3:5 Jesus answered, Verily, verily, I say unto thee, Except a man be born of water and of the Spirit, he cannot enter into the kingdom of God.

John 3:6 That which is born of the flesh is flesh; and that which is born of the Spirit is spirit.

John 3:7 Marvel not that I said unto thee, Ye must be born again.

John 3:8 The wind bloweth where it listeth, and thou hearest the sound thereof, but canst not tell whence it cometh, and whither it goeth: so is every one that is born of the Spirit.

John 3:9 Nicodemus answered and said unto him, How can these things be?

John 3:10 Jesus answered and said unto him, Art thou a master of Israel, and knowest not these things?

John 3:11 Verily, verily, I say unto thee, We speak that we do know, and testify that we have seen; and ye receive not our witness.

John 3:12 If I have told you earthly things, and ye believe not, how shall ye believe, if I tell you of heavenly things?

John 3:13 And no man hath ascended up to heaven, but he that came down from heaven, even the Son of man which is in heaven.

John 3:14 And as Moses lifted up the serpent in the wilderness, even so must the Son of man be lifted up:

John 3:15 That whosoever believeth in him should not perish, but have eternal life.

John 3:16 For God so loved the world, that he gave his only begotten Son, that whosoever believeth in him should not perish, but have everlasting life.

John 3:17 For God sent not his Son into the world to condemn the world; but that the world through him might be saved.

John 3:18 He that believeth on him is not condemned: but he that believeth not is condemned already, because he hath not believed in the name of the only begotten Son of God.

John 3:19 And this is the condemnation, that light is come into the world, and men loved darkness rather than light, because their deeds were evil.

John 3:20 For every one that doeth evil hateth the light, neither cometh to the light, lest his deeds should be reproved.

John 3:21 But he that doeth truth cometh to the light, that his deeds may be made manifest, that they are wrought in God.

John 3:22 After these things came Jesus and his disciples into the land of Judæa; and there he tarried with them, and baptized.

John 3:23 And John also was baptizing in Ænon near to Salim, because there was much water there: and they came, and were baptized.

John 3:24 For John was not yet cast into prison.

John 3:25 Then there arose a question between some of John’s disciples and the Jews about purifying.

John 3:26 And they came unto John, and said unto him, Rabbi, he that was with thee beyond Jordan, to whom thou barest witness, behold, the same baptizeth, and all men come to him.

John 3:27 John answered and said, A man can receive nothing, except it be given him from heaven.

John 3:28 Ye yourselves bear me witness, that I said, I am not the Christ, but that I am sent before him.

John 3:29 He that hath the bride is the bridegroom: but the friend of the bridegroom, which standeth and heareth him, rejoiceth greatly because of the bridegroom’s voice: this my joy therefore is fulfilled.

John 3:30 He must increase, but I must decrease.

John 3:31 He that cometh from above is above all: he that is of the earth is earthly, and speaketh of the earth: he that cometh from heaven is above all.

John 3:32 And what he hath seen and heard, that he testifieth; and no man receiveth his testimony.

John 3:33 He that hath received his testimony hath set to his seal that God is true.

John 3:34 For he whom God hath sent speaketh the words of God: for God giveth not the Spirit by measure unto him.

John 3:35 The Father loveth the Son, and hath given all things into his hand.

John 3:36 He that believeth on the Son hath everlasting life: and he that believeth not the Son shall not see life; but the wrath of God abideth on him.
