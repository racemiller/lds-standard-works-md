# Matthew 28

Matthew 28 (summary): Christ the Lord is risen—He appears to many—He has all power in heaven and earth—He sends the Apostles to teach and baptize all nations.

Matthew 28:1 In the end of the sabbath, as it began to dawn toward the first day of the week, came Mary Magdalene and the other Mary to see the sepulchre.

Matthew 28:2 And, behold, there was a great earthquake: for the angel of the Lord descended from heaven, and came and rolled back the stone from the door, and sat upon it.

Matthew 28:3 His countenance was like lightning, and his raiment white as snow:

Matthew 28:4 And for fear of him the keepers did shake, and became as dead men.

Matthew 28:5 And the angel answered and said unto the women, Fear not ye: for I know that ye seek Jesus, which was crucified.

Matthew 28:6 He is not here: for he is risen, as he said. Come, see the place where the Lord lay.

Matthew 28:7 And go quickly, and tell his disciples that he is risen from the dead; and, behold, he goeth before you into Galilee; there shall ye see him: lo, I have told you.

Matthew 28:8 And they departed quickly from the sepulchre with fear and great joy; and did run to bring his disciples word.

Matthew 28:9 And as they went to tell his disciples, behold, Jesus met them, saying, All hail. And they came and held him by the feet, and worshipped him.

Matthew 28:10 Then said Jesus unto them, Be not afraid: go tell my brethren that they go into Galilee, and there shall they see me.

Matthew 28:11 Now when they were going, behold, some of the watch came into the city, and shewed unto the chief priests all the things that were done.

Matthew 28:12 And when they were assembled with the elders, and had taken counsel, they gave large money unto the soldiers,

Matthew 28:13 Saying, Say ye, His disciples came by night, and stole him away while we slept.

Matthew 28:14 And if this come to the governor’s ears, we will persuade him, and secure you.

Matthew 28:15 So they took the money, and did as they were taught: and this saying is commonly reported among the Jews until this day.

Matthew 28:16 Then the eleven disciples went away into Galilee, into a mountain where Jesus had appointed them.

Matthew 28:17 And when they saw him, they worshipped him: but some doubted.

Matthew 28:18 And Jesus came and spake unto them, saying, All power is given unto me in heaven and in earth.

Matthew 28:19 Go ye therefore, and teach all nations, baptizing them in the name of the Father, and of the Son, and of the Holy Ghost:

Matthew 28:20 Teaching them to observe all things whatsoever I have commanded you: and, lo, I am with you alway, even unto the end of the world. Amen.
