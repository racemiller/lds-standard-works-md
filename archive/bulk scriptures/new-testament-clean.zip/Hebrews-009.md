# Hebrews 9

Hebrews 9 (summary): The Mosaic ordinances prefigured Christ’s ministry—Christ is the Mediator of the new covenant.

Hebrews 9:1 Then verily the first covenant had also ordinances of divine service, and a worldly sanctuary.

Hebrews 9:2 For there was a tabernacle made; the first, wherein was the candlestick, and the table, and the shewbread; which is called the sanctuary.

Hebrews 9:3 And after the second veil, the tabernacle which is called the Holiest of all;

Hebrews 9:4 Which had the golden censer, and the ark of the covenant overlaid round about with gold, wherein was the golden pot that had manna, and Aaron’s rod that budded, and the tables of the covenant;

Hebrews 9:5 And over it the cherubims of glory shadowing the mercyseat; of which we cannot now speak particularly.

Hebrews 9:6 Now when these things were thus ordained, the priests went always into the first tabernacle, accomplishing the service of God.

Hebrews 9:7 But into the second went the high priest alone once every year, not without blood, which he offered for himself, and for the errors of the people:

Hebrews 9:8 The Holy Ghost this signifying, that the way into the holiest of all was not yet made manifest, while as the first tabernacle was yet standing:

Hebrews 9:9 Which was a figure for the time then present, in which were offered both gifts and sacrifices, that could not make him that did the service perfect, as pertaining to the conscience;

Hebrews 9:10 Which stood only in meats and drinks, and divers washings, and carnal ordinances, imposed on them until the time of reformation.

Hebrews 9:11 But Christ being come an high priest of good things to come, by a greater and more perfect tabernacle, not made with hands, that is to say, not of this building;

Hebrews 9:12 Neither by the blood of goats and calves, but by his own blood he entered in once into the holy place, having obtained eternal redemption for us.

Hebrews 9:13 For if the blood of bulls and of goats, and the ashes of an heifer sprinkling the unclean, sanctifieth to the purifying of the flesh:

Hebrews 9:14 How much more shall the blood of Christ, who through the eternal Spirit offered himself without spot to God, purge your conscience from dead works to serve the living God?

Hebrews 9:15 And for this cause he is the mediator of the new testament, that by means of death, for the redemption of the transgressions that were under the first testament, they which are called might receive the promise of eternal inheritance.

Hebrews 9:16 For where a testament is, there must also of necessity be the death of the testator.

Hebrews 9:17 For a testament is of force after men are dead: otherwise it is of no strength at all while the testator liveth.

Hebrews 9:18 Whereupon neither the first testament was dedicated without blood.

Hebrews 9:19 For when Moses had spoken every precept to all the people according to the law, he took the blood of calves and of goats, with water, and scarlet wool, and hyssop, and sprinkled both the book, and all the people,

Hebrews 9:20 Saying, This is the blood of the testament which God hath enjoined unto you.

Hebrews 9:21 Moreover he sprinkled with blood both the tabernacle, and all the vessels of the ministry.

Hebrews 9:22 And almost all things are by the law purged with blood; and without shedding of blood is no remission.

Hebrews 9:23 It was therefore necessary that the patterns of things in the heavens should be purified with these; but the heavenly things themselves with better sacrifices than these.

Hebrews 9:24 For Christ is not entered into the holy places made with hands, which are the figures of the true; but into heaven itself, now to appear in the presence of God for us:

Hebrews 9:25 Nor yet that he should offer himself often, as the high priest entereth into the holy place every year with blood of others;

Hebrews 9:26 For then must he often have suffered since the foundation of the world: but now once in the end of the world hath he appeared to put away sin by the sacrifice of himself.

Hebrews 9:27 And as it is appointed unto men once to die, but after this the judgment:

Hebrews 9:28 So Christ was once offered to bear the sins of many; and unto them that look for him shall he appear the second time without sin unto salvation.
