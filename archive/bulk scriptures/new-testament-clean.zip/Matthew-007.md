# Matthew 7

Matthew 7 (summary): Jesus concludes the Sermon on the Mount—He commands, Judge not; ask of God; beware of false prophets—He promises salvation to those who do the will of the Father.

Matthew 7:1 Judge not, that ye be not judged.

Matthew 7:2 For with what judgment ye judge, ye shall be judged: and with what measure ye mete, it shall be measured to you again.

Matthew 7:3 And why beholdest thou the mote that is in thy brother’s eye, but considerest not the beam that is in thine own eye?

Matthew 7:4 Or how wilt thou say to thy brother, Let me pull out the mote out of thine eye; and, behold, a beam is in thine own eye?

Matthew 7:5 Thou hypocrite, first cast out the beam out of thine own eye; and then shalt thou see clearly to cast out the mote out of thy brother’s eye.

Matthew 7:6 Give not that which is holy unto the dogs, neither cast ye your pearls before swine, lest they trample them under their feet, and turn again and rend you.

Matthew 7:7 Ask, and it shall be given you; seek, and ye shall find; knock, and it shall be opened unto you:

Matthew 7:8 For every one that asketh receiveth; and he that seeketh findeth; and to him that knocketh it shall be opened.

Matthew 7:9 Or what man is there of you, whom if his son ask bread, will he give him a stone?

Matthew 7:10 Or if he ask a fish, will he give him a serpent?

Matthew 7:11 If ye then, being evil, know how to give good gifts unto your children, how much more shall your Father which is in heaven give good things to them that ask him?

Matthew 7:12 Therefore all things whatsoever ye would that men should do to you, do ye even so to them: for this is the law and the prophets.

Matthew 7:13 Enter ye in at the strait gate: for wide is the gate, and broad is the way, that leadeth to destruction, and many there be which go in thereat:

Matthew 7:14 Because strait is the gate, and narrow is the way, which leadeth unto life, and few there be that find it.

Matthew 7:15 Beware of false prophets, which come to you in sheep’s clothing, but inwardly they are ravening wolves.

Matthew 7:16 Ye shall know them by their fruits. Do men gather grapes of thorns, or figs of thistles?

Matthew 7:17 Even so every good tree bringeth forth good fruit; but a corrupt tree bringeth forth evil fruit.

Matthew 7:18 A good tree cannot bring forth evil fruit, neither can a corrupt tree bring forth good fruit.

Matthew 7:19 Every tree that bringeth not forth good fruit is hewn down, and cast into the fire.

Matthew 7:20 Wherefore by their fruits ye shall know them.

Matthew 7:21 Not every one that saith unto me, Lord, Lord, shall enter into the kingdom of heaven; but he that doeth the will of my Father which is in heaven.

Matthew 7:22 Many will say to me in that day, Lord, Lord, have we not prophesied in thy name? and in thy name have cast out devils? and in thy name done many wonderful works?

Matthew 7:23 And then will I profess unto them, I never knew you: depart from me, ye that work iniquity.

Matthew 7:24 Therefore whosoever heareth these sayings of mine, and doeth them, I will liken him unto a wise man, which built his house upon a rock:

Matthew 7:25 And the rain descended, and the floods came, and the winds blew, and beat upon that house; and it fell not: for it was founded upon a rock.

Matthew 7:26 And every one that heareth these sayings of mine, and doeth them not, shall be likened unto a foolish man, which built his house upon the sand:

Matthew 7:27 And the rain descended, and the floods came, and the winds blew, and beat upon that house; and it fell: and great was the fall of it.

Matthew 7:28 And it came to pass, when Jesus had ended these sayings, the people were astonished at his doctrine:

Matthew 7:29 For he taught them as one having authority, and not as the scribes.
