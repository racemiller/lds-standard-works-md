# John 11

John 11 (summary): Jesus testifies that He is the Resurrection and the Life—Mary and Martha testify of Him—He raises Lazarus from the dead—Caiaphas speaks prophetically of the death of Jesus.

John 11:1 Now a certain man was sick, named Lazarus, of Bethany, the town of Mary and her sister Martha.

John 11:2 (It was that Mary which anointed the Lord with ointment, and wiped his feet with her hair, whose brother Lazarus was sick.)

John 11:3 Therefore his sisters sent unto him, saying, Lord, behold, he whom thou lovest is sick.

John 11:4 When Jesus heard that, he said, This sickness is not unto death, but for the glory of God, that the Son of God might be glorified thereby.

John 11:5 Now Jesus loved Martha, and her sister, and Lazarus.

John 11:6 When he had heard therefore that he was sick, he abode two days still in the same place where he was.

John 11:7 Then after that saith he to his disciples, Let us go into Judæa again.

John 11:8 His disciples say unto him, Master, the Jews of late sought to stone thee; and goest thou thither again?

John 11:9 Jesus answered, Are there not twelve hours in the day? If any man walk in the day, he stumbleth not, because he seeth the light of this world.

John 11:10 But if a man walk in the night, he stumbleth, because there is no light in him.

John 11:11 These things said he: and after that he saith unto them, Our friend Lazarus sleepeth; but I go, that I may awake him out of sleep.

John 11:12 Then said his disciples, Lord, if he sleep, he shall do well.

John 11:13 Howbeit Jesus spake of his death: but they thought that he had spoken of taking of rest in sleep.

John 11:14 Then said Jesus unto them plainly, Lazarus is dead.

John 11:15 And I am glad for your sakes that I was not there, to the intent ye may believe; nevertheless let us go unto him.

John 11:16 Then said Thomas, which is called Didymus, unto his fellowdisciples, Let us also go, that we may die with him.

John 11:17 Then when Jesus came, he found that he had lain in the grave four days already.

John 11:18 Now Bethany was nigh unto Jerusalem, about fifteen furlongs off:

John 11:19 And many of the Jews came to Martha and Mary, to comfort them concerning their brother.

John 11:20 Then Martha, as soon as she heard that Jesus was coming, went and met him: but Mary sat still in the house.

John 11:21 Then said Martha unto Jesus, Lord, if thou hadst been here, my brother had not died.

John 11:22 But I know, that even now, whatsoever thou wilt ask of God, God will give it thee.

John 11:23 Jesus saith unto her, Thy brother shall rise again.

John 11:24 Martha saith unto him, I know that he shall rise again in the resurrection at the last day.

John 11:25 Jesus said unto her, I am the resurrection, and the life: he that believeth in me, though he were dead, yet shall he live:

John 11:26 And whosoever liveth and believeth in me shall never die. Believest thou this?

John 11:27 She saith unto him, Yea, Lord: I believe that thou art the Christ, the Son of God, which should come into the world.

John 11:28 And when she had so said, she went her way, and called Mary her sister secretly, saying, The Master is come, and calleth for thee.

John 11:29 As soon as she heard that, she arose quickly, and came unto him.

John 11:30 Now Jesus was not yet come into the town, but was in that place where Martha met him.

John 11:31 The Jews then which were with her in the house, and comforted her, when they saw Mary, that she rose up hastily and went out, followed her, saying, She goeth unto the grave to weep there.

John 11:32 Then when Mary was come where Jesus was, and saw him, she fell down at his feet, saying unto him, Lord, if thou hadst been here, my brother had not died.

John 11:33 When Jesus therefore saw her weeping, and the Jews also weeping which came with her, he groaned in the spirit, and was troubled,

John 11:34 And said, Where have ye laid him? They said unto him, Lord, come and see.

John 11:35 Jesus wept.

John 11:36 Then said the Jews, Behold how he loved him!

John 11:37 And some of them said, Could not this man, which opened the eyes of the blind, have caused that even this man should not have died?

John 11:38 Jesus therefore again groaning in himself cometh to the grave. It was a cave, and a stone lay upon it.

John 11:39 Jesus said, Take ye away the stone. Martha, the sister of him that was dead, saith unto him, Lord, by this time he stinketh: for he hath been dead four days.

John 11:40 Jesus saith unto her, Said I not unto thee, that, if thou wouldest believe, thou shouldest see the glory of God?

John 11:41 Then they took away the stone from the place where the dead was laid. And Jesus lifted up his eyes, and said, Father, I thank thee that thou hast heard me.

John 11:42 And I knew that thou hearest me always: but because of the people which stand by I said it, that they may believe that thou hast sent me.

John 11:43 And when he thus had spoken, he cried with a loud voice, Lazarus, come forth.

John 11:44 And he that was dead came forth, bound hand and foot with graveclothes: and his face was bound about with a napkin. Jesus saith unto them, Loose him, and let him go.

John 11:45 Then many of the Jews which came to Mary, and had seen the things which Jesus did, believed on him.

John 11:46 But some of them went their ways to the Pharisees, and told them what things Jesus had done.

John 11:47 Then gathered the chief priests and the Pharisees a council, and said, What do we? for this man doeth many miracles.

John 11:48 If we let him thus alone, all men will believe on him: and the Romans shall come and take away both our place and nation.

John 11:49 And one of them, named Caiaphas, being the high priest that same year, said unto them, Ye know nothing at all,

John 11:50 Nor consider that it is expedient for us, that one man should die for the people, and that the whole nation perish not.

John 11:51 And this spake he not of himself: but being high priest that year, he prophesied that Jesus should die for that nation;

John 11:52 And not for that nation only, but that also he should gather together in one the children of God that were scattered abroad.

John 11:53 Then from that day forth they took counsel together for to put him to death.

John 11:54 Jesus therefore walked no more openly among the Jews; but went thence unto a country near to the wilderness, into a city called Ephraim, and there continued with his disciples.

John 11:55 And the Jews’ passover was nigh at hand: and many went out of the country up to Jerusalem before the passover, to purify themselves.

John 11:56 Then sought they for Jesus, and spake among themselves, as they stood in the temple, What think ye, that he will not come to the feast?

John 11:57 Now both the chief priests and the Pharisees had given a commandment, that, if any man knew where he were, he should shew it, that they might take him.
