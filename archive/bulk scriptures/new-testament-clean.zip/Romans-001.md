# Romans 1

Romans 1 (summary): The gospel is the power of God unto salvation through Jesus Christ—The wrath of God rests on those guilty of murder, homosexual practices, fornication, and other sins if the guilty do not repent.

Romans 1:1 Paul, a servant of Jesus Christ, called to be an apostle, separated unto the gospel of God,

Romans 1:2 (Which he had promised afore by his prophets in the holy scriptures,)

Romans 1:3 Concerning his Son Jesus Christ our Lord, which was made of the seed of David according to the flesh;

Romans 1:4 And declared to be the Son of God with power, according to the spirit of holiness, by the resurrection from the dead:

Romans 1:5 By whom we have received grace and apostleship, for obedience to the faith among all nations, for his name:

Romans 1:6 Among whom are ye also the called of Jesus Christ:

Romans 1:7 To all that be in Rome, beloved of God, called to be saints: Grace to you and peace from God our Father, and the Lord Jesus Christ.

Romans 1:8 First, I thank my God through Jesus Christ for you all, that your faith is spoken of throughout the whole world.

Romans 1:9 For God is my witness, whom I serve with my spirit in the gospel of his Son, that without ceasing I make mention of you always in my prayers;

Romans 1:10 Making request, if by any means now at length I might have a prosperous journey by the will of God to come unto you.

Romans 1:11 For I long to see you, that I may impart unto you some spiritual gift, to the end ye may be established;

Romans 1:12 That is, that I may be comforted together with you by the mutual faith both of you and me.

Romans 1:13 Now I would not have you ignorant, brethren, that oftentimes I purposed to come unto you, (but was let hitherto,) that I might have some fruit among you also, even as among other Gentiles.

Romans 1:14 I am debtor both to the Greeks, and to the Barbarians; both to the wise, and to the unwise.

Romans 1:15 So, as much as in me is, I am ready to preach the gospel to you that are at Rome also.

Romans 1:16 For I am not ashamed of the gospel of Christ: for it is the power of God unto salvation to every one that believeth; to the Jew first, and also to the Greek.

Romans 1:17 For therein is the righteousness of God revealed from faith to faith: as it is written, The just shall live by faith.

Romans 1:18 For the wrath of God is revealed from heaven against all ungodliness and unrighteousness of men, who hold the truth in unrighteousness;

Romans 1:19 Because that which may be known of God is manifest in them; for God hath shewed it unto them.

Romans 1:20 For the invisible things of him from the creation of the world are clearly seen, being understood by the things that are made, even his eternal power and Godhead; so that they are without excuse:

Romans 1:21 Because that, when they knew God, they glorified him not as God, neither were thankful; but became vain in their imaginations, and their foolish heart was darkened.

Romans 1:22 Professing themselves to be wise, they became fools,

Romans 1:23 And changed the glory of the uncorruptible God into an image made like to corruptible man, and to birds, and fourfooted beasts, and creeping things.

Romans 1:24 Wherefore God also gave them up to uncleanness through the lusts of their own hearts, to dishonour their own bodies between themselves:

Romans 1:25 Who changed the truth of God into a lie, and worshipped and served the creature more than the Creator, who is blessed for ever. Amen.

Romans 1:26 For this cause God gave them up unto vile affections: for even their women did change the natural use into that which is against nature:

Romans 1:27 And likewise also the men, leaving the natural use of the woman, burned in their lust one toward another; men with men working that which is unseemly, and receiving in themselves that recompence of their error which was meet.

Romans 1:28 And even as they did not like to retain God in their knowledge, God gave them over to a reprobate mind, to do those things which are not convenient;

Romans 1:29 Being filled with all unrighteousness, fornication, wickedness, covetousness, maliciousness; full of envy, murder, debate, deceit, malignity; whisperers,

Romans 1:30 Backbiters, haters of God, despiteful, proud, boasters, inventors of evil things, disobedient to parents,

Romans 1:31 Without understanding, covenantbreakers, without natural affection, implacable, unmerciful:

Romans 1:32 Who knowing the judgment of God, that they which commit such things are worthy of death, not only do the same, but have pleasure in them that do them.
