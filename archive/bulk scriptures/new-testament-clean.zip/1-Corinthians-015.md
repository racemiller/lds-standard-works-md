# 1 Corinthians 15

1 Corinthians 15 (summary): Christ died for our sins—He rose from the dead and was seen by many—All men will be resurrected—Paul speaks of baptism for the dead—The three degrees of glory are described—Victory over death comes through Christ.

1 Corinthians 15:1 Moreover, brethren, I declare unto you the gospel which I preached unto you, which also ye have received, and wherein ye stand;

1 Corinthians 15:2 By which also ye are saved, if ye keep in memory what I preached unto you, unless ye have believed in vain.

1 Corinthians 15:3 For I delivered unto you first of all that which I also received, how that Christ died for our sins according to the scriptures;

1 Corinthians 15:4 And that he was buried, and that he rose again the third day according to the scriptures:

1 Corinthians 15:5 And that he was seen of Cephas, then of the twelve:

1 Corinthians 15:6 After that, he was seen of above five hundred brethren at once; of whom the greater part remain unto this present, but some are fallen asleep.

1 Corinthians 15:7 After that, he was seen of James; then of all the apostles.

1 Corinthians 15:8 And last of all he was seen of me also, as of one born out of due time.

1 Corinthians 15:9 For I am the least of the apostles, that am not meet to be called an apostle, because I persecuted the church of God.

1 Corinthians 15:10 But by the grace of God I am what I am: and his grace which was bestowed upon me was not in vain; but I laboured more abundantly than they all: yet not I, but the grace of God which was with me.

1 Corinthians 15:11 Therefore whether it were I or they, so we preach, and so ye believed.

1 Corinthians 15:12 Now if Christ be preached that he rose from the dead, how say some among you that there is no resurrection of the dead?

1 Corinthians 15:13 But if there be no resurrection of the dead, then is Christ not risen:

1 Corinthians 15:14 And if Christ be not risen, then is our preaching vain, and your faith is also vain.

1 Corinthians 15:15 Yea, and we are found false witnesses of God; because we have testified of God that he raised up Christ: whom he raised not up, if so be that the dead rise not.

1 Corinthians 15:16 For if the dead rise not, then is not Christ raised:

1 Corinthians 15:17 And if Christ be not raised, your faith is vain; ye are yet in your sins.

1 Corinthians 15:18 Then they also which are fallen asleep in Christ are perished.

1 Corinthians 15:19 If in this life only we have hope in Christ, we are of all men most miserable.

1 Corinthians 15:20 But now is Christ risen from the dead, and become the firstfruits of them that slept.

1 Corinthians 15:21 For since by man came death, by man came also the resurrection of the dead.

1 Corinthians 15:22 For as in Adam all die, even so in Christ shall all be made alive.

1 Corinthians 15:23 But every man in his own order: Christ the firstfruits; afterward they that are Christ’s at his coming.

1 Corinthians 15:24 Then cometh the end, when he shall have delivered up the kingdom to God, even the Father; when he shall have put down all rule and all authority and power.

1 Corinthians 15:25 For he must reign, till he hath put all enemies under his feet.

1 Corinthians 15:26 The last enemy that shall be destroyed is death.

1 Corinthians 15:27 For he hath put all things under his feet. But when he saith all things are put under him, it is manifest that he is excepted, which did put all things under him.

1 Corinthians 15:28 And when all things shall be subdued unto him, then shall the Son also himself be subject unto him that put all things under him, that God may be all in all.

1 Corinthians 15:29 Else what shall they do which are baptized for the dead, if the dead rise not at all? why are they then baptized for the dead?

1 Corinthians 15:30 And why stand we in jeopardy every hour?

1 Corinthians 15:31 I protest by your rejoicing which I have in Christ Jesus our Lord, I die daily.

1 Corinthians 15:32 If after the manner of men I have fought with beasts at Ephesus, what advantageth it me, if the dead rise not? let us eat and drink; for to morrow we die.

1 Corinthians 15:33 Be not deceived: evil communications corrupt good manners.

1 Corinthians 15:34 Awake to righteousness, and sin not; for some have not the knowledge of God: I speak this to your shame.

1 Corinthians 15:35 But some man will say, How are the dead raised up? and with what body do they come?

1 Corinthians 15:36 Thou fool, that which thou sowest is not quickened, except it die:

1 Corinthians 15:37 And that which thou sowest, thou sowest not that body that shall be, but bare grain, it may chance of wheat, or of some other grain:

1 Corinthians 15:38 But God giveth it a body as it hath pleased him, and to every seed his own body.

1 Corinthians 15:39 All flesh is not the same flesh: but there is one kind of flesh of men, another flesh of beasts, another of fishes, and another of birds.

1 Corinthians 15:40 There are also celestial bodies, and bodies terrestrial: but the glory of the celestial is one, and the glory of the terrestrial is another.

1 Corinthians 15:41 There is one glory of the sun, and another glory of the moon, and another glory of the stars: for one star differeth from another star in glory.

1 Corinthians 15:42 So also is the resurrection of the dead. It is sown in corruption; it is raised in incorruption:

1 Corinthians 15:43 It is sown in dishonour; it is raised in glory: it is sown in weakness; it is raised in power:

1 Corinthians 15:44 It is sown a natural body; it is raised a spiritual body. There is a natural body, and there is a spiritual body.

1 Corinthians 15:45 And so it is written, The first man Adam was made a living soul; the last Adam was made a quickening spirit.

1 Corinthians 15:46 Howbeit that was not first which is spiritual, but that which is natural; and afterward that which is spiritual.

1 Corinthians 15:47 The first man is of the earth, earthy: the second man is the Lord from heaven.

1 Corinthians 15:48 As is the earthy, such are they also that are earthy: and as is the heavenly, such are they also that are heavenly.

1 Corinthians 15:49 And as we have borne the image of the earthy, we shall also bear the image of the heavenly.

1 Corinthians 15:50 Now this I say, brethren, that flesh and blood cannot inherit the kingdom of God; neither doth corruption inherit incorruption.

1 Corinthians 15:51 Behold, I shew you a mystery; We shall not all sleep, but we shall all be changed,

1 Corinthians 15:52 In a moment, in the twinkling of an eye, at the last trump: for the trumpet shall sound, and the dead shall be raised incorruptible, and we shall be changed.

1 Corinthians 15:53 For this corruptible must put on incorruption, and this mortal must put on immortality.

1 Corinthians 15:54 So when this corruptible shall have put on incorruption, and this mortal shall have put on immortality, then shall be brought to pass the saying that is written, Death is swallowed up in victory.

1 Corinthians 15:55 O death, where is thy sting? O grave, where is thy victory?

1 Corinthians 15:56 The sting of death is sin; and the strength of sin is the law.

1 Corinthians 15:57 But thanks be to God, which giveth us the victory through our Lord Jesus Christ.

1 Corinthians 15:58 Therefore, my beloved brethren, be ye steadfast, unmoveable, always abounding in the work of the Lord, forasmuch as ye know that your labour is not in vain in the Lord.
