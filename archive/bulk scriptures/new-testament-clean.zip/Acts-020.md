# Acts 20

Acts 20 (summary): Paul raises Eutychus from death—Paul is free from the blood of all men—He predicts apostasy from within the Church—He reveals a teaching from Jesus, It is more blessed to give than to receive.

Acts 20:1 And after the uproar was ceased, Paul called unto him the disciples, and embraced them, and departed for to go into Macedonia.

Acts 20:2 And when he had gone over those parts, and had given them much exhortation, he came into Greece,

Acts 20:3 And there abode three months. And when the Jews laid wait for him, as he was about to sail into Syria, he purposed to return through Macedonia.

Acts 20:4 And there accompanied him into Asia Sopater of Berea; and of the Thessalonians, Aristarchus and Secundus; and Gaius of Derbe, and Timotheus; and of Asia, Tychicus and Trophimus.

Acts 20:5 These going before tarried for us at Troas.

Acts 20:6 And we sailed away from Philippi after the days of unleavened bread, and came unto them to Troas in five days; where we abode seven days.

Acts 20:7 And upon the first day of the week, when the disciples came together to break bread, Paul preached unto them, ready to depart on the morrow; and continued his speech until midnight.

Acts 20:8 And there were many lights in the upper chamber, where they were gathered together.

Acts 20:9 And there sat in a window a certain young man named Eutychus, being fallen into a deep sleep: and as Paul was long preaching, he sunk down with sleep, and fell down from the third loft, and was taken up dead.

Acts 20:10 And Paul went down, and fell on him, and embracing him said, Trouble not yourselves; for his life is in him.

Acts 20:11 When he therefore was come up again, and had broken bread, and eaten, and talked a long while, even till break of day, so he departed.

Acts 20:12 And they brought the young man alive, and were not a little comforted.

Acts 20:13 And we went before to ship, and sailed unto Assos, there intending to take in Paul: for so had he appointed, minding himself to go afoot.

Acts 20:14 And when he met with us at Assos, we took him in, and came to Mitylene.

Acts 20:15 And we sailed thence, and came the next day over against Chios; and the next day we arrived at Samos, and tarried at Trogyllium; and the next day we came to Miletus.

Acts 20:16 For Paul had determined to sail by Ephesus, because he would not spend the time in Asia: for he hasted, if it were possible for him, to be at Jerusalem the day of Pentecost.

Acts 20:17 And from Miletus he sent to Ephesus, and called the elders of the church.

Acts 20:18 And when they were come to him, he said unto them, Ye know, from the first day that I came into Asia, after what manner I have been with you at all seasons,

Acts 20:19 Serving the Lord with all humility of mind, and with many tears, and temptations, which befell me by the lying in wait of the Jews:

Acts 20:20 And how I kept back nothing that was profitable unto you, but have shewed you, and have taught you publickly, and from house to house,

Acts 20:21 Testifying both to the Jews, and also to the Greeks, repentance toward God, and faith toward our Lord Jesus Christ.

Acts 20:22 And now, behold, I go bound in the spirit unto Jerusalem, not knowing the things that shall befall me there:

Acts 20:23 Save that the Holy Ghost witnesseth in every city, saying that bonds and afflictions abide me.

Acts 20:24 But none of these things move me, neither count I my life dear unto myself, so that I might finish my course with joy, and the ministry, which I have received of the Lord Jesus, to testify the gospel of the grace of God.

Acts 20:25 And now, behold, I know that ye all, among whom I have gone preaching the kingdom of God, shall see my face no more.

Acts 20:26 Wherefore I take you to record this day, that I am pure from the blood of all men.

Acts 20:27 For I have not shunned to declare unto you all the counsel of God.

Acts 20:28 Take heed therefore unto yourselves, and to all the flock, over the which the Holy Ghost hath made you overseers, to feed the church of God, which he hath purchased with his own blood.

Acts 20:29 For I know this, that after my departing shall grievous wolves enter in among you, not sparing the flock.

Acts 20:30 Also of your own selves shall men arise, speaking perverse things, to draw away disciples after them.

Acts 20:31 Therefore watch, and remember, that by the space of three years I ceased not to warn every one night and day with tears.

Acts 20:32 And now, brethren, I commend you to God, and to the word of his grace, which is able to build you up, and to give you an inheritance among all them which are sanctified.

Acts 20:33 I have coveted no man’s silver, or gold, or apparel.

Acts 20:34 Yea, ye yourselves know, that these hands have ministered unto my necessities, and to them that were with me.

Acts 20:35 I have shewed you all things, how that so labouring ye ought to support the weak, and to remember the words of the Lord Jesus, how he said, It is more blessed to give than to receive.

Acts 20:36 And when he had thus spoken, he kneeled down, and prayed with them all.

Acts 20:37 And they all wept sore, and fell on Paul’s neck, and kissed him,

Acts 20:38 Sorrowing most of all for the words which he spake, that they should see his face no more. And they accompanied him unto the ship.
