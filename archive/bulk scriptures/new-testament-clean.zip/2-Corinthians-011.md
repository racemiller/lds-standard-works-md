# 2 Corinthians 11

2 Corinthians 11 (summary): Maintain the simplicity that is in Christ—Satan sends forth false apostles—Paul glories in his sufferings for Christ.

2 Corinthians 11:1 Would to God ye could bear with me a little in my folly: and indeed bear with me.

2 Corinthians 11:2 For I am jealous over you with godly jealousy: for I have espoused you to one husband, that I may present you as a chaste virgin to Christ.

2 Corinthians 11:3 But I fear, lest by any means, as the serpent beguiled Eve through his subtilty, so your minds should be corrupted from the simplicity that is in Christ.

2 Corinthians 11:4 For if he that cometh preacheth another Jesus, whom we have not preached, or if ye receive another spirit, which ye have not received, or another gospel, which ye have not accepted, ye might well bear with him.

2 Corinthians 11:5 For I suppose I was not a whit behind the very chiefest apostles.

2 Corinthians 11:6 But though I be rude in speech, yet not in knowledge; but we have been throughly made manifest among you in all things.

2 Corinthians 11:7 Have I committed an offence in abasing myself that ye might be exalted, because I have preached to you the gospel of God freely?

2 Corinthians 11:8 I robbed other churches, taking wages of them, to do you service.

2 Corinthians 11:9 And when I was present with you, and wanted, I was chargeable to no man: for that which was lacking to me the brethren which came from Macedonia supplied: and in all things I have kept myself from being burdensome unto you, and so will I keep myself.

2 Corinthians 11:10 As the truth of Christ is in me, no man shall stop me of this boasting in the regions of Achaia.

2 Corinthians 11:11 Wherefore? because I love you not? God knoweth.

2 Corinthians 11:12 But what I do, that I will do, that I may cut off occasion from them which desire occasion; that wherein they glory, they may be found even as we.

2 Corinthians 11:13 For such are false apostles, deceitful workers, transforming themselves into the apostles of Christ.

2 Corinthians 11:14 And no marvel; for Satan himself is transformed into an angel of light.

2 Corinthians 11:15 Therefore it is no great thing if his ministers also be transformed as the ministers of righteousness; whose end shall be according to their works.

2 Corinthians 11:16 I say again, Let no man think me a fool; if otherwise, yet as a fool receive me, that I may boast myself a little.

2 Corinthians 11:17 That which I speak, I speak it not after the Lord, but as it were foolishly, in this confidence of boasting.

2 Corinthians 11:18 Seeing that many glory after the flesh, I will glory also.

2 Corinthians 11:19 For ye suffer fools gladly, seeing ye yourselves are wise.

2 Corinthians 11:20 For ye suffer, if a man bring you into bondage, if a man devour you, if a man take of you, if a man exalt himself, if a man smite you on the face.

2 Corinthians 11:21 I speak as concerning reproach, as though we had been weak. Howbeit whereinsoever any is bold, (I speak foolishly,) I am bold also.

2 Corinthians 11:22 Are they Hebrews? so am I. Are they Israelites? so am I. Are they the seed of Abraham? so am I.

2 Corinthians 11:23 Are they ministers of Christ? (I speak as a fool) I am more; in labours more abundant, in stripes above measure, in prisons more frequent, in deaths oft.

2 Corinthians 11:24 Of the Jews five times received I forty stripes save one.

2 Corinthians 11:25 Thrice was I beaten with rods, once was I stoned, thrice I suffered shipwreck, a night and a day I have been in the deep;

2 Corinthians 11:26 In journeyings often, in perils of waters, in perils of robbers, in perils by mine own countrymen, in perils by the heathen, in perils in the city, in perils in the wilderness, in perils in the sea, in perils among false brethren;

2 Corinthians 11:27 In weariness and painfulness, in watchings often, in hunger and thirst, in fastings often, in cold and nakedness.

2 Corinthians 11:28 Beside those things that are without, that which cometh upon me daily, the care of all the churches.

2 Corinthians 11:29 Who is weak, and I am not weak? who is offended, and I burn not?

2 Corinthians 11:30 If I must needs glory, I will glory of the things which concern mine infirmities.

2 Corinthians 11:31 The God and Father of our Lord Jesus Christ, which is blessed for evermore, knoweth that I lie not.

2 Corinthians 11:32 In Damascus the governor under Aretas the king kept the city of the Damascenes with a garrison, desirous to apprehend me:

2 Corinthians 11:33 And through a window in a basket was I let down by the wall, and escaped his hands.
