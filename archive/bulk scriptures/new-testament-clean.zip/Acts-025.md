# Acts 25

Acts 25 (summary): Paul, before Festus, appeals unto Cæsar—Agrippa desires to hear Paul.

Acts 25:1 Now when Festus was come into the province, after three days he ascended from Cæsarea to Jerusalem.

Acts 25:2 Then the high priest and the chief of the Jews informed him against Paul, and besought him,

Acts 25:3 And desired favour against him, that he would send for him to Jerusalem, laying wait in the way to kill him.

Acts 25:4 But Festus answered, that Paul should be kept at Cæsarea, and that he himself would depart shortly thither.

Acts 25:5 Let them therefore, said he, which among you are able, go down with me, and accuse this man, if there be any wickedness in him.

Acts 25:6 And when he had tarried among them more than ten days, he went down unto Cæsarea; and the next day sitting on the judgment seat commanded Paul to be brought.

Acts 25:7 And when he was come, the Jews which came down from Jerusalem stood round about, and laid many and grievous complaints against Paul, which they could not prove.

Acts 25:8 While he answered for himself, Neither against the law of the Jews, neither against the temple, nor yet against Cæsar, have I offended any thing at all.

Acts 25:9 But Festus, willing to do the Jews a pleasure, answered Paul, and said, Wilt thou go up to Jerusalem, and there be judged of these things before me?

Acts 25:10 Then said Paul, I stand at Cæsar’s judgment seat, where I ought to be judged: to the Jews have I done no wrong, as thou very well knowest.

Acts 25:11 For if I be an offender, or have committed any thing worthy of death, I refuse not to die: but if there be none of these things whereof these accuse me, no man may deliver me unto them. I appeal unto Cæsar.

Acts 25:12 Then Festus, when he had conferred with the council, answered, Hast thou appealed unto Cæsar? unto Cæsar shalt thou go.

Acts 25:13 And after certain days king Agrippa and Bernice came unto Cæsarea to salute Festus.

Acts 25:14 And when they had been there many days, Festus declared Paul’s cause unto the king, saying, There is a certain man left in bonds by Felix:

Acts 25:15 About whom, when I was at Jerusalem, the chief priests and the elders of the Jews informed me, desiring to have judgment against him.

Acts 25:16 To whom I answered, It is not the manner of the Romans to deliver any man to die, before that he which is accused have the accusers face to face, and have licence to answer for himself concerning the crime laid against him.

Acts 25:17 Therefore, when they were come hither, without any delay on the morrow I sat on the judgment seat, and commanded the man to be brought forth.

Acts 25:18 Against whom when the accusers stood up, they brought none accusation of such things as I supposed:

Acts 25:19 But had certain questions against him of their own superstition, and of one Jesus, which was dead, whom Paul affirmed to be alive.

Acts 25:20 And because I doubted of such manner of questions, I asked him whether he would go to Jerusalem, and there be judged of these matters.

Acts 25:21 But when Paul had appealed to be reserved unto the hearing of Augustus, I commanded him to be kept till I might send him to Cæsar.

Acts 25:22 Then Agrippa said unto Festus, I would also hear the man myself. To morrow, said he, thou shalt hear him.

Acts 25:23 And on the morrow, when Agrippa was come, and Bernice, with great pomp, and was entered into the place of hearing, with the chief captains, and principal men of the city, at Festus’ commandment Paul was brought forth.

Acts 25:24 And Festus said, King Agrippa, and all men which are here present with us, ye see this man, about whom all the multitude of the Jews have dealt with me, both at Jerusalem, and also here, crying that he ought not to live any longer.

Acts 25:25 But when I found that he had committed nothing worthy of death, and that he himself hath appealed to Augustus, I have determined to send him.

Acts 25:26 Of whom I have no certain thing to write unto my lord. Wherefore I have brought him forth before you, and specially before thee, O king Agrippa, that, after examination had, I might have somewhat to write.

Acts 25:27 For it seemeth to me unreasonable to send a prisoner, and not withal to signify the crimes laid against him.
