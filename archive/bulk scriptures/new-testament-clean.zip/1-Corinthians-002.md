# 1 Corinthians 2

1 Corinthians 2 (summary): The gospel is preached by the power of the Spirit—The Spirit reveals all things to the Saints—The unrepentant natural man cannot receive the things of the Spirit of God.

1 Corinthians 2:1 And I, brethren, when I came to you, came not with excellency of speech or of wisdom, declaring unto you the testimony of God.

1 Corinthians 2:2 For I determined not to know any thing among you, save Jesus Christ, and him crucified.

1 Corinthians 2:3 And I was with you in weakness, and in fear, and in much trembling.

1 Corinthians 2:4 And my speech and my preaching was not with enticing words of man’s wisdom, but in demonstration of the Spirit and of power:

1 Corinthians 2:5 That your faith should not stand in the wisdom of men, but in the power of God.

1 Corinthians 2:6 Howbeit we speak wisdom among them that are perfect: yet not the wisdom of this world, nor of the princes of this world, that come to nought:

1 Corinthians 2:7 But we speak the wisdom of God in a mystery, even the hidden wisdom, which God ordained before the world unto our glory:

1 Corinthians 2:8 Which none of the princes of this world knew: for had they known it, they would not have crucified the Lord of glory.

1 Corinthians 2:9 But as it is written, Eye hath not seen, nor ear heard, neither have entered into the heart of man, the things which God hath prepared for them that love him.

1 Corinthians 2:10 But God hath revealed them unto us by his Spirit: for the Spirit searcheth all things, yea, the deep things of God.

1 Corinthians 2:11 For what man knoweth the things of a man, save the spirit of man which is in him? even so the things of God knoweth no man, but the Spirit of God.

1 Corinthians 2:12 Now we have received, not the spirit of the world, but the spirit which is of God; that we might know the things that are freely given to us of God.

1 Corinthians 2:13 Which things also we speak, not in the words which man’s wisdom teacheth, but which the Holy Ghost teacheth; comparing spiritual things with spiritual.

1 Corinthians 2:14 But the natural man receiveth not the things of the Spirit of God: for they are foolishness unto him: neither can he know them, because they are spiritually discerned.

1 Corinthians 2:15 But he that is spiritual judgeth all things, yet he himself is judged of no man.

1 Corinthians 2:16 For who hath known the mind of the Lord, that he may instruct him? But we have the mind of Christ.
