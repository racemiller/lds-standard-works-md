# Matthew 12

Matthew 12 (summary): Jesus proclaims Himself Lord of the Sabbath and heals on the Sabbath day—He is accused of casting out devils through the power of Beelzebub—He speaks of blasphemy against the Holy Ghost and says that an evil and adulterous generation seeks signs.

Matthew 12:1 At that time Jesus went on the sabbath day through the corn; and his disciples were an hungred, and began to pluck the ears of corn, and to eat.

Matthew 12:2 But when the Pharisees saw it, they said unto him, Behold, thy disciples do that which is not lawful to do upon the sabbath day.

Matthew 12:3 But he said unto them, Have ye not read what David did, when he was an hungred, and they that were with him;

Matthew 12:4 How he entered into the house of God, and did eat the shewbread, which was not lawful for him to eat, neither for them which were with him, but only for the priests?

Matthew 12:5 Or have ye not read in the law, how that on the sabbath days the priests in the temple profane the sabbath, and are blameless?

Matthew 12:6 But I say unto you, That in this place is one greater than the temple.

Matthew 12:7 But if ye had known what this meaneth, I will have mercy, and not sacrifice, ye would not have condemned the guiltless.

Matthew 12:8 For the Son of man is Lord even of the sabbath day.

Matthew 12:9 And when he was departed thence, he went into their synagogue:

Matthew 12:10 And, behold, there was a man which had his hand withered. And they asked him, saying, Is it lawful to heal on the sabbath days? that they might accuse him.

Matthew 12:11 And he said unto them, What man shall there be among you, that shall have one sheep, and if it fall into a pit on the sabbath day, will he not lay hold on it, and lift it out?

Matthew 12:12 How much then is a man better than a sheep? Wherefore it is lawful to do well on the sabbath days.

Matthew 12:13 Then saith he to the man, Stretch forth thine hand. And he stretched it forth; and it was restored whole, like as the other.

Matthew 12:14 Then the Pharisees went out, and held a council against him, how they might destroy him.

Matthew 12:15 But when Jesus knew it, he withdrew himself from thence: and great multitudes followed him, and he healed them all;

Matthew 12:16 And charged them that they should not make him known:

Matthew 12:17 That it might be fulfilled which was spoken by Esaias the prophet, saying,

Matthew 12:18 Behold my servant, whom I have chosen; my beloved, in whom my soul is well pleased: I will put my spirit upon him, and he shall shew judgment to the Gentiles.

Matthew 12:19 He shall not strive, nor cry; neither shall any man hear his voice in the streets.

Matthew 12:20 A bruised reed shall he not break, and smoking flax shall he not quench, till he send forth judgment unto victory.

Matthew 12:21 And in his name shall the Gentiles trust.

Matthew 12:22 Then was brought unto him one possessed with a devil, blind, and dumb: and he healed him, insomuch that the blind and dumb both spake and saw.

Matthew 12:23 And all the people were amazed, and said, Is not this the son of David?

Matthew 12:24 But when the Pharisees heard it, they said, This fellow doth not cast out devils, but by Beelzebub the prince of the devils.

Matthew 12:25 And Jesus knew their thoughts, and said unto them, Every kingdom divided against itself is brought to desolation; and every city or house divided against itself shall not stand:

Matthew 12:26 And if Satan cast out Satan, he is divided against himself; how shall then his kingdom stand?

Matthew 12:27 And if I by Beelzebub cast out devils, by whom do your children cast them out? therefore they shall be your judges.

Matthew 12:28 But if I cast out devils by the Spirit of God, then the kingdom of God is come unto you.

Matthew 12:29 Or else how can one enter into a strong man’s house, and spoil his goods, except he first bind the strong man? and then he will spoil his house.

Matthew 12:30 He that is not with me is against me; and he that gathereth not with me scattereth abroad.

Matthew 12:31 Wherefore I say unto you, All manner of sin and blasphemy shall be forgiven unto men: but the blasphemy against the Holy Ghost shall not be forgiven unto men.

Matthew 12:32 And whosoever speaketh a word against the Son of man, it shall be forgiven him: but whosoever speaketh against the Holy Ghost, it shall not be forgiven him, neither in this world, neither in the world to come.

Matthew 12:33 Either make the tree good, and his fruit good; or else make the tree corrupt, and his fruit corrupt: for the tree is known by his fruit.

Matthew 12:34 O generation of vipers, how can ye, being evil, speak good things? for out of the abundance of the heart the mouth speaketh.

Matthew 12:35 A good man out of the good treasure of the heart bringeth forth good things: and an evil man out of the evil treasure bringeth forth evil things.

Matthew 12:36 But I say unto you, That every idle word that men shall speak, they shall give account thereof in the day of judgment.

Matthew 12:37 For by thy words thou shalt be justified, and by thy words thou shalt be condemned.

Matthew 12:38 Then certain of the scribes and of the Pharisees answered, saying, Master, we would see a sign from thee.

Matthew 12:39 But he answered and said unto them, An evil and adulterous generation seeketh after a sign; and there shall no sign be given to it, but the sign of the prophet Jonas:

Matthew 12:40 For as Jonas was three days and three nights in the whale’s belly; so shall the Son of man be three days and three nights in the heart of the earth.

Matthew 12:41 The men of Nineveh shall rise in judgment with this generation, and shall condemn it: because they repented at the preaching of Jonas; and, behold, a greater than Jonas is here.

Matthew 12:42 The queen of the south shall rise up in the judgment with this generation, and shall condemn it: for she came from the uttermost parts of the earth to hear the wisdom of Solomon; and, behold, a greater than Solomon is here.

Matthew 12:43 When the unclean spirit is gone out of a man, he walketh through dry places, seeking rest, and findeth none.

Matthew 12:44 Then he saith, I will return into my house from whence I came out; and when he is come, he findeth it empty, swept, and garnished.

Matthew 12:45 Then goeth he, and taketh with himself seven other spirits more wicked than himself, and they enter in and dwell there: and the last state of that man is worse than the first. Even so shall it be also unto this wicked generation.

Matthew 12:46 While he yet talked to the people, behold, his mother and his brethren stood without, desiring to speak with him.

Matthew 12:47 Then one said unto him, Behold, thy mother and thy brethren stand without, desiring to speak with thee.

Matthew 12:48 But he answered and said unto him that told him, Who is my mother? and who are my brethren?

Matthew 12:49 And he stretched forth his hand toward his disciples, and said, Behold my mother and my brethren!

Matthew 12:50 For whosoever shall do the will of my Father which is in heaven, the same is my brother, and sister, and mother.
