# Hebrews 10

Hebrews 10 (summary): We are sanctified by the shedding of the blood of Christ—The superiority of His sacrifice is explained—Those who fall from grace through willful sin are damned—The just will live by faith.

Hebrews 10:1 For the law having a shadow of good things to come, and not the very image of the things, can never with those sacrifices which they offered year by year continually make the comers thereunto perfect.

Hebrews 10:2 For then would they not have ceased to be offered? because that the worshippers once purged should have had no more conscience of sins.

Hebrews 10:3 But in those sacrifices there is a remembrance again made of sins every year.

Hebrews 10:4 For it is not possible that the blood of bulls and of goats should take away sins.

Hebrews 10:5 Wherefore when he cometh into the world, he saith, Sacrifice and offering thou wouldest not, but a body hast thou prepared me:

Hebrews 10:6 In burnt offerings and sacrifices for sin thou hast had no pleasure.

Hebrews 10:7 Then said I, Lo, I come (in the volume of the book it is written of me,) to do thy will, O God.

Hebrews 10:8 Above when he said, Sacrifice and offering and burnt offerings and offering for sin thou wouldest not, neither hadst pleasure therein; which are offered by the law;

Hebrews 10:9 Then said he, Lo, I come to do thy will, O God. He taketh away the first, that he may establish the second.

Hebrews 10:10 By the which will we are sanctified through the offering of the body of Jesus Christ once for all.

Hebrews 10:11 And every priest standeth daily ministering and offering oftentimes the same sacrifices, which can never take away sins:

Hebrews 10:12 But this man, after he had offered one sacrifice for sins for ever, sat down on the right hand of God;

Hebrews 10:13 From henceforth expecting till his enemies be made his footstool.

Hebrews 10:14 For by one offering he hath perfected for ever them that are sanctified.

Hebrews 10:15 Whereof the Holy Ghost also is a witness to us: for after that he had said before,

Hebrews 10:16 This is the covenant that I will make with them after those days, saith the Lord, I will put my laws into their hearts, and in their minds will I write them;

Hebrews 10:17 And their sins and iniquities will I remember no more.

Hebrews 10:18 Now where remission of these is, there is no more offering for sin.

Hebrews 10:19 Having therefore, brethren, boldness to enter into the holiest by the blood of Jesus,

Hebrews 10:20 By a new and living way, which he hath consecrated for us, through the veil, that is to say, his flesh;

Hebrews 10:21 And having an high priest over the house of God;

Hebrews 10:22 Let us draw near with a true heart in full assurance of faith, having our hearts sprinkled from an evil conscience, and our bodies washed with pure water.

Hebrews 10:23 Let us hold fast the profession of our faith without wavering; (for he is faithful that promised;)

Hebrews 10:24 And let us consider one another to provoke unto love and to good works:

Hebrews 10:25 Not forsaking the assembling of ourselves together, as the manner of some is; but exhorting one another: and so much the more, as ye see the day approaching.

Hebrews 10:26 For if we sin wilfully after that we have received the knowledge of the truth, there remaineth no more sacrifice for sins,

Hebrews 10:27 But a certain fearful looking for of judgment and fiery indignation, which shall devour the adversaries.

Hebrews 10:28 He that despised Moses’ law died without mercy under two or three witnesses:

Hebrews 10:29 Of how much sorer punishment, suppose ye, shall he be thought worthy, who hath trodden under foot the Son of God, and hath counted the blood of the covenant, wherewith he was sanctified, an unholy thing, and hath done despite unto the Spirit of grace?

Hebrews 10:30 For we know him that hath said, Vengeance belongeth unto me, I will recompense, saith the Lord. And again, The Lord shall judge his people.

Hebrews 10:31 It is a fearful thing to fall into the hands of the living God.

Hebrews 10:32 But call to remembrance the former days, in which, after ye were illuminated, ye endured a great fight of afflictions;

Hebrews 10:33 Partly, whilst ye were made a gazingstock both by reproaches and afflictions; and partly, whilst ye became companions of them that were so used.

Hebrews 10:34 For ye had compassion of me in my bonds, and took joyfully the spoiling of your goods, knowing in yourselves that ye have in heaven a better and an enduring substance.

Hebrews 10:35 Cast not away therefore your confidence, which hath great recompence of reward.

Hebrews 10:36 For ye have need of patience, that, after ye have done the will of God, ye might receive the promise.

Hebrews 10:37 For yet a little while, and he that shall come will come, and will not tarry.

Hebrews 10:38 Now the just shall live by faith: but if any man draw back, my soul shall have no pleasure in him.

Hebrews 10:39 But we are not of them who draw back unto perdition; but of them that believe to the saving of the soul.
