# Luke 23

Luke 23 (summary): Jesus is taken before Pilate, then to Herod, and then to Pilate again—Barabbas is released—Jesus is crucified between two thieves—He is buried in the tomb of Joseph of Arimathæa.

Luke 23:1 And the whole multitude of them arose, and led him unto Pilate.

Luke 23:2 And they began to accuse him, saying, We found this fellow perverting the nation, and forbidding to give tribute to Cæsar, saying that he himself is Christ a King.

Luke 23:3 And Pilate asked him, saying, Art thou the King of the Jews? And he answered him and said, Thou sayest it.

Luke 23:4 Then said Pilate to the chief priests and to the people, I find no fault in this man.

Luke 23:5 And they were the more fierce, saying, He stirreth up the people, teaching throughout all Jewry, beginning from Galilee to this place.

Luke 23:6 When Pilate heard of Galilee, he asked whether the man were a Galilæan.

Luke 23:7 And as soon as he knew that he belonged unto Herod’s jurisdiction, he sent him to Herod, who himself also was at Jerusalem at that time.

Luke 23:8 And when Herod saw Jesus, he was exceeding glad: for he was desirous to see him of a long season, because he had heard many things of him; and he hoped to have seen some miracle done by him.

Luke 23:9 Then he questioned with him in many words; but he answered him nothing.

Luke 23:10 And the chief priests and scribes stood and vehemently accused him.

Luke 23:11 And Herod with his men of war set him at nought, and mocked him, and arrayed him in a gorgeous robe, and sent him again to Pilate.

Luke 23:12 And the same day Pilate and Herod were made friends together: for before they were at enmity between themselves.

Luke 23:13 And Pilate, when he had called together the chief priests and the rulers and the people,

Luke 23:14 Said unto them, Ye have brought this man unto me, as one that perverteth the people: and, behold, I, having examined him before you, have found no fault in this man touching those things whereof ye accuse him:

Luke 23:15 No, nor yet Herod: for I sent you to him; and, lo, nothing worthy of death is done unto him.

Luke 23:16 I will therefore chastise him, and release him.

Luke 23:17 (For of necessity he must release one unto them at the feast.)

Luke 23:18 And they cried out all at once, saying, Away with this man, and release unto us Barabbas:

Luke 23:19 (Who for a certain sedition made in the city, and for murder, was cast into prison.)

Luke 23:20 Pilate therefore, willing to release Jesus, spake again to them.

Luke 23:21 But they cried, saying, Crucify him, crucify him.

Luke 23:22 And he said unto them the third time, Why, what evil hath he done? I have found no cause of death in him: I will therefore chastise him, and let him go.

Luke 23:23 And they were instant with loud voices, requiring that he might be crucified. And the voices of them and of the chief priests prevailed.

Luke 23:24 And Pilate gave sentence that it should be as they required.

Luke 23:25 And he released unto them him that for sedition and murder was cast into prison, whom they had desired; but he delivered Jesus to their will.

Luke 23:26 And as they led him away, they laid hold upon one Simon, a Cyrenian, coming out of the country, and on him they laid the cross, that he might bear it after Jesus.

Luke 23:27 And there followed him a great company of people, and of women, which also bewailed and lamented him.

Luke 23:28 But Jesus turning unto them said, Daughters of Jerusalem, weep not for me, but weep for yourselves, and for your children.

Luke 23:29 For, behold, the days are coming, in the which they shall say, Blessed are the barren, and the wombs that never bare, and the paps which never gave suck.

Luke 23:30 Then shall they begin to say to the mountains, Fall on us; and to the hills, Cover us.

Luke 23:31 For if they do these things in a green tree, what shall be done in the dry?

Luke 23:32 And there were also two other, malefactors, led with him to be put to death.

Luke 23:33 And when they were come to the place, which is called Calvary, there they crucified him, and the malefactors, one on the right hand, and the other on the left.

Luke 23:34 Then said Jesus, Father, forgive them; for they know not what they do. And they parted his raiment, and cast lots.

Luke 23:35 And the people stood beholding. And the rulers also with them derided him, saying, He saved others; let him save himself, if he be Christ, the chosen of God.

Luke 23:36 And the soldiers also mocked him, coming to him, and offering him vinegar,

Luke 23:37 And saying, If thou be the king of the Jews, save thyself.

Luke 23:38 And a superscription also was written over him in letters of Greek, and Latin, and Hebrew, This Is the King of the Jews.

Luke 23:39 And one of the malefactors which were hanged railed on him, saying, If thou be Christ, save thyself and us.

Luke 23:40 But the other answering rebuked him, saying, Dost not thou fear God, seeing thou art in the same condemnation?

Luke 23:41 And we indeed justly; for we receive the due reward of our deeds: but this man hath done nothing amiss.

Luke 23:42 And he said unto Jesus, Lord, remember me when thou comest into thy kingdom.

Luke 23:43 And Jesus said unto him, Verily I say unto thee, To day shalt thou be with me in paradise.

Luke 23:44 And it was about the sixth hour, and there was a darkness over all the earth until the ninth hour.

Luke 23:45 And the sun was darkened, and the veil of the temple was rent in the midst.

Luke 23:46 And when Jesus had cried with a loud voice, he said, Father, into thy hands I commend my spirit: and having said thus, he gave up the ghost.

Luke 23:47 Now when the centurion saw what was done, he glorified God, saying, Certainly this was a righteous man.

Luke 23:48 And all the people that came together to that sight, beholding the things which were done, smote their breasts, and returned.

Luke 23:49 And all his acquaintance, and the women that followed him from Galilee, stood afar off, beholding these things.

Luke 23:50 And, behold, there was a man named Joseph, a counsellor; and he was a good man, and a just:

Luke 23:51 (The same had not consented to the counsel and deed of them;) he was of Arimathæa, a city of the Jews: who also himself waited for the kingdom of God.

Luke 23:52 This man went unto Pilate, and begged the body of Jesus.

Luke 23:53 And he took it down, and wrapped it in linen, and laid it in a sepulchre that was hewn in stone, wherein never man before was laid.

Luke 23:54 And that day was the preparation, and the sabbath drew on.

Luke 23:55 And the women also, which came with him from Galilee, followed after, and beheld the sepulchre, and how his body was laid.

Luke 23:56 And they returned, and prepared spices and ointments; and rested the sabbath day according to the commandment.
