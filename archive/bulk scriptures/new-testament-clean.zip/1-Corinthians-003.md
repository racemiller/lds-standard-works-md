# 1 Corinthians 3

1 Corinthians 3 (summary): Milk comes before meat in the Church—Men’s works will be tried by fire—The Saints are the temple of God, and if they are faithful, they will inherit all things.

1 Corinthians 3:1 And I, brethren, could not speak unto you as unto spiritual, but as unto carnal, even as unto babes in Christ.

1 Corinthians 3:2 I have fed you with milk, and not with meat: for hitherto ye were not able to bear it, neither yet now are ye able.

1 Corinthians 3:3 For ye are yet carnal: for whereas there is among you envying, and strife, and divisions, are ye not carnal, and walk as men?

1 Corinthians 3:4 For while one saith, I am of Paul; and another, I am of Apollos; are ye not carnal?

1 Corinthians 3:5 Who then is Paul, and who is Apollos, but ministers by whom ye believed, even as the Lord gave to every man?

1 Corinthians 3:6 I have planted, Apollos watered; but God gave the increase.

1 Corinthians 3:7 So then neither is he that planteth any thing, neither he that watereth; but God that giveth the increase.

1 Corinthians 3:8 Now he that planteth and he that watereth are one: and every man shall receive his own reward according to his own labour.

1 Corinthians 3:9 For we are labourers together with God: ye are God’s husbandry, ye are God’s building.

1 Corinthians 3:10 According to the grace of God which is given unto me, as a wise masterbuilder, I have laid the foundation, and another buildeth thereon. But let every man take heed how he buildeth thereupon.

1 Corinthians 3:11 For other foundation can no man lay than that is laid, which is Jesus Christ.

1 Corinthians 3:12 Now if any man build upon this foundation gold, silver, precious stones, wood, hay, stubble;

1 Corinthians 3:13 Every man’s work shall be made manifest: for the day shall declare it, because it shall be revealed by fire; and the fire shall try every man’s work of what sort it is.

1 Corinthians 3:14 If any man’s work abide which he hath built thereupon, he shall receive a reward.

1 Corinthians 3:15 If any man’s work shall be burned, he shall suffer loss: but he himself shall be saved; yet so as by fire.

1 Corinthians 3:16 Know ye not that ye are the temple of God, and that the Spirit of God dwelleth in you?

1 Corinthians 3:17 If any man defile the temple of God, him shall God destroy; for the temple of God is holy, which temple ye are.

1 Corinthians 3:18 Let no man deceive himself. If any man among you seemeth to be wise in this world, let him become a fool, that he may be wise.

1 Corinthians 3:19 For the wisdom of this world is foolishness with God. For it is written, He taketh the wise in their own craftiness.

1 Corinthians 3:20 And again, The Lord knoweth the thoughts of the wise, that they are vain.

1 Corinthians 3:21 Therefore let no man glory in men. For all things are yours;

1 Corinthians 3:22 Whether Paul, or Apollos, or Cephas, or the world, or life, or death, or things present, or things to come; all are yours;

1 Corinthians 3:23 And ye are Christ’s; and Christ is God’s.
