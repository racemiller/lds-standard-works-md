# Mark 10

Mark 10 (summary): Jesus teaches the higher law of marriage—He blesses little children—Jesus counsels the rich young man, foretells His own death, and heals blind Bartimæus.

Mark 10:1 And he arose from thence, and cometh into the coasts of Judæa by the farther side of Jordan: and the people resort unto him again; and, as he was wont, he taught them again.

Mark 10:2 And the Pharisees came to him, and asked him, Is it lawful for a man to put away his wife? tempting him.

Mark 10:3 And he answered and said unto them, What did Moses command you?

Mark 10:4 And they said, Moses suffered to write a bill of divorcement, and to put her away.

Mark 10:5 And Jesus answered and said unto them, For the hardness of your heart he wrote you this precept.

Mark 10:6 But from the beginning of the creation God made them male and female.

Mark 10:7 For this cause shall a man leave his father and mother, and cleave to his wife;

Mark 10:8 And they twain shall be one flesh: so then they are no more twain, but one flesh.

Mark 10:9 What therefore God hath joined together, let not man put asunder.

Mark 10:10 And in the house his disciples asked him again of the same matter.

Mark 10:11 And he saith unto them, Whosoever shall put away his wife, and marry another, committeth adultery against her.

Mark 10:12 And if a woman shall put away her husband, and be married to another, she committeth adultery.

Mark 10:13 And they brought young children to him, that he should touch them: and his disciples rebuked those that brought them.

Mark 10:14 But when Jesus saw it, he was much displeased, and said unto them, Suffer the little children to come unto me, and forbid them not: for of such is the kingdom of God.

Mark 10:15 Verily I say unto you, Whosoever shall not receive the kingdom of God as a little child, he shall not enter therein.

Mark 10:16 And he took them up in his arms, put his hands upon them, and blessed them.

Mark 10:17 And when he was gone forth into the way, there came one running, and kneeled to him, and asked him, Good Master, what shall I do that I may inherit eternal life?

Mark 10:18 And Jesus said unto him, Why callest thou me good? there is none good but one, that is, God.

Mark 10:19 Thou knowest the commandments, Do not commit adultery, Do not kill, Do not steal, Do not bear false witness, Defraud not, Honour thy father and mother.

Mark 10:20 And he answered and said unto him, Master, all these have I observed from my youth.

Mark 10:21 Then Jesus beholding him loved him, and said unto him, One thing thou lackest: go thy way, sell whatsoever thou hast, and give to the poor, and thou shalt have treasure in heaven: and come, take up the cross, and follow me.

Mark 10:22 And he was sad at that saying, and went away grieved: for he had great possessions.

Mark 10:23 And Jesus looked round about, and saith unto his disciples, How hardly shall they that have riches enter into the kingdom of God!

Mark 10:24 And the disciples were astonished at his words. But Jesus answereth again, and saith unto them, Children, how hard is it for them that trust in riches to enter into the kingdom of God!

Mark 10:25 It is easier for a camel to go through the eye of a needle, than for a rich man to enter into the kingdom of God.

Mark 10:26 And they were astonished out of measure, saying among themselves, Who then can be saved?

Mark 10:27 And Jesus looking upon them saith, With men it is impossible, but not with God: for with God all things are possible.

Mark 10:28 Then Peter began to say unto him, Lo, we have left all, and have followed thee.

Mark 10:29 And Jesus answered and said, Verily I say unto you, There is no man that hath left house, or brethren, or sisters, or father, or mother, or wife, or children, or lands, for my sake, and the gospel’s,

Mark 10:30 But he shall receive an hundredfold now in this time, houses, and brethren, and sisters, and mothers, and children, and lands, with persecutions; and in the world to come eternal life.

Mark 10:31 But many that are first shall be last; and the last first.

Mark 10:32 And they were in the way going up to Jerusalem; and Jesus went before them: and they were amazed; and as they followed, they were afraid. And he took again the twelve, and began to tell them what things should happen unto him,

Mark 10:33 Saying, Behold, we go up to Jerusalem; and the Son of man shall be delivered unto the chief priests, and unto the scribes; and they shall condemn him to death, and shall deliver him to the Gentiles:

Mark 10:34 And they shall mock him, and shall scourge him, and shall spit upon him, and shall kill him: and the third day he shall rise again.

Mark 10:35 And James and John, the sons of Zebedee, come unto him, saying, Master, we would that thou shouldest do for us whatsoever we shall desire.

Mark 10:36 And he said unto them, What would ye that I should do for you?

Mark 10:37 They said unto him, Grant unto us that we may sit, one on thy right hand, and the other on thy left hand, in thy glory.

Mark 10:38 But Jesus said unto them, Ye know not what ye ask: can ye drink of the cup that I drink of? and be baptized with the baptism that I am baptized with?

Mark 10:39 And they said unto him, We can. And Jesus said unto them, Ye shall indeed drink of the cup that I drink of; and with the baptism that I am baptized withal shall ye be baptized:

Mark 10:40 But to sit on my right hand and on my left hand is not mine to give; but it shall be given to them for whom it is prepared.

Mark 10:41 And when the ten heard it, they began to be much displeased with James and John.

Mark 10:42 But Jesus called them to him, and saith unto them, Ye know that they which are accounted to rule over the Gentiles exercise lordship over them; and their great ones exercise authority upon them.

Mark 10:43 But so shall it not be among you: but whosoever will be great among you, shall be your minister:

Mark 10:44 And whosoever of you will be the chiefest, shall be servant of all.

Mark 10:45 For even the Son of man came not to be ministered unto, but to minister, and to give his life a ransom for many.

Mark 10:46 And they came to Jericho: and as he went out of Jericho with his disciples and a great number of people, blind Bartimæus, the son of Timæus, sat by the highway side begging.

Mark 10:47 And when he heard that it was Jesus of Nazareth, he began to cry out, and say, Jesus, thou Son of David, have mercy on me.

Mark 10:48 And many charged him that he should hold his peace: but he cried the more a great deal, Thou Son of David, have mercy on me.

Mark 10:49 And Jesus stood still, and commanded him to be called. And they call the blind man, saying unto him, Be of good comfort, rise; he calleth thee.

Mark 10:50 And he, casting away his garment, rose, and came to Jesus.

Mark 10:51 And Jesus answered and said unto him, What wilt thou that I should do unto thee? The blind man said unto him, Lord, that I might receive my sight.

Mark 10:52 And Jesus said unto him, Go thy way; thy faith hath made thee whole. And immediately he received his sight, and followed Jesus in the way.
