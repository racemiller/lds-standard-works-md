# Matthew 20

Matthew 20 (summary): Jesus gives the parable of the laborers in the vineyard—He foretells His crucifixion and resurrection—He came to give His life as a ransom for many.

Matthew 20:1 For the kingdom of heaven is like unto a man that is an householder, which went out early in the morning to hire labourers into his vineyard.

Matthew 20:2 And when he had agreed with the labourers for a penny a day, he sent them into his vineyard.

Matthew 20:3 And he went out about the third hour, and saw others standing idle in the marketplace,

Matthew 20:4 And said unto them; Go ye also into the vineyard, and whatsoever is right I will give you. And they went their way.

Matthew 20:5 Again he went out about the sixth and ninth hour, and did likewise.

Matthew 20:6 And about the eleventh hour he went out, and found others standing idle, and saith unto them, Why stand ye here all the day idle?

Matthew 20:7 They say unto him, Because no man hath hired us. He saith unto them, Go ye also into the vineyard; and whatsoever is right, that shall ye receive.

Matthew 20:8 So when even was come, the lord of the vineyard saith unto his steward, Call the labourers, and give them their hire, beginning from the last unto the first.

Matthew 20:9 And when they came that were hired about the eleventh hour, they received every man a penny.

Matthew 20:10 But when the first came, they supposed that they should have received more; and they likewise received every man a penny.

Matthew 20:11 And when they had received it, they murmured against the goodman of the house,

Matthew 20:12 Saying, These last have wrought but one hour, and thou hast made them equal unto us, which have borne the burden and heat of the day.

Matthew 20:13 But he answered one of them, and said, Friend, I do thee no wrong: didst not thou agree with me for a penny?

Matthew 20:14 Take that thine is, and go thy way: I will give unto this last, even as unto thee.

Matthew 20:15 Is it not lawful for me to do what I will with mine own? Is thine eye evil, because I am good?

Matthew 20:16 So the last shall be first, and the first last: for many be called, but few chosen.

Matthew 20:17 And Jesus going up to Jerusalem took the twelve disciples apart in the way, and said unto them,

Matthew 20:18 Behold, we go up to Jerusalem; and the Son of man shall be betrayed unto the chief priests and unto the scribes, and they shall condemn him to death,

Matthew 20:19 And shall deliver him to the Gentiles to mock, and to scourge, and to crucify him: and the third day he shall rise again.

Matthew 20:20 Then came to him the mother of Zebedee’s children with her sons, worshipping him, and desiring a certain thing of him.

Matthew 20:21 And he said unto her, What wilt thou? She saith unto him, Grant that these my two sons may sit, the one on thy right hand, and the other on the left, in thy kingdom.

Matthew 20:22 But Jesus answered and said, Ye know not what ye ask. Are ye able to drink of the cup that I shall drink of, and to be baptized with the baptism that I am baptized with? They say unto him, We are able.

Matthew 20:23 And he saith unto them, Ye shall drink indeed of my cup, and be baptized with the baptism that I am baptized with: but to sit on my right hand, and on my left, is not mine to give, but it shall be given to them for whom it is prepared of my Father.

Matthew 20:24 And when the ten heard it, they were moved with indignation against the two brethren.

Matthew 20:25 But Jesus called them unto him, and said, Ye know that the princes of the Gentiles exercise dominion over them, and they that are great exercise authority upon them.

Matthew 20:26 But it shall not be so among you: but whosoever will be great among you, let him be your minister;

Matthew 20:27 And whosoever will be chief among you, let him be your servant:

Matthew 20:28 Even as the Son of man came not to be ministered unto, but to minister, and to give his life a ransom for many.

Matthew 20:29 And as they departed from Jericho, a great multitude followed him.

Matthew 20:30 And, behold, two blind men sitting by the way side, when they heard that Jesus passed by, cried out, saying, Have mercy on us, O Lord, thou Son of David.

Matthew 20:31 And the multitude rebuked them, because they should hold their peace: but they cried the more, saying, Have mercy on us, O Lord, thou Son of David.

Matthew 20:32 And Jesus stood still, and called them, and said, What will ye that I shall do unto you?

Matthew 20:33 They say unto him, Lord, that our eyes may be opened.

Matthew 20:34 So Jesus had compassion on them, and touched their eyes: and immediately their eyes received sight, and they followed him.
