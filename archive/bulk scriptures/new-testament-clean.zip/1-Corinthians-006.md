# 1 Corinthians 6

1 Corinthians 6 (summary): Church members should not fight one another in the courts—The unrighteous will not be saved—True Saints are the temple of the Holy Ghost.

1 Corinthians 6:1 Dare any of you, having a matter against another, go to law before the unjust, and not before the saints?

1 Corinthians 6:2 Do ye not know that the saints shall judge the world? and if the world shall be judged by you, are ye unworthy to judge the smallest matters?

1 Corinthians 6:3 Know ye not that we shall judge angels? how much more things that pertain to this life?

1 Corinthians 6:4 If then ye have judgments of things pertaining to this life, set them to judge who are least esteemed in the church.

1 Corinthians 6:5 I speak to your shame. Is it so, that there is not a wise man among you? no, not one that shall be able to judge between his brethren?

1 Corinthians 6:6 But brother goeth to law with brother, and that before the unbelievers.

1 Corinthians 6:7 Now therefore there is utterly a fault among you, because ye go to law one with another. Why do ye not rather take wrong? why do ye not rather suffer yourselves to be defrauded?

1 Corinthians 6:8 Nay, ye do wrong, and defraud, and that your brethren.

1 Corinthians 6:9 Know ye not that the unrighteous shall not inherit the kingdom of God? Be not deceived: neither fornicators, nor idolaters, nor adulterers, nor effeminate, nor abusers of themselves with mankind,

1 Corinthians 6:10 Nor thieves, nor covetous, nor drunkards, nor revilers, nor extortioners, shall inherit the kingdom of God.

1 Corinthians 6:11 And such were some of you: but ye are washed, but ye are sanctified, but ye are justified in the name of the Lord Jesus, and by the Spirit of our God.

1 Corinthians 6:12 All things are lawful unto me, but all things are not expedient: all things are lawful for me, but I will not be brought under the power of any.

1 Corinthians 6:13 Meats for the belly, and the belly for meats: but God shall destroy both it and them. Now the body is not for fornication, but for the Lord; and the Lord for the body.

1 Corinthians 6:14 And God hath both raised up the Lord, and will also raise up us by his own power.

1 Corinthians 6:15 Know ye not that your bodies are the members of Christ? shall I then take the members of Christ, and make them the members of an harlot? God forbid.

1 Corinthians 6:16 What? know ye not that he which is joined to an harlot is one body? for two, saith he, shall be one flesh.

1 Corinthians 6:17 But he that is joined unto the Lord is one spirit.

1 Corinthians 6:18 Flee fornication. Every sin that a man doeth is without the body; but he that committeth fornication sinneth against his own body.

1 Corinthians 6:19 What? know ye not that your body is the temple of the Holy Ghost which is in you, which ye have of God, and ye are not your own?

1 Corinthians 6:20 For ye are bought with a price: therefore glorify God in your body, and in your spirit, which are God’s.
