# Matthew 17

Matthew 17 (summary): Jesus is transfigured before Peter, James, and John on the mount—Jesus heals a lunatic, tells of His coming death, and pays taxes in a miraculous manner.

Matthew 17:1 And after six days Jesus taketh Peter, James, and John his brother, and bringeth them up into an high mountain apart,

Matthew 17:2 And was transfigured before them: and his face did shine as the sun, and his raiment was white as the light.

Matthew 17:3 And, behold, there appeared unto them Moses and Elias talking with him.

Matthew 17:4 Then answered Peter, and said unto Jesus, Lord, it is good for us to be here: if thou wilt, let us make here three tabernacles; one for thee, and one for Moses, and one for Elias.

Matthew 17:5 While he yet spake, behold, a bright cloud overshadowed them: and behold a voice out of the cloud, which said, This is my beloved Son, in whom I am well pleased; hear ye him.

Matthew 17:6 And when the disciples heard it, they fell on their face, and were sore afraid.

Matthew 17:7 And Jesus came and touched them, and said, Arise, and be not afraid.

Matthew 17:8 And when they had lifted up their eyes, they saw no man, save Jesus only.

Matthew 17:9 And as they came down from the mountain, Jesus charged them, saying, Tell the vision to no man, until the Son of man be risen again from the dead.

Matthew 17:10 And his disciples asked him, saying, Why then say the scribes that Elias must first come?

Matthew 17:11 And Jesus answered and said unto them, Elias truly shall first come, and restore all things.

Matthew 17:12 But I say unto you, That Elias is come already, and they knew him not, but have done unto him whatsoever they listed. Likewise shall also the Son of man suffer of them.

Matthew 17:13 Then the disciples understood that he spake unto them of John the Baptist.

Matthew 17:14 And when they were come to the multitude, there came to him a certain man, kneeling down to him, and saying,

Matthew 17:15 Lord, have mercy on my son: for he is lunatic, and sore vexed: for ofttimes he falleth into the fire, and oft into the water.

Matthew 17:16 And I brought him to thy disciples, and they could not cure him.

Matthew 17:17 Then Jesus answered and said, O faithless and perverse generation, how long shall I be with you? how long shall I suffer you? bring him hither to me.

Matthew 17:18 And Jesus rebuked the devil; and he departed out of him: and the child was cured from that very hour.

Matthew 17:19 Then came the disciples to Jesus apart, and said, Why could not we cast him out?

Matthew 17:20 And Jesus said unto them, Because of your unbelief: for verily I say unto you, If ye have faith as a grain of mustard seed, ye shall say unto this mountain, Remove hence to yonder place; and it shall remove; and nothing shall be impossible unto you.

Matthew 17:21 Howbeit this kind goeth not out but by prayer and fasting.

Matthew 17:22 And while they abode in Galilee, Jesus said unto them, The Son of man shall be betrayed into the hands of men:

Matthew 17:23 And they shall kill him, and the third day he shall be raised again. And they were exceeding sorry.

Matthew 17:24 And when they were come to Capernaum, they that received tribute money came to Peter, and said, Doth not your master pay tribute?

Matthew 17:25 He saith, Yes. And when he was come into the house, Jesus prevented him, saying, What thinkest thou, Simon? of whom do the kings of the earth take custom or tribute? of their own children, or of strangers?

Matthew 17:26 Peter saith unto him, Of strangers. Jesus saith unto him, Then are the children free.

Matthew 17:27 Notwithstanding, lest we should offend them, go thou to the sea, and cast an hook, and take up the fish that first cometh up; and when thou hast opened his mouth, thou shalt find a piece of money: that take, and give unto them for me and thee.
