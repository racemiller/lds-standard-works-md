# John 4

John 4 (summary): Jesus teaches a woman of Samaria—All must worship the Father in spirit and truth—Those who harvest souls gain eternal life—Many Samaritans believe—Jesus heals a nobleman’s son.

John 4:1 When therefore the Lord knew how the Pharisees had heard that Jesus made and baptized more disciples than John,

John 4:2 (Though Jesus himself baptized not, but his disciples,)

John 4:3 He left Judæa, and departed again into Galilee.

John 4:4 And he must needs go through Samaria.

John 4:5 Then cometh he to a city of Samaria, which is called Sychar, near to the parcel of ground that Jacob gave to his son Joseph.

John 4:6 Now Jacob’s well was there. Jesus therefore, being wearied with his journey, sat thus on the well: and it was about the sixth hour.

John 4:7 There cometh a woman of Samaria to draw water: Jesus saith unto her, Give me to drink.

John 4:8 (For his disciples were gone away unto the city to buy meat.)

John 4:9 Then saith the woman of Samaria unto him, How is it that thou, being a Jew, askest drink of me, which am a woman of Samaria? for the Jews have no dealings with the Samaritans.

John 4:10 Jesus answered and said unto her, If thou knewest the gift of God, and who it is that saith to thee, Give me to drink; thou wouldest have asked of him, and he would have given thee living water.

John 4:11 The woman saith unto him, Sir, thou hast nothing to draw with, and the well is deep: from whence then hast thou that living water?

John 4:12 Art thou greater than our father Jacob, which gave us the well, and drank thereof himself, and his children, and his cattle?

John 4:13 Jesus answered and said unto her, Whosoever drinketh of this water shall thirst again:

John 4:14 But whosoever drinketh of the water that I shall give him shall never thirst; but the water that I shall give him shall be in him a well of water springing up into everlasting life.

John 4:15 The woman saith unto him, Sir, give me this water, that I thirst not, neither come hither to draw.

John 4:16 Jesus saith unto her, Go, call thy husband, and come hither.

John 4:17 The woman answered and said, I have no husband. Jesus said unto her, Thou hast well said, I have no husband:

John 4:18 For thou hast had five husbands; and he whom thou now hast is not thy husband: in that saidst thou truly.

John 4:19 The woman saith unto him, Sir, I perceive that thou art a prophet.

John 4:20 Our fathers worshipped in this mountain; and ye say, that in Jerusalem is the place where men ought to worship.

John 4:21 Jesus saith unto her, Woman, believe me, the hour cometh, when ye shall neither in this mountain, nor yet at Jerusalem, worship the Father.

John 4:22 Ye worship ye know not what: we know what we worship: for salvation is of the Jews.

John 4:23 But the hour cometh, and now is, when the true worshippers shall worship the Father in spirit and in truth: for the Father seeketh such to worship him.

John 4:24 God is a Spirit: and they that worship him must worship him in spirit and in truth.

John 4:25 The woman saith unto him, I know that Messias cometh, which is called Christ: when he is come, he will tell us all things.

John 4:26 Jesus saith unto her, I that speak unto thee am he.

John 4:27 And upon this came his disciples, and marvelled that he talked with the woman: yet no man said, What seekest thou? or, Why talkest thou with her?

John 4:28 The woman then left her waterpot, and went her way into the city, and saith to the men,

John 4:29 Come, see a man, which told me all things that ever I did: is not this the Christ?

John 4:30 Then they went out of the city, and came unto him.

John 4:31 In the mean while his disciples prayed him, saying, Master, eat.

John 4:32 But he said unto them, I have meat to eat that ye know not of.

John 4:33 Therefore said the disciples one to another, Hath any man brought him ought to eat?

John 4:34 Jesus saith unto them, My meat is to do the will of him that sent me, and to finish his work.

John 4:35 Say not ye, There are yet four months, and then cometh harvest? behold, I say unto you, Lift up your eyes, and look on the fields; for they are white already to harvest.

John 4:36 And he that reapeth receiveth wages, and gathereth fruit unto life eternal: that both he that soweth and he that reapeth may rejoice together.

John 4:37 And herein is that saying true, One soweth, and another reapeth.

John 4:38 I sent you to reap that whereon ye bestowed no labour: other men laboured, and ye are entered into their labours.

John 4:39 And many of the Samaritans of that city believed on him for the saying of the woman, which testified, He told me all that ever I did.

John 4:40 So when the Samaritans were come unto him, they besought him that he would tarry with them: and he abode there two days.

John 4:41 And many more believed because of his own word;

John 4:42 And said unto the woman, Now we believe, not because of thy saying: for we have heard him ourselves, and know that this is indeed the Christ, the Saviour of the world.

John 4:43 Now after two days he departed thence, and went into Galilee.

John 4:44 For Jesus himself testified, that a prophet hath no honour in his own country.

John 4:45 Then when he was come into Galilee, the Galilæans received him, having seen all the things that he did at Jerusalem at the feast: for they also went unto the feast.

John 4:46 So Jesus came again into Cana of Galilee, where he made the water wine. And there was a certain nobleman, whose son was sick at Capernaum.

John 4:47 When he heard that Jesus was come out of Judæa into Galilee, he went unto him, and besought him that he would come down, and heal his son: for he was at the point of death.

John 4:48 Then said Jesus unto him, Except ye see signs and wonders, ye will not believe.

John 4:49 The nobleman saith unto him, Sir, come down ere my child die.

John 4:50 Jesus saith unto him, Go thy way; thy son liveth. And the man believed the word that Jesus had spoken unto him, and he went his way.

John 4:51 And as he was now going down, his servants met him, and told him, saying, Thy son liveth.

John 4:52 Then inquired he of them the hour when he began to amend. And they said unto him, Yesterday at the seventh hour the fever left him.

John 4:53 So the father knew that it was at the same hour, in the which Jesus said unto him, Thy son liveth: and himself believed, and his whole house.

John 4:54 This is again the second miracle that Jesus did, when he was come out of Judæa into Galilee.
