# 1 Peter 5

1 Peter 5 (summary): The elders are to feed the flock of God—Humility and godly graces lead to perfection.

1 Peter 5:1 The elders which are among you I exhort, who am also an elder, and a witness of the sufferings of Christ, and also a partaker of the glory that shall be revealed:

1 Peter 5:2 Feed the flock of God which is among you, taking the oversight thereof, not by constraint, but willingly; not for filthy lucre, but of a ready mind;

1 Peter 5:3 Neither as being lords over God’s heritage, but being ensamples to the flock.

1 Peter 5:4 And when the chief Shepherd shall appear, ye shall receive a crown of glory that fadeth not away.

1 Peter 5:5 Likewise, ye younger, submit yourselves unto the elder. Yea, all of you be subject one to another, and be clothed with humility: for God resisteth the proud, and giveth grace to the humble.

1 Peter 5:6 Humble yourselves therefore under the mighty hand of God, that he may exalt you in due time:

1 Peter 5:7 Casting all your care upon him; for he careth for you.

1 Peter 5:8 Be sober, be vigilant; because your adversary the devil, as a roaring lion, walketh about, seeking whom he may devour:

1 Peter 5:9 Whom resist steadfast in the faith, knowing that the same afflictions are accomplished in your brethren that are in the world.

1 Peter 5:10 But the God of all grace, who hath called us unto his eternal glory by Christ Jesus, after that ye have suffered a while, make you perfect, stablish, strengthen, settle you.

1 Peter 5:11 To him be glory and dominion for ever and ever. Amen.

1 Peter 5:12 By Silvanus, a faithful brother unto you, as I suppose, I have written briefly, exhorting, and testifying that this is the true grace of God wherein ye stand.

1 Peter 5:13 The church that is at Babylon, elected together with you, saluteth you; and so doth Marcus my son.

1 Peter 5:14 Greet ye one another with a kiss of charity. Peace be with you all that are in Christ Jesus. Amen.
