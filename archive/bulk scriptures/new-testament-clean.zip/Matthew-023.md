# Matthew 23

Matthew 23 (summary): Jesus pronounces woes upon the scribes and Pharisees—They will be held responsible for killing the prophets—They will not escape the damnation of hell.

Matthew 23:1 Then spake Jesus to the multitude, and to his disciples,

Matthew 23:2 Saying, The scribes and the Pharisees sit in Moses’ seat:

Matthew 23:3 All therefore whatsoever they bid you observe, that observe and do; but do not ye after their works: for they say, and do not.

Matthew 23:4 For they bind heavy burdens and grievous to be borne, and lay them on men’s shoulders; but they themselves will not move them with one of their fingers.

Matthew 23:5 But all their works they do for to be seen of men: they make broad their phylacteries, and enlarge the borders of their garments,

Matthew 23:6 And love the uppermost rooms at feasts, and the chief seats in the synagogues,

Matthew 23:7 And greetings in the markets, and to be called of men, Rabbi, Rabbi.

Matthew 23:8 But be not ye called Rabbi: for one is your Master, even Christ; and all ye are brethren.

Matthew 23:9 And call no man your father upon the earth: for one is your Father, which is in heaven.

Matthew 23:10 Neither be ye called masters: for one is your Master, even Christ.

Matthew 23:11 But he that is greatest among you shall be your servant.

Matthew 23:12 And whosoever shall exalt himself shall be abased; and he that shall humble himself shall be exalted.

Matthew 23:13 But woe unto you, scribes and Pharisees, hypocrites! for ye shut up the kingdom of heaven against men: for ye neither go in yourselves, neither suffer ye them that are entering to go in.

Matthew 23:14 Woe unto you, scribes and Pharisees, hypocrites! for ye devour widows’ houses, and for a pretence make long prayer: therefore ye shall receive the greater damnation.

Matthew 23:15 Woe unto you, scribes and Pharisees, hypocrites! for ye compass sea and land to make one proselyte, and when he is made, ye make him twofold more the child of hell than yourselves.

Matthew 23:16 Woe unto you, ye blind guides, which say, Whosoever shall swear by the temple, it is nothing; but whosoever shall swear by the gold of the temple, he is a debtor!

Matthew 23:17 Ye fools and blind: for whether is greater, the gold, or the temple that sanctifieth the gold?

Matthew 23:18 And, Whosoever shall swear by the altar, it is nothing; but whosoever sweareth by the gift that is upon it, he is guilty.

Matthew 23:19 Ye fools and blind: for whether is greater, the gift, or the altar that sanctifieth the gift?

Matthew 23:20 Whoso therefore shall swear by the altar, sweareth by it, and by all things thereon.

Matthew 23:21 And whoso shall swear by the temple, sweareth by it, and by him that dwelleth therein.

Matthew 23:22 And he that shall swear by heaven, sweareth by the throne of God, and by him that sitteth thereon.

Matthew 23:23 Woe unto you, scribes and Pharisees, hypocrites! for ye pay tithe of mint and anise and cummin, and have omitted the weightier matters of the law, judgment, mercy, and faith: these ought ye to have done, and not to leave the other undone.

Matthew 23:24 Ye blind guides, which strain at a gnat, and swallow a camel.

Matthew 23:25 Woe unto you, scribes and Pharisees, hypocrites! for ye make clean the outside of the cup and of the platter, but within they are full of extortion and excess.

Matthew 23:26 Thou blind Pharisee, cleanse first that which is within the cup and platter, that the outside of them may be clean also.

Matthew 23:27 Woe unto you, scribes and Pharisees, hypocrites! for ye are like unto whited sepulchres, which indeed appear beautiful outward, but are within full of dead men’s bones, and of all uncleanness.

Matthew 23:28 Even so ye also outwardly appear righteous unto men, but within ye are full of hypocrisy and iniquity.

Matthew 23:29 Woe unto you, scribes and Pharisees, hypocrites! because ye build the tombs of the prophets, and garnish the sepulchres of the righteous,

Matthew 23:30 And say, If we had been in the days of our fathers, we would not have been partakers with them in the blood of the prophets.

Matthew 23:31 Wherefore ye be witnesses unto yourselves, that ye are the children of them which killed the prophets.

Matthew 23:32 Fill ye up then the measure of your fathers.

Matthew 23:33 Ye serpents, ye generation of vipers, how can ye escape the damnation of hell?

Matthew 23:34 Wherefore, behold, I send unto you prophets, and wise men, and scribes: and some of them ye shall kill and crucify; and some of them shall ye scourge in your synagogues, and persecute them from city to city:

Matthew 23:35 That upon you may come all the righteous blood shed upon the earth, from the blood of righteous Abel unto the blood of Zacharias son of Barachias, whom ye slew between the temple and the altar.

Matthew 23:36 Verily I say unto you, All these things shall come upon this generation.

Matthew 23:37 O Jerusalem, Jerusalem, thou that killest the prophets, and stonest them which are sent unto thee, how often would I have gathered thy children together, even as a hen gathereth her chickens under her wings, and ye would not!

Matthew 23:38 Behold, your house is left unto you desolate.

Matthew 23:39 For I say unto you, Ye shall not see me henceforth, till ye shall say, Blessed is he that cometh in the name of the Lord.
