# Revelation 21

Revelation 21 (summary): Those who overcome will be sons of God—The earth attains its celestial glory.

Revelation 21:1 And I saw a new heaven and a new earth: for the first heaven and the first earth were passed away; and there was no more sea.

Revelation 21:2 And I John saw the holy city, new Jerusalem, coming down from God out of heaven, prepared as a bride adorned for her husband.

Revelation 21:3 And I heard a great voice out of heaven saying, Behold, the tabernacle of God is with men, and he will dwell with them, and they shall be his people, and God himself shall be with them, and be their God.

Revelation 21:4 And God shall wipe away all tears from their eyes; and there shall be no more death, neither sorrow, nor crying, neither shall there be any more pain: for the former things are passed away.

Revelation 21:5 And he that sat upon the throne said, Behold, I make all things new. And he said unto me, Write: for these words are true and faithful.

Revelation 21:6 And he said unto me, It is done. I am Alpha and Omega, the beginning and the end. I will give unto him that is athirst of the fountain of the water of life freely.

Revelation 21:7 He that overcometh shall inherit all things; and I will be his God, and he shall be my son.

Revelation 21:8 But the fearful, and unbelieving, and the abominable, and murderers, and whoremongers, and sorcerers, and idolaters, and all liars, shall have their part in the lake which burneth with fire and brimstone: which is the second death.

Revelation 21:9 And there came unto me one of the seven angels which had the seven vials full of the seven last plagues, and talked with me, saying, Come hither, I will shew thee the bride, the Lamb’s wife.

Revelation 21:10 And he carried me away in the spirit to a great and high mountain, and shewed me that great city, the holy Jerusalem, descending out of heaven from God,

Revelation 21:11 Having the glory of God: and her light was like unto a stone most precious, even like a jasper stone, clear as crystal;

Revelation 21:12 And had a wall great and high, and had twelve gates, and at the gates twelve angels, and names written thereon, which are the names of the twelve tribes of the children of Israel:

Revelation 21:13 On the east three gates; on the north three gates; on the south three gates; and on the west three gates.

Revelation 21:14 And the wall of the city had twelve foundations, and in them the names of the twelve apostles of the Lamb.

Revelation 21:15 And he that talked with me had a golden reed to measure the city, and the gates thereof, and the wall thereof.

Revelation 21:16 And the city lieth foursquare, and the length is as large as the breadth: and he measured the city with the reed, twelve thousand furlongs. The length and the breadth and the height of it are equal.

Revelation 21:17 And he measured the wall thereof, an hundred and forty and four cubits, according to the measure of a man, that is, of the angel.

Revelation 21:18 And the building of the wall of it was of jasper: and the city was pure gold, like unto clear glass.

Revelation 21:19 And the foundations of the wall of the city were garnished with all manner of precious stones. The first foundation was jasper; the second, sapphire; the third, a chalcedony; the fourth, an emerald;

Revelation 21:20 The fifth, sardonyx; the sixth, sardius; the seventh, chrysolite; the eighth, beryl; the ninth, a topaz; the tenth, a chrysoprasus; the eleventh, a jacinth; the twelfth, an amethyst.

Revelation 21:21 And the twelve gates were twelve pearls; every several gate was of one pearl: and the street of the city was pure gold, as it were transparent glass.

Revelation 21:22 And I saw no temple therein: for the Lord God Almighty and the Lamb are the temple of it.

Revelation 21:23 And the city had no need of the sun, neither of the moon, to shine in it: for the glory of God did lighten it, and the Lamb is the light thereof.

Revelation 21:24 And the nations of them which are saved shall walk in the light of it: and the kings of the earth do bring their glory and honour into it.

Revelation 21:25 And the gates of it shall not be shut at all by day: for there shall be no night there.

Revelation 21:26 And they shall bring the glory and honour of the nations into it.

Revelation 21:27 And there shall in no wise enter into it any thing that defileth, neither whatsoever worketh abomination, or maketh a lie: but they which are written in the Lamb’s book of life.
