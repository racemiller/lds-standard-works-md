# 1 Corinthians 8

1 Corinthians 8 (summary): There are many gods and many lords—To us there is one God (the Father) and one Lord, who is Christ.

1 Corinthians 8:1 Now as touching things offered unto idols, we know that we all have knowledge. Knowledge puffeth up, but charity edifieth.

1 Corinthians 8:2 And if any man think that he knoweth any thing, he knoweth nothing yet as he ought to know.

1 Corinthians 8:3 But if any man love God, the same is known of him.

1 Corinthians 8:4 As concerning therefore the eating of those things that are offered in sacrifice unto idols, we know that an idol is nothing in the world, and that there is none other God but one.

1 Corinthians 8:5 For though there be that are called gods, whether in heaven or in earth, (as there be gods many, and lords many,)

1 Corinthians 8:6 But to us there is but one God, the Father, of whom are all things, and we in him; and one Lord Jesus Christ, by whom are all things, and we by him.

1 Corinthians 8:7 Howbeit there is not in every man that knowledge: for some with conscience of the idol unto this hour eat it as a thing offered unto an idol; and their conscience being weak is defiled.

1 Corinthians 8:8 But meat commendeth us not to God: for neither, if we eat, are we the better; neither, if we eat not, are we the worse.

1 Corinthians 8:9 But take heed lest by any means this liberty of yours become a stumblingblock to them that are weak.

1 Corinthians 8:10 For if any man see thee which hast knowledge sit at meat in the idol’s temple, shall not the conscience of him which is weak be emboldened to eat those things which are offered to idols;

1 Corinthians 8:11 And through thy knowledge shall the weak brother perish, for whom Christ died?

1 Corinthians 8:12 But when ye sin so against the brethren, and wound their weak conscience, ye sin against Christ.

1 Corinthians 8:13 Wherefore, if meat make my brother to offend, I will eat no flesh while the world standeth, lest I make my brother to offend.
