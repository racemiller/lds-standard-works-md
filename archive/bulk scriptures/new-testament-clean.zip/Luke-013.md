# Luke 13

Luke 13 (summary): Jesus teaches, Repent or perish—He gives the parable of the barren fig tree, heals a woman on the Sabbath, and likens the kingdom of God to a mustard seed—He discusses whether few or many are saved and laments over Jerusalem.

Luke 13:1 There were present at that season some that told him of the Galilæans, whose blood Pilate had mingled with their sacrifices.

Luke 13:2 And Jesus answering said unto them, Suppose ye that these Galilæans were sinners above all the Galilæans, because they suffered such things?

Luke 13:3 I tell you, Nay: but, except ye repent, ye shall all likewise perish.

Luke 13:4 Or those eighteen, upon whom the tower in Siloam fell, and slew them, think ye that they were sinners above all men that dwelt in Jerusalem?

Luke 13:5 I tell you, Nay: but, except ye repent, ye shall all likewise perish.

Luke 13:6 He spake also this parable; A certain man had a fig tree planted in his vineyard; and he came and sought fruit thereon, and found none.

Luke 13:7 Then said he unto the dresser of his vineyard, Behold, these three years I come seeking fruit on this fig tree, and find none: cut it down; why cumbereth it the ground?

Luke 13:8 And he answering said unto him, Lord, let it alone this year also, till I shall dig about it, and dung it:

Luke 13:9 And if it bear fruit, well: and if not, then after that thou shalt cut it down.

Luke 13:10 And he was teaching in one of the synagogues on the sabbath.

Luke 13:11 And, behold, there was a woman which had a spirit of infirmity eighteen years, and was bowed together, and could in no wise lift up herself.

Luke 13:12 And when Jesus saw her, he called her to him, and said unto her, Woman, thou art loosed from thine infirmity.

Luke 13:13 And he laid his hands on her: and immediately she was made straight, and glorified God.

Luke 13:14 And the ruler of the synagogue answered with indignation, because that Jesus had healed on the sabbath day, and said unto the people, There are six days in which men ought to work: in them therefore come and be healed, and not on the sabbath day.

Luke 13:15 The Lord then answered him, and said, Thou hypocrite, doth not each one of you on the sabbath loose his ox or his ass from the stall, and lead him away to watering?

Luke 13:16 And ought not this woman, being a daughter of Abraham, whom Satan hath bound, lo, these eighteen years, be loosed from this bond on the sabbath day?

Luke 13:17 And when he had said these things, all his adversaries were ashamed: and all the people rejoiced for all the glorious things that were done by him.

Luke 13:18 Then said he, Unto what is the kingdom of God like? and whereunto shall I resemble it?

Luke 13:19 It is like a grain of mustard seed, which a man took, and cast into his garden; and it grew, and waxed a great tree; and the fowls of the air lodged in the branches of it.

Luke 13:20 And again he said, Whereunto shall I liken the kingdom of God?

Luke 13:21 It is like leaven, which a woman took and hid in three measures of meal, till the whole was leavened.

Luke 13:22 And he went through the cities and villages, teaching, and journeying toward Jerusalem.

Luke 13:23 Then said one unto him, Lord, are there few that be saved? And he said unto them,

Luke 13:24 Strive to enter in at the strait gate: for many, I say unto you, will seek to enter in, and shall not be able.

Luke 13:25 When once the master of the house is risen up, and hath shut to the door, and ye begin to stand without, and to knock at the door, saying, Lord, Lord, open unto us; and he shall answer and say unto you, I know you not whence ye are:

Luke 13:26 Then shall ye begin to say, We have eaten and drunk in thy presence, and thou hast taught in our streets.

Luke 13:27 But he shall say, I tell you, I know you not whence ye are; depart from me, all ye workers of iniquity.

Luke 13:28 There shall be weeping and gnashing of teeth, when ye shall see Abraham, and Isaac, and Jacob, and all the prophets, in the kingdom of God, and you yourselves thrust out.

Luke 13:29 And they shall come from the east, and from the west, and from the north, and from the south, and shall sit down in the kingdom of God.

Luke 13:30 And, behold, there are last which shall be first, and there are first which shall be last.

Luke 13:31 The same day there came certain of the Pharisees, saying unto him, Get thee out, and depart hence: for Herod will kill thee.

Luke 13:32 And he said unto them, Go ye, and tell that fox, Behold, I cast out devils, and I do cures to day and to morrow, and the third day I shall be perfected.

Luke 13:33 Nevertheless I must walk to day, and to morrow, and the day following: for it cannot be that a prophet perish out of Jerusalem.

Luke 13:34 O Jerusalem, Jerusalem, which killest the prophets, and stonest them that are sent unto thee; how often would I have gathered thy children together, as a hen doth gather her brood under her wings, and ye would not!

Luke 13:35 Behold, your house is left unto you desolate: and verily I say unto you, Ye shall not see me, until the time come when ye shall say, Blessed is he that cometh in the name of the Lord.
