# 2 Thessalonians 2

2 Thessalonians 2 (summary): Apostasy is to precede the Second Coming—The gospel prepares men for eternal glory.

2 Thessalonians 2:1 Now we beseech you, brethren, by the coming of our Lord Jesus Christ, and by our gathering together unto him,

2 Thessalonians 2:2 That ye be not soon shaken in mind, or be troubled, neither by spirit, nor by word, nor by letter as from us, as that the day of Christ is at hand.

2 Thessalonians 2:3 Let no man deceive you by any means: for that day shall not come, except there come a falling away first, and that man of sin be revealed, the son of perdition;

2 Thessalonians 2:4 Who opposeth and exalteth himself above all that is called God, or that is worshipped; so that he as God sitteth in the temple of God, shewing himself that he is God.

2 Thessalonians 2:5 Remember ye not, that, when I was yet with you, I told you these things?

2 Thessalonians 2:6 And now ye know what withholdeth that he might be revealed in his time.

2 Thessalonians 2:7 For the mystery of iniquity doth already work: only he who now letteth will let, until he be taken out of the way.

2 Thessalonians 2:8 And then shall that Wicked be revealed, whom the Lord shall consume with the spirit of his mouth, and shall destroy with the brightness of his coming:

2 Thessalonians 2:9 Even him, whose coming is after the working of Satan with all power and signs and lying wonders,

2 Thessalonians 2:10 And with all deceivableness of unrighteousness in them that perish; because they received not the love of the truth, that they might be saved.

2 Thessalonians 2:11 And for this cause God shall send them strong delusion, that they should believe a lie:

2 Thessalonians 2:12 That they all might be damned who believed not the truth, but had pleasure in unrighteousness.

2 Thessalonians 2:13 But we are bound to give thanks alway to God for you, brethren beloved of the Lord, because God hath from the beginning chosen you to salvation through sanctification of the Spirit and belief of the truth:

2 Thessalonians 2:14 Whereunto he called you by our gospel, to the obtaining of the glory of our Lord Jesus Christ.

2 Thessalonians 2:15 Therefore, brethren, stand fast, and hold the traditions which ye have been taught, whether by word, or our epistle.

2 Thessalonians 2:16 Now our Lord Jesus Christ himself, and God, even our Father, which hath loved us, and hath given us everlasting consolation and good hope through grace,

2 Thessalonians 2:17 Comfort your hearts, and stablish you in every good word and work.
