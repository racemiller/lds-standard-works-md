# Revelation 5

Revelation 5 (summary): John sees the book sealed with seven seals, and he sees those people redeemed out of every nation—He hears every creature praising God and the Lamb.

Revelation 5:1 And I saw in the right hand of him that sat on the throne a book written within and on the backside, sealed with seven seals.

Revelation 5:2 And I saw a strong angel proclaiming with a loud voice, Who is worthy to open the book, and to loose the seals thereof?

Revelation 5:3 And no man in heaven, nor in earth, neither under the earth, was able to open the book, neither to look thereon.

Revelation 5:4 And I wept much, because no man was found worthy to open and to read the book, neither to look thereon.

Revelation 5:5 And one of the elders saith unto me, Weep not: behold, the Lion of the tribe of Juda, the Root of David, hath prevailed to open the book, and to loose the seven seals thereof.

Revelation 5:6 And I beheld, and, lo, in the midst of the throne and of the four beasts, and in the midst of the elders, stood a Lamb as it had been slain, having seven horns and seven eyes, which are the seven Spirits of God sent forth into all the earth.

Revelation 5:7 And he came and took the book out of the right hand of him that sat upon the throne.

Revelation 5:8 And when he had taken the book, the four beasts and four and twenty elders fell down before the Lamb, having every one of them harps, and golden vials full of odours, which are the prayers of saints.

Revelation 5:9 And they sung a new song, saying, Thou art worthy to take the book, and to open the seals thereof: for thou wast slain, and hast redeemed us to God by thy blood out of every kindred, and tongue, and people, and nation;

Revelation 5:10 And hast made us unto our God kings and priests: and we shall reign on the earth.

Revelation 5:11 And I beheld, and I heard the voice of many angels round about the throne and the beasts and the elders: and the number of them was ten thousand times ten thousand, and thousands of thousands;

Revelation 5:12 Saying with a loud voice, Worthy is the Lamb that was slain to receive power, and riches, and wisdom, and strength, and honour, and glory, and blessing.

Revelation 5:13 And every creature which is in heaven, and on the earth, and under the earth, and such as are in the sea, and all that are in them, heard I saying, Blessing, and honour, and glory, and power, be unto him that sitteth upon the throne, and unto the Lamb for ever and ever.

Revelation 5:14 And the four beasts said, Amen. And the four and twenty elders fell down and worshipped him that liveth for ever and ever.
