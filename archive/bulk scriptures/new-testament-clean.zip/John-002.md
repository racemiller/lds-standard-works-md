# John 2

John 2 (summary): Jesus turns water into wine in Cana—He attends the Passover, cleanses the temple, foretells His death and resurrection, and performs miracles.

John 2:1 And the third day there was a marriage in Cana of Galilee; and the mother of Jesus was there:

John 2:2 And both Jesus was called, and his disciples, to the marriage.

John 2:3 And when they wanted wine, the mother of Jesus saith unto him, They have no wine.

John 2:4 Jesus saith unto her, Woman, what have I to do with thee? mine hour is not yet come.

John 2:5 His mother saith unto the servants, Whatsoever he saith unto you, do it.

John 2:6 And there were set there six waterpots of stone, after the manner of the purifying of the Jews, containing two or three firkins apiece.

John 2:7 Jesus saith unto them, Fill the waterpots with water. And they filled them up to the brim.

John 2:8 And he saith unto them, Draw out now, and bear unto the governor of the feast. And they bare it.

John 2:9 When the ruler of the feast had tasted the water that was made wine, and knew not whence it was: (but the servants which drew the water knew;) the governor of the feast called the bridegroom,

John 2:10 And saith unto him, Every man at the beginning doth set forth good wine; and when men have well drunk, then that which is worse: but thou hast kept the good wine until now.

John 2:11 This beginning of miracles did Jesus in Cana of Galilee, and manifested forth his glory; and his disciples believed on him.

John 2:12 After this he went down to Capernaum, he, and his mother, and his brethren, and his disciples: and they continued there not many days.

John 2:13 And the Jews’ passover was at hand, and Jesus went up to Jerusalem,

John 2:14 And found in the temple those that sold oxen and sheep and doves, and the changers of money sitting:

John 2:15 And when he had made a scourge of small cords, he drove them all out of the temple, and the sheep, and the oxen; and poured out the changers’ money, and overthrew the tables;

John 2:16 And said unto them that sold doves, Take these things hence; make not my Father’s house an house of merchandise.

John 2:17 And his disciples remembered that it was written, The zeal of thine house hath eaten me up.

John 2:18 Then answered the Jews and said unto him, What sign shewest thou unto us, seeing that thou doest these things?

John 2:19 Jesus answered and said unto them, Destroy this temple, and in three days I will raise it up.

John 2:20 Then said the Jews, Forty and six years was this temple in building, and wilt thou rear it up in three days?

John 2:21 But he spake of the temple of his body.

John 2:22 When therefore he was risen from the dead, his disciples remembered that he had said this unto them; and they believed the scripture, and the word which Jesus had said.

John 2:23 Now when he was in Jerusalem at the passover, in the feast day, many believed in his name, when they saw the miracles which he did.

John 2:24 But Jesus did not commit himself unto them, because he knew all men,

John 2:25 And needed not that any should testify of man: for he knew what was in man.
