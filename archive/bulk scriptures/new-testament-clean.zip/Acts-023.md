# Acts 23

Acts 23 (summary): Paul is smitten at Ananias’s order—The Lord again appears to Paul—Forty Jews plot his death—He is delivered over to Felix.

Acts 23:1 And Paul, earnestly beholding the council, said, Men and brethren, I have lived in all good conscience before God until this day.

Acts 23:2 And the high priest Ananias commanded them that stood by him to smite him on the mouth.

Acts 23:3 Then said Paul unto him, God shall smite thee, thou whited wall: for sittest thou to judge me after the law, and commandest me to be smitten contrary to the law?

Acts 23:4 And they that stood by said, Revilest thou God’s high priest?

Acts 23:5 Then said Paul, I wist not, brethren, that he was the high priest: for it is written, Thou shalt not speak evil of the ruler of thy people.

Acts 23:6 But when Paul perceived that the one part were Sadducees, and the other Pharisees, he cried out in the council, Men and brethren, I am a Pharisee, the son of a Pharisee: of the hope and resurrection of the dead I am called in question.

Acts 23:7 And when he had so said, there arose a dissension between the Pharisees and the Sadducees: and the multitude was divided.

Acts 23:8 For the Sadducees say that there is no resurrection, neither angel, nor spirit: but the Pharisees confess both.

Acts 23:9 And there arose a great cry: and the scribes that were of the Pharisees’ part arose, and strove, saying, We find no evil in this man: but if a spirit or an angel hath spoken to him, let us not fight against God.

Acts 23:10 And when there arose a great dissension, the chief captain, fearing lest Paul should have been pulled in pieces of them, commanded the soldiers to go down, and to take him by force from among them, and to bring him into the castle.

Acts 23:11 And the night following the Lord stood by him, and said, Be of good cheer, Paul: for as thou hast testified of me in Jerusalem, so must thou bear witness also at Rome.

Acts 23:12 And when it was day, certain of the Jews banded together, and bound themselves under a curse, saying that they would neither eat nor drink till they had killed Paul.

Acts 23:13 And they were more than forty which had made this conspiracy.

Acts 23:14 And they came to the chief priests and elders, and said, We have bound ourselves under a great curse, that we will eat nothing until we have slain Paul.

Acts 23:15 Now therefore ye with the council signify to the chief captain that he bring him down unto you to morrow, as though ye would inquire something more perfectly concerning him: and we, or ever he come near, are ready to kill him.

Acts 23:16 And when Paul’s sister’s son heard of their lying in wait, he went and entered into the castle, and told Paul.

Acts 23:17 Then Paul called one of the centurions unto him, and said, Bring this young man unto the chief captain: for he hath a certain thing to tell him.

Acts 23:18 So he took him, and brought him to the chief captain, and said, Paul the prisoner called me unto him, and prayed me to bring this young man unto thee, who hath something to say unto thee.

Acts 23:19 Then the chief captain took him by the hand, and went with him aside privately, and asked him, What is that thou hast to tell me?

Acts 23:20 And he said, The Jews have agreed to desire thee that thou wouldest bring down Paul to morrow into the council, as though they would inquire somewhat of him more perfectly.

Acts 23:21 But do not thou yield unto them: for there lie in wait for him of them more than forty men, which have bound themselves with an oath, that they will neither eat nor drink till they have killed him: and now are they ready, looking for a promise from thee.

Acts 23:22 So the chief captain then let the young man depart, and charged him, See thou tell no man that thou hast shewed these things to me.

Acts 23:23 And he called unto him two centurions, saying, Make ready two hundred soldiers to go to Cæsarea, and horsemen threescore and ten, and spearmen two hundred, at the third hour of the night;

Acts 23:24 And provide them beasts, that they may set Paul on, and bring him safe unto Felix the governor.

Acts 23:25 And he wrote a letter after this manner:

Acts 23:26 Claudius Lysias unto the most excellent governor Felix sendeth greeting.

Acts 23:27 This man was taken of the Jews, and should have been killed of them: then came I with an army, and rescued him, having understood that he was a Roman.

Acts 23:28 And when I would have known the cause wherefore they accused him, I brought him forth into their council:

Acts 23:29 Whom I perceived to be accused of questions of their law, but to have nothing laid to his charge worthy of death or of bonds.

Acts 23:30 And when it was told me how that the Jews laid wait for the man, I sent straightway to thee, and gave commandment to his accusers also to say before thee what they had against him. Farewell.

Acts 23:31 Then the soldiers, as it was commanded them, took Paul, and brought him by night to Antipatris.

Acts 23:32 On the morrow they left the horsemen to go with him, and returned to the castle:

Acts 23:33 Who, when they came to Cæsarea, and delivered the epistle to the governor, presented Paul also before him.

Acts 23:34 And when the governor had read the letter, he asked of what province he was. And when he understood that he was of Cilicia;

Acts 23:35 I will hear thee, said he, when thine accusers are also come. And he commanded him to be kept in Herod’s judgment hall.
