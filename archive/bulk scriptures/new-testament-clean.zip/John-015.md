# John 15

John 15 (summary): Jesus is the vine; His disciples are the branches—He discourses on the perfect law of love—His servants have been chosen and ordained by Him—The world hates and fights true religion—He promises the Comforter, the Spirit of Truth.

John 15:1 I am the true vine, and my Father is the husbandman.

John 15:2 Every branch in me that beareth not fruit he taketh away: and every branch that beareth fruit, he purgeth it, that it may bring forth more fruit.

John 15:3 Now ye are clean through the word which I have spoken unto you.

John 15:4 Abide in me, and I in you. As the branch cannot bear fruit of itself, except it abide in the vine; no more can ye, except ye abide in me.

John 15:5 I am the vine, ye are the branches: He that abideth in me, and I in him, the same bringeth forth much fruit: for without me ye can do nothing.

John 15:6 If a man abide not in me, he is cast forth as a branch, and is withered; and men gather them, and cast them into the fire, and they are burned.

John 15:7 If ye abide in me, and my words abide in you, ye shall ask what ye will, and it shall be done unto you.

John 15:8 Herein is my Father glorified, that ye bear much fruit; so shall ye be my disciples.

John 15:9 As the Father hath loved me, so have I loved you: continue ye in my love.

John 15:10 If ye keep my commandments, ye shall abide in my love; even as I have kept my Father’s commandments, and abide in his love.

John 15:11 These things have I spoken unto you, that my joy might remain in you, and that your joy might be full.

John 15:12 This is my commandment, That ye love one another, as I have loved you.

John 15:13 Greater love hath no man than this, that a man lay down his life for his friends.

John 15:14 Ye are my friends, if ye do whatsoever I command you.

John 15:15 Henceforth I call you not servants; for the servant knoweth not what his lord doeth: but I have called you friends; for all things that I have heard of my Father I have made known unto you.

John 15:16 Ye have not chosen me, but I have chosen you, and ordained you, that ye should go and bring forth fruit, and that your fruit should remain: that whatsoever ye shall ask of the Father in my name, he may give it you.

John 15:17 These things I command you, that ye love one another.

John 15:18 If the world hate you, ye know that it hated me before it hated you.

John 15:19 If ye were of the world, the world would love his own: but because ye are not of the world, but I have chosen you out of the world, therefore the world hateth you.

John 15:20 Remember the word that I said unto you, The servant is not greater than his lord. If they have persecuted me, they will also persecute you; if they have kept my saying, they will keep yours also.

John 15:21 But all these things will they do unto you for my name’s sake, because they know not him that sent me.

John 15:22 If I had not come and spoken unto them, they had not had sin: but now they have no cloak for their sin.

John 15:23 He that hateth me hateth my Father also.

John 15:24 If I had not done among them the works which none other man did, they had not had sin: but now have they both seen and hated both me and my Father.

John 15:25 But this cometh to pass, that the word might be fulfilled that is written in their law, They hated me without a cause.

John 15:26 But when the Comforter is come, whom I will send unto you from the Father, even the Spirit of truth, which proceedeth from the Father, he shall testify of me:

John 15:27 And ye also shall bear witness, because ye have been with me from the beginning.
