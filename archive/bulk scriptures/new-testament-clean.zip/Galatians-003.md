# Galatians 3

Galatians 3 (summary): God gave the gospel to Abraham—The Mosaic law was added because of transgressions—The law was a schoolmaster until Christ—The Saints are children of God by faith—All who are of the faith and baptized into Christ become Abraham’s seed.

Galatians 3:1 O foolish Galatians, who hath bewitched you, that ye should not obey the truth, before whose eyes Jesus Christ hath been evidently set forth, crucified among you?

Galatians 3:2 This only would I learn of you, Received ye the Spirit by the works of the law, or by the hearing of faith?

Galatians 3:3 Are ye so foolish? having begun in the Spirit, are ye now made perfect by the flesh?

Galatians 3:4 Have ye suffered so many things in vain? if it be yet in vain.

Galatians 3:5 He therefore that ministereth to you the Spirit, and worketh miracles among you, doeth he it by the works of the law, or by the hearing of faith?

Galatians 3:6 Even as Abraham believed God, and it was accounted to him for righteousness.

Galatians 3:7 Know ye therefore that they which are of faith, the same are the children of Abraham.

Galatians 3:8 And the scripture, foreseeing that God would justify the heathen through faith, preached before the gospel unto Abraham, saying, In thee shall all nations be blessed.

Galatians 3:9 So then they which be of faith are blessed with faithful Abraham.

Galatians 3:10 For as many as are of the works of the law are under the curse: for it is written, Cursed is every one that continueth not in all things which are written in the book of the law to do them.

Galatians 3:11 But that no man is justified by the law in the sight of God, it is evident: for, The just shall live by faith.

Galatians 3:12 And the law is not of faith: but, The man that doeth them shall live in them.

Galatians 3:13 Christ hath redeemed us from the curse of the law, being made a curse for us: for it is written, Cursed is every one that hangeth on a tree:

Galatians 3:14 That the blessing of Abraham might come on the Gentiles through Jesus Christ; that we might receive the promise of the Spirit through faith.

Galatians 3:15 Brethren, I speak after the manner of men; Though it be but a man’s covenant, yet if it be confirmed, no man disannulleth, or addeth thereto.

Galatians 3:16 Now to Abraham and his seed were the promises made. He saith not, And to seeds, as of many; but as of one, And to thy seed, which is Christ.

Galatians 3:17 And this I say, that the covenant, that was confirmed before of God in Christ, the law, which was four hundred and thirty years after, cannot disannul, that it should make the promise of none effect.

Galatians 3:18 For if the inheritance be of the law, it is no more of promise: but God gave it to Abraham by promise.

Galatians 3:19 Wherefore then serveth the law? It was added because of transgressions, till the seed should come to whom the promise was made; and it was ordained by angels in the hand of a mediator.

Galatians 3:20 Now a mediator is not a mediator of one, but God is one.

Galatians 3:21 Is the law then against the promises of God? God forbid: for if there had been a law given which could have given life, verily righteousness should have been by the law.

Galatians 3:22 But the scripture hath concluded all under sin, that the promise by faith of Jesus Christ might be given to them that believe.

Galatians 3:23 But before faith came, we were kept under the law, shut up unto the faith which should afterwards be revealed.

Galatians 3:24 Wherefore the law was our schoolmaster to bring us unto Christ, that we might be justified by faith.

Galatians 3:25 But after that faith is come, we are no longer under a schoolmaster.

Galatians 3:26 For ye are all the children of God by faith in Christ Jesus.

Galatians 3:27 For as many of you as have been baptized into Christ have put on Christ.

Galatians 3:28 There is neither Jew nor Greek, there is neither bond nor free, there is neither male nor female: for ye are all one in Christ Jesus.

Galatians 3:29 And if ye be Christ’s, then are ye Abraham’s seed, and heirs according to the promise.
