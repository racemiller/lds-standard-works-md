# 1 Corinthians 12

1 Corinthians 12 (summary): The Holy Ghost reveals that Jesus is the Christ—Spiritual gifts are present among the Saints—Apostles, prophets, and miracles are found in the true Church.

1 Corinthians 12:1 Now concerning spiritual gifts, brethren, I would not have you ignorant.

1 Corinthians 12:2 Ye know that ye were Gentiles, carried away unto these dumb idols, even as ye were led.

1 Corinthians 12:3 Wherefore I give you to understand, that no man speaking by the Spirit of God calleth Jesus accursed: and that no man can say that Jesus is the Lord, but by the Holy Ghost.

1 Corinthians 12:4 Now there are diversities of gifts, but the same Spirit.

1 Corinthians 12:5 And there are differences of administrations, but the same Lord.

1 Corinthians 12:6 And there are diversities of operations, but it is the same God which worketh all in all.

1 Corinthians 12:7 But the manifestation of the Spirit is given to every man to profit withal.

1 Corinthians 12:8 For to one is given by the Spirit the word of wisdom; to another the word of knowledge by the same Spirit;

1 Corinthians 12:9 To another faith by the same Spirit; to another the gifts of healing by the same Spirit;

1 Corinthians 12:10 To another the working of miracles; to another prophecy; to another discerning of spirits; to another divers kinds of tongues; to another the interpretation of tongues:

1 Corinthians 12:11 But all these worketh that one and the selfsame Spirit, dividing to every man severally as he will.

1 Corinthians 12:12 For as the body is one, and hath many members, and all the members of that one body, being many, are one body: so also is Christ.

1 Corinthians 12:13 For by one Spirit are we all baptized into one body, whether we be Jews or Gentiles, whether we be bond or free; and have been all made to drink into one Spirit.

1 Corinthians 12:14 For the body is not one member, but many.

1 Corinthians 12:15 If the foot shall say, Because I am not the hand, I am not of the body; is it therefore not of the body?

1 Corinthians 12:16 And if the ear shall say, Because I am not the eye, I am not of the body; is it therefore not of the body?

1 Corinthians 12:17 If the whole body were an eye, where were the hearing? If the whole were hearing, where were the smelling?

1 Corinthians 12:18 But now hath God set the members every one of them in the body, as it hath pleased him.

1 Corinthians 12:19 And if they were all one member, where were the body?

1 Corinthians 12:20 But now are they many members, yet but one body.

1 Corinthians 12:21 And the eye cannot say unto the hand, I have no need of thee: nor again the head to the feet, I have no need of you.

1 Corinthians 12:22 Nay, much more those members of the body, which seem to be more feeble, are necessary:

1 Corinthians 12:23 And those members of the body, which we think to be less honourable, upon these we bestow more abundant honour; and our uncomely parts have more abundant comeliness.

1 Corinthians 12:24 For our comely parts have no need: but God hath tempered the body together, having given more abundant honour to that part which lacked:

1 Corinthians 12:25 That there should be no schism in the body; but that the members should have the same care one for another.

1 Corinthians 12:26 And whether one member suffer, all the members suffer with it; or one member be honoured, all the members rejoice with it.

1 Corinthians 12:27 Now ye are the body of Christ, and members in particular.

1 Corinthians 12:28 And God hath set some in the church, first apostles, secondarily prophets, thirdly teachers, after that miracles, then gifts of healings, helps, governments, diversities of tongues.

1 Corinthians 12:29 Are all apostles? are all prophets? are all teachers? are all workers of miracles?

1 Corinthians 12:30 Have all the gifts of healing? do all speak with tongues? do all interpret?

1 Corinthians 12:31 But covet earnestly the best gifts: and yet shew I unto you a more excellent way.
