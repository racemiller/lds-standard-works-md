# Luke 8

Luke 8 (summary): Jesus gives and interprets the parable of the sower—He stills the tempest; casts out a legion of devils, who then enter the swine; heals a woman of an issue of blood; and raises Jairus’s daughter from death.

Luke 8:1 And it came to pass afterward, that he went throughout every city and village, preaching and shewing the glad tidings of the kingdom of God: and the twelve were with him,

Luke 8:2 And certain women, which had been healed of evil spirits and infirmities, Mary called Magdalene, out of whom went seven devils,

Luke 8:3 And Joanna the wife of Chuza Herod’s steward, and Susanna, and many others, which ministered unto him of their substance.

Luke 8:4 And when much people were gathered together, and were come to him out of every city, he spake by a parable:

Luke 8:5 A sower went out to sow his seed: and as he sowed, some fell by the way side; and it was trodden down, and the fowls of the air devoured it.

Luke 8:6 And some fell upon a rock; and as soon as it was sprung up, it withered away, because it lacked moisture.

Luke 8:7 And some fell among thorns; and the thorns sprang up with it, and choked it.

Luke 8:8 And other fell on good ground, and sprang up, and bare fruit an hundredfold. And when he had said these things, he cried, He that hath ears to hear, let him hear.

Luke 8:9 And his disciples asked him, saying, What might this parable be?

Luke 8:10 And he said, Unto you it is given to know the mysteries of the kingdom of God: but to others in parables; that seeing they might not see, and hearing they might not understand.

Luke 8:11 Now the parable is this: The seed is the word of God.

Luke 8:12 Those by the way side are they that hear; then cometh the devil, and taketh away the word out of their hearts, lest they should believe and be saved.

Luke 8:13 They on the rock are they, which, when they hear, receive the word with joy; and these have no root, which for a while believe, and in time of temptation fall away.

Luke 8:14 And that which fell among thorns are they, which, when they have heard, go forth, and are choked with cares and riches and pleasures of this life, and bring no fruit to perfection.

Luke 8:15 But that on the good ground are they, which in an honest and good heart, having heard the word, keep it, and bring forth fruit with patience.

Luke 8:16 No man, when he hath lighted a candle, covereth it with a vessel, or putteth it under a bed; but setteth it on a candlestick, that they which enter in may see the light.

Luke 8:17 For nothing is secret, that shall not be made manifest; neither any thing hid, that shall not be known and come abroad.

Luke 8:18 Take heed therefore how ye hear: for whosoever hath, to him shall be given; and whosoever hath not, from him shall be taken even that which he seemeth to have.

Luke 8:19 Then came to him his mother and his brethren, and could not come at him for the press.

Luke 8:20 And it was told him by certain which said, Thy mother and thy brethren stand without, desiring to see thee.

Luke 8:21 And he answered and said unto them, My mother and my brethren are these which hear the word of God, and do it.

Luke 8:22 Now it came to pass on a certain day, that he went into a ship with his disciples: and he said unto them, Let us go over unto the other side of the lake. And they launched forth.

Luke 8:23 But as they sailed he fell asleep: and there came down a storm of wind on the lake; and they were filled with water, and were in jeopardy.

Luke 8:24 And they came to him, and awoke him, saying, Master, master, we perish. Then he arose, and rebuked the wind and the raging of the water: and they ceased, and there was a calm.

Luke 8:25 And he said unto them, Where is your faith? And they being afraid wondered, saying one to another, What manner of man is this! for he commandeth even the winds and water, and they obey him.

Luke 8:26 And they arrived at the country of the Gadarenes, which is over against Galilee.

Luke 8:27 And when he went forth to land, there met him out of the city a certain man, which had devils long time, and ware no clothes, neither abode in any house, but in the tombs.

Luke 8:28 When he saw Jesus, he cried out, and fell down before him, and with a loud voice said, What have I to do with thee, Jesus, thou Son of God most high? I beseech thee, torment me not.

Luke 8:29 (For he had commanded the unclean spirit to come out of the man. For oftentimes it had caught him: and he was kept bound with chains and in fetters; and he brake the bands, and was driven of the devil into the wilderness.)

Luke 8:30 And Jesus asked him, saying, What is thy name? And he said, Legion: because many devils were entered into him.

Luke 8:31 And they besought him that he would not command them to go out into the deep.

Luke 8:32 And there was there an herd of many swine feeding on the mountain: and they besought him that he would suffer them to enter into them. And he suffered them.

Luke 8:33 Then went the devils out of the man, and entered into the swine: and the herd ran violently down a steep place into the lake, and were choked.

Luke 8:34 When they that fed them saw what was done, they fled, and went and told it in the city and in the country.

Luke 8:35 Then they went out to see what was done; and came to Jesus, and found the man, out of whom the devils were departed, sitting at the feet of Jesus, clothed, and in his right mind: and they were afraid.

Luke 8:36 They also which saw it told them by what means he that was possessed of the devils was healed.

Luke 8:37 Then the whole multitude of the country of the Gadarenes round about besought him to depart from them; for they were taken with great fear: and he went up into the ship, and returned back again.

Luke 8:38 Now the man out of whom the devils were departed besought him that he might be with him: but Jesus sent him away, saying,

Luke 8:39 Return to thine own house, and shew how great things God hath done unto thee. And he went his way, and published throughout the whole city how great things Jesus had done unto him.

Luke 8:40 And it came to pass, that, when Jesus was returned, the people gladly received him: for they were all waiting for him.

Luke 8:41 And, behold, there came a man named Jairus, and he was a ruler of the synagogue: and he fell down at Jesus’ feet, and besought him that he would come into his house:

Luke 8:42 For he had one only daughter, about twelve years of age, and she lay a dying. But as he went the people thronged him.

Luke 8:43 And a woman having an issue of blood twelve years, which had spent all her living upon physicians, neither could be healed of any,

Luke 8:44 Came behind him, and touched the border of his garment: and immediately her issue of blood stanched.

Luke 8:45 And Jesus said, Who touched me? When all denied, Peter and they that were with him said, Master, the multitude throng thee and press thee, and sayest thou, Who touched me?

Luke 8:46 And Jesus said, Somebody hath touched me: for I perceive that virtue is gone out of me.

Luke 8:47 And when the woman saw that she was not hid, she came trembling, and falling down before him, she declared unto him before all the people for what cause she had touched him, and how she was healed immediately.

Luke 8:48 And he said unto her, Daughter, be of good comfort: thy faith hath made thee whole; go in peace.

Luke 8:49 While he yet spake, there cometh one from the ruler of the synagogue’s house, saying to him, Thy daughter is dead; trouble not the Master.

Luke 8:50 But when Jesus heard it, he answered him, saying, Fear not: believe only, and she shall be made whole.

Luke 8:51 And when he came into the house, he suffered no man to go in, save Peter, and James, and John, and the father and the mother of the maiden.

Luke 8:52 And all wept, and bewailed her: but he said, Weep not; she is not dead, but sleepeth.

Luke 8:53 And they laughed him to scorn, knowing that she was dead.

Luke 8:54 And he put them all out, and took her by the hand, and called, saying, Maid, arise.

Luke 8:55 And her spirit came again, and she arose straightway: and he commanded to give her meat.

Luke 8:56 And her parents were astonished: but he charged them that they should tell no man what was done.
