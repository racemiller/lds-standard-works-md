# Hebrews 13

Hebrews 13 (summary): Marriage is honorable—Christ is the same everlastingly—Paul explains how the Saints are to offer acceptable sacrifices.

Hebrews 13:1 Let brotherly love continue.

Hebrews 13:2 Be not forgetful to entertain strangers: for thereby some have entertained angels unawares.

Hebrews 13:3 Remember them that are in bonds, as bound with them; and them which suffer adversity, as being yourselves also in the body.

Hebrews 13:4 Marriage is honourable in all, and the bed undefiled: but whoremongers and adulterers God will judge.

Hebrews 13:5 Let your conversation be without covetousness; and be content with such things as ye have: for he hath said, I will never leave thee, nor forsake thee.

Hebrews 13:6 So that we may boldly say, The Lord is my helper, and I will not fear what man shall do unto me.

Hebrews 13:7 Remember them which have the rule over you, who have spoken unto you the word of God: whose faith follow, considering the end of their conversation.

Hebrews 13:8 Jesus Christ the same yesterday, and to day, and for ever.

Hebrews 13:9 Be not carried about with divers and strange doctrines. For it is a good thing that the heart be established with grace; not with meats, which have not profited them that have been occupied therein.

Hebrews 13:10 We have an altar, whereof they have no right to eat which serve the tabernacle.

Hebrews 13:11 For the bodies of those beasts, whose blood is brought into the sanctuary by the high priest for sin, are burned without the camp.

Hebrews 13:12 Wherefore Jesus also, that he might sanctify the people with his own blood, suffered without the gate.

Hebrews 13:13 Let us go forth therefore unto him without the camp, bearing his reproach.

Hebrews 13:14 For here have we no continuing city, but we seek one to come.

Hebrews 13:15 By him therefore let us offer the sacrifice of praise to God continually, that is, the fruit of our lips giving thanks to his name.

Hebrews 13:16 But to do good and to communicate forget not: for with such sacrifices God is well pleased.

Hebrews 13:17 Obey them that have the rule over you, and submit yourselves: for they watch for your souls, as they that must give account, that they may do it with joy, and not with grief: for that is unprofitable for you.

Hebrews 13:18 Pray for us: for we trust we have a good conscience, in all things willing to live honestly.

Hebrews 13:19 But I beseech you the rather to do this, that I may be restored to you the sooner.

Hebrews 13:20 Now the God of peace, that brought again from the dead our Lord Jesus, that great shepherd of the sheep, through the blood of the everlasting covenant,

Hebrews 13:21 Make you perfect in every good work to do his will, working in you that which is wellpleasing in his sight, through Jesus Christ; to whom be glory for ever and ever. Amen.

Hebrews 13:22 And I beseech you, brethren, suffer the word of exhortation: for I have written a letter unto you in few words.

Hebrews 13:23 Know ye that our brother Timothy is set at liberty; with whom, if he come shortly, I will see you.

Hebrews 13:24 Salute all them that have the rule over you, and all the saints. They of Italy salute you.

Hebrews 13:25 Grace be with you all. Amen.
