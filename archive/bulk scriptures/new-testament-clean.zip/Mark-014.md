# Mark 14

Mark 14 (summary): Jesus is anointed with oil—He eats the Passover, institutes the sacrament, suffers in Gethsemane, and is betrayed by Judas—Jesus is falsely accused, and Peter denies that he knows Him.

Mark 14:1 After two days was the feast of the passover, and of unleavened bread: and the chief priests and the scribes sought how they might take him by craft, and put him to death.

Mark 14:2 But they said, Not on the feast day, lest there be an uproar of the people.

Mark 14:3 And being in Bethany in the house of Simon the leper, as he sat at meat, there came a woman having an alabaster box of ointment of spikenard very precious; and she brake the box, and poured it on his head.

Mark 14:4 And there were some that had indignation within themselves, and said, Why was this waste of the ointment made?

Mark 14:5 For it might have been sold for more than three hundred pence, and have been given to the poor. And they murmured against her.

Mark 14:6 And Jesus said, Let her alone; why trouble ye her? she hath wrought a good work on me.

Mark 14:7 For ye have the poor with you always, and whensoever ye will ye may do them good: but me ye have not always.

Mark 14:8 She hath done what she could: she is come aforehand to anoint my body to the burying.

Mark 14:9 Verily I say unto you, Wheresoever this gospel shall be preached throughout the whole world, this also that she hath done shall be spoken of for a memorial of her.

Mark 14:10 And Judas Iscariot, one of the twelve, went unto the chief priests, to betray him unto them.

Mark 14:11 And when they heard it, they were glad, and promised to give him money. And he sought how he might conveniently betray him.

Mark 14:12 And the first day of unleavened bread, when they killed the passover, his disciples said unto him, Where wilt thou that we go and prepare that thou mayest eat the passover?

Mark 14:13 And he sendeth forth two of his disciples, and saith unto them, Go ye into the city, and there shall meet you a man bearing a pitcher of water: follow him.

Mark 14:14 And wheresoever he shall go in, say ye to the goodman of the house, The Master saith, Where is the guestchamber, where I shall eat the passover with my disciples?

Mark 14:15 And he will shew you a large upper room furnished and prepared: there make ready for us.

Mark 14:16 And his disciples went forth, and came into the city, and found as he had said unto them: and they made ready the passover.

Mark 14:17 And in the evening he cometh with the twelve.

Mark 14:18 And as they sat and did eat, Jesus said, Verily I say unto you, One of you which eateth with me shall betray me.

Mark 14:19 And they began to be sorrowful, and to say unto him one by one, Is it I? and another said, Is it I?

Mark 14:20 And he answered and said unto them, It is one of the twelve, that dippeth with me in the dish.

Mark 14:21 The Son of man indeed goeth, as it is written of him: but woe to that man by whom the Son of man is betrayed! good were it for that man if he had never been born.

Mark 14:22 And as they did eat, Jesus took bread, and blessed, and brake it, and gave to them, and said, Take, eat: this is my body.

Mark 14:23 And he took the cup, and when he had given thanks, he gave it to them: and they all drank of it.

Mark 14:24 And he said unto them, This is my blood of the new testament, which is shed for many.

Mark 14:25 Verily I say unto you, I will drink no more of the fruit of the vine, until that day that I drink it new in the kingdom of God.

Mark 14:26 And when they had sung an hymn, they went out into the mount of Olives.

Mark 14:27 And Jesus saith unto them, All ye shall be offended because of me this night: for it is written, I will smite the shepherd, and the sheep shall be scattered.

Mark 14:28 But after that I am risen, I will go before you into Galilee.

Mark 14:29 But Peter said unto him, Although all shall be offended, yet will not I.

Mark 14:30 And Jesus saith unto him, Verily I say unto thee, That this day, even in this night, before the cock crow twice, thou shalt deny me thrice.

Mark 14:31 But he spake the more vehemently, If I should die with thee, I will not deny thee in any wise. Likewise also said they all.

Mark 14:32 And they came to a place which was named Gethsemane: and he saith to his disciples, Sit ye here, while I shall pray.

Mark 14:33 And he taketh with him Peter and James and John, and began to be sore amazed, and to be very heavy;

Mark 14:34 And saith unto them, My soul is exceeding sorrowful unto death: tarry ye here, and watch.

Mark 14:35 And he went forward a little, and fell on the ground, and prayed that, if it were possible, the hour might pass from him.

Mark 14:36 And he said, Abba, Father, all things are possible unto thee; take away this cup from me: nevertheless not what I will, but what thou wilt.

Mark 14:37 And he cometh, and findeth them sleeping, and saith unto Peter, Simon, sleepest thou? couldest not thou watch one hour?

Mark 14:38 Watch ye and pray, lest ye enter into temptation. The spirit truly is ready, but the flesh is weak.

Mark 14:39 And again he went away, and prayed, and spake the same words.

Mark 14:40 And when he returned, he found them asleep again, (for their eyes were heavy,) neither wist they what to answer him.

Mark 14:41 And he cometh the third time, and saith unto them, Sleep on now, and take your rest: it is enough, the hour is come; behold, the Son of man is betrayed into the hands of sinners.

Mark 14:42 Rise up, let us go; lo, he that betrayeth me is at hand.

Mark 14:43 And immediately, while he yet spake, cometh Judas, one of the twelve, and with him a great multitude with swords and staves, from the chief priests and the scribes and the elders.

Mark 14:44 And he that betrayed him had given them a token, saying, Whomsoever I shall kiss, that same is he; take him, and lead him away safely.

Mark 14:45 And as soon as he was come, he goeth straightway to him, and saith, Master, master; and kissed him.

Mark 14:46 And they laid their hands on him, and took him.

Mark 14:47 And one of them that stood by drew a sword, and smote a servant of the high priest, and cut off his ear.

Mark 14:48 And Jesus answered and said unto them, Are ye come out, as against a thief, with swords and with staves to take me?

Mark 14:49 I was daily with you in the temple teaching, and ye took me not: but the scriptures must be fulfilled.

Mark 14:50 And they all forsook him, and fled.

Mark 14:51 And there followed him a certain young man, having a linen cloth cast about his naked body; and the young men laid hold on him:

Mark 14:52 And he left the linen cloth, and fled from them naked.

Mark 14:53 And they led Jesus away to the high priest: and with him were assembled all the chief priests and the elders and the scribes.

Mark 14:54 And Peter followed him afar off, even into the palace of the high priest: and he sat with the servants, and warmed himself at the fire.

Mark 14:55 And the chief priests and all the council sought for witness against Jesus to put him to death; and found none.

Mark 14:56 For many bare false witness against him, but their witness agreed not together.

Mark 14:57 And there arose certain, and bare false witness against him, saying,

Mark 14:58 We heard him say, I will destroy this temple that is made with hands, and within three days I will build another made without hands.

Mark 14:59 But neither so did their witness agree together.

Mark 14:60 And the high priest stood up in the midst, and asked Jesus, saying, Answerest thou nothing? what is it which these witness against thee?

Mark 14:61 But he held his peace, and answered nothing. Again the high priest asked him, and said unto him, Art thou the Christ, the Son of the Blessed?

Mark 14:62 And Jesus said, I am: and ye shall see the Son of man sitting on the right hand of power, and coming in the clouds of heaven.

Mark 14:63 Then the high priest rent his clothes, and saith, What need we any further witnesses?

Mark 14:64 Ye have heard the blasphemy: what think ye? And they all condemned him to be guilty of death.

Mark 14:65 And some began to spit on him, and to cover his face, and to buffet him, and to say unto him, Prophesy: and the servants did strike him with the palms of their hands.

Mark 14:66 And as Peter was beneath in the palace, there cometh one of the maids of the high priest:

Mark 14:67 And when she saw Peter warming himself, she looked upon him, and said, And thou also wast with Jesus of Nazareth.

Mark 14:68 But he denied, saying, I know not, neither understand I what thou sayest. And he went out into the porch; and the cock crew.

Mark 14:69 And a maid saw him again, and began to say to them that stood by, This is one of them.

Mark 14:70 And he denied it again. And a little after, they that stood by said again to Peter, Surely thou art one of them: for thou art a Galilæan, and thy speech agreeth thereto.

Mark 14:71 But he began to curse and to swear, saying, I know not this man of whom ye speak.

Mark 14:72 And the second time the cock crew. And Peter called to mind the word that Jesus said unto him, Before the cock crow twice, thou shalt deny me thrice. And when he thought thereon, he wept.
