# Mark 3

Mark 3 (summary): Jesus heals on the Sabbath day—He chooses and ordains the Twelve Apostles—He asks, Can Satan cast out Satan?—Jesus speaks of blasphemy against the Holy Ghost and identifies those who believe as being members of His family.

Mark 3:1 And he entered again into the synagogue; and there was a man there which had a withered hand.

Mark 3:2 And they watched him, whether he would heal him on the sabbath day; that they might accuse him.

Mark 3:3 And he saith unto the man which had the withered hand, Stand forth.

Mark 3:4 And he saith unto them, Is it lawful to do good on the sabbath days, or to do evil? to save life, or to kill? But they held their peace.

Mark 3:5 And when he had looked round about on them with anger, being grieved for the hardness of their hearts, he saith unto the man, Stretch forth thine hand. And he stretched it out: and his hand was restored whole as the other.

Mark 3:6 And the Pharisees went forth, and straightway took counsel with the Herodians against him, how they might destroy him.

Mark 3:7 But Jesus withdrew himself with his disciples to the sea: and a great multitude from Galilee followed him, and from Judæa,

Mark 3:8 And from Jerusalem, and from Idumæa, and from beyond Jordan; and they about Tyre and Sidon, a great multitude, when they had heard what great things he did, came unto him.

Mark 3:9 And he spake to his disciples, that a small ship should wait on him because of the multitude, lest they should throng him.

Mark 3:10 For he had healed many; insomuch that they pressed upon him for to touch him, as many as had plagues.

Mark 3:11 And unclean spirits, when they saw him, fell down before him, and cried, saying, Thou art the Son of God.

Mark 3:12 And he straitly charged them that they should not make him known.

Mark 3:13 And he goeth up into a mountain, and calleth unto him whom he would: and they came unto him.

Mark 3:14 And he ordained twelve, that they should be with him, and that he might send them forth to preach,

Mark 3:15 And to have power to heal sicknesses, and to cast out devils:

Mark 3:16 And Simon he surnamed Peter;

Mark 3:17 And James the son of Zebedee, and John the brother of James; and he surnamed them Boanerges, which is, The sons of thunder:

Mark 3:18 And Andrew, and Philip, and Bartholomew, and Matthew, and Thomas, and James the son of Alphæus, and Thaddæus, and Simon the Canaanite,

Mark 3:19 And Judas Iscariot, which also betrayed him: and they went into an house.

Mark 3:20 And the multitude cometh together again, so that they could not so much as eat bread.

Mark 3:21 And when his friends heard of it, they went out to lay hold on him: for they said, He is beside himself.

Mark 3:22 And the scribes which came down from Jerusalem said, He hath Beelzebub, and by the prince of the devils casteth he out devils.

Mark 3:23 And he called them unto him, and said unto them in parables, How can Satan cast out Satan?

Mark 3:24 And if a kingdom be divided against itself, that kingdom cannot stand.

Mark 3:25 And if a house be divided against itself, that house cannot stand.

Mark 3:26 And if Satan rise up against himself, and be divided, he cannot stand, but hath an end.

Mark 3:27 No man can enter into a strong man’s house, and spoil his goods, except he will first bind the strong man; and then he will spoil his house.

Mark 3:28 Verily I say unto you, All sins shall be forgiven unto the sons of men, and blasphemies wherewith soever they shall blaspheme:

Mark 3:29 But he that shall blaspheme against the Holy Ghost hath never forgiveness, but is in danger of eternal damnation:

Mark 3:30 Because they said, He hath an unclean spirit.

Mark 3:31 There came then his brethren and his mother, and, standing without, sent unto him, calling him.

Mark 3:32 And the multitude sat about him, and they said unto him, Behold, thy mother and thy brethren without seek for thee.

Mark 3:33 And he answered them, saying, Who is my mother, or my brethren?

Mark 3:34 And he looked round about on them which sat about him, and said, Behold my mother and my brethren!

Mark 3:35 For whosoever shall do the will of God, the same is my brother, and my sister, and mother.
