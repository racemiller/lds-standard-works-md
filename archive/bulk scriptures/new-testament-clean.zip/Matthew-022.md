# Matthew 22

Matthew 22 (summary): Jesus gives the parable of the marriage of the king’s son—Pay tribute to Cæsar and to God—Worldly marriages endure in this life only—The first commandment is to love the Lord—Jesus asks, What think ye of Christ?

Matthew 22:1 And Jesus answered and spake unto them again by parables, and said,

Matthew 22:2 The kingdom of heaven is like unto a certain king, which made a marriage for his son,

Matthew 22:3 And sent forth his servants to call them that were bidden to the wedding: and they would not come.

Matthew 22:4 Again, he sent forth other servants, saying, Tell them which are bidden, Behold, I have prepared my dinner: my oxen and my fatlings are killed, and all things are ready: come unto the marriage.

Matthew 22:5 But they made light of it, and went their ways, one to his farm, another to his merchandise:

Matthew 22:6 And the remnant took his servants, and entreated them spitefully, and slew them.

Matthew 22:7 But when the king heard thereof, he was wroth: and he sent forth his armies, and destroyed those murderers, and burned up their city.

Matthew 22:8 Then saith he to his servants, The wedding is ready, but they which were bidden were not worthy.

Matthew 22:9 Go ye therefore into the highways, and as many as ye shall find, bid to the marriage.

Matthew 22:10 So those servants went out into the highways, and gathered together all as many as they found, both bad and good: and the wedding was furnished with guests.

Matthew 22:11 And when the king came in to see the guests, he saw there a man which had not on a wedding garment:

Matthew 22:12 And he saith unto him, Friend, how camest thou in hither not having a wedding garment? And he was speechless.

Matthew 22:13 Then said the king to the servants, Bind him hand and foot, and take him away, and cast him into outer darkness; there shall be weeping and gnashing of teeth.

Matthew 22:14 For many are called, but few are chosen.

Matthew 22:15 Then went the Pharisees, and took counsel how they might entangle him in his talk.

Matthew 22:16 And they sent out unto him their disciples with the Herodians, saying, Master, we know that thou art true, and teachest the way of God in truth, neither carest thou for any man: for thou regardest not the person of men.

Matthew 22:17 Tell us therefore, What thinkest thou? Is it lawful to give tribute unto Cæsar, or not?

Matthew 22:18 But Jesus perceived their wickedness, and said, Why tempt ye me, ye hypocrites?

Matthew 22:19 Shew me the tribute money. And they brought unto him a penny.

Matthew 22:20 And he saith unto them, Whose is this image and superscription?

Matthew 22:21 They say unto him, Cæsar’s. Then saith he unto them, Render therefore unto Cæsar the things which are Cæsar’s; and unto God the things that are God’s.

Matthew 22:22 When they had heard these words, they marvelled, and left him, and went their way.

Matthew 22:23 The same day came to him the Sadducees, which say that there is no resurrection, and asked him,

Matthew 22:24 Saying, Master, Moses said, If a man die, having no children, his brother shall marry his wife, and raise up seed unto his brother.

Matthew 22:25 Now there were with us seven brethren: and the first, when he had married a wife, deceased, and, having no issue, left his wife unto his brother:

Matthew 22:26 Likewise the second also, and the third, unto the seventh.

Matthew 22:27 And last of all the woman died also.

Matthew 22:28 Therefore in the resurrection whose wife shall she be of the seven? for they all had her.

Matthew 22:29 Jesus answered and said unto them, Ye do err, not knowing the scriptures, nor the power of God.

Matthew 22:30 For in the resurrection they neither marry, nor are given in marriage, but are as the angels of God in heaven.

Matthew 22:31 But as touching the resurrection of the dead, have ye not read that which was spoken unto you by God, saying,

Matthew 22:32 I am the God of Abraham, and the God of Isaac, and the God of Jacob? God is not the God of the dead, but of the living.

Matthew 22:33 And when the multitude heard this, they were astonished at his doctrine.

Matthew 22:34 But when the Pharisees had heard that he had put the Sadducees to silence, they were gathered together.

Matthew 22:35 Then one of them, which was a lawyer, asked him a question, tempting him, and saying,

Matthew 22:36 Master, which is the great commandment in the law?

Matthew 22:37 Jesus said unto him, Thou shalt love the Lord thy God with all thy heart, and with all thy soul, and with all thy mind.

Matthew 22:38 This is the first and great commandment.

Matthew 22:39 And the second is like unto it, Thou shalt love thy neighbour as thyself.

Matthew 22:40 On these two commandments hang all the law and the prophets.

Matthew 22:41 While the Pharisees were gathered together, Jesus asked them,

Matthew 22:42 Saying, What think ye of Christ? whose son is he? They say unto him, The Son of David.

Matthew 22:43 He saith unto them, How then doth David in spirit call him Lord, saying,

Matthew 22:44 The Lord said unto my Lord, Sit thou on my right hand, till I make thine enemies thy footstool?

Matthew 22:45 If David then call him Lord, how is he his son?

Matthew 22:46 And no man was able to answer him a word, neither durst any man from that day forth ask him any more questions.
