# Matthew 8

Matthew 8 (summary): Jesus heals a leper, cures the centurion’s servant and others, stills the tempest, and casts out devils—The devils enter a herd of swine.

Matthew 8:1 When he was come down from the mountain, great multitudes followed him.

Matthew 8:2 And, behold, there came a leper and worshipped him, saying, Lord, if thou wilt, thou canst make me clean.

Matthew 8:3 And Jesus put forth his hand, and touched him, saying, I will; be thou clean. And immediately his leprosy was cleansed.

Matthew 8:4 And Jesus saith unto him, See thou tell no man; but go thy way, shew thyself to the priest, and offer the gift that Moses commanded, for a testimony unto them.

Matthew 8:5 And when Jesus was entered into Capernaum, there came unto him a centurion, beseeching him,

Matthew 8:6 And saying, Lord, my servant lieth at home sick of the palsy, grievously tormented.

Matthew 8:7 And Jesus saith unto him, I will come and heal him.

Matthew 8:8 The centurion answered and said, Lord, I am not worthy that thou shouldest come under my roof: but speak the word only, and my servant shall be healed.

Matthew 8:9 For I am a man under authority, having soldiers under me: and I say to this man, Go, and he goeth; and to another, Come, and he cometh; and to my servant, Do this, and he doeth it.

Matthew 8:10 When Jesus heard it, he marvelled, and said to them that followed, Verily I say unto you, I have not found so great faith, no, not in Israel.

Matthew 8:11 And I say unto you, That many shall come from the east and west, and shall sit down with Abraham, and Isaac, and Jacob, in the kingdom of heaven.

Matthew 8:12 But the children of the kingdom shall be cast out into outer darkness: there shall be weeping and gnashing of teeth.

Matthew 8:13 And Jesus said unto the centurion, Go thy way; and as thou hast believed, so be it done unto thee. And his servant was healed in the selfsame hour.

Matthew 8:14 And when Jesus was come into Peter’s house, he saw his wife’s mother laid, and sick of a fever.

Matthew 8:15 And he touched her hand, and the fever left her: and she arose, and ministered unto them.

Matthew 8:16 When the even was come, they brought unto him many that were possessed with devils: and he cast out the spirits with his word, and healed all that were sick:

Matthew 8:17 That it might be fulfilled which was spoken by Esaias the prophet, saying, Himself took our infirmities, and bare our sicknesses.

Matthew 8:18 Now when Jesus saw great multitudes about him, he gave commandment to depart unto the other side.

Matthew 8:19 And a certain scribe came, and said unto him, Master, I will follow thee whithersoever thou goest.

Matthew 8:20 And Jesus saith unto him, The foxes have holes, and the birds of the air have nests; but the Son of man hath not where to lay his head.

Matthew 8:21 And another of his disciples said unto him, Lord, suffer me first to go and bury my father.

Matthew 8:22 But Jesus said unto him, Follow me; and let the dead bury their dead.

Matthew 8:23 And when he was entered into a ship, his disciples followed him.

Matthew 8:24 And, behold, there arose a great tempest in the sea, insomuch that the ship was covered with the waves: but he was asleep.

Matthew 8:25 And his disciples came to him, and awoke him, saying, Lord, save us: we perish.

Matthew 8:26 And he saith unto them, Why are ye fearful, O ye of little faith? Then he arose, and rebuked the winds and the sea; and there was a great calm.

Matthew 8:27 But the men marvelled, saying, What manner of man is this, that even the winds and the sea obey him!

Matthew 8:28 And when he was come to the other side into the country of the Gergesenes, there met him two possessed with devils, coming out of the tombs, exceeding fierce, so that no man might pass by that way.

Matthew 8:29 And, behold, they cried out, saying, What have we to do with thee, Jesus, thou Son of God? art thou come hither to torment us before the time?

Matthew 8:30 And there was a good way off from them an herd of many swine feeding.

Matthew 8:31 So the devils besought him, saying, If thou cast us out, suffer us to go away into the herd of swine.

Matthew 8:32 And he said unto them, Go. And when they were come out, they went into the herd of swine: and, behold, the whole herd of swine ran violently down a steep place into the sea, and perished in the waters.

Matthew 8:33 And they that kept them fled, and went their ways into the city, and told every thing, and what was befallen to the possessed of the devils.

Matthew 8:34 And, behold, the whole city came out to meet Jesus: and when they saw him, they besought him that he would depart out of their coasts.
