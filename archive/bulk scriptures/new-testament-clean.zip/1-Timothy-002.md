# 1 Timothy 2

1 Timothy 2 (summary): We should pray for all people—Christ is our Mediator—Women should dress modestly—Women are blessed in childbearing and are admonished to continue in faith, charity, and holiness.

1 Timothy 2:1 I exhort therefore, that, first of all, supplications, prayers, intercessions, and giving of thanks, be made for all men;

1 Timothy 2:2 For kings, and for all that are in authority; that we may lead a quiet and peaceable life in all godliness and honesty.

1 Timothy 2:3 For this is good and acceptable in the sight of God our Saviour;

1 Timothy 2:4 Who will have all men to be saved, and to come unto the knowledge of the truth.

1 Timothy 2:5 For there is one God, and one mediator between God and men, the man Christ Jesus;

1 Timothy 2:6 Who gave himself a ransom for all, to be testified in due time.

1 Timothy 2:7 Whereunto I am ordained a preacher, and an apostle, (I speak the truth in Christ, and lie not;) a teacher of the Gentiles in faith and verity.

1 Timothy 2:8 I will therefore that men pray every where, lifting up holy hands, without wrath and doubting.

1 Timothy 2:9 In like manner also, that women adorn themselves in modest apparel, with shamefacedness and sobriety; not with broided hair, or gold, or pearls, or costly array;

1 Timothy 2:10 But (which becometh women professing godliness) with good works.

1 Timothy 2:11 Let the woman learn in silence with all subjection.

1 Timothy 2:12 But I suffer not a woman to teach, nor to usurp authority over the man, but to be in silence.

1 Timothy 2:13 For Adam was first formed, then Eve.

1 Timothy 2:14 And Adam was not deceived, but the woman being deceived was in the transgression.

1 Timothy 2:15 Notwithstanding she shall be saved in childbearing, if they continue in faith and charity and holiness with sobriety.
