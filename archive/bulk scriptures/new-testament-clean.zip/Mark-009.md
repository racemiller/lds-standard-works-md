# Mark 9

Mark 9 (summary): Jesus is transfigured on the mountain—He casts out an unclean spirit—He teaches concerning His death and resurrection, who will be greatest, and the condemnation of those who offend His little ones.

Mark 9:1 And he said unto them, Verily I say unto you, That there be some of them that stand here, which shall not taste of death, till they have seen the kingdom of God come with power.

Mark 9:2 And after six days Jesus taketh with him Peter, and James, and John, and leadeth them up into an high mountain apart by themselves: and he was transfigured before them.

Mark 9:3 And his raiment became shining, exceeding white as snow; so as no fuller on earth can white them.

Mark 9:4 And there appeared unto them Elias with Moses: and they were talking with Jesus.

Mark 9:5 And Peter answered and said to Jesus, Master, it is good for us to be here: and let us make three tabernacles; one for thee, and one for Moses, and one for Elias.

Mark 9:6 For he wist not what to say; for they were sore afraid.

Mark 9:7 And there was a cloud that overshadowed them: and a voice came out of the cloud, saying, This is my beloved Son: hear him.

Mark 9:8 And suddenly, when they had looked round about, they saw no man any more, save Jesus only with themselves.

Mark 9:9 And as they came down from the mountain, he charged them that they should tell no man what things they had seen, till the Son of man were risen from the dead.

Mark 9:10 And they kept that saying with themselves, questioning one with another what the rising from the dead should mean.

Mark 9:11 And they asked him, saying, Why say the scribes that Elias must first come?

Mark 9:12 And he answered and told them, Elias verily cometh first, and restoreth all things; and how it is written of the Son of man, that he must suffer many things, and be set at nought.

Mark 9:13 But I say unto you, That Elias is indeed come, and they have done unto him whatsoever they listed, as it is written of him.

Mark 9:14 And when he came to his disciples, he saw a great multitude about them, and the scribes questioning with them.

Mark 9:15 And straightway all the people, when they beheld him, were greatly amazed, and running to him saluted him.

Mark 9:16 And he asked the scribes, What question ye with them?

Mark 9:17 And one of the multitude answered and said, Master, I have brought unto thee my son, which hath a dumb spirit;

Mark 9:18 And wheresoever he taketh him, he teareth him: and he foameth, and gnasheth with his teeth, and pineth away: and I spake to thy disciples that they should cast him out; and they could not.

Mark 9:19 He answereth him, and saith, O faithless generation, how long shall I be with you? how long shall I suffer you? bring him unto me.

Mark 9:20 And they brought him unto him: and when he saw him, straightway the spirit tare him; and he fell on the ground, and wallowed foaming.

Mark 9:21 And he asked his father, How long is it ago since this came unto him? And he said, Of a child.

Mark 9:22 And ofttimes it hath cast him into the fire, and into the waters, to destroy him: but if thou canst do any thing, have compassion on us, and help us.

Mark 9:23 Jesus said unto him, If thou canst believe, all things are possible to him that believeth.

Mark 9:24 And straightway the father of the child cried out, and said with tears, Lord, I believe; help thou mine unbelief.

Mark 9:25 When Jesus saw that the people came running together, he rebuked the foul spirit, saying unto him, Thou dumb and deaf spirit, I charge thee, come out of him, and enter no more into him.

Mark 9:26 And the spirit cried, and rent him sore, and came out of him: and he was as one dead; insomuch that many said, He is dead.

Mark 9:27 But Jesus took him by the hand, and lifted him up; and he arose.

Mark 9:28 And when he was come into the house, his disciples asked him privately, Why could not we cast him out?

Mark 9:29 And he said unto them, This kind can come forth by nothing, but by prayer and fasting.

Mark 9:30 And they departed thence, and passed through Galilee; and he would not that any man should know it.

Mark 9:31 For he taught his disciples, and said unto them, The Son of man is delivered into the hands of men, and they shall kill him; and after that he is killed, he shall rise the third day.

Mark 9:32 But they understood not that saying, and were afraid to ask him.

Mark 9:33 And he came to Capernaum: and being in the house he asked them, What was it that ye disputed among yourselves by the way?

Mark 9:34 But they held their peace: for by the way they had disputed among themselves, who should be the greatest.

Mark 9:35 And he sat down, and called the twelve, and saith unto them, If any man desire to be first, the same shall be last of all, and servant of all.

Mark 9:36 And he took a child, and set him in the midst of them: and when he had taken him in his arms, he said unto them,

Mark 9:37 Whosoever shall receive one of such children in my name, receiveth me: and whosoever shall receive me, receiveth not me, but him that sent me.

Mark 9:38 And John answered him, saying, Master, we saw one casting out devils in thy name, and he followeth not us: and we forbad him, because he followeth not us.

Mark 9:39 But Jesus said, Forbid him not: for there is no man which shall do a miracle in my name, that can lightly speak evil of me.

Mark 9:40 For he that is not against us is on our part.

Mark 9:41 For whosoever shall give you a cup of water to drink in my name, because ye belong to Christ, verily I say unto you, he shall not lose his reward.

Mark 9:42 And whosoever shall offend one of these little ones that believe in me, it is better for him that a millstone were hanged about his neck, and he were cast into the sea.

Mark 9:43 And if thy hand offend thee, cut it off: it is better for thee to enter into life maimed, than having two hands to go into hell, into the fire that never shall be quenched:

Mark 9:44 Where their worm dieth not, and the fire is not quenched.

Mark 9:45 And if thy foot offend thee, cut it off: it is better for thee to enter halt into life, than having two feet to be cast into hell, into the fire that never shall be quenched:

Mark 9:46 Where their worm dieth not, and the fire is not quenched.

Mark 9:47 And if thine eye offend thee, pluck it out: it is better for thee to enter into the kingdom of God with one eye, than having two eyes to be cast into hell fire:

Mark 9:48 Where their worm dieth not, and the fire is not quenched.

Mark 9:49 For every one shall be salted with fire, and every sacrifice shall be salted with salt.

Mark 9:50 Salt is good: but if the salt have lost his saltness, wherewith will ye season it? Have salt in yourselves, and have peace one with another.
