# Acts 11

Acts 11 (summary): God grants the gift of repentance to the Gentiles—The disciples are first called Christians at Antioch—The Church is guided by revelation.

Acts 11:1 And the apostles and brethren that were in Judæa heard that the Gentiles had also received the word of God.

Acts 11:2 And when Peter was come up to Jerusalem, they that were of the circumcision contended with him,

Acts 11:3 Saying, Thou wentest in to men uncircumcised, and didst eat with them.

Acts 11:4 But Peter rehearsed the matter from the beginning, and expounded it by order unto them, saying,

Acts 11:5 I was in the city of Joppa praying: and in a trance I saw a vision, A certain vessel descend, as it had been a great sheet, let down from heaven by four corners; and it came even to me:

Acts 11:6 Upon the which when I had fastened mine eyes, I considered, and saw fourfooted beasts of the earth, and wild beasts, and creeping things, and fowls of the air.

Acts 11:7 And I heard a voice saying unto me, Arise, Peter; slay and eat.

Acts 11:8 But I said, Not so, Lord: for nothing common or unclean hath at any time entered into my mouth.

Acts 11:9 But the voice answered me again from heaven, What God hath cleansed, that call not thou common.

Acts 11:10 And this was done three times: and all were drawn up again into heaven.

Acts 11:11 And, behold, immediately there were three men already come unto the house where I was, sent from Cæsarea unto me.

Acts 11:12 And the Spirit bade me go with them, nothing doubting. Moreover these six brethren accompanied me, and we entered into the man’s house:

Acts 11:13 And he shewed us how he had seen an angel in his house, which stood and said unto him, Send men to Joppa, and call for Simon, whose surname is Peter;

Acts 11:14 Who shall tell thee words, whereby thou and all thy house shall be saved.

Acts 11:15 And as I began to speak, the Holy Ghost fell on them, as on us at the beginning.

Acts 11:16 Then remembered I the word of the Lord, how that he said, John indeed baptized with water; but ye shall be baptized with the Holy Ghost.

Acts 11:17 Forasmuch then as God gave them the like gift as he did unto us, who believed on the Lord Jesus Christ; what was I, that I could withstand God?

Acts 11:18 When they heard these things, they held their peace, and glorified God, saying, Then hath God also to the Gentiles granted repentance unto life.

Acts 11:19 Now they which were scattered abroad upon the persecution that arose about Stephen travelled as far as Phenice, and Cyprus, and Antioch, preaching the word to none but unto the Jews only.

Acts 11:20 And some of them were men of Cyprus and Cyrene, which, when they were come to Antioch, spake unto the Grecians, preaching the Lord Jesus.

Acts 11:21 And the hand of the Lord was with them: and a great number believed, and turned unto the Lord.

Acts 11:22 Then tidings of these things came unto the ears of the church which was in Jerusalem: and they sent forth Barnabas, that he should go as far as Antioch.

Acts 11:23 Who, when he came, and had seen the grace of God, was glad, and exhorted them all, that with purpose of heart they would cleave unto the Lord.

Acts 11:24 For he was a good man, and full of the Holy Ghost and of faith: and much people was added unto the Lord.

Acts 11:25 Then departed Barnabas to Tarsus, for to seek Saul:

Acts 11:26 And when he had found him, he brought him unto Antioch. And it came to pass, that a whole year they assembled themselves with the church, and taught much people. And the disciples were called Christians first in Antioch.

Acts 11:27 And in these days came prophets from Jerusalem unto Antioch.

Acts 11:28 And there stood up one of them named Agabus, and signified by the Spirit that there should be great dearth throughout all the world: which came to pass in the days of Claudius Cæsar.

Acts 11:29 Then the disciples, every man according to his ability, determined to send relief unto the brethren which dwelt in Judæa:

Acts 11:30 Which also they did, and sent it to the elders by the hands of Barnabas and Saul.
