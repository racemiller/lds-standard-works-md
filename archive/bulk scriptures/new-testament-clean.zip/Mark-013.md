# Mark 13

Mark 13 (summary): Jesus tells of the calamities and signs preceding the Second Coming—There will be false Christs and false prophets—He gives the parable of the fig tree.

Mark 13:1 And as he went out of the temple, one of his disciples saith unto him, Master, see what manner of stones and what buildings are here!

Mark 13:2 And Jesus answering said unto him, Seest thou these great buildings? there shall not be left one stone upon another, that shall not be thrown down.

Mark 13:3 And as he sat upon the mount of Olives over against the temple, Peter and James and John and Andrew asked him privately,

Mark 13:4 Tell us, when shall these things be? and what shall be the sign when all these things shall be fulfilled?

Mark 13:5 And Jesus answering them began to say, Take heed lest any man deceive you:

Mark 13:6 For many shall come in my name, saying, I am Christ; and shall deceive many.

Mark 13:7 And when ye shall hear of wars and rumours of wars, be ye not troubled: for such things must needs be; but the end shall not be yet.

Mark 13:8 For nation shall rise against nation, and kingdom against kingdom: and there shall be earthquakes in divers places, and there shall be famines and troubles: these are the beginnings of sorrows.

Mark 13:9 But take heed to yourselves: for they shall deliver you up to councils; and in the synagogues ye shall be beaten: and ye shall be brought before rulers and kings for my sake, for a testimony against them.

Mark 13:10 And the gospel must first be published among all nations.

Mark 13:11 But when they shall lead you, and deliver you up, take no thought beforehand what ye shall speak, neither do ye premeditate: but whatsoever shall be given you in that hour, that speak ye: for it is not ye that speak, but the Holy Ghost.

Mark 13:12 Now the brother shall betray the brother to death, and the father the son; and children shall rise up against their parents, and shall cause them to be put to death.

Mark 13:13 And ye shall be hated of all men for my name’s sake: but he that shall endure unto the end, the same shall be saved.

Mark 13:14 But when ye shall see the abomination of desolation, spoken of by Daniel the prophet, standing where it ought not, (let him that readeth understand,) then let them that be in Judæa flee to the mountains:

Mark 13:15 And let him that is on the housetop not go down into the house, neither enter therein, to take any thing out of his house:

Mark 13:16 And let him that is in the field not turn back again for to take up his garment.

Mark 13:17 But woe to them that are with child, and to them that give suck in those days!

Mark 13:18 And pray ye that your flight be not in the winter.

Mark 13:19 For in those days shall be affliction, such as was not from the beginning of the creation which God created unto this time, neither shall be.

Mark 13:20 And except that the Lord had shortened those days, no flesh should be saved: but for the elect’s sake, whom he hath chosen, he hath shortened the days.

Mark 13:21 And then if any man shall say to you, Lo, here is Christ; or, lo, he is there; believe him not:

Mark 13:22 For false Christs and false prophets shall rise, and shall shew signs and wonders, to seduce, if it were possible, even the elect.

Mark 13:23 But take ye heed: behold, I have foretold you all things.

Mark 13:24 But in those days, after that tribulation, the sun shall be darkened, and the moon shall not give her light,

Mark 13:25 And the stars of heaven shall fall, and the powers that are in heaven shall be shaken.

Mark 13:26 And then shall they see the Son of man coming in the clouds with great power and glory.

Mark 13:27 And then shall he send his angels, and shall gather together his elect from the four winds, from the uttermost part of the earth to the uttermost part of heaven.

Mark 13:28 Now learn a parable of the fig tree; When her branch is yet tender, and putteth forth leaves, ye know that summer is near:

Mark 13:29 So ye in like manner, when ye shall see these things come to pass, know that it is nigh, even at the doors.

Mark 13:30 Verily I say unto you, that this generation shall not pass, till all these things be done.

Mark 13:31 Heaven and earth shall pass away: but my words shall not pass away.

Mark 13:32 But of that day and that hour knoweth no man, no, not the angels which are in heaven, neither the Son, but the Father.

Mark 13:33 Take ye heed, watch and pray: for ye know not when the time is.

Mark 13:34 For the Son of man is as a man taking a far journey, who left his house, and gave authority to his servants, and to every man his work, and commanded the porter to watch.

Mark 13:35 Watch ye therefore: for ye know not when the master of the house cometh, at even, or at midnight, or at the cockcrowing, or in the morning:

Mark 13:36 Lest coming suddenly he find you sleeping.

Mark 13:37 And what I say unto you I say unto all, Watch.
