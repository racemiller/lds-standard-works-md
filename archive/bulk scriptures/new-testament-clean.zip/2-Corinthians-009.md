# 2 Corinthians 9

2 Corinthians 9 (summary): God loves and rewards a cheerful giver—Thanks be to God for His unspeakable gift.

2 Corinthians 9:1 For as touching the ministering to the saints, it is superfluous for me to write to you:

2 Corinthians 9:2 For I know the forwardness of your mind, for which I boast of you to them of Macedonia, that Achaia was ready a year ago; and your zeal hath provoked very many.

2 Corinthians 9:3 Yet have I sent the brethren, lest our boasting of you should be in vain in this behalf; that, as I said, ye may be ready:

2 Corinthians 9:4 Lest haply if they of Macedonia come with me, and find you unprepared, we (that we say not, ye) should be ashamed in this same confident boasting.

2 Corinthians 9:5 Therefore I thought it necessary to exhort the brethren, that they would go before unto you, and make up beforehand your bounty, whereof ye had notice before, that the same might be ready, as a matter of bounty, and not as of covetousness.

2 Corinthians 9:6 But this I say, He which soweth sparingly shall reap also sparingly; and he which soweth bountifully shall reap also bountifully.

2 Corinthians 9:7 Every man according as he purposeth in his heart, so let him give; not grudgingly, or of necessity: for God loveth a cheerful giver.

2 Corinthians 9:8 And God is able to make all grace abound toward you; that ye, always having all sufficiency in all things, may abound to every good work:

2 Corinthians 9:9 (As it is written, He hath dispersed abroad; he hath given to the poor: his righteousness remaineth for ever.

2 Corinthians 9:10 Now he that ministereth seed to the sower both minister bread for your food, and multiply your seed sown, and increase the fruits of your righteousness;)

2 Corinthians 9:11 Being enriched in every thing to all bountifulness, which causeth through us thanksgiving to God.

2 Corinthians 9:12 For the administration of this service not only supplieth the want of the saints, but is abundant also by many thanksgivings unto God;

2 Corinthians 9:13 Whiles by the experiment of this ministration they glorify God for your professed subjection unto the gospel of Christ, and for your liberal distribution unto them, and unto all men;

2 Corinthians 9:14 And by their prayer for you, which long after you for the exceeding grace of God in you.

2 Corinthians 9:15 Thanks be unto God for his unspeakable gift.
