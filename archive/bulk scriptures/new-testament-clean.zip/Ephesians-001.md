# Ephesians 1

Ephesians 1 (summary): The Saints are foreordained to receive the gospel—The gospel is to be restored in the latter days—The Saints are sealed by the Holy Spirit of Promise—They know God and Christ by revelation.

Ephesians 1:1 Paul, an apostle of Jesus Christ by the will of God, to the saints which are at Ephesus, and to the faithful in Christ Jesus:

Ephesians 1:2 Grace be to you, and peace, from God our Father, and from the Lord Jesus Christ.

Ephesians 1:3 Blessed be the God and Father of our Lord Jesus Christ, who hath blessed us with all spiritual blessings in heavenly places in Christ:

Ephesians 1:4 According as he hath chosen us in him before the foundation of the world, that we should be holy and without blame before him in love:

Ephesians 1:5 Having predestinated us unto the adoption of children by Jesus Christ to himself, according to the good pleasure of his will,

Ephesians 1:6 To the praise of the glory of his grace, wherein he hath made us accepted in the beloved.

Ephesians 1:7 In whom we have redemption through his blood, the forgiveness of sins, according to the riches of his grace;

Ephesians 1:8 Wherein he hath abounded toward us in all wisdom and prudence;

Ephesians 1:9 Having made known unto us the mystery of his will, according to his good pleasure which he hath purposed in himself:

Ephesians 1:10 That in the dispensation of the fulness of times he might gather together in one all things in Christ, both which are in heaven, and which are on earth; even in him:

Ephesians 1:11 In whom also we have obtained an inheritance, being predestinated according to the purpose of him who worketh all things after the counsel of his own will:

Ephesians 1:12 That we should be to the praise of his glory, who first trusted in Christ.

Ephesians 1:13 In whom ye also trusted, after that ye heard the word of truth, the gospel of your salvation: in whom also after that ye believed, ye were sealed with that holy Spirit of promise,

Ephesians 1:14 Which is the earnest of our inheritance until the redemption of the purchased possession, unto the praise of his glory.

Ephesians 1:15 Wherefore I also, after I heard of your faith in the Lord Jesus, and love unto all the saints,

Ephesians 1:16 Cease not to give thanks for you, making mention of you in my prayers;

Ephesians 1:17 That the God of our Lord Jesus Christ, the Father of glory, may give unto you the spirit of wisdom and revelation in the knowledge of him:

Ephesians 1:18 The eyes of your understanding being enlightened; that ye may know what is the hope of his calling, and what the riches of the glory of his inheritance in the saints,

Ephesians 1:19 And what is the exceeding greatness of his power to us-ward who believe, according to the working of his mighty power,

Ephesians 1:20 Which he wrought in Christ, when he raised him from the dead, and set him at his own right hand in the heavenly places,

Ephesians 1:21 Far above all principality, and power, and might, and dominion, and every name that is named, not only in this world, but also in that which is to come:

Ephesians 1:22 And hath put all things under his feet, and gave him to be the head over all things to the church,

Ephesians 1:23 Which is his body, the fulness of him that filleth all in all.
