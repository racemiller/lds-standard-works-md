# 1 Timothy 6

1 Timothy 6 (summary): The love of money is the root of all evil—Fight the good fight of faith—Do not trust in worldly riches.

1 Timothy 6:1 Let as many servants as are under the yoke count their own masters worthy of all honour, that the name of God and his doctrine be not blasphemed.

1 Timothy 6:2 And they that have believing masters, let them not despise them, because they are brethren; but rather do them service, because they are faithful and beloved, partakers of the benefit. These things teach and exhort.

1 Timothy 6:3 If any man teach otherwise, and consent not to wholesome words, even the words of our Lord Jesus Christ, and to the doctrine which is according to godliness;

1 Timothy 6:4 He is proud, knowing nothing, but doting about questions and strifes of words, whereof cometh envy, strife, railings, evil surmisings,

1 Timothy 6:5 Perverse disputings of men of corrupt minds, and destitute of the truth, supposing that gain is godliness: from such withdraw thyself.

1 Timothy 6:6 But godliness with contentment is great gain.

1 Timothy 6:7 For we brought nothing into this world, and it is certain we can carry nothing out.

1 Timothy 6:8 And having food and raiment let us be therewith content.

1 Timothy 6:9 But they that will be rich fall into temptation and a snare, and into many foolish and hurtful lusts, which drown men in destruction and perdition.

1 Timothy 6:10 For the love of money is the root of all evil: which while some coveted after, they have erred from the faith, and pierced themselves through with many sorrows.

1 Timothy 6:11 But thou, O man of God, flee these things; and follow after righteousness, godliness, faith, love, patience, meekness.

1 Timothy 6:12 Fight the good fight of faith, lay hold on eternal life, whereunto thou art also called, and hast professed a good profession before many witnesses.

1 Timothy 6:13 I give thee charge in the sight of God, who quickeneth all things, and before Christ Jesus, who before Pontius Pilate witnessed a good confession;

1 Timothy 6:14 That thou keep this commandment without spot, unrebukeable, until the appearing of our Lord Jesus Christ:

1 Timothy 6:15 Which in his times he shall shew, who is the blessed and only Potentate, the King of kings, and Lord of lords;

1 Timothy 6:16 Who only hath immortality, dwelling in the light which no man can approach unto; whom no man hath seen, nor can see: to whom be honour and power everlasting. Amen.

1 Timothy 6:17 Charge them that are rich in this world, that they be not highminded, nor trust in uncertain riches, but in the living God, who giveth us richly all things to enjoy;

1 Timothy 6:18 That they do good, that they be rich in good works, ready to distribute, willing to communicate;

1 Timothy 6:19 Laying up in store for themselves a good foundation against the time to come, that they may lay hold on eternal life.

1 Timothy 6:20 O Timothy, keep that which is committed to thy trust, avoiding profane and vain babblings, and oppositions of science falsely so called:

1 Timothy 6:21 Which some professing have erred concerning the faith. Grace be with thee. Amen.
