# John 14

John 14 (summary): Jesus speaks of many mansions—He says that He is the way, the truth, and the life and that to see Him is to see the Father—He promises the first and second Comforters.

John 14:1 Let not your heart be troubled: ye believe in God, believe also in me.

John 14:2 In my Father’s house are many mansions: if it were not so, I would have told you. I go to prepare a place for you.

John 14:3 And if I go and prepare a place for you, I will come again, and receive you unto myself; that where I am, there ye may be also.

John 14:4 And whither I go ye know, and the way ye know.

John 14:5 Thomas saith unto him, Lord, we know not whither thou goest; and how can we know the way?

John 14:6 Jesus saith unto him, I am the way, the truth, and the life: no man cometh unto the Father, but by me.

John 14:7 If ye had known me, ye should have known my Father also: and from henceforth ye know him, and have seen him.

John 14:8 Philip saith unto him, Lord, shew us the Father, and it sufficeth us.

John 14:9 Jesus saith unto him, Have I been so long time with you, and yet hast thou not known me, Philip? he that hath seen me hath seen the Father; and how sayest thou then, Shew us the Father?

John 14:10 Believest thou not that I am in the Father, and the Father in me? the words that I speak unto you I speak not of myself: but the Father that dwelleth in me, he doeth the works.

John 14:11 Believe me that I am in the Father, and the Father in me: or else believe me for the very works’ sake.

John 14:12 Verily, verily, I say unto you, He that believeth on me, the works that I do shall he do also; and greater works than these shall he do; because I go unto my Father.

John 14:13 And whatsoever ye shall ask in my name, that will I do, that the Father may be glorified in the Son.

John 14:14 If ye shall ask any thing in my name, I will do it.

John 14:15 If ye love me, keep my commandments.

John 14:16 And I will pray the Father, and he shall give you another Comforter, that he may abide with you for ever;

John 14:17 Even the Spirit of truth; whom the world cannot receive, because it seeth him not, neither knoweth him: but ye know him; for he dwelleth with you, and shall be in you.

John 14:18 I will not leave you comfortless: I will come to you.

John 14:19 Yet a little while, and the world seeth me no more; but ye see me: because I live, ye shall live also.

John 14:20 At that day ye shall know that I am in my Father, and ye in me, and I in you.

John 14:21 He that hath my commandments, and keepeth them, he it is that loveth me: and he that loveth me shall be loved of my Father, and I will love him, and will manifest myself to him.

John 14:22 Judas saith unto him, not Iscariot, Lord, how is it that thou wilt manifest thyself unto us, and not unto the world?

John 14:23 Jesus answered and said unto him, If a man love me, he will keep my words: and my Father will love him, and we will come unto him, and make our abode with him.

John 14:24 He that loveth me not keepeth not my sayings: and the word which ye hear is not mine, but the Father’s which sent me.

John 14:25 These things have I spoken unto you, being yet present with you.

John 14:26 But the Comforter, which is the Holy Ghost, whom the Father will send in my name, he shall teach you all things, and bring all things to your remembrance, whatsoever I have said unto you.

John 14:27 Peace I leave with you, my peace I give unto you: not as the world giveth, give I unto you. Let not your heart be troubled, neither let it be afraid.

John 14:28 Ye have heard how I said unto you, I go away, and come again unto you. If ye loved me, ye would rejoice, because I said, I go unto the Father: for my Father is greater than I.

John 14:29 And now I have told you before it come to pass, that, when it is come to pass, ye might believe.

John 14:30 Hereafter I will not talk much with you: for the prince of this world cometh, and hath nothing in me.

John 14:31 But that the world may know that I love the Father; and as the Father gave me commandment, even so I do. Arise, let us go hence.
