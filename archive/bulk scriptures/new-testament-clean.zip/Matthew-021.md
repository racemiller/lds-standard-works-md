# Matthew 21

Matthew 21 (summary): Jesus rides in triumph into Jerusalem—He cleanses the temple, curses the fig tree, and discusses authority—He gives the parables of the two sons and the wicked husbandmen.

Matthew 21:1 And when they drew nigh unto Jerusalem, and were come to Bethphage, unto the mount of Olives, then sent Jesus two disciples,

Matthew 21:2 Saying unto them, Go into the village over against you, and straightway ye shall find an ass tied, and a colt with her: loose them, and bring them unto me.

Matthew 21:3 And if any man say ought unto you, ye shall say, The Lord hath need of them; and straightway he will send them.

Matthew 21:4 All this was done, that it might be fulfilled which was spoken by the prophet, saying,

Matthew 21:5 Tell ye the daughter of Sion, Behold, thy King cometh unto thee, meek, and sitting upon an ass, and a colt the foal of an ass.

Matthew 21:6 And the disciples went, and did as Jesus commanded them,

Matthew 21:7 And brought the ass, and the colt, and put on them their clothes, and they set him thereon.

Matthew 21:8 And a very great multitude spread their garments in the way; others cut down branches from the trees, and strawed them in the way.

Matthew 21:9 And the multitudes that went before, and that followed, cried, saying, Hosanna to the Son of David: Blessed is he that cometh in the name of the Lord; Hosanna in the highest.

Matthew 21:10 And when he was come into Jerusalem, all the city was moved, saying, Who is this?

Matthew 21:11 And the multitude said, This is Jesus the prophet of Nazareth of Galilee.

Matthew 21:12 And Jesus went into the temple of God, and cast out all them that sold and bought in the temple, and overthrew the tables of the moneychangers, and the seats of them that sold doves,

Matthew 21:13 And said unto them, It is written, My house shall be called the house of prayer; but ye have made it a den of thieves.

Matthew 21:14 And the blind and the lame came to him in the temple; and he healed them.

Matthew 21:15 And when the chief priests and scribes saw the wonderful things that he did, and the children crying in the temple, and saying, Hosanna to the Son of David; they were sore displeased,

Matthew 21:16 And said unto him, Hearest thou what these say? And Jesus saith unto them, Yea; have ye never read, Out of the mouth of babes and sucklings thou hast perfected praise?

Matthew 21:17 And he left them, and went out of the city into Bethany; and he lodged there.

Matthew 21:18 Now in the morning as he returned into the city, he hungered.

Matthew 21:19 And when he saw a fig tree in the way, he came to it, and found nothing thereon, but leaves only, and said unto it, Let no fruit grow on thee henceforward for ever. And presently the fig tree withered away.

Matthew 21:20 And when the disciples saw it, they marvelled, saying, How soon is the fig tree withered away!

Matthew 21:21 Jesus answered and said unto them, Verily I say unto you, If ye have faith, and doubt not, ye shall not only do this which is done to the fig tree, but also if ye shall say unto this mountain, Be thou removed, and be thou cast into the sea; it shall be done.

Matthew 21:22 And all things, whatsoever ye shall ask in prayer, believing, ye shall receive.

Matthew 21:23 And when he was come into the temple, the chief priests and the elders of the people came unto him as he was teaching, and said, By what authority doest thou these things? and who gave thee this authority?

Matthew 21:24 And Jesus answered and said unto them, I also will ask you one thing, which if ye tell me, I in like wise will tell you by what authority I do these things.

Matthew 21:25 The baptism of John, whence was it? from heaven, or of men? And they reasoned with themselves, saying, If we shall say, From heaven; he will say unto us, Why did ye not then believe him?

Matthew 21:26 But if we shall say, Of men; we fear the people; for all hold John as a prophet.

Matthew 21:27 And they answered Jesus, and said, We cannot tell. And he said unto them, Neither tell I you by what authority I do these things.

Matthew 21:28 But what think ye? A certain man had two sons; and he came to the first, and said, Son, go work to day in my vineyard.

Matthew 21:29 He answered and said, I will not: but afterward he repented, and went.

Matthew 21:30 And he came to the second, and said likewise. And he answered and said, I go, sir: and went not.

Matthew 21:31 Whether of them twain did the will of his father? They say unto him, The first. Jesus saith unto them, Verily I say unto you, That the publicans and the harlots go into the kingdom of God before you.

Matthew 21:32 For John came unto you in the way of righteousness, and ye believed him not: but the publicans and the harlots believed him: and ye, when ye had seen it, repented not afterward, that ye might believe him.

Matthew 21:33 Hear another parable: There was a certain householder, which planted a vineyard, and hedged it round about, and digged a winepress in it, and built a tower, and let it out to husbandmen, and went into a far country:

Matthew 21:34 And when the time of the fruit drew near, he sent his servants to the husbandmen, that they might receive the fruits of it.

Matthew 21:35 And the husbandmen took his servants, and beat one, and killed another, and stoned another.

Matthew 21:36 Again, he sent other servants more than the first: and they did unto them likewise.

Matthew 21:37 But last of all he sent unto them his son, saying, They will reverence my son.

Matthew 21:38 But when the husbandmen saw the son, they said among themselves, This is the heir; come, let us kill him, and let us seize on his inheritance.

Matthew 21:39 And they caught him, and cast him out of the vineyard, and slew him.

Matthew 21:40 When the lord therefore of the vineyard cometh, what will he do unto those husbandmen?

Matthew 21:41 They say unto him, He will miserably destroy those wicked men, and will let out his vineyard unto other husbandmen, which shall render him the fruits in their seasons.

Matthew 21:42 Jesus saith unto them, Did ye never read in the scriptures, The stone which the builders rejected, the same is become the head of the corner: this is the Lord’s doing, and it is marvellous in our eyes?

Matthew 21:43 Therefore say I unto you, The kingdom of God shall be taken from you, and given to a nation bringing forth the fruits thereof.

Matthew 21:44 And whosoever shall fall on this stone shall be broken: but on whomsoever it shall fall, it will grind him to powder.

Matthew 21:45 And when the chief priests and Pharisees had heard his parables, they perceived that he spake of them.

Matthew 21:46 But when they sought to lay hands on him, they feared the multitude, because they took him for a prophet.
