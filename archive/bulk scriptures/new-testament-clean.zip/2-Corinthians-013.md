# 2 Corinthians 13

2 Corinthians 13 (summary): Saints should test themselves as to righteousness—Be perfect and of one mind; live in peace.

2 Corinthians 13:1 This is the third time I am coming to you. In the mouth of two or three witnesses shall every word be established.

2 Corinthians 13:2 I told you before, and foretell you, as if I were present, the second time; and being absent now I write to them which heretofore have sinned, and to all other, that, if I come again, I will not spare:

2 Corinthians 13:3 Since ye seek a proof of Christ speaking in me, which to you-ward is not weak, but is mighty in you.

2 Corinthians 13:4 For though he was crucified through weakness, yet he liveth by the power of God. For we also are weak in him, but we shall live with him by the power of God toward you.

2 Corinthians 13:5 Examine yourselves, whether ye be in the faith; prove your own selves. Know ye not your own selves, how that Jesus Christ is in you, except ye be reprobates?

2 Corinthians 13:6 But I trust that ye shall know that we are not reprobates.

2 Corinthians 13:7 Now I pray to God that ye do no evil; not that we should appear approved, but that ye should do that which is honest, though we be as reprobates.

2 Corinthians 13:8 For we can do nothing against the truth, but for the truth.

2 Corinthians 13:9 For we are glad, when we are weak, and ye are strong: and this also we wish, even your perfection.

2 Corinthians 13:10 Therefore I write these things being absent, lest being present I should use sharpness, according to the power which the Lord hath given me to edification, and not to destruction.

2 Corinthians 13:11 Finally, brethren, farewell. Be perfect, be of good comfort, be of one mind, live in peace; and the God of love and peace shall be with you.

2 Corinthians 13:12 Greet one another with an holy kiss.

2 Corinthians 13:13 All the saints salute you.

2 Corinthians 13:14 The grace of the Lord Jesus Christ, and the love of God, and the communion of the Holy Ghost, be with you all. Amen.
