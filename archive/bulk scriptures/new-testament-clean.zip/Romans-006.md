# Romans 6

Romans 6 (summary): Baptism is in similitude of the death, burial, and resurrection of Christ—The wages of sin is death—Christ brings eternal life.

Romans 6:1 What shall we say then? Shall we continue in sin, that grace may abound?

Romans 6:2 God forbid. How shall we, that are dead to sin, live any longer therein?

Romans 6:3 Know ye not, that so many of us as were baptized into Jesus Christ were baptized into his death?

Romans 6:4 Therefore we are buried with him by baptism into death: that like as Christ was raised up from the dead by the glory of the Father, even so we also should walk in newness of life.

Romans 6:5 For if we have been planted together in the likeness of his death, we shall be also in the likeness of his resurrection:

Romans 6:6 Knowing this, that our old man is crucified with him, that the body of sin might be destroyed, that henceforth we should not serve sin.

Romans 6:7 For he that is dead is freed from sin.

Romans 6:8 Now if we be dead with Christ, we believe that we shall also live with him:

Romans 6:9 Knowing that Christ being raised from the dead dieth no more; death hath no more dominion over him.

Romans 6:10 For in that he died, he died unto sin once: but in that he liveth, he liveth unto God.

Romans 6:11 Likewise reckon ye also yourselves to be dead indeed unto sin, but alive unto God through Jesus Christ our Lord.

Romans 6:12 Let not sin therefore reign in your mortal body, that ye should obey it in the lusts thereof.

Romans 6:13 Neither yield ye your members as instruments of unrighteousness unto sin: but yield yourselves unto God, as those that are alive from the dead, and your members as instruments of righteousness unto God.

Romans 6:14 For sin shall not have dominion over you: for ye are not under the law, but under grace.

Romans 6:15 What then? shall we sin, because we are not under the law, but under grace? God forbid.

Romans 6:16 Know ye not, that to whom ye yield yourselves servants to obey, his servants ye are to whom ye obey; whether of sin unto death, or of obedience unto righteousness?

Romans 6:17 But God be thanked, that ye were the servants of sin, but ye have obeyed from the heart that form of doctrine which was delivered you.

Romans 6:18 Being then made free from sin, ye became the servants of righteousness.

Romans 6:19 I speak after the manner of men because of the infirmity of your flesh: for as ye have yielded your members servants to uncleanness and to iniquity unto iniquity; even so now yield your members servants to righteousness unto holiness.

Romans 6:20 For when ye were the servants of sin, ye were free from righteousness.

Romans 6:21 What fruit had ye then in those things whereof ye are now ashamed? for the end of those things is death.

Romans 6:22 But now being made free from sin, and become servants to God, ye have your fruit unto holiness, and the end everlasting life.

Romans 6:23 For the wages of sin is death; but the gift of God is eternal life through Jesus Christ our Lord.
