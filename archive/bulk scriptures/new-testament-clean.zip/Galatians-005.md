# Galatians 5

Galatians 5 (summary): Stand fast in gospel liberty—Seek faith, love, Christ, and the Spirit—The works of the flesh and the fruits of the Spirit are named.

Galatians 5:1 Stand fast therefore in the liberty wherewith Christ hath made us free, and be not entangled again with the yoke of bondage.

Galatians 5:2 Behold, I Paul say unto you, that if ye be circumcised, Christ shall profit you nothing.

Galatians 5:3 For I testify again to every man that is circumcised, that he is a debtor to do the whole law.

Galatians 5:4 Christ is become of no effect unto you, whosoever of you are justified by the law; ye are fallen from grace.

Galatians 5:5 For we through the Spirit wait for the hope of righteousness by faith.

Galatians 5:6 For in Jesus Christ neither circumcision availeth any thing, nor uncircumcision; but faith which worketh by love.

Galatians 5:7 Ye did run well; who did hinder you that ye should not obey the truth?

Galatians 5:8 This persuasion cometh not of him that calleth you.

Galatians 5:9 A little leaven leaveneth the whole lump.

Galatians 5:10 I have confidence in you through the Lord, that ye will be none otherwise minded: but he that troubleth you shall bear his judgment, whosoever he be.

Galatians 5:11 And I, brethren, if I yet preach circumcision, why do I yet suffer persecution? then is the offence of the cross ceased.

Galatians 5:12 I would they were even cut off which trouble you.

Galatians 5:13 For, brethren, ye have been called unto liberty; only use not liberty for an occasion to the flesh, but by love serve one another.

Galatians 5:14 For all the law is fulfilled in one word, even in this; Thou shalt love thy neighbour as thyself.

Galatians 5:15 But if ye bite and devour one another, take heed that ye be not consumed one of another.

Galatians 5:16 This I say then, Walk in the Spirit, and ye shall not fulfil the lust of the flesh.

Galatians 5:17 For the flesh lusteth against the Spirit, and the Spirit against the flesh: and these are contrary the one to the other: so that ye cannot do the things that ye would.

Galatians 5:18 But if ye be led of the Spirit, ye are not under the law.

Galatians 5:19 Now the works of the flesh are manifest, which are these; Adultery, fornication, uncleanness, lasciviousness,

Galatians 5:20 Idolatry, witchcraft, hatred, variance, emulations, wrath, strife, seditions, heresies,

Galatians 5:21 Envyings, murders, drunkenness, revellings, and such like: of the which I tell you before, as I have also told you in time past, that they which do such things shall not inherit the kingdom of God.

Galatians 5:22 But the fruit of the Spirit is love, joy, peace, longsuffering, gentleness, goodness, faith,

Galatians 5:23 Meekness, temperance: against such there is no law.

Galatians 5:24 And they that are Christ’s have crucified the flesh with the affections and lusts.

Galatians 5:25 If we live in the Spirit, let us also walk in the Spirit.

Galatians 5:26 Let us not be desirous of vain glory, provoking one another, envying one another.
