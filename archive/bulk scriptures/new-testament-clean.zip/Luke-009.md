# Luke 9

Luke 9 (summary): The Twelve are sent out—Jesus feeds the five thousand—Peter testifies of Christ—Jesus foretells His death and resurrection—He is transfigured on the mount—He heals and teaches.

Luke 9:1 Then he called his twelve disciples together, and gave them power and authority over all devils, and to cure diseases.

Luke 9:2 And he sent them to preach the kingdom of God, and to heal the sick.

Luke 9:3 And he said unto them, Take nothing for your journey, neither staves, nor scrip, neither bread, neither money; neither have two coats apiece.

Luke 9:4 And whatsoever house ye enter into, there abide, and thence depart.

Luke 9:5 And whosoever will not receive you, when ye go out of that city, shake off the very dust from your feet for a testimony against them.

Luke 9:6 And they departed, and went through the towns, preaching the gospel, and healing every where.

Luke 9:7 Now Herod the tetrarch heard of all that was done by him: and he was perplexed, because that it was said of some, that John was risen from the dead;

Luke 9:8 And of some, that Elias had appeared; and of others, that one of the old prophets was risen again.

Luke 9:9 And Herod said, John have I beheaded: but who is this, of whom I hear such things? And he desired to see him.

Luke 9:10 And the apostles, when they were returned, told him all that they had done. And he took them, and went aside privately into a desert place belonging to the city called Bethsaida.

Luke 9:11 And the people, when they knew it, followed him: and he received them, and spake unto them of the kingdom of God, and healed them that had need of healing.

Luke 9:12 And when the day began to wear away, then came the twelve, and said unto him, Send the multitude away, that they may go into the towns and country round about, and lodge, and get victuals: for we are here in a desert place.

Luke 9:13 But he said unto them, Give ye them to eat. And they said, We have no more but five loaves and two fishes; except we should go and buy meat for all this people.

Luke 9:14 For they were about five thousand men. And he said to his disciples, Make them sit down by fifties in a company.

Luke 9:15 And they did so, and made them all sit down.

Luke 9:16 Then he took the five loaves and the two fishes, and looking up to heaven, he blessed them, and brake, and gave to the disciples to set before the multitude.

Luke 9:17 And they did eat, and were all filled: and there was taken up of fragments that remained to them twelve baskets.

Luke 9:18 And it came to pass, as he was alone praying, his disciples were with him: and he asked them, saying, Whom say the people that I am?

Luke 9:19 They answering said, John the Baptist; but some say, Elias; and others say, that one of the old prophets is risen again.

Luke 9:20 He said unto them, But whom say ye that I am? Peter answering said, The Christ of God.

Luke 9:21 And he straitly charged them, and commanded them to tell no man that thing;

Luke 9:22 Saying, The Son of man must suffer many things, and be rejected of the elders and chief priests and scribes, and be slain, and be raised the third day.

Luke 9:23 And he said to them all, If any man will come after me, let him deny himself, and take up his cross daily, and follow me.

Luke 9:24 For whosoever will save his life shall lose it: but whosoever will lose his life for my sake, the same shall save it.

Luke 9:25 For what is a man advantaged, if he gain the whole world, and lose himself, or be cast away?

Luke 9:26 For whosoever shall be ashamed of me and of my words, of him shall the Son of man be ashamed, when he shall come in his own glory, and in his Father’s, and of the holy angels.

Luke 9:27 But I tell you of a truth, there be some standing here, which shall not taste of death, till they see the kingdom of God.

Luke 9:28 And it came to pass about an eight days after these sayings, he took Peter and John and James, and went up into a mountain to pray.

Luke 9:29 And as he prayed, the fashion of his countenance was altered, and his raiment was white and glistering.

Luke 9:30 And, behold, there talked with him two men, which were Moses and Elias:

Luke 9:31 Who appeared in glory, and spake of his decease which he should accomplish at Jerusalem.

Luke 9:32 But Peter and they that were with him were heavy with sleep: and when they were awake, they saw his glory, and the two men that stood with him.

Luke 9:33 And it came to pass, as they departed from him, Peter said unto Jesus, Master, it is good for us to be here: and let us make three tabernacles; one for thee, and one for Moses, and one for Elias: not knowing what he said.

Luke 9:34 While he thus spake, there came a cloud, and overshadowed them: and they feared as they entered into the cloud.

Luke 9:35 And there came a voice out of the cloud, saying, This is my beloved Son: hear him.

Luke 9:36 And when the voice was past, Jesus was found alone. And they kept it close, and told no man in those days any of those things which they had seen.

Luke 9:37 And it came to pass, that on the next day, when they were come down from the hill, much people met him.

Luke 9:38 And, behold, a man of the company cried out, saying, Master, I beseech thee, look upon my son: for he is mine only child.

Luke 9:39 And, lo, a spirit taketh him, and he suddenly crieth out; and it teareth him that he foameth again, and bruising him hardly departeth from him.

Luke 9:40 And I besought thy disciples to cast him out; and they could not.

Luke 9:41 And Jesus answering said, O faithless and perverse generation, how long shall I be with you, and suffer you? Bring thy son hither.

Luke 9:42 And as he was yet a coming, the devil threw him down, and tare him. And Jesus rebuked the unclean spirit, and healed the child, and delivered him again to his father.

Luke 9:43 And they were all amazed at the mighty power of God. But while they wondered every one at all things which Jesus did, he said unto his disciples,

Luke 9:44 Let these sayings sink down into your ears: for the Son of man shall be delivered into the hands of men.

Luke 9:45 But they understood not this saying, and it was hid from them, that they perceived it not: and they feared to ask him of that saying.

Luke 9:46 Then there arose a reasoning among them, which of them should be greatest.

Luke 9:47 And Jesus, perceiving the thought of their heart, took a child, and set him by him,

Luke 9:48 And said unto them, Whosoever shall receive this child in my name receiveth me: and whosoever shall receive me receiveth him that sent me: for he that is least among you all, the same shall be great.

Luke 9:49 And John answered and said, Master, we saw one casting out devils in thy name; and we forbad him, because he followeth not with us.

Luke 9:50 And Jesus said unto him, Forbid him not: for he that is not against us is for us.

Luke 9:51 And it came to pass, when the time was come that he should be received up, he steadfastly set his face to go to Jerusalem,

Luke 9:52 And sent messengers before his face: and they went, and entered into a village of the Samaritans, to make ready for him.

Luke 9:53 And they did not receive him, because his face was as though he would go to Jerusalem.

Luke 9:54 And when his disciples James and John saw this, they said, Lord, wilt thou that we command fire to come down from heaven, and consume them, even as Elias did?

Luke 9:55 But he turned, and rebuked them, and said, Ye know not what manner of spirit ye are of.

Luke 9:56 For the Son of man is not come to destroy men’s lives, but to save them. And they went to another village.

Luke 9:57 And it came to pass, that, as they went in the way, a certain man said unto him, Lord, I will follow thee whithersoever thou goest.

Luke 9:58 And Jesus said unto him, Foxes have holes, and birds of the air have nests; but the Son of man hath not where to lay his head.

Luke 9:59 And he said unto another, Follow me. But he said, Lord, suffer me first to go and bury my father.

Luke 9:60 Jesus said unto him, Let the dead bury their dead: but go thou and preach the kingdom of God.

Luke 9:61 And another also said, Lord, I will follow thee; but let me first go bid them farewell, which are at home at my house.

Luke 9:62 And Jesus said unto him, No man, having put his hand to the plough, and looking back, is fit for the kingdom of God.
