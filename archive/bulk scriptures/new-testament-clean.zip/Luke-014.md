# Luke 14

Luke 14 (summary): Jesus again heals on the Sabbath—He teaches humility and gives the parable of the great supper—Those who follow Him must forsake all else.

Luke 14:1 And it came to pass, as he went into the house of one of the chief Pharisees to eat bread on the sabbath day, that they watched him.

Luke 14:2 And, behold, there was a certain man before him which had the dropsy.

Luke 14:3 And Jesus answering spake unto the lawyers and Pharisees, saying, Is it lawful to heal on the sabbath day?

Luke 14:4 And they held their peace. And he took him, and healed him, and let him go;

Luke 14:5 And answered them, saying, Which of you shall have an ass or an ox fallen into a pit, and will not straightway pull him out on the sabbath day?

Luke 14:6 And they could not answer him again to these things.

Luke 14:7 And he put forth a parable to those which were bidden, when he marked how they chose out the chief rooms; saying unto them,

Luke 14:8 When thou art bidden of any man to a wedding, sit not down in the highest room; lest a more honourable man than thou be bidden of him;

Luke 14:9 And he that bade thee and him come and say to thee, Give this man place; and thou begin with shame to take the lowest room.

Luke 14:10 But when thou art bidden, go and sit down in the lowest room; that when he that bade thee cometh, he may say unto thee, Friend, go up higher: then shalt thou have worship in the presence of them that sit at meat with thee.

Luke 14:11 For whosoever exalteth himself shall be abased; and he that humbleth himself shall be exalted.

Luke 14:12 Then said he also to him that bade him, When thou makest a dinner or a supper, call not thy friends, nor thy brethren, neither thy kinsmen, nor thy rich neighbours; lest they also bid thee again, and a recompence be made thee.

Luke 14:13 But when thou makest a feast, call the poor, the maimed, the lame, the blind:

Luke 14:14 And thou shalt be blessed; for they cannot recompense thee: for thou shalt be recompensed at the resurrection of the just.

Luke 14:15 And when one of them that sat at meat with him heard these things, he said unto him, Blessed is he that shall eat bread in the kingdom of God.

Luke 14:16 Then said he unto him, A certain man made a great supper, and bade many:

Luke 14:17 And sent his servant at supper time to say to them that were bidden, Come; for all things are now ready.

Luke 14:18 And they all with one consent began to make excuse. The first said unto him, I have bought a piece of ground, and I must needs go and see it: I pray thee have me excused.

Luke 14:19 And another said, I have bought five yoke of oxen, and I go to prove them: I pray thee have me excused.

Luke 14:20 And another said, I have married a wife, and therefore I cannot come.

Luke 14:21 So that servant came, and shewed his lord these things. Then the master of the house being angry said to his servant, Go out quickly into the streets and lanes of the city, and bring in hither the poor, and the maimed, and the halt, and the blind.

Luke 14:22 And the servant said, Lord, it is done as thou hast commanded, and yet there is room.

Luke 14:23 And the lord said unto the servant, Go out into the highways and hedges, and compel them to come in, that my house may be filled.

Luke 14:24 For I say unto you, That none of those men which were bidden shall taste of my supper.

Luke 14:25 And there went great multitudes with him: and he turned, and said unto them,

Luke 14:26 If any man come to me, and hate not his father, and mother, and wife, and children, and brethren, and sisters, yea, and his own life also, he cannot be my disciple.

Luke 14:27 And whosoever doth not bear his cross, and come after me, cannot be my disciple.

Luke 14:28 For which of you, intending to build a tower, sitteth not down first, and counteth the cost, whether he have sufficient to finish it?

Luke 14:29 Lest haply, after he hath laid the foundation, and is not able to finish it, all that behold it begin to mock him,

Luke 14:30 Saying, This man began to build, and was not able to finish.

Luke 14:31 Or what king, going to make war against another king, sitteth not down first, and consulteth whether he be able with ten thousand to meet him that cometh against him with twenty thousand?

Luke 14:32 Or else, while the other is yet a great way off, he sendeth an ambassage, and desireth conditions of peace.

Luke 14:33 So likewise, whosoever he be of you that forsaketh not all that he hath, he cannot be my disciple.

Luke 14:34 Salt is good: but if the salt have lost his savour, wherewith shall it be seasoned?

Luke 14:35 It is neither fit for the land, nor yet for the dunghill; but men cast it out. He that hath ears to hear, let him hear.
