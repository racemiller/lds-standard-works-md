# 1 Corinthians 7

1 Corinthians 7 (summary): Paul answers special questions about marriage among those called on missions—Paul praises self-discipline.

1 Corinthians 7:1 Now concerning the things whereof ye wrote unto me: It is good for a man not to touch a woman.

1 Corinthians 7:2 Nevertheless, to avoid fornication, let every man have his own wife, and let every woman have her own husband.

1 Corinthians 7:3 Let the husband render unto the wife due benevolence: and likewise also the wife unto the husband.

1 Corinthians 7:4 The wife hath not power of her own body, but the husband: and likewise also the husband hath not power of his own body, but the wife.

1 Corinthians 7:5 Defraud ye not one the other, except it be with consent for a time, that ye may give yourselves to fasting and prayer; and come together again, that Satan tempt you not for your incontinency.

1 Corinthians 7:6 But I speak this by permission, and not of commandment.

1 Corinthians 7:7 For I would that all men were even as I myself. But every man hath his proper gift of God, one after this manner, and another after that.

1 Corinthians 7:8 I say therefore to the unmarried and widows, It is good for them if they abide even as I.

1 Corinthians 7:9 But if they cannot contain, let them marry: for it is better to marry than to burn.

1 Corinthians 7:10 And unto the married I command, yet not I, but the Lord, Let not the wife depart from her husband:

1 Corinthians 7:11 But and if she depart, let her remain unmarried, or be reconciled to her husband: and let not the husband put away his wife.

1 Corinthians 7:12 But to the rest speak I, not the Lord: If any brother hath a wife that believeth not, and she be pleased to dwell with him, let him not put her away.

1 Corinthians 7:13 And the woman which hath an husband that believeth not, and if he be pleased to dwell with her, let her not leave him.

1 Corinthians 7:14 For the unbelieving husband is sanctified by the wife, and the unbelieving wife is sanctified by the husband: else were your children unclean; but now are they holy.

1 Corinthians 7:15 But if the unbelieving depart, let him depart. A brother or a sister is not under bondage in such cases: but God hath called us to peace.

1 Corinthians 7:16 For what knowest thou, O wife, whether thou shalt save thy husband? or how knowest thou, O man, whether thou shalt save thy wife?

1 Corinthians 7:17 But as God hath distributed to every man, as the Lord hath called every one, so let him walk. And so ordain I in all churches.

1 Corinthians 7:18 Is any man called being circumcised? let him not become uncircumcised. Is any called in uncircumcision? let him not be circumcised.

1 Corinthians 7:19 Circumcision is nothing, and uncircumcision is nothing, but the keeping of the commandments of God.

1 Corinthians 7:20 Let every man abide in the same calling wherein he was called.

1 Corinthians 7:21 Art thou called being a servant? care not for it: but if thou mayest be made free, use it rather.

1 Corinthians 7:22 For he that is called in the Lord, being a servant, is the Lord’s freeman: likewise also he that is called, being free, is Christ’s servant.

1 Corinthians 7:23 Ye are bought with a price; be not ye the servants of men.

1 Corinthians 7:24 Brethren, let every man, wherein he is called, therein abide with God.

1 Corinthians 7:25 Now concerning virgins I have no commandment of the Lord: yet I give my judgment, as one that hath obtained mercy of the Lord to be faithful.

1 Corinthians 7:26 I suppose therefore that this is good for the present distress, I say, that it is good for a man so to be.

1 Corinthians 7:27 Art thou bound unto a wife? seek not to be loosed. Art thou loosed from a wife? seek not a wife.

1 Corinthians 7:28 But and if thou marry, thou hast not sinned; and if a virgin marry, she hath not sinned. Nevertheless such shall have trouble in the flesh: but I spare you.

1 Corinthians 7:29 But this I say, brethren, the time is short: it remaineth, that both they that have wives be as though they had none;

1 Corinthians 7:30 And they that weep, as though they wept not; and they that rejoice, as though they rejoiced not; and they that buy, as though they possessed not;

1 Corinthians 7:31 And they that use this world, as not abusing it: for the fashion of this world passeth away.

1 Corinthians 7:32 But I would have you without carefulness. He that is unmarried careth for the things that belong to the Lord, how he may please the Lord:

1 Corinthians 7:33 But he that is married careth for the things that are of the world, how he may please his wife.

1 Corinthians 7:34 There is difference also between a wife and a virgin. The unmarried woman careth for the things of the Lord, that she may be holy both in body and in spirit: but she that is married careth for the things of the world, how she may please her husband.

1 Corinthians 7:35 And this I speak for your own profit; not that I may cast a snare upon you, but for that which is comely, and that ye may attend upon the Lord without distraction.

1 Corinthians 7:36 But if any man think that he behaveth himself uncomely toward his virgin, if she pass the flower of her age, and need so require, let him do what he will, he sinneth not: let them marry.

1 Corinthians 7:37 Nevertheless he that standeth steadfast in his heart, having no necessity, but hath power over his own will, and hath so decreed in his heart that he will keep his virgin, doeth well.

1 Corinthians 7:38 So then he that giveth her in marriage doeth well; but he that giveth her not in marriage doeth better.

1 Corinthians 7:39 The wife is bound by the law as long as her husband liveth; but if her husband be dead, she is at liberty to be married to whom she will; only in the Lord.

1 Corinthians 7:40 But she is happier if she so abide, after my judgment: and I think also that I have the Spirit of God.
