# Mark 15

Mark 15 (summary): Pilate decrees the death of Jesus—Jesus is mocked and crucified between two thieves—He dies and is buried in the tomb of Joseph of Arimathæa.

Mark 15:1 And straightway in the morning the chief priests held a consultation with the elders and scribes and the whole council, and bound Jesus, and carried him away, and delivered him to Pilate.

Mark 15:2 And Pilate asked him, Art thou the King of the Jews? And he answering said unto him, Thou sayest it.

Mark 15:3 And the chief priests accused him of many things: but he answered nothing.

Mark 15:4 And Pilate asked him again, saying, Answerest thou nothing? behold how many things they witness against thee.

Mark 15:5 But Jesus yet answered nothing; so that Pilate marvelled.

Mark 15:6 Now at that feast he released unto them one prisoner, whomsoever they desired.

Mark 15:7 And there was one named Barabbas, which lay bound with them that had made insurrection with him, who had committed murder in the insurrection.

Mark 15:8 And the multitude crying aloud began to desire him to do as he had ever done unto them.

Mark 15:9 But Pilate answered them, saying, Will ye that I release unto you the King of the Jews?

Mark 15:10 For he knew that the chief priests had delivered him for envy.

Mark 15:11 But the chief priests moved the people, that he should rather release Barabbas unto them.

Mark 15:12 And Pilate answered and said again unto them, What will ye then that I shall do unto him whom ye call the King of the Jews?

Mark 15:13 And they cried out again, Crucify him.

Mark 15:14 Then Pilate said unto them, Why, what evil hath he done? And they cried out the more exceedingly, Crucify him.

Mark 15:15 And so Pilate, willing to content the people, released Barabbas unto them, and delivered Jesus, when he had scourged him, to be crucified.

Mark 15:16 And the soldiers led him away into the hall, called Prætorium; and they call together the whole band.

Mark 15:17 And they clothed him with purple, and plaited a crown of thorns, and put it about his head,

Mark 15:18 And began to salute him, Hail, King of the Jews!

Mark 15:19 And they smote him on the head with a reed, and did spit upon him, and bowing their knees worshipped him.

Mark 15:20 And when they had mocked him, they took off the purple from him, and put his own clothes on him, and led him out to crucify him.

Mark 15:21 And they compel one Simon a Cyrenian, who passed by, coming out of the country, the father of Alexander and Rufus, to bear his cross.

Mark 15:22 And they bring him unto the place Golgotha, which is, being interpreted, The place of a skull.

Mark 15:23 And they gave him to drink wine mingled with myrrh: but he received it not.

Mark 15:24 And when they had crucified him, they parted his garments, casting lots upon them, what every man should take.

Mark 15:25 And it was the third hour, and they crucified him.

Mark 15:26 And the superscription of his accusation was written over, The King of the Jews.

Mark 15:27 And with him they crucify two thieves; the one on his right hand, and the other on his left.

Mark 15:28 And the scripture was fulfilled, which saith, And he was numbered with the transgressors.

Mark 15:29 And they that passed by railed on him, wagging their heads, and saying, Ah, thou that destroyest the temple, and buildest it in three days,

Mark 15:30 Save thyself, and come down from the cross.

Mark 15:31 Likewise also the chief priests mocking said among themselves with the scribes, He saved others; himself he cannot save.

Mark 15:32 Let Christ the King of Israel descend now from the cross, that we may see and believe. And they that were crucified with him reviled him.

Mark 15:33 And when the sixth hour was come, there was darkness over the whole land until the ninth hour.

Mark 15:34 And at the ninth hour Jesus cried with a loud voice, saying, Eloi, Eloi, lama sabachthani? which is, being interpreted, My God, my God, why hast thou forsaken me?

Mark 15:35 And some of them that stood by, when they heard it, said, Behold, he calleth Elias.

Mark 15:36 And one ran and filled a sponge full of vinegar, and put it on a reed, and gave him to drink, saying, Let alone; let us see whether Elias will come to take him down.

Mark 15:37 And Jesus cried with a loud voice, and gave up the ghost.

Mark 15:38 And the veil of the temple was rent in twain from the top to the bottom.

Mark 15:39 And when the centurion, which stood over against him, saw that he so cried out, and gave up the ghost, he said, Truly this man was the Son of God.

Mark 15:40 There were also women looking on afar off: among whom was Mary Magdalene, and Mary the mother of James the less and of Joses, and Salome;

Mark 15:41 (Who also, when he was in Galilee, followed him, and ministered unto him;) and many other women which came up with him unto Jerusalem.

Mark 15:42 And now when the even was come, because it was the preparation, that is, the day before the sabbath,

Mark 15:43 Joseph of Arimathæa, an honourable counsellor, which also waited for the kingdom of God, came, and went in boldly unto Pilate, and craved the body of Jesus.

Mark 15:44 And Pilate marvelled if he were already dead: and calling unto him the centurion, he asked him whether he had been any while dead.

Mark 15:45 And when he knew it of the centurion, he gave the body to Joseph.

Mark 15:46 And he bought fine linen, and took him down, and wrapped him in the linen, and laid him in a sepulchre which was hewn out of a rock, and rolled a stone unto the door of the sepulchre.

Mark 15:47 And Mary Magdalene and Mary the mother of Joses beheld where he was laid.
