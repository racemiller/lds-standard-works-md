# 1 Corinthians 10

1 Corinthians 10 (summary): Christ is the God of Israel and the spiritual Rock that guided them—Ancient Israel rebelled against Christ—Paul contrasts true and false sacraments.

1 Corinthians 10:1 Moreover, brethren, I would not that ye should be ignorant, how that all our fathers were under the cloud, and all passed through the sea;

1 Corinthians 10:2 And were all baptized unto Moses in the cloud and in the sea;

1 Corinthians 10:3 And did all eat the same spiritual meat;

1 Corinthians 10:4 And did all drink the same spiritual drink: for they drank of that spiritual Rock that followed them: and that Rock was Christ.

1 Corinthians 10:5 But with many of them God was not well pleased: for they were overthrown in the wilderness.

1 Corinthians 10:6 Now these things were our examples, to the intent we should not lust after evil things, as they also lusted.

1 Corinthians 10:7 Neither be ye idolaters, as were some of them; as it is written, The people sat down to eat and drink, and rose up to play.

1 Corinthians 10:8 Neither let us commit fornication, as some of them committed, and fell in one day three and twenty thousand.

1 Corinthians 10:9 Neither let us tempt Christ, as some of them also tempted, and were destroyed of serpents.

1 Corinthians 10:10 Neither murmur ye, as some of them also murmured, and were destroyed of the destroyer.

1 Corinthians 10:11 Now all these things happened unto them for ensamples: and they are written for our admonition, upon whom the ends of the world are come.

1 Corinthians 10:12 Wherefore let him that thinketh he standeth take heed lest he fall.

1 Corinthians 10:13 There hath no temptation taken you but such as is common to man: but God is faithful, who will not suffer you to be tempted above that ye are able; but will with the temptation also make a way to escape, that ye may be able to bear it.

1 Corinthians 10:14 Wherefore, my dearly beloved, flee from idolatry.

1 Corinthians 10:15 I speak as to wise men; judge ye what I say.

1 Corinthians 10:16 The cup of blessing which we bless, is it not the communion of the blood of Christ? The bread which we break, is it not the communion of the body of Christ?

1 Corinthians 10:17 For we being many are one bread, and one body: for we are all partakers of that one bread.

1 Corinthians 10:18 Behold Israel after the flesh: are not they which eat of the sacrifices partakers of the altar?

1 Corinthians 10:19 What say I then? that the idol is any thing, or that which is offered in sacrifice to idols is any thing?

1 Corinthians 10:20 But I say, that the things which the Gentiles sacrifice, they sacrifice to devils, and not to God: and I would not that ye should have fellowship with devils.

1 Corinthians 10:21 Ye cannot drink the cup of the Lord, and the cup of devils: ye cannot be partakers of the Lord’s table, and of the table of devils.

1 Corinthians 10:22 Do we provoke the Lord to jealousy? are we stronger than he?

1 Corinthians 10:23 All things are lawful for me, but all things are not expedient: all things are lawful for me, but all things edify not.

1 Corinthians 10:24 Let no man seek his own, but every man another’s wealth.

1 Corinthians 10:25 Whatsoever is sold in the shambles, that eat, asking no question for conscience sake:

1 Corinthians 10:26 For the earth is the Lord’s, and the fulness thereof.

1 Corinthians 10:27 If any of them that believe not bid you to a feast, and ye be disposed to go; whatsoever is set before you, eat, asking no question for conscience sake.

1 Corinthians 10:28 But if any man say unto you, This is offered in sacrifice unto idols, eat not for his sake that shewed it, and for conscience sake: for the earth is the Lord’s, and the fulness thereof:

1 Corinthians 10:29 Conscience, I say, not thine own, but of the other: for why is my liberty judged of another man’s conscience?

1 Corinthians 10:30 For if I by grace be a partaker, why am I evil spoken of for that for which I give thanks?

1 Corinthians 10:31 Whether therefore ye eat, or drink, or whatsoever ye do, do all to the glory of God.

1 Corinthians 10:32 Give none offence, neither to the Jews, nor to the Gentiles, nor to the church of God:

1 Corinthians 10:33 Even as I please all men in all things, not seeking mine own profit, but the profit of many, that they may be saved.
