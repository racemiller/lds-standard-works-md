# Hebrews 3

Hebrews 3 (summary): Christ is the Apostle and High Priest of our profession—Jesus, being the Son, is more than a servant—Now is the time and the day of our salvation.

Hebrews 3:1 Wherefore, holy brethren, partakers of the heavenly calling, consider the Apostle and High Priest of our profession, Christ Jesus;

Hebrews 3:2 Who was faithful to him that appointed him, as also Moses was faithful in all his house.

Hebrews 3:3 For this man was counted worthy of more glory than Moses, inasmuch as he who hath builded the house hath more honour than the house.

Hebrews 3:4 For every house is builded by some man; but he that built all things is God.

Hebrews 3:5 And Moses verily was faithful in all his house, as a servant, for a testimony of those things which were to be spoken after;

Hebrews 3:6 But Christ as a son over his own house; whose house are we, if we hold fast the confidence and the rejoicing of the hope firm unto the end.

Hebrews 3:7 Wherefore (as the Holy Ghost saith, To day if ye will hear his voice,

Hebrews 3:8 Harden not your hearts, as in the provocation, in the day of temptation in the wilderness:

Hebrews 3:9 When your fathers tempted me, proved me, and saw my works forty years.

Hebrews 3:10 Wherefore I was grieved with that generation, and said, They do alway err in their heart; and they have not known my ways.

Hebrews 3:11 So I sware in my wrath, They shall not enter into my rest.)

Hebrews 3:12 Take heed, brethren, lest there be in any of you an evil heart of unbelief, in departing from the living God.

Hebrews 3:13 But exhort one another daily, while it is called To day; lest any of you be hardened through the deceitfulness of sin.

Hebrews 3:14 For we are made partakers of Christ, if we hold the beginning of our confidence steadfast unto the end;

Hebrews 3:15 While it is said, To day if ye will hear his voice, harden not your hearts, as in the provocation.

Hebrews 3:16 For some, when they had heard, did provoke: howbeit not all that came out of Egypt by Moses.

Hebrews 3:17 But with whom was he grieved forty years? was it not with them that had sinned, whose carcases fell in the wilderness?

Hebrews 3:18 And to whom sware he that they should not enter into his rest, but to them that believed not?

Hebrews 3:19 So we see that they could not enter in because of unbelief.
