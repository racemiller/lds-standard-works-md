# 1 Thessalonians 1

1 Thessalonians 1 (summary): The gospel comes both in word and in power.

1 Thessalonians 1:1 Paul, and Silvanus, and Timotheus, unto the church of the Thessalonians which is in God the Father and in the Lord Jesus Christ: Grace be unto you, and peace, from God our Father, and the Lord Jesus Christ.

1 Thessalonians 1:2 We give thanks to God always for you all, making mention of you in our prayers;

1 Thessalonians 1:3 Remembering without ceasing your work of faith, and labour of love, and patience of hope in our Lord Jesus Christ, in the sight of God and our Father;

1 Thessalonians 1:4 Knowing, brethren beloved, your election of God.

1 Thessalonians 1:5 For our gospel came not unto you in word only, but also in power, and in the Holy Ghost, and in much assurance; as ye know what manner of men we were among you for your sake.

1 Thessalonians 1:6 And ye became followers of us, and of the Lord, having received the word in much affliction, with joy of the Holy Ghost:

1 Thessalonians 1:7 So that ye were ensamples to all that believe in Macedonia and Achaia.

1 Thessalonians 1:8 For from you sounded out the word of the Lord not only in Macedonia and Achaia, but also in every place your faith to God-ward is spread abroad; so that we need not to speak any thing.

1 Thessalonians 1:9 For they themselves shew of us what manner of entering in we had unto you, and how ye turned to God from idols to serve the living and true God;

1 Thessalonians 1:10 And to wait for his Son from heaven, whom he raised from the dead, even Jesus, which delivered us from the wrath to come.
