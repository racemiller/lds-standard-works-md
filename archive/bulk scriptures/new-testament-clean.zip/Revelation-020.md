# Revelation 20

Revelation 20 (summary): Satan is bound during the Millennium—The Saints will then live and reign with Christ—The dead stand before God and are judged out of the books according to their works.

Revelation 20:1 And I saw an angel come down from heaven, having the key of the bottomless pit and a great chain in his hand.

Revelation 20:2 And he laid hold on the dragon, that old serpent, which is the Devil, and Satan, and bound him a thousand years,

Revelation 20:3 And cast him into the bottomless pit, and shut him up, and set a seal upon him, that he should deceive the nations no more, till the thousand years should be fulfilled: and after that he must be loosed a little season.

Revelation 20:4 And I saw thrones, and they sat upon them, and judgment was given unto them: and I saw the souls of them that were beheaded for the witness of Jesus, and for the word of God, and which had not worshipped the beast, neither his image, neither had received his mark upon their foreheads, or in their hands; and they lived and reigned with Christ a thousand years.

Revelation 20:5 But the rest of the dead lived not again until the thousand years were finished. This is the first resurrection.

Revelation 20:6 Blessed and holy is he that hath part in the first resurrection: on such the second death hath no power, but they shall be priests of God and of Christ, and shall reign with him a thousand years.

Revelation 20:7 And when the thousand years are expired, Satan shall be loosed out of his prison,

Revelation 20:8 And shall go out to deceive the nations which are in the four quarters of the earth, Gog and Magog, to gather them together to battle: the number of whom is as the sand of the sea.

Revelation 20:9 And they went up on the breadth of the earth, and compassed the camp of the saints about, and the beloved city: and fire came down from God out of heaven, and devoured them.

Revelation 20:10 And the devil that deceived them was cast into the lake of fire and brimstone, where the beast and the false prophet are, and shall be tormented day and night for ever and ever.

Revelation 20:11 And I saw a great white throne, and him that sat on it, from whose face the earth and the heaven fled away; and there was found no place for them.

Revelation 20:12 And I saw the dead, small and great, stand before God; and the books were opened: and another book was opened, which is the book of life: and the dead were judged out of those things which were written in the books, according to their works.

Revelation 20:13 And the sea gave up the dead which were in it; and death and hell delivered up the dead which were in them: and they were judged every man according to their works.

Revelation 20:14 And death and hell were cast into the lake of fire. This is the second death.

Revelation 20:15 And whosoever was not found written in the book of life was cast into the lake of fire.
