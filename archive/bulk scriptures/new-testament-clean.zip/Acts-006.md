# Acts 6

Acts 6 (summary): The Apostles choose seven to assist them—Stephen is tried before the council.

Acts 6:1 And in those days, when the number of the disciples was multiplied, there arose a murmuring of the Grecians against the Hebrews, because their widows were neglected in the daily ministration.

Acts 6:2 Then the twelve called the multitude of the disciples unto them, and said, It is not reason that we should leave the word of God, and serve tables.

Acts 6:3 Wherefore, brethren, look ye out among you seven men of honest report, full of the Holy Ghost and wisdom, whom we may appoint over this business.

Acts 6:4 But we will give ourselves continually to prayer, and to the ministry of the word.

Acts 6:5 And the saying pleased the whole multitude: and they chose Stephen, a man full of faith and of the Holy Ghost, and Philip, and Prochorus, and Nicanor, and Timon, and Parmenas, and Nicolas a proselyte of Antioch:

Acts 6:6 Whom they set before the apostles: and when they had prayed, they laid their hands on them.

Acts 6:7 And the word of God increased; and the number of the disciples multiplied in Jerusalem greatly; and a great company of the priests were obedient to the faith.

Acts 6:8 And Stephen, full of faith and power, did great wonders and miracles among the people.

Acts 6:9 Then there arose certain of the synagogue, which is called the synagogue of the Libertines, and Cyrenians, and Alexandrians, and of them of Cilicia and of Asia, disputing with Stephen.

Acts 6:10 And they were not able to resist the wisdom and the spirit by which he spake.

Acts 6:11 Then they suborned men, which said, We have heard him speak blasphemous words against Moses, and against God.

Acts 6:12 And they stirred up the people, and the elders, and the scribes, and came upon him, and caught him, and brought him to the council,

Acts 6:13 And set up false witnesses, which said, This man ceaseth not to speak blasphemous words against this holy place, and the law:

Acts 6:14 For we have heard him say, that this Jesus of Nazareth shall destroy this place, and shall change the customs which Moses delivered us.

Acts 6:15 And all that sat in the council, looking steadfastly on him, saw his face as it had been the face of an angel.
