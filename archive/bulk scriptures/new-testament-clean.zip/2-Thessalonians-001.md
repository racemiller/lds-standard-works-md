# 2 Thessalonians 1

2 Thessalonians 1 (summary): At His Second Coming, the Lord Jesus will take vengeance upon the ungodly.

2 Thessalonians 1:1 Paul, and Silvanus, and Timotheus, unto the church of the Thessalonians in God our Father and the Lord Jesus Christ:

2 Thessalonians 1:2 Grace unto you, and peace, from God our Father and the Lord Jesus Christ.

2 Thessalonians 1:3 We are bound to thank God always for you, brethren, as it is meet, because that your faith groweth exceedingly, and the charity of every one of you all toward each other aboundeth;

2 Thessalonians 1:4 So that we ourselves glory in you in the churches of God for your patience and faith in all your persecutions and tribulations that ye endure:

2 Thessalonians 1:5 Which is a manifest token of the righteous judgment of God, that ye may be counted worthy of the kingdom of God, for which ye also suffer:

2 Thessalonians 1:6 Seeing it is a righteous thing with God to recompense tribulation to them that trouble you;

2 Thessalonians 1:7 And to you who are troubled rest with us, when the Lord Jesus shall be revealed from heaven with his mighty angels,

2 Thessalonians 1:8 In flaming fire taking vengeance on them that know not God, and that obey not the gospel of our Lord Jesus Christ:

2 Thessalonians 1:9 Who shall be punished with everlasting destruction from the presence of the Lord, and from the glory of his power;

2 Thessalonians 1:10 When he shall come to be glorified in his saints, and to be admired in all them that believe (because our testimony among you was believed) in that day.

2 Thessalonians 1:11 Wherefore also we pray always for you, that our God would count you worthy of this calling, and fulfil all the good pleasure of his goodness, and the work of faith with power:

2 Thessalonians 1:12 That the name of our Lord Jesus Christ may be glorified in you, and ye in him, according to the grace of our God and the Lord Jesus Christ.
