# Romans 7

Romans 7 (summary): The law of Moses is fulfilled in Christ—Paul delights in the law of God after the inward man.

Romans 7:1 Know ye not, brethren, (for I speak to them that know the law,) how that the law hath dominion over a man as long as he liveth?

Romans 7:2 For the woman which hath an husband is bound by the law to her husband so long as he liveth; but if the husband be dead, she is loosed from the law of her husband.

Romans 7:3 So then if, while her husband liveth, she be married to another man, she shall be called an adulteress: but if her husband be dead, she is free from that law; so that she is no adulteress, though she be married to another man.

Romans 7:4 Wherefore, my brethren, ye also are become dead to the law by the body of Christ; that ye should be married to another, even to him who is raised from the dead, that we should bring forth fruit unto God.

Romans 7:5 For when we were in the flesh, the motions of sins, which were by the law, did work in our members to bring forth fruit unto death.

Romans 7:6 But now we are delivered from the law, that being dead wherein we were held; that we should serve in newness of spirit, and not in the oldness of the letter.

Romans 7:7 What shall we say then? Is the law sin? God forbid. Nay, I had not known sin, but by the law: for I had not known lust, except the law had said, Thou shalt not covet.

Romans 7:8 But sin, taking occasion by the commandment, wrought in me all manner of concupiscence. For without the law sin was dead.

Romans 7:9 For I was alive without the law once: but when the commandment came, sin revived, and I died.

Romans 7:10 And the commandment, which was ordained to life, I found to be unto death.

Romans 7:11 For sin, taking occasion by the commandment, deceived me, and by it slew me.

Romans 7:12 Wherefore the law is holy, and the commandment holy, and just, and good.

Romans 7:13 Was then that which is good made death unto me? God forbid. But sin, that it might appear sin, working death in me by that which is good; that sin by the commandment might become exceeding sinful.

Romans 7:14 For we know that the law is spiritual: but I am carnal, sold under sin.

Romans 7:15 For that which I do I allow not: for what I would, that do I not; but what I hate, that do I.

Romans 7:16 If then I do that which I would not, I consent unto the law that it is good.

Romans 7:17 Now then it is no more I that do it, but sin that dwelleth in me.

Romans 7:18 For I know that in me (that is, in my flesh,) dwelleth no good thing: for to will is present with me; but how to perform that which is good I find not.

Romans 7:19 For the good that I would I do not: but the evil which I would not, that I do.

Romans 7:20 Now if I do that I would not, it is no more I that do it, but sin that dwelleth in me.

Romans 7:21 I find then a law, that, when I would do good, evil is present with me.

Romans 7:22 For I delight in the law of God after the inward man:

Romans 7:23 But I see another law in my members, warring against the law of my mind, and bringing me into captivity to the law of sin which is in my members.

Romans 7:24 O wretched man that I am! who shall deliver me from the body of this death?

Romans 7:25 I thank God through Jesus Christ our Lord. So then with the mind I myself serve the law of God; but with the flesh the law of sin.
