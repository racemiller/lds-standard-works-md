# 2 Corinthians 1

2 Corinthians 1 (summary): God comforts and cares for His Saints—The Saints are sealed and given assurance by the Spirit in their hearts.

2 Corinthians 1:1 Paul, an apostle of Jesus Christ by the will of God, and Timothy our brother, unto the church of God which is at Corinth, with all the saints which are in all Achaia:

2 Corinthians 1:2 Grace be to you and peace from God our Father, and from the Lord Jesus Christ.

2 Corinthians 1:3 Blessed be God, even the Father of our Lord Jesus Christ, the Father of mercies, and the God of all comfort;

2 Corinthians 1:4 Who comforteth us in all our tribulation, that we may be able to comfort them which are in any trouble, by the comfort wherewith we ourselves are comforted of God.

2 Corinthians 1:5 For as the sufferings of Christ abound in us, so our consolation also aboundeth by Christ.

2 Corinthians 1:6 And whether we be afflicted, it is for your consolation and salvation, which is effectual in the enduring of the same sufferings which we also suffer: or whether we be comforted, it is for your consolation and salvation.

2 Corinthians 1:7 And our hope of you is steadfast, knowing, that as ye are partakers of the sufferings, so shall ye be also of the consolation.

2 Corinthians 1:8 For we would not, brethren, have you ignorant of our trouble which came to us in Asia, that we were pressed out of measure, above strength, insomuch that we despaired even of life:

2 Corinthians 1:9 But we had the sentence of death in ourselves, that we should not trust in ourselves, but in God which raiseth the dead:

2 Corinthians 1:10 Who delivered us from so great a death, and doth deliver: in whom we trust that he will yet deliver us;

2 Corinthians 1:11 Ye also helping together by prayer for us, that for the gift bestowed upon us by the means of many persons thanks may be given by many on our behalf.

2 Corinthians 1:12 For our rejoicing is this, the testimony of our conscience, that in simplicity and godly sincerity, not with fleshly wisdom, but by the grace of God, we have had our conversation in the world, and more abundantly to you-ward.

2 Corinthians 1:13 For we write none other things unto you, than what ye read or acknowledge; and I trust ye shall acknowledge even to the end;

2 Corinthians 1:14 As also ye have acknowledged us in part, that we are your rejoicing, even as ye also are ours in the day of the Lord Jesus.

2 Corinthians 1:15 And in this confidence I was minded to come unto you before, that ye might have a second benefit;

2 Corinthians 1:16 And to pass by you into Macedonia, and to come again out of Macedonia unto you, and of you to be brought on my way toward Judæa.

2 Corinthians 1:17 When I therefore was thus minded, did I use lightness? or the things that I purpose, do I purpose according to the flesh, that with me there should be yea yea, and nay nay?

2 Corinthians 1:18 But as God is true, our word toward you was not yea and nay.

2 Corinthians 1:19 For the Son of God, Jesus Christ, who was preached among you by us, even by me and Silvanus and Timotheus, was not yea and nay, but in him was yea.

2 Corinthians 1:20 For all the promises of God in him are yea, and in him Amen, unto the glory of God by us.

2 Corinthians 1:21 Now he which stablisheth us with you in Christ, and hath anointed us, is God;

2 Corinthians 1:22 Who hath also sealed us, and given the earnest of the Spirit in our hearts.

2 Corinthians 1:23 Moreover I call God for a record upon my soul, that to spare you I came not as yet unto Corinth.

2 Corinthians 1:24 Not for that we have dominion over your faith, but are helpers of your joy: for by faith ye stand.
