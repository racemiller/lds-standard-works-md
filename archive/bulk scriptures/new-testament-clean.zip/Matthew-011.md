# Matthew 11

Matthew 11 (summary): Jesus acclaims John as more than a prophet—The cities of Chorazin, Bethsaida, and Capernaum are rebuked for unbelief—The Son reveals the Father—The yoke of Christ is easy, and His burden is light.

Matthew 11:1 And it came to pass, when Jesus had made an end of commanding his twelve disciples, he departed thence to teach and to preach in their cities.

Matthew 11:2 Now when John had heard in the prison the works of Christ, he sent two of his disciples,

Matthew 11:3 And said unto him, Art thou he that should come, or do we look for another?

Matthew 11:4 Jesus answered and said unto them, Go and shew John again those things which ye do hear and see:

Matthew 11:5 The blind receive their sight, and the lame walk, the lepers are cleansed, and the deaf hear, the dead are raised up, and the poor have the gospel preached to them.

Matthew 11:6 And blessed is he, whosoever shall not be offended in me.

Matthew 11:7 And as they departed, Jesus began to say unto the multitudes concerning John, What went ye out into the wilderness to see? A reed shaken with the wind?

Matthew 11:8 But what went ye out for to see? A man clothed in soft raiment? behold, they that wear soft clothing are in kings’ houses.

Matthew 11:9 But what went ye out for to see? A prophet? yea, I say unto you, and more than a prophet.

Matthew 11:10 For this is he, of whom it is written, Behold, I send my messenger before thy face, which shall prepare thy way before thee.

Matthew 11:11 Verily I say unto you, Among them that are born of women there hath not risen a greater than John the Baptist: notwithstanding he that is least in the kingdom of heaven is greater than he.

Matthew 11:12 And from the days of John the Baptist until now the kingdom of heaven suffereth violence, and the violent take it by force.

Matthew 11:13 For all the prophets and the law prophesied until John.

Matthew 11:14 And if ye will receive it, this is Elias, which was for to come.

Matthew 11:15 He that hath ears to hear, let him hear.

Matthew 11:16 But whereunto shall I liken this generation? It is like unto children sitting in the markets, and calling unto their fellows,

Matthew 11:17 And saying, We have piped unto you, and ye have not danced; we have mourned unto you, and ye have not lamented.

Matthew 11:18 For John came neither eating nor drinking, and they say, He hath a devil.

Matthew 11:19 The Son of man came eating and drinking, and they say, Behold a man gluttonous, and a winebibber, a friend of publicans and sinners. But wisdom is justified of her children.

Matthew 11:20 Then began he to upbraid the cities wherein most of his mighty works were done, because they repented not:

Matthew 11:21 Woe unto thee, Chorazin! woe unto thee, Bethsaida! for if the mighty works, which were done in you, had been done in Tyre and Sidon, they would have repented long ago in sackcloth and ashes.

Matthew 11:22 But I say unto you, It shall be more tolerable for Tyre and Sidon at the day of judgment, than for you.

Matthew 11:23 And thou, Capernaum, which art exalted unto heaven, shalt be brought down to hell: for if the mighty works, which have been done in thee, had been done in Sodom, it would have remained until this day.

Matthew 11:24 But I say unto you, That it shall be more tolerable for the land of Sodom in the day of judgment, than for thee.

Matthew 11:25 At that time Jesus answered and said, I thank thee, O Father, Lord of heaven and earth, because thou hast hid these things from the wise and prudent, and hast revealed them unto babes.

Matthew 11:26 Even so, Father: for so it seemed good in thy sight.

Matthew 11:27 All things are delivered unto me of my Father: and no man knoweth the Son, but the Father; neither knoweth any man the Father, save the Son, and he to whomsoever the Son will reveal him.

Matthew 11:28 Come unto me, all ye that labour and are heavy laden, and I will give you rest.

Matthew 11:29 Take my yoke upon you, and learn of me; for I am meek and lowly in heart: and ye shall find rest unto your souls.

Matthew 11:30 For my yoke is easy, and my burden is light.
