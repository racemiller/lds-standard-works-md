# Revelation 8

Revelation 8 (summary): John sees fire and desolation poured out during the seventh seal and preceding the Second Coming.

Revelation 8:1 And when he had opened the seventh seal, there was silence in heaven about the space of half an hour.

Revelation 8:2 And I saw the seven angels which stood before God; and to them were given seven trumpets.

Revelation 8:3 And another angel came and stood at the altar, having a golden censer; and there was given unto him much incense, that he should offer it with the prayers of all saints upon the golden altar which was before the throne.

Revelation 8:4 And the smoke of the incense, which came with the prayers of the saints, ascended up before God out of the angel’s hand.

Revelation 8:5 And the angel took the censer, and filled it with fire of the altar, and cast it into the earth: and there were voices, and thunderings, and lightnings, and an earthquake.

Revelation 8:6 And the seven angels which had the seven trumpets prepared themselves to sound.

Revelation 8:7 The first angel sounded, and there followed hail and fire mingled with blood, and they were cast upon the earth: and the third part of trees was burnt up, and all green grass was burnt up.

Revelation 8:8 And the second angel sounded, and as it were a great mountain burning with fire was cast into the sea: and the third part of the sea became blood;

Revelation 8:9 And the third part of the creatures which were in the sea, and had life, died; and the third part of the ships were destroyed.

Revelation 8:10 And the third angel sounded, and there fell a great star from heaven, burning as it were a lamp, and it fell upon the third part of the rivers, and upon the fountains of waters;

Revelation 8:11 And the name of the star is called Wormwood: and the third part of the waters became wormwood; and many men died of the waters, because they were made bitter.

Revelation 8:12 And the fourth angel sounded, and the third part of the sun was smitten, and the third part of the moon, and the third part of the stars; so as the third part of them was darkened, and the day shone not for a third part of it, and the night likewise.

Revelation 8:13 And I beheld, and heard an angel flying through the midst of heaven, saying with a loud voice, Woe, woe, woe, to the inhabiters of the earth by reason of the other voices of the trumpet of the three angels, which are yet to sound!
