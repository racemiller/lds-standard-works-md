# Acts 10

Acts 10 (summary): An angel ministers to Cornelius—Peter, in a vision, is commanded to take the gospel to the Gentiles—The gospel is taught by witnesses—The Holy Ghost falls upon the Gentiles.

Acts 10:1 There was a certain man in Cæsarea called Cornelius, a centurion of the band called the Italian band,

Acts 10:2 A devout man, and one that feared God with all his house, which gave much alms to the people, and prayed to God alway.

Acts 10:3 He saw in a vision evidently about the ninth hour of the day an angel of God coming in to him, and saying unto him, Cornelius.

Acts 10:4 And when he looked on him, he was afraid, and said, What is it, Lord? And he said unto him, Thy prayers and thine alms are come up for a memorial before God.

Acts 10:5 And now send men to Joppa, and call for one Simon, whose surname is Peter:

Acts 10:6 He lodgeth with one Simon a tanner, whose house is by the sea side: he shall tell thee what thou oughtest to do.

Acts 10:7 And when the angel which spake unto Cornelius was departed, he called two of his household servants, and a devout soldier of them that waited on him continually;

Acts 10:8 And when he had declared all these things unto them, he sent them to Joppa.

Acts 10:9 On the morrow, as they went on their journey, and drew nigh unto the city, Peter went up upon the housetop to pray about the sixth hour:

Acts 10:10 And he became very hungry, and would have eaten: but while they made ready, he fell into a trance,

Acts 10:11 And saw heaven opened, and a certain vessel descending unto him, as it had been a great sheet knit at the four corners, and let down to the earth:

Acts 10:12 Wherein were all manner of fourfooted beasts of the earth, and wild beasts, and creeping things, and fowls of the air.

Acts 10:13 And there came a voice to him, Rise, Peter; kill, and eat.

Acts 10:14 But Peter said, Not so, Lord; for I have never eaten any thing that is common or unclean.

Acts 10:15 And the voice spake unto him again the second time, What God hath cleansed, that call not thou common.

Acts 10:16 This was done thrice: and the vessel was received up again into heaven.

Acts 10:17 Now while Peter doubted in himself what this vision which he had seen should mean, behold, the men which were sent from Cornelius had made inquiry for Simon’s house, and stood before the gate,

Acts 10:18 And called, and asked whether Simon, which was surnamed Peter, were lodged there.

Acts 10:19 While Peter thought on the vision, the Spirit said unto him, Behold, three men seek thee.

Acts 10:20 Arise therefore, and get thee down, and go with them, doubting nothing: for I have sent them.

Acts 10:21 Then Peter went down to the men which were sent unto him from Cornelius; and said, Behold, I am he whom ye seek: what is the cause wherefore ye are come?

Acts 10:22 And they said, Cornelius the centurion, a just man, and one that feareth God, and of good report among all the nation of the Jews, was warned from God by an holy angel to send for thee into his house, and to hear words of thee.

Acts 10:23 Then called he them in, and lodged them. And on the morrow Peter went away with them, and certain brethren from Joppa accompanied him.

Acts 10:24 And the morrow after they entered into Cæsarea. And Cornelius waited for them, and had called together his kinsmen and near friends.

Acts 10:25 And as Peter was coming in, Cornelius met him, and fell down at his feet, and worshipped him.

Acts 10:26 But Peter took him up, saying, Stand up; I myself also am a man.

Acts 10:27 And as he talked with him, he went in, and found many that were come together.

Acts 10:28 And he said unto them, Ye know how that it is an unlawful thing for a man that is a Jew to keep company, or come unto one of another nation; but God hath shewed me that I should not call any man common or unclean.

Acts 10:29 Therefore came I unto you without gainsaying, as soon as I was sent for: I ask therefore for what intent ye have sent for me?

Acts 10:30 And Cornelius said, Four days ago I was fasting until this hour; and at the ninth hour I prayed in my house, and, behold, a man stood before me in bright clothing,

Acts 10:31 And said, Cornelius, thy prayer is heard, and thine alms are had in remembrance in the sight of God.

Acts 10:32 Send therefore to Joppa, and call hither Simon, whose surname is Peter; he is lodged in the house of one Simon a tanner by the sea side: who, when he cometh, shall speak unto thee.

Acts 10:33 Immediately therefore I sent to thee; and thou hast well done that thou art come. Now therefore are we all here present before God, to hear all things that are commanded thee of God.

Acts 10:34 Then Peter opened his mouth, and said, Of a truth I perceive that God is no respecter of persons:

Acts 10:35 But in every nation he that feareth him, and worketh righteousness, is accepted with him.

Acts 10:36 The word which God sent unto the children of Israel, preaching peace by Jesus Christ: (he is Lord of all:)

Acts 10:37 That word, I say, ye know, which was published throughout all Judæa, and began from Galilee, after the baptism which John preached;

Acts 10:38 How God anointed Jesus of Nazareth with the Holy Ghost and with power: who went about doing good, and healing all that were oppressed of the devil; for God was with him.

Acts 10:39 And we are witnesses of all things which he did both in the land of the Jews, and in Jerusalem; whom they slew and hanged on a tree:

Acts 10:40 Him God raised up the third day, and shewed him openly;

Acts 10:41 Not to all the people, but unto witnesses chosen before of God, even to us, who did eat and drink with him after he rose from the dead.

Acts 10:42 And he commanded us to preach unto the people, and to testify that it is he which was ordained of God to be the Judge of quick and dead.

Acts 10:43 To him give all the prophets witness, that through his name whosoever believeth in him shall receive remission of sins.

Acts 10:44 While Peter yet spake these words, the Holy Ghost fell on all them which heard the word.

Acts 10:45 And they of the circumcision which believed were astonished, as many as came with Peter, because that on the Gentiles also was poured out the gift of the Holy Ghost.

Acts 10:46 For they heard them speak with tongues, and magnify God. Then answered Peter,

Acts 10:47 Can any man forbid water, that these should not be baptized, which have received the Holy Ghost as well as we?

Acts 10:48 And he commanded them to be baptized in the name of the Lord. Then prayed they him to tarry certain days.
