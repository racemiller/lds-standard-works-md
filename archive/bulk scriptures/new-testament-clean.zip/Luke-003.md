# Luke 3

Luke 3 (summary): John the Baptist preaches and baptizes—Jesus is baptized, and God acclaims Him as His Son—Jesus’ genealogy back to Adam is given.

Luke 3:1 Now in the fifteenth year of the reign of Tiberius Cæsar, Pontius Pilate being governor of Judæa, and Herod being tetrarch of Galilee, and his brother Philip tetrarch of Ituræa and of the region of Trachonitis, and Lysanias the tetrarch of Abilene,

Luke 3:2 Annas and Caiaphas being the high priests, the word of God came unto John the son of Zacharias in the wilderness.

Luke 3:3 And he came into all the country about Jordan, preaching the baptism of repentance for the remission of sins;

Luke 3:4 As it is written in the book of the words of Esaias the prophet, saying, The voice of one crying in the wilderness, Prepare ye the way of the Lord, make his paths straight.

Luke 3:5 Every valley shall be filled, and every mountain and hill shall be brought low; and the crooked shall be made straight, and the rough ways shall be made smooth;

Luke 3:6 And all flesh shall see the salvation of God.

Luke 3:7 Then said he to the multitude that came forth to be baptized of him, O generation of vipers, who hath warned you to flee from the wrath to come?

Luke 3:8 Bring forth therefore fruits worthy of repentance, and begin not to say within yourselves, We have Abraham to our father: for I say unto you, That God is able of these stones to raise up children unto Abraham.

Luke 3:9 And now also the axe is laid unto the root of the trees: every tree therefore which bringeth not forth good fruit is hewn down, and cast into the fire.

Luke 3:10 And the people asked him, saying, What shall we do then?

Luke 3:11 He answereth and saith unto them, He that hath two coats, let him impart to him that hath none; and he that hath meat, let him do likewise.

Luke 3:12 Then came also publicans to be baptized, and said unto him, Master, what shall we do?

Luke 3:13 And he said unto them, Exact no more than that which is appointed you.

Luke 3:14 And the soldiers likewise demanded of him, saying, And what shall we do? And he said unto them, Do violence to no man, neither accuse any falsely; and be content with your wages.

Luke 3:15 And as the people were in expectation, and all men mused in their hearts of John, whether he were the Christ, or not;

Luke 3:16 John answered, saying unto them all, I indeed baptize you with water; but one mightier than I cometh, the latchet of whose shoes I am not worthy to unloose: he shall baptize you with the Holy Ghost and with fire:

Luke 3:17 Whose fan is in his hand, and he will throughly purge his floor, and will gather the wheat into his garner; but the chaff he will burn with fire unquenchable.

Luke 3:18 And many other things in his exhortation preached he unto the people.

Luke 3:19 But Herod the tetrarch, being reproved by him for Herodias his brother Philip’s wife, and for all the evils which Herod had done,

Luke 3:20 Added yet this above all, that he shut up John in prison.

Luke 3:21 Now when all the people were baptized, it came to pass, that Jesus also being baptized, and praying, the heaven was opened,

Luke 3:22 And the Holy Ghost descended in a bodily shape like a dove upon him, and a voice came from heaven, which said, Thou art my beloved Son; in thee I am well pleased.

Luke 3:23 And Jesus himself began to be about thirty years of age, being (as was supposed) the son of Joseph, which was the son of Heli,

Luke 3:24 Which was the son of Matthat, which was the son of Levi, which was the son of Melchi, which was the son of Janna, which was the son of Joseph,

Luke 3:25 Which was the son of Mattathias, which was the son of Amos, which was the son of Naum, which was the son of Esli, which was the son of Nagge,

Luke 3:26 Which was the son of Maath, which was the son of Mattathias, which was the son of Semei, which was the son of Joseph, which was the son of Juda,

Luke 3:27 Which was the son of Joanna, which was the son of Rhesa, which was the son of Zorobabel, which was the son of Salathiel, which was the son of Neri,

Luke 3:28 Which was the son of Melchi, which was the son of Addi, which was the son of Cosam, which was the son of Elmodam, which was the son of Er,

Luke 3:29 Which was the son of Jose, which was the son of Eliezer, which was the son of Jorim, which was the son of Matthat, which was the son of Levi,

Luke 3:30 Which was the son of Simeon, which was the son of Juda, which was the son of Joseph, which was the son of Jonan, which was the son of Eliakim,

Luke 3:31 Which was the son of Melea, which was the son of Menan, which was the son of Mattatha, which was the son of Nathan, which was the son of David,

Luke 3:32 Which was the son of Jesse, which was the son of Obed, which was the son of Booz, which was the son of Salmon, which was the son of Naasson,

Luke 3:33 Which was the son of Aminadab, which was the son of Aram, which was the son of Esrom, which was the son of Phares, which was the son of Juda,

Luke 3:34 Which was the son of Jacob, which was the son of Isaac, which was the son of Abraham, which was the son of Thara, which was the son of Nachor,

Luke 3:35 Which was the son of Saruch, which was the son of Ragau, which was the son of Phalec, which was the son of Heber, which was the son of Sala,

Luke 3:36 Which was the son of Cainan, which was the son of Arphaxad, which was the son of Sem, which was the son of Noe, which was the son of Lamech,

Luke 3:37 Which was the son of Mathusala, which was the son of Enoch, which was the son of Jared, which was the son of Maleleel, which was the son of Cainan,

Luke 3:38 Which was the son of Enos, which was the son of Seth, which was the son of Adam, which was the son of God.
