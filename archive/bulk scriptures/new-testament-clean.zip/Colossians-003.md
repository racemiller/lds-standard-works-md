# Colossians 3

Colossians 3 (summary): Some lives are hidden with God in Christ—The Saints are told to be holy and to serve the Lord Jesus Christ.

Colossians 3:1 If ye then be risen with Christ, seek those things which are above, where Christ sitteth on the right hand of God.

Colossians 3:2 Set your affection on things above, not on things on the earth.

Colossians 3:3 For ye are dead, and your life is hid with Christ in God.

Colossians 3:4 When Christ, who is our life, shall appear, then shall ye also appear with him in glory.

Colossians 3:5 Mortify therefore your members which are upon the earth; fornication, uncleanness, inordinate affection, evil concupiscence, and covetousness, which is idolatry:

Colossians 3:6 For which things’ sake the wrath of God cometh on the children of disobedience:

Colossians 3:7 In the which ye also walked some time, when ye lived in them.

Colossians 3:8 But now ye also put off all these; anger, wrath, malice, blasphemy, filthy communication out of your mouth.

Colossians 3:9 Lie not one to another, seeing that ye have put off the old man with his deeds;

Colossians 3:10 And have put on the new man, which is renewed in knowledge after the image of him that created him:

Colossians 3:11 Where there is neither Greek nor Jew, circumcision nor uncircumcision, Barbarian, Scythian, bond nor free: but Christ is all, and in all.

Colossians 3:12 Put on therefore, as the elect of God, holy and beloved, bowels of mercies, kindness, humbleness of mind, meekness, longsuffering;

Colossians 3:13 Forbearing one another, and forgiving one another, if any man have a quarrel against any: even as Christ forgave you, so also do ye.

Colossians 3:14 And above all these things put on charity, which is the bond of perfectness.

Colossians 3:15 And let the peace of God rule in your hearts, to the which also ye are called in one body; and be ye thankful.

Colossians 3:16 Let the word of Christ dwell in you richly in all wisdom; teaching and admonishing one another in psalms and hymns and spiritual songs, singing with grace in your hearts to the Lord.

Colossians 3:17 And whatsoever ye do in word or deed, do all in the name of the Lord Jesus, giving thanks to God and the Father by him.

Colossians 3:18 Wives, submit yourselves unto your own husbands, as it is fit in the Lord.

Colossians 3:19 Husbands, love your wives, and be not bitter against them.

Colossians 3:20 Children, obey your parents in all things: for this is well pleasing unto the Lord.

Colossians 3:21 Fathers, provoke not your children to anger, lest they be discouraged.

Colossians 3:22 Servants, obey in all things your masters according to the flesh; not with eyeservice, as menpleasers; but in singleness of heart, fearing God:

Colossians 3:23 And whatsoever ye do, do it heartily, as to the Lord, and not unto men;

Colossians 3:24 Knowing that of the Lord ye shall receive the reward of the inheritance: for ye serve the Lord Christ.

Colossians 3:25 But he that doeth wrong shall receive for the wrong which he hath done: and there is no respect of persons.
