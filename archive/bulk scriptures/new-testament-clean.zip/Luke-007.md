# Luke 7

Luke 7 (summary): Jesus heals the centurion’s servant—Jesus raises from death the son of the widow of Nain—He praises John the Baptist as more than a prophet—A woman anoints Jesus’ feet, and He forgives her sins.

Luke 7:1 Now when he had ended all his sayings in the audience of the people, he entered into Capernaum.

Luke 7:2 And a certain centurion’s servant, who was dear unto him, was sick, and ready to die.

Luke 7:3 And when he heard of Jesus, he sent unto him the elders of the Jews, beseeching him that he would come and heal his servant.

Luke 7:4 And when they came to Jesus, they besought him instantly, saying, That he was worthy for whom he should do this:

Luke 7:5 For he loveth our nation, and he hath built us a synagogue.

Luke 7:6 Then Jesus went with them. And when he was now not far from the house, the centurion sent friends to him, saying unto him, Lord, trouble not thyself: for I am not worthy that thou shouldest enter under my roof:

Luke 7:7 Wherefore neither thought I myself worthy to come unto thee: but say in a word, and my servant shall be healed.

Luke 7:8 For I also am a man set under authority, having under me soldiers, and I say unto one, Go, and he goeth; and to another, Come, and he cometh; and to my servant, Do this, and he doeth it.

Luke 7:9 When Jesus heard these things, he marvelled at him, and turned him about, and said unto the people that followed him, I say unto you, I have not found so great faith, no, not in Israel.

Luke 7:10 And they that were sent, returning to the house, found the servant whole that had been sick.

Luke 7:11 And it came to pass the day after, that he went into a city called Nain; and many of his disciples went with him, and much people.

Luke 7:12 Now when he came nigh to the gate of the city, behold, there was a dead man carried out, the only son of his mother, and she was a widow: and much people of the city was with her.

Luke 7:13 And when the Lord saw her, he had compassion on her, and said unto her, Weep not.

Luke 7:14 And he came and touched the bier: and they that bare him stood still. And he said, Young man, I say unto thee, Arise.

Luke 7:15 And he that was dead sat up, and began to speak. And he delivered him to his mother.

Luke 7:16 And there came a fear on all: and they glorified God, saying, That a great prophet is risen up among us; and, That God hath visited his people.

Luke 7:17 And this rumour of him went forth throughout all Judæa, and throughout all the region round about.

Luke 7:18 And the disciples of John shewed him of all these things.

Luke 7:19 And John calling unto him two of his disciples sent them to Jesus, saying, Art thou he that should come? or look we for another?

Luke 7:20 When the men were come unto him, they said, John Baptist hath sent us unto thee, saying, Art thou he that should come? or look we for another?

Luke 7:21 And in that same hour he cured many of their infirmities and plagues, and of evil spirits; and unto many that were blind he gave sight.

Luke 7:22 Then Jesus answering said unto them, Go your way, and tell John what things ye have seen and heard; how that the blind see, the lame walk, the lepers are cleansed, the deaf hear, the dead are raised, to the poor the gospel is preached.

Luke 7:23 And blessed is he, whosoever shall not be offended in me.

Luke 7:24 And when the messengers of John were departed, he began to speak unto the people concerning John, What went ye out into the wilderness for to see? A reed shaken with the wind?

Luke 7:25 But what went ye out for to see? A man clothed in soft raiment? Behold, they which are gorgeously apparelled, and live delicately, are in kings’ courts.

Luke 7:26 But what went ye out for to see? A prophet? Yea, I say unto you, and much more than a prophet.

Luke 7:27 This is he, of whom it is written, Behold, I send my messenger before thy face, which shall prepare thy way before thee.

Luke 7:28 For I say unto you, Among those that are born of women there is not a greater prophet than John the Baptist: but he that is least in the kingdom of God is greater than he.

Luke 7:29 And all the people that heard him, and the publicans, justified God, being baptized with the baptism of John.

Luke 7:30 But the Pharisees and lawyers rejected the counsel of God against themselves, being not baptized of him.

Luke 7:31 And the Lord said, Whereunto then shall I liken the men of this generation? and to what are they like?

Luke 7:32 They are like unto children sitting in the marketplace, and calling one to another, and saying, We have piped unto you, and ye have not danced; we have mourned to you, and ye have not wept.

Luke 7:33 For John the Baptist came neither eating bread nor drinking wine; and ye say, He hath a devil.

Luke 7:34 The Son of man is come eating and drinking; and ye say, Behold a gluttonous man, and a winebibber, a friend of publicans and sinners!

Luke 7:35 But wisdom is justified of all her children.

Luke 7:36 And one of the Pharisees desired him that he would eat with him. And he went into the Pharisee’s house, and sat down to meat.

Luke 7:37 And, behold, a woman in the city, which was a sinner, when she knew that Jesus sat at meat in the Pharisee’s house, brought an alabaster box of ointment,

Luke 7:38 And stood at his feet behind him weeping, and began to wash his feet with tears, and did wipe them with the hairs of her head, and kissed his feet, and anointed them with the ointment.

Luke 7:39 Now when the Pharisee which had bidden him saw it, he spake within himself, saying, This man, if he were a prophet, would have known who and what manner of woman this is that toucheth him: for she is a sinner.

Luke 7:40 And Jesus answering said unto him, Simon, I have somewhat to say unto thee. And he saith, Master, say on.

Luke 7:41 There was a certain creditor which had two debtors: the one owed five hundred pence, and the other fifty.

Luke 7:42 And when they had nothing to pay, he frankly forgave them both. Tell me therefore, which of them will love him most?

Luke 7:43 Simon answered and said, I suppose that he, to whom he forgave most. And he said unto him, Thou hast rightly judged.

Luke 7:44 And he turned to the woman, and said unto Simon, Seest thou this woman? I entered into thine house, thou gavest me no water for my feet: but she hath washed my feet with tears, and wiped them with the hairs of her head.

Luke 7:45 Thou gavest me no kiss: but this woman since the time I came in hath not ceased to kiss my feet.

Luke 7:46 My head with oil thou didst not anoint: but this woman hath anointed my feet with ointment.

Luke 7:47 Wherefore I say unto thee, Her sins, which are many, are forgiven; for she loved much: but to whom little is forgiven, the same loveth little.

Luke 7:48 And he said unto her, Thy sins are forgiven.

Luke 7:49 And they that sat at meat with him began to say within themselves, Who is this that forgiveth sins also?

Luke 7:50 And he said to the woman, Thy faith hath saved thee; go in peace.
