# Mark 4

Mark 4 (summary): Jesus gives the parables of the sower, the candle under a bushel, the seed growing secretly, and the mustard seed—He stills the tempest.

Mark 4:1 And he began again to teach by the sea side: and there was gathered unto him a great multitude, so that he entered into a ship, and sat in the sea; and the whole multitude was by the sea on the land.

Mark 4:2 And he taught them many things by parables, and said unto them in his doctrine,

Mark 4:3 Hearken; Behold, there went out a sower to sow:

Mark 4:4 And it came to pass, as he sowed, some fell by the way side, and the fowls of the air came and devoured it up.

Mark 4:5 And some fell on stony ground, where it had not much earth; and immediately it sprang up, because it had no depth of earth:

Mark 4:6 But when the sun was up, it was scorched; and because it had no root, it withered away.

Mark 4:7 And some fell among thorns, and the thorns grew up, and choked it, and it yielded no fruit.

Mark 4:8 And other fell on good ground, and did yield fruit that sprang up and increased; and brought forth, some thirty, and some sixty, and some an hundred.

Mark 4:9 And he said unto them, He that hath ears to hear, let him hear.

Mark 4:10 And when he was alone, they that were about him with the twelve asked of him the parable.

Mark 4:11 And he said unto them, Unto you it is given to know the mystery of the kingdom of God: but unto them that are without, all these things are done in parables:

Mark 4:12 That seeing they may see, and not perceive; and hearing they may hear, and not understand; lest at any time they should be converted, and their sins should be forgiven them.

Mark 4:13 And he said unto them, Know ye not this parable? and how then will ye know all parables?

Mark 4:14 The sower soweth the word.

Mark 4:15 And these are they by the way side, where the word is sown; but when they have heard, Satan cometh immediately, and taketh away the word that was sown in their hearts.

Mark 4:16 And these are they likewise which are sown on stony ground; who, when they have heard the word, immediately receive it with gladness;

Mark 4:17 And have no root in themselves, and so endure but for a time: afterward, when affliction or persecution ariseth for the word’s sake, immediately they are offended.

Mark 4:18 And these are they which are sown among thorns; such as hear the word,

Mark 4:19 And the cares of this world, and the deceitfulness of riches, and the lusts of other things entering in, choke the word, and it becometh unfruitful.

Mark 4:20 And these are they which are sown on good ground; such as hear the word, and receive it, and bring forth fruit, some thirtyfold, some sixty, and some an hundred.

Mark 4:21 And he said unto them, Is a candle brought to be put under a bushel, or under a bed? and not to be set on a candlestick?

Mark 4:22 For there is nothing hid, which shall not be manifested; neither was any thing kept secret, but that it should come abroad.

Mark 4:23 If any man have ears to hear, let him hear.

Mark 4:24 And he said unto them, Take heed what ye hear: with what measure ye mete, it shall be measured to you: and unto you that hear shall more be given.

Mark 4:25 For he that hath, to him shall be given: and he that hath not, from him shall be taken even that which he hath.

Mark 4:26 And he said, So is the kingdom of God, as if a man should cast seed into the ground;

Mark 4:27 And should sleep, and rise night and day, and the seed should spring and grow up, he knoweth not how.

Mark 4:28 For the earth bringeth forth fruit of herself; first the blade, then the ear, after that the full corn in the ear.

Mark 4:29 But when the fruit is brought forth, immediately he putteth in the sickle, because the harvest is come.

Mark 4:30 And he said, Whereunto shall we liken the kingdom of God? or with what comparison shall we compare it?

Mark 4:31 It is like a grain of mustard seed, which, when it is sown in the earth, is less than all the seeds that be in the earth:

Mark 4:32 But when it is sown, it groweth up, and becometh greater than all herbs, and shooteth out great branches; so that the fowls of the air may lodge under the shadow of it.

Mark 4:33 And with many such parables spake he the word unto them, as they were able to hear it.

Mark 4:34 But without a parable spake he not unto them: and when they were alone, he expounded all things to his disciples.

Mark 4:35 And the same day, when the even was come, he saith unto them, Let us pass over unto the other side.

Mark 4:36 And when they had sent away the multitude, they took him even as he was in the ship. And there were also with him other little ships.

Mark 4:37 And there arose a great storm of wind, and the waves beat into the ship, so that it was now full.

Mark 4:38 And he was in the hinder part of the ship, asleep on a pillow: and they awake him, and say unto him, Master, carest thou not that we perish?

Mark 4:39 And he arose, and rebuked the wind, and said unto the sea, Peace, be still. And the wind ceased, and there was a great calm.

Mark 4:40 And he said unto them, Why are ye so fearful? how is it that ye have no faith?

Mark 4:41 And they feared exceedingly, and said one to another, What manner of man is this, that even the wind and the sea obey him?
