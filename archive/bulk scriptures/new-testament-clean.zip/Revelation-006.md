# Revelation 6

Revelation 6 (summary): Christ opens the six seals, and John sees the events therein—In the fifth seal, he sees the Christian martyrs; and in the sixth, he sees the signs of the times.

Revelation 6:1 And I saw when the Lamb opened one of the seals, and I heard, as it were the noise of thunder, one of the four beasts saying, Come and see.

Revelation 6:2 And I saw, and behold a white horse: and he that sat on him had a bow; and a crown was given unto him: and he went forth conquering, and to conquer.

Revelation 6:3 And when he had opened the second seal, I heard the second beast say, Come and see.

Revelation 6:4 And there went out another horse that was red: and power was given to him that sat thereon to take peace from the earth, and that they should kill one another: and there was given unto him a great sword.

Revelation 6:5 And when he had opened the third seal, I heard the third beast say, Come and see. And I beheld, and lo a black horse; and he that sat on him had a pair of balances in his hand.

Revelation 6:6 And I heard a voice in the midst of the four beasts say, A measure of wheat for a penny, and three measures of barley for a penny; and see thou hurt not the oil and the wine.

Revelation 6:7 And when he had opened the fourth seal, I heard the voice of the fourth beast say, Come and see.

Revelation 6:8 And I looked, and behold a pale horse: and his name that sat on him was Death, and Hell followed with him. And power was given unto them over the fourth part of the earth, to kill with sword, and with hunger, and with death, and with the beasts of the earth.

Revelation 6:9 And when he had opened the fifth seal, I saw under the altar the souls of them that were slain for the word of God, and for the testimony which they held:

Revelation 6:10 And they cried with a loud voice, saying, How long, O Lord, holy and true, dost thou not judge and avenge our blood on them that dwell on the earth?

Revelation 6:11 And white robes were given unto every one of them; and it was said unto them, that they should rest yet for a little season, until their fellowservants also and their brethren, that should be killed as they were, should be fulfilled.

Revelation 6:12 And I beheld when he had opened the sixth seal, and, lo, there was a great earthquake; and the sun became black as sackcloth of hair, and the moon became as blood;

Revelation 6:13 And the stars of heaven fell unto the earth, even as a fig tree casteth her untimely figs, when she is shaken of a mighty wind.

Revelation 6:14 And the heaven departed as a scroll when it is rolled together; and every mountain and island were moved out of their places.

Revelation 6:15 And the kings of the earth, and the great men, and the rich men, and the chief captains, and the mighty men, and every bondman, and every free man, hid themselves in the dens and in the rocks of the mountains;

Revelation 6:16 And said to the mountains and rocks, Fall on us, and hide us from the face of him that sitteth on the throne, and from the wrath of the Lamb:

Revelation 6:17 For the great day of his wrath is come; and who shall be able to stand?
