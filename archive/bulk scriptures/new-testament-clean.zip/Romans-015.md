# Romans 15

Romans 15 (summary): True Saints fellowship one another—Paul recounts his diligence in preaching the gospel—The gifts of the Spirit are poured out upon the Gentiles.

Romans 15:1 We then that are strong ought to bear the infirmities of the weak, and not to please ourselves.

Romans 15:2 Let every one of us please his neighbour for his good to edification.

Romans 15:3 For even Christ pleased not himself; but, as it is written, The reproaches of them that reproached thee fell on me.

Romans 15:4 For whatsoever things were written aforetime were written for our learning, that we through patience and comfort of the scriptures might have hope.

Romans 15:5 Now the God of patience and consolation grant you to be likeminded one toward another according to Christ Jesus:

Romans 15:6 That ye may with one mind and one mouth glorify God, even the Father of our Lord Jesus Christ.

Romans 15:7 Wherefore receive ye one another, as Christ also received us to the glory of God.

Romans 15:8 Now I say that Jesus Christ was a minister of the circumcision for the truth of God, to confirm the promises made unto the fathers:

Romans 15:9 And that the Gentiles might glorify God for his mercy; as it is written, For this cause I will confess to thee among the Gentiles, and sing unto thy name.

Romans 15:10 And again he saith, Rejoice, ye Gentiles, with his people.

Romans 15:11 And again, Praise the Lord, all ye Gentiles; and laud him, all ye people.

Romans 15:12 And again, Esaias saith, There shall be a root of Jesse, and he that shall rise to reign over the Gentiles; in him shall the Gentiles trust.

Romans 15:13 Now the God of hope fill you with all joy and peace in believing, that ye may abound in hope, through the power of the Holy Ghost.

Romans 15:14 And I myself also am persuaded of you, my brethren, that ye also are full of goodness, filled with all knowledge, able also to admonish one another.

Romans 15:15 Nevertheless, brethren, I have written the more boldly unto you in some sort, as putting you in mind, because of the grace that is given to me of God,

Romans 15:16 That I should be the minister of Jesus Christ to the Gentiles, ministering the gospel of God, that the offering up of the Gentiles might be acceptable, being sanctified by the Holy Ghost.

Romans 15:17 I have therefore whereof I may glory through Jesus Christ in those things which pertain to God.

Romans 15:18 For I will not dare to speak of any of those things which Christ hath not wrought by me, to make the Gentiles obedient, by word and deed,

Romans 15:19 Through mighty signs and wonders, by the power of the Spirit of God; so that from Jerusalem, and round about unto Illyricum, I have fully preached the gospel of Christ.

Romans 15:20 Yea, so have I strived to preach the gospel, not where Christ was named, lest I should build upon another man’s foundation:

Romans 15:21 But as it is written, To whom he was not spoken of, they shall see: and they that have not heard shall understand.

Romans 15:22 For which cause also I have been much hindered from coming to you.

Romans 15:23 But now having no more place in these parts, and having a great desire these many years to come unto you;

Romans 15:24 Whensoever I take my journey into Spain, I will come to you: for I trust to see you in my journey, and to be brought on my way thitherward by you, if first I be somewhat filled with your company.

Romans 15:25 But now I go unto Jerusalem to minister unto the saints.

Romans 15:26 For it hath pleased them of Macedonia and Achaia to make a certain contribution for the poor saints which are at Jerusalem.

Romans 15:27 It hath pleased them verily; and their debtors they are. For if the Gentiles have been made partakers of their spiritual things, their duty is also to minister unto them in carnal things.

Romans 15:28 When therefore I have performed this, and have sealed to them this fruit, I will come by you into Spain.

Romans 15:29 And I am sure that, when I come unto you, I shall come in the fulness of the blessing of the gospel of Christ.

Romans 15:30 Now I beseech you, brethren, for the Lord Jesus Christ’s sake, and for the love of the Spirit, that ye strive together with me in your prayers to God for me;

Romans 15:31 That I may be delivered from them that do not believe in Judæa; and that my service which I have for Jerusalem may be accepted of the saints;

Romans 15:32 That I may come unto you with joy by the will of God, and may with you be refreshed.

Romans 15:33 Now the God of peace be with you all. Amen.
