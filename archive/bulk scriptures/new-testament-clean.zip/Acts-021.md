# Acts 21

Acts 21 (summary): Paul journeys to Jerusalem—He is persecuted, arrested, and bound.

Acts 21:1 And it came to pass, that after we were gotten from them, and had launched, we came with a straight course unto Coos, and the day following unto Rhodes, and from thence unto Patara:

Acts 21:2 And finding a ship sailing over unto Phenicia, we went aboard, and set forth.

Acts 21:3 Now when we had discovered Cyprus, we left it on the left hand, and sailed into Syria, and landed at Tyre: for there the ship was to unlade her burden.

Acts 21:4 And finding disciples, we tarried there seven days: who said to Paul through the Spirit, that he should not go up to Jerusalem.

Acts 21:5 And when we had accomplished those days, we departed and went our way; and they all brought us on our way, with wives and children, till we were out of the city: and we kneeled down on the shore, and prayed.

Acts 21:6 And when we had taken our leave one of another, we took ship; and they returned home again.

Acts 21:7 And when we had finished our course from Tyre, we came to Ptolemais, and saluted the brethren, and abode with them one day.

Acts 21:8 And the next day we that were of Paul’s company departed, and came unto Cæsarea: and we entered into the house of Philip the evangelist, which was one of the seven; and abode with him.

Acts 21:9 And the same man had four daughters, virgins, which did prophesy.

Acts 21:10 And as we tarried there many days, there came down from Judæa a certain prophet, named Agabus.

Acts 21:11 And when he was come unto us, he took Paul’s girdle, and bound his own hands and feet, and said, Thus saith the Holy Ghost, So shall the Jews at Jerusalem bind the man that owneth this girdle, and shall deliver him into the hands of the Gentiles.

Acts 21:12 And when we heard these things, both we, and they of that place, besought him not to go up to Jerusalem.

Acts 21:13 Then Paul answered, What mean ye to weep and to break mine heart? for I am ready not to be bound only, but also to die at Jerusalem for the name of the Lord Jesus.

Acts 21:14 And when he would not be persuaded, we ceased, saying, The will of the Lord be done.

Acts 21:15 And after those days we took up our carriages, and went up to Jerusalem.

Acts 21:16 There went with us also certain of the disciples of Cæsarea, and brought with them one Mnason of Cyprus, an old disciple, with whom we should lodge.

Acts 21:17 And when we were come to Jerusalem, the brethren received us gladly.

Acts 21:18 And the day following Paul went in with us unto James; and all the elders were present.

Acts 21:19 And when he had saluted them, he declared particularly what things God had wrought among the Gentiles by his ministry.

Acts 21:20 And when they heard it, they glorified the Lord, and said unto him, Thou seest, brother, how many thousands of Jews there are which believe; and they are all zealous of the law:

Acts 21:21 And they are informed of thee, that thou teachest all the Jews which are among the Gentiles to forsake Moses, saying that they ought not to circumcise their children, neither to walk after the customs.

Acts 21:22 What is it therefore? the multitude must needs come together: for they will hear that thou art come.

Acts 21:23 Do therefore this that we say to thee: We have four men which have a vow on them;

Acts 21:24 Them take, and purify thyself with them, and be at charges with them, that they may shave their heads: and all may know that those things, whereof they were informed concerning thee, are nothing; but that thou thyself also walkest orderly, and keepest the law.

Acts 21:25 As touching the Gentiles which believe, we have written and concluded that they observe no such thing, save only that they keep themselves from things offered to idols, and from blood, and from strangled, and from fornication.

Acts 21:26 Then Paul took the men, and the next day purifying himself with them entered into the temple, to signify the accomplishment of the days of purification, until that an offering should be offered for every one of them.

Acts 21:27 And when the seven days were almost ended, the Jews which were of Asia, when they saw him in the temple, stirred up all the people, and laid hands on him,

Acts 21:28 Crying out, Men of Israel, help: This is the man, that teacheth all men every where against the people, and the law, and this place: and further brought Greeks also into the temple, and hath polluted this holy place.

Acts 21:29 (For they had seen before with him in the city Trophimus an Ephesian, whom they supposed that Paul had brought into the temple.)

Acts 21:30 And all the city was moved, and the people ran together: and they took Paul, and drew him out of the temple: and forthwith the doors were shut.

Acts 21:31 And as they went about to kill him, tidings came unto the chief captain of the band, that all Jerusalem was in an uproar.

Acts 21:32 Who immediately took soldiers and centurions, and ran down unto them: and when they saw the chief captain and the soldiers, they left beating of Paul.

Acts 21:33 Then the chief captain came near, and took him, and commanded him to be bound with two chains; and demanded who he was, and what he had done.

Acts 21:34 And some cried one thing, some another, among the multitude: and when he could not know the certainty for the tumult, he commanded him to be carried into the castle.

Acts 21:35 And when he came upon the stairs, so it was, that he was borne of the soldiers for the violence of the people.

Acts 21:36 For the multitude of the people followed after, crying, Away with him.

Acts 21:37 And as Paul was to be led into the castle, he said unto the chief captain, May I speak unto thee? Who said, Canst thou speak Greek?

Acts 21:38 Art not thou that Egyptian, which before these days madest an uproar, and leddest out into the wilderness four thousand men that were murderers?

Acts 21:39 But Paul said, I am a man which am a Jew of Tarsus, a city in Cilicia, a citizen of no mean city: and, I beseech thee, suffer me to speak unto the people.

Acts 21:40 And when he had given him licence, Paul stood on the stairs, and beckoned with the hand unto the people. And when there was made a great silence, he spake unto them in the Hebrew tongue, saying,
