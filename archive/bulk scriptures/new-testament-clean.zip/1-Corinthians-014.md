# 1 Corinthians 14

1 Corinthians 14 (summary): People should desire spiritual gifts—Tongues and prophecy are compared—Prophecy is the greater gift—Paul says, You may all prophesy; covet to prophesy.

1 Corinthians 14:1 Follow after charity, and desire spiritual gifts, but rather that ye may prophesy.

1 Corinthians 14:2 For he that speaketh in an unknown tongue speaketh not unto men, but unto God: for no man understandeth him; howbeit in the spirit he speaketh mysteries.

1 Corinthians 14:3 But he that prophesieth speaketh unto men to edification, and exhortation, and comfort.

1 Corinthians 14:4 He that speaketh in an unknown tongue edifieth himself; but he that prophesieth edifieth the church.

1 Corinthians 14:5 I would that ye all spake with tongues, but rather that ye prophesied: for greater is he that prophesieth than he that speaketh with tongues, except he interpret, that the church may receive edifying.

1 Corinthians 14:6 Now, brethren, if I come unto you speaking with tongues, what shall I profit you, except I shall speak to you either by revelation, or by knowledge, or by prophesying, or by doctrine?

1 Corinthians 14:7 And even things without life giving sound, whether pipe or harp, except they give a distinction in the sounds, how shall it be known what is piped or harped?

1 Corinthians 14:8 For if the trumpet give an uncertain sound, who shall prepare himself to the battle?

1 Corinthians 14:9 So likewise ye, except ye utter by the tongue words easy to be understood, how shall it be known what is spoken? for ye shall speak into the air.

1 Corinthians 14:10 There are, it may be, so many kinds of voices in the world, and none of them is without signification.

1 Corinthians 14:11 Therefore if I know not the meaning of the voice, I shall be unto him that speaketh a barbarian, and he that speaketh shall be a barbarian unto me.

1 Corinthians 14:12 Even so ye, forasmuch as ye are zealous of spiritual gifts, seek that ye may excel to the edifying of the church.

1 Corinthians 14:13 Wherefore let him that speaketh in an unknown tongue pray that he may interpret.

1 Corinthians 14:14 For if I pray in an unknown tongue, my spirit prayeth, but my understanding is unfruitful.

1 Corinthians 14:15 What is it then? I will pray with the spirit, and I will pray with the understanding also: I will sing with the spirit, and I will sing with the understanding also.

1 Corinthians 14:16 Else when thou shalt bless with the spirit, how shall he that occupieth the room of the unlearned say Amen at thy giving of thanks, seeing he understandeth not what thou sayest?

1 Corinthians 14:17 For thou verily givest thanks well, but the other is not edified.

1 Corinthians 14:18 I thank my God, I speak with tongues more than ye all:

1 Corinthians 14:19 Yet in the church I had rather speak five words with my understanding, that by my voice I might teach others also, than ten thousand words in an unknown tongue.

1 Corinthians 14:20 Brethren, be not children in understanding: howbeit in malice be ye children, but in understanding be men.

1 Corinthians 14:21 In the law it is written, With men of other tongues and other lips will I speak unto this people; and yet for all that will they not hear me, saith the Lord.

1 Corinthians 14:22 Wherefore tongues are for a sign, not to them that believe, but to them that believe not: but prophesying serveth not for them that believe not, but for them which believe.

1 Corinthians 14:23 If therefore the whole church be come together into one place, and all speak with tongues, and there come in those that are unlearned, or unbelievers, will they not say that ye are mad?

1 Corinthians 14:24 But if all prophesy, and there come in one that believeth not, or one unlearned, he is convinced of all, he is judged of all:

1 Corinthians 14:25 And thus are the secrets of his heart made manifest; and so falling down on his face he will worship God, and report that God is in you of a truth.

1 Corinthians 14:26 How is it then, brethren? when ye come together, every one of you hath a psalm, hath a doctrine, hath a tongue, hath a revelation, hath an interpretation. Let all things be done unto edifying.

1 Corinthians 14:27 If any man speak in an unknown tongue, let it be by two, or at the most by three, and that by course; and let one interpret.

1 Corinthians 14:28 But if there be no interpreter, let him keep silence in the church; and let him speak to himself, and to God.

1 Corinthians 14:29 Let the prophets speak two or three, and let the other judge.

1 Corinthians 14:30 If any thing be revealed to another that sitteth by, let the first hold his peace.

1 Corinthians 14:31 For ye may all prophesy one by one, that all may learn, and all may be comforted.

1 Corinthians 14:32 And the spirits of the prophets are subject to the prophets.

1 Corinthians 14:33 For God is not the author of confusion, but of peace, as in all churches of the saints.

1 Corinthians 14:34 Let your women keep silence in the churches: for it is not permitted unto them to speak; but they are commanded to be under obedience, as also saith the law.

1 Corinthians 14:35 And if they will learn any thing, let them ask their husbands at home: for it is a shame for women to speak in the church.

1 Corinthians 14:36 What? came the word of God out from you? or came it unto you only?

1 Corinthians 14:37 If any man think himself to be a prophet, or spiritual, let him acknowledge that the things that I write unto you are the commandments of the Lord.

1 Corinthians 14:38 But if any man be ignorant, let him be ignorant.

1 Corinthians 14:39 Wherefore, brethren, covet to prophesy, and forbid not to speak with tongues.

1 Corinthians 14:40 Let all things be done decently and in order.
