# Titus 3

Titus 3 (summary): Saints must live righteously after baptism.

Titus 3:1 Put them in mind to be subject to principalities and powers, to obey magistrates, to be ready to every good work,

Titus 3:2 To speak evil of no man, to be no brawlers, but gentle, shewing all meekness unto all men.

Titus 3:3 For we ourselves also were sometimes foolish, disobedient, deceived, serving divers lusts and pleasures, living in malice and envy, hateful, and hating one another.

Titus 3:4 But after that the kindness and love of God our Saviour toward man appeared,

Titus 3:5 Not by works of righteousness which we have done, but according to his mercy he saved us, by the washing of regeneration, and renewing of the Holy Ghost;

Titus 3:6 Which he shed on us abundantly through Jesus Christ our Saviour;

Titus 3:7 That being justified by his grace, we should be made heirs according to the hope of eternal life.

Titus 3:8 This is a faithful saying, and these things I will that thou affirm constantly, that they which have believed in God might be careful to maintain good works. These things are good and profitable unto men.

Titus 3:9 But avoid foolish questions, and genealogies, and contentions, and strivings about the law; for they are unprofitable and vain.

Titus 3:10 A man that is an heretick after the first and second admonition reject;

Titus 3:11 Knowing that he that is such is subverted, and sinneth, being condemned of himself.

Titus 3:12 When I shall send Artemas unto thee, or Tychicus, be diligent to come unto me to Nicopolis: for I have determined there to winter.

Titus 3:13 Bring Zenas the lawyer and Apollos on their journey diligently, that nothing be wanting unto them.

Titus 3:14 And let ours also learn to maintain good works for necessary uses, that they be not unfruitful.

Titus 3:15 All that are with me salute thee. Greet them that love us in the faith. Grace be with you all. Amen.
