# 2 Corinthians 7

2 Corinthians 7 (summary): Godly sorrow for sin leads to repentance—The sorrow of the world leads to death.

2 Corinthians 7:1 Having therefore these promises, dearly beloved, let us cleanse ourselves from all filthiness of the flesh and spirit, perfecting holiness in the fear of God.

2 Corinthians 7:2 Receive us; we have wronged no man, we have corrupted no man, we have defrauded no man.

2 Corinthians 7:3 I speak not this to condemn you: for I have said before, that ye are in our hearts to die and live with you.

2 Corinthians 7:4 Great is my boldness of speech toward you, great is my glorying of you: I am filled with comfort, I am exceeding joyful in all our tribulation.

2 Corinthians 7:5 For, when we were come into Macedonia, our flesh had no rest, but we were troubled on every side; without were fightings, within were fears.

2 Corinthians 7:6 Nevertheless God, that comforteth those that are cast down, comforted us by the coming of Titus;

2 Corinthians 7:7 And not by his coming only, but by the consolation wherewith he was comforted in you, when he told us your earnest desire, your mourning, your fervent mind toward me; so that I rejoiced the more.

2 Corinthians 7:8 For though I made you sorry with a letter, I do not repent, though I did repent: for I perceive that the same epistle hath made you sorry, though it were but for a season.

2 Corinthians 7:9 Now I rejoice, not that ye were made sorry, but that ye sorrowed to repentance: for ye were made sorry after a godly manner, that ye might receive damage by us in nothing.

2 Corinthians 7:10 For godly sorrow worketh repentance to salvation not to be repented of: but the sorrow of the world worketh death.

2 Corinthians 7:11 For behold this selfsame thing, that ye sorrowed after a godly sort, what carefulness it wrought in you, yea, what clearing of yourselves, yea, what indignation, yea, what fear, yea, what vehement desire, yea, what zeal, yea, what revenge! In all things ye have approved yourselves to be clear in this matter.

2 Corinthians 7:12 Wherefore, though I wrote unto you, I did it not for his cause that had done the wrong, nor for his cause that suffered wrong, but that our care for you in the sight of God might appear unto you.

2 Corinthians 7:13 Therefore we were comforted in your comfort: yea, and exceedingly the more joyed we for the joy of Titus, because his spirit was refreshed by you all.

2 Corinthians 7:14 For if I have boasted any thing to him of you, I am not ashamed; but as we spake all things to you in truth, even so our boasting, which I made before Titus, is found a truth.

2 Corinthians 7:15 And his inward affection is more abundant toward you, whilst he remembereth the obedience of you all, how with fear and trembling ye received him.

2 Corinthians 7:16 I rejoice therefore that I have confidence in you in all things.
