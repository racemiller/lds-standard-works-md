# Romans 9

Romans 9 (summary): Paul explains how the law of election (foreordination) operates—The people of Israel are chosen (foreordained) to receive the adoption, covenants, promises, and blessings of the gospel; yet they are not all Israel who are of Israel—They must seek their blessings by faith—The Gentiles also attain to righteousness and salvation by faith.

Romans 9:1 I say the truth in Christ, I lie not, my conscience also bearing me witness in the Holy Ghost,

Romans 9:2 That I have great heaviness and continual sorrow in my heart.

Romans 9:3 For I could wish that myself were accursed from Christ for my brethren, my kinsmen according to the flesh:

Romans 9:4 Who are Israelites; to whom pertaineth the adoption, and the glory, and the covenants, and the giving of the law, and the service of God, and the promises;

Romans 9:5 Whose are the fathers, and of whom as concerning the flesh Christ came, who is over all, God blessed for ever. Amen.

Romans 9:6 Not as though the word of God hath taken none effect. For they are not all Israel, which are of Israel:

Romans 9:7 Neither, because they are the seed of Abraham, are they all children: but, In Isaac shall thy seed be called.

Romans 9:8 That is, They which are the children of the flesh, these are not the children of God: but the children of the promise are counted for the seed.

Romans 9:9 For this is the word of promise, At this time will I come, and Sara shall have a son.

Romans 9:10 And not only this; but when Rebecca also had conceived by one, even by our father Isaac;

Romans 9:11 (For the children being not yet born, neither having done any good or evil, that the purpose of God according to election might stand, not of works, but of him that calleth;)

Romans 9:12 It was said unto her, The elder shall serve the younger.

Romans 9:13 As it is written, Jacob have I loved, but Esau have I hated.

Romans 9:14 What shall we say then? Is there unrighteousness with God? God forbid.

Romans 9:15 For he saith to Moses, I will have mercy on whom I will have mercy, and I will have compassion on whom I will have compassion.

Romans 9:16 So then it is not of him that willeth, nor of him that runneth, but of God that sheweth mercy.

Romans 9:17 For the scripture saith unto Pharaoh, Even for this same purpose have I raised thee up, that I might shew my power in thee, and that my name might be declared throughout all the earth.

Romans 9:18 Therefore hath he mercy on whom he will have mercy, and whom he will he hardeneth.

Romans 9:19 Thou wilt say then unto me, Why doth he yet find fault? For who hath resisted his will?

Romans 9:20 Nay but, O man, who art thou that repliest against God? Shall the thing formed say to him that formed it, Why hast thou made me thus?

Romans 9:21 Hath not the potter power over the clay, of the same lump to make one vessel unto honour, and another unto dishonour?

Romans 9:22 What if God, willing to shew his wrath, and to make his power known, endured with much longsuffering the vessels of wrath fitted to destruction:

Romans 9:23 And that he might make known the riches of his glory on the vessels of mercy, which he had afore prepared unto glory,

Romans 9:24 Even us, whom he hath called, not of the Jews only, but also of the Gentiles?

Romans 9:25 As he saith also in Osee, I will call them my people, which were not my people; and her beloved, which was not beloved.

Romans 9:26 And it shall come to pass, that in the place where it was said unto them, Ye are not my people; there shall they be called the children of the living God.

Romans 9:27 Esaias also crieth concerning Israel, Though the number of the children of Israel be as the sand of the sea, a remnant shall be saved:

Romans 9:28 For he will finish the work, and cut it short in righteousness: because a short work will the Lord make upon the earth.

Romans 9:29 And as Esaias said before, Except the Lord of Sabaoth had left us a seed, we had been as Sodoma, and been made like unto Gomorrha.

Romans 9:30 What shall we say then? That the Gentiles, which followed not after righteousness, have attained to righteousness, even the righteousness which is of faith.

Romans 9:31 But Israel, which followed after the law of righteousness, hath not attained to the law of righteousness.

Romans 9:32 Wherefore? Because they sought it not by faith, but as it were by the works of the law. For they stumbled at that stumblingstone;

Romans 9:33 As it is written, Behold, I lay in Sion a stumblingstone and rock of offence: and whosoever believeth on him shall not be ashamed.
