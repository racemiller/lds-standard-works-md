# 1 Thessalonians 3

1 Thessalonians 3 (summary): The Saints are told to perfect that which is lacking in their faith.

1 Thessalonians 3:1 Wherefore when we could no longer forbear, we thought it good to be left at Athens alone;

1 Thessalonians 3:2 And sent Timotheus, our brother, and minister of God, and our fellowlabourer in the gospel of Christ, to establish you, and to comfort you concerning your faith:

1 Thessalonians 3:3 That no man should be moved by these afflictions: for yourselves know that we are appointed thereunto.

1 Thessalonians 3:4 For verily, when we were with you, we told you before that we should suffer tribulation; even as it came to pass, and ye know.

1 Thessalonians 3:5 For this cause, when I could no longer forbear, I sent to know your faith, lest by some means the tempter have tempted you, and our labour be in vain.

1 Thessalonians 3:6 But now when Timotheus came from you unto us, and brought us good tidings of your faith and charity, and that ye have good remembrance of us always, desiring greatly to see us, as we also to see you:

1 Thessalonians 3:7 Therefore, brethren, we were comforted over you in all our affliction and distress by your faith:

1 Thessalonians 3:8 For now we live, if ye stand fast in the Lord.

1 Thessalonians 3:9 For what thanks can we render to God again for you, for all the joy wherewith we joy for your sakes before our God;

1 Thessalonians 3:10 Night and day praying exceedingly that we might see your face, and might perfect that which is lacking in your faith?

1 Thessalonians 3:11 Now God himself and our Father, and our Lord Jesus Christ, direct our way unto you.

1 Thessalonians 3:12 And the Lord make you to increase and abound in love one toward another, and toward all men, even as we do toward you:

1 Thessalonians 3:13 To the end he may stablish your hearts unblameable in holiness before God, even our Father, at the coming of our Lord Jesus Christ with all his saints.
