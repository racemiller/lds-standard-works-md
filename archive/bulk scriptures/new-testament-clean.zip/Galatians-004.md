# Galatians 4

Galatians 4 (summary): The Saints are children of God by adoption—Paul calls the Galatians back to Christ—He compares the two covenants.

Galatians 4:1 Now I say, That the heir, as long as he is a child, differeth nothing from a servant, though he be lord of all;

Galatians 4:2 But is under tutors and governors until the time appointed of the father.

Galatians 4:3 Even so we, when we were children, were in bondage under the elements of the world:

Galatians 4:4 But when the fulness of the time was come, God sent forth his Son, made of a woman, made under the law,

Galatians 4:5 To redeem them that were under the law, that we might receive the adoption of sons.

Galatians 4:6 And because ye are sons, God hath sent forth the Spirit of his Son into your hearts, crying, Abba, Father.

Galatians 4:7 Wherefore thou art no more a servant, but a son; and if a son, then an heir of God through Christ.

Galatians 4:8 Howbeit then, when ye knew not God, ye did service unto them which by nature are no gods.

Galatians 4:9 But now, after that ye have known God, or rather are known of God, how turn ye again to the weak and beggarly elements, whereunto ye desire again to be in bondage?

Galatians 4:10 Ye observe days, and months, and times, and years.

Galatians 4:11 I am afraid of you, lest I have bestowed upon you labour in vain.

Galatians 4:12 Brethren, I beseech you, be as I am; for I am as ye are: ye have not injured me at all.

Galatians 4:13 Ye know how through infirmity of the flesh I preached the gospel unto you at the first.

Galatians 4:14 And my temptation which was in my flesh ye despised not, nor rejected; but received me as an angel of God, even as Christ Jesus.

Galatians 4:15 Where is then the blessedness ye spake of? for I bear you record, that, if it had been possible, ye would have plucked out your own eyes, and have given them to me.

Galatians 4:16 Am I therefore become your enemy, because I tell you the truth?

Galatians 4:17 They zealously affect you, but not well; yea, they would exclude you, that ye might affect them.

Galatians 4:18 But it is good to be zealously affected always in a good thing, and not only when I am present with you.

Galatians 4:19 My little children, of whom I travail in birth again until Christ be formed in you,

Galatians 4:20 I desire to be present with you now, and to change my voice; for I stand in doubt of you.

Galatians 4:21 Tell me, ye that desire to be under the law, do ye not hear the law?

Galatians 4:22 For it is written, that Abraham had two sons, the one by a bondmaid, the other by a freewoman.

Galatians 4:23 But he who was of the bondwoman was born after the flesh; but he of the freewoman was by promise.

Galatians 4:24 Which things are an allegory: for these are the two covenants; the one from the mount Sinai, which gendereth to bondage, which is Agar.

Galatians 4:25 For this Agar is mount Sinai in Arabia, and answereth to Jerusalem which now is, and is in bondage with her children.

Galatians 4:26 But Jerusalem which is above is free, which is the mother of us all.

Galatians 4:27 For it is written, Rejoice, thou barren that bearest not; break forth and cry, thou that travailest not: for the desolate hath many more children than she which hath an husband.

Galatians 4:28 Now we, brethren, as Isaac was, are the children of promise.

Galatians 4:29 But as then he that was born after the flesh persecuted him that was born after the Spirit, even so it is now.

Galatians 4:30 Nevertheless what saith the scripture? Cast out the bondwoman and her son: for the son of the bondwoman shall not be heir with the son of the freewoman.

Galatians 4:31 So then, brethren, we are not children of the bondwoman, but of the free.
