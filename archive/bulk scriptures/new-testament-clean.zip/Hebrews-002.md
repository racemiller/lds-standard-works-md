# Hebrews 2

Hebrews 2 (summary): Jesus came to suffer death and save men—He came to make reconciliation for the sins of the people.

Hebrews 2:1 Therefore we ought to give the more earnest heed to the things which we have heard, lest at any time we should let them slip.

Hebrews 2:2 For if the word spoken by angels was steadfast, and every transgression and disobedience received a just recompence of reward;

Hebrews 2:3 How shall we escape, if we neglect so great salvation; which at the first began to be spoken by the Lord, and was confirmed unto us by them that heard him;

Hebrews 2:4 God also bearing them witness, both with signs and wonders, and with divers miracles, and gifts of the Holy Ghost, according to his own will?

Hebrews 2:5 For unto the angels hath he not put in subjection the world to come, whereof we speak.

Hebrews 2:6 But one in a certain place testified, saying, What is man, that thou art mindful of him? or the son of man, that thou visitest him?

Hebrews 2:7 Thou madest him a little lower than the angels; thou crownedst him with glory and honour, and didst set him over the works of thy hands:

Hebrews 2:8 Thou hast put all things in subjection under his feet. For in that he put all in subjection under him, he left nothing that is not put under him. But now we see not yet all things put under him.

Hebrews 2:9 But we see Jesus, who was made a little lower than the angels for the suffering of death, crowned with glory and honour; that he by the grace of God should taste death for every man.

Hebrews 2:10 For it became him, for whom are all things, and by whom are all things, in bringing many sons unto glory, to make the captain of their salvation perfect through sufferings.

Hebrews 2:11 For both he that sanctifieth and they who are sanctified are all of one: for which cause he is not ashamed to call them brethren,

Hebrews 2:12 Saying, I will declare thy name unto my brethren, in the midst of the church will I sing praise unto thee.

Hebrews 2:13 And again, I will put my trust in him. And again, Behold I and the children which God hath given me.

Hebrews 2:14 Forasmuch then as the children are partakers of flesh and blood, he also himself likewise took part of the same; that through death he might destroy him that had the power of death, that is, the devil;

Hebrews 2:15 And deliver them who through fear of death were all their lifetime subject to bondage.

Hebrews 2:16 For verily he took not on him the nature of angels; but he took on him the seed of Abraham.

Hebrews 2:17 Wherefore in all things it behoved him to be made like unto his brethren, that he might be a merciful and faithful high priest in things pertaining to God, to make reconciliation for the sins of the people.

Hebrews 2:18 For in that he himself hath suffered being tempted, he is able to succour them that are tempted.
