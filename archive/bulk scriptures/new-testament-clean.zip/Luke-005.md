# Luke 5

Luke 5 (summary): Peter, the fisherman, is called to catch men—Jesus heals a leper—He forgives sins and heals a paralytic—Matthew is called—The sick need a physician—New wine must be put in new bottles.

Luke 5:1 And it came to pass, that, as the people pressed upon him to hear the word of God, he stood by the lake of Gennesaret,

Luke 5:2 And saw two ships standing by the lake: but the fishermen were gone out of them, and were washing their nets.

Luke 5:3 And he entered into one of the ships, which was Simon’s, and prayed him that he would thrust out a little from the land. And he sat down, and taught the people out of the ship.

Luke 5:4 Now when he had left speaking, he said unto Simon, Launch out into the deep, and let down your nets for a draught.

Luke 5:5 And Simon answering said unto him, Master, we have toiled all the night, and have taken nothing: nevertheless at thy word I will let down the net.

Luke 5:6 And when they had this done, they inclosed a great multitude of fishes: and their net brake.

Luke 5:7 And they beckoned unto their partners, which were in the other ship, that they should come and help them. And they came, and filled both the ships, so that they began to sink.

Luke 5:8 When Simon Peter saw it, he fell down at Jesus’ knees, saying, Depart from me; for I am a sinful man, O Lord.

Luke 5:9 For he was astonished, and all that were with him, at the draught of the fishes which they had taken:

Luke 5:10 And so was also James, and John, the sons of Zebedee, which were partners with Simon. And Jesus said unto Simon, Fear not; from henceforth thou shalt catch men.

Luke 5:11 And when they had brought their ships to land, they forsook all, and followed him.

Luke 5:12 And it came to pass, when he was in a certain city, behold a man full of leprosy: who seeing Jesus fell on his face, and besought him, saying, Lord, if thou wilt, thou canst make me clean.

Luke 5:13 And he put forth his hand, and touched him, saying, I will: be thou clean. And immediately the leprosy departed from him.

Luke 5:14 And he charged him to tell no man: but go, and shew thyself to the priest, and offer for thy cleansing, according as Moses commanded, for a testimony unto them.

Luke 5:15 But so much the more went there a fame abroad of him: and great multitudes came together to hear, and to be healed by him of their infirmities.

Luke 5:16 And he withdrew himself into the wilderness, and prayed.

Luke 5:17 And it came to pass on a certain day, as he was teaching, that there were Pharisees and doctors of the law sitting by, which were come out of every town of Galilee, and Judæa, and Jerusalem: and the power of the Lord was present to heal them.

Luke 5:18 And, behold, men brought in a bed a man which was taken with a palsy: and they sought means to bring him in, and to lay him before him.

Luke 5:19 And when they could not find by what way they might bring him in because of the multitude, they went upon the housetop, and let him down through the tiling with his couch into the midst before Jesus.

Luke 5:20 And when he saw their faith, he said unto him, Man, thy sins are forgiven thee.

Luke 5:21 And the scribes and the Pharisees began to reason, saying, Who is this which speaketh blasphemies? Who can forgive sins, but God alone?

Luke 5:22 But when Jesus perceived their thoughts, he answering said unto them, What reason ye in your hearts?

Luke 5:23 Whether is easier, to say, Thy sins be forgiven thee; or to say, Rise up and walk?

Luke 5:24 But that ye may know that the Son of man hath power upon earth to forgive sins, (he said unto the sick of the palsy,) I say unto thee, Arise, and take up thy couch, and go into thine house.

Luke 5:25 And immediately he rose up before them, and took up that whereon he lay, and departed to his own house, glorifying God.

Luke 5:26 And they were all amazed, and they glorified God, and were filled with fear, saying, We have seen strange things to day.

Luke 5:27 And after these things he went forth, and saw a publican, named Levi, sitting at the receipt of custom: and he said unto him, Follow me.

Luke 5:28 And he left all, rose up, and followed him.

Luke 5:29 And Levi made him a great feast in his own house: and there was a great company of publicans and of others that sat down with them.

Luke 5:30 But their scribes and Pharisees murmured against his disciples, saying, Why do ye eat and drink with publicans and sinners?

Luke 5:31 And Jesus answering said unto them, They that are whole need not a physician; but they that are sick.

Luke 5:32 I came not to call the righteous, but sinners to repentance.

Luke 5:33 And they said unto him, Why do the disciples of John fast often, and make prayers, and likewise the disciples of the Pharisees; but thine eat and drink?

Luke 5:34 And he said unto them, Can ye make the children of the bridechamber fast, while the bridegroom is with them?

Luke 5:35 But the days will come, when the bridegroom shall be taken away from them, and then shall they fast in those days.

Luke 5:36 And he spake also a parable unto them; No man putteth a piece of a new garment upon an old; if otherwise, then both the new maketh a rent, and the piece that was taken out of the new agreeth not with the old.

Luke 5:37 And no man putteth new wine into old bottles; else the new wine will burst the bottles, and be spilled, and the bottles shall perish.

Luke 5:38 But new wine must be put into new bottles; and both are preserved.

Luke 5:39 No man also having drunk old wine straightway desireth new: for he saith, The old is better.
