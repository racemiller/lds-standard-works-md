# 2 Corinthians 8

2 Corinthians 8 (summary): True Saints impart of their substance to the poor—Christ, out of His poverty, brought eternal riches.

2 Corinthians 8:1 Moreover, brethren, we do you to wit of the grace of God bestowed on the churches of Macedonia;

2 Corinthians 8:2 How that in a great trial of affliction the abundance of their joy and their deep poverty abounded unto the riches of their liberality.

2 Corinthians 8:3 For to their power, I bear record, yea, and beyond their power they were willing of themselves;

2 Corinthians 8:4 Praying us with much entreaty that we would receive the gift, and take upon us the fellowship of the ministering to the saints.

2 Corinthians 8:5 And this they did, not as we hoped, but first gave their own selves to the Lord, and unto us by the will of God.

2 Corinthians 8:6 Insomuch that we desired Titus, that as he had begun, so he would also finish in you the same grace also.

2 Corinthians 8:7 Therefore, as ye abound in every thing, in faith, and utterance, and knowledge, and in all diligence, and in your love to us, see that ye abound in this grace also.

2 Corinthians 8:8 I speak not by commandment, but by occasion of the forwardness of others, and to prove the sincerity of your love.

2 Corinthians 8:9 For ye know the grace of our Lord Jesus Christ, that, though he was rich, yet for your sakes he became poor, that ye through his poverty might be rich.

2 Corinthians 8:10 And herein I give my advice: for this is expedient for you, who have begun before, not only to do, but also to be forward a year ago.

2 Corinthians 8:11 Now therefore perform the doing of it; that as there was a readiness to will, so there may be a performance also out of that which ye have.

2 Corinthians 8:12 For if there be first a willing mind, it is accepted according to that a man hath, and not according to that he hath not.

2 Corinthians 8:13 For I mean not that other men be eased, and ye burdened:

2 Corinthians 8:14 But by an equality, that now at this time your abundance may be a supply for their want, that their abundance also may be a supply for your want: that there may be equality:

2 Corinthians 8:15 As it is written, He that had gathered much had nothing over; and he that had gathered little had no lack.

2 Corinthians 8:16 But thanks be to God, which put the same earnest care into the heart of Titus for you.

2 Corinthians 8:17 For indeed he accepted the exhortation; but being more forward, of his own accord he went unto you.

2 Corinthians 8:18 And we have sent with him the brother, whose praise is in the gospel throughout all the churches;

2 Corinthians 8:19 And not that only, but who was also chosen of the churches to travel with us with this grace, which is administered by us to the glory of the same Lord, and declaration of your ready mind:

2 Corinthians 8:20 Avoiding this, that no man should blame us in this abundance which is administered by us:

2 Corinthians 8:21 Providing for honest things, not only in the sight of the Lord, but also in the sight of men.

2 Corinthians 8:22 And we have sent with them our brother, whom we have oftentimes proved diligent in many things, but now much more diligent, upon the great confidence which I have in you.

2 Corinthians 8:23 Whether any do inquire of Titus, he is my partner and fellowhelper concerning you: or our brethren be inquired of, they are the messengers of the churches, and the glory of Christ.

2 Corinthians 8:24 Wherefore shew ye to them, and before the churches, the proof of your love, and of our boasting on your behalf.
