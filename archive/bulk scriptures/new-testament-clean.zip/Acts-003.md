# Acts 3

Acts 3 (summary): Peter and John heal a man lame since birth—Peter preaches repentance—He also speaks of the age of restoration preceding the Second Coming—He identifies Christ as the prophet of whom Moses spoke.

Acts 3:1 Now Peter and John went up together into the temple at the hour of prayer, being the ninth hour.

Acts 3:2 And a certain man lame from his mother’s womb was carried, whom they laid daily at the gate of the temple which is called Beautiful, to ask alms of them that entered into the temple;

Acts 3:3 Who seeing Peter and John about to go into the temple asked an alms.

Acts 3:4 And Peter, fastening his eyes upon him with John, said, Look on us.

Acts 3:5 And he gave heed unto them, expecting to receive something of them.

Acts 3:6 Then Peter said, Silver and gold have I none; but such as I have give I thee: In the name of Jesus Christ of Nazareth rise up and walk.

Acts 3:7 And he took him by the right hand, and lifted him up: and immediately his feet and ankle bones received strength.

Acts 3:8 And he leaping up stood, and walked, and entered with them into the temple, walking, and leaping, and praising God.

Acts 3:9 And all the people saw him walking and praising God:

Acts 3:10 And they knew that it was he which sat for alms at the Beautiful gate of the temple: and they were filled with wonder and amazement at that which had happened unto him.

Acts 3:11 And as the lame man which was healed held Peter and John, all the people ran together unto them in the porch that is called Solomon’s, greatly wondering.

Acts 3:12 And when Peter saw it, he answered unto the people, Ye men of Israel, why marvel ye at this? or why look ye so earnestly on us, as though by our own power or holiness we had made this man to walk?

Acts 3:13 The God of Abraham, and of Isaac, and of Jacob, the God of our fathers, hath glorified his Son Jesus; whom ye delivered up, and denied him in the presence of Pilate, when he was determined to let him go.

Acts 3:14 But ye denied the Holy One and the Just, and desired a murderer to be granted unto you;

Acts 3:15 And killed the Prince of life, whom God hath raised from the dead; whereof we are witnesses.

Acts 3:16 And his name through faith in his name hath made this man strong, whom ye see and know: yea, the faith which is by him hath given him this perfect soundness in the presence of you all.

Acts 3:17 And now, brethren, I wot that through ignorance ye did it, as did also your rulers.

Acts 3:18 But those things, which God before had shewed by the mouth of all his prophets, that Christ should suffer, he hath so fulfilled.

Acts 3:19 Repent ye therefore, and be converted, that your sins may be blotted out, when the times of refreshing shall come from the presence of the Lord;

Acts 3:20 And he shall send Jesus Christ, which before was preached unto you:

Acts 3:21 Whom the heaven must receive until the times of restitution of all things, which God hath spoken by the mouth of all his holy prophets since the world began.

Acts 3:22 For Moses truly said unto the fathers, A prophet shall the Lord your God raise up unto you of your brethren, like unto me; him shall ye hear in all things whatsoever he shall say unto you.

Acts 3:23 And it shall come to pass, that every soul, which will not hear that prophet, shall be destroyed from among the people.

Acts 3:24 Yea, and all the prophets from Samuel and those that follow after, as many as have spoken, have likewise foretold of these days.

Acts 3:25 Ye are the children of the prophets, and of the covenant which God made with our fathers, saying unto Abraham, And in thy seed shall all the kindreds of the earth be blessed.

Acts 3:26 Unto you first God, having raised up his Son Jesus, sent him to bless you, in turning away every one of you from his iniquities.
