# Hebrews 4

Hebrews 4 (summary): The gospel was offered to ancient Israel—Saints enter into the rest of the Lord—Though tempted in all points, Jesus was without sin.

Hebrews 4:1 Let us therefore fear, lest, a promise being left us of entering into his rest, any of you should seem to come short of it.

Hebrews 4:2 For unto us was the gospel preached, as well as unto them: but the word preached did not profit them, not being mixed with faith in them that heard it.

Hebrews 4:3 For we which have believed do enter into rest, as he said, As I have sworn in my wrath, if they shall enter into my rest: although the works were finished from the foundation of the world.

Hebrews 4:4 For he spake in a certain place of the seventh day on this wise, And God did rest the seventh day from all his works.

Hebrews 4:5 And in this place again, If they shall enter into my rest.

Hebrews 4:6 Seeing therefore it remaineth that some must enter therein, and they to whom it was first preached entered not in because of unbelief:

Hebrews 4:7 Again, he limiteth a certain day, saying in David, To day, after so long a time; as it is said, To day if ye will hear his voice, harden not your hearts.

Hebrews 4:8 For if Jesus had given them rest, then would he not afterward have spoken of another day.

Hebrews 4:9 There remaineth therefore a rest to the people of God.

Hebrews 4:10 For he that is entered into his rest, he also hath ceased from his own works, as God did from his.

Hebrews 4:11 Let us labour therefore to enter into that rest, lest any man fall after the same example of unbelief.

Hebrews 4:12 For the word of God is quick, and powerful, and sharper than any twoedged sword, piercing even to the dividing asunder of soul and spirit, and of the joints and marrow, and is a discerner of the thoughts and intents of the heart.

Hebrews 4:13 Neither is there any creature that is not manifest in his sight: but all things are naked and opened unto the eyes of him with whom we have to do.

Hebrews 4:14 Seeing then that we have a great high priest, that is passed into the heavens, Jesus the Son of God, let us hold fast our profession.

Hebrews 4:15 For we have not an high priest which cannot be touched with the feeling of our infirmities; but was in all points tempted like as we are, yet without sin.

Hebrews 4:16 Let us therefore come boldly unto the throne of grace, that we may obtain mercy, and find grace to help in time of need.
