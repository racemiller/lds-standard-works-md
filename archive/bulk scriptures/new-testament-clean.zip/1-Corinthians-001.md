# 1 Corinthians 1

1 Corinthians 1 (summary): True Saints are perfectly united in the same mind and in the same judgment—Preach the gospel and save souls—The gospel is preached by the weak and the simple.

1 Corinthians 1:1 Paul, called to be an apostle of Jesus Christ through the will of God, and Sosthenes our brother,

1 Corinthians 1:2 Unto the church of God which is at Corinth, to them that are sanctified in Christ Jesus, called to be saints, with all that in every place call upon the name of Jesus Christ our Lord, both theirs and ours:

1 Corinthians 1:3 Grace be unto you, and peace, from God our Father, and from the Lord Jesus Christ.

1 Corinthians 1:4 I thank my God always on your behalf, for the grace of God which is given you by Jesus Christ;

1 Corinthians 1:5 That in every thing ye are enriched by him, in all utterance, and in all knowledge;

1 Corinthians 1:6 Even as the testimony of Christ was confirmed in you:

1 Corinthians 1:7 So that ye come behind in no gift; waiting for the coming of our Lord Jesus Christ:

1 Corinthians 1:8 Who shall also confirm you unto the end, that ye may be blameless in the day of our Lord Jesus Christ.

1 Corinthians 1:9 God is faithful, by whom ye were called unto the fellowship of his Son Jesus Christ our Lord.

1 Corinthians 1:10 Now I beseech you, brethren, by the name of our Lord Jesus Christ, that ye all speak the same thing, and that there be no divisions among you; but that ye be perfectly joined together in the same mind and in the same judgment.

1 Corinthians 1:11 For it hath been declared unto me of you, my brethren, by them which are of the house of Chloe, that there are contentions among you.

1 Corinthians 1:12 Now this I say, that every one of you saith, I am of Paul; and I of Apollos; and I of Cephas; and I of Christ.

1 Corinthians 1:13 Is Christ divided? was Paul crucified for you? or were ye baptized in the name of Paul?

1 Corinthians 1:14 I thank God that I baptized none of you, but Crispus and Gaius;

1 Corinthians 1:15 Lest any should say that I had baptized in mine own name.

1 Corinthians 1:16 And I baptized also the household of Stephanas: besides, I know not whether I baptized any other.

1 Corinthians 1:17 For Christ sent me not to baptize, but to preach the gospel: not with wisdom of words, lest the cross of Christ should be made of none effect.

1 Corinthians 1:18 For the preaching of the cross is to them that perish foolishness; but unto us which are saved it is the power of God.

1 Corinthians 1:19 For it is written, I will destroy the wisdom of the wise, and will bring to nothing the understanding of the prudent.

1 Corinthians 1:20 Where is the wise? where is the scribe? where is the disputer of this world? hath not God made foolish the wisdom of this world?

1 Corinthians 1:21 For after that in the wisdom of God the world by wisdom knew not God, it pleased God by the foolishness of preaching to save them that believe.

1 Corinthians 1:22 For the Jews require a sign, and the Greeks seek after wisdom:

1 Corinthians 1:23 But we preach Christ crucified, unto the Jews a stumblingblock, and unto the Greeks foolishness;

1 Corinthians 1:24 But unto them which are called, both Jews and Greeks, Christ the power of God, and the wisdom of God.

1 Corinthians 1:25 Because the foolishness of God is wiser than men; and the weakness of God is stronger than men.

1 Corinthians 1:26 For ye see your calling, brethren, how that not many wise men after the flesh, not many mighty, not many noble, are called:

1 Corinthians 1:27 But God hath chosen the foolish things of the world to confound the wise; and God hath chosen the weak things of the world to confound the things which are mighty;

1 Corinthians 1:28 And base things of the world, and things which are despised, hath God chosen, yea, and things which are not, to bring to nought things that are:

1 Corinthians 1:29 That no flesh should glory in his presence.

1 Corinthians 1:30 But of him are ye in Christ Jesus, who of God is made unto us wisdom, and righteousness, and sanctification, and redemption:

1 Corinthians 1:31 That, according as it is written, He that glorieth, let him glory in the Lord.
