# Acts 9

Acts 9 (summary): Jesus appears to Saul—Saul is a chosen vessel—Ananias restores Saul’s sight—Saul is baptized and begins his ministry—Peter heals Æneas and raises Dorcas from death.

Acts 9:1 And Saul, yet breathing out threatenings and slaughter against the disciples of the Lord, went unto the high priest,

Acts 9:2 And desired of him letters to Damascus to the synagogues, that if he found any of this way, whether they were men or women, he might bring them bound unto Jerusalem.

Acts 9:3 And as he journeyed, he came near Damascus: and suddenly there shined round about him a light from heaven:

Acts 9:4 And he fell to the earth, and heard a voice saying unto him, Saul, Saul, why persecutest thou me?

Acts 9:5 And he said, Who art thou, Lord? And the Lord said, I am Jesus whom thou persecutest: it is hard for thee to kick against the pricks.

Acts 9:6 And he trembling and astonished said, Lord, what wilt thou have me to do? And the Lord said unto him, Arise, and go into the city, and it shall be told thee what thou must do.

Acts 9:7 And the men which journeyed with him stood speechless, hearing a voice, but seeing no man.

Acts 9:8 And Saul arose from the earth; and when his eyes were opened, he saw no man: but they led him by the hand, and brought him into Damascus.

Acts 9:9 And he was three days without sight, and neither did eat nor drink.

Acts 9:10 And there was a certain disciple at Damascus, named Ananias; and to him said the Lord in a vision, Ananias. And he said, Behold, I am here, Lord.

Acts 9:11 And the Lord said unto him, Arise, and go into the street which is called Straight, and inquire in the house of Judas for one called Saul, of Tarsus: for, behold, he prayeth,

Acts 9:12 And hath seen in a vision a man named Ananias coming in, and putting his hand on him, that he might receive his sight.

Acts 9:13 Then Ananias answered, Lord, I have heard by many of this man, how much evil he hath done to thy saints at Jerusalem:

Acts 9:14 And here he hath authority from the chief priests to bind all that call on thy name.

Acts 9:15 But the Lord said unto him, Go thy way: for he is a chosen vessel unto me, to bear my name before the Gentiles, and kings, and the children of Israel:

Acts 9:16 For I will shew him how great things he must suffer for my name’s sake.

Acts 9:17 And Ananias went his way, and entered into the house; and putting his hands on him said, Brother Saul, the Lord, even Jesus, that appeared unto thee in the way as thou camest, hath sent me, that thou mightest receive thy sight, and be filled with the Holy Ghost.

Acts 9:18 And immediately there fell from his eyes as it had been scales: and he received sight forthwith, and arose, and was baptized.

Acts 9:19 And when he had received meat, he was strengthened. Then was Saul certain days with the disciples which were at Damascus.

Acts 9:20 And straightway he preached Christ in the synagogues, that he is the Son of God.

Acts 9:21 But all that heard him were amazed, and said; Is not this he that destroyed them which called on this name in Jerusalem, and came hither for that intent, that he might bring them bound unto the chief priests?

Acts 9:22 But Saul increased the more in strength, and confounded the Jews which dwelt at Damascus, proving that this is very Christ.

Acts 9:23 And after that many days were fulfilled, the Jews took counsel to kill him:

Acts 9:24 But their laying await was known of Saul. And they watched the gates day and night to kill him.

Acts 9:25 Then the disciples took him by night, and let him down by the wall in a basket.

Acts 9:26 And when Saul was come to Jerusalem, he assayed to join himself to the disciples: but they were all afraid of him, and believed not that he was a disciple.

Acts 9:27 But Barnabas took him, and brought him to the apostles, and declared unto them how he had seen the Lord in the way, and that he had spoken to him, and how he had preached boldly at Damascus in the name of Jesus.

Acts 9:28 And he was with them coming in and going out at Jerusalem.

Acts 9:29 And he spake boldly in the name of the Lord Jesus, and disputed against the Grecians: but they went about to slay him.

Acts 9:30 Which when the brethren knew, they brought him down to Cæsarea, and sent him forth to Tarsus.

Acts 9:31 Then had the churches rest throughout all Judæa and Galilee and Samaria, and were edified; and walking in the fear of the Lord, and in the comfort of the Holy Ghost, were multiplied.

Acts 9:32 And it came to pass, as Peter passed throughout all quarters, he came down also to the saints which dwelt at Lydda.

Acts 9:33 And there he found a certain man named Æneas, which had kept his bed eight years, and was sick of the palsy.

Acts 9:34 And Peter said unto him, Æneas, Jesus Christ maketh thee whole: arise, and make thy bed. And he arose immediately.

Acts 9:35 And all that dwelt at Lydda and Saron saw him, and turned to the Lord.

Acts 9:36 Now there was at Joppa a certain disciple named Tabitha, which by interpretation is called Dorcas: this woman was full of good works and almsdeeds which she did.

Acts 9:37 And it came to pass in those days, that she was sick, and died: whom when they had washed, they laid her in an upper chamber.

Acts 9:38 And forasmuch as Lydda was nigh to Joppa, and the disciples had heard that Peter was there, they sent unto him two men, desiring him that he would not delay to come to them.

Acts 9:39 Then Peter arose and went with them. When he was come, they brought him into the upper chamber: and all the widows stood by him weeping, and shewing the coats and garments which Dorcas made, while she was with them.

Acts 9:40 But Peter put them all forth, and kneeled down, and prayed; and turning him to the body said, Tabitha, arise. And she opened her eyes: and when she saw Peter, she sat up.

Acts 9:41 And he gave her his hand, and lifted her up, and when he had called the saints and widows, presented her alive.

Acts 9:42 And it was known throughout all Joppa; and many believed in the Lord.

Acts 9:43 And it came to pass, that he tarried many days in Joppa with one Simon a tanner.
