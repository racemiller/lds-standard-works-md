# Luke 11

Luke 11 (summary): Jesus gives the Lord’s Prayer—He discusses the casting out of devils—He acclaims Himself as greater than Jonah and Solomon—He rebukes the Pharisees and says that the blood of all the prophets may be required of their generation.

Luke 11:1 And it came to pass, that, as he was praying in a certain place, when he ceased, one of his disciples said unto him, Lord, teach us to pray, as John also taught his disciples.

Luke 11:2 And he said unto them, When ye pray, say, Our Father which art in heaven, Hallowed be thy name. Thy kingdom come. Thy will be done, as in heaven, so in earth.

Luke 11:3 Give us day by day our daily bread.

Luke 11:4 And forgive us our sins; for we also forgive every one that is indebted to us. And lead us not into temptation; but deliver us from evil.

Luke 11:5 And he said unto them, Which of you shall have a friend, and shall go unto him at midnight, and say unto him, Friend, lend me three loaves;

Luke 11:6 For a friend of mine in his journey is come to me, and I have nothing to set before him?

Luke 11:7 And he from within shall answer and say, Trouble me not: the door is now shut, and my children are with me in bed; I cannot rise and give thee.

Luke 11:8 I say unto you, Though he will not rise and give him, because he is his friend, yet because of his importunity he will rise and give him as many as he needeth.

Luke 11:9 And I say unto you, Ask, and it shall be given you; seek, and ye shall find; knock, and it shall be opened unto you.

Luke 11:10 For every one that asketh receiveth; and he that seeketh findeth; and to him that knocketh it shall be opened.

Luke 11:11 If a son shall ask bread of any of you that is a father, will he give him a stone? or if he ask a fish, will he for a fish give him a serpent?

Luke 11:12 Or if he shall ask an egg, will he offer him a scorpion?

Luke 11:13 If ye then, being evil, know how to give good gifts unto your children: how much more shall your heavenly Father give the Holy Spirit to them that ask him?

Luke 11:14 And he was casting out a devil, and it was dumb. And it came to pass, when the devil was gone out, the dumb spake; and the people wondered.

Luke 11:15 But some of them said, He casteth out devils through Beelzebub the chief of the devils.

Luke 11:16 And others, tempting him, sought of him a sign from heaven.

Luke 11:17 But he, knowing their thoughts, said unto them, Every kingdom divided against itself is brought to desolation; and a house divided against a house falleth.

Luke 11:18 If Satan also be divided against himself, how shall his kingdom stand? because ye say that I cast out devils through Beelzebub.

Luke 11:19 And if I by Beelzebub cast out devils, by whom do your sons cast them out? therefore shall they be your judges.

Luke 11:20 But if I with the finger of God cast out devils, no doubt the kingdom of God is come upon you.

Luke 11:21 When a strong man armed keepeth his palace, his goods are in peace:

Luke 11:22 But when a stronger than he shall come upon him, and overcome him, he taketh from him all his armour wherein he trusted, and divideth his spoils.

Luke 11:23 He that is not with me is against me: and he that gathereth not with me scattereth.

Luke 11:24 When the unclean spirit is gone out of a man, he walketh through dry places, seeking rest; and finding none, he saith, I will return unto my house whence I came out.

Luke 11:25 And when he cometh, he findeth it swept and garnished.

Luke 11:26 Then goeth he, and taketh to him seven other spirits more wicked than himself; and they enter in, and dwell there: and the last state of that man is worse than the first.

Luke 11:27 And it came to pass, as he spake these things, a certain woman of the company lifted up her voice, and said unto him, Blessed is the womb that bare thee, and the paps which thou hast sucked.

Luke 11:28 But he said, Yea rather, blessed are they that hear the word of God, and keep it.

Luke 11:29 And when the people were gathered thick together, he began to say, This is an evil generation: they seek a sign; and there shall no sign be given it, but the sign of Jonas the prophet.

Luke 11:30 For as Jonas was a sign unto the Ninevites, so shall also the Son of man be to this generation.

Luke 11:31 The queen of the south shall rise up in the judgment with the men of this generation, and condemn them: for she came from the utmost parts of the earth to hear the wisdom of Solomon; and, behold, a greater than Solomon is here.

Luke 11:32 The men of Nineve shall rise up in the judgment with this generation, and shall condemn it: for they repented at the preaching of Jonas; and, behold, a greater than Jonas is here.

Luke 11:33 No man, when he hath lighted a candle, putteth it in a secret place, neither under a bushel, but on a candlestick, that they which come in may see the light.

Luke 11:34 The light of the body is the eye: therefore when thine eye is single, thy whole body also is full of light; but when thine eye is evil, thy body also is full of darkness.

Luke 11:35 Take heed therefore that the light which is in thee be not darkness.

Luke 11:36 If thy whole body therefore be full of light, having no part dark, the whole shall be full of light, as when the bright shining of a candle doth give thee light.

Luke 11:37 And as he spake, a certain Pharisee besought him to dine with him: and he went in, and sat down to meat.

Luke 11:38 And when the Pharisee saw it, he marvelled that he had not first washed before dinner.

Luke 11:39 And the Lord said unto him, Now do ye Pharisees make clean the outside of the cup and the platter; but your inward part is full of ravening and wickedness.

Luke 11:40 Ye fools, did not he that made that which is without make that which is within also?

Luke 11:41 But rather give alms of such things as ye have; and, behold, all things are clean unto you.

Luke 11:42 But woe unto you, Pharisees! for ye tithe mint and rue and all manner of herbs, and pass over judgment and the love of God: these ought ye to have done, and not to leave the other undone.

Luke 11:43 Woe unto you, Pharisees! for ye love the uppermost seats in the synagogues, and greetings in the markets.

Luke 11:44 Woe unto you, scribes and Pharisees, hypocrites! for ye are as graves which appear not, and the men that walk over them are not aware of them.

Luke 11:45 Then answered one of the lawyers, and said unto him, Master, thus saying thou reproachest us also.

Luke 11:46 And he said, Woe unto you also, ye lawyers! for ye lade men with burdens grievous to be borne, and ye yourselves touch not the burdens with one of your fingers.

Luke 11:47 Woe unto you! for ye build the sepulchres of the prophets, and your fathers killed them.

Luke 11:48 Truly ye bear witness that ye allow the deeds of your fathers: for they indeed killed them, and ye build their sepulchres.

Luke 11:49 Therefore also said the wisdom of God, I will send them prophets and apostles, and some of them they shall slay and persecute:

Luke 11:50 That the blood of all the prophets, which was shed from the foundation of the world, may be required of this generation;

Luke 11:51 From the blood of Abel unto the blood of Zacharias, which perished between the altar and the temple: verily I say unto you, It shall be required of this generation.

Luke 11:52 Woe unto you, lawyers! for ye have taken away the key of knowledge: ye entered not in yourselves, and them that were entering in ye hindered.

Luke 11:53 And as he said these things unto them, the scribes and the Pharisees began to urge him vehemently, and to provoke him to speak of many things:

Luke 11:54 Laying wait for him, and seeking to catch something out of his mouth, that they might accuse him.
