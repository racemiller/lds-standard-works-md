# Mark 11

Mark 11 (summary): Jesus rides into Jerusalem amid shouts of hosanna—He curses a fig tree, drives the money changers from the temple, and confounds the scribes on the matter of authority.

Mark 11:1 And when they came nigh to Jerusalem, unto Bethphage and Bethany, at the mount of Olives, he sendeth forth two of his disciples,

Mark 11:2 And saith unto them, Go your way into the village over against you: and as soon as ye be entered into it, ye shall find a colt tied, whereon never man sat; loose him, and bring him.

Mark 11:3 And if any man say unto you, Why do ye this? say ye that the Lord hath need of him; and straightway he will send him hither.

Mark 11:4 And they went their way, and found the colt tied by the door without in a place where two ways met; and they loose him.

Mark 11:5 And certain of them that stood there said unto them, What do ye, loosing the colt?

Mark 11:6 And they said unto them even as Jesus had commanded: and they let them go.

Mark 11:7 And they brought the colt to Jesus, and cast their garments on him; and he sat upon him.

Mark 11:8 And many spread their garments in the way: and others cut down branches off the trees, and strawed them in the way.

Mark 11:9 And they that went before, and they that followed, cried, saying, Hosanna; Blessed is he that cometh in the name of the Lord:

Mark 11:10 Blessed be the kingdom of our father David, that cometh in the name of the Lord: Hosanna in the highest.

Mark 11:11 And Jesus entered into Jerusalem, and into the temple: and when he had looked round about upon all things, and now the eventide was come, he went out unto Bethany with the twelve.

Mark 11:12 And on the morrow, when they were come from Bethany, he was hungry:

Mark 11:13 And seeing a fig tree afar off having leaves, he came, if haply he might find any thing thereon: and when he came to it, he found nothing but leaves; for the time of figs was not yet.

Mark 11:14 And Jesus answered and said unto it, No man eat fruit of thee hereafter for ever. And his disciples heard it.

Mark 11:15 And they come to Jerusalem: and Jesus went into the temple, and began to cast out them that sold and bought in the temple, and overthrew the tables of the moneychangers, and the seats of them that sold doves;

Mark 11:16 And would not suffer that any man should carry any vessel through the temple.

Mark 11:17 And he taught, saying unto them, Is it not written, My house shall be called of all nations the house of prayer? but ye have made it a den of thieves.

Mark 11:18 And the scribes and chief priests heard it, and sought how they might destroy him: for they feared him, because all the people was astonished at his doctrine.

Mark 11:19 And when even was come, he went out of the city.

Mark 11:20 And in the morning, as they passed by, they saw the fig tree dried up from the roots.

Mark 11:21 And Peter calling to remembrance saith unto him, Master, behold, the fig tree which thou cursedst is withered away.

Mark 11:22 And Jesus answering saith unto them, Have faith in God.

Mark 11:23 For verily I say unto you, That whosoever shall say unto this mountain, Be thou removed, and be thou cast into the sea; and shall not doubt in his heart, but shall believe that those things which he saith shall come to pass; he shall have whatsoever he saith.

Mark 11:24 Therefore I say unto you, What things soever ye desire, when ye pray, believe that ye receive them, and ye shall have them.

Mark 11:25 And when ye stand praying, forgive, if ye have ought against any: that your Father also which is in heaven may forgive you your trespasses.

Mark 11:26 But if ye do not forgive, neither will your Father which is in heaven forgive your trespasses.

Mark 11:27 And they come again to Jerusalem: and as he was walking in the temple, there come to him the chief priests, and the scribes, and the elders,

Mark 11:28 And say unto him, By what authority doest thou these things? and who gave thee this authority to do these things?

Mark 11:29 And Jesus answered and said unto them, I will also ask of you one question, and answer me, and I will tell you by what authority I do these things.

Mark 11:30 The baptism of John, was it from heaven, or of men? answer me.

Mark 11:31 And they reasoned with themselves, saying, If we shall say, From heaven; he will say, Why then did ye not believe him?

Mark 11:32 But if we shall say, Of men; they feared the people: for all men counted John, that he was a prophet indeed.

Mark 11:33 And they answered and said unto Jesus, We cannot tell. And Jesus answering saith unto them, Neither do I tell you by what authority I do these things.
