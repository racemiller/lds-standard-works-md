# Luke 2

Luke 2 (summary): Heavenly messengers herald the birth of Jesus in Bethlehem—He is circumcised, and Simeon and Anna prophesy of His mission—At twelve years of age, He goes about His Father’s business.

Luke 2:1 And it came to pass in those days, that there went out a decree from Cæsar Augustus, that all the world should be taxed.

Luke 2:2 (And this taxing was first made when Cyrenius was governor of Syria.)

Luke 2:3 And all went to be taxed, every one into his own city.

Luke 2:4 And Joseph also went up from Galilee, out of the city of Nazareth, into Judæa, unto the city of David, which is called Bethlehem; (because he was of the house and lineage of David:)

Luke 2:5 To be taxed with Mary his espoused wife, being great with child.

Luke 2:6 And so it was, that, while they were there, the days were accomplished that she should be delivered.

Luke 2:7 And she brought forth her firstborn son, and wrapped him in swaddling clothes, and laid him in a manger; because there was no room for them in the inn.

Luke 2:8 And there were in the same country shepherds abiding in the field, keeping watch over their flock by night.

Luke 2:9 And, lo, the angel of the Lord came upon them, and the glory of the Lord shone round about them: and they were sore afraid.

Luke 2:10 And the angel said unto them, Fear not: for, behold, I bring you good tidings of great joy, which shall be to all people.

Luke 2:11 For unto you is born this day in the city of David a Saviour, which is Christ the Lord.

Luke 2:12 And this shall be a sign unto you; Ye shall find the babe wrapped in swaddling clothes, lying in a manger.

Luke 2:13 And suddenly there was with the angel a multitude of the heavenly host praising God, and saying,

Luke 2:14 Glory to God in the highest, and on earth peace, good will toward men.

Luke 2:15 And it came to pass, as the angels were gone away from them into heaven, the shepherds said one to another, Let us now go even unto Bethlehem, and see this thing which is come to pass, which the Lord hath made known unto us.

Luke 2:16 And they came with haste, and found Mary, and Joseph, and the babe lying in a manger.

Luke 2:17 And when they had seen it, they made known abroad the saying which was told them concerning this child.

Luke 2:18 And all they that heard it wondered at those things which were told them by the shepherds.

Luke 2:19 But Mary kept all these things, and pondered them in her heart.

Luke 2:20 And the shepherds returned, glorifying and praising God for all the things that they had heard and seen, as it was told unto them.

Luke 2:21 And when eight days were accomplished for the circumcising of the child, his name was called Jesus, which was so named of the angel before he was conceived in the womb.

Luke 2:22 And when the days of her purification according to the law of Moses were accomplished, they brought him to Jerusalem, to present him to the Lord;

Luke 2:23 (As it is written in the law of the Lord, Every male that openeth the womb shall be called holy to the Lord;)

Luke 2:24 And to offer a sacrifice according to that which is said in the law of the Lord, A pair of turtledoves, or two young pigeons.

Luke 2:25 And, behold, there was a man in Jerusalem, whose name was Simeon; and the same man was just and devout, waiting for the consolation of Israel: and the Holy Ghost was upon him.

Luke 2:26 And it was revealed unto him by the Holy Ghost, that he should not see death, before he had seen the Lord’s Christ.

Luke 2:27 And he came by the Spirit into the temple: and when the parents brought in the child Jesus, to do for him after the custom of the law,

Luke 2:28 Then took he him up in his arms, and blessed God, and said,

Luke 2:29 Lord, now lettest thou thy servant depart in peace, according to thy word:

Luke 2:30 For mine eyes have seen thy salvation,

Luke 2:31 Which thou hast prepared before the face of all people;

Luke 2:32 A light to lighten the Gentiles, and the glory of thy people Israel.

Luke 2:33 And Joseph and his mother marvelled at those things which were spoken of him.

Luke 2:34 And Simeon blessed them, and said unto Mary his mother, Behold, this child is set for the fall and rising again of many in Israel; and for a sign which shall be spoken against;

Luke 2:35 (Yea, a sword shall pierce through thy own soul also,) that the thoughts of many hearts may be revealed.

Luke 2:36 And there was one Anna, a prophetess, the daughter of Phanuel, of the tribe of Aser: she was of a great age, and had lived with an husband seven years from her virginity;

Luke 2:37 And she was a widow of about fourscore and four years, which departed not from the temple, but served God with fastings and prayers night and day.

Luke 2:38 And she coming in that instant gave thanks likewise unto the Lord, and spake of him to all them that looked for redemption in Jerusalem.

Luke 2:39 And when they had performed all things according to the law of the Lord, they returned into Galilee, to their own city Nazareth.

Luke 2:40 And the child grew, and waxed strong in spirit, filled with wisdom: and the grace of God was upon him.

Luke 2:41 Now his parents went to Jerusalem every year at the feast of the passover.

Luke 2:42 And when he was twelve years old, they went up to Jerusalem after the custom of the feast.

Luke 2:43 And when they had fulfilled the days, as they returned, the child Jesus tarried behind in Jerusalem; and Joseph and his mother knew not of it.

Luke 2:44 But they, supposing him to have been in the company, went a day’s journey; and they sought him among their kinsfolk and acquaintance.

Luke 2:45 And when they found him not, they turned back again to Jerusalem, seeking him.

Luke 2:46 And it came to pass, that after three days they found him in the temple, sitting in the midst of the doctors, both hearing them, and asking them questions.

Luke 2:47 And all that heard him were astonished at his understanding and answers.

Luke 2:48 And when they saw him, they were amazed: and his mother said unto him, Son, why hast thou thus dealt with us? behold, thy father and I have sought thee sorrowing.

Luke 2:49 And he said unto them, How is it that ye sought me? wist ye not that I must be about my Father’s business?

Luke 2:50 And they understood not the saying which he spake unto them.

Luke 2:51 And he went down with them, and came to Nazareth, and was subject unto them: but his mother kept all these sayings in her heart.

Luke 2:52 And Jesus increased in wisdom and stature, and in favour with God and man.
