# John 21

John 21 (summary): Jesus appears to the disciples at the sea of Tiberias—He says, Feed my sheep—He foretells Peter’s martyrdom and that John will not die.

John 21:1 After these things Jesus shewed himself again to the disciples at the sea of Tiberias; and on this wise shewed he himself.

John 21:2 There were together Simon Peter, and Thomas called Didymus, and Nathanael of Cana in Galilee, and the sons of Zebedee, and two other of his disciples.

John 21:3 Simon Peter saith unto them, I go a fishing. They say unto him, We also go with thee. They went forth, and entered into a ship immediately; and that night they caught nothing.

John 21:4 But when the morning was now come, Jesus stood on the shore: but the disciples knew not that it was Jesus.

John 21:5 Then Jesus saith unto them, Children, have ye any meat? They answered him, No.

John 21:6 And he said unto them, Cast the net on the right side of the ship, and ye shall find. They cast therefore, and now they were not able to draw it for the multitude of fishes.

John 21:7 Therefore that disciple whom Jesus loved saith unto Peter, It is the Lord. Now when Simon Peter heard that it was the Lord, he girt his fisher’s coat unto him, (for he was naked,) and did cast himself into the sea.

John 21:8 And the other disciples came in a little ship; (for they were not far from land, but as it were two hundred cubits,) dragging the net with fishes.

John 21:9 As soon then as they were come to land, they saw a fire of coals there, and fish laid thereon, and bread.

John 21:10 Jesus saith unto them, Bring of the fish which ye have now caught.

John 21:11 Simon Peter went up, and drew the net to land full of great fishes, an hundred and fifty and three: and for all there were so many, yet was not the net broken.

John 21:12 Jesus saith unto them, Come and dine. And none of the disciples durst ask him, Who art thou? knowing that it was the Lord.

John 21:13 Jesus then cometh, and taketh bread, and giveth them, and fish likewise.

John 21:14 This is now the third time that Jesus shewed himself to his disciples, after that he was risen from the dead.

John 21:15 So when they had dined, Jesus saith to Simon Peter, Simon, son of Jonas, lovest thou me more than these? He saith unto him, Yea, Lord; thou knowest that I love thee. He saith unto him, Feed my lambs.

John 21:16 He saith to him again the second time, Simon, son of Jonas, lovest thou me? He saith unto him, Yea, Lord; thou knowest that I love thee. He saith unto him, Feed my sheep.

John 21:17 He saith unto him the third time, Simon, son of Jonas, lovest thou me? Peter was grieved because he said unto him the third time, Lovest thou me? And he said unto him, Lord, thou knowest all things; thou knowest that I love thee. Jesus saith unto him, Feed my sheep.

John 21:18 Verily, verily, I say unto thee, When thou wast young, thou girdedst thyself, and walkedst whither thou wouldest: but when thou shalt be old, thou shalt stretch forth thy hands, and another shall gird thee, and carry thee whither thou wouldest not.

John 21:19 This spake he, signifying by what death he should glorify God. And when he had spoken this, he saith unto him, Follow me.

John 21:20 Then Peter, turning about, seeth the disciple whom Jesus loved following; which also leaned on his breast at supper, and said, Lord, which is he that betrayeth thee?

John 21:21 Peter seeing him saith to Jesus, Lord, and what shall this man do?

John 21:22 Jesus saith unto him, If I will that he tarry till I come, what is that to thee? follow thou me.

John 21:23 Then went this saying abroad among the brethren, that that disciple should not die: yet Jesus said not unto him, He shall not die; but, If I will that he tarry till I come, what is that to thee?

John 21:24 This is the disciple which testifieth of these things, and wrote these things: and we know that his testimony is true.

John 21:25 And there are also many other things which Jesus did, the which, if they should be written every one, I suppose that even the world itself could not contain the books that should be written. Amen.
