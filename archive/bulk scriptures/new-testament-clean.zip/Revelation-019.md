# Revelation 19

Revelation 19 (summary): The marriage supper of the Lamb is made ready—The testimony of Jesus is the spirit of prophecy—Christ is King of Kings and Lord of Lords.

Revelation 19:1 And after these things I heard a great voice of much people in heaven, saying, Alleluia; Salvation, and glory, and honour, and power, unto the Lord our God:

Revelation 19:2 For true and righteous are his judgments: for he hath judged the great whore, which did corrupt the earth with her fornication, and hath avenged the blood of his servants at her hand.

Revelation 19:3 And again they said, Alleluia. And her smoke rose up for ever and ever.

Revelation 19:4 And the four and twenty elders and the four beasts fell down and worshipped God that sat on the throne, saying, Amen; Alleluia.

Revelation 19:5 And a voice came out of the throne, saying, Praise our God, all ye his servants, and ye that fear him, both small and great.

Revelation 19:6 And I heard as it were the voice of a great multitude, and as the voice of many waters, and as the voice of mighty thunderings, saying, Alleluia: for the Lord God omnipotent reigneth.

Revelation 19:7 Let us be glad and rejoice, and give honour to him: for the marriage of the Lamb is come, and his wife hath made herself ready.

Revelation 19:8 And to her was granted that she should be arrayed in fine linen, clean and white: for the fine linen is the righteousness of saints.

Revelation 19:9 And he saith unto me, Write, Blessed are they which are called unto the marriage supper of the Lamb. And he saith unto me, These are the true sayings of God.

Revelation 19:10 And I fell at his feet to worship him. And he said unto me, See thou do it not: I am thy fellowservant, and of thy brethren that have the testimony of Jesus: worship God: for the testimony of Jesus is the spirit of prophecy.

Revelation 19:11 And I saw heaven opened, and behold a white horse; and he that sat upon him was called Faithful and True, and in righteousness he doth judge and make war.

Revelation 19:12 His eyes were as a flame of fire, and on his head were many crowns; and he had a name written, that no man knew, but he himself.

Revelation 19:13 And he was clothed with a vesture dipped in blood: and his name is called The Word of God.

Revelation 19:14 And the armies which were in heaven followed him upon white horses, clothed in fine linen, white and clean.

Revelation 19:15 And out of his mouth goeth a sharp sword, that with it he should smite the nations: and he shall rule them with a rod of iron: and he treadeth the winepress of the fierceness and wrath of Almighty God.

Revelation 19:16 And he hath on his vesture and on his thigh a name written, King of Kings, and Lord of Lords.

Revelation 19:17 And I saw an angel standing in the sun; and he cried with a loud voice, saying to all the fowls that fly in the midst of heaven, Come and gather yourselves together unto the supper of the great God;

Revelation 19:18 That ye may eat the flesh of kings, and the flesh of captains, and the flesh of mighty men, and the flesh of horses, and of them that sit on them, and the flesh of all men, both free and bond, both small and great.

Revelation 19:19 And I saw the beast, and the kings of the earth, and their armies, gathered together to make war against him that sat on the horse, and against his army.

Revelation 19:20 And the beast was taken, and with him the false prophet that wrought miracles before him, with which he deceived them that had received the mark of the beast, and them that worshipped his image. These both were cast alive into a lake of fire burning with brimstone.

Revelation 19:21 And the remnant were slain with the sword of him that sat upon the horse, which sword proceeded out of his mouth: and all the fowls were filled with their flesh.
