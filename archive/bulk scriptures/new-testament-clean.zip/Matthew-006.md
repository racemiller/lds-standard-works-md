# Matthew 6

Matthew 6 (summary): Jesus continues the Sermon on the Mount—He teaches the disciples the Lord’s Prayer—They are commanded to seek first the kingdom of God and His righteousness.

Matthew 6:1 Take heed that ye do not your alms before men, to be seen of them: otherwise ye have no reward of your Father which is in heaven.

Matthew 6:2 Therefore when thou doest thine alms, do not sound a trumpet before thee, as the hypocrites do in the synagogues and in the streets, that they may have glory of men. Verily I say unto you, They have their reward.

Matthew 6:3 But when thou doest alms, let not thy left hand know what thy right hand doeth:

Matthew 6:4 That thine alms may be in secret: and thy Father which seeth in secret himself shall reward thee openly.

Matthew 6:5 And when thou prayest, thou shalt not be as the hypocrites are: for they love to pray standing in the synagogues and in the corners of the streets, that they may be seen of men. Verily I say unto you, They have their reward.

Matthew 6:6 But thou, when thou prayest, enter into thy closet, and when thou hast shut thy door, pray to thy Father which is in secret; and thy Father which seeth in secret shall reward thee openly.

Matthew 6:7 But when ye pray, use not vain repetitions, as the heathen do: for they think that they shall be heard for their much speaking.

Matthew 6:8 Be not ye therefore like unto them: for your Father knoweth what things ye have need of, before ye ask him.

Matthew 6:9 After this manner therefore pray ye: Our Father which art in heaven, Hallowed be thy name.

Matthew 6:10 Thy kingdom come. Thy will be done in earth, as it is in heaven.

Matthew 6:11 Give us this day our daily bread.

Matthew 6:12 And forgive us our debts, as we forgive our debtors.

Matthew 6:13 And lead us not into temptation, but deliver us from evil: For thine is the kingdom, and the power, and the glory, for ever. Amen.

Matthew 6:14 For if ye forgive men their trespasses, your heavenly Father will also forgive you:

Matthew 6:15 But if ye forgive not men their trespasses, neither will your Father forgive your trespasses.

Matthew 6:16 Moreover when ye fast, be not, as the hypocrites, of a sad countenance: for they disfigure their faces, that they may appear unto men to fast. Verily I say unto you, They have their reward.

Matthew 6:17 But thou, when thou fastest, anoint thine head, and wash thy face;

Matthew 6:18 That thou appear not unto men to fast, but unto thy Father which is in secret: and thy Father, which seeth in secret, shall reward thee openly.

Matthew 6:19 Lay not up for yourselves treasures upon earth, where moth and rust doth corrupt, and where thieves break through and steal:

Matthew 6:20 But lay up for yourselves treasures in heaven, where neither moth nor rust doth corrupt, and where thieves do not break through nor steal:

Matthew 6:21 For where your treasure is, there will your heart be also.

Matthew 6:22 The light of the body is the eye: if therefore thine eye be single, thy whole body shall be full of light.

Matthew 6:23 But if thine eye be evil, thy whole body shall be full of darkness. If therefore the light that is in thee be darkness, how great is that darkness!

Matthew 6:24 No man can serve two masters: for either he will hate the one, and love the other; or else he will hold to the one, and despise the other. Ye cannot serve God and mammon.

Matthew 6:25 Therefore I say unto you, Take no thought for your life, what ye shall eat, or what ye shall drink; nor yet for your body, what ye shall put on. Is not the life more than meat, and the body than raiment?

Matthew 6:26 Behold the fowls of the air: for they sow not, neither do they reap, nor gather into barns; yet your heavenly Father feedeth them. Are ye not much better than they?

Matthew 6:27 Which of you by taking thought can add one cubit unto his stature?

Matthew 6:28 And why take ye thought for raiment? Consider the lilies of the field, how they grow; they toil not, neither do they spin:

Matthew 6:29 And yet I say unto you, That even Solomon in all his glory was not arrayed like one of these.

Matthew 6:30 Wherefore, if God so clothe the grass of the field, which to day is, and to morrow is cast into the oven, shall he not much more clothe you, O ye of little faith?

Matthew 6:31 Therefore take no thought, saying, What shall we eat? or, What shall we drink? or, Wherewithal shall we be clothed?

Matthew 6:32 (For after all these things do the Gentiles seek:) for your heavenly Father knoweth that ye have need of all these things.

Matthew 6:33 But seek ye first the kingdom of God, and his righteousness; and all these things shall be added unto you.

Matthew 6:34 Take therefore no thought for the morrow: for the morrow shall take thought for the things of itself. Sufficient unto the day is the evil thereof.
