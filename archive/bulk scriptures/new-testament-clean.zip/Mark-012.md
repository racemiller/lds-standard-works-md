# Mark 12

Mark 12 (summary): Jesus gives the parable of the wicked husbandmen—He speaks of paying taxes, celestial marriage, the two great commandments, the divine sonship of Christ, and the widow’s mites.

Mark 12:1 And he began to speak unto them by parables. A certain man planted a vineyard, and set an hedge about it, and digged a place for the winefat, and built a tower, and let it out to husbandmen, and went into a far country.

Mark 12:2 And at the season he sent to the husbandmen a servant, that he might receive from the husbandmen of the fruit of the vineyard.

Mark 12:3 And they caught him, and beat him, and sent him away empty.

Mark 12:4 And again he sent unto them another servant; and at him they cast stones, and wounded him in the head, and sent him away shamefully handled.

Mark 12:5 And again he sent another; and him they killed, and many others; beating some, and killing some.

Mark 12:6 Having yet therefore one son, his wellbeloved, he sent him also last unto them, saying, They will reverence my son.

Mark 12:7 But those husbandmen said among themselves, This is the heir; come, let us kill him, and the inheritance shall be ours.

Mark 12:8 And they took him, and killed him, and cast him out of the vineyard.

Mark 12:9 What shall therefore the lord of the vineyard do? he will come and destroy the husbandmen, and will give the vineyard unto others.

Mark 12:10 And have ye not read this scripture; The stone which the builders rejected is become the head of the corner:

Mark 12:11 This was the Lord’s doing, and it is marvellous in our eyes?

Mark 12:12 And they sought to lay hold on him, but feared the people: for they knew that he had spoken the parable against them: and they left him, and went their way.

Mark 12:13 And they send unto him certain of the Pharisees and of the Herodians, to catch him in his words.

Mark 12:14 And when they were come, they say unto him, Master, we know that thou art true, and carest for no man: for thou regardest not the person of men, but teachest the way of God in truth: Is it lawful to give tribute to Cæsar, or not?

Mark 12:15 Shall we give, or shall we not give? But he, knowing their hypocrisy, said unto them, Why tempt ye me? bring me a penny, that I may see it.

Mark 12:16 And they brought it. And he saith unto them, Whose is this image and superscription? And they said unto him, Cæsar’s.

Mark 12:17 And Jesus answering said unto them, Render to Cæsar the things that are Cæsar’s, and to God the things that are God’s. And they marvelled at him.

Mark 12:18 Then come unto him the Sadducees, which say there is no resurrection; and they asked him, saying,

Mark 12:19 Master, Moses wrote unto us, If a man’s brother die, and leave his wife behind him, and leave no children, that his brother should take his wife, and raise up seed unto his brother.

Mark 12:20 Now there were seven brethren: and the first took a wife, and dying left no seed.

Mark 12:21 And the second took her, and died, neither left he any seed: and the third likewise.

Mark 12:22 And the seven had her, and left no seed: last of all the woman died also.

Mark 12:23 In the resurrection therefore, when they shall rise, whose wife shall she be of them? for the seven had her to wife.

Mark 12:24 And Jesus answering said unto them, Do ye not therefore err, because ye know not the scriptures, neither the power of God?

Mark 12:25 For when they shall rise from the dead, they neither marry, nor are given in marriage; but are as the angels which are in heaven.

Mark 12:26 And as touching the dead, that they rise: have ye not read in the book of Moses, how in the bush God spake unto him, saying, I am the God of Abraham, and the God of Isaac, and the God of Jacob?

Mark 12:27 He is not the God of the dead, but the God of the living: ye therefore do greatly err.

Mark 12:28 And one of the scribes came, and having heard them reasoning together, and perceiving that he had answered them well, asked him, Which is the first commandment of all?

Mark 12:29 And Jesus answered him, The first of all the commandments is, Hear, O Israel; The Lord our God is one Lord:

Mark 12:30 And thou shalt love the Lord thy God with all thy heart, and with all thy soul, and with all thy mind, and with all thy strength: this is the first commandment.

Mark 12:31 And the second is like, namely this, Thou shalt love thy neighbour as thyself. There is none other commandment greater than these.

Mark 12:32 And the scribe said unto him, Well, Master, thou hast said the truth: for there is one God; and there is none other but he:

Mark 12:33 And to love him with all the heart, and with all the understanding, and with all the soul, and with all the strength, and to love his neighbour as himself, is more than all whole burnt offerings and sacrifices.

Mark 12:34 And when Jesus saw that he answered discreetly, he said unto him, Thou art not far from the kingdom of God. And no man after that durst ask him any question.

Mark 12:35 And Jesus answered and said, while he taught in the temple, How say the scribes that Christ is the Son of David?

Mark 12:36 For David himself said by the Holy Ghost, The Lord said to my Lord, Sit thou on my right hand, till I make thine enemies thy footstool.

Mark 12:37 David therefore himself calleth him Lord; and whence is he then his son? And the common people heard him gladly.

Mark 12:38 And he said unto them in his doctrine, Beware of the scribes, which love to go in long clothing, and love salutations in the marketplaces,

Mark 12:39 And the chief seats in the synagogues, and the uppermost rooms at feasts:

Mark 12:40 Which devour widows’ houses, and for a pretence make long prayers: these shall receive greater damnation.

Mark 12:41 And Jesus sat over against the treasury, and beheld how the people cast money into the treasury: and many that were rich cast in much.

Mark 12:42 And there came a certain poor widow, and she threw in two mites, which make a farthing.

Mark 12:43 And he called unto him his disciples, and saith unto them, Verily I say unto you, That this poor widow hath cast more in, than all they which have cast into the treasury:

Mark 12:44 For all they did cast in of their abundance; but she of her want did cast in all that she had, even all her living.
