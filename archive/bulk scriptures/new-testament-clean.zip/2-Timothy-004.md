# 2 Timothy 4

2 Timothy 4 (summary): Paul gives a solemn charge to preach the gospel in a day of apostasy—Paul and all Saints are assured of exaltation.

2 Timothy 4:1 I charge thee therefore before God, and the Lord Jesus Christ, who shall judge the quick and the dead at his appearing and his kingdom;

2 Timothy 4:2 Preach the word; be instant in season, out of season; reprove, rebuke, exhort with all longsuffering and doctrine.

2 Timothy 4:3 For the time will come when they will not endure sound doctrine; but after their own lusts shall they heap to themselves teachers, having itching ears;

2 Timothy 4:4 And they shall turn away their ears from the truth, and shall be turned unto fables.

2 Timothy 4:5 But watch thou in all things, endure afflictions, do the work of an evangelist, make full proof of thy ministry.

2 Timothy 4:6 For I am now ready to be offered, and the time of my departure is at hand.

2 Timothy 4:7 I have fought a good fight, I have finished my course, I have kept the faith:

2 Timothy 4:8 Henceforth there is laid up for me a crown of righteousness, which the Lord, the righteous judge, shall give me at that day: and not to me only, but unto all them also that love his appearing.

2 Timothy 4:9 Do thy diligence to come shortly unto me:

2 Timothy 4:10 For Demas hath forsaken me, having loved this present world, and is departed unto Thessalonica; Crescens to Galatia, Titus unto Dalmatia.

2 Timothy 4:11 Only Luke is with me. Take Mark, and bring him with thee: for he is profitable to me for the ministry.

2 Timothy 4:12 And Tychicus have I sent to Ephesus.

2 Timothy 4:13 The cloak that I left at Troas with Carpus, when thou comest, bring with thee, and the books, but especially the parchments.

2 Timothy 4:14 Alexander the coppersmith did me much evil: the Lord reward him according to his works:

2 Timothy 4:15 Of whom be thou ware also; for he hath greatly withstood our words.

2 Timothy 4:16 At my first answer no man stood with me, but all men forsook me: I pray God that it may not be laid to their charge.

2 Timothy 4:17 Notwithstanding the Lord stood with me, and strengthened me; that by me the preaching might be fully known, and that all the Gentiles might hear: and I was delivered out of the mouth of the lion.

2 Timothy 4:18 And the Lord shall deliver me from every evil work, and will preserve me unto his heavenly kingdom: to whom be glory for ever and ever. Amen.

2 Timothy 4:19 Salute Prisca and Aquila, and the household of Onesiphorus.

2 Timothy 4:20 Erastus abode at Corinth: but Trophimus have I left at Miletum sick.

2 Timothy 4:21 Do thy diligence to come before winter. Eubulus greeteth thee, and Pudens, and Linus, and Claudia, and all the brethren.

2 Timothy 4:22 The Lord Jesus Christ be with thy spirit. Grace be with you. Amen.
