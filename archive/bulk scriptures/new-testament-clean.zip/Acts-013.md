# Acts 13

Acts 13 (summary): Saul and Barnabas are called to missionary service—Saul, now called Paul, curses a sorcerer—Christ is a descendant of David—Paul offers the gospel to Israel, then to the Gentiles.

Acts 13:1 Now there were in the church that was at Antioch certain prophets and teachers; as Barnabas, and Simeon that was called Niger, and Lucius of Cyrene, and Manaen, which had been brought up with Herod the tetrarch, and Saul.

Acts 13:2 As they ministered to the Lord, and fasted, the Holy Ghost said, Separate me Barnabas and Saul for the work whereunto I have called them.

Acts 13:3 And when they had fasted and prayed, and laid their hands on them, they sent them away.

Acts 13:4 So they, being sent forth by the Holy Ghost, departed unto Seleucia; and from thence they sailed to Cyprus.

Acts 13:5 And when they were at Salamis, they preached the word of God in the synagogues of the Jews: and they had also John to their minister.

Acts 13:6 And when they had gone through the isle unto Paphos, they found a certain sorcerer, a false prophet, a Jew, whose name was Bar-jesus:

Acts 13:7 Which was with the deputy of the country, Sergius Paulus, a prudent man; who called for Barnabas and Saul, and desired to hear the word of God.

Acts 13:8 But Elymas the sorcerer (for so is his name by interpretation) withstood them, seeking to turn away the deputy from the faith.

Acts 13:9 Then Saul, (who also is called Paul,) filled with the Holy Ghost, set his eyes on him,

Acts 13:10 And said, O full of all subtilty and all mischief, thou child of the devil, thou enemy of all righteousness, wilt thou not cease to pervert the right ways of the Lord?

Acts 13:11 And now, behold, the hand of the Lord is upon thee, and thou shalt be blind, not seeing the sun for a season. And immediately there fell on him a mist and a darkness; and he went about seeking some to lead him by the hand.

Acts 13:12 Then the deputy, when he saw what was done, believed, being astonished at the doctrine of the Lord.

Acts 13:13 Now when Paul and his company loosed from Paphos, they came to Perga in Pamphylia: and John departing from them returned to Jerusalem.

Acts 13:14 But when they departed from Perga, they came to Antioch in Pisidia, and went into the synagogue on the sabbath day, and sat down.

Acts 13:15 And after the reading of the law and the prophets the rulers of the synagogue sent unto them, saying, Ye men and brethren, if ye have any word of exhortation for the people, say on.

Acts 13:16 Then Paul stood up, and beckoning with his hand said, Men of Israel, and ye that fear God, give audience.

Acts 13:17 The God of this people of Israel chose our fathers, and exalted the people when they dwelt as strangers in the land of Egypt, and with an high arm brought he them out of it.

Acts 13:18 And about the time of forty years suffered he their manners in the wilderness.

Acts 13:19 And when he had destroyed seven nations in the land of Chanaan, he divided their land to them by lot.

Acts 13:20 And after that he gave unto them judges about the space of four hundred and fifty years, until Samuel the prophet.

Acts 13:21 And afterward they desired a king: and God gave unto them Saul the son of Cis, a man of the tribe of Benjamin, by the space of forty years.

Acts 13:22 And when he had removed him, he raised up unto them David to be their king; to whom also he gave testimony, and said, I have found David the son of Jesse, a man after mine own heart, which shall fulfil all my will.

Acts 13:23 Of this man’s seed hath God according to his promise raised unto Israel a Saviour, Jesus:

Acts 13:24 When John had first preached before his coming the baptism of repentance to all the people of Israel.

Acts 13:25 And as John fulfilled his course, he said, Whom think ye that I am? I am not he. But, behold, there cometh one after me, whose shoes of his feet I am not worthy to loose.

Acts 13:26 Men and brethren, children of the stock of Abraham, and whosoever among you feareth God, to you is the word of this salvation sent.

Acts 13:27 For they that dwell at Jerusalem, and their rulers, because they knew him not, nor yet the voices of the prophets which are read every sabbath day, they have fulfilled them in condemning him.

Acts 13:28 And though they found no cause of death in him, yet desired they Pilate that he should be slain.

Acts 13:29 And when they had fulfilled all that was written of him, they took him down from the tree, and laid him in a sepulchre.

Acts 13:30 But God raised him from the dead:

Acts 13:31 And he was seen many days of them which came up with him from Galilee to Jerusalem, who are his witnesses unto the people.

Acts 13:32 And we declare unto you glad tidings, how that the promise which was made unto the fathers,

Acts 13:33 God hath fulfilled the same unto us their children, in that he hath raised up Jesus again; as it is also written in the second psalm, Thou art my Son, this day have I begotten thee.

Acts 13:34 And as concerning that he raised him up from the dead, now no more to return to corruption, he said on this wise, I will give you the sure mercies of David.

Acts 13:35 Wherefore he saith also in another psalm, Thou shalt not suffer thine Holy One to see corruption.

Acts 13:36 For David, after he had served his own generation by the will of God, fell on sleep, and was laid unto his fathers, and saw corruption:

Acts 13:37 But he, whom God raised again, saw no corruption.

Acts 13:38 Be it known unto you therefore, men and brethren, that through this man is preached unto you the forgiveness of sins:

Acts 13:39 And by him all that believe are justified from all things, from which ye could not be justified by the law of Moses.

Acts 13:40 Beware therefore, lest that come upon you, which is spoken of in the prophets;

Acts 13:41 Behold, ye despisers, and wonder, and perish: for I work a work in your days, a work which ye shall in no wise believe, though a man declare it unto you.

Acts 13:42 And when the Jews were gone out of the synagogue, the Gentiles besought that these words might be preached to them the next sabbath.

Acts 13:43 Now when the congregation was broken up, many of the Jews and religious proselytes followed Paul and Barnabas: who, speaking to them, persuaded them to continue in the grace of God.

Acts 13:44 And the next sabbath day came almost the whole city together to hear the word of God.

Acts 13:45 But when the Jews saw the multitudes, they were filled with envy, and spake against those things which were spoken by Paul, contradicting and blaspheming.

Acts 13:46 Then Paul and Barnabas waxed bold, and said, It was necessary that the word of God should first have been spoken to you: but seeing ye put it from you, and judge yourselves unworthy of everlasting life, lo, we turn to the Gentiles.

Acts 13:47 For so hath the Lord commanded us, saying, I have set thee to be a light of the Gentiles, that thou shouldest be for salvation unto the ends of the earth.

Acts 13:48 And when the Gentiles heard this, they were glad, and glorified the word of the Lord: and as many as were ordained to eternal life believed.

Acts 13:49 And the word of the Lord was published throughout all the region.

Acts 13:50 But the Jews stirred up the devout and honourable women, and the chief men of the city, and raised persecution against Paul and Barnabas, and expelled them out of their coasts.

Acts 13:51 But they shook off the dust of their feet against them, and came unto Iconium.

Acts 13:52 And the disciples were filled with joy, and with the Holy Ghost.
