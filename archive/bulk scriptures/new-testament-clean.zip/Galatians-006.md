# Galatians 6

Galatians 6 (summary): Bear one another’s burdens—As you sow, so shall you reap—Be not weary in well-doing.

Galatians 6:1 Brethren, if a man be overtaken in a fault, ye which are spiritual, restore such an one in the spirit of meekness; considering thyself, lest thou also be tempted.

Galatians 6:2 Bear ye one another’s burdens, and so fulfil the law of Christ.

Galatians 6:3 For if a man think himself to be something, when he is nothing, he deceiveth himself.

Galatians 6:4 But let every man prove his own work, and then shall he have rejoicing in himself alone, and not in another.

Galatians 6:5 For every man shall bear his own burden.

Galatians 6:6 Let him that is taught in the word communicate unto him that teacheth in all good things.

Galatians 6:7 Be not deceived; God is not mocked: for whatsoever a man soweth, that shall he also reap.

Galatians 6:8 For he that soweth to his flesh shall of the flesh reap corruption; but he that soweth to the Spirit shall of the Spirit reap life everlasting.

Galatians 6:9 And let us not be weary in well doing: for in due season we shall reap, if we faint not.

Galatians 6:10 As we have therefore opportunity, let us do good unto all men, especially unto them who are of the household of faith.

Galatians 6:11 Ye see how large a letter I have written unto you with mine own hand.

Galatians 6:12 As many as desire to make a fair shew in the flesh, they constrain you to be circumcised; only lest they should suffer persecution for the cross of Christ.

Galatians 6:13 For neither they themselves who are circumcised keep the law; but desire to have you circumcised, that they may glory in your flesh.

Galatians 6:14 But God forbid that I should glory, save in the cross of our Lord Jesus Christ, by whom the world is crucified unto me, and I unto the world.

Galatians 6:15 For in Christ Jesus neither circumcision availeth any thing, nor uncircumcision, but a new creature.

Galatians 6:16 And as many as walk according to this rule, peace be on them, and mercy, and upon the Israel of God.

Galatians 6:17 From henceforth let no man trouble me: for I bear in my body the marks of the Lord Jesus.

Galatians 6:18 Brethren, the grace of our Lord Jesus Christ be with your spirit. Amen.
