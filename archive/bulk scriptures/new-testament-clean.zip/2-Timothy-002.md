# 2 Timothy 2

2 Timothy 2 (summary): Christ gives eternal glory to the elect—Shun contention and seek godliness.

2 Timothy 2:1 Thou therefore, my son, be strong in the grace that is in Christ Jesus.

2 Timothy 2:2 And the things that thou hast heard of me among many witnesses, the same commit thou to faithful men, who shall be able to teach others also.

2 Timothy 2:3 Thou therefore endure hardness, as a good soldier of Jesus Christ.

2 Timothy 2:4 No man that warreth entangleth himself with the affairs of this life; that he may please him who hath chosen him to be a soldier.

2 Timothy 2:5 And if a man also strive for masteries, yet is he not crowned, except he strive lawfully.

2 Timothy 2:6 The husbandman that laboureth must be first partaker of the fruits.

2 Timothy 2:7 Consider what I say; and the Lord give thee understanding in all things.

2 Timothy 2:8 Remember that Jesus Christ of the seed of David was raised from the dead according to my gospel:

2 Timothy 2:9 Wherein I suffer trouble, as an evil doer, even unto bonds; but the word of God is not bound.

2 Timothy 2:10 Therefore I endure all things for the elect’s sakes, that they may also obtain the salvation which is in Christ Jesus with eternal glory.

2 Timothy 2:11 It is a faithful saying: For if we be dead with him, we shall also live with him:

2 Timothy 2:12 If we suffer, we shall also reign with him: if we deny him, he also will deny us:

2 Timothy 2:13 If we believe not, yet he abideth faithful: he cannot deny himself.

2 Timothy 2:14 Of these things put them in remembrance, charging them before the Lord that they strive not about words to no profit, but to the subverting of the hearers.

2 Timothy 2:15 Study to shew thyself approved unto God, a workman that needeth not to be ashamed, rightly dividing the word of truth.

2 Timothy 2:16 But shun profane and vain babblings: for they will increase unto more ungodliness.

2 Timothy 2:17 And their word will eat as doth a canker: of whom is Hymenæus and Philetus;

2 Timothy 2:18 Who concerning the truth have erred, saying that the resurrection is past already; and overthrow the faith of some.

2 Timothy 2:19 Nevertheless the foundation of God standeth sure, having this seal, The Lord knoweth them that are his. And, Let every one that nameth the name of Christ depart from iniquity.

2 Timothy 2:20 But in a great house there are not only vessels of gold and of silver, but also of wood and of earth; and some to honour, and some to dishonour.

2 Timothy 2:21 If a man therefore purge himself from these, he shall be a vessel unto honour, sanctified, and meet for the master’s use, and prepared unto every good work.

2 Timothy 2:22 Flee also youthful lusts: but follow righteousness, faith, charity, peace, with them that call on the Lord out of a pure heart.

2 Timothy 2:23 But foolish and unlearned questions avoid, knowing that they do gender strifes.

2 Timothy 2:24 And the servant of the Lord must not strive; but be gentle unto all men, apt to teach, patient,

2 Timothy 2:25 In meekness instructing those that oppose themselves; if God peradventure will give them repentance to the acknowledging of the truth;

2 Timothy 2:26 And that they may recover themselves out of the snare of the devil, who are taken captive by him at his will.
