# Luke 4

Luke 4 (summary): Jesus fasts forty days and is tempted by the devil—Jesus announces His divine sonship in Nazareth and is rejected—He casts out a devil in Capernaum, heals Peter’s mother-in-law, and preaches and heals throughout Galilee.

Luke 4:1 And Jesus being full of the Holy Ghost returned from Jordan, and was led by the Spirit into the wilderness,

Luke 4:2 Being forty days tempted of the devil. And in those days he did eat nothing: and when they were ended, he afterward hungered.

Luke 4:3 And the devil said unto him, If thou be the Son of God, command this stone that it be made bread.

Luke 4:4 And Jesus answered him, saying, It is written, That man shall not live by bread alone, but by every word of God.

Luke 4:5 And the devil, taking him up into an high mountain, shewed unto him all the kingdoms of the world in a moment of time.

Luke 4:6 And the devil said unto him, All this power will I give thee, and the glory of them: for that is delivered unto me; and to whomsoever I will I give it.

Luke 4:7 If thou therefore wilt worship me, all shall be thine.

Luke 4:8 And Jesus answered and said unto him, Get thee behind me, Satan: for it is written, Thou shalt worship the Lord thy God, and him only shalt thou serve.

Luke 4:9 And he brought him to Jerusalem, and set him on a pinnacle of the temple, and said unto him, If thou be the Son of God, cast thyself down from hence:

Luke 4:10 For it is written, He shall give his angels charge over thee, to keep thee:

Luke 4:11 And in their hands they shall bear thee up, lest at any time thou dash thy foot against a stone.

Luke 4:12 And Jesus answering said unto him, It is said, Thou shalt not tempt the Lord thy God.

Luke 4:13 And when the devil had ended all the temptation, he departed from him for a season.

Luke 4:14 And Jesus returned in the power of the Spirit into Galilee: and there went out a fame of him through all the region round about.

Luke 4:15 And he taught in their synagogues, being glorified of all.

Luke 4:16 And he came to Nazareth, where he had been brought up: and, as his custom was, he went into the synagogue on the sabbath day, and stood up for to read.

Luke 4:17 And there was delivered unto him the book of the prophet Esaias. And when he had opened the book, he found the place where it was written,

Luke 4:18 The Spirit of the Lord is upon me, because he hath anointed me to preach the gospel to the poor; he hath sent me to heal the brokenhearted, to preach deliverance to the captives, and recovering of sight to the blind, to set at liberty them that are bruised,

Luke 4:19 To preach the acceptable year of the Lord.

Luke 4:20 And he closed the book, and he gave it again to the minister, and sat down. And the eyes of all them that were in the synagogue were fastened on him.

Luke 4:21 And he began to say unto them, This day is this scripture fulfilled in your ears.

Luke 4:22 And all bare him witness, and wondered at the gracious words which proceeded out of his mouth. And they said, Is not this Joseph’s son?

Luke 4:23 And he said unto them, Ye will surely say unto me this proverb, Physician, heal thyself: whatsoever we have heard done in Capernaum, do also here in thy country.

Luke 4:24 And he said, Verily I say unto you, No prophet is accepted in his own country.

Luke 4:25 But I tell you of a truth, many widows were in Israel in the days of Elias, when the heaven was shut up three years and six months, when great famine was throughout all the land;

Luke 4:26 But unto none of them was Elias sent, save unto Sarepta, a city of Sidon, unto a woman that was a widow.

Luke 4:27 And many lepers were in Israel in the time of Eliseus the prophet; and none of them was cleansed, saving Naaman the Syrian.

Luke 4:28 And all they in the synagogue, when they heard these things, were filled with wrath,

Luke 4:29 And rose up, and thrust him out of the city, and led him unto the brow of the hill whereon their city was built, that they might cast him down headlong.

Luke 4:30 But he passing through the midst of them went his way,

Luke 4:31 And came down to Capernaum, a city of Galilee, and taught them on the sabbath days.

Luke 4:32 And they were astonished at his doctrine: for his word was with power.

Luke 4:33 And in the synagogue there was a man, which had a spirit of an unclean devil, and cried out with a loud voice,

Luke 4:34 Saying, Let us alone; what have we to do with thee, thou Jesus of Nazareth? art thou come to destroy us? I know thee who thou art; the Holy One of God.

Luke 4:35 And Jesus rebuked him, saying, Hold thy peace, and come out of him. And when the devil had thrown him in the midst, he came out of him, and hurt him not.

Luke 4:36 And they were all amazed, and spake among themselves, saying, What a word is this! for with authority and power he commandeth the unclean spirits, and they come out.

Luke 4:37 And the fame of him went out into every place of the country round about.

Luke 4:38 And he arose out of the synagogue, and entered into Simon’s house. And Simon’s wife’s mother was taken with a great fever; and they besought him for her.

Luke 4:39 And he stood over her, and rebuked the fever; and it left her: and immediately she arose and ministered unto them.

Luke 4:40 Now when the sun was setting, all they that had any sick with divers diseases brought them unto him; and he laid his hands on every one of them, and healed them.

Luke 4:41 And devils also came out of many, crying out, and saying, Thou art Christ the Son of God. And he rebuking them suffered them not to speak: for they knew that he was Christ.

Luke 4:42 And when it was day, he departed and went into a desert place: and the people sought him, and came unto him, and stayed him, that he should not depart from them.

Luke 4:43 And he said unto them, I must preach the kingdom of God to other cities also: for therefore am I sent.

Luke 4:44 And he preached in the synagogues of Galilee.
