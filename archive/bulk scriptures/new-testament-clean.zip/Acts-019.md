# Acts 19

Acts 19 (summary): Paul confers the gift of the Holy Ghost by the laying on of hands—He preaches and works many miracles—The sons of Sceva fail to cast out devils by exorcism—The worshippers of Diana (Artemis) raise a tumult against Paul.

Acts 19:1 And it came to pass, that, while Apollos was at Corinth, Paul having passed through the upper coasts came to Ephesus: and finding certain disciples,

Acts 19:2 He said unto them, Have ye received the Holy Ghost since ye believed? And they said unto him, We have not so much as heard whether there be any Holy Ghost.

Acts 19:3 And he said unto them, Unto what then were ye baptized? And they said, Unto John’s baptism.

Acts 19:4 Then said Paul, John verily baptized with the baptism of repentance, saying unto the people, that they should believe on him which should come after him, that is, on Christ Jesus.

Acts 19:5 When they heard this, they were baptized in the name of the Lord Jesus.

Acts 19:6 And when Paul had laid his hands upon them, the Holy Ghost came on them; and they spake with tongues, and prophesied.

Acts 19:7 And all the men were about twelve.

Acts 19:8 And he went into the synagogue, and spake boldly for the space of three months, disputing and persuading the things concerning the kingdom of God.

Acts 19:9 But when divers were hardened, and believed not, but spake evil of that way before the multitude, he departed from them, and separated the disciples, disputing daily in the school of one Tyrannus.

Acts 19:10 And this continued by the space of two years; so that all they which dwelt in Asia heard the word of the Lord Jesus, both Jews and Greeks.

Acts 19:11 And God wrought special miracles by the hands of Paul:

Acts 19:12 So that from his body were brought unto the sick handkerchiefs or aprons, and the diseases departed from them, and the evil spirits went out of them.

Acts 19:13 Then certain of the vagabond Jews, exorcists, took upon them to call over them which had evil spirits the name of the Lord Jesus, saying, We adjure you by Jesus whom Paul preacheth.

Acts 19:14 And there were seven sons of one Sceva, a Jew, and chief of the priests, which did so.

Acts 19:15 And the evil spirit answered and said, Jesus I know, and Paul I know; but who are ye?

Acts 19:16 And the man in whom the evil spirit was leaped on them, and overcame them, and prevailed against them, so that they fled out of that house naked and wounded.

Acts 19:17 And this was known to all the Jews and Greeks also dwelling at Ephesus; and fear fell on them all, and the name of the Lord Jesus was magnified.

Acts 19:18 And many that believed came, and confessed, and shewed their deeds.

Acts 19:19 Many of them also which used curious arts brought their books together, and burned them before all men: and they counted the price of them, and found it fifty thousand pieces of silver.

Acts 19:20 So mightily grew the word of God and prevailed.

Acts 19:21 After these things were ended, Paul purposed in the spirit, when he had passed through Macedonia and Achaia, to go to Jerusalem, saying, After I have been there, I must also see Rome.

Acts 19:22 So he sent into Macedonia two of them that ministered unto him, Timotheus and Erastus; but he himself stayed in Asia for a season.

Acts 19:23 And the same time there arose no small stir about that way.

Acts 19:24 For a certain man named Demetrius, a silversmith, which made silver shrines for Diana, brought no small gain unto the craftsmen;

Acts 19:25 Whom he called together with the workmen of like occupation, and said, Sirs, ye know that by this craft we have our wealth.

Acts 19:26 Moreover ye see and hear, that not alone at Ephesus, but almost throughout all Asia, this Paul hath persuaded and turned away much people, saying that they be no gods, which are made with hands:

Acts 19:27 So that not only this our craft is in danger to be set at nought; but also that the temple of the great goddess Diana should be despised, and her magnificence should be destroyed, whom all Asia and the world worshippeth.

Acts 19:28 And when they heard these sayings, they were full of wrath, and cried out, saying, Great is Diana of the Ephesians.

Acts 19:29 And the whole city was filled with confusion: and having caught Gaius and Aristarchus, men of Macedonia, Paul’s companions in travel, they rushed with one accord into the theatre.

Acts 19:30 And when Paul would have entered in unto the people, the disciples suffered him not.

Acts 19:31 And certain of the chief of Asia, which were his friends, sent unto him, desiring him that he would not adventure himself into the theatre.

Acts 19:32 Some therefore cried one thing, and some another: for the assembly was confused; and the more part knew not wherefore they were come together.

Acts 19:33 And they drew Alexander out of the multitude, the Jews putting him forward. And Alexander beckoned with the hand, and would have made his defence unto the people.

Acts 19:34 But when they knew that he was a Jew, all with one voice about the space of two hours cried out, Great is Diana of the Ephesians.

Acts 19:35 And when the townclerk had appeased the people, he said, Ye men of Ephesus, what man is there that knoweth not how that the city of the Ephesians is a worshipper of the great goddess Diana, and of the image which fell down from Jupiter?

Acts 19:36 Seeing then that these things cannot be spoken against, ye ought to be quiet, and to do nothing rashly.

Acts 19:37 For ye have brought hither these men, which are neither robbers of churches, nor yet blasphemers of your goddess.

Acts 19:38 Wherefore if Demetrius, and the craftsmen which are with him, have a matter against any man, the law is open, and there are deputies: let them implead one another.

Acts 19:39 But if ye inquire any thing concerning other matters, it shall be determined in a lawful assembly.

Acts 19:40 For we are in danger to be called in question for this day’s uproar, there being no cause whereby we may give an account of this concourse.

Acts 19:41 And when he had thus spoken, he dismissed the assembly.
