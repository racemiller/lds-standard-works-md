# 1 Peter 1

1 Peter 1 (summary): The trial of our faith precedes salvation—Christ was foreordained to be the Redeemer.

1 Peter 1:1 Peter, an apostle of Jesus Christ, to the strangers scattered throughout Pontus, Galatia, Cappadocia, Asia, and Bithynia,

1 Peter 1:2 Elect according to the foreknowledge of God the Father, through sanctification of the Spirit, unto obedience and sprinkling of the blood of Jesus Christ: Grace unto you, and peace, be multiplied.

1 Peter 1:3 Blessed be the God and Father of our Lord Jesus Christ, which according to his abundant mercy hath begotten us again unto a lively hope by the resurrection of Jesus Christ from the dead,

1 Peter 1:4 To an inheritance incorruptible, and undefiled, and that fadeth not away, reserved in heaven for you,

1 Peter 1:5 Who are kept by the power of God through faith unto salvation ready to be revealed in the last time.

1 Peter 1:6 Wherein ye greatly rejoice, though now for a season, if need be, ye are in heaviness through manifold temptations:

1 Peter 1:7 That the trial of your faith, being much more precious than of gold that perisheth, though it be tried with fire, might be found unto praise and honour and glory at the appearing of Jesus Christ:

1 Peter 1:8 Whom having not seen, ye love; in whom, though now ye see him not, yet believing, ye rejoice with joy unspeakable and full of glory:

1 Peter 1:9 Receiving the end of your faith, even the salvation of your souls.

1 Peter 1:10 Of which salvation the prophets have inquired and searched diligently, who prophesied of the grace that should come unto you:

1 Peter 1:11 Searching what, or what manner of time the Spirit of Christ which was in them did signify, when it testified beforehand the sufferings of Christ, and the glory that should follow.

1 Peter 1:12 Unto whom it was revealed, that not unto themselves, but unto us they did minister the things, which are now reported unto you by them that have preached the gospel unto you with the Holy Ghost sent down from heaven; which things the angels desire to look into.

1 Peter 1:13 Wherefore gird up the loins of your mind, be sober, and hope to the end for the grace that is to be brought unto you at the revelation of Jesus Christ;

1 Peter 1:14 As obedient children, not fashioning yourselves according to the former lusts in your ignorance:

1 Peter 1:15 But as he which hath called you is holy, so be ye holy in all manner of conversation;

1 Peter 1:16 Because it is written, Be ye holy; for I am holy.

1 Peter 1:17 And if ye call on the Father, who without respect of persons judgeth according to every man’s work, pass the time of your sojourning here in fear:

1 Peter 1:18 Forasmuch as ye know that ye were not redeemed with corruptible things, as silver and gold, from your vain conversation received by tradition from your fathers;

1 Peter 1:19 But with the precious blood of Christ, as of a lamb without blemish and without spot:

1 Peter 1:20 Who verily was foreordained before the foundation of the world, but was manifest in these last times for you,

1 Peter 1:21 Who by him do believe in God, that raised him up from the dead, and gave him glory; that your faith and hope might be in God.

1 Peter 1:22 Seeing ye have purified your souls in obeying the truth through the Spirit unto unfeigned love of the brethren, see that ye love one another with a pure heart fervently:

1 Peter 1:23 Being born again, not of corruptible seed, but of incorruptible, by the word of God, which liveth and abideth for ever.

1 Peter 1:24 For all flesh is as grass, and all the glory of man as the flower of grass. The grass withereth, and the flower thereof falleth away:

1 Peter 1:25 But the word of the Lord endureth for ever. And this is the word which by the gospel is preached unto you.
