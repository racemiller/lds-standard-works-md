# 1 Corinthians 9

1 Corinthians 9 (summary): Paul rejoices in his Christian liberty—He preaches the gospel to all without charge—He is all things to all men to gain converts.

1 Corinthians 9:1 Am I not an apostle? am I not free? have I not seen Jesus Christ our Lord? are not ye my work in the Lord?

1 Corinthians 9:2 If I be not an apostle unto others, yet doubtless I am to you: for the seal of mine apostleship are ye in the Lord.

1 Corinthians 9:3 Mine answer to them that do examine me is this,

1 Corinthians 9:4 Have we not power to eat and to drink?

1 Corinthians 9:5 Have we not power to lead about a sister, a wife, as well as other apostles, and as the brethren of the Lord, and Cephas?

1 Corinthians 9:6 Or I only and Barnabas, have not we power to forbear working?

1 Corinthians 9:7 Who goeth a warfare any time at his own charges? who planteth a vineyard, and eateth not of the fruit thereof? or who feedeth a flock, and eateth not of the milk of the flock?

1 Corinthians 9:8 Say I these things as a man? or saith not the law the same also?

1 Corinthians 9:9 For it is written in the law of Moses, Thou shalt not muzzle the mouth of the ox that treadeth out the corn. Doth God take care for oxen?

1 Corinthians 9:10 Or saith he it altogether for our sakes? For our sakes, no doubt, this is written: that he that ploweth should plow in hope; and that he that thresheth in hope should be partaker of his hope.

1 Corinthians 9:11 If we have sown unto you spiritual things, is it a great thing if we shall reap your carnal things?

1 Corinthians 9:12 If others be partakers of this power over you, are not we rather? Nevertheless we have not used this power; but suffer all things, lest we should hinder the gospel of Christ.

1 Corinthians 9:13 Do ye not know that they which minister about holy things live of the things of the temple? and they which wait at the altar are partakers with the altar?

1 Corinthians 9:14 Even so hath the Lord ordained that they which preach the gospel should live of the gospel.

1 Corinthians 9:15 But I have used none of these things: neither have I written these things, that it should be so done unto me: for it were better for me to die, than that any man should make my glorying void.

1 Corinthians 9:16 For though I preach the gospel, I have nothing to glory of: for necessity is laid upon me; yea, woe is unto me, if I preach not the gospel!

1 Corinthians 9:17 For if I do this thing willingly, I have a reward: but if against my will, a dispensation of the gospel is committed unto me.

1 Corinthians 9:18 What is my reward then? Verily that, when I preach the gospel, I may make the gospel of Christ without charge, that I abuse not my power in the gospel.

1 Corinthians 9:19 For though I be free from all men, yet have I made myself servant unto all, that I might gain the more.

1 Corinthians 9:20 And unto the Jews I became as a Jew, that I might gain the Jews; to them that are under the law, as under the law, that I might gain them that are under the law;

1 Corinthians 9:21 To them that are without law, as without law, (being not without law to God, but under the law to Christ,) that I might gain them that are without law.

1 Corinthians 9:22 To the weak became I as weak, that I might gain the weak: I am made all things to all men, that I might by all means save some.

1 Corinthians 9:23 And this I do for the gospel’s sake, that I might be partaker thereof with you.

1 Corinthians 9:24 Know ye not that they which run in a race run all, but one receiveth the prize? So run, that ye may obtain.

1 Corinthians 9:25 And every man that striveth for the mastery is temperate in all things. Now they do it to obtain a corruptible crown; but we an incorruptible.

1 Corinthians 9:26 I therefore so run, not as uncertainly; so fight I, not as one that beateth the air:

1 Corinthians 9:27 But I keep under my body, and bring it into subjection: lest that by any means, when I have preached to others, I myself should be a castaway.
