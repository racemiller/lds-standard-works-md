# 2 Corinthians 2

2 Corinthians 2 (summary): Saints should love and forgive one another—They always triumph in Christ.

2 Corinthians 2:1 But I determined this with myself, that I would not come again to you in heaviness.

2 Corinthians 2:2 For if I make you sorry, who is he then that maketh me glad, but the same which is made sorry by me?

2 Corinthians 2:3 And I wrote this same unto you, lest, when I came, I should have sorrow from them of whom I ought to rejoice; having confidence in you all, that my joy is the joy of you all.

2 Corinthians 2:4 For out of much affliction and anguish of heart I wrote unto you with many tears; not that ye should be grieved, but that ye might know the love which I have more abundantly unto you.

2 Corinthians 2:5 But if any have caused grief, he hath not grieved me, but in part: that I may not overcharge you all.

2 Corinthians 2:6 Sufficient to such a man is this punishment, which was inflicted of many.

2 Corinthians 2:7 So that contrariwise ye ought rather to forgive him, and comfort him, lest perhaps such a one should be swallowed up with overmuch sorrow.

2 Corinthians 2:8 Wherefore I beseech you that ye would confirm your love toward him.

2 Corinthians 2:9 For to this end also did I write, that I might know the proof of you, whether ye be obedient in all things.

2 Corinthians 2:10 To whom ye forgive any thing, I forgive also: for if I forgave any thing, to whom I forgave it, for your sakes forgave I it in the person of Christ;

2 Corinthians 2:11 Lest Satan should get an advantage of us: for we are not ignorant of his devices.

2 Corinthians 2:12 Furthermore, when I came to Troas to preach Christ’s gospel, and a door was opened unto me of the Lord,

2 Corinthians 2:13 I had no rest in my spirit, because I found not Titus my brother: but taking my leave of them, I went from thence into Macedonia.

2 Corinthians 2:14 Now thanks be unto God, which always causeth us to triumph in Christ, and maketh manifest the savour of his knowledge by us in every place.

2 Corinthians 2:15 For we are unto God a sweet savour of Christ, in them that are saved, and in them that perish:

2 Corinthians 2:16 To the one we are the savour of death unto death; and to the other the savour of life unto life. And who is sufficient for these things?

2 Corinthians 2:17 For we are not as many, which corrupt the word of God: but as of sincerity, but as of God, in the sight of God speak we in Christ.
