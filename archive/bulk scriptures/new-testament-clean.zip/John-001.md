# John 1

John 1 (summary): Christ is the Word of God—He created all things and was made flesh—John baptizes Jesus and testifies that He is the Lamb of God—John, Andrew, Simon, Philip, and Nathanael believe in Christ and follow Him.

John 1:1 In the beginning was the Word, and the Word was with God, and the Word was God.

John 1:2 The same was in the beginning with God.

John 1:3 All things were made by him; and without him was not any thing made that was made.

John 1:4 In him was life; and the life was the light of men.

John 1:5 And the light shineth in darkness; and the darkness comprehended it not.

John 1:6 There was a man sent from God, whose name was John.

John 1:7 The same came for a witness, to bear witness of the Light, that all men through him might believe.

John 1:8 He was not that Light, but was sent to bear witness of that Light.

John 1:9 That was the true Light, which lighteth every man that cometh into the world.

John 1:10 He was in the world, and the world was made by him, and the world knew him not.

John 1:11 He came unto his own, and his own received him not.

John 1:12 But as many as received him, to them gave he power to become the sons of God, even to them that believe on his name:

John 1:13 Which were born, not of blood, nor of the will of the flesh, nor of the will of man, but of God.

John 1:14 And the Word was made flesh, and dwelt among us, (and we beheld his glory, the glory as of the only begotten of the Father,) full of grace and truth.

John 1:15 John bare witness of him, and cried, saying, This was he of whom I spake, He that cometh after me is preferred before me: for he was before me.

John 1:16 And of his fulness have all we received, and grace for grace.

John 1:17 For the law was given by Moses, but grace and truth came by Jesus Christ.

John 1:18 No man hath seen God at any time; the only begotten Son, which is in the bosom of the Father, he hath declared him.

John 1:19 And this is the record of John, when the Jews sent priests and Levites from Jerusalem to ask him, Who art thou?

John 1:20 And he confessed, and denied not; but confessed, I am not the Christ.

John 1:21 And they asked him, What then? Art thou Elias? And he saith, I am not. Art thou that prophet? And he answered, No.

John 1:22 Then said they unto him, Who art thou? that we may give an answer to them that sent us. What sayest thou of thyself?

John 1:23 He said, I am the voice of one crying in the wilderness, Make straight the way of the Lord, as said the prophet Esaias.

John 1:24 And they which were sent were of the Pharisees.

John 1:25 And they asked him, and said unto him, Why baptizest thou then, if thou be not that Christ, nor Elias, neither that prophet?

John 1:26 John answered them, saying, I baptize with water: but there standeth one among you, whom ye know not;

John 1:27 He it is, who coming after me is preferred before me, whose shoe’s latchet I am not worthy to unloose.

John 1:28 These things were done in Bethabara beyond Jordan, where John was baptizing.

John 1:29 The next day John seeth Jesus coming unto him, and saith, Behold the Lamb of God, which taketh away the sin of the world.

John 1:30 This is he of whom I said, After me cometh a man which is preferred before me: for he was before me.

John 1:31 And I knew him not: but that he should be made manifest to Israel, therefore am I come baptizing with water.

John 1:32 And John bare record, saying, I saw the Spirit descending from heaven like a dove, and it abode upon him.

John 1:33 And I knew him not: but he that sent me to baptize with water, the same said unto me, Upon whom thou shalt see the Spirit descending, and remaining on him, the same is he which baptizeth with the Holy Ghost.

John 1:34 And I saw, and bare record that this is the Son of God.

John 1:35 Again the next day after John stood, and two of his disciples;

John 1:36 And looking upon Jesus as he walked, he saith, Behold the Lamb of God!

John 1:37 And the two disciples heard him speak, and they followed Jesus.

John 1:38 Then Jesus turned, and saw them following, and saith unto them, What seek ye? They said unto him, Rabbi, (which is to say, being interpreted, Master,) where dwellest thou?

John 1:39 He saith unto them, Come and see. They came and saw where he dwelt, and abode with him that day: for it was about the tenth hour.

John 1:40 One of the two which heard John speak, and followed him, was Andrew, Simon Peter’s brother.

John 1:41 He first findeth his own brother Simon, and saith unto him, We have found the Messias, which is, being interpreted, the Christ.

John 1:42 And he brought him to Jesus. And when Jesus beheld him, he said, Thou art Simon the son of Jona: thou shalt be called Cephas, which is by interpretation, A stone.

John 1:43 The day following Jesus would go forth into Galilee, and findeth Philip, and saith unto him, Follow me.

John 1:44 Now Philip was of Bethsaida, the city of Andrew and Peter.

John 1:45 Philip findeth Nathanael, and saith unto him, We have found him, of whom Moses in the law, and the prophets, did write, Jesus of Nazareth, the son of Joseph.

John 1:46 And Nathanael said unto him, Can there any good thing come out of Nazareth? Philip saith unto him, Come and see.

John 1:47 Jesus saw Nathanael coming to him, and saith of him, Behold an Israelite indeed, in whom is no guile!

John 1:48 Nathanael saith unto him, Whence knowest thou me? Jesus answered and said unto him, Before that Philip called thee, when thou wast under the fig tree, I saw thee.

John 1:49 Nathanael answered and saith unto him, Rabbi, thou art the Son of God; thou art the King of Israel.

John 1:50 Jesus answered and said unto him, Because I said unto thee, I saw thee under the fig tree, believest thou? thou shalt see greater things than these.

John 1:51 And he saith unto him, Verily, verily, I say unto you, Hereafter ye shall see heaven open, and the angels of God ascending and descending upon the Son of man.
