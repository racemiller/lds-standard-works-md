# 2 Corinthians 4

2 Corinthians 4 (summary): Gospel light shines on the Saints—Mortal trials are nothing as contrasted with eternal glory.

2 Corinthians 4:1 Therefore seeing we have this ministry, as we have received mercy, we faint not;

2 Corinthians 4:2 But have renounced the hidden things of dishonesty, not walking in craftiness, nor handling the word of God deceitfully; but by manifestation of the truth commending ourselves to every man’s conscience in the sight of God.

2 Corinthians 4:3 But if our gospel be hid, it is hid to them that are lost:

2 Corinthians 4:4 In whom the god of this world hath blinded the minds of them which believe not, lest the light of the glorious gospel of Christ, who is the image of God, should shine unto them.

2 Corinthians 4:5 For we preach not ourselves, but Christ Jesus the Lord; and ourselves your servants for Jesus’ sake.

2 Corinthians 4:6 For God, who commanded the light to shine out of darkness, hath shined in our hearts, to give the light of the knowledge of the glory of God in the face of Jesus Christ.

2 Corinthians 4:7 But we have this treasure in earthen vessels, that the excellency of the power may be of God, and not of us.

2 Corinthians 4:8 We are troubled on every side, yet not distressed; we are perplexed, but not in despair;

2 Corinthians 4:9 Persecuted, but not forsaken; cast down, but not destroyed;

2 Corinthians 4:10 Always bearing about in the body the dying of the Lord Jesus, that the life also of Jesus might be made manifest in our body.

2 Corinthians 4:11 For we which live are alway delivered unto death for Jesus’ sake, that the life also of Jesus might be made manifest in our mortal flesh.

2 Corinthians 4:12 So then death worketh in us, but life in you.

2 Corinthians 4:13 We having the same spirit of faith, according as it is written, I believed, and therefore have I spoken; we also believe, and therefore speak;

2 Corinthians 4:14 Knowing that he which raised up the Lord Jesus shall raise up us also by Jesus, and shall present us with you.

2 Corinthians 4:15 For all things are for your sakes, that the abundant grace might through the thanksgiving of many redound to the glory of God.

2 Corinthians 4:16 For which cause we faint not; but though our outward man perish, yet the inward man is renewed day by day.

2 Corinthians 4:17 For our light affliction, which is but for a moment, worketh for us a far more exceeding and eternal weight of glory;

2 Corinthians 4:18 While we look not at the things which are seen, but at the things which are not seen: for the things which are seen are temporal; but the things which are not seen are eternal.
