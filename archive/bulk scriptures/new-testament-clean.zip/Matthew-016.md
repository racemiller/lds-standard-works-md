# Matthew 16

Matthew 16 (summary): Jesus warns against the doctrine of the Pharisees and Sadducees—Peter testifies that Jesus is the Christ and is promised the keys of the kingdom—Jesus foretells His death and resurrection.

Matthew 16:1 The Pharisees also with the Sadducees came, and tempting desired him that he would shew them a sign from heaven.

Matthew 16:2 He answered and said unto them, When it is evening, ye say, It will be fair weather: for the sky is red.

Matthew 16:3 And in the morning, It will be foul weather to day: for the sky is red and lowring. O ye hypocrites, ye can discern the face of the sky; but can ye not discern the signs of the times?

Matthew 16:4 A wicked and adulterous generation seeketh after a sign; and there shall no sign be given unto it, but the sign of the prophet Jonas. And he left them, and departed.

Matthew 16:5 And when his disciples were come to the other side, they had forgotten to take bread.

Matthew 16:6 Then Jesus said unto them, Take heed and beware of the leaven of the Pharisees and of the Sadducees.

Matthew 16:7 And they reasoned among themselves, saying, It is because we have taken no bread.

Matthew 16:8 Which when Jesus perceived, he said unto them, O ye of little faith, why reason ye among yourselves, because ye have brought no bread?

Matthew 16:9 Do ye not yet understand, neither remember the five loaves of the five thousand, and how many baskets ye took up?

Matthew 16:10 Neither the seven loaves of the four thousand, and how many baskets ye took up?

Matthew 16:11 How is it that ye do not understand that I spake it not to you concerning bread, that ye should beware of the leaven of the Pharisees and of the Sadducees?

Matthew 16:12 Then understood they how that he bade them not beware of the leaven of bread, but of the doctrine of the Pharisees and of the Sadducees.

Matthew 16:13 When Jesus came into the coasts of Cæsarea Philippi, he asked his disciples, saying, Whom do men say that I the Son of man am?

Matthew 16:14 And they said, Some say that thou art John the Baptist: some, Elias; and others, Jeremias, or one of the prophets.

Matthew 16:15 He saith unto them, But whom say ye that I am?

Matthew 16:16 And Simon Peter answered and said, Thou art the Christ, the Son of the living God.

Matthew 16:17 And Jesus answered and said unto him, Blessed art thou, Simon Bar-jona: for flesh and blood hath not revealed it unto thee, but my Father which is in heaven.

Matthew 16:18 And I say also unto thee, That thou art Peter, and upon this rock I will build my church; and the gates of hell shall not prevail against it.

Matthew 16:19 And I will give unto thee the keys of the kingdom of heaven: and whatsoever thou shalt bind on earth shall be bound in heaven: and whatsoever thou shalt loose on earth shall be loosed in heaven.

Matthew 16:20 Then charged he his disciples that they should tell no man that he was Jesus the Christ.

Matthew 16:21 From that time forth began Jesus to shew unto his disciples, how that he must go unto Jerusalem, and suffer many things of the elders and chief priests and scribes, and be killed, and be raised again the third day.

Matthew 16:22 Then Peter took him, and began to rebuke him, saying, Be it far from thee, Lord: this shall not be unto thee.

Matthew 16:23 But he turned, and said unto Peter, Get thee behind me, Satan: thou art an offence unto me: for thou savourest not the things that be of God, but those that be of men.

Matthew 16:24 Then said Jesus unto his disciples, If any man will come after me, let him deny himself, and take up his cross, and follow me.

Matthew 16:25 For whosoever will save his life shall lose it: and whosoever will lose his life for my sake shall find it.

Matthew 16:26 For what is a man profited, if he shall gain the whole world, and lose his own soul? or what shall a man give in exchange for his soul?

Matthew 16:27 For the Son of man shall come in the glory of his Father with his angels; and then he shall reward every man according to his works.

Matthew 16:28 Verily I say unto you, There be some standing here, which shall not taste of death, till they see the Son of man coming in his kingdom.
