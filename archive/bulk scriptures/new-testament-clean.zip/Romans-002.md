# Romans 2

Romans 2 (summary): God will render to every person according to his or her deeds—Both Jews and Gentiles will be judged by gospel laws.

Romans 2:1 Therefore thou art inexcusable, O man, whosoever thou art that judgest: for wherein thou judgest another, thou condemnest thyself; for thou that judgest doest the same things.

Romans 2:2 But we are sure that the judgment of God is according to truth against them which commit such things.

Romans 2:3 And thinkest thou this, O man, that judgest them which do such things, and doest the same, that thou shalt escape the judgment of God?

Romans 2:4 Or despisest thou the riches of his goodness and forbearance and longsuffering; not knowing that the goodness of God leadeth thee to repentance?

Romans 2:5 But after thy hardness and impenitent heart treasurest up unto thyself wrath against the day of wrath and revelation of the righteous judgment of God;

Romans 2:6 Who will render to every man according to his deeds:

Romans 2:7 To them who by patient continuance in well doing seek for glory and honour and immortality, eternal life:

Romans 2:8 But unto them that are contentious, and do not obey the truth, but obey unrighteousness, indignation and wrath,

Romans 2:9 Tribulation and anguish, upon every soul of man that doeth evil, of the Jew first, and also of the Gentile;

Romans 2:10 But glory, honour, and peace, to every man that worketh good, to the Jew first, and also to the Gentile:

Romans 2:11 For there is no respect of persons with God.

Romans 2:12 For as many as have sinned without law shall also perish without law: and as many as have sinned in the law shall be judged by the law;

Romans 2:13 (For not the hearers of the law are just before God, but the doers of the law shall be justified.

Romans 2:14 For when the Gentiles, which have not the law, do by nature the things contained in the law, these, having not the law, are a law unto themselves:

Romans 2:15 Which shew the work of the law written in their hearts, their conscience also bearing witness, and their thoughts the mean while accusing or else excusing one another;)

Romans 2:16 In the day when God shall judge the secrets of men by Jesus Christ according to my gospel.

Romans 2:17 Behold, thou art called a Jew, and restest in the law, and makest thy boast of God,

Romans 2:18 And knowest his will, and approvest the things that are more excellent, being instructed out of the law;

Romans 2:19 And art confident that thou thyself art a guide of the blind, a light of them which are in darkness,

Romans 2:20 An instructor of the foolish, a teacher of babes, which hast the form of knowledge and of the truth in the law.

Romans 2:21 Thou therefore which teachest another, teachest thou not thyself? thou that preachest a man should not steal, dost thou steal?

Romans 2:22 Thou that sayest a man should not commit adultery, dost thou commit adultery? thou that abhorrest idols, dost thou commit sacrilege?

Romans 2:23 Thou that makest thy boast of the law, through breaking the law dishonourest thou God?

Romans 2:24 For the name of God is blasphemed among the Gentiles through you, as it is written.

Romans 2:25 For circumcision verily profiteth, if thou keep the law: but if thou be a breaker of the law, thy circumcision is made uncircumcision.

Romans 2:26 Therefore if the uncircumcision keep the righteousness of the law, shall not his uncircumcision be counted for circumcision?

Romans 2:27 And shall not uncircumcision which is by nature, if it fulfil the law, judge thee, who by the letter and circumcision dost transgress the law?

Romans 2:28 For he is not a Jew, which is one outwardly; neither is that circumcision, which is outward in the flesh:

Romans 2:29 But he is a Jew, which is one inwardly; and circumcision is that of the heart, in the spirit, and not in the letter; whose praise is not of men, but of God.
