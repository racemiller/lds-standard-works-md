# 1 Corinthians 16

1 Corinthians 16 (summary): Paul counsels, Stand fast in the faith; let all things be done with charity.

1 Corinthians 16:1 Now concerning the collection for the saints, as I have given order to the churches of Galatia, even so do ye.

1 Corinthians 16:2 Upon the first day of the week let every one of you lay by him in store, as God hath prospered him, that there be no gatherings when I come.

1 Corinthians 16:3 And when I come, whomsoever ye shall approve by your letters, them will I send to bring your liberality unto Jerusalem.

1 Corinthians 16:4 And if it be meet that I go also, they shall go with me.

1 Corinthians 16:5 Now I will come unto you, when I shall pass through Macedonia: for I do pass through Macedonia.

1 Corinthians 16:6 And it may be that I will abide, yea, and winter with you, that ye may bring me on my journey whithersoever I go.

1 Corinthians 16:7 For I will not see you now by the way; but I trust to tarry a while with you, if the Lord permit.

1 Corinthians 16:8 But I will tarry at Ephesus until Pentecost.

1 Corinthians 16:9 For a great door and effectual is opened unto me, and there are many adversaries.

1 Corinthians 16:10 Now if Timotheus come, see that he may be with you without fear: for he worketh the work of the Lord, as I also do.

1 Corinthians 16:11 Let no man therefore despise him: but conduct him forth in peace, that he may come unto me: for I look for him with the brethren.

1 Corinthians 16:12 As touching our brother Apollos, I greatly desired him to come unto you with the brethren: but his will was not at all to come at this time; but he will come when he shall have convenient time.

1 Corinthians 16:13 Watch ye, stand fast in the faith, quit you like men, be strong.

1 Corinthians 16:14 Let all your things be done with charity.

1 Corinthians 16:15 I beseech you, brethren, (ye know the house of Stephanas, that it is the firstfruits of Achaia, and that they have addicted themselves to the ministry of the saints,)

1 Corinthians 16:16 That ye submit yourselves unto such, and to every one that helpeth with us, and laboureth.

1 Corinthians 16:17 I am glad of the coming of Stephanas and Fortunatus and Achaicus: for that which was lacking on your part they have supplied.

1 Corinthians 16:18 For they have refreshed my spirit and yours: therefore acknowledge ye them that are such.

1 Corinthians 16:19 The churches of Asia salute you. Aquila and Priscilla salute you much in the Lord, with the church that is in their house.

1 Corinthians 16:20 All the brethren greet you. Greet ye one another with an holy kiss.

1 Corinthians 16:21 The salutation of me Paul with mine own hand.

1 Corinthians 16:22 If any man love not the Lord Jesus Christ, let him be Anathema Maran-atha.

1 Corinthians 16:23 The grace of our Lord Jesus Christ be with you.

1 Corinthians 16:24 My love be with you all in Christ Jesus. Amen.
