# John 17

John 17 (summary): Jesus offers the great Intercessory Prayer—He is glorified by gaining eternal life—He prays for His Apostles and all the Saints—He explains how the Father and Son are one.

John 17:1 These words spake Jesus, and lifted up his eyes to heaven, and said, Father, the hour is come; glorify thy Son, that thy Son also may glorify thee:

John 17:2 As thou hast given him power over all flesh, that he should give eternal life to as many as thou hast given him.

John 17:3 And this is life eternal, that they might know thee the only true God, and Jesus Christ, whom thou hast sent.

John 17:4 I have glorified thee on the earth: I have finished the work which thou gavest me to do.

John 17:5 And now, O Father, glorify thou me with thine own self with the glory which I had with thee before the world was.

John 17:6 I have manifested thy name unto the men which thou gavest me out of the world: thine they were, and thou gavest them me; and they have kept thy word.

John 17:7 Now they have known that all things whatsoever thou hast given me are of thee.

John 17:8 For I have given unto them the words which thou gavest me; and they have received them, and have known surely that I came out from thee, and they have believed that thou didst send me.

John 17:9 I pray for them: I pray not for the world, but for them which thou hast given me; for they are thine.

John 17:10 And all mine are thine, and thine are mine; and I am glorified in them.

John 17:11 And now I am no more in the world, but these are in the world, and I come to thee. Holy Father, keep through thine own name those whom thou hast given me, that they may be one, as we are.

John 17:12 While I was with them in the world, I kept them in thy name: those that thou gavest me I have kept, and none of them is lost, but the son of perdition; that the scripture might be fulfilled.

John 17:13 And now come I to thee; and these things I speak in the world, that they might have my joy fulfilled in themselves.

John 17:14 I have given them thy word; and the world hath hated them, because they are not of the world, even as I am not of the world.

John 17:15 I pray not that thou shouldest take them out of the world, but that thou shouldest keep them from the evil.

John 17:16 They are not of the world, even as I am not of the world.

John 17:17 Sanctify them through thy truth: thy word is truth.

John 17:18 As thou hast sent me into the world, even so have I also sent them into the world.

John 17:19 And for their sakes I sanctify myself, that they also might be sanctified through the truth.

John 17:20 Neither pray I for these alone, but for them also which shall believe on me through their word;

John 17:21 That they all may be one; as thou, Father, art in me, and I in thee, that they also may be one in us: that the world may believe that thou hast sent me.

John 17:22 And the glory which thou gavest me I have given them; that they may be one, even as we are one:

John 17:23 I in them, and thou in me, that they may be made perfect in one; and that the world may know that thou hast sent me, and hast loved them, as thou hast loved me.

John 17:24 Father, I will that they also, whom thou hast given me, be with me where I am; that they may behold my glory, which thou hast given me: for thou lovedst me before the foundation of the world.

John 17:25 O righteous Father, the world hath not known thee: but I have known thee, and these have known that thou hast sent me.

John 17:26 And I have declared unto them thy name, and will declare it: that the love wherewith thou hast loved me may be in them, and I in them.
