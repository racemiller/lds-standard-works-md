# Luke 19

Luke 19 (summary): Jesus came to save souls—He gives the parable of the pounds—He rides in triumph into Jerusalem, weeps over the city, and cleanses the temple again.

Luke 19:1 And Jesus entered and passed through Jericho.

Luke 19:2 And, behold, there was a man named Zacchæus, which was the chief among the publicans, and he was rich.

Luke 19:3 And he sought to see Jesus who he was; and could not for the press, because he was little of stature.

Luke 19:4 And he ran before, and climbed up into a sycomore tree to see him: for he was to pass that way.

Luke 19:5 And when Jesus came to the place, he looked up, and saw him, and said unto him, Zacchæus, make haste, and come down; for to day I must abide at thy house.

Luke 19:6 And he made haste, and came down, and received him joyfully.

Luke 19:7 And when they saw it, they all murmured, saying, That he was gone to be guest with a man that is a sinner.

Luke 19:8 And Zacchæus stood, and said unto the Lord; Behold, Lord, the half of my goods I give to the poor; and if I have taken any thing from any man by false accusation, I restore him fourfold.

Luke 19:9 And Jesus said unto him, This day is salvation come to this house, forsomuch as he also is a son of Abraham.

Luke 19:10 For the Son of man is come to seek and to save that which was lost.

Luke 19:11 And as they heard these things, he added and spake a parable, because he was nigh to Jerusalem, and because they thought that the kingdom of God should immediately appear.

Luke 19:12 He said therefore, A certain nobleman went into a far country to receive for himself a kingdom, and to return.

Luke 19:13 And he called his ten servants, and delivered them ten pounds, and said unto them, Occupy till I come.

Luke 19:14 But his citizens hated him, and sent a message after him, saying, We will not have this man to reign over us.

Luke 19:15 And it came to pass, that when he was returned, having received the kingdom, then he commanded these servants to be called unto him, to whom he had given the money, that he might know how much every man had gained by trading.

Luke 19:16 Then came the first, saying, Lord, thy pound hath gained ten pounds.

Luke 19:17 And he said unto him, Well, thou good servant: because thou hast been faithful in a very little, have thou authority over ten cities.

Luke 19:18 And the second came, saying, Lord, thy pound hath gained five pounds.

Luke 19:19 And he said likewise to him, Be thou also over five cities.

Luke 19:20 And another came, saying, Lord, behold, here is thy pound, which I have kept laid up in a napkin:

Luke 19:21 For I feared thee, because thou art an austere man: thou takest up that thou layedst not down, and reapest that thou didst not sow.

Luke 19:22 And he saith unto him, Out of thine own mouth will I judge thee, thou wicked servant. Thou knewest that I was an austere man, taking up that I laid not down, and reaping that I did not sow:

Luke 19:23 Wherefore then gavest not thou my money into the bank, that at my coming I might have required mine own with usury?

Luke 19:24 And he said unto them that stood by, Take from him the pound, and give it to him that hath ten pounds.

Luke 19:25 (And they said unto him, Lord, he hath ten pounds.)

Luke 19:26 For I say unto you, That unto every one which hath shall be given; and from him that hath not, even that he hath shall be taken away from him.

Luke 19:27 But those mine enemies, which would not that I should reign over them, bring hither, and slay them before me.

Luke 19:28 And when he had thus spoken, he went before, ascending up to Jerusalem.

Luke 19:29 And it came to pass, when he was come nigh to Bethphage and Bethany, at the mount called the mount of Olives, he sent two of his disciples,

Luke 19:30 Saying, Go ye into the village over against you; in the which at your entering ye shall find a colt tied, whereon yet never man sat: loose him, and bring him hither.

Luke 19:31 And if any man ask you, Why do ye loose him? thus shall ye say unto him, Because the Lord hath need of him.

Luke 19:32 And they that were sent went their way, and found even as he had said unto them.

Luke 19:33 And as they were loosing the colt, the owners thereof said unto them, Why loose ye the colt?

Luke 19:34 And they said, The Lord hath need of him.

Luke 19:35 And they brought him to Jesus: and they cast their garments upon the colt, and they set Jesus thereon.

Luke 19:36 And as he went, they spread their clothes in the way.

Luke 19:37 And when he was come nigh, even now at the descent of the mount of Olives, the whole multitude of the disciples began to rejoice and praise God with a loud voice for all the mighty works that they had seen;

Luke 19:38 Saying, Blessed be the King that cometh in the name of the Lord: peace in heaven, and glory in the highest.

Luke 19:39 And some of the Pharisees from among the multitude said unto him, Master, rebuke thy disciples.

Luke 19:40 And he answered and said unto them, I tell you that, if these should hold their peace, the stones would immediately cry out.

Luke 19:41 And when he was come near, he beheld the city, and wept over it,

Luke 19:42 Saying, If thou hadst known, even thou, at least in this thy day, the things which belong unto thy peace! but now they are hid from thine eyes.

Luke 19:43 For the days shall come upon thee, that thine enemies shall cast a trench about thee, and compass thee round, and keep thee in on every side,

Luke 19:44 And shall lay thee even with the ground, and thy children within thee; and they shall not leave in thee one stone upon another; because thou knewest not the time of thy visitation.

Luke 19:45 And he went into the temple, and began to cast out them that sold therein, and them that bought;

Luke 19:46 Saying unto them, It is written, My house is the house of prayer: but ye have made it a den of thieves.

Luke 19:47 And he taught daily in the temple. But the chief priests and the scribes and the chief of the people sought to destroy him,

Luke 19:48 And could not find what they might do: for all the people were very attentive to hear him.
