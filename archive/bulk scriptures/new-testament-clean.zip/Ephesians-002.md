# Ephesians 2

Ephesians 2 (summary): We are saved by grace through faith—The blood of Christ saves Jew and Gentile alike—The Church is built upon the foundation of apostles and prophets.

Ephesians 2:1 And you hath he quickened, who were dead in trespasses and sins;

Ephesians 2:2 Wherein in time past ye walked according to the course of this world, according to the prince of the power of the air, the spirit that now worketh in the children of disobedience:

Ephesians 2:3 Among whom also we all had our conversation in times past in the lusts of our flesh, fulfilling the desires of the flesh and of the mind; and were by nature the children of wrath, even as others.

Ephesians 2:4 But God, who is rich in mercy, for his great love wherewith he loved us,

Ephesians 2:5 Even when we were dead in sins, hath quickened us together with Christ, (by grace ye are saved;)

Ephesians 2:6 And hath raised us up together, and made us sit together in heavenly places in Christ Jesus:

Ephesians 2:7 That in the ages to come he might shew the exceeding riches of his grace in his kindness toward us through Christ Jesus.

Ephesians 2:8 For by grace are ye saved through faith; and that not of yourselves: it is the gift of God:

Ephesians 2:9 Not of works, lest any man should boast.

Ephesians 2:10 For we are his workmanship, created in Christ Jesus unto good works, which God hath before ordained that we should walk in them.

Ephesians 2:11 Wherefore remember, that ye being in time past Gentiles in the flesh, who are called Uncircumcision by that which is called the Circumcision in the flesh made by hands;

Ephesians 2:12 That at that time ye were without Christ, being aliens from the commonwealth of Israel, and strangers from the covenants of promise, having no hope, and without God in the world:

Ephesians 2:13 But now in Christ Jesus ye who sometimes were far off are made nigh by the blood of Christ.

Ephesians 2:14 For he is our peace, who hath made both one, and hath broken down the middle wall of partition between us;

Ephesians 2:15 Having abolished in his flesh the enmity, even the law of commandments contained in ordinances; for to make in himself of twain one new man, so making peace;

Ephesians 2:16 And that he might reconcile both unto God in one body by the cross, having slain the enmity thereby:

Ephesians 2:17 And came and preached peace to you which were afar off, and to them that were nigh.

Ephesians 2:18 For through him we both have access by one Spirit unto the Father.

Ephesians 2:19 Now therefore ye are no more strangers and foreigners, but fellowcitizens with the saints, and of the household of God;

Ephesians 2:20 And are built upon the foundation of the apostles and prophets, Jesus Christ himself being the chief corner stone;

Ephesians 2:21 In whom all the building fitly framed together groweth unto an holy temple in the Lord:

Ephesians 2:22 In whom ye also are builded together for an habitation of God through the Spirit.
