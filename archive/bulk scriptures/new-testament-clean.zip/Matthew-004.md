# Matthew 4

Matthew 4 (summary): Jesus fasts forty days and is tempted—He begins His ministry, calls disciples, and heals the sick.

Matthew 4:1 Then was Jesus led up of the Spirit into the wilderness to be tempted of the devil.

Matthew 4:2 And when he had fasted forty days and forty nights, he was afterward an hungred.

Matthew 4:3 And when the tempter came to him, he said, If thou be the Son of God, command that these stones be made bread.

Matthew 4:4 But he answered and said, It is written, Man shall not live by bread alone, but by every word that proceedeth out of the mouth of God.

Matthew 4:5 Then the devil taketh him up into the holy city, and setteth him on a pinnacle of the temple,

Matthew 4:6 And saith unto him, If thou be the Son of God, cast thyself down: for it is written, He shall give his angels charge concerning thee: and in their hands they shall bear thee up, lest at any time thou dash thy foot against a stone.

Matthew 4:7 Jesus said unto him, It is written again, Thou shalt not tempt the Lord thy God.

Matthew 4:8 Again, the devil taketh him up into an exceeding high mountain, and sheweth him all the kingdoms of the world, and the glory of them;

Matthew 4:9 And saith unto him, All these things will I give thee, if thou wilt fall down and worship me.

Matthew 4:10 Then saith Jesus unto him, Get thee hence, Satan: for it is written, Thou shalt worship the Lord thy God, and him only shalt thou serve.

Matthew 4:11 Then the devil leaveth him, and, behold, angels came and ministered unto him.

Matthew 4:12 Now when Jesus had heard that John was cast into prison, he departed into Galilee;

Matthew 4:13 And leaving Nazareth, he came and dwelt in Capernaum, which is upon the sea coast, in the borders of Zabulon and Nephthalim:

Matthew 4:14 That it might be fulfilled which was spoken by Esaias the prophet, saying,

Matthew 4:15 The land of Zabulon, and the land of Nephthalim, by the way of the sea, beyond Jordan, Galilee of the Gentiles;

Matthew 4:16 The people which sat in darkness saw great light; and to them which sat in the region and shadow of death light is sprung up.

Matthew 4:17 From that time Jesus began to preach, and to say, Repent: for the kingdom of heaven is at hand.

Matthew 4:18 And Jesus, walking by the sea of Galilee, saw two brethren, Simon called Peter, and Andrew his brother, casting a net into the sea: for they were fishers.

Matthew 4:19 And he saith unto them, Follow me, and I will make you fishers of men.

Matthew 4:20 And they straightway left their nets, and followed him.

Matthew 4:21 And going on from thence, he saw other two brethren, James the son of Zebedee, and John his brother, in a ship with Zebedee their father, mending their nets; and he called them.

Matthew 4:22 And they immediately left the ship and their father, and followed him.

Matthew 4:23 And Jesus went about all Galilee, teaching in their synagogues, and preaching the gospel of the kingdom, and healing all manner of sickness and all manner of disease among the people.

Matthew 4:24 And his fame went throughout all Syria: and they brought unto him all sick people that were taken with divers diseases and torments, and those which were possessed with devils, and those which were lunatic, and those that had the palsy; and he healed them.

Matthew 4:25 And there followed him great multitudes of people from Galilee, and from Decapolis, and from Jerusalem, and from Judæa, and from beyond Jordan.
