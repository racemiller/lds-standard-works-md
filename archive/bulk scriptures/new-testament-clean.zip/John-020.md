# John 20

John 20 (summary): Mary Magdalene, Peter, and John find the empty tomb—The risen Christ appears to Mary Magdalene in the garden—He appears to the disciples and shows His resurrected body—Thomas feels the wounds in Jesus’ hands, feet, and side—Jesus is the Christ, the Son of God.

John 20:1 The first day of the week cometh Mary Magdalene early, when it was yet dark, unto the sepulchre, and seeth the stone taken away from the sepulchre.

John 20:2 Then she runneth, and cometh to Simon Peter, and to the other disciple, whom Jesus loved, and saith unto them, They have taken away the Lord out of the sepulchre, and we know not where they have laid him.

John 20:3 Peter therefore went forth, and that other disciple, and came to the sepulchre.

John 20:4 So they ran both together: and the other disciple did outrun Peter, and came first to the sepulchre.

John 20:5 And he stooping down, and looking in, saw the linen clothes lying; yet went he not in.

John 20:6 Then cometh Simon Peter following him, and went into the sepulchre, and seeth the linen clothes lie,

John 20:7 And the napkin, that was about his head, not lying with the linen clothes, but wrapped together in a place by itself.

John 20:8 Then went in also that other disciple, which came first to the sepulchre, and he saw, and believed.

John 20:9 For as yet they knew not the scripture, that he must rise again from the dead.

John 20:10 Then the disciples went away again unto their own home.

John 20:11 But Mary stood without at the sepulchre weeping: and as she wept, she stooped down, and looked into the sepulchre,

John 20:12 And seeth two angels in white sitting, the one at the head, and the other at the feet, where the body of Jesus had lain.

John 20:13 And they say unto her, Woman, why weepest thou? She saith unto them, Because they have taken away my Lord, and I know not where they have laid him.

John 20:14 And when she had thus said, she turned herself back, and saw Jesus standing, and knew not that it was Jesus.

John 20:15 Jesus saith unto her, Woman, why weepest thou? whom seekest thou? She, supposing him to be the gardener, saith unto him, Sir, if thou have borne him hence, tell me where thou hast laid him, and I will take him away.

John 20:16 Jesus saith unto her, Mary. She turned herself, and saith unto him, Rabboni; which is to say, Master.

John 20:17 Jesus saith unto her, Touch me not; for I am not yet ascended to my Father: but go to my brethren, and say unto them, I ascend unto my Father, and your Father; and to my God, and your God.

John 20:18 Mary Magdalene came and told the disciples that she had seen the Lord, and that he had spoken these things unto her.

John 20:19 Then the same day at evening, being the first day of the week, when the doors were shut where the disciples were assembled for fear of the Jews, came Jesus and stood in the midst, and saith unto them, Peace be unto you.

John 20:20 And when he had so said, he shewed unto them his hands and his side. Then were the disciples glad, when they saw the Lord.

John 20:21 Then said Jesus to them again, Peace be unto you: as my Father hath sent me, even so send I you.

John 20:22 And when he had said this, he breathed on them, and saith unto them, Receive ye the Holy Ghost:

John 20:23 Whose soever sins ye remit, they are remitted unto them; and whose soever sins ye retain, they are retained.

John 20:24 But Thomas, one of the twelve, called Didymus, was not with them when Jesus came.

John 20:25 The other disciples therefore said unto him, We have seen the Lord. But he said unto them, Except I shall see in his hands the print of the nails, and put my finger into the print of the nails, and thrust my hand into his side, I will not believe.

John 20:26 And after eight days again his disciples were within, and Thomas with them: then came Jesus, the doors being shut, and stood in the midst, and said, Peace be unto you.

John 20:27 Then saith he to Thomas, Reach hither thy finger, and behold my hands; and reach hither thy hand, and thrust it into my side: and be not faithless, but believing.

John 20:28 And Thomas answered and said unto him, My Lord and my God.

John 20:29 Jesus saith unto him, Thomas, because thou hast seen me, thou hast believed: blessed are they that have not seen, and yet have believed.

John 20:30 And many other signs truly did Jesus in the presence of his disciples, which are not written in this book:

John 20:31 But these are written, that ye might believe that Jesus is the Christ, the Son of God; and that believing ye might have life through his name.
