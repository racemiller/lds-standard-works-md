# 2 Corinthians 12

2 Corinthians 12 (summary): Paul is caught up to the third heaven—The Lord gives men weaknesses that they may triumph over them—Paul manifests the signs of an Apostle.

2 Corinthians 12:1 It is not expedient for me doubtless to glory. I will come to visions and revelations of the Lord.

2 Corinthians 12:2 I knew a man in Christ above fourteen years ago, (whether in the body, I cannot tell; or whether out of the body, I cannot tell: God knoweth;) such an one caught up to the third heaven.

2 Corinthians 12:3 And I knew such a man, (whether in the body, or out of the body, I cannot tell: God knoweth;)

2 Corinthians 12:4 How that he was caught up into paradise, and heard unspeakable words, which it is not lawful for a man to utter.

2 Corinthians 12:5 Of such an one will I glory: yet of myself I will not glory, but in mine infirmities.

2 Corinthians 12:6 For though I would desire to glory, I shall not be a fool; for I will say the truth: but now I forbear, lest any man should think of me above that which he seeth me to be, or that he heareth of me.

2 Corinthians 12:7 And lest I should be exalted above measure through the abundance of the revelations, there was given to me a thorn in the flesh, the messenger of Satan to buffet me, lest I should be exalted above measure.

2 Corinthians 12:8 For this thing I besought the Lord thrice, that it might depart from me.

2 Corinthians 12:9 And he said unto me, My grace is sufficient for thee: for my strength is made perfect in weakness. Most gladly therefore will I rather glory in my infirmities, that the power of Christ may rest upon me.

2 Corinthians 12:10 Therefore I take pleasure in infirmities, in reproaches, in necessities, in persecutions, in distresses for Christ’s sake: for when I am weak, then am I strong.

2 Corinthians 12:11 I am become a fool in glorying; ye have compelled me: for I ought to have been commended of you: for in nothing am I behind the very chiefest apostles, though I be nothing.

2 Corinthians 12:12 Truly the signs of an apostle were wrought among you in all patience, in signs, and wonders, and mighty deeds.

2 Corinthians 12:13 For what is it wherein ye were inferior to other churches, except it be that I myself was not burdensome to you? forgive me this wrong.

2 Corinthians 12:14 Behold, the third time I am ready to come to you; and I will not be burdensome to you: for I seek not yours, but you: for the children ought not to lay up for the parents, but the parents for the children.

2 Corinthians 12:15 And I will very gladly spend and be spent for you; though the more abundantly I love you, the less I be loved.

2 Corinthians 12:16 But be it so, I did not burden you: nevertheless, being crafty, I caught you with guile.

2 Corinthians 12:17 Did I make a gain of you by any of them whom I sent unto you?

2 Corinthians 12:18 I desired Titus, and with him I sent a brother. Did Titus make a gain of you? walked we not in the same spirit? walked we not in the same steps?

2 Corinthians 12:19 Again, think ye that we excuse ourselves unto you? we speak before God in Christ: but we do all things, dearly beloved, for your edifying.

2 Corinthians 12:20 For I fear, lest, when I come, I shall not find you such as I would, and that I shall be found unto you such as ye would not: lest there be debates, envyings, wraths, strifes, backbitings, whisperings, swellings, tumults:

2 Corinthians 12:21 And lest, when I come again, my God will humble me among you, and that I shall bewail many which have sinned already, and have not repented of the uncleanness and fornication and lasciviousness which they have committed.
