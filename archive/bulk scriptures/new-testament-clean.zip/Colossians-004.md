# Colossians 4

Colossians 4 (summary): The Saints are told to be wise in all things—Luke and others greet the Colossians.

Colossians 4:1 Masters, give unto your servants that which is just and equal; knowing that ye also have a Master in heaven.

Colossians 4:2 Continue in prayer, and watch in the same with thanksgiving;

Colossians 4:3 Withal praying also for us, that God would open unto us a door of utterance, to speak the mystery of Christ, for which I am also in bonds:

Colossians 4:4 That I may make it manifest, as I ought to speak.

Colossians 4:5 Walk in wisdom toward them that are without, redeeming the time.

Colossians 4:6 Let your speech be alway with grace, seasoned with salt, that ye may know how ye ought to answer every man.

Colossians 4:7 All my state shall Tychicus declare unto you, who is a beloved brother, and a faithful minister and fellowservant in the Lord:

Colossians 4:8 Whom I have sent unto you for the same purpose, that he might know your estate, and comfort your hearts;

Colossians 4:9 With Onesimus, a faithful and beloved brother, who is one of you. They shall make known unto you all things which are done here.

Colossians 4:10 Aristarchus my fellowprisoner saluteth you, and Marcus, sister’s son to Barnabas, (touching whom ye received commandments: if he come unto you, receive him;)

Colossians 4:11 And Jesus, which is called Justus, who are of the circumcision. These only are my fellowworkers unto the kingdom of God, which have been a comfort unto me.

Colossians 4:12 Epaphras, who is one of you, a servant of Christ, saluteth you, always labouring fervently for you in prayers, that ye may stand perfect and complete in all the will of God.

Colossians 4:13 For I bear him record, that he hath a great zeal for you, and them that are in Laodicea, and them in Hierapolis.

Colossians 4:14 Luke, the beloved physician, and Demas, greet you.

Colossians 4:15 Salute the brethren which are in Laodicea, and Nymphas, and the church which is in his house.

Colossians 4:16 And when this epistle is read among you, cause that it be read also in the church of the Laodiceans; and that ye likewise read the epistle from Laodicea.

Colossians 4:17 And say to Archippus, Take heed to the ministry which thou hast received in the Lord, that thou fulfil it.

Colossians 4:18 The salutation by the hand of me Paul. Remember my bonds. Grace be with you. Amen.
