# Luke 1

Luke 1 (summary): Gabriel promises Zacharias that Elisabeth will bear a son, whom they will name John—He also tells Mary that she will be the mother of the Son of God—Mary visits Elisabeth and utters a psalm of praise—John the Baptist is born—Zacharias prophesies of John’s mission.

Luke 1:1 Forasmuch as many have taken in hand to set forth in order a declaration of those things which are most surely believed among us,

Luke 1:2 Even as they delivered them unto us, which from the beginning were eyewitnesses, and ministers of the word;

Luke 1:3 It seemed good to me also, having had perfect understanding of all things from the very first, to write unto thee in order, most excellent Theophilus,

Luke 1:4 That thou mightest know the certainty of those things, wherein thou hast been instructed.

Luke 1:5 There was in the days of Herod, the king of Judæa, a certain priest named Zacharias, of the course of Abia: and his wife was of the daughters of Aaron, and her name was Elisabeth.

Luke 1:6 And they were both righteous before God, walking in all the commandments and ordinances of the Lord blameless.

Luke 1:7 And they had no child, because that Elisabeth was barren, and they both were now well stricken in years.

Luke 1:8 And it came to pass, that while he executed the priest’s office before God in the order of his course,

Luke 1:9 According to the custom of the priest’s office, his lot was to burn incense when he went into the temple of the Lord.

Luke 1:10 And the whole multitude of the people were praying without at the time of incense.

Luke 1:11 And there appeared unto him an angel of the Lord standing on the right side of the altar of incense.

Luke 1:12 And when Zacharias saw him, he was troubled, and fear fell upon him.

Luke 1:13 But the angel said unto him, Fear not, Zacharias: for thy prayer is heard; and thy wife Elisabeth shall bear thee a son, and thou shalt call his name John.

Luke 1:14 And thou shalt have joy and gladness; and many shall rejoice at his birth.

Luke 1:15 For he shall be great in the sight of the Lord, and shall drink neither wine nor strong drink; and he shall be filled with the Holy Ghost, even from his mother’s womb.

Luke 1:16 And many of the children of Israel shall he turn to the Lord their God.

Luke 1:17 And he shall go before him in the spirit and power of Elias, to turn the hearts of the fathers to the children, and the disobedient to the wisdom of the just; to make ready a people prepared for the Lord.

Luke 1:18 And Zacharias said unto the angel, Whereby shall I know this? for I am an old man, and my wife well stricken in years.

Luke 1:19 And the angel answering said unto him, I am Gabriel, that stand in the presence of God; and am sent to speak unto thee, and to shew thee these glad tidings.

Luke 1:20 And, behold, thou shalt be dumb, and not able to speak, until the day that these things shall be performed, because thou believest not my words, which shall be fulfilled in their season.

Luke 1:21 And the people waited for Zacharias, and marvelled that he tarried so long in the temple.

Luke 1:22 And when he came out, he could not speak unto them: and they perceived that he had seen a vision in the temple: for he beckoned unto them, and remained speechless.

Luke 1:23 And it came to pass, that, as soon as the days of his ministration were accomplished, he departed to his own house.

Luke 1:24 And after those days his wife Elisabeth conceived, and hid herself five months, saying,

Luke 1:25 Thus hath the Lord dealt with me in the days wherein he looked on me, to take away my reproach among men.

Luke 1:26 And in the sixth month the angel Gabriel was sent from God unto a city of Galilee, named Nazareth,

Luke 1:27 To a virgin espoused to a man whose name was Joseph, of the house of David; and the virgin’s name was Mary.

Luke 1:28 And the angel came in unto her, and said, Hail, thou that art highly favoured, the Lord is with thee: blessed art thou among women.

Luke 1:29 And when she saw him, she was troubled at his saying, and cast in her mind what manner of salutation this should be.

Luke 1:30 And the angel said unto her, Fear not, Mary: for thou hast found favour with God.

Luke 1:31 And, behold, thou shalt conceive in thy womb, and bring forth a son, and shalt call his name Jesus.

Luke 1:32 He shall be great, and shall be called the Son of the Highest: and the Lord God shall give unto him the throne of his father David:

Luke 1:33 And he shall reign over the house of Jacob for ever; and of his kingdom there shall be no end.

Luke 1:34 Then said Mary unto the angel, How shall this be, seeing I know not a man?

Luke 1:35 And the angel answered and said unto her, The Holy Ghost shall come upon thee, and the power of the Highest shall overshadow thee: therefore also that holy thing which shall be born of thee shall be called the Son of God.

Luke 1:36 And, behold, thy cousin Elisabeth, she hath also conceived a son in her old age: and this is the sixth month with her, who was called barren.

Luke 1:37 For with God nothing shall be impossible.

Luke 1:38 And Mary said, Behold the handmaid of the Lord; be it unto me according to thy word. And the angel departed from her.

Luke 1:39 And Mary arose in those days, and went into the hill country with haste, into a city of Juda;

Luke 1:40 And entered into the house of Zacharias, and saluted Elisabeth.

Luke 1:41 And it came to pass, that, when Elisabeth heard the salutation of Mary, the babe leaped in her womb; and Elisabeth was filled with the Holy Ghost:

Luke 1:42 And she spake out with a loud voice, and said, Blessed art thou among women, and blessed is the fruit of thy womb.

Luke 1:43 And whence is this to me, that the mother of my Lord should come to me?

Luke 1:44 For, lo, as soon as the voice of thy salutation sounded in mine ears, the babe leaped in my womb for joy.

Luke 1:45 And blessed is she that believed: for there shall be a performance of those things which were told her from the Lord.

Luke 1:46 And Mary said, My soul doth magnify the Lord,

Luke 1:47 And my spirit hath rejoiced in God my Saviour.

Luke 1:48 For he hath regarded the low estate of his handmaiden: for, behold, from henceforth all generations shall call me blessed.

Luke 1:49 For he that is mighty hath done to me great things; and holy is his name.

Luke 1:50 And his mercy is on them that fear him from generation to generation.

Luke 1:51 He hath shewed strength with his arm; he hath scattered the proud in the imagination of their hearts.

Luke 1:52 He hath put down the mighty from their seats, and exalted them of low degree.

Luke 1:53 He hath filled the hungry with good things; and the rich he hath sent empty away.

Luke 1:54 He hath holpen his servant Israel, in remembrance of his mercy;

Luke 1:55 As he spake to our fathers, to Abraham, and to his seed for ever.

Luke 1:56 And Mary abode with her about three months, and returned to her own house.

Luke 1:57 Now Elisabeth’s full time came that she should be delivered; and she brought forth a son.

Luke 1:58 And her neighbours and her cousins heard how the Lord had shewed great mercy upon her; and they rejoiced with her.

Luke 1:59 And it came to pass, that on the eighth day they came to circumcise the child; and they called him Zacharias, after the name of his father.

Luke 1:60 And his mother answered and said, Not so; but he shall be called John.

Luke 1:61 And they said unto her, There is none of thy kindred that is called by this name.

Luke 1:62 And they made signs to his father, how he would have him called.

Luke 1:63 And he asked for a writing table, and wrote, saying, His name is John. And they marvelled all.

Luke 1:64 And his mouth was opened immediately, and his tongue loosed, and he spake, and praised God.

Luke 1:65 And fear came on all that dwelt round about them: and all these sayings were noised abroad throughout all the hill country of Judæa.

Luke 1:66 And all they that heard them laid them up in their hearts, saying, What manner of child shall this be! And the hand of the Lord was with him.

Luke 1:67 And his father Zacharias was filled with the Holy Ghost, and prophesied, saying,

Luke 1:68 Blessed be the Lord God of Israel; for he hath visited and redeemed his people,

Luke 1:69 And hath raised up an horn of salvation for us in the house of his servant David;

Luke 1:70 As he spake by the mouth of his holy prophets, which have been since the world began:

Luke 1:71 That we should be saved from our enemies, and from the hand of all that hate us;

Luke 1:72 To perform the mercy promised to our fathers, and to remember his holy covenant;

Luke 1:73 The oath which he sware to our father Abraham,

Luke 1:74 That he would grant unto us, that we being delivered out of the hand of our enemies might serve him without fear,

Luke 1:75 In holiness and righteousness before him, all the days of our life.

Luke 1:76 And thou, child, shalt be called the prophet of the Highest: for thou shalt go before the face of the Lord to prepare his ways;

Luke 1:77 To give knowledge of salvation unto his people by the remission of their sins,

Luke 1:78 Through the tender mercy of our God; whereby the dayspring from on high hath visited us,

Luke 1:79 To give light to them that sit in darkness and in the shadow of death, to guide our feet into the way of peace.

Luke 1:80 And the child grew, and waxed strong in spirit, and was in the deserts till the day of his shewing unto Israel.
