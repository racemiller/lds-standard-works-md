# John 13

John 13 (summary): Jesus washes the feet of the Twelve—He identifies Judas as His betrayer—He commands them to love one another.

John 13:1 Now before the feast of the passover, when Jesus knew that his hour was come that he should depart out of this world unto the Father, having loved his own which were in the world, he loved them unto the end.

John 13:2 And supper being ended, the devil having now put into the heart of Judas Iscariot, Simon’s son, to betray him;

John 13:3 Jesus knowing that the Father had given all things into his hands, and that he was come from God, and went to God;

John 13:4 He riseth from supper, and laid aside his garments; and took a towel, and girded himself.

John 13:5 After that he poureth water into a basin, and began to wash the disciples’ feet, and to wipe them with the towel wherewith he was girded.

John 13:6 Then cometh he to Simon Peter: and Peter saith unto him, Lord, dost thou wash my feet?

John 13:7 Jesus answered and said unto him, What I do thou knowest not now; but thou shalt know hereafter.

John 13:8 Peter saith unto him, Thou shalt never wash my feet. Jesus answered him, If I wash thee not, thou hast no part with me.

John 13:9 Simon Peter saith unto him, Lord, not my feet only, but also my hands and my head.

John 13:10 Jesus saith to him, He that is washed needeth not save to wash his feet, but is clean every whit: and ye are clean, but not all.

John 13:11 For he knew who should betray him; therefore said he, Ye are not all clean.

John 13:12 So after he had washed their feet, and had taken his garments, and was set down again, he said unto them, Know ye what I have done to you?

John 13:13 Ye call me Master and Lord: and ye say well; for so I am.

John 13:14 If I then, your Lord and Master, have washed your feet; ye also ought to wash one another’s feet.

John 13:15 For I have given you an example, that ye should do as I have done to you.

John 13:16 Verily, verily, I say unto you, The servant is not greater than his lord; neither he that is sent greater than he that sent him.

John 13:17 If ye know these things, happy are ye if ye do them.

John 13:18 I speak not of you all: I know whom I have chosen: but that the scripture may be fulfilled, He that eateth bread with me hath lifted up his heel against me.

John 13:19 Now I tell you before it come, that, when it is come to pass, ye may believe that I am he.

John 13:20 Verily, verily, I say unto you, He that receiveth whomsoever I send receiveth me; and he that receiveth me receiveth him that sent me.

John 13:21 When Jesus had thus said, he was troubled in spirit, and testified, and said, Verily, verily, I say unto you, that one of you shall betray me.

John 13:22 Then the disciples looked one on another, doubting of whom he spake.

John 13:23 Now there was leaning on Jesus’ bosom one of his disciples, whom Jesus loved.

John 13:24 Simon Peter therefore beckoned to him, that he should ask who it should be of whom he spake.

John 13:25 He then lying on Jesus’ breast saith unto him, Lord, who is it?

John 13:26 Jesus answered, He it is, to whom I shall give a sop, when I have dipped it. And when he had dipped the sop, he gave it to Judas Iscariot, the son of Simon.

John 13:27 And after the sop Satan entered into him. Then said Jesus unto him, That thou doest, do quickly.

John 13:28 Now no man at the table knew for what intent he spake this unto him.

John 13:29 For some of them thought, because Judas had the bag, that Jesus had said unto him, Buy those things that we have need of against the feast; or, that he should give something to the poor.

John 13:30 He then having received the sop went immediately out: and it was night.

John 13:31 Therefore, when he was gone out, Jesus said, Now is the Son of man glorified, and God is glorified in him.

John 13:32 If God be glorified in him, God shall also glorify him in himself, and shall straightway glorify him.

John 13:33 Little children, yet a little while I am with you. Ye shall seek me: and as I said unto the Jews, Whither I go, ye cannot come; so now I say to you.

John 13:34 A new commandment I give unto you, That ye love one another; as I have loved you, that ye also love one another.

John 13:35 By this shall all men know that ye are my disciples, if ye have love one to another.

John 13:36 Simon Peter said unto him, Lord, whither goest thou? Jesus answered him, Whither I go, thou canst not follow me now; but thou shalt follow me afterwards.

John 13:37 Peter said unto him, Lord, why cannot I follow thee now? I will lay down my life for thy sake.

John 13:38 Jesus answered him, Wilt thou lay down thy life for my sake? Verily, verily, I say unto thee, The cock shall not crow, till thou hast denied me thrice.
