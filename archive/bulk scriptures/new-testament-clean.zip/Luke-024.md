# Luke 24

Luke 24 (summary): Angels announce the resurrection of Christ—He walks on the Emmaus road—He appears with a body of flesh and bones, eats food, testifies of His divinity, and promises the Holy Ghost—He ascends into heaven.

Luke 24:1 Now upon the first day of the week, very early in the morning, they came unto the sepulchre, bringing the spices which they had prepared, and certain others with them.

Luke 24:2 And they found the stone rolled away from the sepulchre.

Luke 24:3 And they entered in, and found not the body of the Lord Jesus.

Luke 24:4 And it came to pass, as they were much perplexed thereabout, behold, two men stood by them in shining garments:

Luke 24:5 And as they were afraid, and bowed down their faces to the earth, they said unto them, Why seek ye the living among the dead?

Luke 24:6 He is not here, but is risen: remember how he spake unto you when he was yet in Galilee,

Luke 24:7 Saying, The Son of man must be delivered into the hands of sinful men, and be crucified, and the third day rise again.

Luke 24:8 And they remembered his words,

Luke 24:9 And returned from the sepulchre, and told all these things unto the eleven, and to all the rest.

Luke 24:10 It was Mary Magdalene, and Joanna, and Mary the mother of James, and other women that were with them, which told these things unto the apostles.

Luke 24:11 And their words seemed to them as idle tales, and they believed them not.

Luke 24:12 Then arose Peter, and ran unto the sepulchre; and stooping down, he beheld the linen clothes laid by themselves, and departed, wondering in himself at that which was come to pass.

Luke 24:13 And, behold, two of them went that same day to a village called Emmaus, which was from Jerusalem about threescore furlongs.

Luke 24:14 And they talked together of all these things which had happened.

Luke 24:15 And it came to pass, that, while they communed together and reasoned, Jesus himself drew near, and went with them.

Luke 24:16 But their eyes were holden that they should not know him.

Luke 24:17 And he said unto them, What manner of communications are these that ye have one to another, as ye walk, and are sad?

Luke 24:18 And the one of them, whose name was Cleopas, answering said unto him, Art thou only a stranger in Jerusalem, and hast not known the things which are come to pass there in these days?

Luke 24:19 And he said unto them, What things? And they said unto him, Concerning Jesus of Nazareth, which was a prophet mighty in deed and word before God and all the people:

Luke 24:20 And how the chief priests and our rulers delivered him to be condemned to death, and have crucified him.

Luke 24:21 But we trusted that it had been he which should have redeemed Israel: and beside all this, to day is the third day since these things were done.

Luke 24:22 Yea, and certain women also of our company made us astonished, which were early at the sepulchre;

Luke 24:23 And when they found not his body, they came, saying, that they had also seen a vision of angels, which said that he was alive.

Luke 24:24 And certain of them which were with us went to the sepulchre, and found it even so as the women had said: but him they saw not.

Luke 24:25 Then he said unto them, O fools, and slow of heart to believe all that the prophets have spoken:

Luke 24:26 Ought not Christ to have suffered these things, and to enter into his glory?

Luke 24:27 And beginning at Moses and all the prophets, he expounded unto them in all the scriptures the things concerning himself.

Luke 24:28 And they drew nigh unto the village, whither they went: and he made as though he would have gone further.

Luke 24:29 But they constrained him, saying, Abide with us: for it is toward evening, and the day is far spent. And he went in to tarry with them.

Luke 24:30 And it came to pass, as he sat at meat with them, he took bread, and blessed it, and brake, and gave to them.

Luke 24:31 And their eyes were opened, and they knew him; and he vanished out of their sight.

Luke 24:32 And they said one to another, Did not our heart burn within us, while he talked with us by the way, and while he opened to us the scriptures?

Luke 24:33 And they rose up the same hour, and returned to Jerusalem, and found the eleven gathered together, and them that were with them,

Luke 24:34 Saying, The Lord is risen indeed, and hath appeared to Simon.

Luke 24:35 And they told what things were done in the way, and how he was known of them in breaking of bread.

Luke 24:36 And as they thus spake, Jesus himself stood in the midst of them, and saith unto them, Peace be unto you.

Luke 24:37 But they were terrified and affrighted, and supposed that they had seen a spirit.

Luke 24:38 And he said unto them, Why are ye troubled? and why do thoughts arise in your hearts?

Luke 24:39 Behold my hands and my feet, that it is I myself: handle me, and see; for a spirit hath not flesh and bones, as ye see me have.

Luke 24:40 And when he had thus spoken, he shewed them his hands and his feet.

Luke 24:41 And while they yet believed not for joy, and wondered, he said unto them, Have ye here any meat?

Luke 24:42 And they gave him a piece of a broiled fish, and of an honeycomb.

Luke 24:43 And he took it, and did eat before them.

Luke 24:44 And he said unto them, These are the words which I spake unto you, while I was yet with you, that all things must be fulfilled, which were written in the law of Moses, and in the prophets, and in the psalms, concerning me.

Luke 24:45 Then opened he their understanding, that they might understand the scriptures,

Luke 24:46 And said unto them, Thus it is written, and thus it behoved Christ to suffer, and to rise from the dead the third day:

Luke 24:47 And that repentance and remission of sins should be preached in his name among all nations, beginning at Jerusalem.

Luke 24:48 And ye are witnesses of these things.

Luke 24:49 And, behold, I send the promise of my Father upon you: but tarry ye in the city of Jerusalem, until ye be endued with power from on high.

Luke 24:50 And he led them out as far as to Bethany, and he lifted up his hands, and blessed them.

Luke 24:51 And it came to pass, while he blessed them, he was parted from them, and carried up into heaven.

Luke 24:52 And they worshipped him, and returned to Jerusalem with great joy:

Luke 24:53 And were continually in the temple, praising and blessing God. Amen.
