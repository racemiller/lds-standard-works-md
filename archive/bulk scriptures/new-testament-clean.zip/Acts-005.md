# Acts 5

Acts 5 (summary): Ananias and Sapphira lie to the Lord and lose their lives—The Apostles continue the miracles of Jesus—Peter and John are arrested, an angel delivers them from prison, and they testify of Christ—Gamaliel counsels moderation.

Acts 5:1 But a certain man named Ananias, with Sapphira his wife, sold a possession,

Acts 5:2 And kept back part of the price, his wife also being privy to it, and brought a certain part, and laid it at the apostles’ feet.

Acts 5:3 But Peter said, Ananias, why hath Satan filled thine heart to lie to the Holy Ghost, and to keep back part of the price of the land?

Acts 5:4 Whiles it remained, was it not thine own? and after it was sold, was it not in thine own power? why hast thou conceived this thing in thine heart? thou hast not lied unto men, but unto God.

Acts 5:5 And Ananias hearing these words fell down, and gave up the ghost: and great fear came on all them that heard these things.

Acts 5:6 And the young men arose, wound him up, and carried him out, and buried him.

Acts 5:7 And it was about the space of three hours after, when his wife, not knowing what was done, came in.

Acts 5:8 And Peter answered unto her, Tell me whether ye sold the land for so much? And she said, Yea, for so much.

Acts 5:9 Then Peter said unto her, How is it that ye have agreed together to tempt the Spirit of the Lord? behold, the feet of them which have buried thy husband are at the door, and shall carry thee out.

Acts 5:10 Then fell she down straightway at his feet, and yielded up the ghost: and the young men came in, and found her dead, and, carrying her forth, buried her by her husband.

Acts 5:11 And great fear came upon all the church, and upon as many as heard these things.

Acts 5:12 And by the hands of the apostles were many signs and wonders wrought among the people; (and they were all with one accord in Solomon’s porch.

Acts 5:13 And of the rest durst no man join himself to them: but the people magnified them.

Acts 5:14 And believers were the more added to the Lord, multitudes both of men and women.)

Acts 5:15 Insomuch that they brought forth the sick into the streets, and laid them on beds and couches, that at the least the shadow of Peter passing by might overshadow some of them.

Acts 5:16 There came also a multitude out of the cities round about unto Jerusalem, bringing sick folks, and them which were vexed with unclean spirits: and they were healed every one.

Acts 5:17 Then the high priest rose up, and all they that were with him, (which is the sect of the Sadducees,) and were filled with indignation,

Acts 5:18 And laid their hands on the apostles, and put them in the common prison.

Acts 5:19 But the angel of the Lord by night opened the prison doors, and brought them forth, and said,

Acts 5:20 Go, stand and speak in the temple to the people all the words of this life.

Acts 5:21 And when they heard that, they entered into the temple early in the morning, and taught. But the high priest came, and they that were with him, and called the council together, and all the senate of the children of Israel, and sent to the prison to have them brought.

Acts 5:22 But when the officers came, and found them not in the prison, they returned, and told,

Acts 5:23 Saying, The prison truly found we shut with all safety, and the keepers standing without before the doors: but when we had opened, we found no man within.

Acts 5:24 Now when the high priest and the captain of the temple and the chief priests heard these things, they doubted of them whereunto this would grow.

Acts 5:25 Then came one and told them, saying, Behold, the men whom ye put in prison are standing in the temple, and teaching the people.

Acts 5:26 Then went the captain with the officers, and brought them without violence: for they feared the people, lest they should have been stoned.

Acts 5:27 And when they had brought them, they set them before the council: and the high priest asked them,

Acts 5:28 Saying, Did not we straitly command you that ye should not teach in this name? and, behold, ye have filled Jerusalem with your doctrine, and intend to bring this man’s blood upon us.

Acts 5:29 Then Peter and the other apostles answered and said, We ought to obey God rather than men.

Acts 5:30 The God of our fathers raised up Jesus, whom ye slew and hanged on a tree.

Acts 5:31 Him hath God exalted with his right hand to be a Prince and a Saviour, for to give repentance to Israel, and forgiveness of sins.

Acts 5:32 And we are his witnesses of these things; and so is also the Holy Ghost, whom God hath given to them that obey him.

Acts 5:33 When they heard that, they were cut to the heart, and took counsel to slay them.

Acts 5:34 Then stood there up one in the council, a Pharisee, named Gamaliel, a doctor of the law, had in reputation among all the people, and commanded to put the apostles forth a little space;

Acts 5:35 And said unto them, Ye men of Israel, take heed to yourselves what ye intend to do as touching these men.

Acts 5:36 For before these days rose up Theudas, boasting himself to be somebody; to whom a number of men, about four hundred, joined themselves: who was slain; and all, as many as obeyed him, were scattered, and brought to nought.

Acts 5:37 After this man rose up Judas of Galilee in the days of the taxing, and drew away much people after him: he also perished; and all, even as many as obeyed him, were dispersed.

Acts 5:38 And now I say unto you, Refrain from these men, and let them alone: for if this counsel or this work be of men, it will come to nought:

Acts 5:39 But if it be of God, ye cannot overthrow it; lest haply ye be found even to fight against God.

Acts 5:40 And to him they agreed: and when they had called the apostles, and beaten them, they commanded that they should not speak in the name of Jesus, and let them go.

Acts 5:41 And they departed from the presence of the council, rejoicing that they were counted worthy to suffer shame for his name.

Acts 5:42 And daily in the temple, and in every house, they ceased not to teach and preach Jesus Christ.
