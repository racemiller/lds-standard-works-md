# Hebrews 5

Hebrews 5 (summary): For a man to hold the priesthood, he must be called of God as was Aaron—Christ was a priest forever after the order of Melchizedek—Jesus Christ is the Author of eternal salvation.

Hebrews 5:1 For every high priest taken from among men is ordained for men in things pertaining to God, that he may offer both gifts and sacrifices for sins:

Hebrews 5:2 Who can have compassion on the ignorant, and on them that are out of the way; for that he himself also is compassed with infirmity.

Hebrews 5:3 And by reason hereof he ought, as for the people, so also for himself, to offer for sins.

Hebrews 5:4 And no man taketh this honour unto himself, but he that is called of God, as was Aaron.

Hebrews 5:5 So also Christ glorified not himself to be made an high priest; but he that said unto him, Thou art my Son, to day have I begotten thee.

Hebrews 5:6 As he saith also in another place, Thou art a priest for ever after the order of Melchisedec.

Hebrews 5:7 Who in the days of his flesh, when he had offered up prayers and supplications with strong crying and tears unto him that was able to save him from death, and was heard in that he feared;

Hebrews 5:8 Though he were a Son, yet learned he obedience by the things which he suffered;

Hebrews 5:9 And being made perfect, he became the author of eternal salvation unto all them that obey him;

Hebrews 5:10 Called of God an high priest after the order of Melchisedec.

Hebrews 5:11 Of whom we have many things to say, and hard to be uttered, seeing ye are dull of hearing.

Hebrews 5:12 For when for the time ye ought to be teachers, ye have need that one teach you again which be the first principles of the oracles of God; and are become such as have need of milk, and not of strong meat.

Hebrews 5:13 For every one that useth milk is unskilful in the word of righteousness: for he is a babe.

Hebrews 5:14 But strong meat belongeth to them that are of full age, even those who by reason of use have their senses exercised to discern both good and evil.
