# John 6

John 6 (summary): Jesus feeds the five thousand—He walks on the sea—He is the living manna sent from God—Salvation is gained by eating living bread—Jesus explains how men eat His flesh and drink His blood—Peter testifies that Jesus is the Messiah.

John 6:1 After these things Jesus went over the sea of Galilee, which is the sea of Tiberias.

John 6:2 And a great multitude followed him, because they saw his miracles which he did on them that were diseased.

John 6:3 And Jesus went up into a mountain, and there he sat with his disciples.

John 6:4 And the passover, a feast of the Jews, was nigh.

John 6:5 When Jesus then lifted up his eyes, and saw a great company come unto him, he saith unto Philip, Whence shall we buy bread, that these may eat?

John 6:6 And this he said to prove him: for he himself knew what he would do.

John 6:7 Philip answered him, Two hundred pennyworth of bread is not sufficient for them, that every one of them may take a little.

John 6:8 One of his disciples, Andrew, Simon Peter’s brother, saith unto him,

John 6:9 There is a lad here, which hath five barley loaves, and two small fishes: but what are they among so many?

John 6:10 And Jesus said, Make the men sit down. Now there was much grass in the place. So the men sat down, in number about five thousand.

John 6:11 And Jesus took the loaves; and when he had given thanks, he distributed to the disciples, and the disciples to them that were set down; and likewise of the fishes as much as they would.

John 6:12 When they were filled, he said unto his disciples, Gather up the fragments that remain, that nothing be lost.

John 6:13 Therefore they gathered them together, and filled twelve baskets with the fragments of the five barley loaves, which remained over and above unto them that had eaten.

John 6:14 Then those men, when they had seen the miracle that Jesus did, said, This is of a truth that prophet that should come into the world.

John 6:15 When Jesus therefore perceived that they would come and take him by force, to make him a king, he departed again into a mountain himself alone.

John 6:16 And when even was now come, his disciples went down unto the sea,

John 6:17 And entered into a ship, and went over the sea toward Capernaum. And it was now dark, and Jesus was not come to them.

John 6:18 And the sea arose by reason of a great wind that blew.

John 6:19 So when they had rowed about five and twenty or thirty furlongs, they see Jesus walking on the sea, and drawing nigh unto the ship: and they were afraid.

John 6:20 But he saith unto them, It is I; be not afraid.

John 6:21 Then they willingly received him into the ship: and immediately the ship was at the land whither they went.

John 6:22 The day following, when the people which stood on the other side of the sea saw that there was none other boat there, save that one whereinto his disciples were entered, and that Jesus went not with his disciples into the boat, but that his disciples were gone away alone;

John 6:23 (Howbeit there came other boats from Tiberias nigh unto the place where they did eat bread, after that the Lord had given thanks:)

John 6:24 When the people therefore saw that Jesus was not there, neither his disciples, they also took shipping, and came to Capernaum, seeking for Jesus.

John 6:25 And when they had found him on the other side of the sea, they said unto him, Rabbi, when camest thou hither?

John 6:26 Jesus answered them and said, Verily, verily, I say unto you, Ye seek me, not because ye saw the miracles, but because ye did eat of the loaves, and were filled.

John 6:27 Labour not for the meat which perisheth, but for that meat which endureth unto everlasting life, which the Son of man shall give unto you: for him hath God the Father sealed.

John 6:28 Then said they unto him, What shall we do, that we might work the works of God?

John 6:29 Jesus answered and said unto them, This is the work of God, that ye believe on him whom he hath sent.

John 6:30 They said therefore unto him, What sign shewest thou then, that we may see, and believe thee? what dost thou work?

John 6:31 Our fathers did eat manna in the desert; as it is written, He gave them bread from heaven to eat.

John 6:32 Then Jesus said unto them, Verily, verily, I say unto you, Moses gave you not that bread from heaven; but my Father giveth you the true bread from heaven.

John 6:33 For the bread of God is he which cometh down from heaven, and giveth life unto the world.

John 6:34 Then said they unto him, Lord, evermore give us this bread.

John 6:35 And Jesus said unto them, I am the bread of life: he that cometh to me shall never hunger; and he that believeth on me shall never thirst.

John 6:36 But I said unto you, That ye also have seen me, and believe not.

John 6:37 All that the Father giveth me shall come to me; and him that cometh to me I will in no wise cast out.

John 6:38 For I came down from heaven, not to do mine own will, but the will of him that sent me.

John 6:39 And this is the Father’s will which hath sent me, that of all which he hath given me I should lose nothing, but should raise it up again at the last day.

John 6:40 And this is the will of him that sent me, that every one which seeth the Son, and believeth on him, may have everlasting life: and I will raise him up at the last day.

John 6:41 The Jews then murmured at him, because he said, I am the bread which came down from heaven.

John 6:42 And they said, Is not this Jesus, the son of Joseph, whose father and mother we know? how is it then that he saith, I came down from heaven?

John 6:43 Jesus therefore answered and said unto them, Murmur not among yourselves.

John 6:44 No man can come to me, except the Father which hath sent me draw him: and I will raise him up at the last day.

John 6:45 It is written in the prophets, And they shall be all taught of God. Every man therefore that hath heard, and hath learned of the Father, cometh unto me.

John 6:46 Not that any man hath seen the Father, save he which is of God, he hath seen the Father.

John 6:47 Verily, verily, I say unto you, He that believeth on me hath everlasting life.

John 6:48 I am that bread of life.

John 6:49 Your fathers did eat manna in the wilderness, and are dead.

John 6:50 This is the bread which cometh down from heaven, that a man may eat thereof, and not die.

John 6:51 I am the living bread which came down from heaven: if any man eat of this bread, he shall live for ever: and the bread that I will give is my flesh, which I will give for the life of the world.

John 6:52 The Jews therefore strove among themselves, saying, How can this man give us his flesh to eat?

John 6:53 Then Jesus said unto them, Verily, verily, I say unto you, Except ye eat the flesh of the Son of man, and drink his blood, ye have no life in you.

John 6:54 Whoso eateth my flesh, and drinketh my blood, hath eternal life; and I will raise him up at the last day.

John 6:55 For my flesh is meat indeed, and my blood is drink indeed.

John 6:56 He that eateth my flesh, and drinketh my blood, dwelleth in me, and I in him.

John 6:57 As the living Father hath sent me, and I live by the Father: so he that eateth me, even he shall live by me.

John 6:58 This is that bread which came down from heaven: not as your fathers did eat manna, and are dead: he that eateth of this bread shall live for ever.

John 6:59 These things said he in the synagogue, as he taught in Capernaum.

John 6:60 Many therefore of his disciples, when they had heard this, said, This is an hard saying; who can hear it?

John 6:61 When Jesus knew in himself that his disciples murmured at it, he said unto them, Doth this offend you?

John 6:62 What and if ye shall see the Son of man ascend up where he was before?

John 6:63 It is the spirit that quickeneth; the flesh profiteth nothing: the words that I speak unto you, they are spirit, and they are life.

John 6:64 But there are some of you that believe not. For Jesus knew from the beginning who they were that believed not, and who should betray him.

John 6:65 And he said, Therefore said I unto you, that no man can come unto me, except it were given unto him of my Father.

John 6:66 From that time many of his disciples went back, and walked no more with him.

John 6:67 Then said Jesus unto the twelve, Will ye also go away?

John 6:68 Then Simon Peter answered him, Lord, to whom shall we go? thou hast the words of eternal life.

John 6:69 And we believe and are sure that thou art that Christ, the Son of the living God.

John 6:70 Jesus answered them, Have not I chosen you twelve, and one of you is a devil?

John 6:71 He spake of Judas Iscariot the son of Simon: for he it was that should betray him, being one of the twelve.
