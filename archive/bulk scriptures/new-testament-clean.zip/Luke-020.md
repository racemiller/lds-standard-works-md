# Luke 20

Luke 20 (summary): The chief priests oppose Jesus—He gives the parable of the wicked husbandmen—Render unto Cæsar and God that which is theirs—Jesus teaches the law of marriage.

Luke 20:1 And it came to pass, that on one of those days, as he taught the people in the temple, and preached the gospel, the chief priests and the scribes came upon him with the elders,

Luke 20:2 And spake unto him, saying, Tell us, by what authority doest thou these things? or who is he that gave thee this authority?

Luke 20:3 And he answered and said unto them, I will also ask you one thing; and answer me:

Luke 20:4 The baptism of John, was it from heaven, or of men?

Luke 20:5 And they reasoned with themselves, saying, If we shall say, From heaven; he will say, Why then believed ye him not?

Luke 20:6 But and if we say, Of men; all the people will stone us: for they be persuaded that John was a prophet.

Luke 20:7 And they answered, that they could not tell whence it was.

Luke 20:8 And Jesus said unto them, Neither tell I you by what authority I do these things.

Luke 20:9 Then began he to speak to the people this parable; A certain man planted a vineyard, and let it forth to husbandmen, and went into a far country for a long time.

Luke 20:10 And at the season he sent a servant to the husbandmen, that they should give him of the fruit of the vineyard: but the husbandmen beat him, and sent him away empty.

Luke 20:11 And again he sent another servant: and they beat him also, and entreated him shamefully, and sent him away empty.

Luke 20:12 And again he sent a third: and they wounded him also, and cast him out.

Luke 20:13 Then said the lord of the vineyard, What shall I do? I will send my beloved son: it may be they will reverence him when they see him.

Luke 20:14 But when the husbandmen saw him, they reasoned among themselves, saying, This is the heir: come, let us kill him, that the inheritance may be ours.

Luke 20:15 So they cast him out of the vineyard, and killed him. What therefore shall the lord of the vineyard do unto them?

Luke 20:16 He shall come and destroy these husbandmen, and shall give the vineyard to others. And when they heard it, they said, God forbid.

Luke 20:17 And he beheld them, and said, What is this then that is written, The stone which the builders rejected, the same is become the head of the corner?

Luke 20:18 Whosoever shall fall upon that stone shall be broken; but on whomsoever it shall fall, it will grind him to powder.

Luke 20:19 And the chief priests and the scribes the same hour sought to lay hands on him; and they feared the people: for they perceived that he had spoken this parable against them.

Luke 20:20 And they watched him, and sent forth spies, which should feign themselves just men, that they might take hold of his words, that so they might deliver him unto the power and authority of the governor.

Luke 20:21 And they asked him, saying, Master, we know that thou sayest and teachest rightly, neither acceptest thou the person of any, but teachest the way of God truly:

Luke 20:22 Is it lawful for us to give tribute unto Cæsar, or no?

Luke 20:23 But he perceived their craftiness, and said unto them, Why tempt ye me?

Luke 20:24 Shew me a penny. Whose image and superscription hath it? They answered and said, Cæsar’s.

Luke 20:25 And he said unto them, Render therefore unto Cæsar the things which be Cæsar’s, and unto God the things which be God’s.

Luke 20:26 And they could not take hold of his words before the people: and they marvelled at his answer, and held their peace.

Luke 20:27 Then came to him certain of the Sadducees, which deny that there is any resurrection; and they asked him,

Luke 20:28 Saying, Master, Moses wrote unto us, If any man’s brother die, having a wife, and he die without children, that his brother should take his wife, and raise up seed unto his brother.

Luke 20:29 There were therefore seven brethren: and the first took a wife, and died without children.

Luke 20:30 And the second took her to wife, and he died childless.

Luke 20:31 And the third took her; and in like manner the seven also: and they left no children, and died.

Luke 20:32 Last of all the woman died also.

Luke 20:33 Therefore in the resurrection whose wife of them is she? for seven had her to wife.

Luke 20:34 And Jesus answering said unto them, The children of this world marry, and are given in marriage:

Luke 20:35 But they which shall be accounted worthy to obtain that world, and the resurrection from the dead, neither marry, nor are given in marriage:

Luke 20:36 Neither can they die any more: for they are equal unto the angels; and are the children of God, being the children of the resurrection.

Luke 20:37 Now that the dead are raised, even Moses shewed at the bush, when he calleth the Lord the God of Abraham, and the God of Isaac, and the God of Jacob.

Luke 20:38 For he is not a God of the dead, but of the living: for all live unto him.

Luke 20:39 Then certain of the scribes answering said, Master, thou hast well said.

Luke 20:40 And after that they durst not ask him any question at all.

Luke 20:41 And he said unto them, How say they that Christ is David’s son?

Luke 20:42 And David himself saith in the book of Psalms, The Lord said unto my Lord, Sit thou on my right hand,

Luke 20:43 Till I make thine enemies thy footstool.

Luke 20:44 David therefore calleth him Lord, how is he then his son?

Luke 20:45 Then in the audience of all the people he said unto his disciples,

Luke 20:46 Beware of the scribes, which desire to walk in long robes, and love greetings in the markets, and the highest seats in the synagogues, and the chief rooms at feasts;

Luke 20:47 Which devour widows’ houses, and for a shew make long prayers: the same shall receive greater damnation.
