# Acts 1

Acts 1 (summary): Jesus ministers for forty days after His resurrection—The kingdom is to be restored to Israel at a later time—The Twelve are to bear witness in Jerusalem, Judæa, Samaria, and the uttermost parts of the earth—Jesus ascends into heaven—Matthias is chosen to fill the vacancy in the Twelve.

Acts 1:1 The former treatise have I made, O Theophilus, of all that Jesus began both to do and teach,

Acts 1:2 Until the day in which he was taken up, after that he through the Holy Ghost had given commandments unto the apostles whom he had chosen:

Acts 1:3 To whom also he shewed himself alive after his passion by many infallible proofs, being seen of them forty days, and speaking of the things pertaining to the kingdom of God:

Acts 1:4 And, being assembled together with them, commanded them that they should not depart from Jerusalem, but wait for the promise of the Father, which, saith he, ye have heard of me.

Acts 1:5 For John truly baptized with water; but ye shall be baptized with the Holy Ghost not many days hence.

Acts 1:6 When they therefore were come together, they asked of him, saying, Lord, wilt thou at this time restore again the kingdom to Israel?

Acts 1:7 And he said unto them, It is not for you to know the times or the seasons, which the Father hath put in his own power.

Acts 1:8 But ye shall receive power, after that the Holy Ghost is come upon you: and ye shall be witnesses unto me both in Jerusalem, and in all Judæa, and in Samaria, and unto the uttermost part of the earth.

Acts 1:9 And when he had spoken these things, while they beheld, he was taken up; and a cloud received him out of their sight.

Acts 1:10 And while they looked steadfastly toward heaven as he went up, behold, two men stood by them in white apparel;

Acts 1:11 Which also said, Ye men of Galilee, why stand ye gazing up into heaven? this same Jesus, which is taken up from you into heaven, shall so come in like manner as ye have seen him go into heaven.

Acts 1:12 Then returned they unto Jerusalem from the mount called Olivet, which is from Jerusalem a sabbath day’s journey.

Acts 1:13 And when they were come in, they went up into an upper room, where abode both Peter, and James, and John, and Andrew, Philip, and Thomas, Bartholomew, and Matthew, James the son of Alphæus, and Simon Zelotes, and Judas the brother of James.

Acts 1:14 These all continued with one accord in prayer and supplication, with the women, and Mary the mother of Jesus, and with his brethren.

Acts 1:15 And in those days Peter stood up in the midst of the disciples, and said, (the number of names together were about an hundred and twenty,)

Acts 1:16 Men and brethren, this scripture must needs have been fulfilled, which the Holy Ghost by the mouth of David spake before concerning Judas, which was guide to them that took Jesus.

Acts 1:17 For he was numbered with us, and had obtained part of this ministry.

Acts 1:18 Now this man purchased a field with the reward of iniquity; and falling headlong, he burst asunder in the midst, and all his bowels gushed out.

Acts 1:19 And it was known unto all the dwellers at Jerusalem; insomuch as that field is called in their proper tongue, Aceldama, that is to say, The field of blood.

Acts 1:20 For it is written in the book of Psalms, Let his habitation be desolate, and let no man dwell therein: and his bishoprick let another take.

Acts 1:21 Wherefore of these men which have companied with us all the time that the Lord Jesus went in and out among us,

Acts 1:22 Beginning from the baptism of John, unto that same day that he was taken up from us, must one be ordained to be a witness with us of his resurrection.

Acts 1:23 And they appointed two, Joseph called Barsabas, who was surnamed Justus, and Matthias.

Acts 1:24 And they prayed, and said, Thou, Lord, which knowest the hearts of all men, shew whether of these two thou hast chosen,

Acts 1:25 That he may take part of this ministry and apostleship, from which Judas by transgression fell, that he might go to his own place.

Acts 1:26 And they gave forth their lots; and the lot fell upon Matthias; and he was numbered with the eleven apostles.
