# John 9

John 9 (summary): Jesus, on the Sabbath, heals a man born blind—The Jews accuse Him of Sabbath violation—He lectures them on spiritual blindness.

John 9:1 And as Jesus passed by, he saw a man which was blind from his birth.

John 9:2 And his disciples asked him, saying, Master, who did sin, this man, or his parents, that he was born blind?

John 9:3 Jesus answered, Neither hath this man sinned, nor his parents: but that the works of God should be made manifest in him.

John 9:4 I must work the works of him that sent me, while it is day: the night cometh, when no man can work.

John 9:5 As long as I am in the world, I am the light of the world.

John 9:6 When he had thus spoken, he spat on the ground, and made clay of the spittle, and he anointed the eyes of the blind man with the clay,

John 9:7 And said unto him, Go, wash in the pool of Siloam, (which is by interpretation, Sent.) He went his way therefore, and washed, and came seeing.

John 9:8 The neighbours therefore, and they which before had seen him that he was blind, said, Is not this he that sat and begged?

John 9:9 Some said, This is he: others said, He is like him: but he said, I am he.

John 9:10 Therefore said they unto him, How were thine eyes opened?

John 9:11 He answered and said, A man that is called Jesus made clay, and anointed mine eyes, and said unto me, Go to the pool of Siloam, and wash: and I went and washed, and I received sight.

John 9:12 Then said they unto him, Where is he? He said, I know not.

John 9:13 They brought to the Pharisees him that aforetime was blind.

John 9:14 And it was the sabbath day when Jesus made the clay, and opened his eyes.

John 9:15 Then again the Pharisees also asked him how he had received his sight. He said unto them, He put clay upon mine eyes, and I washed, and do see.

John 9:16 Therefore said some of the Pharisees, This man is not of God, because he keepeth not the sabbath day. Others said, How can a man that is a sinner do such miracles? And there was a division among them.

John 9:17 They say unto the blind man again, What sayest thou of him, that he hath opened thine eyes? He said, He is a prophet.

John 9:18 But the Jews did not believe concerning him, that he had been blind, and received his sight, until they called the parents of him that had received his sight.

John 9:19 And they asked them, saying, Is this your son, who ye say was born blind? how then doth he now see?

John 9:20 His parents answered them and said, We know that this is our son, and that he was born blind:

John 9:21 But by what means he now seeth, we know not; or who hath opened his eyes, we know not: he is of age; ask him: he shall speak for himself.

John 9:22 These words spake his parents, because they feared the Jews: for the Jews had agreed already, that if any man did confess that he was Christ, he should be put out of the synagogue.

John 9:23 Therefore said his parents, He is of age; ask him.

John 9:24 Then again called they the man that was blind, and said unto him, Give God the praise: we know that this man is a sinner.

John 9:25 He answered and said, Whether he be a sinner or no, I know not: one thing I know, that, whereas I was blind, now I see.

John 9:26 Then said they to him again, What did he to thee? how opened he thine eyes?

John 9:27 He answered them, I have told you already, and ye did not hear: wherefore would ye hear it again? will ye also be his disciples?

John 9:28 Then they reviled him, and said, Thou art his disciple; but we are Moses’ disciples.

John 9:29 We know that God spake unto Moses: as for this fellow, we know not from whence he is.

John 9:30 The man answered and said unto them, Why herein is a marvellous thing, that ye know not from whence he is, and yet he hath opened mine eyes.

John 9:31 Now we know that God heareth not sinners: but if any man be a worshipper of God, and doeth his will, him he heareth.

John 9:32 Since the world began was it not heard that any man opened the eyes of one that was born blind.

John 9:33 If this man were not of God, he could do nothing.

John 9:34 They answered and said unto him, Thou wast altogether born in sins, and dost thou teach us? And they cast him out.

John 9:35 Jesus heard that they had cast him out; and when he had found him, he said unto him, Dost thou believe on the Son of God?

John 9:36 He answered and said, Who is he, Lord, that I might believe on him?

John 9:37 And Jesus said unto him, Thou hast both seen him, and it is he that talketh with thee.

John 9:38 And he said, Lord, I believe. And he worshipped him.

John 9:39 And Jesus said, For judgment I am come into this world, that they which see not might see; and that they which see might be made blind.

John 9:40 And some of the Pharisees which were with him heard these words, and said unto him, Are we blind also?

John 9:41 Jesus said unto them, If ye were blind, ye should have no sin: but now ye say, We see; therefore your sin remaineth.
