# 2 Chronicles 18

2 Chronicles 18 (summary): Jehoshaphat of Judah joins Ahab of Israel to fight Syria—Ahab’s false prophets foretell victory—Micaiah prophesies the fall and death of Ahab—The Syrians slay Ahab.

2 Chronicles 18:1 Now Jehoshaphat had riches and honour in abundance, and joined affinity with Ahab.

2 Chronicles 18:2 And after certain years he went down to Ahab to Samaria. And Ahab killed sheep and oxen for him in abundance, and for the people that he had with him, and persuaded him to go up with him to Ramoth-gilead.

2 Chronicles 18:3 And Ahab king of Israel said unto Jehoshaphat king of Judah, Wilt thou go with me to Ramoth-gilead? And he answered him, I am as thou art, and my people as thy people; and we will be with thee in the war.

2 Chronicles 18:4 And Jehoshaphat said unto the king of Israel, Inquire, I pray thee, at the word of the Lord to day.

2 Chronicles 18:5 Therefore the king of Israel gathered together of prophets four hundred men, and said unto them, Shall we go to Ramoth-gilead to battle, or shall I forbear? And they said, Go up; for God will deliver it into the king’s hand.

2 Chronicles 18:6 But Jehoshaphat said, Is there not here a prophet of the Lord besides, that we might inquire of him?

2 Chronicles 18:7 And the king of Israel said unto Jehoshaphat, There is yet one man, by whom we may inquire of the Lord: but I hate him; for he never prophesied good unto me, but always evil: the same is Micaiah the son of Imla. And Jehoshaphat said, Let not the king say so.

2 Chronicles 18:8 And the king of Israel called for one of his officers, and said, Fetch quickly Micaiah the son of Imla.

2 Chronicles 18:9 And the king of Israel and Jehoshaphat king of Judah sat either of them on his throne, clothed in their robes, and they sat in a void place at the entering in of the gate of Samaria; and all the prophets prophesied before them.

2 Chronicles 18:10 And Zedekiah the son of Chenaanah had made him horns of iron, and said, Thus saith the Lord, With these thou shalt push Syria until they be consumed.

2 Chronicles 18:11 And all the prophets prophesied so, saying, Go up to Ramoth-gilead, and prosper: for the Lord shall deliver it into the hand of the king.

2 Chronicles 18:12 And the messenger that went to call Micaiah spake to him, saying, Behold, the words of the prophets declare good to the king with one assent; let thy word therefore, I pray thee, be like one of theirs, and speak thou good.

2 Chronicles 18:13 And Micaiah said, As the Lord liveth, even what my God saith, that will I speak.

2 Chronicles 18:14 And when he was come to the king, the king said unto him, Micaiah, shall we go to Ramoth-gilead to battle, or shall I forbear? And he said, Go ye up, and prosper, and they shall be delivered into your hand.

2 Chronicles 18:15 And the king said to him, How many times shall I adjure thee that thou say nothing but the truth to me in the name of the Lord?

2 Chronicles 18:16 Then he said, I did see all Israel scattered upon the mountains, as sheep that have no shepherd: and the Lord said, These have no master; let them return therefore every man to his house in peace.

2 Chronicles 18:17 And the king of Israel said to Jehoshaphat, Did I not tell thee that he would not prophesy good unto me, but evil?

2 Chronicles 18:18 Again he said, Therefore hear the word of the Lord; I saw the Lord sitting upon his throne, and all the host of heaven standing on his right hand and on his left.

2 Chronicles 18:19 And the Lord said, Who shall entice Ahab king of Israel, that he may go up and fall at Ramoth-gilead? And one spake saying after this manner, and another saying after that manner.

2 Chronicles 18:20 Then there came out a spirit, and stood before the Lord, and said, I will entice him. And the Lord said unto him, Wherewith?

2 Chronicles 18:21 And he said, I will go out, and be a lying spirit in the mouth of all his prophets. And the Lord said, Thou shalt entice him, and thou shalt also prevail: go out, and do even so.

2 Chronicles 18:22 Now therefore, behold, the Lord hath put a lying spirit in the mouth of these thy prophets, and the Lord hath spoken evil against thee.

2 Chronicles 18:23 Then Zedekiah the son of Chenaanah came near, and smote Micaiah upon the cheek, and said, Which way went the Spirit of the Lord from me to speak unto thee?

2 Chronicles 18:24 And Micaiah said, Behold, thou shalt see on that day when thou shalt go into an inner chamber to hide thyself.

2 Chronicles 18:25 Then the king of Israel said, Take ye Micaiah, and carry him back to Amon the governor of the city, and to Joash the king’s son;

2 Chronicles 18:26 And say, Thus saith the king, Put this fellow in the prison, and feed him with bread of affliction and with water of affliction, until I return in peace.

2 Chronicles 18:27 And Micaiah said, If thou certainly return in peace, then hath not the Lord spoken by me. And he said, Hearken, all ye people.

2 Chronicles 18:28 So the king of Israel and Jehoshaphat the king of Judah went up to Ramoth-gilead.

2 Chronicles 18:29 And the king of Israel said unto Jehoshaphat, I will disguise myself, and will go to the battle; but put thou on thy robes. So the king of Israel disguised himself; and they went to the battle.

2 Chronicles 18:30 Now the king of Syria had commanded the captains of the chariots that were with him, saying, Fight ye not with small or great, save only with the king of Israel.

2 Chronicles 18:31 And it came to pass, when the captains of the chariots saw Jehoshaphat, that they said, It is the king of Israel. Therefore they compassed about him to fight: but Jehoshaphat cried out, and the Lord helped him; and God moved them to depart from him.

2 Chronicles 18:32 For it came to pass, that, when the captains of the chariots perceived that it was not the king of Israel, they turned back again from pursuing him.

2 Chronicles 18:33 And a certain man drew a bow at a venture, and smote the king of Israel between the joints of the harness: therefore he said to his chariot man, Turn thine hand, that thou mayest carry me out of the host; for I am wounded.

2 Chronicles 18:34 And the battle increased that day: howbeit the king of Israel stayed himself up in his chariot against the Syrians until the even: and about the time of the sun going down he died.
