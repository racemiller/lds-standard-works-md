# Jeremiah 37

Jeremiah 37 (summary): Jeremiah prophesies that Egypt will not save Judah from Babylon—He is cast into a dungeon—Zedekiah transfers him to the court of the prison.

Jeremiah 37:1 And king Zedekiah the son of Josiah reigned instead of Coniah the son of Jehoiakim, whom Nebuchadrezzar king of Babylon made king in the land of Judah.

Jeremiah 37:2 But neither he, nor his servants, nor the people of the land, did hearken unto the words of the Lord, which he spake by the prophet Jeremiah.

Jeremiah 37:3 And Zedekiah the king sent Jehucal the son of Shelemiah and Zephaniah the son of Maaseiah the priest to the prophet Jeremiah, saying, Pray now unto the Lord our God for us.

Jeremiah 37:4 Now Jeremiah came in and went out among the people: for they had not put him into prison.

Jeremiah 37:5 Then Pharaoh’s army was come forth out of Egypt: and when the Chaldeans that besieged Jerusalem heard tidings of them, they departed from Jerusalem.

Jeremiah 37:6 Then came the word of the Lord unto the prophet Jeremiah, saying,

Jeremiah 37:7 Thus saith the Lord, the God of Israel; Thus shall ye say to the king of Judah, that sent you unto me to inquire of me; Behold, Pharaoh’s army, which is come forth to help you, shall return to Egypt into their own land.

Jeremiah 37:8 And the Chaldeans shall come again, and fight against this city, and take it, and burn it with fire.

Jeremiah 37:9 Thus saith the Lord; Deceive not yourselves, saying, The Chaldeans shall surely depart from us: for they shall not depart.

Jeremiah 37:10 For though ye had smitten the whole army of the Chaldeans that fight against you, and there remained but wounded men among them, yet should they rise up every man in his tent, and burn this city with fire.

Jeremiah 37:11 And it came to pass, that when the army of the Chaldeans was broken up from Jerusalem for fear of Pharaoh’s army,

Jeremiah 37:12 Then Jeremiah went forth out of Jerusalem to go into the land of Benjamin, to separate himself thence in the midst of the people.

Jeremiah 37:13 And when he was in the gate of Benjamin, a captain of the ward was there, whose name was Irijah, the son of Shelemiah, the son of Hananiah; and he took Jeremiah the prophet, saying, Thou fallest away to the Chaldeans.

Jeremiah 37:14 Then said Jeremiah, It is false; I fall not away to the Chaldeans. But he hearkened not to him: so Irijah took Jeremiah, and brought him to the princes.

Jeremiah 37:15 Wherefore the princes were wroth with Jeremiah, and smote him, and put him in prison in the house of Jonathan the scribe: for they had made that the prison.

Jeremiah 37:16 When Jeremiah was entered into the dungeon, and into the cabins, and Jeremiah had remained there many days;

Jeremiah 37:17 Then Zedekiah the king sent, and took him out: and the king asked him secretly in his house, and said, Is there any word from the Lord? And Jeremiah said, There is: for, said he, thou shalt be delivered into the hand of the king of Babylon.

Jeremiah 37:18 Moreover Jeremiah said unto king Zedekiah, What have I offended against thee, or against thy servants, or against this people, that ye have put me in prison?

Jeremiah 37:19 Where are now your prophets which prophesied unto you, saying, The king of Babylon shall not come against you, nor against this land?

Jeremiah 37:20 Therefore hear now, I pray thee, O my lord the king: let my supplication, I pray thee, be accepted before thee; that thou cause me not to return to the house of Jonathan the scribe, lest I die there.

Jeremiah 37:21 Then Zedekiah the king commanded that they should commit Jeremiah into the court of the prison, and that they should give him daily a piece of bread out of the bakers’ street, until all the bread in the city were spent. Thus Jeremiah remained in the court of the prison.
