# Judges 6

Judges 6 (summary): Israel is in bondage to the Midianites—An angel appears to Gideon and calls him to deliver Israel—He overthrows the altar of Baal, the Spirit of the Lord rests upon him, and the Lord gives him a sign to show he is called to deliver Israel.

Judges 6:1 And the children of Israel did evil in the sight of the Lord: and the Lord delivered them into the hand of Midian seven years.

Judges 6:2 And the hand of Midian prevailed against Israel: and because of the Midianites the children of Israel made them the dens which are in the mountains, and caves, and strong holds.

Judges 6:3 And so it was, when Israel had sown, that the Midianites came up, and the Amalekites, and the children of the east, even they came up against them;

Judges 6:4 And they encamped against them, and destroyed the increase of the earth, till thou come unto Gaza, and left no sustenance for Israel, neither sheep, nor ox, nor ass.

Judges 6:5 For they came up with their cattle and their tents, and they came as grasshoppers for multitude; for both they and their camels were without number: and they entered into the land to destroy it.

Judges 6:6 And Israel was greatly impoverished because of the Midianites; and the children of Israel cried unto the Lord.

Judges 6:7 And it came to pass, when the children of Israel cried unto the Lord because of the Midianites,

Judges 6:8 That the Lord sent a prophet unto the children of Israel, which said unto them, Thus saith the Lord God of Israel, I brought you up from Egypt, and brought you forth out of the house of bondage;

Judges 6:9 And I delivered you out of the hand of the Egyptians, and out of the hand of all that oppressed you, and drave them out from before you, and gave you their land;

Judges 6:10 And I said unto you, I am the Lord your God; fear not the gods of the Amorites, in whose land ye dwell: but ye have not obeyed my voice.

Judges 6:11 And there came an angel of the Lord, and sat under an oak which was in Ophrah, that pertained unto Joash the Abi-ezrite: and his son Gideon threshed wheat by the winepress, to hide it from the Midianites.

Judges 6:12 And the angel of the Lord appeared unto him, and said unto him, The Lord is with thee, thou mighty man of valour.

Judges 6:13 And Gideon said unto him, Oh my Lord, if the Lord be with us, why then is all this befallen us? and where be all his miracles which our fathers told us of, saying, Did not the Lord bring us up from Egypt? but now the Lord hath forsaken us, and delivered us into the hands of the Midianites.

Judges 6:14 And the Lord looked upon him, and said, Go in this thy might, and thou shalt save Israel from the hand of the Midianites: have not I sent thee?

Judges 6:15 And he said unto him, Oh my Lord, wherewith shall I save Israel? behold, my family is poor in Manasseh, and I am the least in my father’s house.

Judges 6:16 And the Lord said unto him, Surely I will be with thee, and thou shalt smite the Midianites as one man.

Judges 6:17 And he said unto him, If now I have found grace in thy sight, then shew me a sign that thou talkest with me.

Judges 6:18 Depart not hence, I pray thee, until I come unto thee, and bring forth my present, and set it before thee. And he said, I will tarry until thou come again.

Judges 6:19 And Gideon went in, and made ready a kid, and unleavened cakes of an ephah of flour: the flesh he put in a basket, and he put the broth in a pot, and brought it out unto him under the oak, and presented it.

Judges 6:20 And the angel of God said unto him, Take the flesh and the unleavened cakes, and lay them upon this rock, and pour out the broth. And he did so.

Judges 6:21 Then the angel of the Lord put forth the end of the staff that was in his hand, and touched the flesh and the unleavened cakes; and there rose up fire out of the rock, and consumed the flesh and the unleavened cakes. Then the angel of the Lord departed out of his sight.

Judges 6:22 And when Gideon perceived that he was an angel of the Lord, Gideon said, Alas, O Lord God! for because I have seen an angel of the Lord face to face.

Judges 6:23 And the Lord said unto him, Peace be unto thee; fear not: thou shalt not die.

Judges 6:24 Then Gideon built an altar there unto the Lord, and called it Jehovah-shalom: unto this day it is yet in Ophrah of the Abi-ezrites.

Judges 6:25 And it came to pass the same night, that the Lord said unto him, Take thy father’s young bullock, even the second bullock of seven years old, and throw down the altar of Baal that thy father hath, and cut down the grove that is by it:

Judges 6:26 And build an altar unto the Lord thy God upon the top of this rock, in the ordered place, and take the second bullock, and offer a burnt sacrifice with the wood of the grove which thou shalt cut down.

Judges 6:27 Then Gideon took ten men of his servants, and did as the Lord had said unto him: and so it was, because he feared his father’s household, and the men of the city, that he could not do it by day, that he did it by night.

Judges 6:28 And when the men of the city arose early in the morning, behold, the altar of Baal was cast down, and the grove was cut down that was by it, and the second bullock was offered upon the altar that was built.

Judges 6:29 And they said one to another, Who hath done this thing? And when they inquired and asked, they said, Gideon the son of Joash hath done this thing.

Judges 6:30 Then the men of the city said unto Joash, Bring out thy son, that he may die: because he hath cast down the altar of Baal, and because he hath cut down the grove that was by it.

Judges 6:31 And Joash said unto all that stood against him, Will ye plead for Baal? will ye save him? he that will plead for him, let him be put to death whilst it is yet morning: if he be a god, let him plead for himself, because one hath cast down his altar.

Judges 6:32 Therefore on that day he called him Jerubbaal, saying, Let Baal plead against him, because he hath thrown down his altar.

Judges 6:33 Then all the Midianites and the Amalekites and the children of the east were gathered together, and went over, and pitched in the valley of Jezreel.

Judges 6:34 But the Spirit of the Lord came upon Gideon, and he blew a trumpet; and Abi-ezer was gathered after him.

Judges 6:35 And he sent messengers throughout all Manasseh; who also was gathered after him: and he sent messengers unto Asher, and unto Zebulun, and unto Naphtali; and they came up to meet them.

Judges 6:36 And Gideon said unto God, If thou wilt save Israel by mine hand, as thou hast said,

Judges 6:37 Behold, I will put a fleece of wool in the floor; and if the dew be on the fleece only, and it be dry upon all the earth beside, then shall I know that thou wilt save Israel by mine hand, as thou hast said.

Judges 6:38 And it was so: for he rose up early on the morrow, and thrust the fleece together, and wringed the dew out of the fleece, a bowl full of water.

Judges 6:39 And Gideon said unto God, Let not thine anger be hot against me, and I will speak but this once: let me prove, I pray thee, but this once with the fleece; let it now be dry only upon the fleece, and upon all the ground let there be dew.

Judges 6:40 And God did so that night: for it was dry upon the fleece only, and there was dew on all the ground.
