# Psalms 115

Psalms 115 (summary): Our God is in the heavens—Idols are false gods—Trust in the Lord.

Psalms 115:1 Not unto us, O Lord, not unto us, but unto thy name give glory, for thy mercy, and for thy truth’s sake.

Psalms 115:2 Wherefore should the heathen say, Where is now their God?

Psalms 115:3 But our God is in the heavens: he hath done whatsoever he hath pleased.

Psalms 115:4 Their idols are silver and gold, the work of men’s hands.

Psalms 115:5 They have mouths, but they speak not: eyes have they, but they see not:

Psalms 115:6 They have ears, but they hear not: noses have they, but they smell not:

Psalms 115:7 They have hands, but they handle not: feet have they, but they walk not: neither speak they through their throat.

Psalms 115:8 They that make them are like unto them; so is every one that trusteth in them.

Psalms 115:9 O Israel, trust thou in the Lord: he is their help and their shield.

Psalms 115:10 O house of Aaron, trust in the Lord: he is their help and their shield.

Psalms 115:11 Ye that fear the Lord, trust in the Lord: he is their help and their shield.

Psalms 115:12 The Lord hath been mindful of us: he will bless us; he will bless the house of Israel; he will bless the house of Aaron.

Psalms 115:13 He will bless them that fear the Lord, both small and great.

Psalms 115:14 The Lord shall increase you more and more, you and your children.

Psalms 115:15 Ye are blessed of the Lord which made heaven and earth.

Psalms 115:16 The heaven, even the heavens, are the Lord’s: but the earth hath he given to the children of men.

Psalms 115:17 The dead praise not the Lord, neither any that go down into silence.

Psalms 115:18 But we will bless the Lord from this time forth and for evermore. Praise the Lord.
