# Ezekiel 21

Ezekiel 21 (summary): Both the righteous and the wicked in Jerusalem will be slain—Babylon will draw a sharp and bright sword against Israel and will prevail.

Ezekiel 21:1 And the word of the Lord came unto me, saying,

Ezekiel 21:2 Son of man, set thy face toward Jerusalem, and drop thy word toward the holy places, and prophesy against the land of Israel,

Ezekiel 21:3 And say to the land of Israel, Thus saith the Lord; Behold, I am against thee, and will draw forth my sword out of his sheath, and will cut off from thee the righteous and the wicked.

Ezekiel 21:4 Seeing then that I will cut off from thee the righteous and the wicked, therefore shall my sword go forth out of his sheath against all flesh from the south to the north:

Ezekiel 21:5 That all flesh may know that I the Lord have drawn forth my sword out of his sheath: it shall not return any more.

Ezekiel 21:6 Sigh therefore, thou son of man, with the breaking of thy loins; and with bitterness sigh before their eyes.

Ezekiel 21:7 And it shall be, when they say unto thee, Wherefore sighest thou? that thou shalt answer, For the tidings; because it cometh: and every heart shall melt, and all hands shall be feeble, and every spirit shall faint, and all knees shall be weak as water: behold, it cometh, and shall be brought to pass, saith the Lord God.

Ezekiel 21:8 Again the word of the Lord came unto me, saying,

Ezekiel 21:9 Son of man, prophesy, and say, Thus saith the Lord; Say, A sword, a sword is sharpened, and also furbished:

Ezekiel 21:10 It is sharpened to make a sore slaughter; it is furbished that it may glitter: should we then make mirth? it contemneth the rod of my son, as every tree.

Ezekiel 21:11 And he hath given it to be furbished, that it may be handled: this sword is sharpened, and it is furbished, to give it into the hand of the slayer.

Ezekiel 21:12 Cry and howl, son of man: for it shall be upon my people, it shall be upon all the princes of Israel: terrors by reason of the sword shall be upon my people: smite therefore upon thy thigh.

Ezekiel 21:13 Because it is a trial, and what if the sword contemn even the rod? it shall be no more, saith the Lord God.

Ezekiel 21:14 Thou therefore, son of man, prophesy, and smite thine hands together, and let the sword be doubled the third time, the sword of the slain: it is the sword of the great men that are slain, which entereth into their privy chambers.

Ezekiel 21:15 I have set the point of the sword against all their gates, that their heart may faint, and their ruins be multiplied: ah! it is made bright, it is wrapped up for the slaughter.

Ezekiel 21:16 Go thee one way or other, either on the right hand, or on the left, whithersoever thy face is set.

Ezekiel 21:17 I will also smite mine hands together, and I will cause my fury to rest: I the Lord have said it.

Ezekiel 21:18 The word of the Lord came unto me again, saying,

Ezekiel 21:19 Also, thou son of man, appoint thee two ways, that the sword of the king of Babylon may come: both twain shall come forth out of one land: and choose thou a place, choose it at the head of the way to the city.

Ezekiel 21:20 Appoint a way, that the sword may come to Rabbath of the Ammonites, and to Judah in Jerusalem the defenced.

Ezekiel 21:21 For the king of Babylon stood at the parting of the way, at the head of the two ways, to use divination: he made his arrows bright, he consulted with images, he looked in the liver.

Ezekiel 21:22 At his right hand was the divination for Jerusalem, to appoint captains, to open the mouth in the slaughter, to lift up the voice with shouting, to appoint battering rams against the gates, to cast a mount, and to build a fort.

Ezekiel 21:23 And it shall be unto them as a false divination in their sight, to them that have sworn oaths: but he will call to remembrance the iniquity, that they may be taken.

Ezekiel 21:24 Therefore thus saith the Lord God; Because ye have made your iniquity to be remembered, in that your transgressions are discovered, so that in all your doings your sins do appear; because, I say, that ye are come to remembrance, ye shall be taken with the hand.

Ezekiel 21:25 And thou, profane wicked prince of Israel, whose day is come, when iniquity shall have an end,

Ezekiel 21:26 Thus saith the Lord God; Remove the diadem, and take off the crown: this shall not be the same: exalt him that is low, and abase him that is high.

Ezekiel 21:27 I will overturn, overturn, overturn, it: and it shall be no more, until he come whose right it is; and I will give it him.

Ezekiel 21:28 And thou, son of man, prophesy and say, Thus saith the Lord God concerning the Ammonites, and concerning their reproach; even say thou, The sword, the sword is drawn: for the slaughter it is furbished, to consume because of the glittering:

Ezekiel 21:29 Whiles they see vanity unto thee, whiles they divine a lie unto thee, to bring thee upon the necks of them that are slain, of the wicked, whose day is come, when their iniquity shall have an end.

Ezekiel 21:30 Shall I cause it to return into his sheath? I will judge thee in the place where thou wast created, in the land of thy nativity.

Ezekiel 21:31 And I will pour out mine indignation upon thee, I will blow against thee in the fire of my wrath, and deliver thee into the hand of brutish men, and skilful to destroy.

Ezekiel 21:32 Thou shalt be for fuel to the fire; thy blood shall be in the midst of the land; thou shalt be no more remembered: for I the Lord have spoken it.
