# 2 Kings 8

2 Kings 8 (summary): Elisha prophesies a seven-year famine—The Shunammite woman is preserved through the famine—Jehoram and then Ahaziah reign in wickedness in Judah.

2 Kings 8:1 Then spake Elisha unto the woman, whose son he had restored to life, saying, Arise, and go thou and thine household, and sojourn wheresoever thou canst sojourn: for the Lord hath called for a famine; and it shall also come upon the land seven years.

2 Kings 8:2 And the woman arose, and did after the saying of the man of God: and she went with her household, and sojourned in the land of the Philistines seven years.

2 Kings 8:3 And it came to pass at the seven years’ end, that the woman returned out of the land of the Philistines: and she went forth to cry unto the king for her house and for her land.

2 Kings 8:4 And the king talked with Gehazi the servant of the man of God, saying, Tell me, I pray thee, all the great things that Elisha hath done.

2 Kings 8:5 And it came to pass, as he was telling the king how he had restored a dead body to life, that, behold, the woman, whose son he had restored to life, cried to the king for her house and for her land. And Gehazi said, My lord, O king, this is the woman, and this is her son, whom Elisha restored to life.

2 Kings 8:6 And when the king asked the woman, she told him. So the king appointed unto her a certain officer, saying, Restore all that was hers, and all the fruits of the field since the day that she left the land, even until now.

2 Kings 8:7 And Elisha came to Damascus; and Ben-hadad the king of Syria was sick; and it was told him, saying, The man of God is come hither.

2 Kings 8:8 And the king said unto Hazael, Take a present in thine hand, and go, meet the man of God, and inquire of the Lord by him, saying, Shall I recover of this disease?

2 Kings 8:9 So Hazael went to meet him, and took a present with him, even of every good thing of Damascus, forty camels’ burden, and came and stood before him, and said, Thy son Ben-hadad king of Syria hath sent me to thee, saying, Shall I recover of this disease?

2 Kings 8:10 And Elisha said unto him, Go, say unto him, Thou mayest certainly recover: howbeit the Lord hath shewed me that he shall surely die.

2 Kings 8:11 And he settled his countenance steadfastly, until he was ashamed: and the man of God wept.

2 Kings 8:12 And Hazael said, Why weepeth my lord? And he answered, Because I know the evil that thou wilt do unto the children of Israel: their strong holds wilt thou set on fire, and their young men wilt thou slay with the sword, and wilt dash their children, and rip up their women with child.

2 Kings 8:13 And Hazael said, But what, is thy servant a dog, that he should do this great thing? And Elisha answered, The Lord hath shewed me that thou shalt be king over Syria.

2 Kings 8:14 So he departed from Elisha, and came to his master; who said to him, What said Elisha to thee? And he answered, He told me that thou shouldest surely recover.

2 Kings 8:15 And it came to pass on the morrow, that he took a thick cloth, and dipped it in water, and spread it on his face, so that he died: and Hazael reigned in his stead.

2 Kings 8:16 And in the fifth year of Joram the son of Ahab king of Israel, Jehoshaphat being then king of Judah, Jehoram the son of Jehoshaphat king of Judah began to reign.

2 Kings 8:17 Thirty and two years old was he when he began to reign; and he reigned eight years in Jerusalem.

2 Kings 8:18 And he walked in the way of the kings of Israel, as did the house of Ahab: for the daughter of Ahab was his wife: and he did evil in the sight of the Lord.

2 Kings 8:19 Yet the Lord would not destroy Judah for David his servant’s sake, as he promised him to give him alway a light, and to his children.

2 Kings 8:20 In his days Edom revolted from under the hand of Judah, and made a king over themselves.

2 Kings 8:21 So Joram went over to Zair, and all the chariots with him: and he rose by night, and smote the Edomites which compassed him about, and the captains of the chariots: and the people fled into their tents.

2 Kings 8:22 Yet Edom revolted from under the hand of Judah unto this day. Then Libnah revolted at the same time.

2 Kings 8:23 And the rest of the acts of Joram, and all that he did, are they not written in the book of the chronicles of the kings of Judah?

2 Kings 8:24 And Joram slept with his fathers, and was buried with his fathers in the city of David: and Ahaziah his son reigned in his stead.

2 Kings 8:25 In the twelfth year of Joram the son of Ahab king of Israel did Ahaziah the son of Jehoram king of Judah begin to reign.

2 Kings 8:26 Two and twenty years old was Ahaziah when he began to reign; and he reigned one year in Jerusalem. And his mother’s name was Athaliah, the daughter of Omri king of Israel.

2 Kings 8:27 And he walked in the way of the house of Ahab, and did evil in the sight of the Lord, as did the house of Ahab: for he was the son in law of the house of Ahab.

2 Kings 8:28 And he went with Joram the son of Ahab to the war against Hazael king of Syria in Ramoth-gilead; and the Syrians wounded Joram.

2 Kings 8:29 And king Joram went back to be healed in Jezreel of the wounds which the Syrians had given him at Ramah, when he fought against Hazael king of Syria. And Ahaziah the son of Jehoram king of Judah went down to see Joram the son of Ahab in Jezreel, because he was sick.
