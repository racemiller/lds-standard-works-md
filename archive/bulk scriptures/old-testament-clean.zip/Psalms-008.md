# Psalms 8

Psalms 8 (summary): A messianic psalm of David—He says that babes and children praise the Lord—He asks, What is man, that Thou art mindful of him?

Psalms 8:1 O Lord our Lord, how excellent is thy name in all the earth! who hast set thy glory above the heavens.

Psalms 8:2 Out of the mouth of babes and sucklings hast thou ordained strength because of thine enemies, that thou mightest still the enemy and the avenger.

Psalms 8:3 When I consider thy heavens, the work of thy fingers, the moon and the stars, which thou hast ordained;

Psalms 8:4 What is man, that thou art mindful of him? and the son of man, that thou visitest him?

Psalms 8:5 For thou hast made him a little lower than the angels, and hast crowned him with glory and honour.

Psalms 8:6 Thou madest him to have dominion over the works of thy hands; thou hast put all things under his feet:

Psalms 8:7 All sheep and oxen, yea, and the beasts of the field;

Psalms 8:8 The fowl of the air, and the fish of the sea, and whatsoever passeth through the paths of the seas.

Psalms 8:9 O Lord our Lord, how excellent is thy name in all the earth!
