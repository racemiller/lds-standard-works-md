# Proverbs 21

Proverbs 21 (summary): Do righteousness and justice—Follow after righteousness and mercy—Safety comes from the Lord.

Proverbs 21:1 The king’s heart is in the hand of the Lord, as the rivers of water: he turneth it whithersoever he will.

Proverbs 21:2 Every way of a man is right in his own eyes: but the Lord pondereth the hearts.

Proverbs 21:3 To do justice and judgment is more acceptable to the Lord than sacrifice.

Proverbs 21:4 An high look, and a proud heart, and the plowing of the wicked, is sin.

Proverbs 21:5 The thoughts of the diligent tend only to plenteousness; but of every one that is hasty only to want.

Proverbs 21:6 The getting of treasures by a lying tongue is a vanity tossed to and fro of them that seek death.

Proverbs 21:7 The robbery of the wicked shall destroy them; because they refuse to do judgment.

Proverbs 21:8 The way of man is froward and strange: but as for the pure, his work is right.

Proverbs 21:9 It is better to dwell in a corner of the housetop, than with a brawling woman in a wide house.

Proverbs 21:10 The soul of the wicked desireth evil: his neighbour findeth no favour in his eyes.

Proverbs 21:11 When the scorner is punished, the simple is made wise: and when the wise is instructed, he receiveth knowledge.

Proverbs 21:12 The righteous man wisely considereth the house of the wicked: but God overthroweth the wicked for their wickedness.

Proverbs 21:13 Whoso stoppeth his ears at the cry of the poor, he also shall cry himself, but shall not be heard.

Proverbs 21:14 A gift in secret pacifieth anger: and a reward in the bosom strong wrath.

Proverbs 21:15 It is joy to the just to do judgment: but destruction shall be to the workers of iniquity.

Proverbs 21:16 The man that wandereth out of the way of understanding shall remain in the congregation of the dead.

Proverbs 21:17 He that loveth pleasure shall be a poor man: he that loveth wine and oil shall not be rich.

Proverbs 21:18 The wicked shall be a ransom for the righteous, and the transgressor for the upright.

Proverbs 21:19 It is better to dwell in the wilderness, than with a contentious and an angry woman.

Proverbs 21:20 There is treasure to be desired and oil in the dwelling of the wise; but a foolish man spendeth it up.

Proverbs 21:21 He that followeth after righteousness and mercy findeth life, righteousness, and honour.

Proverbs 21:22 A wise man scaleth the city of the mighty, and casteth down the strength of the confidence thereof.

Proverbs 21:23 Whoso keepeth his mouth and his tongue keepeth his soul from troubles.

Proverbs 21:24 Proud and haughty scorner is his name, who dealeth in proud wrath.

Proverbs 21:25 The desire of the slothful killeth him; for his hands refuse to labour.

Proverbs 21:26 He coveteth greedily all the day long: but the righteous giveth and spareth not.

Proverbs 21:27 The sacrifice of the wicked is abomination: how much more, when he bringeth it with a wicked mind?

Proverbs 21:28 A false witness shall perish: but the man that heareth speaketh constantly.

Proverbs 21:29 A wicked man hardeneth his face: but as for the upright, he directeth his way.

Proverbs 21:30 There is no wisdom nor understanding nor counsel against the Lord.

Proverbs 21:31 The horse is prepared against the day of battle: but safety is of the Lord.
