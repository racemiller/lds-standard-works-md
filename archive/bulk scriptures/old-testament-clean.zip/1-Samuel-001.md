# 1 Samuel 1

1 Samuel 1 (summary): Hannah prays for a son and vows to give him to the Lord—Eli the priest blesses her—Samuel is born—Hannah loans him to the Lord.

1 Samuel 1:1 Now there was a certain man of Ramathaim-zophim, of mount Ephraim, and his name was Elkanah, the son of Jeroham, the son of Elihu, the son of Tohu, the son of Zuph, an Ephrathite:

1 Samuel 1:2 And he had two wives; the name of the one was Hannah, and the name of the other Peninnah: and Peninnah had children, but Hannah had no children.

1 Samuel 1:3 And this man went up out of his city yearly to worship and to sacrifice unto the Lord of hosts in Shiloh. And the two sons of Eli, Hophni and Phinehas, the priests of the Lord, were there.

1 Samuel 1:4 And when the time was that Elkanah offered, he gave to Peninnah his wife, and to all her sons and her daughters, portions:

1 Samuel 1:5 But unto Hannah he gave a worthy portion; for he loved Hannah: but the Lord had shut up her womb.

1 Samuel 1:6 And her adversary also provoked her sore, for to make her fret, because the Lord had shut up her womb.

1 Samuel 1:7 And as he did so year by year, when she went up to the house of the Lord, so she provoked her; therefore she wept, and did not eat.

1 Samuel 1:8 Then said Elkanah her husband to her, Hannah, why weepest thou? and why eatest thou not? and why is thy heart grieved? am not I better to thee than ten sons?

1 Samuel 1:9 So Hannah rose up after they had eaten in Shiloh, and after they had drunk. Now Eli the priest sat upon a seat by a post of the temple of the Lord.

1 Samuel 1:10 And she was in bitterness of soul, and prayed unto the Lord, and wept sore.

1 Samuel 1:11 And she vowed a vow, and said, O Lord of hosts, if thou wilt indeed look on the affliction of thine handmaid, and remember me, and not forget thine handmaid, but wilt give unto thine handmaid a man child, then I will give him unto the Lord all the days of his life, and there shall no razor come upon his head.

1 Samuel 1:12 And it came to pass, as she continued praying before the Lord, that Eli marked her mouth.

1 Samuel 1:13 Now Hannah, she spake in her heart; only her lips moved, but her voice was not heard: therefore Eli thought she had been drunken.

1 Samuel 1:14 And Eli said unto her, How long wilt thou be drunken? put away thy wine from thee.

1 Samuel 1:15 And Hannah answered and said, No, my lord, I am a woman of a sorrowful spirit: I have drunk neither wine nor strong drink, but have poured out my soul before the Lord.

1 Samuel 1:16 Count not thine handmaid for a daughter of Belial: for out of the abundance of my complaint and grief have I spoken hitherto.

1 Samuel 1:17 Then Eli answered and said, Go in peace: and the God of Israel grant thee thy petition that thou hast asked of him.

1 Samuel 1:18 And she said, Let thine handmaid find grace in thy sight. So the woman went her way, and did eat, and her countenance was no more sad.

1 Samuel 1:19 And they rose up in the morning early, and worshipped before the Lord, and returned, and came to their house to Ramah: and Elkanah knew Hannah his wife; and the Lord remembered her.

1 Samuel 1:20 Wherefore it came to pass, when the time was come about after Hannah had conceived, that she bare a son, and called his name Samuel, saying, Because I have asked him of the Lord.

1 Samuel 1:21 And the man Elkanah, and all his house, went up to offer unto the Lord the yearly sacrifice, and his vow.

1 Samuel 1:22 But Hannah went not up; for she said unto her husband, I will not go up until the child be weaned, and then I will bring him, that he may appear before the Lord, and there abide for ever.

1 Samuel 1:23 And Elkanah her husband said unto her, Do what seemeth thee good; tarry until thou have weaned him; only the Lord establish his word. So the woman abode, and gave her son suck until she weaned him.

1 Samuel 1:24 And when she had weaned him, she took him up with her, with three bullocks, and one ephah of flour, and a bottle of wine, and brought him unto the house of the Lord in Shiloh: and the child was young.

1 Samuel 1:25 And they slew a bullock, and brought the child to Eli.

1 Samuel 1:26 And she said, Oh my lord, as thy soul liveth, my lord, I am the woman that stood by thee here, praying unto the Lord.

1 Samuel 1:27 For this child I prayed; and the Lord hath given me my petition which I asked of him:

1 Samuel 1:28 Therefore also I have lent him to the Lord; as long as he liveth he shall be lent to the Lord. And he worshipped the Lord there.
