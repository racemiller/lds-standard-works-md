# Genesis 6

Genesis 6 (summary): The sons of God marry the daughters of men—Men turn to wickedness, the earth is filled with violence, and all flesh is corrupted—The Flood is promised—God establishes His covenant with Noah, who builds an ark to save his family and various living things.

Genesis 6:1 And it came to pass, when men began to multiply on the face of the earth, and daughters were born unto them,

Genesis 6:2 That the sons of God saw the daughters of men that they were fair; and they took them wives of all which they chose.

Genesis 6:3 And the Lord said, My spirit shall not always strive with man, for that he also is flesh: yet his days shall be an hundred and twenty years.

Genesis 6:4 There were giants in the earth in those days; and also after that, when the sons of God came in unto the daughters of men, and they bare children to them, the same became mighty men which were of old, men of renown.

Genesis 6:5 And God saw that the wickedness of man was great in the earth, and that every imagination of the thoughts of his heart was only evil continually.

Genesis 6:6 And it repented the Lord that he had made man on the earth, and it grieved him at his heart.

Genesis 6:7 And the Lord said, I will destroy man whom I have created from the face of the earth; both man, and beast, and the creeping thing, and the fowls of the air; for it repenteth me that I have made them.

Genesis 6:8 But Noah found grace in the eyes of the Lord.

Genesis 6:9 These are the generations of Noah: Noah was a just man and perfect in his generations, and Noah walked with God.

Genesis 6:10 And Noah begat three sons, Shem, Ham, and Japheth.

Genesis 6:11 The earth also was corrupt before God, and the earth was filled with violence.

Genesis 6:12 And God looked upon the earth, and, behold, it was corrupt; for all flesh had corrupted his way upon the earth.

Genesis 6:13 And God said unto Noah, The end of all flesh is come before me; for the earth is filled with violence through them; and, behold, I will destroy them with the earth.

Genesis 6:14 Make thee an ark of gopher wood; rooms shalt thou make in the ark, and shalt pitch it within and without with pitch.

Genesis 6:15 And this is the fashion which thou shalt make it of: The length of the ark shall be three hundred cubits, the breadth of it fifty cubits, and the height of it thirty cubits.

Genesis 6:16 A window shalt thou make to the ark, and in a cubit shalt thou finish it above; and the door of the ark shalt thou set in the side thereof; with lower, second, and third stories shalt thou make it.

Genesis 6:17 And, behold, I, even I, do bring a flood of waters upon the earth, to destroy all flesh, wherein is the breath of life, from under heaven; and every thing that is in the earth shall die.

Genesis 6:18 But with thee will I establish my covenant; and thou shalt come into the ark, thou, and thy sons, and thy wife, and thy sons’ wives with thee.

Genesis 6:19 And of every living thing of all flesh, two of every sort shalt thou bring into the ark, to keep them alive with thee; they shall be male and female.

Genesis 6:20 Of fowls after their kind, and of cattle after their kind, of every creeping thing of the earth after his kind, two of every sort shall come unto thee, to keep them alive.

Genesis 6:21 And take thou unto thee of all food that is eaten, and thou shalt gather it to thee; and it shall be for food for thee, and for them.

Genesis 6:22 Thus did Noah; according to all that God commanded him, so did he.
