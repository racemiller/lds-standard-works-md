# Joshua 19

Joshua 19 (summary): Simeon, Zebulun, Issachar, Asher, Naphtali, and Dan receive their inheritances by lot.

Joshua 19:1 And the second lot came forth to Simeon, even for the tribe of the children of Simeon according to their families: and their inheritance was within the inheritance of the children of Judah.

Joshua 19:2 And they had in their inheritance Beer-sheba, or Sheba, and Moladah,

Joshua 19:3 And Hazar-shual, and Balah, and Azem,

Joshua 19:4 And Eltolad, and Bethul, and Hormah,

Joshua 19:5 And Ziklag, and Beth-marcaboth, and Hazar-susah,

Joshua 19:6 And Beth-lebaoth, and Sharuhen; thirteen cities and their villages:

Joshua 19:7 Ain, Remmon, and Ether, and Ashan; four cities and their villages:

Joshua 19:8 And all the villages that were round about these cities to Baalath-beer, Ramath of the south. This is the inheritance of the tribe of the children of Simeon according to their families.

Joshua 19:9 Out of the portion of the children of Judah was the inheritance of the children of Simeon: for the part of the children of Judah was too much for them: therefore the children of Simeon had their inheritance within the inheritance of them.

Joshua 19:10 And the third lot came up for the children of Zebulun according to their families: and the border of their inheritance was unto Sarid:

Joshua 19:11 And their border went up toward the sea, and Maralah, and reached to Dabbasheth, and reached to the river that is before Jokneam;

Joshua 19:12 And turned from Sarid eastward toward the sunrising unto the border of Chisloth-tabor, and then goeth out to Daberath, and goeth up to Japhia,

Joshua 19:13 And from thence passeth on along on the east to Gittah-hepher, to Ittah-kazin, and goeth out to Remmon-methoar to Neah;

Joshua 19:14 And the border compasseth it on the north side to Hannathon: and the outgoings thereof are in the valley of Jiphthah-el:

Joshua 19:15 And Kattath, and Nahallal, and Shimron, and Idalah, and Beth-lehem: twelve cities with their villages.

Joshua 19:16 This is the inheritance of the children of Zebulun according to their families, these cities with their villages.

Joshua 19:17 And the fourth lot came out to Issachar, for the children of Issachar according to their families.

Joshua 19:18 And their border was toward Jezreel, and Chesulloth, and Shunem,

Joshua 19:19 And Hapharaim, and Shion, and Anaharath,

Joshua 19:20 And Rabbith, and Kishion, and Abez,

Joshua 19:21 And Remeth, and En-gannim, and En-haddah, and Beth-pazzez;

Joshua 19:22 And the coast reacheth to Tabor, and Shahazimah, and Beth-shemesh; and the outgoings of their border were at Jordan: sixteen cities with their villages.

Joshua 19:23 This is the inheritance of the tribe of the children of Issachar according to their families, the cities and their villages.

Joshua 19:24 And the fifth lot came out for the tribe of the children of Asher according to their families.

Joshua 19:25 And their border was Helkath, and Hali, and Beten, and Achshaph,

Joshua 19:26 And Alammelech, and Amad, and Misheal; and reacheth to Carmel westward, and to Shihor-libnath;

Joshua 19:27 And turneth toward the sunrising to Beth-dagon, and reacheth to Zebulun, and to the valley of Jiphthah-el toward the north side of Beth-emek, and Neiel, and goeth out to Cabul on the left hand,

Joshua 19:28 And Hebron, and Rehob, and Hammon, and Kanah, even unto great Zidon;

Joshua 19:29 And then the coast turneth to Ramah, and to the strong city Tyre; and the coast turneth to Hosah; and the outgoings thereof are at the sea from the coast to Achzib:

Joshua 19:30 Ummah also, and Aphek, and Rehob: twenty and two cities with their villages.

Joshua 19:31 This is the inheritance of the tribe of the children of Asher according to their families, these cities with their villages.

Joshua 19:32 The sixth lot came out to the children of Naphtali, even for the children of Naphtali according to their families.

Joshua 19:33 And their coast was from Heleph, from Allon to Zaanannim, and Adami, Nekeb, and Jabneel, unto Lakum; and the outgoings thereof were at Jordan:

Joshua 19:34 And then the coast turneth westward to Aznoth-tabor, and goeth out from thence to Hukkok, and reacheth to Zebulun on the south side, and reacheth to Asher on the west side, and to Judah upon Jordan toward the sunrising.

Joshua 19:35 And the fenced cities are Ziddim, Zer, and Hammath, Rakkath, and Chinnereth,

Joshua 19:36 And Adamah, and Ramah, and Hazor,

Joshua 19:37 And Kedesh, and Edrei, and En-hazor,

Joshua 19:38 And Iron, and Migdal-el, Horem, and Beth-anath, and Beth-shemesh; nineteen cities with their villages.

Joshua 19:39 This is the inheritance of the tribe of the children of Naphtali according to their families, the cities and their villages.

Joshua 19:40 And the seventh lot came out for the tribe of the children of Dan according to their families.

Joshua 19:41 And the coast of their inheritance was Zorah, and Eshtaol, and Ir-shemesh,

Joshua 19:42 And Shaalabbin, and Ajalon, and Jethlah,

Joshua 19:43 And Elon, and Thimnathah, and Ekron,

Joshua 19:44 And Eltekeh, and Gibbethon, and Baalath,

Joshua 19:45 And Jehud, and Bene-berak, and Gath-rimmon,

Joshua 19:46 And Me-jarkon, and Rakkon, with the border before Japho.

Joshua 19:47 And the coast of the children of Dan went out too little for them: therefore the children of Dan went up to fight against Leshem, and took it, and smote it with the edge of the sword, and possessed it, and dwelt therein, and called Leshem, Dan, after the name of Dan their father.

Joshua 19:48 This is the inheritance of the tribe of the children of Dan according to their families, these cities with their villages.

Joshua 19:49 When they had made an end of dividing the land for inheritance by their coasts, the children of Israel gave an inheritance to Joshua the son of Nun among them:

Joshua 19:50 According to the word of the Lord they gave him the city which he asked, even Timnath-serah in mount Ephraim: and he built the city, and dwelt therein.

Joshua 19:51 These are the inheritances, which Eleazar the priest, and Joshua the son of Nun, and the heads of the fathers of the tribes of the children of Israel, divided for an inheritance by lot in Shiloh before the Lord, at the door of the tabernacle of the congregation. So they made an end of dividing the country.
