# 2 Kings 25

2 Kings 25 (summary): Nebuchadnezzar again besieges Jerusalem—Zedekiah is captured, Jerusalem and the temple are destroyed, and most of the people of Judah are carried into Babylon—Gedaliah, left to govern the remnant, is slain—The remnant flee to Egypt—Jehoiachin is shown favor in Babylon.

2 Kings 25:1 And it came to pass in the ninth year of his reign, in the tenth month, in the tenth day of the month, that Nebuchadnezzar king of Babylon came, he, and all his host, against Jerusalem, and pitched against it; and they built forts against it round about.

2 Kings 25:2 And the city was besieged unto the eleventh year of king Zedekiah.

2 Kings 25:3 And on the ninth day of the fourth month the famine prevailed in the city, and there was no bread for the people of the land.

2 Kings 25:4 And the city was broken up, and all the men of war fled by night by the way of the gate between two walls, which is by the king’s garden: (now the Chaldees were against the city round about:) and the king went the way toward the plain.

2 Kings 25:5 And the army of the Chaldees pursued after the king, and overtook him in the plains of Jericho: and all his army were scattered from him.

2 Kings 25:6 So they took the king, and brought him up to the king of Babylon to Riblah; and they gave judgment upon him.

2 Kings 25:7 And they slew the sons of Zedekiah before his eyes, and put out the eyes of Zedekiah, and bound him with fetters of brass, and carried him to Babylon.

2 Kings 25:8 And in the fifth month, on the seventh day of the month, which is the nineteenth year of king Nebuchadnezzar king of Babylon, came Nebuzar-adan, captain of the guard, a servant of the king of Babylon, unto Jerusalem:

2 Kings 25:9 And he burnt the house of the Lord, and the king’s house, and all the houses of Jerusalem, and every great man’s house burnt he with fire.

2 Kings 25:10 And all the army of the Chaldees, that were with the captain of the guard, brake down the walls of Jerusalem round about.

2 Kings 25:11 Now the rest of the people that were left in the city, and the fugitives that fell away to the king of Babylon, with the remnant of the multitude, did Nebuzar-adan the captain of the guard carry away.

2 Kings 25:12 But the captain of the guard left of the poor of the land to be vinedressers and husbandmen.

2 Kings 25:13 And the pillars of brass that were in the house of the Lord, and the bases, and the brasen sea that was in the house of the Lord, did the Chaldees break in pieces, and carried the brass of them to Babylon.

2 Kings 25:14 And the pots, and the shovels, and the snuffers, and the spoons, and all the vessels of brass wherewith they ministered, took they away.

2 Kings 25:15 And the firepans, and the bowls, and such things as were of gold, in gold, and of silver, in silver, the captain of the guard took away.

2 Kings 25:16 The two pillars, one sea, and the bases which Solomon had made for the house of the Lord; the brass of all these vessels was without weight.

2 Kings 25:17 The height of the one pillar was eighteen cubits, and the chapiter upon it was brass: and the height of the chapiter three cubits; and the wreathen work, and pomegranates upon the chapiter round about, all of brass: and like unto these had the second pillar with wreathen work.

2 Kings 25:18 And the captain of the guard took Seraiah the chief priest, and Zephaniah the second priest, and the three keepers of the door:

2 Kings 25:19 And out of the city he took an officer that was set over the men of war, and five men of them that were in the king’s presence, which were found in the city, and the principal scribe of the host, which mustered the people of the land, and threescore men of the people of the land that were found in the city:

2 Kings 25:20 And Nebuzar-adan captain of the guard took these, and brought them to the king of Babylon to Riblah:

2 Kings 25:21 And the king of Babylon smote them, and slew them at Riblah in the land of Hamath. So Judah was carried away out of their land.

2 Kings 25:22 And as for the people that remained in the land of Judah, whom Nebuchadnezzar king of Babylon had left, even over them he made Gedaliah the son of Ahikam, the son of Shaphan, ruler.

2 Kings 25:23 And when all the captains of the armies, they and their men, heard that the king of Babylon had made Gedaliah governor, there came to Gedaliah to Mizpah, even Ishmael the son of Nethaniah, and Johanan the son of Careah, and Seraiah the son of Tanhumeth the Netophathite, and Jaazaniah the son of a Maachathite, they and their men.

2 Kings 25:24 And Gedaliah sware to them, and to their men, and said unto them, Fear not to be the servants of the Chaldees: dwell in the land, and serve the king of Babylon; and it shall be well with you.

2 Kings 25:25 But it came to pass in the seventh month, that Ishmael the son of Nethaniah, the son of Elishama, of the seed royal, came, and ten men with him, and smote Gedaliah, that he died, and the Jews and the Chaldees that were with him at Mizpah.

2 Kings 25:26 And all the people, both small and great, and the captains of the armies, arose, and came to Egypt: for they were afraid of the Chaldees.

2 Kings 25:27 And it came to pass in the seven and thirtieth year of the captivity of Jehoiachin king of Judah, in the twelfth month, on the seven and twentieth day of the month, that Evil-merodach king of Babylon in the year that he began to reign did lift up the head of Jehoiachin king of Judah out of prison;

2 Kings 25:28 And he spake kindly to him, and set his throne above the throne of the kings that were with him in Babylon;

2 Kings 25:29 And changed his prison garments: and he did eat bread continually before him all the days of his life.

2 Kings 25:30 And his allowance was a continual allowance given him of the king, a daily rate for every day, all the days of his life.
