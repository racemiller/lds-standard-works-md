# Psalms 88

Psalms 88 (summary): A prayer of one who feels forsaken and who asks whether the Lord’s loving kindness will be declared in the grave.

Psalms 88:1 O Lord God of my salvation, I have cried day and night before thee:

Psalms 88:2 Let my prayer come before thee: incline thine ear unto my cry;

Psalms 88:3 For my soul is full of troubles: and my life draweth nigh unto the grave.

Psalms 88:4 I am counted with them that go down into the pit: I am as a man that hath no strength:

Psalms 88:5 Free among the dead, like the slain that lie in the grave, whom thou rememberest no more: and they are cut off from thy hand.

Psalms 88:6 Thou hast laid me in the lowest pit, in darkness, in the deeps.

Psalms 88:7 Thy wrath lieth hard upon me, and thou hast afflicted me with all thy waves. Selah.

Psalms 88:8 Thou hast put away mine acquaintance far from me; thou hast made me an abomination unto them: I am shut up, and I cannot come forth.

Psalms 88:9 Mine eye mourneth by reason of affliction: Lord, I have called daily upon thee, I have stretched out my hands unto thee.

Psalms 88:10 Wilt thou shew wonders to the dead? shall the dead arise and praise thee? Selah.

Psalms 88:11 Shall thy lovingkindness be declared in the grave? or thy faithfulness in destruction?

Psalms 88:12 Shall thy wonders be known in the dark? and thy righteousness in the land of forgetfulness?

Psalms 88:13 But unto thee have I cried, O Lord; and in the morning shall my prayer prevent thee.

Psalms 88:14 Lord, why castest thou off my soul? why hidest thou thy face from me?

Psalms 88:15 I am afflicted and ready to die from my youth up: while I suffer thy terrors I am distracted.

Psalms 88:16 Thy fierce wrath goeth over me; thy terrors have cut me off.

Psalms 88:17 They came round about me daily like water; they compassed me about together.

Psalms 88:18 Lover and friend hast thou put far from me, and mine acquaintance into darkness.
