# Proverbs 17

Proverbs 17 (summary): He who is glad at calamities will be punished—A friend loves at all times—Even a fool, when he holds his peace, is counted wise.

Proverbs 17:1 Better is a dry morsel, and quietness therewith, than an house full of sacrifices with strife.

Proverbs 17:2 A wise servant shall have rule over a son that causeth shame, and shall have part of the inheritance among the brethren.

Proverbs 17:3 The fining pot is for silver, and the furnace for gold: but the Lord trieth the hearts.

Proverbs 17:4 A wicked doer giveth heed to false lips; and a liar giveth ear to a naughty tongue.

Proverbs 17:5 Whoso mocketh the poor reproacheth his Maker: and he that is glad at calamities shall not be unpunished.

Proverbs 17:6 Children’s children are the crown of old men; and the glory of children are their fathers.

Proverbs 17:7 Excellent speech becometh not a fool: much less do lying lips a prince.

Proverbs 17:8 A gift is as a precious stone in the eyes of him that hath it: whithersoever it turneth, it prospereth.

Proverbs 17:9 He that covereth a transgression seeketh love; but he that repeateth a matter separateth very friends.

Proverbs 17:10 A reproof entereth more into a wise man than an hundred stripes into a fool.

Proverbs 17:11 An evil man seeketh only rebellion: therefore a cruel messenger shall be sent against him.

Proverbs 17:12 Let a bear robbed of her whelps meet a man, rather than a fool in his folly.

Proverbs 17:13 Whoso rewardeth evil for good, evil shall not depart from his house.

Proverbs 17:14 The beginning of strife is as when one letteth out water: therefore leave off contention, before it be meddled with.

Proverbs 17:15 He that justifieth the wicked, and he that condemneth the just, even they both are abomination to the Lord.

Proverbs 17:16 Wherefore is there a price in the hand of a fool to get wisdom, seeing he hath no heart to it?

Proverbs 17:17 A friend loveth at all times, and a brother is born for adversity.

Proverbs 17:18 A man void of understanding striketh hands, and becometh surety in the presence of his friend.

Proverbs 17:19 He loveth transgression that loveth strife: and he that exalteth his gate seeketh destruction.

Proverbs 17:20 He that hath a froward heart findeth no good: and he that hath a perverse tongue falleth into mischief.

Proverbs 17:21 He that begetteth a fool doeth it to his sorrow: and the father of a fool hath no joy.

Proverbs 17:22 A merry heart doeth good like a medicine: but a broken spirit drieth the bones.

Proverbs 17:23 A wicked man taketh a gift out of the bosom to pervert the ways of judgment.

Proverbs 17:24 Wisdom is before him that hath understanding; but the eyes of a fool are in the ends of the earth.

Proverbs 17:25 A foolish son is a grief to his father, and bitterness to her that bare him.

Proverbs 17:26 Also to punish the just is not good, nor to strike princes for equity.

Proverbs 17:27 He that hath knowledge spareth his words: and a man of understanding is of an excellent spirit.

Proverbs 17:28 Even a fool, when he holdeth his peace, is counted wise: and he that shutteth his lips is esteemed a man of understanding.
