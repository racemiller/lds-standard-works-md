# Exodus 11

Exodus 11 (summary): The departing Israelites are authorized to ask for jewels and gold from their neighbors—The Lord promises to slay the firstborn in every Egyptian home—He puts a difference between the Egyptians and the Israelites.

Exodus 11:1 And the Lord said unto Moses, Yet will I bring one plague more upon Pharaoh, and upon Egypt; afterwards he will let you go hence: when he shall let you go, he shall surely thrust you out hence altogether.

Exodus 11:2 Speak now in the ears of the people, and let every man borrow of his neighbour, and every woman of her neighbour, jewels of silver, and jewels of gold.

Exodus 11:3 And the Lord gave the people favour in the sight of the Egyptians. Moreover the man Moses was very great in the land of Egypt, in the sight of Pharaoh’s servants, and in the sight of the people.

Exodus 11:4 And Moses said, Thus saith the Lord, About midnight will I go out into the midst of Egypt:

Exodus 11:5 And all the firstborn in the land of Egypt shall die, from the firstborn of Pharaoh that sitteth upon his throne, even unto the firstborn of the maidservant that is behind the mill; and all the firstborn of beasts.

Exodus 11:6 And there shall be a great cry throughout all the land of Egypt, such as there was none like it, nor shall be like it any more.

Exodus 11:7 But against any of the children of Israel shall not a dog move his tongue, against man or beast: that ye may know how that the Lord doth put a difference between the Egyptians and Israel.

Exodus 11:8 And all these thy servants shall come down unto me, and bow down themselves unto me, saying, Get thee out, and all the people that follow thee: and after that I will go out. And he went out from Pharaoh in a great anger.

Exodus 11:9 And the Lord said unto Moses, Pharaoh shall not hearken unto you; that my wonders may be multiplied in the land of Egypt.

Exodus 11:10 And Moses and Aaron did all these wonders before Pharaoh: and the Lord hardened Pharaoh’s heart, so that he would not let the children of Israel go out of his land.
