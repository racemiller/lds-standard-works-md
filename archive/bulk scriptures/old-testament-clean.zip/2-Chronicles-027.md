# 2 Chronicles 27

2 Chronicles 27 (summary): Jotham reigns, builds up the kingdom, and subdues the Ammonites.

2 Chronicles 27:1 Jotham was twenty and five years old when he began to reign, and he reigned sixteen years in Jerusalem. His mother’s name also was Jerushah, the daughter of Zadok.

2 Chronicles 27:2 And he did that which was right in the sight of the Lord, according to all that his father Uzziah did: howbeit he entered not into the temple of the Lord. And the people did yet corruptly.

2 Chronicles 27:3 He built the high gate of the house of the Lord, and on the wall of Ophel he built much.

2 Chronicles 27:4 Moreover he built cities in the mountains of Judah, and in the forests he built castles and towers.

2 Chronicles 27:5 He fought also with the king of the Ammonites, and prevailed against them. And the children of Ammon gave him the same year an hundred talents of silver, and ten thousand measures of wheat, and ten thousand of barley. So much did the children of Ammon pay unto him, both the second year, and the third.

2 Chronicles 27:6 So Jotham became mighty, because he prepared his ways before the Lord his God.

2 Chronicles 27:7 Now the rest of the acts of Jotham, and all his wars, and his ways, lo, they are written in the book of the kings of Israel and Judah.

2 Chronicles 27:8 He was five and twenty years old when he began to reign, and reigned sixteen years in Jerusalem.

2 Chronicles 27:9 And Jotham slept with his fathers, and they buried him in the city of David: and Ahaz his son reigned in his stead.
