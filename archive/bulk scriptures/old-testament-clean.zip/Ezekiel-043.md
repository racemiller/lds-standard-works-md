# Ezekiel 43

Ezekiel 43 (summary): The glory of God fills the temple—His throne is there, and He promises to dwell in the midst of Israel forever—Ezekiel sees the altar and the ordinances of the altar.

Ezekiel 43:1 Afterward he brought me to the gate, even the gate that looketh toward the east:

Ezekiel 43:2 And, behold, the glory of the God of Israel came from the way of the east: and his voice was like a noise of many waters: and the earth shined with his glory.

Ezekiel 43:3 And it was according to the appearance of the vision which I saw, even according to the vision that I saw when I came to destroy the city: and the visions were like the vision that I saw by the river Chebar; and I fell upon my face.

Ezekiel 43:4 And the glory of the Lord came into the house by the way of the gate whose prospect is toward the east.

Ezekiel 43:5 So the spirit took me up, and brought me into the inner court; and, behold, the glory of the Lord filled the house.

Ezekiel 43:6 And I heard him speaking unto me out of the house; and the man stood by me.

Ezekiel 43:7 And he said unto me, Son of man, the place of my throne, and the place of the soles of my feet, where I will dwell in the midst of the children of Israel for ever, and my holy name, shall the house of Israel no more defile, neither they, nor their kings, by their whoredom, nor by the carcases of their kings in their high places.

Ezekiel 43:8 In their setting of their threshold by my thresholds, and their post by my posts, and the wall between me and them, they have even defiled my holy name by their abominations that they have committed: wherefore I have consumed them in mine anger.

Ezekiel 43:9 Now let them put away their whoredom, and the carcases of their kings, far from me, and I will dwell in the midst of them for ever.

Ezekiel 43:10 Thou son of man, shew the house to the house of Israel, that they may be ashamed of their iniquities: and let them measure the pattern.

Ezekiel 43:11 And if they be ashamed of all that they have done, shew them the form of the house, and the fashion thereof, and the goings out thereof, and the comings in thereof, and all the forms thereof, and all the ordinances thereof, and all the forms thereof, and all the laws thereof: and write it in their sight, that they may keep the whole form thereof, and all the ordinances thereof, and do them.

Ezekiel 43:12 This is the law of the house; Upon the top of the mountain the whole limit thereof round about shall be most holy. Behold, this is the law of the house.

Ezekiel 43:13 And these are the measures of the altar after the cubits: The cubit is a cubit and an hand breadth; even the bottom shall be a cubit, and the breadth a cubit, and the border thereof by the edge thereof round about shall be a span: and this shall be the higher place of the altar.

Ezekiel 43:14 And from the bottom upon the ground even to the lower settle shall be two cubits, and the breadth one cubit; and from the lesser settle even to the greater settle shall be four cubits, and the breadth one cubit.

Ezekiel 43:15 So the altar shall be four cubits; and from the altar and upward shall be four horns.

Ezekiel 43:16 And the altar shall be twelve cubits long, twelve broad, square in the four squares thereof.

Ezekiel 43:17 And the settle shall be fourteen cubits long and fourteen broad in the four squares thereof; and the border about it shall be half a cubit; and the bottom thereof shall be a cubit about; and his stairs shall look toward the east.

Ezekiel 43:18 And he said unto me, Son of man, thus saith the Lord God; These are the ordinances of the altar in the day when they shall make it, to offer burnt offerings thereon, and to sprinkle blood thereon.

Ezekiel 43:19 And thou shalt give to the priests the Levites that be of the seed of Zadok, which approach unto me, to minister unto me, saith the Lord God, a young bullock for a sin offering.

Ezekiel 43:20 And thou shalt take of the blood thereof, and put it on the four horns of it, and on the four corners of the settle, and upon the border round about: thus shalt thou cleanse and purge it.

Ezekiel 43:21 Thou shalt take the bullock also of the sin offering, and he shall burn it in the appointed place of the house, without the sanctuary.

Ezekiel 43:22 And on the second day thou shalt offer a kid of the goats without blemish for a sin offering; and they shall cleanse the altar, as they did cleanse it with the bullock.

Ezekiel 43:23 When thou hast made an end of cleansing it, thou shalt offer a young bullock without blemish, and a ram out of the flock without blemish.

Ezekiel 43:24 And thou shalt offer them before the Lord, and the priests shall cast salt upon them, and they shall offer them up for a burnt offering unto the Lord.

Ezekiel 43:25 Seven days shalt thou prepare every day a goat for a sin offering: they shall also prepare a young bullock, and a ram out of the flock, without blemish.

Ezekiel 43:26 Seven days shall they purge the altar and purify it; and they shall consecrate themselves.

Ezekiel 43:27 And when these days are expired, it shall be, that upon the eighth day, and so forward, the priests shall make your burnt offerings upon the altar, and your peace offerings; and I will accept you, saith the Lord God.
