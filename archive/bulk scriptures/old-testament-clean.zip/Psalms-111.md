# Psalms 111

Psalms 111 (summary): The Lord is gracious and full of compassion—Holy and reverend is His name—The fear of the Lord is the beginning of wisdom.

Psalms 111:1 Praise ye the Lord. I will praise the Lord with my whole heart, in the assembly of the upright, and in the congregation.

Psalms 111:2 The works of the Lord are great, sought out of all them that have pleasure therein.

Psalms 111:3 His work is honourable and glorious: and his righteousness endureth for ever.

Psalms 111:4 He hath made his wonderful works to be remembered: the Lord is gracious and full of compassion.

Psalms 111:5 He hath given meat unto them that fear him: he will ever be mindful of his covenant.

Psalms 111:6 He hath shewed his people the power of his works, that he may give them the heritage of the heathen.

Psalms 111:7 The works of his hands are verity and judgment; all his commandments are sure.

Psalms 111:8 They stand fast for ever and ever, and are done in truth and uprightness.

Psalms 111:9 He sent redemption unto his people: he hath commanded his covenant for ever: holy and reverend is his name.

Psalms 111:10 The fear of the Lord is the beginning of wisdom: a good understanding have all they that do his commandments: his praise endureth for ever.
