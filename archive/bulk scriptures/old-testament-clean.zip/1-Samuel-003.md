# 1 Samuel 3

1 Samuel 3 (summary): The Lord calls Samuel—The house of Eli will not be purged by sacrifices and offerings—Samuel is recognized as a prophet by all Israel—The Lord appears to him.

1 Samuel 3:1 And the child Samuel ministered unto the Lord before Eli. And the word of the Lord was precious in those days; there was no open vision.

1 Samuel 3:2 And it came to pass at that time, when Eli was laid down in his place, and his eyes began to wax dim, that he could not see;

1 Samuel 3:3 And ere the lamp of God went out in the temple of the Lord, where the ark of God was, and Samuel was laid down to sleep;

1 Samuel 3:4 That the Lord called Samuel: and he answered, Here am I.

1 Samuel 3:5 And he ran unto Eli, and said, Here am I; for thou calledst me. And he said, I called not; lie down again. And he went and lay down.

1 Samuel 3:6 And the Lord called yet again, Samuel. And Samuel arose and went to Eli, and said, Here am I; for thou didst call me. And he answered, I called not, my son; lie down again.

1 Samuel 3:7 Now Samuel did not yet know the Lord, neither was the word of the Lord yet revealed unto him.

1 Samuel 3:8 And the Lord called Samuel again the third time. And he arose and went to Eli, and said, Here am I; for thou didst call me. And Eli perceived that the Lord had called the child.

1 Samuel 3:9 Therefore Eli said unto Samuel, Go, lie down: and it shall be, if he call thee, that thou shalt say, Speak, Lord; for thy servant heareth. So Samuel went and lay down in his place.

1 Samuel 3:10 And the Lord came, and stood, and called as at other times, Samuel, Samuel. Then Samuel answered, Speak; for thy servant heareth.

1 Samuel 3:11 And the Lord said to Samuel, Behold, I will do a thing in Israel, at which both the ears of every one that heareth it shall tingle.

1 Samuel 3:12 In that day I will perform against Eli all things which I have spoken concerning his house: when I begin, I will also make an end.

1 Samuel 3:13 For I have told him that I will judge his house for ever for the iniquity which he knoweth; because his sons made themselves vile, and he restrained them not.

1 Samuel 3:14 And therefore I have sworn unto the house of Eli, that the iniquity of Eli’s house shall not be purged with sacrifice nor offering for ever.

1 Samuel 3:15 And Samuel lay until the morning, and opened the doors of the house of the Lord. And Samuel feared to shew Eli the vision.

1 Samuel 3:16 Then Eli called Samuel, and said, Samuel, my son. And he answered, Here am I.

1 Samuel 3:17 And he said, What is the thing that the Lord hath said unto thee? I pray thee hide it not from me: God do so to thee, and more also, if thou hide any thing from me of all the things that he said unto thee.

1 Samuel 3:18 And Samuel told him every whit, and hid nothing from him. And he said, It is the Lord: let him do what seemeth him good.

1 Samuel 3:19 And Samuel grew, and the Lord was with him, and did let none of his words fall to the ground.

1 Samuel 3:20 And all Israel from Dan even to Beer-sheba knew that Samuel was established to be a prophet of the Lord.

1 Samuel 3:21 And the Lord appeared again in Shiloh: for the Lord revealed himself to Samuel in Shiloh by the word of the Lord.
