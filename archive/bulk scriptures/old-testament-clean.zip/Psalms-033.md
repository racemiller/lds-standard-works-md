# Psalms 33

Psalms 33 (summary): Rejoice in the Lord—Sing unto Him a new song—He loves righteousness and judgment—Blessed is the nation whose God is the Lord.

Psalms 33:1 Rejoice in the Lord, O ye righteous: for praise is comely for the upright.

Psalms 33:2 Praise the Lord with harp: sing unto him with the psaltery and an instrument of ten strings.

Psalms 33:3 Sing unto him a new song; play skilfully with a loud noise.

Psalms 33:4 For the word of the Lord is right; and all his works are done in truth.

Psalms 33:5 He loveth righteousness and judgment: the earth is full of the goodness of the Lord.

Psalms 33:6 By the word of the Lord were the heavens made; and all the host of them by the breath of his mouth.

Psalms 33:7 He gathereth the waters of the sea together as an heap: he layeth up the depth in storehouses.

Psalms 33:8 Let all the earth fear the Lord: let all the inhabitants of the world stand in awe of him.

Psalms 33:9 For he spake, and it was done; he commanded, and it stood fast.

Psalms 33:10 The Lord bringeth the counsel of the heathen to nought: he maketh the devices of the people of none effect.

Psalms 33:11 The counsel of the Lord standeth for ever, the thoughts of his heart to all generations.

Psalms 33:12 Blessed is the nation whose God is the Lord; and the people whom he hath chosen for his own inheritance.

Psalms 33:13 The Lord looketh from heaven; he beholdeth all the sons of men.

Psalms 33:14 From the place of his habitation he looketh upon all the inhabitants of the earth.

Psalms 33:15 He fashioneth their hearts alike; he considereth all their works.

Psalms 33:16 There is no king saved by the multitude of an host: a mighty man is not delivered by much strength.

Psalms 33:17 An horse is a vain thing for safety: neither shall he deliver any by his great strength.

Psalms 33:18 Behold, the eye of the Lord is upon them that fear him, upon them that hope in his mercy;

Psalms 33:19 To deliver their soul from death, and to keep them alive in famine.

Psalms 33:20 Our soul waiteth for the Lord: he is our help and our shield.

Psalms 33:21 For our heart shall rejoice in him, because we have trusted in his holy name.

Psalms 33:22 Let thy mercy, O Lord, be upon us, according as we hope in thee.
