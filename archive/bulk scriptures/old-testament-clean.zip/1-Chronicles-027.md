# 1 Chronicles 27

1 Chronicles 27 (summary): The officers who serve the king are named—The princes of the tribes of Israel are set forth.

1 Chronicles 27:1 Now the children of Israel after their number, to wit, the chief fathers and captains of thousands and hundreds, and their officers that served the king in any matter of the courses, which came in and went out month by month throughout all the months of the year, of every course were twenty and four thousand.

1 Chronicles 27:2 Over the first course for the first month was Jashobeam the son of Zabdiel: and in his course were twenty and four thousand.

1 Chronicles 27:3 Of the children of Perez was the chief of all the captains of the host for the first month.

1 Chronicles 27:4 And over the course of the second month was Dodai an Ahohite, and of his course was Mikloth also the ruler: in his course likewise were twenty and four thousand.

1 Chronicles 27:5 The third captain of the host for the third month was Benaiah the son of Jehoiada, a chief priest: and in his course were twenty and four thousand.

1 Chronicles 27:6 This is that Benaiah, who was mighty among the thirty, and above the thirty: and in his course was Ammizabad his son.

1 Chronicles 27:7 The fourth captain for the fourth month was Asahel the brother of Joab, and Zebadiah his son after him: and in his course were twenty and four thousand.

1 Chronicles 27:8 The fifth captain for the fifth month was Shamhuth the Izrahite: and in his course were twenty and four thousand.

1 Chronicles 27:9 The sixth captain for the sixth month was Ira the son of Ikkesh the Tekoite: and in his course were twenty and four thousand.

1 Chronicles 27:10 The seventh captain for the seventh month was Helez the Pelonite, of the children of Ephraim: and in his course were twenty and four thousand.

1 Chronicles 27:11 The eighth captain for the eighth month was Sibbecai the Hushathite, of the Zarhites: and in his course were twenty and four thousand.

1 Chronicles 27:12 The ninth captain for the ninth month was Abiezer the Anetothite, of the Benjamites: and in his course were twenty and four thousand.

1 Chronicles 27:13 The tenth captain for the tenth month was Maharai the Netophathite, of the Zarhites: and in his course were twenty and four thousand.

1 Chronicles 27:14 The eleventh captain for the eleventh month was Benaiah the Pirathonite, of the children of Ephraim: and in his course were twenty and four thousand.

1 Chronicles 27:15 The twelfth captain for the twelfth month was Heldai the Netophathite, of Othniel: and in his course were twenty and four thousand.

1 Chronicles 27:16 Furthermore over the tribes of Israel: the ruler of the Reubenites was Eliezer the son of Zichri: of the Simeonites, Shephatiah the son of Maachah:

1 Chronicles 27:17 Of the Levites, Hashabiah the son of Kemuel: of the Aaronites, Zadok:

1 Chronicles 27:18 Of Judah, Elihu, one of the brethren of David: of Issachar, Omri the son of Michael:

1 Chronicles 27:19 Of Zebulun, Ishmaiah the son of Obadiah: of Naphtali, Jerimoth the son of Azriel:

1 Chronicles 27:20 Of the children of Ephraim, Hoshea the son of Azaziah: of the half tribe of Manasseh, Joel the son of Pedaiah:

1 Chronicles 27:21 Of the half tribe of Manasseh in Gilead, Iddo the son of Zechariah: of Benjamin, Jaasiel the son of Abner:

1 Chronicles 27:22 Of Dan, Azareel the son of Jeroham. These were the princes of the tribes of Israel.

1 Chronicles 27:23 But David took not the number of them from twenty years old and under: because the Lord had said he would increase Israel like to the stars of the heavens.

1 Chronicles 27:24 Joab the son of Zeruiah began to number, but he finished not, because there fell wrath for it against Israel; neither was the number put in the account of the chronicles of king David.

1 Chronicles 27:25 And over the king’s treasures was Azmaveth the son of Adiel: and over the storehouses in the fields, in the cities, and in the villages, and in the castles, was Jehonathan the son of Uzziah:

1 Chronicles 27:26 And over them that did the work of the field for tillage of the ground was Ezri the son of Chelub:

1 Chronicles 27:27 And over the vineyards was Shimei the Ramathite: over the increase of the vineyards for the wine cellars was Zabdi the Shiphmite:

1 Chronicles 27:28 And over the olive trees and the sycomore trees that were in the low plains was Baal-hanan the Gederite: and over the cellars of oil was Joash:

1 Chronicles 27:29 And over the herds that fed in Sharon was Shitrai the Sharonite: and over the herds that were in the valleys was Shaphat the son of Adlai:

1 Chronicles 27:30 Over the camels also was Obil the Ishmaelite: and over the asses was Jehdeiah the Meronothite:

1 Chronicles 27:31 And over the flocks was Jaziz the Hagerite. All these were the rulers of the substance which was king David’s.

1 Chronicles 27:32 Also Jonathan David’s uncle was a counsellor, a wise man, and a scribe: and Jehiel the son of Hachmoni was with the king’s sons:

1 Chronicles 27:33 And Ahithophel was the king’s counsellor: and Hushai the Archite was the king’s companion:

1 Chronicles 27:34 And after Ahithophel was Jehoiada the son of Benaiah, and Abiathar: and the general of the king’s army was Joab.
