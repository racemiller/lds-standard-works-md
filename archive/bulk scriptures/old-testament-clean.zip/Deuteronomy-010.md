# Deuteronomy 10

Deuteronomy 10 (summary): The tables of stone containing the Ten Commandments are placed in the ark—All that God requires is that Israel love and serve Him—How great and mighty is the Lord!

Deuteronomy 10:1 At that time the Lord said unto me, Hew thee two tables of stone like unto the first, and come up unto me into the mount, and make thee an ark of wood.

Deuteronomy 10:2 And I will write on the tables the words that were in the first tables which thou brakest, and thou shalt put them in the ark.

Deuteronomy 10:3 And I made an ark of shittim wood, and hewed two tables of stone like unto the first, and went up into the mount, having the two tables in mine hand.

Deuteronomy 10:4 And he wrote on the tables, according to the first writing, the ten commandments, which the Lord spake unto you in the mount out of the midst of the fire in the day of the assembly: and the Lord gave them unto me.

Deuteronomy 10:5 And I turned myself and came down from the mount, and put the tables in the ark which I had made; and there they be, as the Lord commanded me.

Deuteronomy 10:6 And the children of Israel took their journey from Beeroth of the children of Jaakan to Mosera: there Aaron died, and there he was buried; and Eleazar his son ministered in the priest’s office in his stead.

Deuteronomy 10:7 From thence they journeyed unto Gudgodah; and from Gudgodah to Jotbath, a land of rivers of waters.

Deuteronomy 10:8 At that time the Lord separated the tribe of Levi, to bear the ark of the covenant of the Lord, to stand before the Lord to minister unto him, and to bless in his name, unto this day.

Deuteronomy 10:9 Wherefore Levi hath no part nor inheritance with his brethren; the Lord is his inheritance, according as the Lord thy God promised him.

Deuteronomy 10:10 And I stayed in the mount, according to the first time, forty days and forty nights; and the Lord hearkened unto me at that time also, and the Lord would not destroy thee.

Deuteronomy 10:11 And the Lord said unto me, Arise, take thy journey before the people, that they may go in and possess the land, which I sware unto their fathers to give unto them.

Deuteronomy 10:12 And now, Israel, what doth the Lord thy God require of thee, but to fear the Lord thy God, to walk in all his ways, and to love him, and to serve the Lord thy God with all thy heart and with all thy soul,

Deuteronomy 10:13 To keep the commandments of the Lord, and his statutes, which I command thee this day for thy good?

Deuteronomy 10:14 Behold, the heaven and the heaven of heavens is the Lord’s thy God, the earth also, with all that therein is.

Deuteronomy 10:15 Only the Lord had a delight in thy fathers to love them, and he chose their seed after them, even you above all people, as it is this day.

Deuteronomy 10:16 Circumcise therefore the foreskin of your heart, and be no more stiffnecked.

Deuteronomy 10:17 For the Lord your God is God of gods, and Lord of lords, a great God, a mighty, and a terrible, which regardeth not persons, nor taketh reward:

Deuteronomy 10:18 He doth execute the judgment of the fatherless and widow, and loveth the stranger, in giving him food and raiment.

Deuteronomy 10:19 Love ye therefore the stranger: for ye were strangers in the land of Egypt.

Deuteronomy 10:20 Thou shalt fear the Lord thy God; him shalt thou serve, and to him shalt thou cleave, and swear by his name.

Deuteronomy 10:21 He is thy praise, and he is thy God, that hath done for thee these great and terrible things, which thine eyes have seen.

Deuteronomy 10:22 Thy fathers went down into Egypt with threescore and ten persons; and now the Lord thy God hath made thee as the stars of heaven for multitude.
