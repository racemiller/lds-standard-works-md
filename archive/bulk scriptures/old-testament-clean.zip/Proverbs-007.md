# Proverbs 7

Proverbs 7 (summary): An immoral woman leads a man to destruction as an ox to the slaughter—The house of an adulterous woman is the way to hell.

Proverbs 7:1 My son, keep my words, and lay up my commandments with thee.

Proverbs 7:2 Keep my commandments, and live; and my law as the apple of thine eye.

Proverbs 7:3 Bind them upon thy fingers, write them upon the table of thine heart.

Proverbs 7:4 Say unto wisdom, Thou art my sister; and call understanding thy kinswoman:

Proverbs 7:5 That they may keep thee from the strange woman, from the stranger which flattereth with her words.

Proverbs 7:6 For at the window of my house I looked through my casement,

Proverbs 7:7 And beheld among the simple ones, I discerned among the youths, a young man void of understanding,

Proverbs 7:8 Passing through the street near her corner; and he went the way to her house,

Proverbs 7:9 In the twilight, in the evening, in the black and dark night:

Proverbs 7:10 And, behold, there met him a woman with the attire of an harlot, and subtil of heart.

Proverbs 7:11 (She is loud and stubborn; her feet abide not in her house:

Proverbs 7:12 Now is she without, now in the streets, and lieth in wait at every corner.)

Proverbs 7:13 So she caught him, and kissed him, and with an impudent face said unto him,

Proverbs 7:14 I have peace offerings with me; this day have I payed my vows.

Proverbs 7:15 Therefore came I forth to meet thee, diligently to seek thy face, and I have found thee.

Proverbs 7:16 I have decked my bed with coverings of tapestry, with carved works, with fine linen of Egypt.

Proverbs 7:17 I have perfumed my bed with myrrh, aloes, and cinnamon.

Proverbs 7:18 Come, let us take our fill of love until the morning: let us solace ourselves with loves.

Proverbs 7:19 For the goodman is not at home, he is gone a long journey:

Proverbs 7:20 He hath taken a bag of money with him, and will come home at the day appointed.

Proverbs 7:21 With her much fair speech she caused him to yield, with the flattering of her lips she forced him.

Proverbs 7:22 He goeth after her straightway, as an ox goeth to the slaughter, or as a fool to the correction of the stocks;

Proverbs 7:23 Till a dart strike through his liver; as a bird hasteth to the snare, and knoweth not that it is for his life.

Proverbs 7:24 Hearken unto me now therefore, O ye children, and attend to the words of my mouth.

Proverbs 7:25 Let not thine heart decline to her ways, go not astray in her paths.

Proverbs 7:26 For she hath cast down many wounded: yea, many strong men have been slain by her.

Proverbs 7:27 Her house is the way to hell, going down to the chambers of death.
