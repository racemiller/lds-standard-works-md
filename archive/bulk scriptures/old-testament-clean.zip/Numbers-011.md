# Numbers 11

Numbers 11 (summary): Fire from the Lord consumes the rebels in Israel—Israel murmurs and lusts for meat instead of manna—Moses complains that he cannot bear the burden alone—He is commanded to choose seventy elders to assist him—The Lord promises meat until it becomes loathsome to the Israelites—The seventy elders are chosen, they prophesy, the Lord comes down, and Eldad and Medad prophesy in the camp—Israel is provided with quail—The people lust, a great plague follows, and many die.

Numbers 11:1 And when the people complained, it displeased the Lord: and the Lord heard it; and his anger was kindled; and the fire of the Lord burnt among them, and consumed them that were in the uttermost parts of the camp.

Numbers 11:2 And the people cried unto Moses; and when Moses prayed unto the Lord, the fire was quenched.

Numbers 11:3 And he called the name of the place Taberah: because the fire of the Lord burnt among them.

Numbers 11:4 And the mixed multitude that was among them fell a lusting: and the children of Israel also wept again, and said, Who shall give us flesh to eat?

Numbers 11:5 We remember the fish, which we did eat in Egypt freely; the cucumbers, and the melons, and the leeks, and the onions, and the garlick:

Numbers 11:6 But now our soul is dried away: there is nothing at all, beside this manna, before our eyes.

Numbers 11:7 And the manna was as coriander seed, and the colour thereof as the colour of bdellium.

Numbers 11:8 And the people went about, and gathered it, and ground it in mills, or beat it in a mortar, and baked it in pans, and made cakes of it: and the taste of it was as the taste of fresh oil.

Numbers 11:9 And when the dew fell upon the camp in the night, the manna fell upon it.

Numbers 11:10 Then Moses heard the people weep throughout their families, every man in the door of his tent: and the anger of the Lord was kindled greatly; Moses also was displeased.

Numbers 11:11 And Moses said unto the Lord, Wherefore hast thou afflicted thy servant? and wherefore have I not found favour in thy sight, that thou layest the burden of all this people upon me?

Numbers 11:12 Have I conceived all this people? have I begotten them, that thou shouldest say unto me, Carry them in thy bosom, as a nursing father beareth the sucking child, unto the land which thou swarest unto their fathers?

Numbers 11:13 Whence should I have flesh to give unto all this people? for they weep unto me, saying, Give us flesh, that we may eat.

Numbers 11:14 I am not able to bear all this people alone, because it is too heavy for me.

Numbers 11:15 And if thou deal thus with me, kill me, I pray thee, out of hand, if I have found favour in thy sight; and let me not see my wretchedness.

Numbers 11:16 And the Lord said unto Moses, Gather unto me seventy men of the elders of Israel, whom thou knowest to be the elders of the people, and officers over them; and bring them unto the tabernacle of the congregation, that they may stand there with thee.

Numbers 11:17 And I will come down and talk with thee there: and I will take of the spirit which is upon thee, and will put it upon them; and they shall bear the burden of the people with thee, that thou bear it not thyself alone.

Numbers 11:18 And say thou unto the people, Sanctify yourselves against to morrow, and ye shall eat flesh: for ye have wept in the ears of the Lord, saying, Who shall give us flesh to eat? for it was well with us in Egypt: therefore the Lord will give you flesh, and ye shall eat.

Numbers 11:19 Ye shall not eat one day, nor two days, nor five days, neither ten days, nor twenty days;

Numbers 11:20 But even a whole month, until it come out at your nostrils, and it be loathsome unto you: because that ye have despised the Lord which is among you, and have wept before him, saying, Why came we forth out of Egypt?

Numbers 11:21 And Moses said, The people, among whom I am, are six hundred thousand footmen; and thou hast said, I will give them flesh, that they may eat a whole month.

Numbers 11:22 Shall the flocks and the herds be slain for them, to suffice them? or shall all the fish of the sea be gathered together for them, to suffice them?

Numbers 11:23 And the Lord said unto Moses, Is the Lord’s hand waxed short? thou shalt see now whether my word shall come to pass unto thee or not.

Numbers 11:24 And Moses went out, and told the people the words of the Lord, and gathered the seventy men of the elders of the people, and set them round about the tabernacle.

Numbers 11:25 And the Lord came down in a cloud, and spake unto him, and took of the spirit that was upon him, and gave it unto the seventy elders: and it came to pass, that, when the spirit rested upon them, they prophesied, and did not cease.

Numbers 11:26 But there remained two of the men in the camp, the name of the one was Eldad, and the name of the other Medad: and the spirit rested upon them; and they were of them that were written, but went not out unto the tabernacle: and they prophesied in the camp.

Numbers 11:27 And there ran a young man, and told Moses, and said, Eldad and Medad do prophesy in the camp.

Numbers 11:28 And Joshua the son of Nun, the servant of Moses, one of his young men, answered and said, My lord Moses, forbid them.

Numbers 11:29 And Moses said unto him, Enviest thou for my sake? would God that all the Lord’s people were prophets, and that the Lord would put his spirit upon them!

Numbers 11:30 And Moses gat him into the camp, he and the elders of Israel.

Numbers 11:31 And there went forth a wind from the Lord, and brought quails from the sea, and let them fall by the camp, as it were a day’s journey on this side, and as it were a day’s journey on the other side, round about the camp, and as it were two cubits high upon the face of the earth.

Numbers 11:32 And the people stood up all that day, and all that night, and all the next day, and they gathered the quails: he that gathered least gathered ten homers: and they spread them all abroad for themselves round about the camp.

Numbers 11:33 And while the flesh was yet between their teeth, ere it was chewed, the wrath of the Lord was kindled against the people, and the Lord smote the people with a very great plague.

Numbers 11:34 And he called the name of that place Kibroth-hattaavah: because there they buried the people that lusted.

Numbers 11:35 And the people journeyed from Kibroth-hattaavah unto Hazeroth; and abode at Hazeroth.
