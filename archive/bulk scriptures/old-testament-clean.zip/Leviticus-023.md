# Leviticus 23

Leviticus 23 (summary): Israel is to hold a holy convocation on each weekly Sabbath—Israel is to keep the Feasts of the Passover, of Unleavened Bread, of Pentecost or Firstfruits, of Trumpets, of the Day of Atonement, and of Tabernacles.

Leviticus 23:1 And the Lord spake unto Moses, saying,

Leviticus 23:2 Speak unto the children of Israel, and say unto them, Concerning the feasts of the Lord, which ye shall proclaim to be holy convocations, even these are my feasts.

Leviticus 23:3 Six days shall work be done: but the seventh day is the sabbath of rest, an holy convocation; ye shall do no work therein: it is the sabbath of the Lord in all your dwellings.

Leviticus 23:4 These are the feasts of the Lord, even holy convocations, which ye shall proclaim in their seasons.

Leviticus 23:5 In the fourteenth day of the first month at even is the Lord’s passover.

Leviticus 23:6 And on the fifteenth day of the same month is the feast of unleavened bread unto the Lord: seven days ye must eat unleavened bread.

Leviticus 23:7 In the first day ye shall have an holy convocation: ye shall do no servile work therein.

Leviticus 23:8 But ye shall offer an offering made by fire unto the Lord seven days: in the seventh day is an holy convocation: ye shall do no servile work therein.

Leviticus 23:9 And the Lord spake unto Moses, saying,

Leviticus 23:10 Speak unto the children of Israel, and say unto them, When ye be come into the land which I give unto you, and shall reap the harvest thereof, then ye shall bring a sheaf of the firstfruits of your harvest unto the priest:

Leviticus 23:11 And he shall wave the sheaf before the Lord, to be accepted for you: on the morrow after the sabbath the priest shall wave it.

Leviticus 23:12 And ye shall offer that day when ye wave the sheaf an he lamb without blemish of the first year for a burnt offering unto the Lord.

Leviticus 23:13 And the meat offering thereof shall be two tenth deals of fine flour mingled with oil, an offering made by fire unto the Lord for a sweet savour: and the drink offering thereof shall be of wine, the fourth part of an hin.

Leviticus 23:14 And ye shall eat neither bread, nor parched corn, nor green ears, until the selfsame day that ye have brought an offering unto your God: it shall be a statute for ever throughout your generations in all your dwellings.

Leviticus 23:15 And ye shall count unto you from the morrow after the sabbath, from the day that ye brought the sheaf of the wave offering; seven sabbaths shall be complete:

Leviticus 23:16 Even unto the morrow after the seventh sabbath shall ye number fifty days; and ye shall offer a new meat offering unto the Lord.

Leviticus 23:17 Ye shall bring out of your habitations two wave loaves of two tenth deals: they shall be of fine flour; they shall be baken with leaven; they are the firstfruits unto the Lord.

Leviticus 23:18 And ye shall offer with the bread seven lambs without blemish of the first year, and one young bullock, and two rams: they shall be for a burnt offering unto the Lord, with their meat offering, and their drink offerings, even an offering made by fire, of sweet savour unto the Lord.

Leviticus 23:19 Then ye shall sacrifice one kid of the goats for a sin offering, and two lambs of the first year for a sacrifice of peace offerings.

Leviticus 23:20 And the priest shall wave them with the bread of the firstfruits for a wave offering before the Lord, with the two lambs: they shall be holy to the Lord for the priest.

Leviticus 23:21 And ye shall proclaim on the selfsame day, that it may be an holy convocation unto you: ye shall do no servile work therein: it shall be a statute for ever in all your dwellings throughout your generations.

Leviticus 23:22 And when ye reap the harvest of your land, thou shalt not make clean riddance of the corners of thy field when thou reapest, neither shalt thou gather any gleaning of thy harvest: thou shalt leave them unto the poor, and to the stranger: I am the Lord your God.

Leviticus 23:23 And the Lord spake unto Moses, saying,

Leviticus 23:24 Speak unto the children of Israel, saying, In the seventh month, in the first day of the month, shall ye have a sabbath, a memorial of blowing of trumpets, an holy convocation.

Leviticus 23:25 Ye shall do no servile work therein: but ye shall offer an offering made by fire unto the Lord.

Leviticus 23:26 And the Lord spake unto Moses, saying,

Leviticus 23:27 Also on the tenth day of this seventh month there shall be a day of atonement: it shall be an holy convocation unto you; and ye shall afflict your souls, and offer an offering made by fire unto the Lord.

Leviticus 23:28 And ye shall do no work in that same day: for it is a day of atonement, to make an atonement for you before the Lord your God.

Leviticus 23:29 For whatsoever soul it be that shall not be afflicted in that same day, he shall be cut off from among his people.

Leviticus 23:30 And whatsoever soul it be that doeth any work in that same day, the same soul will I destroy from among his people.

Leviticus 23:31 Ye shall do no manner of work: it shall be a statute for ever throughout your generations in all your dwellings.

Leviticus 23:32 It shall be unto you a sabbath of rest, and ye shall afflict your souls: in the ninth day of the month at even, from even unto even, shall ye celebrate your sabbath.

Leviticus 23:33 And the Lord spake unto Moses, saying,

Leviticus 23:34 Speak unto the children of Israel, saying, The fifteenth day of this seventh month shall be the feast of tabernacles for seven days unto the Lord.

Leviticus 23:35 On the first day shall be an holy convocation: ye shall do no servile work therein.

Leviticus 23:36 Seven days ye shall offer an offering made by fire unto the Lord: on the eighth day shall be an holy convocation unto you; and ye shall offer an offering made by fire unto the Lord: it is a solemn assembly; and ye shall do no servile work therein.

Leviticus 23:37 These are the feasts of the Lord, which ye shall proclaim to be holy convocations, to offer an offering made by fire unto the Lord, a burnt offering, and a meat offering, a sacrifice, and drink offerings, every thing upon his day:

Leviticus 23:38 Beside the sabbaths of the Lord, and beside your gifts, and beside all your vows, and beside all your freewill offerings, which ye give unto the Lord.

Leviticus 23:39 Also in the fifteenth day of the seventh month, when ye have gathered in the fruit of the land, ye shall keep a feast unto the Lord seven days: on the first day shall be a sabbath, and on the eighth day shall be a sabbath.

Leviticus 23:40 And ye shall take you on the first day the boughs of goodly trees, branches of palm trees, and the boughs of thick trees, and willows of the brook; and ye shall rejoice before the Lord your God seven days.

Leviticus 23:41 And ye shall keep it a feast unto the Lord seven days in the year. It shall be a statute for ever in your generations: ye shall celebrate it in the seventh month.

Leviticus 23:42 Ye shall dwell in booths seven days; all that are Israelites born shall dwell in booths:

Leviticus 23:43 That your generations may know that I made the children of Israel to dwell in booths, when I brought them out of the land of Egypt: I am the Lord your God.

Leviticus 23:44 And Moses declared unto the children of Israel the feasts of the Lord.
