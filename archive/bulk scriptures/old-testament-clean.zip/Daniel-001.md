# Daniel 1

Daniel 1 (summary): Daniel and certain Hebrews are trained in the court of Nebuchadnezzar—They eat plain food and drink no wine—God gives them knowledge and wisdom beyond all others.

Daniel 1:1 In the third year of the reign of Jehoiakim king of Judah came Nebuchadnezzar king of Babylon unto Jerusalem, and besieged it.

Daniel 1:2 And the Lord gave Jehoiakim king of Judah into his hand, with part of the vessels of the house of God: which he carried into the land of Shinar to the house of his god; and he brought the vessels into the treasure house of his god.

Daniel 1:3 And the king spake unto Ashpenaz the master of his eunuchs, that he should bring certain of the children of Israel, and of the king’s seed, and of the princes;

Daniel 1:4 Children in whom was no blemish, but well favoured, and skilful in all wisdom, and cunning in knowledge, and understanding science, and such as had ability in them to stand in the king’s palace, and whom they might teach the learning and the tongue of the Chaldeans.

Daniel 1:5 And the king appointed them a daily provision of the king’s meat, and of the wine which he drank: so nourishing them three years, that at the end thereof they might stand before the king.

Daniel 1:6 Now among these were of the children of Judah, Daniel, Hananiah, Mishael, and Azariah:

Daniel 1:7 Unto whom the prince of the eunuchs gave names: for he gave unto Daniel the name of Belteshazzar; and to Hananiah, of Shadrach; and to Mishael, of Meshach; and to Azariah, of Abed-nego.

Daniel 1:8 But Daniel purposed in his heart that he would not defile himself with the portion of the king’s meat, nor with the wine which he drank: therefore he requested of the prince of the eunuchs that he might not defile himself.

Daniel 1:9 Now God had brought Daniel into favour and tender love with the prince of the eunuchs.

Daniel 1:10 And the prince of the eunuchs said unto Daniel, I fear my lord the king, who hath appointed your meat and your drink: for why should he see your faces worse liking than the children which are of your sort? then shall ye make me endanger my head to the king.

Daniel 1:11 Then said Daniel to Melzar, whom the prince of the eunuchs had set over Daniel, Hananiah, Mishael, and Azariah,

Daniel 1:12 Prove thy servants, I beseech thee, ten days; and let them give us pulse to eat, and water to drink.

Daniel 1:13 Then let our countenances be looked upon before thee, and the countenance of the children that eat of the portion of the king’s meat: and as thou seest, deal with thy servants.

Daniel 1:14 So he consented to them in this matter, and proved them ten days.

Daniel 1:15 And at the end of ten days their countenances appeared fairer and fatter in flesh than all the children which did eat the portion of the king’s meat.

Daniel 1:16 Thus Melzar took away the portion of their meat, and the wine that they should drink; and gave them pulse.

Daniel 1:17 As for these four children, God gave them knowledge and skill in all learning and wisdom: and Daniel had understanding in all visions and dreams.

Daniel 1:18 Now at the end of the days that the king had said he should bring them in, then the prince of the eunuchs brought them in before Nebuchadnezzar.

Daniel 1:19 And the king communed with them; and among them all was found none like Daniel, Hananiah, Mishael, and Azariah: therefore stood they before the king.

Daniel 1:20 And in all matters of wisdom and understanding, that the king inquired of them, he found them ten times better than all the magicians and astrologers that were in all his realm.

Daniel 1:21 And Daniel continued even unto the first year of king Cyrus.
