# Ezekiel 25

Ezekiel 25 (summary): The Lord’s vengeance will fall on the Ammonites, on the Moabites and Edomites, and on the Philistines.

Ezekiel 25:1 The word of the Lord came again unto me, saying,

Ezekiel 25:2 Son of man, set thy face against the Ammonites, and prophesy against them;

Ezekiel 25:3 And say unto the Ammonites, Hear the word of the Lord God; Thus saith the Lord God; Because thou saidst, Aha, against my sanctuary, when it was profaned; and against the land of Israel, when it was desolate; and against the house of Judah, when they went into captivity;

Ezekiel 25:4 Behold, therefore I will deliver thee to the men of the east for a possession, and they shall set their palaces in thee, and make their dwellings in thee: they shall eat thy fruit, and they shall drink thy milk.

Ezekiel 25:5 And I will make Rabbah a stable for camels, and the Ammonites a couchingplace for flocks: and ye shall know that I am the Lord.

Ezekiel 25:6 For thus saith the Lord God; Because thou hast clapped thine hands, and stamped with the feet, and rejoiced in heart with all thy despite against the land of Israel;

Ezekiel 25:7 Behold, therefore I will stretch out mine hand upon thee, and will deliver thee for a spoil to the heathen; and I will cut thee off from the people, and I will cause thee to perish out of the countries: I will destroy thee; and thou shalt know that I am the Lord.

Ezekiel 25:8 Thus saith the Lord God; Because that Moab and Seir do say, Behold, the house of Judah is like unto all the heathen;

Ezekiel 25:9 Therefore, behold, I will open the side of Moab from the cities, from his cities which are on his frontiers, the glory of the country, Beth-jeshimoth, Baal-meon, and Kiriathaim,

Ezekiel 25:10 Unto the men of the east with the Ammonites, and will give them in possession, that the Ammonites may not be remembered among the nations.

Ezekiel 25:11 And I will execute judgments upon Moab; and they shall know that I am the Lord.

Ezekiel 25:12 Thus saith the Lord God; Because that Edom hath dealt against the house of Judah by taking vengeance, and hath greatly offended, and revenged himself upon them;

Ezekiel 25:13 Therefore thus saith the Lord God; I will also stretch out mine hand upon Edom, and will cut off man and beast from it; and I will make it desolate from Teman; and they of Dedan shall fall by the sword.

Ezekiel 25:14 And I will lay my vengeance upon Edom by the hand of my people Israel: and they shall do in Edom according to mine anger and according to my fury; and they shall know my vengeance, saith the Lord God.

Ezekiel 25:15 Thus saith the Lord God; Because the Philistines have dealt by revenge, and have taken vengeance with a despiteful heart, to destroy it for the old hatred;

Ezekiel 25:16 Therefore thus saith the Lord God; Behold, I will stretch out mine hand upon the Philistines, and I will cut off the Cherethims, and destroy the remnant of the sea coast.

Ezekiel 25:17 And I will execute great vengeance upon them with furious rebukes; and they shall know that I am the Lord, when I shall lay my vengeance upon them.
