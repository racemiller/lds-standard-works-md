# Zechariah 9

Zechariah 9 (summary): Zechariah speaks as the Messiah—The Messiah will come, having salvation, lowly and riding upon an ass—He will free the prisoners from the pit—Judah and Ephraim are instruments of the Lord.

Zechariah 9:1 The burden of the word of the Lord in the land of Hadrach, and Damascus shall be the rest thereof: when the eyes of man, as of all the tribes of Israel, shall be toward the Lord.

Zechariah 9:2 And Hamath also shall border thereby; Tyrus, and Zidon, though it be very wise.

Zechariah 9:3 And Tyrus did build herself a strong hold, and heaped up silver as the dust, and fine gold as the mire of the streets.

Zechariah 9:4 Behold, the Lord will cast her out, and he will smite her power in the sea; and she shall be devoured with fire.

Zechariah 9:5 Ashkelon shall see it, and fear; Gaza also shall see it, and be very sorrowful, and Ekron; for her expectation shall be ashamed; and the king shall perish from Gaza, and Ashkelon shall not be inhabited.

Zechariah 9:6 And a bastard shall dwell in Ashdod, and I will cut off the pride of the Philistines.

Zechariah 9:7 And I will take away his blood out of his mouth, and his abominations from between his teeth: but he that remaineth, even he, shall be for our God, and he shall be as a governor in Judah, and Ekron as a Jebusite.

Zechariah 9:8 And I will encamp about mine house because of the army, because of him that passeth by, and because of him that returneth: and no oppressor shall pass through them any more: for now have I seen with mine eyes.

Zechariah 9:9 Rejoice greatly, O daughter of Zion; shout, O daughter of Jerusalem: behold, thy King cometh unto thee: he is just, and having salvation; lowly, and riding upon an ass, and upon a colt the foal of an ass.

Zechariah 9:10 And I will cut off the chariot from Ephraim, and the horse from Jerusalem, and the battle bow shall be cut off: and he shall speak peace unto the heathen: and his dominion shall be from sea even to sea, and from the river even to the ends of the earth.

Zechariah 9:11 As for thee also, by the blood of thy covenant I have sent forth thy prisoners out of the pit wherein is no water.

Zechariah 9:12 Turn you to the strong hold, ye prisoners of hope: even to day do I declare that I will render double unto thee;

Zechariah 9:13 When I have bent Judah for me, filled the bow with Ephraim, and raised up thy sons, O Zion, against thy sons, O Greece, and made thee as the sword of a mighty man.

Zechariah 9:14 And the Lord shall be seen over them, and his arrow shall go forth as the lightning: and the Lord God shall blow the trumpet, and shall go with whirlwinds of the south.

Zechariah 9:15 The Lord of hosts shall defend them; and they shall devour, and subdue with sling stones; and they shall drink, and make a noise as through wine; and they shall be filled like bowls, and as the corners of the altar.

Zechariah 9:16 And the Lord their God shall save them in that day as the flock of his people: for they shall be as the stones of a crown, lifted up as an ensign upon his land.

Zechariah 9:17 For how great is his goodness, and how great is his beauty! corn shall make the young men cheerful, and new wine the maids.
