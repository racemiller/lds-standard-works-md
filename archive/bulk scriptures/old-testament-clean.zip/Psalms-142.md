# Psalms 142

Psalms 142 (summary): David prays for preservation from his persecutors.

Psalms 142:1 I cried unto the Lord with my voice; with my voice unto the Lord did I make my supplication.

Psalms 142:2 I poured out my complaint before him; I shewed before him my trouble.

Psalms 142:3 When my spirit was overwhelmed within me, then thou knewest my path. In the way wherein I walked have they privily laid a snare for me.

Psalms 142:4 I looked on my right hand, and beheld, but there was no man that would know me: refuge failed me; no man cared for my soul.

Psalms 142:5 I cried unto thee, O Lord: I said, Thou art my refuge and my portion in the land of the living.

Psalms 142:6 Attend unto my cry; for I am brought very low: deliver me from my persecutors; for they are stronger than I.

Psalms 142:7 Bring my soul out of prison, that I may praise thy name: the righteous shall compass me about; for thou shalt deal bountifully with me.
