# Ezekiel 33

Ezekiel 33 (summary): Watchmen who raise the warning voice save their own souls—Repentant sinners are saved—The righteous who turn to sin are damned—The people of Judah in Jerusalem are destroyed because of their sins.

Ezekiel 33:1 Again the word of the Lord came unto me, saying,

Ezekiel 33:2 Son of man, speak to the children of thy people, and say unto them, When I bring the sword upon a land, if the people of the land take a man of their coasts, and set him for their watchman:

Ezekiel 33:3 If when he seeth the sword come upon the land, he blow the trumpet, and warn the people;

Ezekiel 33:4 Then whosoever heareth the sound of the trumpet, and taketh not warning; if the sword come, and take him away, his blood shall be upon his own head.

Ezekiel 33:5 He heard the sound of the trumpet, and took not warning; his blood shall be upon him. But he that taketh warning shall deliver his soul.

Ezekiel 33:6 But if the watchman see the sword come, and blow not the trumpet, and the people be not warned; if the sword come, and take any person from among them, he is taken away in his iniquity; but his blood will I require at the watchman’s hand.

Ezekiel 33:7 So thou, O son of man, I have set thee a watchman unto the house of Israel; therefore thou shalt hear the word at my mouth, and warn them from me.

Ezekiel 33:8 When I say unto the wicked, O wicked man, thou shalt surely die; if thou dost not speak to warn the wicked from his way, that wicked man shall die in his iniquity; but his blood will I require at thine hand.

Ezekiel 33:9 Nevertheless, if thou warn the wicked of his way to turn from it; if he do not turn from his way, he shall die in his iniquity; but thou hast delivered thy soul.

Ezekiel 33:10 Therefore, O thou son of man, speak unto the house of Israel; Thus ye speak, saying, If our transgressions and our sins be upon us, and we pine away in them, how should we then live?

Ezekiel 33:11 Say unto them, As I live, saith the Lord God, I have no pleasure in the death of the wicked; but that the wicked turn from his way and live: turn ye, turn ye from your evil ways; for why will ye die, O house of Israel?

Ezekiel 33:12 Therefore, thou son of man, say unto the children of thy people, The righteousness of the righteous shall not deliver him in the day of his transgression: as for the wickedness of the wicked, he shall not fall thereby in the day that he turneth from his wickedness; neither shall the righteous be able to live for his righteousness in the day that he sinneth.

Ezekiel 33:13 When I shall say to the righteous, that he shall surely live; if he trust to his own righteousness, and commit iniquity, all his righteousnesses shall not be remembered; but for his iniquity that he hath committed, he shall die for it.

Ezekiel 33:14 Again, when I say unto the wicked, Thou shalt surely die; if he turn from his sin, and do that which is lawful and right;

Ezekiel 33:15 If the wicked restore the pledge, give again that he had robbed, walk in the statutes of life, without committing iniquity; he shall surely live, he shall not die.

Ezekiel 33:16 None of his sins that he hath committed shall be mentioned unto him: he hath done that which is lawful and right; he shall surely live.

Ezekiel 33:17 Yet the children of thy people say, The way of the Lord is not equal: but as for them, their way is not equal.

Ezekiel 33:18 When the righteous turneth from his righteousness, and committeth iniquity, he shall even die thereby.

Ezekiel 33:19 But if the wicked turn from his wickedness, and do that which is lawful and right, he shall live thereby.

Ezekiel 33:20 Yet ye say, The way of the Lord is not equal. O ye house of Israel, I will judge you every one after his ways.

Ezekiel 33:21 And it came to pass in the twelfth year of our captivity, in the tenth month, in the fifth day of the month, that one that had escaped out of Jerusalem came unto me, saying, The city is smitten.

Ezekiel 33:22 Now the hand of the Lord was upon me in the evening, afore he that was escaped came; and had opened my mouth, until he came to me in the morning; and my mouth was opened, and I was no more dumb.

Ezekiel 33:23 Then the word of the Lord came unto me, saying,

Ezekiel 33:24 Son of man, they that inhabit those wastes of the land of Israel speak, saying, Abraham was one, and he inherited the land: but we are many; the land is given us for inheritance.

Ezekiel 33:25 Wherefore say unto them, Thus saith the Lord God; Ye eat with the blood, and lift up your eyes toward your idols, and shed blood: and shall ye possess the land?

Ezekiel 33:26 Ye stand upon your sword, ye work abomination, and ye defile every one his neighbour’s wife: and shall ye possess the land?

Ezekiel 33:27 Say thou thus unto them, Thus saith the Lord God; As I live, surely they that are in the wastes shall fall by the sword, and him that is in the open field will I give to the beasts to be devoured, and they that be in the forts and in the caves shall die of the pestilence.

Ezekiel 33:28 For I will lay the land most desolate, and the pomp of her strength shall cease; and the mountains of Israel shall be desolate, that none shall pass through.

Ezekiel 33:29 Then shall they know that I am the Lord, when I have laid the land most desolate because of all their abominations which they have committed.

Ezekiel 33:30 Also, thou son of man, the children of thy people still are talking against thee by the walls and in the doors of the houses, and speak one to another, every one to his brother, saying, Come, I pray you, and hear what is the word that cometh forth from the Lord.

Ezekiel 33:31 And they come unto thee as the people cometh, and they sit before thee as my people, and they hear thy words, but they will not do them: for with their mouth they shew much love, but their heart goeth after their covetousness.

Ezekiel 33:32 And, lo, thou art unto them as a very lovely song of one that hath a pleasant voice, and can play well on an instrument: for they hear thy words, but they do them not.

Ezekiel 33:33 And when this cometh to pass, (lo, it will come,) then shall they know that a prophet hath been among them.
