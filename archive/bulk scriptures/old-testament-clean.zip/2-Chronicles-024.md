# 2 Chronicles 24

2 Chronicles 24 (summary): Joash and Jehoiada receive contributions and repair the house of the Lord—Jehoiada dies—Joash falls into idolatry, slays a prophet named Zechariah, and is himself slain in a conspiracy.

2 Chronicles 24:1 Joash was seven years old when he began to reign, and he reigned forty years in Jerusalem. His mother’s name also was Zibiah of Beer-sheba.

2 Chronicles 24:2 And Joash did that which was right in the sight of the Lord all the days of Jehoiada the priest.

2 Chronicles 24:3 And Jehoiada took for him two wives; and he begat sons and daughters.

2 Chronicles 24:4 And it came to pass after this, that Joash was minded to repair the house of the Lord.

2 Chronicles 24:5 And he gathered together the priests and the Levites, and said to them, Go out unto the cities of Judah, and gather of all Israel money to repair the house of your God from year to year, and see that ye hasten the matter. Howbeit the Levites hastened it not.

2 Chronicles 24:6 And the king called for Jehoiada the chief, and said unto him, Why hast thou not required of the Levites to bring in out of Judah and out of Jerusalem the collection, according to the commandment of Moses the servant of the Lord, and of the congregation of Israel, for the tabernacle of witness?

2 Chronicles 24:7 For the sons of Athaliah, that wicked woman, had broken up the house of God; and also all the dedicated things of the house of the Lord did they bestow upon Baalim.

2 Chronicles 24:8 And at the king’s commandment they made a chest, and set it without at the gate of the house of the Lord.

2 Chronicles 24:9 And they made a proclamation through Judah and Jerusalem, to bring in to the Lord the collection that Moses the servant of God laid upon Israel in the wilderness.

2 Chronicles 24:10 And all the princes and all the people rejoiced, and brought in, and cast into the chest, until they had made an end.

2 Chronicles 24:11 Now it came to pass, that at what time the chest was brought unto the king’s office by the hand of the Levites, and when they saw that there was much money, the king’s scribe and the high priest’s officer came and emptied the chest, and took it, and carried it to his place again. Thus they did day by day, and gathered money in abundance.

2 Chronicles 24:12 And the king and Jehoiada gave it to such as did the work of the service of the house of the Lord, and hired masons and carpenters to repair the house of the Lord, and also such as wrought iron and brass to mend the house of the Lord.

2 Chronicles 24:13 So the workmen wrought, and the work was perfected by them, and they set the house of God in his state, and strengthened it.

2 Chronicles 24:14 And when they had finished it, they brought the rest of the money before the king and Jehoiada, whereof were made vessels for the house of the Lord, even vessels to minister, and to offer withal, and spoons, and vessels of gold and silver. And they offered burnt offerings in the house of the Lord continually all the days of Jehoiada.

2 Chronicles 24:15 But Jehoiada waxed old, and was full of days when he died; an hundred and thirty years old was he when he died.

2 Chronicles 24:16 And they buried him in the city of David among the kings, because he had done good in Israel, both toward God, and toward his house.

2 Chronicles 24:17 Now after the death of Jehoiada came the princes of Judah, and made obeisance to the king. Then the king hearkened unto them.

2 Chronicles 24:18 And they left the house of the Lord God of their fathers, and served groves and idols: and wrath came upon Judah and Jerusalem for this their trespass.

2 Chronicles 24:19 Yet he sent prophets to them, to bring them again unto the Lord; and they testified against them: but they would not give ear.

2 Chronicles 24:20 And the Spirit of God came upon Zechariah the son of Jehoiada the priest, which stood above the people, and said unto them, Thus saith God, Why transgress ye the commandments of the Lord, that ye cannot prosper? because ye have forsaken the Lord, he hath also forsaken you.

2 Chronicles 24:21 And they conspired against him, and stoned him with stones at the commandment of the king in the court of the house of the Lord.

2 Chronicles 24:22 Thus Joash the king remembered not the kindness which Jehoiada his father had done to him, but slew his son. And when he died, he said, The Lord look upon it, and require it.

2 Chronicles 24:23 And it came to pass at the end of the year, that the host of Syria came up against him: and they came to Judah and Jerusalem, and destroyed all the princes of the people from among the people, and sent all the spoil of them unto the king of Damascus.

2 Chronicles 24:24 For the army of the Syrians came with a small company of men, and the Lord delivered a very great host into their hand, because they had forsaken the Lord God of their fathers. So they executed judgment against Joash.

2 Chronicles 24:25 And when they were departed from him, (for they left him in great diseases,) his own servants conspired against him for the blood of the sons of Jehoiada the priest, and slew him on his bed, and he died: and they buried him in the city of David, but they buried him not in the sepulchres of the kings.

2 Chronicles 24:26 And these are they that conspired against him; Zabad the son of Shimeath an Ammonitess, and Jehozabad the son of Shimrith a Moabitess.

2 Chronicles 24:27 Now concerning his sons, and the greatness of the burdens laid upon him, and the repairing of the house of God, behold, they are written in the story of the book of the kings. And Amaziah his son reigned in his stead.
