# Exodus 16

Exodus 16 (summary): Israel murmurs for want of bread and lusts for the fleshpots of Egypt—The Lord rains bread from heaven and sends quail for meat—Israel is given manna each day, except the Sabbath, for forty years.

Exodus 16:1 And they took their journey from Elim, and all the congregation of the children of Israel came unto the wilderness of Sin, which is between Elim and Sinai, on the fifteenth day of the second month after their departing out of the land of Egypt.

Exodus 16:2 And the whole congregation of the children of Israel murmured against Moses and Aaron in the wilderness:

Exodus 16:3 And the children of Israel said unto them, Would to God we had died by the hand of the Lord in the land of Egypt, when we sat by the flesh pots, and when we did eat bread to the full; for ye have brought us forth into this wilderness, to kill this whole assembly with hunger.

Exodus 16:4 Then said the Lord unto Moses, Behold, I will rain bread from heaven for you; and the people shall go out and gather a certain rate every day, that I may prove them, whether they will walk in my law, or no.

Exodus 16:5 And it shall come to pass, that on the sixth day they shall prepare that which they bring in; and it shall be twice as much as they gather daily.

Exodus 16:6 And Moses and Aaron said unto all the children of Israel, At even, then ye shall know that the Lord hath brought you out from the land of Egypt:

Exodus 16:7 And in the morning, then ye shall see the glory of the Lord; for that he heareth your murmurings against the Lord: and what are we, that ye murmur against us?

Exodus 16:8 And Moses said, This shall be, when the Lord shall give you in the evening flesh to eat, and in the morning bread to the full; for that the Lord heareth your murmurings which ye murmur against him: and what are we? your murmurings are not against us, but against the Lord.

Exodus 16:9 And Moses spake unto Aaron, Say unto all the congregation of the children of Israel, Come near before the Lord: for he hath heard your murmurings.

Exodus 16:10 And it came to pass, as Aaron spake unto the whole congregation of the children of Israel, that they looked toward the wilderness, and, behold, the glory of the Lord appeared in the cloud.

Exodus 16:11 And the Lord spake unto Moses, saying,

Exodus 16:12 I have heard the murmurings of the children of Israel: speak unto them, saying, At even ye shall eat flesh, and in the morning ye shall be filled with bread; and ye shall know that I am the Lord your God.

Exodus 16:13 And it came to pass, that at even the quails came up, and covered the camp: and in the morning the dew lay round about the host.

Exodus 16:14 And when the dew that lay was gone up, behold, upon the face of the wilderness there lay a small round thing, as small as the hoar frost on the ground.

Exodus 16:15 And when the children of Israel saw it, they said one to another, It is manna: for they wist not what it was. And Moses said unto them, This is the bread which the Lord hath given you to eat.

Exodus 16:16 This is the thing which the Lord hath commanded, Gather of it every man according to his eating, an omer for every man, according to the number of your persons; take ye every man for them which are in his tents.

Exodus 16:17 And the children of Israel did so, and gathered, some more, some less.

Exodus 16:18 And when they did mete it with an omer, he that gathered much had nothing over, and he that gathered little had no lack; they gathered every man according to his eating.

Exodus 16:19 And Moses said, Let no man leave of it till the morning.

Exodus 16:20 Notwithstanding they hearkened not unto Moses; but some of them left of it until the morning, and it bred worms, and stank: and Moses was wroth with them.

Exodus 16:21 And they gathered it every morning, every man according to his eating: and when the sun waxed hot, it melted.

Exodus 16:22 And it came to pass, that on the sixth day they gathered twice as much bread, two omers for one man: and all the rulers of the congregation came and told Moses.

Exodus 16:23 And he said unto them, This is that which the Lord hath said, To morrow is the rest of the holy sabbath unto the Lord: bake that which ye will bake to day, and seethe that ye will seethe; and that which remaineth over lay up for you to be kept until the morning.

Exodus 16:24 And they laid it up till the morning, as Moses bade: and it did not stink, neither was there any worm therein.

Exodus 16:25 And Moses said, Eat that to day; for to day is a sabbath unto the Lord: to day ye shall not find it in the field.

Exodus 16:26 Six days ye shall gather it; but on the seventh day, which is the sabbath, in it there shall be none.

Exodus 16:27 And it came to pass, that there went out some of the people on the seventh day for to gather, and they found none.

Exodus 16:28 And the Lord said unto Moses, How long refuse ye to keep my commandments and my laws?

Exodus 16:29 See, for that the Lord hath given you the sabbath, therefore he giveth you on the sixth day the bread of two days; abide ye every man in his place, let no man go out of his place on the seventh day.

Exodus 16:30 So the people rested on the seventh day.

Exodus 16:31 And the house of Israel called the name thereof Manna: and it was like coriander seed, white; and the taste of it was like wafers made with honey.

Exodus 16:32 And Moses said, This is the thing which the Lord commandeth, Fill an omer of it to be kept for your generations; that they may see the bread wherewith I have fed you in the wilderness, when I brought you forth from the land of Egypt.

Exodus 16:33 And Moses said unto Aaron, Take a pot, and put an omer full of manna therein, and lay it up before the Lord, to be kept for your generations.

Exodus 16:34 As the Lord commanded Moses, so Aaron laid it up before the Testimony, to be kept.

Exodus 16:35 And the children of Israel did eat manna forty years, until they came to a land inhabited; they did eat manna, until they came unto the borders of the land of Canaan.

Exodus 16:36 Now an omer is the tenth part of an ephah.
