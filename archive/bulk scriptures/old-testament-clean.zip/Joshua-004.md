# Joshua 4

Joshua 4 (summary): Joshua places twelve stones to commemorate the crossing of the Jordan—Joshua is magnified before the children of Israel as they cross the Jordan—After the priests bearing the ark pass over, the river returns to its course.

Joshua 4:1 And it came to pass, when all the people were clean passed over Jordan, that the Lord spake unto Joshua, saying,

Joshua 4:2 Take you twelve men out of the people, out of every tribe a man,

Joshua 4:3 And command ye them, saying, Take you hence out of the midst of Jordan, out of the place where the priests’ feet stood firm, twelve stones, and ye shall carry them over with you, and leave them in the lodging place, where ye shall lodge this night.

Joshua 4:4 Then Joshua called the twelve men, whom he had prepared of the children of Israel, out of every tribe a man:

Joshua 4:5 And Joshua said unto them, Pass over before the ark of the Lord your God into the midst of Jordan, and take ye up every man of you a stone upon his shoulder, according unto the number of the tribes of the children of Israel:

Joshua 4:6 That this may be a sign among you, that when your children ask their fathers in time to come, saying, What mean ye by these stones?

Joshua 4:7 Then ye shall answer them, That the waters of Jordan were cut off before the ark of the covenant of the Lord; when it passed over Jordan, the waters of Jordan were cut off: and these stones shall be for a memorial unto the children of Israel for ever.

Joshua 4:8 And the children of Israel did so as Joshua commanded, and took up twelve stones out of the midst of Jordan, as the Lord spake unto Joshua, according to the number of the tribes of the children of Israel, and carried them over with them unto the place where they lodged, and laid them down there.

Joshua 4:9 And Joshua set up twelve stones in the midst of Jordan, in the place where the feet of the priests which bare the ark of the covenant stood: and they are there unto this day.

Joshua 4:10 For the priests which bare the ark stood in the midst of Jordan, until every thing was finished that the Lord commanded Joshua to speak unto the people, according to all that Moses commanded Joshua: and the people hasted and passed over.

Joshua 4:11 And it came to pass, when all the people were clean passed over, that the ark of the Lord passed over, and the priests, in the presence of the people.

Joshua 4:12 And the children of Reuben, and the children of Gad, and half the tribe of Manasseh, passed over armed before the children of Israel, as Moses spake unto them:

Joshua 4:13 About forty thousand prepared for war passed over before the Lord unto battle, to the plains of Jericho.

Joshua 4:14 On that day the Lord magnified Joshua in the sight of all Israel; and they feared him, as they feared Moses, all the days of his life.

Joshua 4:15 And the Lord spake unto Joshua, saying,

Joshua 4:16 Command the priests that bear the ark of the testimony, that they come up out of Jordan.

Joshua 4:17 Joshua therefore commanded the priests, saying, Come ye up out of Jordan.

Joshua 4:18 And it came to pass, when the priests that bare the ark of the covenant of the Lord were come up out of the midst of Jordan, and the soles of the priests’ feet were lifted up unto the dry land, that the waters of Jordan returned unto their place, and flowed over all his banks, as they did before.

Joshua 4:19 And the people came up out of Jordan on the tenth day of the first month, and encamped in Gilgal, in the east border of Jericho.

Joshua 4:20 And those twelve stones, which they took out of Jordan, did Joshua pitch in Gilgal.

Joshua 4:21 And he spake unto the children of Israel, saying, When your children shall ask their fathers in time to come, saying, What mean these stones?

Joshua 4:22 Then ye shall let your children know, saying, Israel came over this Jordan on dry land.

Joshua 4:23 For the Lord your God dried up the waters of Jordan from before you, until ye were passed over, as the Lord your God did to the Red sea, which he dried up from before us, until we were gone over:

Joshua 4:24 That all the people of the earth might know the hand of the Lord, that it is mighty: that ye might fear the Lord your God for ever.
