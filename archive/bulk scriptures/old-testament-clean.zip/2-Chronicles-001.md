# 2 Chronicles 1

2 Chronicles 1 (summary): The Lord honors Solomon before all Israel—The Lord appears to him—Solomon chooses and is given wisdom—His kingdom is blessed with splendor and riches.

2 Chronicles 1:1 And Solomon the son of David was strengthened in his kingdom, and the Lord his God was with him, and magnified him exceedingly.

2 Chronicles 1:2 Then Solomon spake unto all Israel, to the captains of thousands and of hundreds, and to the judges, and to every governor in all Israel, the chief of the fathers.

2 Chronicles 1:3 So Solomon, and all the congregation with him, went to the high place that was at Gibeon; for there was the tabernacle of the congregation of God, which Moses the servant of the Lord had made in the wilderness.

2 Chronicles 1:4 But the ark of God had David brought up from Kirjath-jearim to the place which David had prepared for it: for he had pitched a tent for it at Jerusalem.

2 Chronicles 1:5 Moreover the brasen altar, that Bezaleel the son of Uri, the son of Hur, had made, he put before the tabernacle of the Lord: and Solomon and the congregation sought unto it.

2 Chronicles 1:6 And Solomon went up thither to the brasen altar before the Lord, which was at the tabernacle of the congregation, and offered a thousand burnt offerings upon it.

2 Chronicles 1:7 In that night did God appear unto Solomon, and said unto him, Ask what I shall give thee.

2 Chronicles 1:8 And Solomon said unto God, Thou hast shewed great mercy unto David my father, and hast made me to reign in his stead.

2 Chronicles 1:9 Now, O Lord God, let thy promise unto David my father be established: for thou hast made me king over a people like the dust of the earth in multitude.

2 Chronicles 1:10 Give me now wisdom and knowledge, that I may go out and come in before this people: for who can judge this thy people, that is so great?

2 Chronicles 1:11 And God said to Solomon, Because this was in thine heart, and thou hast not asked riches, wealth, or honour, nor the life of thine enemies, neither yet hast asked long life; but hast asked wisdom and knowledge for thyself, that thou mayest judge my people, over whom I have made thee king:

2 Chronicles 1:12 Wisdom and knowledge is granted unto thee; and I will give thee riches, and wealth, and honour, such as none of the kings have had that have been before thee, neither shall there any after thee have the like.

2 Chronicles 1:13 Then Solomon came from his journey to the high place that was at Gibeon to Jerusalem, from before the tabernacle of the congregation, and reigned over Israel.

2 Chronicles 1:14 And Solomon gathered chariots and horsemen: and he had a thousand and four hundred chariots, and twelve thousand horsemen, which he placed in the chariot cities, and with the king at Jerusalem.

2 Chronicles 1:15 And the king made silver and gold at Jerusalem as plenteous as stones, and cedar trees made he as the sycomore trees that are in the vale for abundance.

2 Chronicles 1:16 And Solomon had horses brought out of Egypt, and linen yarn: the king’s merchants received the linen yarn at a price.

2 Chronicles 1:17 And they fetched up, and brought forth out of Egypt a chariot for six hundred shekels of silver, and an horse for an hundred and fifty: and so brought they out horses for all the kings of the Hittites, and for the kings of Syria, by their means.
