# Joshua 1

Joshua 1 (summary): The Lord speaks to Joshua—He is commanded to be of good courage, to meditate upon the law, and to keep the commandments—He prepares Israel to enter Canaan.

Joshua 1:1 Now after the death of Moses the servant of the Lord it came to pass, that the Lord spake unto Joshua the son of Nun, Moses’ minister, saying,

Joshua 1:2 Moses my servant is dead; now therefore arise, go over this Jordan, thou, and all this people, unto the land which I do give to them, even to the children of Israel.

Joshua 1:3 Every place that the sole of your foot shall tread upon, that have I given unto you, as I said unto Moses.

Joshua 1:4 From the wilderness and this Lebanon even unto the great river, the river Euphrates, all the land of the Hittites, and unto the great sea toward the going down of the sun, shall be your coast.

Joshua 1:5 There shall not any man be able to stand before thee all the days of thy life: as I was with Moses, so I will be with thee: I will not fail thee, nor forsake thee.

Joshua 1:6 Be strong and of a good courage: for unto this people shalt thou divide for an inheritance the land, which I sware unto their fathers to give them.

Joshua 1:7 Only be thou strong and very courageous, that thou mayest observe to do according to all the law, which Moses my servant commanded thee: turn not from it to the right hand or to the left, that thou mayest prosper whithersoever thou goest.

Joshua 1:8 This book of the law shall not depart out of thy mouth; but thou shalt meditate therein day and night, that thou mayest observe to do according to all that is written therein: for then thou shalt make thy way prosperous, and then thou shalt have good success.

Joshua 1:9 Have not I commanded thee? Be strong and of a good courage; be not afraid, neither be thou dismayed: for the Lord thy God is with thee whithersoever thou goest.

Joshua 1:10 Then Joshua commanded the officers of the people, saying,

Joshua 1:11 Pass through the host, and command the people, saying, Prepare you victuals; for within three days ye shall pass over this Jordan, to go in to possess the land, which the Lord your God giveth you to possess it.

Joshua 1:12 And to the Reubenites, and to the Gadites, and to half the tribe of Manasseh, spake Joshua, saying,

Joshua 1:13 Remember the word which Moses the servant of the Lord commanded you, saying, The Lord your God hath given you rest, and hath given you this land.

Joshua 1:14 Your wives, your little ones, and your cattle, shall remain in the land which Moses gave you on this side Jordan; but ye shall pass before your brethren armed, all the mighty men of valour, and help them;

Joshua 1:15 Until the Lord have given your brethren rest, as he hath given you, and they also have possessed the land which the Lord your God giveth them: then ye shall return unto the land of your possession, and enjoy it, which Moses the Lord’s servant gave you on this side Jordan toward the sunrising.

Joshua 1:16 And they answered Joshua, saying, All that thou commandest us we will do, and whithersoever thou sendest us, we will go.

Joshua 1:17 According as we hearkened unto Moses in all things, so will we hearken unto thee: only the Lord thy God be with thee, as he was with Moses.

Joshua 1:18 Whosoever he be that doth rebel against thy commandment, and will not hearken unto thy words in all that thou commandest him, he shall be put to death: only be strong and of a good courage.
