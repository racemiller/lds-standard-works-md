# Zechariah 12

Zechariah 12 (summary): In the final great war, all nations will be engaged at Jerusalem, but the Lord will defend His people—Then the Jews will look upon the Lord, whom they crucified, and there will be great mourning.

Zechariah 12:1 The burden of the word of the Lord for Israel, saith the Lord, which stretcheth forth the heavens, and layeth the foundation of the earth, and formeth the spirit of man within him.

Zechariah 12:2 Behold, I will make Jerusalem a cup of trembling unto all the people round about, when they shall be in the siege both against Judah and against Jerusalem.

Zechariah 12:3 And in that day will I make Jerusalem a burdensome stone for all people: all that burden themselves with it shall be cut in pieces, though all the people of the earth be gathered together against it.

Zechariah 12:4 In that day, saith the Lord, I will smite every horse with astonishment, and his rider with madness: and I will open mine eyes upon the house of Judah, and will smite every horse of the people with blindness.

Zechariah 12:5 And the governors of Judah shall say in their heart, The inhabitants of Jerusalem shall be my strength in the Lord of hosts their God.

Zechariah 12:6 In that day will I make the governors of Judah like an hearth of fire among the wood, and like a torch of fire in a sheaf; and they shall devour all the people round about, on the right hand and on the left: and Jerusalem shall be inhabited again in her own place, even in Jerusalem.

Zechariah 12:7 The Lord also shall save the tents of Judah first, that the glory of the house of David and the glory of the inhabitants of Jerusalem do not magnify themselves against Judah.

Zechariah 12:8 In that day shall the Lord defend the inhabitants of Jerusalem; and he that is feeble among them at that day shall be as David; and the house of David shall be as God, as the angel of the Lord before them.

Zechariah 12:9 And it shall come to pass in that day, that I will seek to destroy all the nations that come against Jerusalem.

Zechariah 12:10 And I will pour upon the house of David, and upon the inhabitants of Jerusalem, the spirit of grace and of supplications: and they shall look upon me whom they have pierced, and they shall mourn for him, as one mourneth for his only son, and shall be in bitterness for him, as one that is in bitterness for his firstborn.

Zechariah 12:11 In that day shall there be a great mourning in Jerusalem, as the mourning of Hadadrimmon in the valley of Megiddon.

Zechariah 12:12 And the land shall mourn, every family apart; the family of the house of David apart, and their wives apart; the family of the house of Nathan apart, and their wives apart;

Zechariah 12:13 The family of the house of Levi apart, and their wives apart; the family of Shimei apart, and their wives apart;

Zechariah 12:14 All the families that remain, every family apart, and their wives apart.
