# 2 Chronicles 14

2 Chronicles 14 (summary): Asa reigns in Judah, rebuilds the cities, and defeats and plunders the Ethiopians, who attack Judah.

2 Chronicles 14:1 So Abijah slept with his fathers, and they buried him in the city of David: and Asa his son reigned in his stead. In his days the land was quiet ten years.

2 Chronicles 14:2 And Asa did that which was good and right in the eyes of the Lord his God:

2 Chronicles 14:3 For he took away the altars of the strange gods, and the high places, and brake down the images, and cut down the groves:

2 Chronicles 14:4 And commanded Judah to seek the Lord God of their fathers, and to do the law and the commandment.

2 Chronicles 14:5 Also he took away out of all the cities of Judah the high places and the images: and the kingdom was quiet before him.

2 Chronicles 14:6 And he built fenced cities in Judah: for the land had rest, and he had no war in those years; because the Lord had given him rest.

2 Chronicles 14:7 Therefore he said unto Judah, Let us build these cities, and make about them walls, and towers, gates, and bars, while the land is yet before us; because we have sought the Lord our God, we have sought him, and he hath given us rest on every side. So they built and prospered.

2 Chronicles 14:8 And Asa had an army of men that bare targets and spears, out of Judah three hundred thousand; and out of Benjamin, that bare shields and drew bows, two hundred and fourscore thousand: all these were mighty men of valour.

2 Chronicles 14:9 And there came out against them Zerah the Ethiopian with an host of a thousand thousand, and three hundred chariots; and came unto Mareshah.

2 Chronicles 14:10 Then Asa went out against him, and they set the battle in array in the valley of Zephathah at Mareshah.

2 Chronicles 14:11 And Asa cried unto the Lord his God, and said, Lord, it is nothing with thee to help, whether with many, or with them that have no power: help us, O Lord our God; for we rest on thee, and in thy name we go against this multitude. O Lord, thou art our God; let not man prevail against thee.

2 Chronicles 14:12 So the Lord smote the Ethiopians before Asa, and before Judah; and the Ethiopians fled.

2 Chronicles 14:13 And Asa and the people that were with him pursued them unto Gerar: and the Ethiopians were overthrown, that they could not recover themselves; for they were destroyed before the Lord, and before his host; and they carried away very much spoil.

2 Chronicles 14:14 And they smote all the cities round about Gerar; for the fear of the Lord came upon them: and they spoiled all the cities; for there was exceeding much spoil in them.

2 Chronicles 14:15 They smote also the tents of cattle, and carried away sheep and camels in abundance, and returned to Jerusalem.
