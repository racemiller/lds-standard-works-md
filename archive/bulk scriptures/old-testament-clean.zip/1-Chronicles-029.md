# 1 Chronicles 29

1 Chronicles 29 (summary): All Israel makes a liberal offering for the temple—David blesses and praises the Lord and instructs the people—David dies—Solomon reigns as king—The books of Nathan and Gad are mentioned.

1 Chronicles 29:1 Furthermore David the king said unto all the congregation, Solomon my son, whom alone God hath chosen, is yet young and tender, and the work is great: for the palace is not for man, but for the Lord God.

1 Chronicles 29:2 Now I have prepared with all my might for the house of my God the gold for things to be made of gold, and the silver for things of silver, and the brass for things of brass, the iron for things of iron, and wood for things of wood; onyx stones, and stones to be set, glistering stones, and of divers colours, and all manner of precious stones, and marble stones in abundance.

1 Chronicles 29:3 Moreover, because I have set my affection to the house of my God, I have of mine own proper good, of gold and silver, which I have given to the house of my God, over and above all that I have prepared for the holy house,

1 Chronicles 29:4 Even three thousand talents of gold, of the gold of Ophir, and seven thousand talents of refined silver, to overlay the walls of the houses withal:

1 Chronicles 29:5 The gold for things of gold, and the silver for things of silver, and for all manner of work to be made by the hands of artificers. And who then is willing to consecrate his service this day unto the Lord?

1 Chronicles 29:6 Then the chief of the fathers and princes of the tribes of Israel, and the captains of thousands and of hundreds, with the rulers of the king’s work, offered willingly,

1 Chronicles 29:7 And gave for the service of the house of God of gold five thousand talents and ten thousand drams, and of silver ten thousand talents, and of brass eighteen thousand talents, and one hundred thousand talents of iron.

1 Chronicles 29:8 And they with whom precious stones were found gave them to the treasure of the house of the Lord, by the hand of Jehiel the Gershonite.

1 Chronicles 29:9 Then the people rejoiced, for that they offered willingly, because with perfect heart they offered willingly to the Lord: and David the king also rejoiced with great joy.

1 Chronicles 29:10 Wherefore David blessed the Lord before all the congregation: and David said, Blessed be thou, Lord God of Israel our father, for ever and ever.

1 Chronicles 29:11 Thine, O Lord, is the greatness, and the power, and the glory, and the victory, and the majesty: for all that is in the heaven and in the earth is thine; thine is the kingdom, O Lord, and thou art exalted as head above all.

1 Chronicles 29:12 Both riches and honour come of thee, and thou reignest over all; and in thine hand is power and might; and in thine hand it is to make great, and to give strength unto all.

1 Chronicles 29:13 Now therefore, our God, we thank thee, and praise thy glorious name.

1 Chronicles 29:14 But who am I, and what is my people, that we should be able to offer so willingly after this sort? for all things come of thee, and of thine own have we given thee.

1 Chronicles 29:15 For we are strangers before thee, and sojourners, as were all our fathers: our days on the earth are as a shadow, and there is none abiding.

1 Chronicles 29:16 O Lord our God, all this store that we have prepared to build thee an house for thine holy name cometh of thine hand, and is all thine own.

1 Chronicles 29:17 I know also, my God, that thou triest the heart, and hast pleasure in uprightness. As for me, in the uprightness of mine heart I have willingly offered all these things: and now have I seen with joy thy people, which are present here, to offer willingly unto thee.

1 Chronicles 29:18 O Lord God of Abraham, Isaac, and of Israel, our fathers, keep this for ever in the imagination of the thoughts of the heart of thy people, and prepare their heart unto thee:

1 Chronicles 29:19 And give unto Solomon my son a perfect heart, to keep thy commandments, thy testimonies, and thy statutes, and to do all these things, and to build the palace, for the which I have made provision.

1 Chronicles 29:20 And David said to all the congregation, Now bless the Lord your God. And all the congregation blessed the Lord God of their fathers, and bowed down their heads, and worshipped the Lord, and the king.

1 Chronicles 29:21 And they sacrificed sacrifices unto the Lord, and offered burnt offerings unto the Lord, on the morrow after that day, even a thousand bullocks, a thousand rams, and a thousand lambs, with their drink offerings, and sacrifices in abundance for all Israel:

1 Chronicles 29:22 And did eat and drink before the Lord on that day with great gladness. And they made Solomon the son of David king the second time, and anointed him unto the Lord to be the chief governor, and Zadok to be priest.

1 Chronicles 29:23 Then Solomon sat on the throne of the Lord as king instead of David his father, and prospered; and all Israel obeyed him.

1 Chronicles 29:24 And all the princes, and the mighty men, and all the sons likewise of king David, submitted themselves unto Solomon the king.

1 Chronicles 29:25 And the Lord magnified Solomon exceedingly in the sight of all Israel, and bestowed upon him such royal majesty as had not been on any king before him in Israel.

1 Chronicles 29:26 Thus David the son of Jesse reigned over all Israel.

1 Chronicles 29:27 And the time that he reigned over Israel was forty years; seven years reigned he in Hebron, and thirty and three years reigned he in Jerusalem.

1 Chronicles 29:28 And he died in a good old age, full of days, riches, and honour: and Solomon his son reigned in his stead.

1 Chronicles 29:29 Now the acts of David the king, first and last, behold, they are written in the book of Samuel the seer, and in the book of Nathan the prophet, and in the book of Gad the seer,

1 Chronicles 29:30 With all his reign and his might, and the times that went over him, and over Israel, and over all the kingdoms of the countries.
