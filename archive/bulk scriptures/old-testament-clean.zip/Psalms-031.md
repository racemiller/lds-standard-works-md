# Psalms 31

Psalms 31 (summary): David trusts in the Lord and rejoices in His mercy—Speaking as the Messiah he says, Into Thine hand I commit my spirit—He counsels, O love the Lord, all ye His Saints, for the Lord preserves the faithful.

Psalms 31:1 In thee, O Lord, do I put my trust; let me never be ashamed: deliver me in thy righteousness.

Psalms 31:2 Bow down thine ear to me; deliver me speedily: be thou my strong rock, for an house of defence to save me.

Psalms 31:3 For thou art my rock and my fortress; therefore for thy name’s sake lead me, and guide me.

Psalms 31:4 Pull me out of the net that they have laid privily for me: for thou art my strength.

Psalms 31:5 Into thine hand I commit my spirit: thou hast redeemed me, O Lord God of truth.

Psalms 31:6 I have hated them that regard lying vanities: but I trust in the Lord.

Psalms 31:7 I will be glad and rejoice in thy mercy: for thou hast considered my trouble; thou hast known my soul in adversities;

Psalms 31:8 And hast not shut me up into the hand of the enemy: thou hast set my feet in a large room.

Psalms 31:9 Have mercy upon me, O Lord, for I am in trouble: mine eye is consumed with grief, yea, my soul and my belly.

Psalms 31:10 For my life is spent with grief, and my years with sighing: my strength faileth because of mine iniquity, and my bones are consumed.

Psalms 31:11 I was a reproach among all mine enemies, but especially among my neighbours, and a fear to mine acquaintance: they that did see me without fled from me.

Psalms 31:12 I am forgotten as a dead man out of mind: I am like a broken vessel.

Psalms 31:13 For I have heard the slander of many: fear was on every side: while they took counsel together against me, they devised to take away my life.

Psalms 31:14 But I trusted in thee, O Lord: I said, Thou art my God.

Psalms 31:15 My times are in thy hand: deliver me from the hand of mine enemies, and from them that persecute me.

Psalms 31:16 Make thy face to shine upon thy servant: save me for thy mercies’ sake.

Psalms 31:17 Let me not be ashamed, O Lord; for I have called upon thee: let the wicked be ashamed, and let them be silent in the grave.

Psalms 31:18 Let the lying lips be put to silence; which speak grievous things proudly and contemptuously against the righteous.

Psalms 31:19 Oh how great is thy goodness, which thou hast laid up for them that fear thee; which thou hast wrought for them that trust in thee before the sons of men!

Psalms 31:20 Thou shalt hide them in the secret of thy presence from the pride of man: thou shalt keep them secretly in a pavilion from the strife of tongues.

Psalms 31:21 Blessed be the Lord: for he hath shewed me his marvellous kindness in a strong city.

Psalms 31:22 For I said in my haste, I am cut off from before thine eyes: nevertheless thou heardest the voice of my supplications when I cried unto thee.

Psalms 31:23 O love the Lord, all ye his saints: for the Lord preserveth the faithful, and plentifully rewardeth the proud doer.

Psalms 31:24 Be of good courage, and he shall strengthen your heart, all ye that hope in the Lord.
