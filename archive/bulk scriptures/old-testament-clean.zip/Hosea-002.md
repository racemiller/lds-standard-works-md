# Hosea 2

Hosea 2 (summary): Worshipping false gods brings severe judgments upon Israel—In the last days, Israel will be reconciled to God and become His people.

Hosea 2:1 Say ye unto your brethren, Ammi; and to your sisters, Ruhamah.

Hosea 2:2 Plead with your mother, plead: for she is not my wife, neither am I her husband: let her therefore put away her whoredoms out of her sight, and her adulteries from between her breasts;

Hosea 2:3 Lest I strip her naked, and set her as in the day that she was born, and make her as a wilderness, and set her like a dry land, and slay her with thirst.

Hosea 2:4 And I will not have mercy upon her children; for they be the children of whoredoms.

Hosea 2:5 For their mother hath played the harlot: she that conceived them hath done shamefully: for she said, I will go after my lovers, that give me my bread and my water, my wool and my flax, mine oil and my drink.

Hosea 2:6 Therefore, behold, I will hedge up thy way with thorns, and make a wall, that she shall not find her paths.

Hosea 2:7 And she shall follow after her lovers, but she shall not overtake them; and she shall seek them, but shall not find them: then shall she say, I will go and return to my first husband; for then was it better with me than now.

Hosea 2:8 For she did not know that I gave her corn, and wine, and oil, and multiplied her silver and gold, which they prepared for Baal.

Hosea 2:9 Therefore will I return, and take away my corn in the time thereof, and my wine in the season thereof, and will recover my wool and my flax given to cover her nakedness.

Hosea 2:10 And now will I discover her lewdness in the sight of her lovers, and none shall deliver her out of mine hand.

Hosea 2:11 I will also cause all her mirth to cease, her feast days, her new moons, and her sabbaths, and all her solemn feasts.

Hosea 2:12 And I will destroy her vines and her fig trees, whereof she hath said, These are my rewards that my lovers have given me: and I will make them a forest, and the beasts of the field shall eat them.

Hosea 2:13 And I will visit upon her the days of Baalim, wherein she burned incense to them, and she decked herself with her earrings and her jewels, and she went after her lovers, and forgat me, saith the Lord.

Hosea 2:14 Therefore, behold, I will allure her, and bring her into the wilderness, and speak comfortably unto her.

Hosea 2:15 And I will give her her vineyards from thence, and the valley of Achor for a door of hope: and she shall sing there, as in the days of her youth, and as in the day when she came up out of the land of Egypt.

Hosea 2:16 And it shall be at that day, saith the Lord, that thou shalt call me Ishi; and shalt call me no more Baali.

Hosea 2:17 For I will take away the names of Baalim out of her mouth, and they shall no more be remembered by their name.

Hosea 2:18 And in that day will I make a covenant for them with the beasts of the field, and with the fowls of heaven, and with the creeping things of the ground: and I will break the bow and the sword and the battle out of the earth, and will make them to lie down safely.

Hosea 2:19 And I will betroth thee unto me for ever; yea, I will betroth thee unto me in righteousness, and in judgment, and in lovingkindness, and in mercies.

Hosea 2:20 I will even betroth thee unto me in faithfulness: and thou shalt know the Lord.

Hosea 2:21 And it shall come to pass in that day, I will hear, saith the Lord, I will hear the heavens, and they shall hear the earth;

Hosea 2:22 And the earth shall hear the corn, and the wine, and the oil; and they shall hear Jezreel.

Hosea 2:23 And I will sow her unto me in the earth; and I will have mercy upon her that had not obtained mercy; and I will say to them which were not my people, Thou art my people; and they shall say, Thou art my God.
