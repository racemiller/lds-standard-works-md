# Ezekiel 44

Ezekiel 44 (summary): The glory of the Lord fills the house of the Lord—No strangers may enter the sanctuary—The services of the priests in the temple are explained.

Ezekiel 44:1 Then he brought me back the way of the gate of the outward sanctuary which looketh toward the east; and it was shut.

Ezekiel 44:2 Then said the Lord unto me; This gate shall be shut, it shall not be opened, and no man shall enter in by it; because the Lord, the God of Israel, hath entered in by it, therefore it shall be shut.

Ezekiel 44:3 It is for the prince; the prince, he shall sit in it to eat bread before the Lord; he shall enter by the way of the porch of that gate, and shall go out by the way of the same.

Ezekiel 44:4 Then brought he me the way of the north gate before the house: and I looked, and, behold, the glory of the Lord filled the house of the Lord: and I fell upon my face.

Ezekiel 44:5 And the Lord said unto me, Son of man, mark well, and behold with thine eyes, and hear with thine ears all that I say unto thee concerning all the ordinances of the house of the Lord, and all the laws thereof; and mark well the entering in of the house, with every going forth of the sanctuary.

Ezekiel 44:6 And thou shalt say to the rebellious, even to the house of Israel, Thus saith the Lord God; O ye house of Israel, let it suffice you of all your abominations,

Ezekiel 44:7 In that ye have brought into my sanctuary strangers, uncircumcised in heart, and uncircumcised in flesh, to be in my sanctuary, to pollute it, even my house, when ye offer my bread, the fat and the blood, and they have broken my covenant because of all your abominations.

Ezekiel 44:8 And ye have not kept the charge of mine holy things: but ye have set keepers of my charge in my sanctuary for yourselves.

Ezekiel 44:9 Thus saith the Lord God; No stranger, uncircumcised in heart, nor uncircumcised in flesh, shall enter into my sanctuary, of any stranger that is among the children of Israel.

Ezekiel 44:10 And the Levites that are gone away far from me, when Israel went astray, which went astray away from me after their idols; they shall even bear their iniquity.

Ezekiel 44:11 Yet they shall be ministers in my sanctuary, having charge at the gates of the house, and ministering to the house: they shall slay the burnt offering and the sacrifice for the people, and they shall stand before them to minister unto them.

Ezekiel 44:12 Because they ministered unto them before their idols, and caused the house of Israel to fall into iniquity; therefore have I lifted up mine hand against them, saith the Lord God, and they shall bear their iniquity.

Ezekiel 44:13 And they shall not come near unto me, to do the office of a priest unto me, nor to come near to any of my holy things, in the most holy place: but they shall bear their shame, and their abominations which they have committed.

Ezekiel 44:14 But I will make them keepers of the charge of the house, for all the service thereof, and for all that shall be done therein.

Ezekiel 44:15 But the priests the Levites, the sons of Zadok, that kept the charge of my sanctuary when the children of Israel went astray from me, they shall come near to me to minister unto me, and they shall stand before me to offer unto me the fat and the blood, saith the Lord God:

Ezekiel 44:16 They shall enter into my sanctuary, and they shall come near to my table, to minister unto me, and they shall keep my charge.

Ezekiel 44:17 And it shall come to pass, that when they enter in at the gates of the inner court, they shall be clothed with linen garments; and no wool shall come upon them, whiles they minister in the gates of the inner court, and within.

Ezekiel 44:18 They shall have linen bonnets upon their heads, and shall have linen breeches upon their loins; they shall not gird themselves with any thing that causeth sweat.

Ezekiel 44:19 And when they go forth into the utter court, even into the utter court to the people, they shall put off their garments wherein they ministered, and lay them in the holy chambers, and they shall put on other garments; and they shall not sanctify the people with their garments.

Ezekiel 44:20 Neither shall they shave their heads, nor suffer their locks to grow long; they shall only poll their heads.

Ezekiel 44:21 Neither shall any priest drink wine, when they enter into the inner court.

Ezekiel 44:22 Neither shall they take for their wives a widow, nor her that is put away: but they shall take maidens of the seed of the house of Israel, or a widow that had a priest before.

Ezekiel 44:23 And they shall teach my people the difference between the holy and profane, and cause them to discern between the unclean and the clean.

Ezekiel 44:24 And in controversy they shall stand in judgment; and they shall judge it according to my judgments: and they shall keep my laws and my statutes in all mine assemblies; and they shall hallow my sabbaths.

Ezekiel 44:25 And they shall come at no dead person to defile themselves: but for father, or for mother, or for son, or for daughter, for brother, or for sister that hath had no husband, they may defile themselves.

Ezekiel 44:26 And after he is cleansed, they shall reckon unto him seven days.

Ezekiel 44:27 And in the day that he goeth into the sanctuary, unto the inner court, to minister in the sanctuary, he shall offer his sin offering, saith the Lord God.

Ezekiel 44:28 And it shall be unto them for an inheritance: I am their inheritance: and ye shall give them no possession in Israel: I am their possession.

Ezekiel 44:29 They shall eat the meat offering, and the sin offering, and the trespass offering; and every dedicated thing in Israel shall be theirs.

Ezekiel 44:30 And the first of all the firstfruits of all things, and every oblation of all, of every sort of your oblations, shall be the priest’s: ye shall also give unto the priest the first of your dough, that he may cause the blessing to rest in thine house.

Ezekiel 44:31 The priests shall not eat of any thing that is dead of itself, or torn, whether it be fowl or beast.
