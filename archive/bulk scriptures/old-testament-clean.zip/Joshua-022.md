# Joshua 22

Joshua 22 (summary): The 2½ tribes are dismissed with a blessing—They build an altar of testimony by the Jordan to show they are the Lord’s people—It is not an altar for sacrifices or burnt offerings.

Joshua 22:1 Then Joshua called the Reubenites, and the Gadites, and the half tribe of Manasseh,

Joshua 22:2 And said unto them, Ye have kept all that Moses the servant of the Lord commanded you, and have obeyed my voice in all that I commanded you:

Joshua 22:3 Ye have not left your brethren these many days unto this day, but have kept the charge of the commandment of the Lord your God.

Joshua 22:4 And now the Lord your God hath given rest unto your brethren, as he promised them: therefore now return ye, and get you unto your tents, and unto the land of your possession, which Moses the servant of the Lord gave you on the other side Jordan.

Joshua 22:5 But take diligent heed to do the commandment and the law, which Moses the servant of the Lord charged you, to love the Lord your God, and to walk in all his ways, and to keep his commandments, and to cleave unto him, and to serve him with all your heart and with all your soul.

Joshua 22:6 So Joshua blessed them, and sent them away: and they went unto their tents.

Joshua 22:7 Now to the one half of the tribe of Manasseh Moses had given possession in Bashan: but unto the other half thereof gave Joshua among their brethren on this side Jordan westward. And when Joshua sent them away also unto their tents, then he blessed them,

Joshua 22:8 And he spake unto them, saying, Return with much riches unto your tents, and with very much cattle, with silver, and with gold, and with brass, and with iron, and with very much raiment: divide the spoil of your enemies with your brethren.

Joshua 22:9 And the children of Reuben and the children of Gad and the half tribe of Manasseh returned, and departed from the children of Israel out of Shiloh, which is in the land of Canaan, to go unto the country of Gilead, to the land of their possession, whereof they were possessed, according to the word of the Lord by the hand of Moses.

Joshua 22:10 And when they came unto the borders of Jordan, that are in the land of Canaan, the children of Reuben and the children of Gad and the half tribe of Manasseh built there an altar by Jordan, a great altar to see to.

Joshua 22:11 And the children of Israel heard say, Behold, the children of Reuben and the children of Gad and the half tribe of Manasseh have built an altar over against the land of Canaan, in the borders of Jordan, at the passage of the children of Israel.

Joshua 22:12 And when the children of Israel heard of it, the whole congregation of the children of Israel gathered themselves together at Shiloh, to go up to war against them.

Joshua 22:13 And the children of Israel sent unto the children of Reuben, and to the children of Gad, and to the half tribe of Manasseh, into the land of Gilead, Phinehas the son of Eleazar the priest,

Joshua 22:14 And with him ten princes, of each chief house a prince throughout all the tribes of Israel; and each one was an head of the house of their fathers among the thousands of Israel.

Joshua 22:15 And they came unto the children of Reuben, and to the children of Gad, and to the half tribe of Manasseh, unto the land of Gilead, and they spake with them, saying,

Joshua 22:16 Thus saith the whole congregation of the Lord, What trespass is this that ye have committed against the God of Israel, to turn away this day from following the Lord, in that ye have builded you an altar, that ye might rebel this day against the Lord?

Joshua 22:17 Is the iniquity of Peor too little for us, from which we are not cleansed until this day, although there was a plague in the congregation of the Lord,

Joshua 22:18 But that ye must turn away this day from following the Lord? and it will be, seeing ye rebel to day against the Lord, that to morrow he will be wroth with the whole congregation of Israel.

Joshua 22:19 Notwithstanding, if the land of your possession be unclean, then pass ye over unto the land of the possession of the Lord, wherein the Lord’s tabernacle dwelleth, and take possession among us: but rebel not against the Lord, nor rebel against us, in building you an altar beside the altar of the Lord our God.

Joshua 22:20 Did not Achan the son of Zerah commit a trespass in the accursed thing, and wrath fell on all the congregation of Israel? and that man perished not alone in his iniquity.

Joshua 22:21 Then the children of Reuben and the children of Gad and the half tribe of Manasseh answered, and said unto the heads of the thousands of Israel,

Joshua 22:22 The Lord God of gods, the Lord God of gods, he knoweth, and Israel he shall know; if it be in rebellion, or if in transgression against the Lord, (save us not this day,)

Joshua 22:23 That we have built us an altar to turn from following the Lord, or if to offer thereon burnt offering or meat offering, or if to offer peace offerings thereon, let the Lord himself require it;

Joshua 22:24 And if we have not rather done it for fear of this thing, saying, In time to come your children might speak unto our children, saying, What have ye to do with the Lord God of Israel?

Joshua 22:25 For the Lord hath made Jordan a border between us and you, ye children of Reuben and children of Gad; ye have no part in the Lord: so shall your children make our children cease from fearing the Lord.

Joshua 22:26 Therefore we said, Let us now prepare to build us an altar, not for burnt offering, nor for sacrifice:

Joshua 22:27 But that it may be a witness between us, and you, and our generations after us, that we might do the service of the Lord before him with our burnt offerings, and with our sacrifices, and with our peace offerings; that your children may not say to our children in time to come, Ye have no part in the Lord.

Joshua 22:28 Therefore said we, that it shall be, when they should so say to us or to our generations in time to come, that we may say again, Behold the pattern of the altar of the Lord, which our fathers made, not for burnt offerings, nor for sacrifices; but it is a witness between us and you.

Joshua 22:29 God forbid that we should rebel against the Lord, and turn this day from following the Lord, to build an altar for burnt offerings, for meat offerings, or for sacrifices, beside the altar of the Lord our God that is before his tabernacle.

Joshua 22:30 And when Phinehas the priest, and the princes of the congregation and heads of the thousands of Israel which were with him, heard the words that the children of Reuben and the children of Gad and the children of Manasseh spake, it pleased them.

Joshua 22:31 And Phinehas the son of Eleazar the priest said unto the children of Reuben, and to the children of Gad, and to the children of Manasseh, This day we perceive that the Lord is among us, because ye have not committed this trespass against the Lord: now ye have delivered the children of Israel out of the hand of the Lord.

Joshua 22:32 And Phinehas the son of Eleazar the priest, and the princes, returned from the children of Reuben, and from the children of Gad, out of the land of Gilead, unto the land of Canaan, to the children of Israel, and brought them word again.

Joshua 22:33 And the thing pleased the children of Israel; and the children of Israel blessed God, and did not intend to go up against them in battle, to destroy the land wherein the children of Reuben and Gad dwelt.

Joshua 22:34 And the children of Reuben and the children of Gad called the altar Ed: for it shall be a witness between us that the Lord is God.
