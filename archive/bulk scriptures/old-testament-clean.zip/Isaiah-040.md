# Isaiah 40

Isaiah 40 (summary): Isaiah speaks about the Messiah—Prepare ye the way of the Lord—He will feed His flock like a shepherd—Israel’s God is incomparably great.

Isaiah 40:1 Comfort ye, comfort ye my people, saith your God.

Isaiah 40:2 Speak ye comfortably to Jerusalem, and cry unto her, that her warfare is accomplished, that her iniquity is pardoned: for she hath received of the Lord’s hand double for all her sins.

Isaiah 40:3 The voice of him that crieth in the wilderness, Prepare ye the way of the Lord, make straight in the desert a highway for our God.

Isaiah 40:4 Every valley shall be exalted, and every mountain and hill shall be made low: and the crooked shall be made straight, and the rough places plain:

Isaiah 40:5 And the glory of the Lord shall be revealed, and all flesh shall see it together: for the mouth of the Lord hath spoken it.

Isaiah 40:6 The voice said, Cry. And he said, What shall I cry? All flesh is grass, and all the goodliness thereof is as the flower of the field:

Isaiah 40:7 The grass withereth, the flower fadeth: because the spirit of the Lord bloweth upon it: surely the people is grass.

Isaiah 40:8 The grass withereth, the flower fadeth: but the word of our God shall stand for ever.

Isaiah 40:9 O Zion, that bringest good tidings, get thee up into the high mountain; O Jerusalem, that bringest good tidings, lift up thy voice with strength; lift it up, be not afraid; say unto the cities of Judah, Behold your God!

Isaiah 40:10 Behold, the Lord God will come with strong hand, and his arm shall rule for him: behold, his reward is with him, and his work before him.

Isaiah 40:11 He shall feed his flock like a shepherd: he shall gather the lambs with his arm, and carry them in his bosom, and shall gently lead those that are with young.

Isaiah 40:12 Who hath measured the waters in the hollow of his hand, and meted out heaven with the span, and comprehended the dust of the earth in a measure, and weighed the mountains in scales, and the hills in a balance?

Isaiah 40:13 Who hath directed the Spirit of the Lord, or being his counsellor hath taught him?

Isaiah 40:14 With whom took he counsel, and who instructed him, and taught him in the path of judgment, and taught him knowledge, and shewed to him the way of understanding?

Isaiah 40:15 Behold, the nations are as a drop of a bucket, and are counted as the small dust of the balance: behold, he taketh up the isles as a very little thing.

Isaiah 40:16 And Lebanon is not sufficient to burn, nor the beasts thereof sufficient for a burnt offering.

Isaiah 40:17 All nations before him are as nothing; and they are counted to him less than nothing, and vanity.

Isaiah 40:18 To whom then will ye liken God? or what likeness will ye compare unto him?

Isaiah 40:19 The workman melteth a graven image, and the goldsmith spreadeth it over with gold, and casteth silver chains.

Isaiah 40:20 He that is so impoverished that he hath no oblation chooseth a tree that will not rot; he seeketh unto him a cunning workman to prepare a graven image, that shall not be moved.

Isaiah 40:21 Have ye not known? have ye not heard? hath it not been told you from the beginning? have ye not understood from the foundations of the earth?

Isaiah 40:22 It is he that sitteth upon the circle of the earth, and the inhabitants thereof are as grasshoppers; that stretcheth out the heavens as a curtain, and spreadeth them out as a tent to dwell in:

Isaiah 40:23 That bringeth the princes to nothing; he maketh the judges of the earth as vanity.

Isaiah 40:24 Yea, they shall not be planted; yea, they shall not be sown: yea, their stock shall not take root in the earth: and he shall also blow upon them, and they shall wither, and the whirlwind shall take them away as stubble.

Isaiah 40:25 To whom then will ye liken me, or shall I be equal? saith the Holy One.

Isaiah 40:26 Lift up your eyes on high, and behold who hath created these things, that bringeth out their host by number: he calleth them all by names by the greatness of his might, for that he is strong in power; not one faileth.

Isaiah 40:27 Why sayest thou, O Jacob, and speakest, O Israel, My way is hid from the Lord, and my judgment is passed over from my God?

Isaiah 40:28 Hast thou not known? hast thou not heard, that the everlasting God, the Lord, the Creator of the ends of the earth, fainteth not, neither is weary? there is no searching of his understanding.

Isaiah 40:29 He giveth power to the faint; and to them that have no might he increaseth strength.

Isaiah 40:30 Even the youths shall faint and be weary, and the young men shall utterly fall:

Isaiah 40:31 But they that wait upon the Lord shall renew their strength; they shall mount up with wings as eagles; they shall run, and not be weary; and they shall walk, and not faint.
