# Deuteronomy 14

Deuteronomy 14 (summary): The Israelites are children of the Lord Jehovah—Unclean beasts, fish, and fowl are not to be eaten—The Israelites are to tithe all the increase of their seed annually.

Deuteronomy 14:1 Ye are the children of the Lord your God: ye shall not cut yourselves, nor make any baldness between your eyes for the dead.

Deuteronomy 14:2 For thou art an holy people unto the Lord thy God, and the Lord hath chosen thee to be a peculiar people unto himself, above all the nations that are upon the earth.

Deuteronomy 14:3 Thou shalt not eat any abominable thing.

Deuteronomy 14:4 These are the beasts which ye shall eat: the ox, the sheep, and the goat,

Deuteronomy 14:5 The hart, and the roebuck, and the fallow deer, and the wild goat, and the pygarg, and the wild ox, and the chamois.

Deuteronomy 14:6 And every beast that parteth the hoof, and cleaveth the cleft into two claws, and cheweth the cud among the beasts, that ye shall eat.

Deuteronomy 14:7 Nevertheless these ye shall not eat of them that chew the cud, or of them that divide the cloven hoof; as the camel, and the hare, and the coney: for they chew the cud, but divide not the hoof; therefore they are unclean unto you.

Deuteronomy 14:8 And the swine, because it divideth the hoof, yet cheweth not the cud, it is unclean unto you: ye shall not eat of their flesh, nor touch their dead carcase.

Deuteronomy 14:9 These ye shall eat of all that are in the waters: all that have fins and scales shall ye eat:

Deuteronomy 14:10 And whatsoever hath not fins and scales ye may not eat; it is unclean unto you.

Deuteronomy 14:11 Of all clean birds ye shall eat.

Deuteronomy 14:12 But these are they of which ye shall not eat: the eagle, and the ossifrage, and the ospray,

Deuteronomy 14:13 And the glede, and the kite, and the vulture after his kind,

Deuteronomy 14:14 And every raven after his kind,

Deuteronomy 14:15 And the owl, and the night hawk, and the cuckow, and the hawk after his kind,

Deuteronomy 14:16 The little owl, and the great owl, and the swan,

Deuteronomy 14:17 And the pelican, and the gier eagle, and the cormorant,

Deuteronomy 14:18 And the stork, and the heron after her kind, and the lapwing, and the bat.

Deuteronomy 14:19 And every creeping thing that flieth is unclean unto you: they shall not be eaten.

Deuteronomy 14:20 But of all clean fowls ye may eat.

Deuteronomy 14:21 Ye shall not eat of any thing that dieth of itself: thou shalt give it unto the stranger that is in thy gates, that he may eat it; or thou mayest sell it unto an alien: for thou art an holy people unto the Lord thy God. Thou shalt not seethe a kid in his mother’s milk.

Deuteronomy 14:22 Thou shalt truly tithe all the increase of thy seed, that the field bringeth forth year by year.

Deuteronomy 14:23 And thou shalt eat before the Lord thy God, in the place which he shall choose to place his name there, the tithe of thy corn, of thy wine, and of thine oil, and the firstlings of thy herds and of thy flocks; that thou mayest learn to fear the Lord thy God always.

Deuteronomy 14:24 And if the way be too long for thee, so that thou art not able to carry it; or if the place be too far from thee, which the Lord thy God shall choose to set his name there, when the Lord thy God hath blessed thee:

Deuteronomy 14:25 Then shalt thou turn it into money, and bind up the money in thine hand, and shalt go unto the place which the Lord thy God shall choose:

Deuteronomy 14:26 And thou shalt bestow that money for whatsoever thy soul lusteth after, for oxen, or for sheep, or for wine, or for strong drink, or for whatsoever thy soul desireth: and thou shalt eat there before the Lord thy God, and thou shalt rejoice, thou, and thine household,

Deuteronomy 14:27 And the Levite that is within thy gates; thou shalt not forsake him; for he hath no part nor inheritance with thee.

Deuteronomy 14:28 At the end of three years thou shalt bring forth all the tithe of thine increase the same year, and shalt lay it up within thy gates:

Deuteronomy 14:29 And the Levite, (because he hath no part nor inheritance with thee,) and the stranger, and the fatherless, and the widow, which are within thy gates, shall come, and shall eat and be satisfied; that the Lord thy God may bless thee in all the work of thine hand which thou doest.
