# Ezra 8

Ezra 8 (summary): Those who go up from Babylon to Jerusalem are listed—The Levites are called to accompany them—Ezra and the people fast and pray for and gain guidance and protection in going to Jerusalem.

Ezra 8:1 These are now the chief of their fathers, and this is the genealogy of them that went up with me from Babylon, in the reign of Artaxerxes the king.

Ezra 8:2 Of the sons of Phinehas; Gershom: of the sons of Ithamar; Daniel: of the sons of David; Hattush.

Ezra 8:3 Of the sons of Shechaniah, of the sons of Pharosh; Zechariah: and with him were reckoned by genealogy of the males an hundred and fifty.

Ezra 8:4 Of the sons of Pahath-moab; Elihoenai the son of Zerahiah, and with him two hundred males.

Ezra 8:5 Of the sons of Shechaniah; the son of Jahaziel, and with him three hundred males.

Ezra 8:6 Of the sons also of Adin; Ebed the son of Jonathan, and with him fifty males.

Ezra 8:7 And of the sons of Elam; Jeshaiah the son of Athaliah, and with him seventy males.

Ezra 8:8 And of the sons of Shephatiah; Zebadiah the son of Michael, and with him fourscore males.

Ezra 8:9 Of the sons of Joab; Obadiah the son of Jehiel, and with him two hundred and eighteen males.

Ezra 8:10 And of the sons of Shelomith; the son of Josiphiah, and with him an hundred and threescore males.

Ezra 8:11 And of the sons of Bebai; Zechariah the son of Bebai, and with him twenty and eight males.

Ezra 8:12 And of the sons of Azgad; Johanan the son of Hakkatan, and with him an hundred and ten males.

Ezra 8:13 And of the last sons of Adonikam, whose names are these, Eliphelet, Jeiel, and Shemaiah, and with them threescore males.

Ezra 8:14 Of the sons also of Bigvai; Uthai, and Zabbud, and with them seventy males.

Ezra 8:15 And I gathered them together to the river that runneth to Ahava; and there abode we in tents three days: and I viewed the people, and the priests, and found there none of the sons of Levi.

Ezra 8:16 Then sent I for Eliezer, for Ariel, for Shemaiah, and for Elnathan, and for Jarib, and for Elnathan, and for Nathan, and for Zechariah, and for Meshullam, chief men; also for Joiarib, and for Elnathan, men of understanding.

Ezra 8:17 And I sent them with commandment unto Iddo the chief at the place Casiphia, and I told them what they should say unto Iddo, and to his brethren the Nethinims, at the place Casiphia, that they should bring unto us ministers for the house of our God.

Ezra 8:18 And by the good hand of our God upon us they brought us a man of understanding, of the sons of Mahli, the son of Levi, the son of Israel; and Sherebiah, with his sons and his brethren, eighteen;

Ezra 8:19 And Hashabiah, and with him Jeshaiah of the sons of Merari, his brethren and their sons, twenty;

Ezra 8:20 Also of the Nethinims, whom David and the princes had appointed for the service of the Levites, two hundred and twenty Nethinims: all of them were expressed by name.

Ezra 8:21 Then I proclaimed a fast there, at the river of Ahava, that we might afflict ourselves before our God, to seek of him a right way for us, and for our little ones, and for all our substance.

Ezra 8:22 For I was ashamed to require of the king a band of soldiers and horsemen to help us against the enemy in the way: because we had spoken unto the king, saying, The hand of our God is upon all them for good that seek him; but his power and his wrath is against all them that forsake him.

Ezra 8:23 So we fasted and besought our God for this: and he was entreated of us.

Ezra 8:24 Then I separated twelve of the chief of the priests, Sherebiah, Hashabiah, and ten of their brethren with them,

Ezra 8:25 And weighed unto them the silver, and the gold, and the vessels, even the offering of the house of our God, which the king, and his counsellors, and his lords, and all Israel there present, had offered:

Ezra 8:26 I even weighed unto their hand six hundred and fifty talents of silver, and silver vessels an hundred talents, and of gold an hundred talents;

Ezra 8:27 Also twenty basins of gold, of a thousand drams; and two vessels of fine copper, precious as gold.

Ezra 8:28 And I said unto them, Ye are holy unto the Lord; the vessels are holy also; and the silver and the gold are a freewill offering unto the Lord God of your fathers.

Ezra 8:29 Watch ye, and keep them, until ye weigh them before the chief of the priests and the Levites, and chief of the fathers of Israel, at Jerusalem, in the chambers of the house of the Lord.

Ezra 8:30 So took the priests and the Levites the weight of the silver, and the gold, and the vessels, to bring them to Jerusalem unto the house of our God.

Ezra 8:31 Then we departed from the river of Ahava on the twelfth day of the first month, to go unto Jerusalem: and the hand of our God was upon us, and he delivered us from the hand of the enemy, and of such as lay in wait by the way.

Ezra 8:32 And we came to Jerusalem, and abode there three days.

Ezra 8:33 Now on the fourth day was the silver and the gold and the vessels weighed in the house of our God by the hand of Meremoth the son of Uriah the priest; and with him was Eleazar the son of Phinehas; and with them was Jozabad the son of Jeshua, and Noadiah the son of Binnui, Levites;

Ezra 8:34 By number and by weight of every one: and all the weight was written at that time.

Ezra 8:35 Also the children of those that had been carried away, which were come out of the captivity, offered burnt offerings unto the God of Israel, twelve bullocks for all Israel, ninety and six rams, seventy and seven lambs, twelve he goats for a sin offering: all this was a burnt offering unto the Lord.

Ezra 8:36 And they delivered the king’s commissions unto the king’s lieutenants, and to the governors on this side the river: and they furthered the people, and the house of God.
