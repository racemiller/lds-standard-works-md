# Ezekiel 1

Ezekiel 1 (summary): Ezekiel sees in vision four living creatures, four wheels, and the glory of God on His throne.

Ezekiel 1:1 Now it came to pass in the thirtieth year, in the fourth month, in the fifth day of the month, as I was among the captives by the river of Chebar, that the heavens were opened, and I saw visions of God.

Ezekiel 1:2 In the fifth day of the month, which was the fifth year of king Jehoiachin’s captivity,

Ezekiel 1:3 The word of the Lord came expressly unto Ezekiel the priest, the son of Buzi, in the land of the Chaldeans by the river Chebar; and the hand of the Lord was there upon him.

Ezekiel 1:4 And I looked, and, behold, a whirlwind came out of the north, a great cloud, and a fire infolding itself, and a brightness was about it, and out of the midst thereof as the colour of amber, out of the midst of the fire.

Ezekiel 1:5 Also out of the midst thereof came the likeness of four living creatures. And this was their appearance; they had the likeness of a man.

Ezekiel 1:6 And every one had four faces, and every one had four wings.

Ezekiel 1:7 And their feet were straight feet; and the sole of their feet was like the sole of a calf’s foot: and they sparkled like the colour of burnished brass.

Ezekiel 1:8 And they had the hands of a man under their wings on their four sides; and they four had their faces and their wings.

Ezekiel 1:9 Their wings were joined one to another; they turned not when they went; they went every one straight forward.

Ezekiel 1:10 As for the likeness of their faces, they four had the face of a man, and the face of a lion, on the right side: and they four had the face of an ox on the left side; they four also had the face of an eagle.

Ezekiel 1:11 Thus were their faces: and their wings were stretched upward; two wings of every one were joined one to another, and two covered their bodies.

Ezekiel 1:12 And they went every one straight forward: whither the spirit was to go, they went; and they turned not when they went.

Ezekiel 1:13 As for the likeness of the living creatures, their appearance was like burning coals of fire, and like the appearance of lamps: it went up and down among the living creatures; and the fire was bright, and out of the fire went forth lightning.

Ezekiel 1:14 And the living creatures ran and returned as the appearance of a flash of lightning.

Ezekiel 1:15 Now as I beheld the living creatures, behold one wheel upon the earth by the living creatures, with his four faces.

Ezekiel 1:16 The appearance of the wheels and their work was like unto the colour of a beryl: and they four had one likeness: and their appearance and their work was as it were a wheel in the middle of a wheel.

Ezekiel 1:17 When they went, they went upon their four sides: and they turned not when they went.

Ezekiel 1:18 As for their rings, they were so high that they were dreadful; and their rings were full of eyes round about them four.

Ezekiel 1:19 And when the living creatures went, the wheels went by them: and when the living creatures were lifted up from the earth, the wheels were lifted up.

Ezekiel 1:20 Whithersoever the spirit was to go, they went, thither was their spirit to go; and the wheels were lifted up over against them: for the spirit of the living creature was in the wheels.

Ezekiel 1:21 When those went, these went; and when those stood, these stood; and when those were lifted up from the earth, the wheels were lifted up over against them: for the spirit of the living creature was in the wheels.

Ezekiel 1:22 And the likeness of the firmament upon the heads of the living creature was as the colour of the terrible crystal, stretched forth over their heads above.

Ezekiel 1:23 And under the firmament were their wings straight, the one toward the other: every one had two, which covered on this side, and every one had two, which covered on that side, their bodies.

Ezekiel 1:24 And when they went, I heard the noise of their wings, like the noise of great waters, as the voice of the Almighty, the voice of speech, as the noise of an host: when they stood, they let down their wings.

Ezekiel 1:25 And there was a voice from the firmament that was over their heads, when they stood, and had let down their wings.

Ezekiel 1:26 And above the firmament that was over their heads was the likeness of a throne, as the appearance of a sapphire stone: and upon the likeness of the throne was the likeness as the appearance of a man above upon it.

Ezekiel 1:27 And I saw as the colour of amber, as the appearance of fire round about within it, from the appearance of his loins even upward, and from the appearance of his loins even downward, I saw as it were the appearance of fire, and it had brightness round about.

Ezekiel 1:28 As the appearance of the bow that is in the cloud in the day of rain, so was the appearance of the brightness round about. This was the appearance of the likeness of the glory of the Lord. And when I saw it, I fell upon my face, and I heard a voice of one that spake.
