# Isaiah 42

Isaiah 42 (summary): Isaiah speaks about the Messiah—The Lord will bring His law and His justice, be a light to the Gentiles, and free the prisoners—Praise the Lord.

Isaiah 42:1 Behold my servant, whom I uphold; mine elect, in whom my soul delighteth; I have put my spirit upon him: he shall bring forth judgment to the Gentiles.

Isaiah 42:2 He shall not cry, nor lift up, nor cause his voice to be heard in the street.

Isaiah 42:3 A bruised reed shall he not break, and the smoking flax shall he not quench: he shall bring forth judgment unto truth.

Isaiah 42:4 He shall not fail nor be discouraged, till he have set judgment in the earth: and the isles shall wait for his law.

Isaiah 42:5 Thus saith God the Lord, he that created the heavens, and stretched them out; he that spread forth the earth, and that which cometh out of it; he that giveth breath unto the people upon it, and spirit to them that walk therein:

Isaiah 42:6 I the Lord have called thee in righteousness, and will hold thine hand, and will keep thee, and give thee for a covenant of the people, for a light of the Gentiles;

Isaiah 42:7 To open the blind eyes, to bring out the prisoners from the prison, and them that sit in darkness out of the prison house.

Isaiah 42:8 I am the Lord: that is my name: and my glory will I not give to another, neither my praise to graven images.

Isaiah 42:9 Behold, the former things are come to pass, and new things do I declare: before they spring forth I tell you of them.

Isaiah 42:10 Sing unto the Lord a new song, and his praise from the end of the earth, ye that go down to the sea, and all that is therein; the isles, and the inhabitants thereof.

Isaiah 42:11 Let the wilderness and the cities thereof lift up their voice, the villages that Kedar doth inhabit: let the inhabitants of the rock sing, let them shout from the top of the mountains.

Isaiah 42:12 Let them give glory unto the Lord, and declare his praise in the islands.

Isaiah 42:13 The Lord shall go forth as a mighty man, he shall stir up jealousy like a man of war: he shall cry, yea, roar; he shall prevail against his enemies.

Isaiah 42:14 I have long time holden my peace; I have been still, and refrained myself: now will I cry like a travailing woman; I will destroy and devour at once.

Isaiah 42:15 I will make waste mountains and hills, and dry up all their herbs; and I will make the rivers islands, and I will dry up the pools.

Isaiah 42:16 And I will bring the blind by a way that they knew not; I will lead them in paths that they have not known: I will make darkness light before them, and crooked things straight. These things will I do unto them, and not forsake them.

Isaiah 42:17 They shall be turned back, they shall be greatly ashamed, that trust in graven images, that say to the molten images, Ye are our gods.

Isaiah 42:18 Hear, ye deaf; and look, ye blind, that ye may see.

Isaiah 42:19 Who is blind, but my servant? or deaf, as my messenger that I sent? who is blind as he that is perfect, and blind as the Lord’s servant?

Isaiah 42:20 Seeing many things, but thou observest not; opening the ears, but he heareth not.

Isaiah 42:21 The Lord is well pleased for his righteousness’ sake; he will magnify the law, and make it honourable.

Isaiah 42:22 But this is a people robbed and spoiled; they are all of them snared in holes, and they are hid in prison houses: they are for a prey, and none delivereth; for a spoil, and none saith, Restore.

Isaiah 42:23 Who among you will give ear to this? who will hearken and hear for the time to come?

Isaiah 42:24 Who gave Jacob for a spoil, and Israel to the robbers? did not the Lord, he against whom we have sinned? for they would not walk in his ways, neither were they obedient unto his law.

Isaiah 42:25 Therefore he hath poured upon him the fury of his anger, and the strength of battle: and it hath set him on fire round about, yet he knew not; and it burned him, yet he laid it not to heart.
