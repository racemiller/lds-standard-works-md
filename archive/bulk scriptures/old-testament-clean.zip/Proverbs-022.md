# Proverbs 22

Proverbs 22 (summary): A good name is better than riches—Train up a child in the way he should go.

Proverbs 22:1 A good name is rather to be chosen than great riches, and loving favour rather than silver and gold.

Proverbs 22:2 The rich and poor meet together: the Lord is the maker of them all.

Proverbs 22:3 A prudent man foreseeth the evil, and hideth himself: but the simple pass on, and are punished.

Proverbs 22:4 By humility and the fear of the Lord are riches, and honour, and life.

Proverbs 22:5 Thorns and snares are in the way of the froward: he that doth keep his soul shall be far from them.

Proverbs 22:6 Train up a child in the way he should go: and when he is old, he will not depart from it.

Proverbs 22:7 The rich ruleth over the poor, and the borrower is servant to the lender.

Proverbs 22:8 He that soweth iniquity shall reap vanity: and the rod of his anger shall fail.

Proverbs 22:9 He that hath a bountiful eye shall be blessed; for he giveth of his bread to the poor.

Proverbs 22:10 Cast out the scorner, and contention shall go out; yea, strife and reproach shall cease.

Proverbs 22:11 He that loveth pureness of heart, for the grace of his lips the king shall be his friend.

Proverbs 22:12 The eyes of the Lord preserve knowledge, and he overthroweth the words of the transgressor.

Proverbs 22:13 The slothful man saith, There is a lion without, I shall be slain in the streets.

Proverbs 22:14 The mouth of strange women is a deep pit: he that is abhorred of the Lord shall fall therein.

Proverbs 22:15 Foolishness is bound in the heart of a child; but the rod of correction shall drive it far from him.

Proverbs 22:16 He that oppresseth the poor to increase his riches, and he that giveth to the rich, shall surely come to want.

Proverbs 22:17 Bow down thine ear, and hear the words of the wise, and apply thine heart unto my knowledge.

Proverbs 22:18 For it is a pleasant thing if thou keep them within thee; they shall withal be fitted in thy lips.

Proverbs 22:19 That thy trust may be in the Lord, I have made known to thee this day, even to thee.

Proverbs 22:20 Have not I written to thee excellent things in counsels and knowledge,

Proverbs 22:21 That I might make thee know the certainty of the words of truth; that thou mightest answer the words of truth to them that send unto thee?

Proverbs 22:22 Rob not the poor, because he is poor: neither oppress the afflicted in the gate:

Proverbs 22:23 For the Lord will plead their cause, and spoil the soul of those that spoiled them.

Proverbs 22:24 Make no friendship with an angry man; and with a furious man thou shalt not go:

Proverbs 22:25 Lest thou learn his ways, and get a snare to thy soul.

Proverbs 22:26 Be not thou one of them that strike hands, or of them that are sureties for debts.

Proverbs 22:27 If thou hast nothing to pay, why should he take away thy bed from under thee?

Proverbs 22:28 Remove not the ancient landmark, which thy fathers have set.

Proverbs 22:29 Seest thou a man diligent in his business? he shall stand before kings; he shall not stand before mean men.
