# Ezekiel 46

Ezekiel 46 (summary): The ordinances of worship and of sacrifice are explained.

Ezekiel 46:1 Thus saith the Lord God; The gate of the inner court that looketh toward the east shall be shut the six working days; but on the sabbath it shall be opened, and in the day of the new moon it shall be opened.

Ezekiel 46:2 And the prince shall enter by the way of the porch of that gate without, and shall stand by the post of the gate, and the priests shall prepare his burnt offering and his peace offerings, and he shall worship at the threshold of the gate: then he shall go forth; but the gate shall not be shut until the evening.

Ezekiel 46:3 Likewise the people of the land shall worship at the door of this gate before the Lord in the sabbaths and in the new moons.

Ezekiel 46:4 And the burnt offering that the prince shall offer unto the Lord in the sabbath day shall be six lambs without blemish, and a ram without blemish.

Ezekiel 46:5 And the meat offering shall be an ephah for a ram, and the meat offering for the lambs as he shall be able to give, and an hin of oil to an ephah.

Ezekiel 46:6 And in the day of the new moon it shall be a young bullock without blemish, and six lambs, and a ram: they shall be without blemish.

Ezekiel 46:7 And he shall prepare a meat offering, an ephah for a bullock, and an ephah for a ram, and for the lambs according as his hand shall attain unto, and an hin of oil to an ephah.

Ezekiel 46:8 And when the prince shall enter, he shall go in by the way of the porch of that gate, and he shall go forth by the way thereof.

Ezekiel 46:9 But when the people of the land shall come before the Lord in the solemn feasts, he that entereth in by the way of the north gate to worship shall go out by the way of the south gate; and he that entereth by the way of the south gate shall go forth by the way of the north gate: he shall not return by the way of the gate whereby he came in, but shall go forth over against it.

Ezekiel 46:10 And the prince in the midst of them, when they go in, shall go in; and when they go forth, shall go forth.

Ezekiel 46:11 And in the feasts and in the solemnities the meat offering shall be an ephah to a bullock, and an ephah to a ram, and to the lambs as he is able to give, and an hin of oil to an ephah.

Ezekiel 46:12 Now when the prince shall prepare a voluntary burnt offering or peace offerings voluntarily unto the Lord, one shall then open him the gate that looketh toward the east, and he shall prepare his burnt offering and his peace offerings, as he did on the sabbath day: then he shall go forth; and after his going forth one shall shut the gate.

Ezekiel 46:13 Thou shalt daily prepare a burnt offering unto the Lord of a lamb of the first year without blemish: thou shalt prepare it every morning.

Ezekiel 46:14 And thou shalt prepare a meat offering for it every morning, the sixth part of an ephah, and the third part of an hin of oil, to temper with the fine flour; a meat offering continually by a perpetual ordinance unto the Lord.

Ezekiel 46:15 Thus shall they prepare the lamb, and the meat offering, and the oil, every morning for a continual burnt offering.

Ezekiel 46:16 Thus saith the Lord God; If the prince give a gift unto any of his sons, the inheritance thereof shall be his sons’; it shall be their possession by inheritance.

Ezekiel 46:17 But if he give a gift of his inheritance to one of his servants, then it shall be his to the year of liberty; after it shall return to the prince: but his inheritance shall be his sons’ for them.

Ezekiel 46:18 Moreover the prince shall not take of the people’s inheritance by oppression, to thrust them out of their possession; but he shall give his sons inheritance out of his own possession: that my people be not scattered every man from his possession.

Ezekiel 46:19 After he brought me through the entry, which was at the side of the gate, into the holy chambers of the priests, which looked toward the north: and, behold, there was a place on the two sides westward.

Ezekiel 46:20 Then said he unto me, This is the place where the priests shall boil the trespass offering and the sin offering, where they shall bake the meat offering; that they bear them not out into the utter court, to sanctify the people.

Ezekiel 46:21 Then he brought me forth into the utter court, and caused me to pass by the four corners of the court; and, behold, in every corner of the court there was a court.

Ezekiel 46:22 In the four corners of the court there were courts joined of forty cubits long and thirty broad: these four corners were of one measure.

Ezekiel 46:23 And there was a row of building round about in them, round about them four, and it was made with boiling places under the rows round about.

Ezekiel 46:24 Then said he unto me, These are the places of them that boil, where the ministers of the house shall boil the sacrifice of the people.
