# Jeremiah 9

Jeremiah 9 (summary): Jeremiah sorrows greatly because of the sins of the people—They will be scattered among the nations and punished.

Jeremiah 9:1 Oh that my head were waters, and mine eyes a fountain of tears, that I might weep day and night for the slain of the daughter of my people!

Jeremiah 9:2 Oh that I had in the wilderness a lodging place of wayfaring men; that I might leave my people, and go from them! for they be all adulterers, an assembly of treacherous men.

Jeremiah 9:3 And they bend their tongues like their bow for lies: but they are not valiant for the truth upon the earth; for they proceed from evil to evil, and they know not me, saith the Lord.

Jeremiah 9:4 Take ye heed every one of his neighbour, and trust ye not in any brother: for every brother will utterly supplant, and every neighbour will walk with slanders.

Jeremiah 9:5 And they will deceive every one his neighbour, and will not speak the truth: they have taught their tongue to speak lies, and weary themselves to commit iniquity.

Jeremiah 9:6 Thine habitation is in the midst of deceit; through deceit they refuse to know me, saith the Lord.

Jeremiah 9:7 Therefore thus saith the Lord of hosts, Behold, I will melt them, and try them; for how shall I do for the daughter of my people?

Jeremiah 9:8 Their tongue is as an arrow shot out; it speaketh deceit: one speaketh peaceably to his neighbour with his mouth, but in heart he layeth his wait.

Jeremiah 9:9 Shall I not visit them for these things? saith the Lord: shall not my soul be avenged on such a nation as this?

Jeremiah 9:10 For the mountains will I take up a weeping and wailing, and for the habitations of the wilderness a lamentation, because they are burned up, so that none can pass through them; neither can men hear the voice of the cattle; both the fowl of the heavens and the beast are fled; they are gone.

Jeremiah 9:11 And I will make Jerusalem heaps, and a den of dragons; and I will make the cities of Judah desolate, without an inhabitant.

Jeremiah 9:12 Who is the wise man, that may understand this? and who is he to whom the mouth of the Lord hath spoken, that he may declare it, for what the land perisheth and is burned up like a wilderness, that none passeth through?

Jeremiah 9:13 And the Lord saith, Because they have forsaken my law which I set before them, and have not obeyed my voice, neither walked therein;

Jeremiah 9:14 But have walked after the imagination of their own heart, and after Baalim, which their fathers taught them:

Jeremiah 9:15 Therefore thus saith the Lord of hosts, the God of Israel; Behold, I will feed them, even this people, with wormwood, and give them water of gall to drink.

Jeremiah 9:16 I will scatter them also among the heathen, whom neither they nor their fathers have known: and I will send a sword after them, till I have consumed them.

Jeremiah 9:17 Thus saith the Lord of hosts, Consider ye, and call for the mourning women, that they may come; and send for cunning women, that they may come:

Jeremiah 9:18 And let them make haste, and take up a wailing for us, that our eyes may run down with tears, and our eyelids gush out with waters.

Jeremiah 9:19 For a voice of wailing is heard out of Zion, How are we spoiled! we are greatly confounded, because we have forsaken the land, because our dwellings have cast us out.

Jeremiah 9:20 Yet hear the word of the Lord, O ye women, and let your ear receive the word of his mouth, and teach your daughters wailing, and every one her neighbour lamentation.

Jeremiah 9:21 For death is come up into our windows, and is entered into our palaces, to cut off the children from without, and the young men from the streets.

Jeremiah 9:22 Speak, Thus saith the Lord, Even the carcases of men shall fall as dung upon the open field, and as the handful after the harvestman, and none shall gather them.

Jeremiah 9:23 Thus saith the Lord, Let not the wise man glory in his wisdom, neither let the mighty man glory in his might, let not the rich man glory in his riches:

Jeremiah 9:24 But let him that glorieth glory in this, that he understandeth and knoweth me, that I am the Lord which exercise lovingkindness, judgment, and righteousness, in the earth: for in these things I delight, saith the Lord.

Jeremiah 9:25 Behold, the days come, saith the Lord, that I will punish all them which are circumcised with the uncircumcised;

Jeremiah 9:26 Egypt, and Judah, and Edom, and the children of Ammon, and Moab, and all that are in the utmost corners, that dwell in the wilderness: for all these nations are uncircumcised, and all the house of Israel are uncircumcised in the heart.
