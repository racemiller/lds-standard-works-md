# Genesis 19

Genesis 19 (summary): Lot entertains holy men—The men of Sodom seek to abuse Lot’s guests and are smitten with blindness—Lot is sent out of Sodom—The Lord rains brimstone and fire upon Sodom and Gomorrah—Lot’s daughters preserve his seed in the land.

Genesis 19:1 And there came two angels to Sodom at even; and Lot sat in the gate of Sodom: and Lot seeing them rose up to meet them; and he bowed himself with his face toward the ground;

Genesis 19:2 And he said, Behold now, my lords, turn in, I pray you, into your servant’s house, and tarry all night, and wash your feet, and ye shall rise up early, and go on your ways. And they said, Nay; but we will abide in the street all night.

Genesis 19:3 And he pressed upon them greatly; and they turned in unto him, and entered into his house; and he made them a feast, and did bake unleavened bread, and they did eat.

Genesis 19:4 But before they lay down, the men of the city, even the men of Sodom, compassed the house round, both old and young, all the people from every quarter:

Genesis 19:5 And they called unto Lot, and said unto him, Where are the men which came in to thee this night? bring them out unto us, that we may know them.

Genesis 19:6 And Lot went out at the door unto them, and shut the door after him,

Genesis 19:7 And said, I pray you, brethren, do not so wickedly.

Genesis 19:8 Behold now, I have two daughters which have not known man; let me, I pray you, bring them out unto you, and do ye to them as is good in your eyes: only unto these men do nothing; for therefore came they under the shadow of my roof.

Genesis 19:9 And they said, Stand back. And they said again, This one fellow came in to sojourn, and he will needs be a judge: now will we deal worse with thee, than with them. And they pressed sore upon the man, even Lot, and came near to break the door.

Genesis 19:10 But the men put forth their hand, and pulled Lot into the house to them, and shut to the door.

Genesis 19:11 And they smote the men that were at the door of the house with blindness, both small and great: so that they wearied themselves to find the door.

Genesis 19:12 And the men said unto Lot, Hast thou here any besides? son in law, and thy sons, and thy daughters, and whatsoever thou hast in the city, bring them out of this place:

Genesis 19:13 For we will destroy this place, because the cry of them is waxen great before the face of the Lord; and the Lord hath sent us to destroy it.

Genesis 19:14 And Lot went out, and spake unto his sons in law, which married his daughters, and said, Up, get you out of this place; for the Lord will destroy this city. But he seemed as one that mocked unto his sons in law.

Genesis 19:15 And when the morning arose, then the angels hastened Lot, saying, Arise, take thy wife, and thy two daughters, which are here; lest thou be consumed in the iniquity of the city.

Genesis 19:16 And while he lingered, the men laid hold upon his hand, and upon the hand of his wife, and upon the hand of his two daughters; the Lord being merciful unto him: and they brought him forth, and set him without the city.

Genesis 19:17 And it came to pass, when they had brought them forth abroad, that he said, Escape for thy life; look not behind thee, neither stay thou in all the plain; escape to the mountain, lest thou be consumed.

Genesis 19:18 And Lot said unto them, Oh, not so, my Lord:

Genesis 19:19 Behold now, thy servant hath found grace in thy sight, and thou hast magnified thy mercy, which thou hast shewed unto me in saving my life; and I cannot escape to the mountain, lest some evil take me, and I die:

Genesis 19:20 Behold now, this city is near to flee unto, and it is a little one: Oh, let me escape thither, (is it not a little one?) and my soul shall live.

Genesis 19:21 And he said unto him, See, I have accepted thee concerning this thing also, that I will not overthrow this city, for the which thou hast spoken.

Genesis 19:22 Haste thee, escape thither; for I cannot do any thing till thou be come thither. Therefore the name of the city was called Zoar.

Genesis 19:23 The sun was risen upon the earth when Lot entered into Zoar.

Genesis 19:24 Then the Lord rained upon Sodom and upon Gomorrah brimstone and fire from the Lord out of heaven;

Genesis 19:25 And he overthrew those cities, and all the plain, and all the inhabitants of the cities, and that which grew upon the ground.

Genesis 19:26 But his wife looked back from behind him, and she became a pillar of salt.

Genesis 19:27 And Abraham gat up early in the morning to the place where he stood before the Lord:

Genesis 19:28 And he looked toward Sodom and Gomorrah, and toward all the land of the plain, and beheld, and, lo, the smoke of the country went up as the smoke of a furnace.

Genesis 19:29 And it came to pass, when God destroyed the cities of the plain, that God remembered Abraham, and sent Lot out of the midst of the overthrow, when he overthrew the cities in the which Lot dwelt.

Genesis 19:30 And Lot went up out of Zoar, and dwelt in the mountain, and his two daughters with him; for he feared to dwell in Zoar: and he dwelt in a cave, he and his two daughters.

Genesis 19:31 And the firstborn said unto the younger, Our father is old, and there is not a man in the earth to come in unto us after the manner of all the earth:

Genesis 19:32 Come, let us make our father drink wine, and we will lie with him, that we may preserve seed of our father.

Genesis 19:33 And they made their father drink wine that night: and the firstborn went in, and lay with her father; and he perceived not when she lay down, nor when she arose.

Genesis 19:34 And it came to pass on the morrow, that the firstborn said unto the younger, Behold, I lay yesternight with my father: let us make him drink wine this night also; and go thou in, and lie with him, that we may preserve seed of our father.

Genesis 19:35 And they made their father drink wine that night also: and the younger arose, and lay with him; and he perceived not when she lay down, nor when she arose.

Genesis 19:36 Thus were both the daughters of Lot with child by their father.

Genesis 19:37 And the firstborn bare a son, and called his name Moab: the same is the father of the Moabites unto this day.

Genesis 19:38 And the younger, she also bare a son, and called his name Ben-ammi: the same is the father of the children of Ammon unto this day.
