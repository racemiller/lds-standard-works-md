# 1 Samuel 7

1 Samuel 7 (summary): Samuel exhorts Israel to forsake Ashtaroth and Baalim and serve the Lord—Israel fasts and seeks the Lord—The Philistines are subdued—Samuel judges Israel.

1 Samuel 7:1 And the men of Kirjath-jearim came, and fetched up the ark of the Lord, and brought it into the house of Abinadab in the hill, and sanctified Eleazar his son to keep the ark of the Lord.

1 Samuel 7:2 And it came to pass, while the ark abode in Kirjath-jearim, that the time was long; for it was twenty years: and all the house of Israel lamented after the Lord.

1 Samuel 7:3 And Samuel spake unto all the house of Israel, saying, If ye do return unto the Lord with all your hearts, then put away the strange gods and Ashtaroth from among you, and prepare your hearts unto the Lord, and serve him only: and he will deliver you out of the hand of the Philistines.

1 Samuel 7:4 Then the children of Israel did put away Baalim and Ashtaroth, and served the Lord only.

1 Samuel 7:5 And Samuel said, Gather all Israel to Mizpeh, and I will pray for you unto the Lord.

1 Samuel 7:6 And they gathered together to Mizpeh, and drew water, and poured it out before the Lord, and fasted on that day, and said there, We have sinned against the Lord. And Samuel judged the children of Israel in Mizpeh.

1 Samuel 7:7 And when the Philistines heard that the children of Israel were gathered together to Mizpeh, the lords of the Philistines went up against Israel. And when the children of Israel heard it, they were afraid of the Philistines.

1 Samuel 7:8 And the children of Israel said to Samuel, Cease not to cry unto the Lord our God for us, that he will save us out of the hand of the Philistines.

1 Samuel 7:9 And Samuel took a sucking lamb, and offered it for a burnt offering wholly unto the Lord: and Samuel cried unto the Lord for Israel; and the Lord heard him.

1 Samuel 7:10 And as Samuel was offering up the burnt offering, the Philistines drew near to battle against Israel: but the Lord thundered with a great thunder on that day upon the Philistines, and discomfited them; and they were smitten before Israel.

1 Samuel 7:11 And the men of Israel went out of Mizpeh, and pursued the Philistines, and smote them, until they came under Beth-car.

1 Samuel 7:12 Then Samuel took a stone, and set it between Mizpeh and Shen, and called the name of it Eben-ezer, saying, Hitherto hath the Lord helped us.

1 Samuel 7:13 So the Philistines were subdued, and they came no more into the coast of Israel: and the hand of the Lord was against the Philistines all the days of Samuel.

1 Samuel 7:14 And the cities which the Philistines had taken from Israel were restored to Israel, from Ekron even unto Gath; and the coasts thereof did Israel deliver out of the hands of the Philistines. And there was peace between Israel and the Amorites.

1 Samuel 7:15 And Samuel judged Israel all the days of his life.

1 Samuel 7:16 And he went from year to year in circuit to Beth-el, and Gilgal, and Mizpeh, and judged Israel in all those places.

1 Samuel 7:17 And his return was to Ramah; for there was his house; and there he judged Israel; and there he built an altar unto the Lord.
