# Proverbs 9

Proverbs 9 (summary): Rebuke a wise man and he will love you—The fear of the Lord is the beginning of wisdom—The guests of an immoral woman are in the depths of hell.

Proverbs 9:1 Wisdom hath builded her house, she hath hewn out her seven pillars:

Proverbs 9:2 She hath killed her beasts; she hath mingled her wine; she hath also furnished her table.

Proverbs 9:3 She hath sent forth her maidens: she crieth upon the highest places of the city,

Proverbs 9:4 Whoso is simple, let him turn in hither: as for him that wanteth understanding, she saith to him,

Proverbs 9:5 Come, eat of my bread, and drink of the wine which I have mingled.

Proverbs 9:6 Forsake the foolish, and live; and go in the way of understanding.

Proverbs 9:7 He that reproveth a scorner getteth to himself shame: and he that rebuketh a wicked man getteth himself a blot.

Proverbs 9:8 Reprove not a scorner, lest he hate thee: rebuke a wise man, and he will love thee.

Proverbs 9:9 Give instruction to a wise man, and he will be yet wiser: teach a just man, and he will increase in learning.

Proverbs 9:10 The fear of the Lord is the beginning of wisdom: and the knowledge of the holy is understanding.

Proverbs 9:11 For by me thy days shall be multiplied, and the years of thy life shall be increased.

Proverbs 9:12 If thou be wise, thou shalt be wise for thyself: but if thou scornest, thou alone shalt bear it.

Proverbs 9:13 A foolish woman is clamorous: she is simple, and knoweth nothing.

Proverbs 9:14 For she sitteth at the door of her house, on a seat in the high places of the city,

Proverbs 9:15 To call passengers who go right on their ways:

Proverbs 9:16 Whoso is simple, let him turn in hither: and as for him that wanteth understanding, she saith to him,

Proverbs 9:17 Stolen waters are sweet, and bread eaten in secret is pleasant.

Proverbs 9:18 But he knoweth not that the dead are there; and that her guests are in the depths of hell.
