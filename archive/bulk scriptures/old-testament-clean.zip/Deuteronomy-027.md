# Deuteronomy 27

Deuteronomy 27 (summary): The children of Israel are to cross the Jordan, build an altar, and worship the Lord—They are the Lord’s people but will be cursed if they do not obey Him.

Deuteronomy 27:1 And Moses with the elders of Israel commanded the people, saying, Keep all the commandments which I command you this day.

Deuteronomy 27:2 And it shall be on the day when ye shall pass over Jordan unto the land which the Lord thy God giveth thee, that thou shalt set thee up great stones, and plaster them with plaster:

Deuteronomy 27:3 And thou shalt write upon them all the words of this law, when thou art passed over, that thou mayest go in unto the land which the Lord thy God giveth thee, a land that floweth with milk and honey; as the Lord God of thy fathers hath promised thee.

Deuteronomy 27:4 Therefore it shall be when ye be gone over Jordan, that ye shall set up these stones, which I command you this day, in mount Ebal, and thou shalt plaster them with plaster.

Deuteronomy 27:5 And there shalt thou build an altar unto the Lord thy God, an altar of stones: thou shalt not lift up any iron tool upon them.

Deuteronomy 27:6 Thou shalt build the altar of the Lord thy God of whole stones: and thou shalt offer burnt offerings thereon unto the Lord thy God:

Deuteronomy 27:7 And thou shalt offer peace offerings, and shalt eat there, and rejoice before the Lord thy God.

Deuteronomy 27:8 And thou shalt write upon the stones all the words of this law very plainly.

Deuteronomy 27:9 And Moses and the priests the Levites spake unto all Israel, saying, Take heed, and hearken, O Israel; this day thou art become the people of the Lord thy God.

Deuteronomy 27:10 Thou shalt therefore obey the voice of the Lord thy God, and do his commandments and his statutes, which I command thee this day.

Deuteronomy 27:11 And Moses charged the people the same day, saying,

Deuteronomy 27:12 These shall stand upon mount Gerizim to bless the people, when ye are come over Jordan; Simeon, and Levi, and Judah, and Issachar, and Joseph, and Benjamin:

Deuteronomy 27:13 And these shall stand upon mount Ebal to curse; Reuben, Gad, and Asher, and Zebulun, Dan, and Naphtali.

Deuteronomy 27:14 And the Levites shall speak, and say unto all the men of Israel with a loud voice,

Deuteronomy 27:15 Cursed be the man that maketh any graven or molten image, an abomination unto the Lord, the work of the hands of the craftsman, and putteth it in a secret place. And all the people shall answer and say, Amen.

Deuteronomy 27:16 Cursed be he that setteth light by his father or his mother. And all the people shall say, Amen.

Deuteronomy 27:17 Cursed be he that removeth his neighbour’s landmark. And all the people shall say, Amen.

Deuteronomy 27:18 Cursed be he that maketh the blind to wander out of the way. And all the people shall say, Amen.

Deuteronomy 27:19 Cursed be he that perverteth the judgment of the stranger, fatherless, and widow. And all the people shall say, Amen.

Deuteronomy 27:20 Cursed be he that lieth with his father’s wife; because he uncovereth his father’s skirt. And all the people shall say, Amen.

Deuteronomy 27:21 Cursed be he that lieth with any manner of beast. And all the people shall say, Amen.

Deuteronomy 27:22 Cursed be he that lieth with his sister, the daughter of his father, or the daughter of his mother. And all the people shall say, Amen.

Deuteronomy 27:23 Cursed be he that lieth with his mother in law. And all the people shall say, Amen.

Deuteronomy 27:24 Cursed be he that smiteth his neighbour secretly. And all the people shall say, Amen.

Deuteronomy 27:25 Cursed be he that taketh reward to slay an innocent person. And all the people shall say, Amen.

Deuteronomy 27:26 Cursed be he that confirmeth not all the words of this law to do them. And all the people shall say, Amen.
