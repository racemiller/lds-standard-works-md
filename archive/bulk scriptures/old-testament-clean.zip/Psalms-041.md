# Psalms 41

Psalms 41 (summary): A messianic psalm of David—Blessed is he who considers the poor—The treachery of Judas is foretold.

Psalms 41:1 Blessed is he that considereth the poor: the Lord will deliver him in time of trouble.

Psalms 41:2 The Lord will preserve him, and keep him alive; and he shall be blessed upon the earth: and thou wilt not deliver him unto the will of his enemies.

Psalms 41:3 The Lord will strengthen him upon the bed of languishing: thou wilt make all his bed in his sickness.

Psalms 41:4 I said, Lord, be merciful unto me: heal my soul; for I have sinned against thee.

Psalms 41:5 Mine enemies speak evil of me, When shall he die, and his name perish?

Psalms 41:6 And if he come to see me, he speaketh vanity: his heart gathereth iniquity to itself; when he goeth abroad, he telleth it.

Psalms 41:7 All that hate me whisper together against me: against me do they devise my hurt.

Psalms 41:8 An evil disease, say they, cleaveth fast unto him: and now that he lieth he shall rise up no more.

Psalms 41:9 Yea, mine own familiar friend, in whom I trusted, which did eat of my bread, hath lifted up his heel against me.

Psalms 41:10 But thou, O Lord, be merciful unto me, and raise me up, that I may requite them.

Psalms 41:11 By this I know that thou favourest me, because mine enemy doth not triumph over me.

Psalms 41:12 And as for me, thou upholdest me in mine integrity, and settest me before thy face for ever.

Psalms 41:13 Blessed be the Lord God of Israel from everlasting, and to everlasting. Amen, and Amen.
