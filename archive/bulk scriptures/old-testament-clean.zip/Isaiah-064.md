# Isaiah 64

Isaiah 64 (summary): The people of the Lord pray for the Second Coming and for the salvation that will then be theirs.

Isaiah 64:1 Oh that thou wouldest rend the heavens, that thou wouldest come down, that the mountains might flow down at thy presence,

Isaiah 64:2 As when the melting fire burneth, the fire causeth the waters to boil, to make thy name known to thine adversaries, that the nations may tremble at thy presence!

Isaiah 64:3 When thou didst terrible things which we looked not for, thou camest down, the mountains flowed down at thy presence.

Isaiah 64:4 For since the beginning of the world men have not heard, nor perceived by the ear, neither hath the eye seen, O God, beside thee, what he hath prepared for him that waiteth for him.

Isaiah 64:5 Thou meetest him that rejoiceth and worketh righteousness, those that remember thee in thy ways: behold, thou art wroth; for we have sinned: in those is continuance, and we shall be saved.

Isaiah 64:6 But we are all as an unclean thing, and all our righteousnesses are as filthy rags; and we all do fade as a leaf; and our iniquities, like the wind, have taken us away.

Isaiah 64:7 And there is none that calleth upon thy name, that stirreth up himself to take hold of thee: for thou hast hid thy face from us, and hast consumed us, because of our iniquities.

Isaiah 64:8 But now, O Lord, thou art our father; we are the clay, and thou our potter; and we all are the work of thy hand.

Isaiah 64:9 Be not wroth very sore, O Lord, neither remember iniquity for ever: behold, see, we beseech thee, we are all thy people.

Isaiah 64:10 Thy holy cities are a wilderness, Zion is a wilderness, Jerusalem a desolation.

Isaiah 64:11 Our holy and our beautiful house, where our fathers praised thee, is burned up with fire: and all our pleasant things are laid waste.

Isaiah 64:12 Wilt thou refrain thyself for these things, O Lord? wilt thou hold thy peace, and afflict us very sore?
