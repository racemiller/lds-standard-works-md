# Numbers 12

Numbers 12 (summary): Aaron and Miriam complain against Moses, the most meek of all men—The Lord promises to speak to Moses mouth to mouth and to reveal to him the similitude of the Lord—Miriam becomes leprous for a week.

Numbers 12:1 And Miriam and Aaron spake against Moses because of the Ethiopian woman whom he had married: for he had married an Ethiopian woman.

Numbers 12:2 And they said, Hath the Lord indeed spoken only by Moses? hath he not spoken also by us? And the Lord heard it.

Numbers 12:3 (Now the man Moses was very meek, above all the men which were upon the face of the earth.)

Numbers 12:4 And the Lord spake suddenly unto Moses, and unto Aaron, and unto Miriam, Come out ye three unto the tabernacle of the congregation. And they three came out.

Numbers 12:5 And the Lord came down in the pillar of the cloud, and stood in the door of the tabernacle, and called Aaron and Miriam: and they both came forth.

Numbers 12:6 And he said, Hear now my words: If there be a prophet among you, I the Lord will make myself known unto him in a vision, and will speak unto him in a dream.

Numbers 12:7 My servant Moses is not so, who is faithful in all mine house.

Numbers 12:8 With him will I speak mouth to mouth, even apparently, and not in dark speeches; and the similitude of the Lord shall he behold: wherefore then were ye not afraid to speak against my servant Moses?

Numbers 12:9 And the anger of the Lord was kindled against them; and he departed.

Numbers 12:10 And the cloud departed from off the tabernacle; and, behold, Miriam became leprous, white as snow: and Aaron looked upon Miriam, and, behold, she was leprous.

Numbers 12:11 And Aaron said unto Moses, Alas, my lord, I beseech thee, lay not the sin upon us, wherein we have done foolishly, and wherein we have sinned.

Numbers 12:12 Let her not be as one dead, of whom the flesh is half consumed when he cometh out of his mother’s womb.

Numbers 12:13 And Moses cried unto the Lord, saying, Heal her now, O God, I beseech thee.

Numbers 12:14 And the Lord said unto Moses, If her father had but spit in her face, should she not be ashamed seven days? let her be shut out from the camp seven days, and after that let her be received in again.

Numbers 12:15 And Miriam was shut out from the camp seven days: and the people journeyed not till Miriam was brought in again.

Numbers 12:16 And afterward the people removed from Hazeroth, and pitched in the wilderness of Paran.
