# Jeremiah 51

Jeremiah 51 (summary): Judgment, destruction, and desolation will come upon Babylon for her sins—Israel is commanded, Flee from Babylon—Israel is the Lord’s rod to destroy all kingdoms.

Jeremiah 51:1 Thus saith the Lord; Behold, I will raise up against Babylon, and against them that dwell in the midst of them that rise up against me, a destroying wind;

Jeremiah 51:2 And will send unto Babylon fanners, that shall fan her, and shall empty her land: for in the day of trouble they shall be against her round about.

Jeremiah 51:3 Against him that bendeth let the archer bend his bow, and against him that lifteth himself up in his brigandine: and spare ye not her young men; destroy ye utterly all her host.

Jeremiah 51:4 Thus the slain shall fall in the land of the Chaldeans, and they that are thrust through in her streets.

Jeremiah 51:5 For Israel hath not been forsaken, nor Judah of his God, of the Lord of hosts; though their land was filled with sin against the Holy One of Israel.

Jeremiah 51:6 Flee out of the midst of Babylon, and deliver every man his soul: be not cut off in her iniquity; for this is the time of the Lord’s vengeance; he will render unto her a recompence.

Jeremiah 51:7 Babylon hath been a golden cup in the Lord’s hand, that made all the earth drunken: the nations have drunken of her wine; therefore the nations are mad.

Jeremiah 51:8 Babylon is suddenly fallen and destroyed: howl for her; take balm for her pain, if so be she may be healed.

Jeremiah 51:9 We would have healed Babylon, but she is not healed: forsake her, and let us go every one into his own country: for her judgment reacheth unto heaven, and is lifted up even to the skies.

Jeremiah 51:10 The Lord hath brought forth our righteousness: come, and let us declare in Zion the work of the Lord our God.

Jeremiah 51:11 Make bright the arrows; gather the shields: the Lord hath raised up the spirit of the kings of the Medes: for his device is against Babylon, to destroy it; because it is the vengeance of the Lord, the vengeance of his temple.

Jeremiah 51:12 Set up the standard upon the walls of Babylon, make the watch strong, set up the watchmen, prepare the ambushes: for the Lord hath both devised and done that which he spake against the inhabitants of Babylon.

Jeremiah 51:13 O thou that dwellest upon many waters, abundant in treasures, thine end is come, and the measure of thy covetousness.

Jeremiah 51:14 The Lord of hosts hath sworn by himself, saying, Surely I will fill thee with men, as with caterpillers; and they shall lift up a shout against thee.

Jeremiah 51:15 He hath made the earth by his power, he hath established the world by his wisdom, and hath stretched out the heaven by his understanding.

Jeremiah 51:16 When he uttereth his voice, there is a multitude of waters in the heavens; and he causeth the vapours to ascend from the ends of the earth: he maketh lightnings with rain, and bringeth forth the wind out of his treasures.

Jeremiah 51:17 Every man is brutish by his knowledge; every founder is confounded by the graven image: for his molten image is falsehood, and there is no breath in them.

Jeremiah 51:18 They are vanity, the work of errors: in the time of their visitation they shall perish.

Jeremiah 51:19 The portion of Jacob is not like them; for he is the former of all things: and Israel is the rod of his inheritance: the Lord of hosts is his name.

Jeremiah 51:20 Thou art my battle axe and weapons of war: for with thee will I break in pieces the nations, and with thee will I destroy kingdoms;

Jeremiah 51:21 And with thee will I break in pieces the horse and his rider; and with thee will I break in pieces the chariot and his rider;

Jeremiah 51:22 With thee also will I break in pieces man and woman; and with thee will I break in pieces old and young; and with thee will I break in pieces the young man and the maid;

Jeremiah 51:23 I will also break in pieces with thee the shepherd and his flock; and with thee will I break in pieces the husbandman and his yoke of oxen; and with thee will I break in pieces captains and rulers.

Jeremiah 51:24 And I will render unto Babylon and to all the inhabitants of Chaldea all their evil that they have done in Zion in your sight, saith the Lord.

Jeremiah 51:25 Behold, I am against thee, O destroying mountain, saith the Lord, which destroyest all the earth: and I will stretch out mine hand upon thee, and roll thee down from the rocks, and will make thee a burnt mountain.

Jeremiah 51:26 And they shall not take of thee a stone for a corner, nor a stone for foundations; but thou shalt be desolate for ever, saith the Lord.

Jeremiah 51:27 Set ye up a standard in the land, blow the trumpet among the nations, prepare the nations against her, call together against her the kingdoms of Ararat, Minni, and Ashchenaz; appoint a captain against her; cause the horses to come up as the rough caterpillers.

Jeremiah 51:28 Prepare against her the nations with the kings of the Medes, the captains thereof, and all the rulers thereof, and all the land of his dominion.

Jeremiah 51:29 And the land shall tremble and sorrow: for every purpose of the Lord shall be performed against Babylon, to make the land of Babylon a desolation without an inhabitant.

Jeremiah 51:30 The mighty men of Babylon have forborn to fight, they have remained in their holds: their might hath failed; they became as women: they have burned her dwellingplaces; her bars are broken.

Jeremiah 51:31 One post shall run to meet another, and one messenger to meet another, to shew the king of Babylon that his city is taken at one end,

Jeremiah 51:32 And that the passages are stopped, and the reeds they have burned with fire, and the men of war are affrighted.

Jeremiah 51:33 For thus saith the Lord of hosts, the God of Israel; The daughter of Babylon is like a threshingfloor, it is time to thresh her: yet a little while, and the time of her harvest shall come.

Jeremiah 51:34 Nebuchadrezzar the king of Babylon hath devoured me, he hath crushed me, he hath made me an empty vessel, he hath swallowed me up like a dragon, he hath filled his belly with my delicates, he hath cast me out.

Jeremiah 51:35 The violence done to me and to my flesh be upon Babylon, shall the inhabitant of Zion say; and my blood upon the inhabitants of Chaldea, shall Jerusalem say.

Jeremiah 51:36 Therefore thus saith the Lord; Behold, I will plead thy cause, and take vengeance for thee; and I will dry up her sea, and make her springs dry.

Jeremiah 51:37 And Babylon shall become heaps, a dwellingplace for dragons, an astonishment, and an hissing, without an inhabitant.

Jeremiah 51:38 They shall roar together like lions: they shall yell as lions’ whelps.

Jeremiah 51:39 In their heat I will make their feasts, and I will make them drunken, that they may rejoice, and sleep a perpetual sleep, and not wake, saith the Lord.

Jeremiah 51:40 I will bring them down like lambs to the slaughter, like rams with he goats.

Jeremiah 51:41 How is Sheshach taken! and how is the praise of the whole earth surprised! how is Babylon become an astonishment among the nations!

Jeremiah 51:42 The sea is come up upon Babylon: she is covered with the multitude of the waves thereof.

Jeremiah 51:43 Her cities are a desolation, a dry land, and a wilderness, a land wherein no man dwelleth, neither doth any son of man pass thereby.

Jeremiah 51:44 And I will punish Bel in Babylon, and I will bring forth out of his mouth that which he hath swallowed up: and the nations shall not flow together any more unto him: yea, the wall of Babylon shall fall.

Jeremiah 51:45 My people, go ye out of the midst of her, and deliver ye every man his soul from the fierce anger of the Lord.

Jeremiah 51:46 And lest your heart faint, and ye fear for the rumour that shall be heard in the land; a rumour shall both come one year, and after that in another year shall come a rumour, and violence in the land, ruler against ruler.

Jeremiah 51:47 Therefore, behold, the days come, that I will do judgment upon the graven images of Babylon: and her whole land shall be confounded, and all her slain shall fall in the midst of her.

Jeremiah 51:48 Then the heaven and the earth, and all that is therein, shall sing for Babylon: for the spoilers shall come unto her from the north, saith the Lord.

Jeremiah 51:49 As Babylon hath caused the slain of Israel to fall, so at Babylon shall fall the slain of all the earth.

Jeremiah 51:50 Ye that have escaped the sword, go away, stand not still: remember the Lord afar off, and let Jerusalem come into your mind.

Jeremiah 51:51 We are confounded, because we have heard reproach: shame hath covered our faces: for strangers are come into the sanctuaries of the Lord’s house.

Jeremiah 51:52 Wherefore, behold, the days come, saith the Lord, that I will do judgment upon her graven images: and through all her land the wounded shall groan.

Jeremiah 51:53 Though Babylon should mount up to heaven, and though she should fortify the height of her strength, yet from me shall spoilers come unto her, saith the Lord.

Jeremiah 51:54 A sound of a cry cometh from Babylon, and great destruction from the land of the Chaldeans:

Jeremiah 51:55 Because the Lord hath spoiled Babylon, and destroyed out of her the great voice; when her waves do roar like great waters, a noise of their voice is uttered:

Jeremiah 51:56 Because the spoiler is come upon her, even upon Babylon, and her mighty men are taken, every one of their bows is broken: for the Lord God of recompences shall surely requite.

Jeremiah 51:57 And I will make drunk her princes, and her wise men, her captains, and her rulers, and her mighty men: and they shall sleep a perpetual sleep, and not wake, saith the King, whose name is the Lord of hosts.

Jeremiah 51:58 Thus saith the Lord of hosts; The broad walls of Babylon shall be utterly broken, and her high gates shall be burned with fire; and the people shall labour in vain, and the folk in the fire, and they shall be weary.

Jeremiah 51:59 The word which Jeremiah the prophet commanded Seraiah the son of Neriah, the son of Maaseiah, when he went with Zedekiah the king of Judah into Babylon in the fourth year of his reign. And this Seraiah was a quiet prince.

Jeremiah 51:60 So Jeremiah wrote in a book all the evil that should come upon Babylon, even all these words that are written against Babylon.

Jeremiah 51:61 And Jeremiah said to Seraiah, When thou comest to Babylon, and shalt see, and shalt read all these words;

Jeremiah 51:62 Then shalt thou say, O Lord, thou hast spoken against this place, to cut it off, that none shall remain in it, neither man nor beast, but that it shall be desolate for ever.

Jeremiah 51:63 And it shall be, when thou hast made an end of reading this book, that thou shalt bind a stone to it, and cast it into the midst of Euphrates:

Jeremiah 51:64 And thou shalt say, Thus shall Babylon sink, and shall not rise from the evil that I will bring upon her: and they shall be weary. Thus far are the words of Jeremiah.
