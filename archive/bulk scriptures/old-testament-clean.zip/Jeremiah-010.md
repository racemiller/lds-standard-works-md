# Jeremiah 10

Jeremiah 10 (summary): Learn not the way of other nations—Their gods are idols and molten images—The Lord is the true and living God.

Jeremiah 10:1 Hear ye the word which the Lord speaketh unto you, O house of Israel:

Jeremiah 10:2 Thus saith the Lord, Learn not the way of the heathen, and be not dismayed at the signs of heaven; for the heathen are dismayed at them.

Jeremiah 10:3 For the customs of the people are vain: for one cutteth a tree out of the forest, the work of the hands of the workman, with the axe.

Jeremiah 10:4 They deck it with silver and with gold; they fasten it with nails and with hammers, that it move not.

Jeremiah 10:5 They are upright as the palm tree, but speak not: they must needs be borne, because they cannot go. Be not afraid of them; for they cannot do evil, neither also is it in them to do good.

Jeremiah 10:6 Forasmuch as there is none like unto thee, O Lord; thou art great, and thy name is great in might.

Jeremiah 10:7 Who would not fear thee, O King of nations? for to thee doth it appertain: forasmuch as among all the wise men of the nations, and in all their kingdoms, there is none like unto thee.

Jeremiah 10:8 But they are altogether brutish and foolish: the stock is a doctrine of vanities.

Jeremiah 10:9 Silver spread into plates is brought from Tarshish, and gold from Uphaz, the work of the workman, and of the hands of the founder: blue and purple is their clothing: they are all the work of cunning men.

Jeremiah 10:10 But the Lord is the true God, he is the living God, and an everlasting king: at his wrath the earth shall tremble, and the nations shall not be able to abide his indignation.

Jeremiah 10:11 Thus shall ye say unto them, The gods that have not made the heavens and the earth, even they shall perish from the earth, and from under these heavens.

Jeremiah 10:12 He hath made the earth by his power, he hath established the world by his wisdom, and hath stretched out the heavens by his discretion.

Jeremiah 10:13 When he uttereth his voice, there is a multitude of waters in the heavens, and he causeth the vapours to ascend from the ends of the earth; he maketh lightnings with rain, and bringeth forth the wind out of his treasures.

Jeremiah 10:14 Every man is brutish in his knowledge: every founder is confounded by the graven image: for his molten image is falsehood, and there is no breath in them.

Jeremiah 10:15 They are vanity, and the work of errors: in the time of their visitation they shall perish.

Jeremiah 10:16 The portion of Jacob is not like them: for he is the former of all things; and Israel is the rod of his inheritance: The Lord of hosts is his name.

Jeremiah 10:17 Gather up thy wares out of the land, O inhabitant of the fortress.

Jeremiah 10:18 For thus saith the Lord, Behold, I will sling out the inhabitants of the land at this once, and will distress them, that they may find it so.

Jeremiah 10:19 Woe is me for my hurt! my wound is grievous: but I said, Truly this is a grief, and I must bear it.

Jeremiah 10:20 My tabernacle is spoiled, and all my cords are broken: my children are gone forth of me, and they are not: there is none to stretch forth my tent any more, and to set up my curtains.

Jeremiah 10:21 For the pastors are become brutish, and have not sought the Lord: therefore they shall not prosper, and all their flocks shall be scattered.

Jeremiah 10:22 Behold, the noise of the bruit is come, and a great commotion out of the north country, to make the cities of Judah desolate, and a den of dragons.

Jeremiah 10:23 O Lord, I know that the way of man is not in himself: it is not in man that walketh to direct his steps.

Jeremiah 10:24 O Lord, correct me, but with judgment; not in thine anger, lest thou bring me to nothing.

Jeremiah 10:25 Pour out thy fury upon the heathen that know thee not, and upon the families that call not on thy name: for they have eaten up Jacob, and devoured him, and consumed him, and have made his habitation desolate.
