# Exodus 36

Exodus 36 (summary): Wise-hearted men are chosen to work on the tabernacle—Moses restrains the people from donating any more material.

Exodus 36:1 Then wrought Bezaleel and Aholiab, and every wise hearted man, in whom the Lord put wisdom and understanding to know how to work all manner of work for the service of the sanctuary, according to all that the Lord had commanded.

Exodus 36:2 And Moses called Bezaleel and Aholiab, and every wise hearted man, in whose heart the Lord had put wisdom, even every one whose heart stirred him up to come unto the work to do it:

Exodus 36:3 And they received of Moses all the offering, which the children of Israel had brought for the work of the service of the sanctuary, to make it withal. And they brought yet unto him free offerings every morning.

Exodus 36:4 And all the wise men, that wrought all the work of the sanctuary, came every man from his work which they made;

Exodus 36:5 And they spake unto Moses, saying, The people bring much more than enough for the service of the work, which the Lord commanded to make.

Exodus 36:6 And Moses gave commandment, and they caused it to be proclaimed throughout the camp, saying, Let neither man nor woman make any more work for the offering of the sanctuary. So the people were restrained from bringing.

Exodus 36:7 For the stuff they had was sufficient for all the work to make it, and too much.

Exodus 36:8 And every wise hearted man among them that wrought the work of the tabernacle made ten curtains of fine twined linen, and blue, and purple, and scarlet: with cherubims of cunning work made he them.

Exodus 36:9 The length of one curtain was twenty and eight cubits, and the breadth of one curtain four cubits: the curtains were all of one size.

Exodus 36:10 And he coupled the five curtains one unto another: and the other five curtains he coupled one unto another.

Exodus 36:11 And he made loops of blue on the edge of one curtain from the selvedge in the coupling: likewise he made in the uttermost side of another curtain, in the coupling of the second.

Exodus 36:12 Fifty loops made he in one curtain, and fifty loops made he in the edge of the curtain which was in the coupling of the second: the loops held one curtain to another.

Exodus 36:13 And he made fifty taches of gold, and coupled the curtains one unto another with the taches: so it became one tabernacle.

Exodus 36:14 And he made curtains of goats’ hair for the tent over the tabernacle: eleven curtains he made them.

Exodus 36:15 The length of one curtain was thirty cubits, and four cubits was the breadth of one curtain: the eleven curtains were of one size.

Exodus 36:16 And he coupled five curtains by themselves, and six curtains by themselves.

Exodus 36:17 And he made fifty loops upon the uttermost edge of the curtain in the coupling, and fifty loops made he upon the edge of the curtain which coupleth the second.

Exodus 36:18 And he made fifty taches of brass to couple the tent together, that it might be one.

Exodus 36:19 And he made a covering for the tent of rams’ skins dyed red, and a covering of badgers’ skins above that.

Exodus 36:20 And he made boards for the tabernacle of shittim wood, standing up.

Exodus 36:21 The length of a board was ten cubits, and the breadth of a board one cubit and a half.

Exodus 36:22 One board had two tenons, equally distant one from another: thus did he make for all the boards of the tabernacle.

Exodus 36:23 And he made boards for the tabernacle; twenty boards for the south side southward:

Exodus 36:24 And forty sockets of silver he made under the twenty boards; two sockets under one board for his two tenons, and two sockets under another board for his two tenons.

Exodus 36:25 And for the other side of the tabernacle, which is toward the north corner, he made twenty boards,

Exodus 36:26 And their forty sockets of silver; two sockets under one board, and two sockets under another board.

Exodus 36:27 And for the sides of the tabernacle westward he made six boards.

Exodus 36:28 And two boards made he for the corners of the tabernacle in the two sides.

Exodus 36:29 And they were coupled beneath, and coupled together at the head thereof, to one ring: thus he did to both of them in both the corners.

Exodus 36:30 And there were eight boards; and their sockets were sixteen sockets of silver, under every board two sockets.

Exodus 36:31 And he made bars of shittim wood; five for the boards of the one side of the tabernacle,

Exodus 36:32 And five bars for the boards of the other side of the tabernacle, and five bars for the boards of the tabernacle for the sides westward.

Exodus 36:33 And he made the middle bar to shoot through the boards from the one end to the other.

Exodus 36:34 And he overlaid the boards with gold, and made their rings of gold to be places for the bars, and overlaid the bars with gold.

Exodus 36:35 And he made a veil of blue, and purple, and scarlet, and fine twined linen: with cherubims made he it of cunning work.

Exodus 36:36 And he made thereunto four pillars of shittim wood, and overlaid them with gold: their hooks were of gold; and he cast for them four sockets of silver.

Exodus 36:37 And he made an hanging for the tabernacle door of blue, and purple, and scarlet, and fine twined linen, of needlework;

Exodus 36:38 And the five pillars of it with their hooks: and he overlaid their chapiters and their fillets with gold: but their five sockets were of brass.
