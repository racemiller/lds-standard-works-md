# Psalms 72

Psalms 72 (summary): David speaks of Solomon, who is made a type of the Messiah—He will have dominion—His name will endure forever—All nations will call him blessed—The whole earth will be filled with the glory of the Lord.

Psalms 72:1 Give the king thy judgments, O God, and thy righteousness unto the king’s son.

Psalms 72:2 He shall judge thy people with righteousness, and thy poor with judgment.

Psalms 72:3 The mountains shall bring peace to the people, and the little hills, by righteousness.

Psalms 72:4 He shall judge the poor of the people, he shall save the children of the needy, and shall break in pieces the oppressor.

Psalms 72:5 They shall fear thee as long as the sun and moon endure, throughout all generations.

Psalms 72:6 He shall come down like rain upon the mown grass: as showers that water the earth.

Psalms 72:7 In his days shall the righteous flourish; and abundance of peace so long as the moon endureth.

Psalms 72:8 He shall have dominion also from sea to sea, and from the river unto the ends of the earth.

Psalms 72:9 They that dwell in the wilderness shall bow before him; and his enemies shall lick the dust.

Psalms 72:10 The kings of Tarshish and of the isles shall bring presents: the kings of Sheba and Seba shall offer gifts.

Psalms 72:11 Yea, all kings shall fall down before him: all nations shall serve him.

Psalms 72:12 For he shall deliver the needy when he crieth; the poor also, and him that hath no helper.

Psalms 72:13 He shall spare the poor and needy, and shall save the souls of the needy.

Psalms 72:14 He shall redeem their soul from deceit and violence: and precious shall their blood be in his sight.

Psalms 72:15 And he shall live, and to him shall be given of the gold of Sheba: prayer also shall be made for him continually; and daily shall he be praised.

Psalms 72:16 There shall be an handful of corn in the earth upon the top of the mountains; the fruit thereof shall shake like Lebanon: and they of the city shall flourish like grass of the earth.

Psalms 72:17 His name shall endure for ever: his name shall be continued as long as the sun: and men shall be blessed in him: all nations shall call him blessed.

Psalms 72:18 Blessed be the Lord God, the God of Israel, who only doeth wondrous things.

Psalms 72:19 And blessed be his glorious name for ever: and let the whole earth be filled with his glory; Amen, and Amen.

Psalms 72:20 The prayers of David the son of Jesse are ended.
