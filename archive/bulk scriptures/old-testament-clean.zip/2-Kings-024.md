# 2 Kings 24

2 Kings 24 (summary): Jerusalem is besieged and taken by Nebuchadnezzar—Many of the people of Judah are carried captive into Babylon—Zedekiah becomes king in Jerusalem—He rebels against Babylon.

2 Kings 24:1 In his days Nebuchadnezzar king of Babylon came up, and Jehoiakim became his servant three years: then he turned and rebelled against him.

2 Kings 24:2 And the Lord sent against him bands of the Chaldees, and bands of the Syrians, and bands of the Moabites, and bands of the children of Ammon, and sent them against Judah to destroy it, according to the word of the Lord, which he spake by his servants the prophets.

2 Kings 24:3 Surely at the commandment of the Lord came this upon Judah, to remove them out of his sight, for the sins of Manasseh, according to all that he did;

2 Kings 24:4 And also for the innocent blood that he shed: for he filled Jerusalem with innocent blood; which the Lord would not pardon.

2 Kings 24:5 Now the rest of the acts of Jehoiakim, and all that he did, are they not written in the book of the chronicles of the kings of Judah?

2 Kings 24:6 So Jehoiakim slept with his fathers: and Jehoiachin his son reigned in his stead.

2 Kings 24:7 And the king of Egypt came not again any more out of his land: for the king of Babylon had taken from the river of Egypt unto the river Euphrates all that pertained to the king of Egypt.

2 Kings 24:8 Jehoiachin was eighteen years old when he began to reign, and he reigned in Jerusalem three months. And his mother’s name was Nehushta, the daughter of Elnathan of Jerusalem.

2 Kings 24:9 And he did that which was evil in the sight of the Lord, according to all that his father had done.

2 Kings 24:10 At that time the servants of Nebuchadnezzar king of Babylon came up against Jerusalem, and the city was besieged.

2 Kings 24:11 And Nebuchadnezzar king of Babylon came against the city, and his servants did besiege it.

2 Kings 24:12 And Jehoiachin the king of Judah went out to the king of Babylon, he, and his mother, and his servants, and his princes, and his officers: and the king of Babylon took him in the eighth year of his reign.

2 Kings 24:13 And he carried out thence all the treasures of the house of the Lord, and the treasures of the king’s house, and cut in pieces all the vessels of gold which Solomon king of Israel had made in the temple of the Lord, as the Lord had said.

2 Kings 24:14 And he carried away all Jerusalem, and all the princes, and all the mighty men of valour, even ten thousand captives, and all the craftsmen and smiths: none remained, save the poorest sort of the people of the land.

2 Kings 24:15 And he carried away Jehoiachin to Babylon, and the king’s mother, and the king’s wives, and his officers, and the mighty of the land, those carried he into captivity from Jerusalem to Babylon.

2 Kings 24:16 And all the men of might, even seven thousand, and craftsmen and smiths a thousand, all that were strong and apt for war, even them the king of Babylon brought captive to Babylon.

2 Kings 24:17 And the king of Babylon made Mattaniah his father’s brother king in his stead, and changed his name to Zedekiah.

2 Kings 24:18 Zedekiah was twenty and one years old when he began to reign, and he reigned eleven years in Jerusalem. And his mother’s name was Hamutal, the daughter of Jeremiah of Libnah.

2 Kings 24:19 And he did that which was evil in the sight of the Lord, according to all that Jehoiakim had done.

2 Kings 24:20 For through the anger of the Lord it came to pass in Jerusalem and Judah, until he had cast them out from his presence, that Zedekiah rebelled against the king of Babylon.
