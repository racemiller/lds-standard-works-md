# Numbers 16

Numbers 16 (summary): Korah, Dathan, Abiram, and 250 leaders rebel and seek priestly offices—The earth swallows the three rebels and their families—Fire from the Lord consumes the 250 rebels—Israel murmurs against Moses and Aaron for slaying the people—The Lord sends a plague, from which 14,700 die.

Numbers 16:1 Now Korah, the son of Izhar, the son of Kohath, the son of Levi, and Dathan and Abiram, the sons of Eliab, and On, the son of Peleth, sons of Reuben, took men:

Numbers 16:2 And they rose up before Moses, with certain of the children of Israel, two hundred and fifty princes of the assembly, famous in the congregation, men of renown:

Numbers 16:3 And they gathered themselves together against Moses and against Aaron, and said unto them, Ye take too much upon you, seeing all the congregation are holy, every one of them, and the Lord is among them: wherefore then lift ye up yourselves above the congregation of the Lord?

Numbers 16:4 And when Moses heard it, he fell upon his face:

Numbers 16:5 And he spake unto Korah and unto all his company, saying, Even to morrow the Lord will shew who are his, and who is holy; and will cause him to come near unto him: even him whom he hath chosen will he cause to come near unto him.

Numbers 16:6 This do; Take you censers, Korah, and all his company;

Numbers 16:7 And put fire therein, and put incense in them before the Lord to morrow: and it shall be that the man whom the Lord doth choose, he shall be holy: ye take too much upon you, ye sons of Levi.

Numbers 16:8 And Moses said unto Korah, Hear, I pray you, ye sons of Levi:

Numbers 16:9 Seemeth it but a small thing unto you, that the God of Israel hath separated you from the congregation of Israel, to bring you near to himself to do the service of the tabernacle of the Lord, and to stand before the congregation to minister unto them?

Numbers 16:10 And he hath brought thee near to him, and all thy brethren the sons of Levi with thee: and seek ye the priesthood also?

Numbers 16:11 For which cause both thou and all thy company are gathered together against the Lord: and what is Aaron, that ye murmur against him?

Numbers 16:12 And Moses sent to call Dathan and Abiram, the sons of Eliab: which said, We will not come up:

Numbers 16:13 Is it a small thing that thou hast brought us up out of a land that floweth with milk and honey, to kill us in the wilderness, except thou make thyself altogether a prince over us?

Numbers 16:14 Moreover thou hast not brought us into a land that floweth with milk and honey, or given us inheritance of fields and vineyards: wilt thou put out the eyes of these men? we will not come up.

Numbers 16:15 And Moses was very wroth, and said unto the Lord, Respect not thou their offering: I have not taken one ass from them, neither have I hurt one of them.

Numbers 16:16 And Moses said unto Korah, Be thou and all thy company before the Lord, thou, and they, and Aaron, to morrow:

Numbers 16:17 And take every man his censer, and put incense in them, and bring ye before the Lord every man his censer, two hundred and fifty censers; thou also, and Aaron, each of you his censer.

Numbers 16:18 And they took every man his censer, and put fire in them, and laid incense thereon, and stood in the door of the tabernacle of the congregation with Moses and Aaron.

Numbers 16:19 And Korah gathered all the congregation against them unto the door of the tabernacle of the congregation: and the glory of the Lord appeared unto all the congregation.

Numbers 16:20 And the Lord spake unto Moses and unto Aaron, saying,

Numbers 16:21 Separate yourselves from among this congregation, that I may consume them in a moment.

Numbers 16:22 And they fell upon their faces, and said, O God, the God of the spirits of all flesh, shall one man sin, and wilt thou be wroth with all the congregation?

Numbers 16:23 And the Lord spake unto Moses, saying,

Numbers 16:24 Speak unto the congregation, saying, Get you up from about the tabernacle of Korah, Dathan, and Abiram.

Numbers 16:25 And Moses rose up and went unto Dathan and Abiram; and the elders of Israel followed him.

Numbers 16:26 And he spake unto the congregation, saying, Depart, I pray you, from the tents of these wicked men, and touch nothing of theirs, lest ye be consumed in all their sins.

Numbers 16:27 So they gat up from the tabernacle of Korah, Dathan, and Abiram, on every side: and Dathan and Abiram came out, and stood in the door of their tents, and their wives, and their sons, and their little children.

Numbers 16:28 And Moses said, Hereby ye shall know that the Lord hath sent me to do all these works; for I have not done them of mine own mind.

Numbers 16:29 If these men die the common death of all men, or if they be visited after the visitation of all men; then the Lord hath not sent me.

Numbers 16:30 But if the Lord make a new thing, and the earth open her mouth, and swallow them up, with all that appertain unto them, and they go down quick into the pit; then ye shall understand that these men have provoked the Lord.

Numbers 16:31 And it came to pass, as he had made an end of speaking all these words, that the ground clave asunder that was under them:

Numbers 16:32 And the earth opened her mouth, and swallowed them up, and their houses, and all the men that appertained unto Korah, and all their goods.

Numbers 16:33 They, and all that appertained to them, went down alive into the pit, and the earth closed upon them: and they perished from among the congregation.

Numbers 16:34 And all Israel that were round about them fled at the cry of them: for they said, Lest the earth swallow us up also.

Numbers 16:35 And there came out a fire from the Lord, and consumed the two hundred and fifty men that offered incense.

Numbers 16:36 And the Lord spake unto Moses, saying,

Numbers 16:37 Speak unto Eleazar the son of Aaron the priest, that he take up the censers out of the burning, and scatter thou the fire yonder; for they are hallowed.

Numbers 16:38 The censers of these sinners against their own souls, let them make them broad plates for a covering of the altar: for they offered them before the Lord, therefore they are hallowed: and they shall be a sign unto the children of Israel.

Numbers 16:39 And Eleazar the priest took the brasen censers, wherewith they that were burnt had offered; and they were made broad plates for a covering of the altar:

Numbers 16:40 To be a memorial unto the children of Israel, that no stranger, which is not of the seed of Aaron, come near to offer incense before the Lord; that he be not as Korah, and as his company: as the Lord said to him by the hand of Moses.

Numbers 16:41 But on the morrow all the congregation of the children of Israel murmured against Moses and against Aaron, saying, Ye have killed the people of the Lord.

Numbers 16:42 And it came to pass, when the congregation was gathered against Moses and against Aaron, that they looked toward the tabernacle of the congregation: and, behold, the cloud covered it, and the glory of the Lord appeared.

Numbers 16:43 And Moses and Aaron came before the tabernacle of the congregation.

Numbers 16:44 And the Lord spake unto Moses, saying,

Numbers 16:45 Get you up from among this congregation, that I may consume them as in a moment. And they fell upon their faces.

Numbers 16:46 And Moses said unto Aaron, Take a censer, and put fire therein from off the altar, and put on incense, and go quickly unto the congregation, and make an atonement for them: for there is wrath gone out from the Lord; the plague is begun.

Numbers 16:47 And Aaron took as Moses commanded, and ran into the midst of the congregation; and, behold, the plague was begun among the people: and he put on incense, and made an atonement for the people.

Numbers 16:48 And he stood between the dead and the living; and the plague was stayed.

Numbers 16:49 Now they that died in the plague were fourteen thousand and seven hundred, beside them that died about the matter of Korah.

Numbers 16:50 And Aaron returned unto Moses unto the door of the tabernacle of the congregation: and the plague was stayed.
