# Exodus 6

Exodus 6 (summary): The Lord identifies Himself as Jehovah—The genealogies of Reuben, Simeon, and Levi are listed.

Exodus 6:1 Then the Lord said unto Moses, Now shalt thou see what I will do to Pharaoh: for with a strong hand shall he let them go, and with a strong hand shall he drive them out of his land.

Exodus 6:2 And God spake unto Moses, and said unto him, I am the Lord:

Exodus 6:3 And I appeared unto Abraham, unto Isaac, and unto Jacob, by the name of God Almighty, but by my name Jehovah was I not known to them.

Exodus 6:4 And I have also established my covenant with them, to give them the land of Canaan, the land of their pilgrimage, wherein they were strangers.

Exodus 6:5 And I have also heard the groaning of the children of Israel, whom the Egyptians keep in bondage; and I have remembered my covenant.

Exodus 6:6 Wherefore say unto the children of Israel, I am the Lord, and I will bring you out from under the burdens of the Egyptians, and I will rid you out of their bondage, and I will redeem you with a stretched out arm, and with great judgments:

Exodus 6:7 And I will take you to me for a people, and I will be to you a God: and ye shall know that I am the Lord your God, which bringeth you out from under the burdens of the Egyptians.

Exodus 6:8 And I will bring you in unto the land, concerning the which I did swear to give it to Abraham, to Isaac, and to Jacob; and I will give it you for an heritage: I am the Lord.

Exodus 6:9 And Moses spake so unto the children of Israel: but they hearkened not unto Moses for anguish of spirit, and for cruel bondage.

Exodus 6:10 And the Lord spake unto Moses, saying,

Exodus 6:11 Go in, speak unto Pharaoh king of Egypt, that he let the children of Israel go out of his land.

Exodus 6:12 And Moses spake before the Lord, saying, Behold, the children of Israel have not hearkened unto me; how then shall Pharaoh hear me, who am of uncircumcised lips?

Exodus 6:13 And the Lord spake unto Moses and unto Aaron, and gave them a charge unto the children of Israel, and unto Pharaoh king of Egypt, to bring the children of Israel out of the land of Egypt.

Exodus 6:14 These be the heads of their fathers’ houses: The sons of Reuben the firstborn of Israel; Hanoch, and Pallu, Hezron, and Carmi: these be the families of Reuben.

Exodus 6:15 And the sons of Simeon; Jemuel, and Jamin, and Ohad, and Jachin, and Zohar, and Shaul the son of a Canaanitish woman: these are the families of Simeon.

Exodus 6:16 And these are the names of the sons of Levi according to their generations; Gershon, and Kohath, and Merari: and the years of the life of Levi were an hundred thirty and seven years.

Exodus 6:17 The sons of Gershon; Libni, and Shimi, according to their families.

Exodus 6:18 And the sons of Kohath; Amram, and Izhar, and Hebron, and Uzziel: and the years of the life of Kohath were an hundred thirty and three years.

Exodus 6:19 And the sons of Merari; Mahali and Mushi: these are the families of Levi according to their generations.

Exodus 6:20 And Amram took him Jochebed his father’s sister to wife; and she bare him Aaron and Moses: and the years of the life of Amram were an hundred and thirty and seven years.

Exodus 6:21 And the sons of Izhar; Korah, and Nepheg, and Zichri.

Exodus 6:22 And the sons of Uzziel; Mishael, and Elzaphan, and Zithri.

Exodus 6:23 And Aaron took him Elisheba, daughter of Amminadab, sister of Naashon, to wife; and she bare him Nadab, and Abihu, Eleazar, and Ithamar.

Exodus 6:24 And the sons of Korah; Assir, and Elkanah, and Abiasaph: these are the families of the Korhites.

Exodus 6:25 And Eleazar Aaron’s son took him one of the daughters of Putiel to wife; and she bare him Phinehas: these are the heads of the fathers of the Levites according to their families.

Exodus 6:26 These are that Aaron and Moses, to whom the Lord said, Bring out the children of Israel from the land of Egypt according to their armies.

Exodus 6:27 These are they which spake to Pharaoh king of Egypt, to bring out the children of Israel from Egypt: these are that Moses and Aaron.

Exodus 6:28 And it came to pass on the day when the Lord spake unto Moses in the land of Egypt,

Exodus 6:29 That the Lord spake unto Moses, saying, I am the Lord: speak thou unto Pharaoh king of Egypt all that I say unto thee.

Exodus 6:30 And Moses said before the Lord, Behold, I am of uncircumcised lips, and how shall Pharaoh hearken unto me?
