# Deuteronomy 1

Deuteronomy 1 (summary): Moses begins the recitation of all that befell Israel during forty years in the wilderness—The children of Israel are commanded to go into and possess Canaan—Judges and rulers are chosen to assist Moses—Israel’s spies bring an evil report—The adults of Israel will perish—The Amorites defeat the armies of Israel.

Deuteronomy 1:1 These be the words which Moses spake unto all Israel on this side Jordan in the wilderness, in the plain over against the Red sea, between Paran, and Tophel, and Laban, and Hazeroth, and Dizahab.

Deuteronomy 1:2 (There are eleven days’ journey from Horeb by the way of mount Seir unto Kadesh-barnea.)

Deuteronomy 1:3 And it came to pass in the fortieth year, in the eleventh month, on the first day of the month, that Moses spake unto the children of Israel, according unto all that the Lord had given him in commandment unto them;

Deuteronomy 1:4 After he had slain Sihon the king of the Amorites, which dwelt in Heshbon, and Og the king of Bashan, which dwelt at Astaroth in Edrei:

Deuteronomy 1:5 On this side Jordan, in the land of Moab, began Moses to declare this law, saying,

Deuteronomy 1:6 The Lord our God spake unto us in Horeb, saying, Ye have dwelt long enough in this mount:

Deuteronomy 1:7 Turn you, and take your journey, and go to the mount of the Amorites, and unto all the places nigh thereunto, in the plain, in the hills, and in the vale, and in the south, and by the sea side, to the land of the Canaanites, and unto Lebanon, unto the great river, the river Euphrates.

Deuteronomy 1:8 Behold, I have set the land before you: go in and possess the land which the Lord sware unto your fathers, Abraham, Isaac, and Jacob, to give unto them and to their seed after them.

Deuteronomy 1:9 And I spake unto you at that time, saying, I am not able to bear you myself alone:

Deuteronomy 1:10 The Lord your God hath multiplied you, and, behold, ye are this day as the stars of heaven for multitude.

Deuteronomy 1:11 (The Lord God of your fathers make you a thousand times so many more as ye are, and bless you, as he hath promised you!)

Deuteronomy 1:12 How can I myself alone bear your cumbrance, and your burden, and your strife?

Deuteronomy 1:13 Take you wise men, and understanding, and known among your tribes, and I will make them rulers over you.

Deuteronomy 1:14 And ye answered me, and said, The thing which thou hast spoken is good for us to do.

Deuteronomy 1:15 So I took the chief of your tribes, wise men, and known, and made them heads over you, captains over thousands, and captains over hundreds, and captains over fifties, and captains over tens, and officers among your tribes.

Deuteronomy 1:16 And I charged your judges at that time, saying, Hear the causes between your brethren, and judge righteously between every man and his brother, and the stranger that is with him.

Deuteronomy 1:17 Ye shall not respect persons in judgment; but ye shall hear the small as well as the great; ye shall not be afraid of the face of man; for the judgment is God’s: and the cause that is too hard for you, bring it unto me, and I will hear it.

Deuteronomy 1:18 And I commanded you at that time all the things which ye should do.

Deuteronomy 1:19 And when we departed from Horeb, we went through all that great and terrible wilderness, which ye saw by the way of the mountain of the Amorites, as the Lord our God commanded us; and we came to Kadesh-barnea.

Deuteronomy 1:20 And I said unto you, Ye are come unto the mountain of the Amorites, which the Lord our God doth give unto us.

Deuteronomy 1:21 Behold, the Lord thy God hath set the land before thee: go up and possess it, as the Lord God of thy fathers hath said unto thee; fear not, neither be discouraged.

Deuteronomy 1:22 And ye came near unto me every one of you, and said, We will send men before us, and they shall search us out the land, and bring us word again by what way we must go up, and into what cities we shall come.

Deuteronomy 1:23 And the saying pleased me well: and I took twelve men of you, one of a tribe:

Deuteronomy 1:24 And they turned and went up into the mountain, and came unto the valley of Eshcol, and searched it out.

Deuteronomy 1:25 And they took of the fruit of the land in their hands, and brought it down unto us, and brought us word again, and said, It is a good land which the Lord our God doth give us.

Deuteronomy 1:26 Notwithstanding ye would not go up, but rebelled against the commandment of the Lord your God:

Deuteronomy 1:27 And ye murmured in your tents, and said, Because the Lord hated us, he hath brought us forth out of the land of Egypt, to deliver us into the hand of the Amorites, to destroy us.

Deuteronomy 1:28 Whither shall we go up? our brethren have discouraged our heart, saying, The people is greater and taller than we; the cities are great and walled up to heaven; and moreover we have seen the sons of the Anakims there.

Deuteronomy 1:29 Then I said unto you, Dread not, neither be afraid of them.

Deuteronomy 1:30 The Lord your God which goeth before you, he shall fight for you, according to all that he did for you in Egypt before your eyes;

Deuteronomy 1:31 And in the wilderness, where thou hast seen how that the Lord thy God bare thee, as a man doth bear his son, in all the way that ye went, until ye came into this place.

Deuteronomy 1:32 Yet in this thing ye did not believe the Lord your God,

Deuteronomy 1:33 Who went in the way before you, to search you out a place to pitch your tents in, in fire by night, to shew you by what way ye should go, and in a cloud by day.

Deuteronomy 1:34 And the Lord heard the voice of your words, and was wroth, and sware, saying,

Deuteronomy 1:35 Surely there shall not one of these men of this evil generation see that good land, which I sware to give unto your fathers,

Deuteronomy 1:36 Save Caleb the son of Jephunneh; he shall see it, and to him will I give the land that he hath trodden upon, and to his children, because he hath wholly followed the Lord.

Deuteronomy 1:37 Also the Lord was angry with me for your sakes, saying, Thou also shalt not go in thither.

Deuteronomy 1:38 But Joshua the son of Nun, which standeth before thee, he shall go in thither: encourage him: for he shall cause Israel to inherit it.

Deuteronomy 1:39 Moreover your little ones, which ye said should be a prey, and your children, which in that day had no knowledge between good and evil, they shall go in thither, and unto them will I give it, and they shall possess it.

Deuteronomy 1:40 But as for you, turn you, and take your journey into the wilderness by the way of the Red sea.

Deuteronomy 1:41 Then ye answered and said unto me, We have sinned against the Lord, we will go up and fight, according to all that the Lord our God commanded us. And when ye had girded on every man his weapons of war, ye were ready to go up into the hill.

Deuteronomy 1:42 And the Lord said unto me, Say unto them, Go not up, neither fight; for I am not among you; lest ye be smitten before your enemies.

Deuteronomy 1:43 So I spake unto you; and ye would not hear, but rebelled against the commandment of the Lord, and went presumptuously up into the hill.

Deuteronomy 1:44 And the Amorites, which dwelt in that mountain, came out against you, and chased you, as bees do, and destroyed you in Seir, even unto Hormah.

Deuteronomy 1:45 And ye returned and wept before the Lord; but the Lord would not hearken to your voice, nor give ear unto you.

Deuteronomy 1:46 So ye abode in Kadesh many days, according unto the days that ye abode there.
