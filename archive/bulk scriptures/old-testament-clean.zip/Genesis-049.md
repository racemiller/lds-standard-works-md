# Genesis 49

Genesis 49 (summary): Jacob blesses his sons and their seed—Reuben, Simeon, and Levi are chastened—Judah will rule until Shiloh (Christ) comes—Joseph is a fruitful bough by a well—His branches (the Nephites and Lamanites) will run over the wall—The Shepherd and Stone of Israel (Christ) will bless Joseph temporally and spiritually—Jacob chooses to be buried with his fathers in Canaan—He yields up the ghost and is gathered to his people.

Genesis 49:1 And Jacob called unto his sons, and said, Gather yourselves together, that I may tell you that which shall befall you in the last days.

Genesis 49:2 Gather yourselves together, and hear, ye sons of Jacob; and hearken unto Israel your father.

Genesis 49:3 Reuben, thou art my firstborn, my might, and the beginning of my strength, the excellency of dignity, and the excellency of power:

Genesis 49:4 Unstable as water, thou shalt not excel; because thou wentest up to thy father’s bed; then defiledst thou it: he went up to my couch.

Genesis 49:5 Simeon and Levi are brethren; instruments of cruelty are in their habitations.

Genesis 49:6 O my soul, come not thou into their secret; unto their assembly, mine honour, be not thou united: for in their anger they slew a man, and in their selfwill they digged down a wall.

Genesis 49:7 Cursed be their anger, for it was fierce; and their wrath, for it was cruel: I will divide them in Jacob, and scatter them in Israel.

Genesis 49:8 Judah, thou art he whom thy brethren shall praise: thy hand shall be in the neck of thine enemies; thy father’s children shall bow down before thee.

Genesis 49:9 Judah is a lion’s whelp: from the prey, my son, thou art gone up: he stooped down, he couched as a lion, and as an old lion; who shall rouse him up?

Genesis 49:10 The sceptre shall not depart from Judah, nor a lawgiver from between his feet, until Shiloh come; and unto him shall the gathering of the people be.

Genesis 49:11 Binding his foal unto the vine, and his ass’s colt unto the choice vine; he washed his garments in wine, and his clothes in the blood of grapes:

Genesis 49:12 His eyes shall be red with wine, and his teeth white with milk.

Genesis 49:13 Zebulun shall dwell at the haven of the sea; and he shall be for an haven of ships; and his border shall be unto Zidon.

Genesis 49:14 Issachar is a strong ass couching down between two burdens:

Genesis 49:15 And he saw that rest was good, and the land that it was pleasant; and bowed his shoulder to bear, and became a servant unto tribute.

Genesis 49:16 Dan shall judge his people, as one of the tribes of Israel.

Genesis 49:17 Dan shall be a serpent by the way, an adder in the path, that biteth the horse heels, so that his rider shall fall backward.

Genesis 49:18 I have waited for thy salvation, O Lord.

Genesis 49:19 Gad, a troop shall overcome him: but he shall overcome at the last.

Genesis 49:20 Out of Asher his bread shall be fat, and he shall yield royal dainties.

Genesis 49:21 Naphtali is a hind let loose: he giveth goodly words.

Genesis 49:22 Joseph is a fruitful bough, even a fruitful bough by a well; whose branches run over the wall:

Genesis 49:23 The archers have sorely grieved him, and shot at him, and hated him:

Genesis 49:24 But his bow abode in strength, and the arms of his hands were made strong by the hands of the mighty God of Jacob; (from thence is the shepherd, the stone of Israel:)

Genesis 49:25 Even by the God of thy father, who shall help thee; and by the Almighty, who shall bless thee with blessings of heaven above, blessings of the deep that lieth under, blessings of the breasts, and of the womb:

Genesis 49:26 The blessings of thy father have prevailed above the blessings of my progenitors unto the utmost bound of the everlasting hills: they shall be on the head of Joseph, and on the crown of the head of him that was separate from his brethren.

Genesis 49:27 Benjamin shall ravin as a wolf: in the morning he shall devour the prey, and at night he shall divide the spoil.

Genesis 49:28 All these are the twelve tribes of Israel: and this is it that their father spake unto them, and blessed them; every one according to his blessing he blessed them.

Genesis 49:29 And he charged them, and said unto them, I am to be gathered unto my people: bury me with my fathers in the cave that is in the field of Ephron the Hittite,

Genesis 49:30 In the cave that is in the field of Machpelah, which is before Mamre, in the land of Canaan, which Abraham bought with the field of Ephron the Hittite for a possession of a buryingplace.

Genesis 49:31 There they buried Abraham and Sarah his wife; there they buried Isaac and Rebekah his wife; and there I buried Leah.

Genesis 49:32 The purchase of the field and of the cave that is therein was from the children of Heth.

Genesis 49:33 And when Jacob had made an end of commanding his sons, he gathered up his feet into the bed, and yielded up the ghost, and was gathered unto his people.
