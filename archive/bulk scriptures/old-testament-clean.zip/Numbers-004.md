# Numbers 4

Numbers 4 (summary): When the camps of Israel move, Aaron and his sons cover the holy things in the tabernacle—The Levites of the families of Kohath, Gershon, and Merari carry the burden of the tabernacle.

Numbers 4:1 And the Lord spake unto Moses and unto Aaron, saying,

Numbers 4:2 Take the sum of the sons of Kohath from among the sons of Levi, after their families, by the house of their fathers,

Numbers 4:3 From thirty years old and upward even until fifty years old, all that enter into the host, to do the work in the tabernacle of the congregation.

Numbers 4:4 This shall be the service of the sons of Kohath in the tabernacle of the congregation, about the most holy things:

Numbers 4:5 And when the camp setteth forward, Aaron shall come, and his sons, and they shall take down the covering veil, and cover the ark of testimony with it:

Numbers 4:6 And shall put thereon the covering of badgers’ skins, and shall spread over it a cloth wholly of blue, and shall put in the staves thereof.

Numbers 4:7 And upon the table of shewbread they shall spread a cloth of blue, and put thereon the dishes, and the spoons, and the bowls, and covers to cover withal: and the continual bread shall be thereon:

Numbers 4:8 And they shall spread upon them a cloth of scarlet, and cover the same with a covering of badgers’ skins, and shall put in the staves thereof.

Numbers 4:9 And they shall take a cloth of blue, and cover the candlestick of the light, and his lamps, and his tongs, and his snuffdishes, and all the oil vessels thereof, wherewith they minister unto it:

Numbers 4:10 And they shall put it and all the vessels thereof within a covering of badgers’ skins, and shall put it upon a bar.

Numbers 4:11 And upon the golden altar they shall spread a cloth of blue, and cover it with a covering of badgers’ skins, and shall put to the staves thereof:

Numbers 4:12 And they shall take all the instruments of ministry, wherewith they minister in the sanctuary, and put them in a cloth of blue, and cover them with a covering of badgers’ skins, and shall put them on a bar:

Numbers 4:13 And they shall take away the ashes from the altar, and spread a purple cloth thereon:

Numbers 4:14 And they shall put upon it all the vessels thereof, wherewith they minister about it, even the censers, the fleshhooks, and the shovels, and the basins, all the vessels of the altar; and they shall spread upon it a covering of badgers’ skins, and put to the staves of it.

Numbers 4:15 And when Aaron and his sons have made an end of covering the sanctuary, and all the vessels of the sanctuary, as the camp is to set forward; after that, the sons of Kohath shall come to bear it: but they shall not touch any holy thing, lest they die. These things are the burden of the sons of Kohath in the tabernacle of the congregation.

Numbers 4:16 And to the office of Eleazar the son of Aaron the priest pertaineth the oil for the light, and the sweet incense, and the daily meat offering, and the anointing oil, and the oversight of all the tabernacle, and of all that therein is, in the sanctuary, and in the vessels thereof.

Numbers 4:17 And the Lord spake unto Moses and unto Aaron, saying,

Numbers 4:18 Cut ye not off the tribe of the families of the Kohathites from among the Levites:

Numbers 4:19 But thus do unto them, that they may live, and not die, when they approach unto the most holy things: Aaron and his sons shall go in, and appoint them every one to his service and to his burden:

Numbers 4:20 But they shall not go in to see when the holy things are covered, lest they die.

Numbers 4:21 And the Lord spake unto Moses, saying,

Numbers 4:22 Take also the sum of the sons of Gershon, throughout the houses of their fathers, by their families;

Numbers 4:23 From thirty years old and upward until fifty years old shalt thou number them; all that enter in to perform the service, to do the work in the tabernacle of the congregation.

Numbers 4:24 This is the service of the families of the Gershonites, to serve, and for burdens:

Numbers 4:25 And they shall bear the curtains of the tabernacle, and the tabernacle of the congregation, his covering, and the covering of the badgers’ skins that is above upon it, and the hanging for the door of the tabernacle of the congregation,

Numbers 4:26 And the hangings of the court, and the hanging for the door of the gate of the court, which is by the tabernacle and by the altar round about, and their cords, and all the instruments of their service, and all that is made for them: so shall they serve.

Numbers 4:27 At the appointment of Aaron and his sons shall be all the service of the sons of the Gershonites, in all their burdens, and in all their service: and ye shall appoint unto them in charge all their burdens.

Numbers 4:28 This is the service of the families of the sons of Gershon in the tabernacle of the congregation: and their charge shall be under the hand of Ithamar the son of Aaron the priest.

Numbers 4:29 As for the sons of Merari, thou shalt number them after their families, by the house of their fathers;

Numbers 4:30 From thirty years old and upward even unto fifty years old shalt thou number them, every one that entereth into the service, to do the work of the tabernacle of the congregation.

Numbers 4:31 And this is the charge of their burden, according to all their service in the tabernacle of the congregation; the boards of the tabernacle, and the bars thereof, and the pillars thereof, and sockets thereof,

Numbers 4:32 And the pillars of the court round about, and their sockets, and their pins, and their cords, with all their instruments, and with all their service: and by name ye shall reckon the instruments of the charge of their burden.

Numbers 4:33 This is the service of the families of the sons of Merari, according to all their service, in the tabernacle of the congregation, under the hand of Ithamar the son of Aaron the priest.

Numbers 4:34 And Moses and Aaron and the chief of the congregation numbered the sons of the Kohathites after their families, and after the house of their fathers,

Numbers 4:35 From thirty years old and upward even unto fifty years old, every one that entereth into the service, for the work in the tabernacle of the congregation:

Numbers 4:36 And those that were numbered of them by their families were two thousand seven hundred and fifty.

Numbers 4:37 These were they that were numbered of the families of the Kohathites, all that might do service in the tabernacle of the congregation, which Moses and Aaron did number according to the commandment of the Lord by the hand of Moses.

Numbers 4:38 And those that were numbered of the sons of Gershon, throughout their families, and by the house of their fathers,

Numbers 4:39 From thirty years old and upward even unto fifty years old, every one that entereth into the service, for the work in the tabernacle of the congregation,

Numbers 4:40 Even those that were numbered of them, throughout their families, by the house of their fathers, were two thousand and six hundred and thirty.

Numbers 4:41 These are they that were numbered of the families of the sons of Gershon, of all that might do service in the tabernacle of the congregation, whom Moses and Aaron did number according to the commandment of the Lord.

Numbers 4:42 And those that were numbered of the families of the sons of Merari, throughout their families, by the house of their fathers,

Numbers 4:43 From thirty years old and upward even unto fifty years old, every one that entereth into the service, for the work in the tabernacle of the congregation,

Numbers 4:44 Even those that were numbered of them after their families, were three thousand and two hundred.

Numbers 4:45 These be those that were numbered of the families of the sons of Merari, whom Moses and Aaron numbered according to the word of the Lord by the hand of Moses.

Numbers 4:46 All those that were numbered of the Levites, whom Moses and Aaron and the chief of Israel numbered, after their families, and after the house of their fathers,

Numbers 4:47 From thirty years old and upward even unto fifty years old, every one that came to do the service of the ministry, and the service of the burden in the tabernacle of the congregation,

Numbers 4:48 Even those that were numbered of them, were eight thousand and five hundred and fourscore.

Numbers 4:49 According to the commandment of the Lord they were numbered by the hand of Moses, every one according to his service, and according to his burden: thus were they numbered of him, as the Lord commanded Moses.
