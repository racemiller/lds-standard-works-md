# Isaiah 8

Isaiah 8 (summary): Christ will be as a stone of stumbling and a rock of offense—Seek the Lord, not muttering wizards—Turn to the law and to the testimony for guidance—Compare 2 Nephi 18.

Isaiah 8:1 Moreover the Lord said unto me, Take thee a great roll, and write in it with a man’s pen concerning Maher-shalal-hash-baz.

Isaiah 8:2 And I took unto me faithful witnesses to record, Uriah the priest, and Zechariah the son of Jeberechiah.

Isaiah 8:3 And I went unto the prophetess; and she conceived, and bare a son. Then said the Lord to me, Call his name Maher-shalal-hash-baz.

Isaiah 8:4 For before the child shall have knowledge to cry, My father, and my mother, the riches of Damascus and the spoil of Samaria shall be taken away before the king of Assyria.

Isaiah 8:5 The Lord spake also unto me again, saying,

Isaiah 8:6 Forasmuch as this people refuseth the waters of Shiloah that go softly, and rejoice in Rezin and Remaliah’s son;

Isaiah 8:7 Now therefore, behold, the Lord bringeth up upon them the waters of the river, strong and many, even the king of Assyria, and all his glory: and he shall come up over all his channels, and go over all his banks:

Isaiah 8:8 And he shall pass through Judah; he shall overflow and go over, he shall reach even to the neck; and the stretching out of his wings shall fill the breadth of thy land, O Immanuel.

Isaiah 8:9 Associate yourselves, O ye people, and ye shall be broken in pieces; and give ear, all ye of far countries: gird yourselves, and ye shall be broken in pieces; gird yourselves, and ye shall be broken in pieces.

Isaiah 8:10 Take counsel together, and it shall come to nought; speak the word, and it shall not stand: for God is with us.

Isaiah 8:11 For the Lord spake thus to me with a strong hand, and instructed me that I should not walk in the way of this people, saying,

Isaiah 8:12 Say ye not, A confederacy, to all them to whom this people shall say, A confederacy; neither fear ye their fear, nor be afraid.

Isaiah 8:13 Sanctify the Lord of hosts himself; and let him be your fear, and let him be your dread.

Isaiah 8:14 And he shall be for a sanctuary; but for a stone of stumbling and for a rock of offence to both the houses of Israel, for a gin and for a snare to the inhabitants of Jerusalem.

Isaiah 8:15 And many among them shall stumble, and fall, and be broken, and be snared, and be taken.

Isaiah 8:16 Bind up the testimony, seal the law among my disciples.

Isaiah 8:17 And I will wait upon the Lord, that hideth his face from the house of Jacob, and I will look for him.

Isaiah 8:18 Behold, I and the children whom the Lord hath given me are for signs and for wonders in Israel from the Lord of hosts, which dwelleth in mount Zion.

Isaiah 8:19 And when they shall say unto you, Seek unto them that have familiar spirits, and unto wizards that peep, and that mutter: should not a people seek unto their God? for the living to the dead?

Isaiah 8:20 To the law and to the testimony: if they speak not according to this word, it is because there is no light in them.

Isaiah 8:21 And they shall pass through it, hardly bestead and hungry: and it shall come to pass, that when they shall be hungry, they shall fret themselves, and curse their king and their God, and look upward.

Isaiah 8:22 And they shall look unto the earth; and behold trouble and darkness, dimness of anguish; and they shall be driven to darkness.
