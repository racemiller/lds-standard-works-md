# 2 Kings 23

2 Kings 23 (summary): Josiah reads the book of the covenant to the people—They covenant to keep the commandments—Josiah overturns the worship of false gods, removes the sodomites, and puts down idolatry—Idolatrous priests are slain—Judah holds a solemn Passover—Egypt subjects the land of Judah.

2 Kings 23:1 And the king sent, and they gathered unto him all the elders of Judah and of Jerusalem.

2 Kings 23:2 And the king went up into the house of the Lord, and all the men of Judah and all the inhabitants of Jerusalem with him, and the priests, and the prophets, and all the people, both small and great: and he read in their ears all the words of the book of the covenant which was found in the house of the Lord.

2 Kings 23:3 And the king stood by a pillar, and made a covenant before the Lord, to walk after the Lord, and to keep his commandments and his testimonies and his statutes with all their heart and all their soul, to perform the words of this covenant that were written in this book. And all the people stood to the covenant.

2 Kings 23:4 And the king commanded Hilkiah the high priest, and the priests of the second order, and the keepers of the door, to bring forth out of the temple of the Lord all the vessels that were made for Baal, and for the grove, and for all the host of heaven: and he burned them without Jerusalem in the fields of Kidron, and carried the ashes of them unto Beth-el.

2 Kings 23:5 And he put down the idolatrous priests, whom the kings of Judah had ordained to burn incense in the high places in the cities of Judah, and in the places round about Jerusalem; them also that burned incense unto Baal, to the sun, and to the moon, and to the planets, and to all the host of heaven.

2 Kings 23:6 And he brought out the grove from the house of the Lord, without Jerusalem, unto the brook Kidron, and burned it at the brook Kidron, and stamped it small to powder, and cast the powder thereof upon the graves of the children of the people.

2 Kings 23:7 And he brake down the houses of the sodomites, that were by the house of the Lord, where the women wove hangings for the grove.

2 Kings 23:8 And he brought all the priests out of the cities of Judah, and defiled the high places where the priests had burned incense, from Geba to Beer-sheba, and brake down the high places of the gates that were in the entering in of the gate of Joshua the governor of the city, which were on a man’s left hand at the gate of the city.

2 Kings 23:9 Nevertheless the priests of the high places came not up to the altar of the Lord in Jerusalem, but they did eat of the unleavened bread among their brethren.

2 Kings 23:10 And he defiled Topheth, which is in the valley of the children of Hinnom, that no man might make his son or his daughter to pass through the fire to Molech.

2 Kings 23:11 And he took away the horses that the kings of Judah had given to the sun, at the entering in of the house of the Lord, by the chamber of Nathan-melech the chamberlain, which was in the suburbs, and burned the chariots of the sun with fire.

2 Kings 23:12 And the altars that were on the top of the upper chamber of Ahaz, which the kings of Judah had made, and the altars which Manasseh had made in the two courts of the house of the Lord, did the king beat down, and brake them down from thence, and cast the dust of them into the brook Kidron.

2 Kings 23:13 And the high places that were before Jerusalem, which were on the right hand of the mount of corruption, which Solomon the king of Israel had builded for Ashtoreth the abomination of the Zidonians, and for Chemosh the abomination of the Moabites, and for Milcom the abomination of the children of Ammon, did the king defile.

2 Kings 23:14 And he brake in pieces the images, and cut down the groves, and filled their places with the bones of men.

2 Kings 23:15 Moreover the altar that was at Beth-el, and the high place which Jeroboam the son of Nebat, who made Israel to sin, had made, both that altar and the high place he brake down, and burned the high place, and stamped it small to powder, and burned the grove.

2 Kings 23:16 And as Josiah turned himself, he spied the sepulchres that were there in the mount, and sent, and took the bones out of the sepulchres, and burned them upon the altar, and polluted it, according to the word of the Lord which the man of God proclaimed, who proclaimed these words.

2 Kings 23:17 Then he said, What title is that that I see? And the men of the city told him, It is the sepulchre of the man of God, which came from Judah, and proclaimed these things that thou hast done against the altar of Beth-el.

2 Kings 23:18 And he said, Let him alone; let no man move his bones. So they let his bones alone, with the bones of the prophet that came out of Samaria.

2 Kings 23:19 And all the houses also of the high places that were in the cities of Samaria, which the kings of Israel had made to provoke the Lord to anger, Josiah took away, and did to them according to all the acts that he had done in Beth-el.

2 Kings 23:20 And he slew all the priests of the high places that were there upon the altars, and burned men’s bones upon them, and returned to Jerusalem.

2 Kings 23:21 And the king commanded all the people, saying, Keep the passover unto the Lord your God, as it is written in the book of this covenant.

2 Kings 23:22 Surely there was not holden such a passover from the days of the judges that judged Israel, nor in all the days of the kings of Israel, nor of the kings of Judah;

2 Kings 23:23 But in the eighteenth year of king Josiah, wherein this passover was holden to the Lord in Jerusalem.

2 Kings 23:24 Moreover the workers with familiar spirits, and the wizards, and the images, and the idols, and all the abominations that were spied in the land of Judah and in Jerusalem, did Josiah put away, that he might perform the words of the law which were written in the book that Hilkiah the priest found in the house of the Lord.

2 Kings 23:25 And like unto him was there no king before him, that turned to the Lord with all his heart, and with all his soul, and with all his might, according to all the law of Moses; neither after him arose there any like him.

2 Kings 23:26 Notwithstanding the Lord turned not from the fierceness of his great wrath, wherewith his anger was kindled against Judah, because of all the provocations that Manasseh had provoked him withal.

2 Kings 23:27 And the Lord said, I will remove Judah also out of my sight, as I have removed Israel, and will cast off this city Jerusalem which I have chosen, and the house of which I said, My name shall be there.

2 Kings 23:28 Now the rest of the acts of Josiah, and all that he did, are they not written in the book of the chronicles of the kings of Judah?

2 Kings 23:29 In his days Pharaoh-nechoh king of Egypt went up against the king of Assyria to the river Euphrates: and king Josiah went against him; and he slew him at Megiddo, when he had seen him.

2 Kings 23:30 And his servants carried him in a chariot dead from Megiddo, and brought him to Jerusalem, and buried him in his own sepulchre. And the people of the land took Jehoahaz the son of Josiah, and anointed him, and made him king in his father’s stead.

2 Kings 23:31 Jehoahaz was twenty and three years old when he began to reign; and he reigned three months in Jerusalem. And his mother’s name was Hamutal, the daughter of Jeremiah of Libnah.

2 Kings 23:32 And he did that which was evil in the sight of the Lord, according to all that his fathers had done.

2 Kings 23:33 And Pharaoh-nechoh put him in bands at Riblah in the land of Hamath, that he might not reign in Jerusalem; and put the land to a tribute of an hundred talents of silver, and a talent of gold.

2 Kings 23:34 And Pharaoh-nechoh made Eliakim the son of Josiah king in the room of Josiah his father, and turned his name to Jehoiakim, and took Jehoahaz away: and he came to Egypt, and died there.

2 Kings 23:35 And Jehoiakim gave the silver and the gold to Pharaoh; but he taxed the land to give the money according to the commandment of Pharaoh: he exacted the silver and the gold of the people of the land, of every one according to his taxation, to give it unto Pharaoh-nechoh.

2 Kings 23:36 Jehoiakim was twenty and five years old when he began to reign; and he reigned eleven years in Jerusalem. And his mother’s name was Zebudah, the daughter of Pedaiah of Rumah.

2 Kings 23:37 And he did that which was evil in the sight of the Lord, according to all that his fathers had done.
