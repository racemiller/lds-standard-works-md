# Exodus 31

Exodus 31 (summary): Artisans are inspired in building and furnishing the tabernacle—Israel is commanded to keep the Lord’s Sabbaths—The death penalty is decreed for Sabbath desecration—Moses receives the stone tablets.

Exodus 31:1 And the Lord spake unto Moses, saying,

Exodus 31:2 See, I have called by name Bezaleel the son of Uri, the son of Hur, of the tribe of Judah:

Exodus 31:3 And I have filled him with the spirit of God, in wisdom, and in understanding, and in knowledge, and in all manner of workmanship,

Exodus 31:4 To devise cunning works, to work in gold, and in silver, and in brass,

Exodus 31:5 And in cutting of stones, to set them, and in carving of timber, to work in all manner of workmanship.

Exodus 31:6 And I, behold, I have given with him Aholiab, the son of Ahisamach, of the tribe of Dan: and in the hearts of all that are wise hearted I have put wisdom, that they may make all that I have commanded thee;

Exodus 31:7 The tabernacle of the congregation, and the ark of the testimony, and the mercy seat that is thereupon, and all the furniture of the tabernacle,

Exodus 31:8 And the table and his furniture, and the pure candlestick with all his furniture, and the altar of incense,

Exodus 31:9 And the altar of burnt offering with all his furniture, and the laver and his foot,

Exodus 31:10 And the cloths of service, and the holy garments for Aaron the priest, and the garments of his sons, to minister in the priest’s office,

Exodus 31:11 And the anointing oil, and sweet incense for the holy place: according to all that I have commanded thee shall they do.

Exodus 31:12 And the Lord spake unto Moses, saying,

Exodus 31:13 Speak thou also unto the children of Israel, saying, Verily my sabbaths ye shall keep: for it is a sign between me and you throughout your generations; that ye may know that I am the Lord that doth sanctify you.

Exodus 31:14 Ye shall keep the sabbath therefore; for it is holy unto you: every one that defileth it shall surely be put to death: for whosoever doeth any work therein, that soul shall be cut off from among his people.

Exodus 31:15 Six days may work be done; but in the seventh is the sabbath of rest, holy to the Lord: whosoever doeth any work in the sabbath day, he shall surely be put to death.

Exodus 31:16 Wherefore the children of Israel shall keep the sabbath, to observe the sabbath throughout their generations, for a perpetual covenant.

Exodus 31:17 It is a sign between me and the children of Israel for ever: for in six days the Lord made heaven and earth, and on the seventh day he rested, and was refreshed.

Exodus 31:18 And he gave unto Moses, when he had made an end of communing with him upon mount Sinai, two tables of testimony, tables of stone, written with the finger of God.
