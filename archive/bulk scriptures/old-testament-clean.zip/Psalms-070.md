# Psalms 70

Psalms 70 (summary): David proclaims, Let God be magnified.

Psalms 70:1 Make haste, O God, to deliver me; make haste to help me, O Lord.

Psalms 70:2 Let them be ashamed and confounded that seek after my soul: let them be turned backward, and put to confusion, that desire my hurt.

Psalms 70:3 Let them be turned back for a reward of their shame that say, Aha, aha.

Psalms 70:4 Let all those that seek thee rejoice and be glad in thee: and let such as love thy salvation say continually, Let God be magnified.

Psalms 70:5 But I am poor and needy: make haste unto me, O God: thou art my help and my deliverer; O Lord, make no tarrying.
