# Jeremiah 35

Jeremiah 35 (summary): The Rechabites are commended and blessed for their obedience.

Jeremiah 35:1 The word which came unto Jeremiah from the Lord in the days of Jehoiakim the son of Josiah king of Judah, saying,

Jeremiah 35:2 Go unto the house of the Rechabites, and speak unto them, and bring them into the house of the Lord, into one of the chambers, and give them wine to drink.

Jeremiah 35:3 Then I took Jaazaniah the son of Jeremiah, the son of Habaziniah, and his brethren, and all his sons, and the whole house of the Rechabites;

Jeremiah 35:4 And I brought them into the house of the Lord, into the chamber of the sons of Hanan, the son of Igdaliah, a man of God, which was by the chamber of the princes, which was above the chamber of Maaseiah the son of Shallum, the keeper of the door:

Jeremiah 35:5 And I set before the sons of the house of the Rechabites pots full of wine, and cups, and I said unto them, Drink ye wine.

Jeremiah 35:6 But they said, We will drink no wine: for Jonadab the son of Rechab our father commanded us, saying, Ye shall drink no wine, neither ye, nor your sons for ever:

Jeremiah 35:7 Neither shall ye build house, nor sow seed, nor plant vineyard, nor have any: but all your days ye shall dwell in tents; that ye may live many days in the land where ye be strangers.

Jeremiah 35:8 Thus have we obeyed the voice of Jonadab the son of Rechab our father in all that he hath charged us, to drink no wine all our days, we, our wives, our sons, nor our daughters;

Jeremiah 35:9 Nor to build houses for us to dwell in: neither have we vineyard, nor field, nor seed:

Jeremiah 35:10 But we have dwelt in tents, and have obeyed, and done according to all that Jonadab our father commanded us.

Jeremiah 35:11 But it came to pass, when Nebuchadrezzar king of Babylon came up into the land, that we said, Come, and let us go to Jerusalem for fear of the army of the Chaldeans, and for fear of the army of the Syrians: so we dwell at Jerusalem.

Jeremiah 35:12 Then came the word of the Lord unto Jeremiah, saying,

Jeremiah 35:13 Thus saith the Lord of hosts, the God of Israel; Go and tell the men of Judah and the inhabitants of Jerusalem, Will ye not receive instruction to hearken to my words? saith the Lord.

Jeremiah 35:14 The words of Jonadab the son of Rechab, that he commanded his sons not to drink wine, are performed; for unto this day they drink none, but obey their father’s commandment: notwithstanding I have spoken unto you, rising early and speaking; but ye hearkened not unto me.

Jeremiah 35:15 I have sent also unto you all my servants the prophets, rising up early and sending them, saying, Return ye now every man from his evil way, and amend your doings, and go not after other gods to serve them, and ye shall dwell in the land which I have given to you and to your fathers: but ye have not inclined your ear, nor hearkened unto me.

Jeremiah 35:16 Because the sons of Jonadab the son of Rechab have performed the commandment of their father, which he commanded them; but this people hath not hearkened unto me:

Jeremiah 35:17 Therefore thus saith the Lord God of hosts, the God of Israel; Behold, I will bring upon Judah and upon all the inhabitants of Jerusalem all the evil that I have pronounced against them: because I have spoken unto them, but they have not heard; and I have called unto them, but they have not answered.

Jeremiah 35:18 And Jeremiah said unto the house of the Rechabites, Thus saith the Lord of hosts, the God of Israel; Because ye have obeyed the commandment of Jonadab your father, and kept all his precepts, and done according unto all that he hath commanded you:

Jeremiah 35:19 Therefore thus saith the Lord of hosts, the God of Israel; Jonadab the son of Rechab shall not want a man to stand before me for ever.
