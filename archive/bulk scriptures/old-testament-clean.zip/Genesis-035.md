# Genesis 35

Genesis 35 (summary): God sends Jacob to Bethel, where he builds an altar and the Lord appears to him—God renews the promise that Jacob will be a great nation and that his name will be Israel—Jacob sets up an altar and pours a drink offering—Rachel bears Benjamin, dies in childbirth, and is buried near Bethlehem—Reuben sins with Bilhah—Isaac dies and is buried by Jacob and Esau.

Genesis 35:1 And God said unto Jacob, Arise, go up to Beth-el, and dwell there: and make there an altar unto God, that appeared unto thee when thou fleddest from the face of Esau thy brother.

Genesis 35:2 Then Jacob said unto his household, and to all that were with him, Put away the strange gods that are among you, and be clean, and change your garments:

Genesis 35:3 And let us arise, and go up to Beth-el; and I will make there an altar unto God, who answered me in the day of my distress, and was with me in the way which I went.

Genesis 35:4 And they gave unto Jacob all the strange gods which were in their hand, and all their earrings which were in their ears; and Jacob hid them under the oak which was by Shechem.

Genesis 35:5 And they journeyed: and the terror of God was upon the cities that were round about them, and they did not pursue after the sons of Jacob.

Genesis 35:6 So Jacob came to Luz, which is in the land of Canaan, that is, Beth-el, he and all the people that were with him.

Genesis 35:7 And he built there an altar, and called the place El-beth-el: because there God appeared unto him, when he fled from the face of his brother.

Genesis 35:8 But Deborah Rebekah’s nurse died, and she was buried beneath Beth-el under an oak: and the name of it was called Allon-bachuth.

Genesis 35:9 And God appeared unto Jacob again, when he came out of Padan-aram, and blessed him.

Genesis 35:10 And God said unto him, Thy name is Jacob: thy name shall not be called any more Jacob, but Israel shall be thy name: and he called his name Israel.

Genesis 35:11 And God said unto him, I am God Almighty: be fruitful and multiply; a nation and a company of nations shall be of thee, and kings shall come out of thy loins;

Genesis 35:12 And the land which I gave Abraham and Isaac, to thee I will give it, and to thy seed after thee will I give the land.

Genesis 35:13 And God went up from him in the place where he talked with him.

Genesis 35:14 And Jacob set up a pillar in the place where he talked with him, even a pillar of stone: and he poured a drink offering thereon, and he poured oil thereon.

Genesis 35:15 And Jacob called the name of the place where God spake with him, Beth-el.

Genesis 35:16 And they journeyed from Beth-el; and there was but a little way to come to Ephrath: and Rachel travailed, and she had hard labour.

Genesis 35:17 And it came to pass, when she was in hard labour, that the midwife said unto her, Fear not; thou shalt have this son also.

Genesis 35:18 And it came to pass, as her soul was in departing, (for she died) that she called his name Ben-oni: but his father called him Benjamin.

Genesis 35:19 And Rachel died, and was buried in the way to Ephrath, which is Beth-lehem.

Genesis 35:20 And Jacob set a pillar upon her grave: that is the pillar of Rachel’s grave unto this day.

Genesis 35:21 And Israel journeyed, and spread his tent beyond the tower of Edar.

Genesis 35:22 And it came to pass, when Israel dwelt in that land, that Reuben went and lay with Bilhah his father’s concubine: and Israel heard it. Now the sons of Jacob were twelve:

Genesis 35:23 The sons of Leah; Reuben, Jacob’s firstborn, and Simeon, and Levi, and Judah, and Issachar, and Zebulun:

Genesis 35:24 The sons of Rachel; Joseph, and Benjamin:

Genesis 35:25 And the sons of Bilhah, Rachel’s handmaid; Dan, and Naphtali:

Genesis 35:26 And the sons of Zilpah, Leah’s handmaid; Gad, and Asher: these are the sons of Jacob, which were born to him in Padan-aram.

Genesis 35:27 And Jacob came unto Isaac his father unto Mamre, unto the city of Arbah, which is Hebron, where Abraham and Isaac sojourned.

Genesis 35:28 And the days of Isaac were an hundred and fourscore years.

Genesis 35:29 And Isaac gave up the ghost, and died, and was gathered unto his people, being old and full of days: and his sons Esau and Jacob buried him.
