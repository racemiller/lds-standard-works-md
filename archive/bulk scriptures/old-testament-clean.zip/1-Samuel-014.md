# 1 Samuel 14

1 Samuel 14 (summary): Jonathan smites the garrison of the Philistines—Saul instructs the people to eat no food until evening—Unaware of the oath, Jonathan eats, and Saul decrees his death—He is rescued by the people—Saul vexes his enemies on every hand.

1 Samuel 14:1 Now it came to pass upon a day, that Jonathan the son of Saul said unto the young man that bare his armour, Come, and let us go over to the Philistines’ garrison, that is on the other side. But he told not his father.

1 Samuel 14:2 And Saul tarried in the uttermost part of Gibeah under a pomegranate tree which is in Migron: and the people that were with him were about six hundred men;

1 Samuel 14:3 And Ahiah, the son of Ahitub, I-chabod’s brother, the son of Phinehas, the son of Eli, the Lord’s priest in Shiloh, wearing an ephod. And the people knew not that Jonathan was gone.

1 Samuel 14:4 And between the passages, by which Jonathan sought to go over unto the Philistines’ garrison, there was a sharp rock on the one side, and a sharp rock on the other side: and the name of the one was Bozez, and the name of the other Seneh.

1 Samuel 14:5 The forefront of the one was situate northward over against Michmash, and the other southward over against Gibeah.

1 Samuel 14:6 And Jonathan said to the young man that bare his armour, Come, and let us go over unto the garrison of these uncircumcised: it may be that the Lord will work for us: for there is no restraint to the Lord to save by many or by few.

1 Samuel 14:7 And his armourbearer said unto him, Do all that is in thine heart: turn thee; behold, I am with thee according to thy heart.

1 Samuel 14:8 Then said Jonathan, Behold, we will pass over unto these men, and we will discover ourselves unto them.

1 Samuel 14:9 If they say thus unto us, Tarry until we come to you; then we will stand still in our place, and will not go up unto them.

1 Samuel 14:10 But if they say thus, Come up unto us; then we will go up: for the Lord hath delivered them into our hand: and this shall be a sign unto us.

1 Samuel 14:11 And both of them discovered themselves unto the garrison of the Philistines: and the Philistines said, Behold, the Hebrews come forth out of the holes where they had hid themselves.

1 Samuel 14:12 And the men of the garrison answered Jonathan and his armourbearer, and said, Come up to us, and we will shew you a thing. And Jonathan said unto his armourbearer, Come up after me: for the Lord hath delivered them into the hand of Israel.

1 Samuel 14:13 And Jonathan climbed up upon his hands and upon his feet, and his armourbearer after him: and they fell before Jonathan; and his armourbearer slew after him.

1 Samuel 14:14 And that first slaughter, which Jonathan and his armourbearer made, was about twenty men, within as it were an half acre of land, which a yoke of oxen might plow.

1 Samuel 14:15 And there was trembling in the host, in the field, and among all the people: the garrison, and the spoilers, they also trembled, and the earth quaked: so it was a very great trembling.

1 Samuel 14:16 And the watchmen of Saul in Gibeah of Benjamin looked; and, behold, the multitude melted away, and they went on beating down one another.

1 Samuel 14:17 Then said Saul unto the people that were with him, Number now, and see who is gone from us. And when they had numbered, behold, Jonathan and his armourbearer were not there.

1 Samuel 14:18 And Saul said unto Ahiah, Bring hither the ark of God. For the ark of God was at that time with the children of Israel.

1 Samuel 14:19 And it came to pass, while Saul talked unto the priest, that the noise that was in the host of the Philistines went on and increased: and Saul said unto the priest, Withdraw thine hand.

1 Samuel 14:20 And Saul and all the people that were with him assembled themselves, and they came to the battle: and, behold, every man’s sword was against his fellow, and there was a very great discomfiture.

1 Samuel 14:21 Moreover the Hebrews that were with the Philistines before that time, which went up with them into the camp from the country round about, even they also turned to be with the Israelites that were with Saul and Jonathan.

1 Samuel 14:22 Likewise all the men of Israel which had hid themselves in mount Ephraim, when they heard that the Philistines fled, even they also followed hard after them in the battle.

1 Samuel 14:23 So the Lord saved Israel that day: and the battle passed over unto Beth-aven.

1 Samuel 14:24 And the men of Israel were distressed that day: for Saul had adjured the people, saying, Cursed be the man that eateth any food until evening, that I may be avenged on mine enemies. So none of the people tasted any food.

1 Samuel 14:25 And all they of the land came to a wood; and there was honey upon the ground.

1 Samuel 14:26 And when the people were come into the wood, behold, the honey dropped; but no man put his hand to his mouth: for the people feared the oath.

1 Samuel 14:27 But Jonathan heard not when his father charged the people with the oath: wherefore he put forth the end of the rod that was in his hand, and dipped it in an honeycomb, and put his hand to his mouth; and his eyes were enlightened.

1 Samuel 14:28 Then answered one of the people, and said, Thy father straitly charged the people with an oath, saying, Cursed be the man that eateth any food this day. And the people were faint.

1 Samuel 14:29 Then said Jonathan, My father hath troubled the land: see, I pray you, how mine eyes have been enlightened, because I tasted a little of this honey.

1 Samuel 14:30 How much more, if haply the people had eaten freely to day of the spoil of their enemies which they found? for had there not been now a much greater slaughter among the Philistines?

1 Samuel 14:31 And they smote the Philistines that day from Michmash to Aijalon: and the people were very faint.

1 Samuel 14:32 And the people flew upon the spoil, and took sheep, and oxen, and calves, and slew them on the ground: and the people did eat them with the blood.

1 Samuel 14:33 Then they told Saul, saying, Behold, the people sin against the Lord, in that they eat with the blood. And he said, Ye have transgressed: roll a great stone unto me this day.

1 Samuel 14:34 And Saul said, Disperse yourselves among the people, and say unto them, Bring me hither every man his ox, and every man his sheep, and slay them here, and eat; and sin not against the Lord in eating with the blood. And all the people brought every man his ox with him that night, and slew them there.

1 Samuel 14:35 And Saul built an altar unto the Lord: the same was the first altar that he built unto the Lord.

1 Samuel 14:36 And Saul said, Let us go down after the Philistines by night, and spoil them until the morning light, and let us not leave a man of them. And they said, Do whatsoever seemeth good unto thee. Then said the priest, Let us draw near hither unto God.

1 Samuel 14:37 And Saul asked counsel of God, Shall I go down after the Philistines? wilt thou deliver them into the hand of Israel? But he answered him not that day.

1 Samuel 14:38 And Saul said, Draw ye near hither, all the chief of the people: and know and see wherein this sin hath been this day.

1 Samuel 14:39 For, as the Lord liveth, which saveth Israel, though it be in Jonathan my son, he shall surely die. But there was not a man among all the people that answered him.

1 Samuel 14:40 Then said he unto all Israel, Be ye on one side, and I and Jonathan my son will be on the other side. And the people said unto Saul, Do what seemeth good unto thee.

1 Samuel 14:41 Therefore Saul said unto the Lord God of Israel, Give a perfect lot. And Saul and Jonathan were taken: but the people escaped.

1 Samuel 14:42 And Saul said, Cast lots between me and Jonathan my son. And Jonathan was taken.

1 Samuel 14:43 Then Saul said to Jonathan, Tell me what thou hast done. And Jonathan told him, and said, I did but taste a little honey with the end of the rod that was in mine hand, and, lo, I must die.

1 Samuel 14:44 And Saul answered, God do so and more also: for thou shalt surely die, Jonathan.

1 Samuel 14:45 And the people said unto Saul, Shall Jonathan die, who hath wrought this great salvation in Israel? God forbid: as the Lord liveth, there shall not one hair of his head fall to the ground; for he hath wrought with God this day. So the people rescued Jonathan, that he died not.

1 Samuel 14:46 Then Saul went up from following the Philistines: and the Philistines went to their own place.

1 Samuel 14:47 So Saul took the kingdom over Israel, and fought against all his enemies on every side, against Moab, and against the children of Ammon, and against Edom, and against the kings of Zobah, and against the Philistines: and whithersoever he turned himself, he vexed them.

1 Samuel 14:48 And he gathered an host, and smote the Amalekites, and delivered Israel out of the hands of them that spoiled them.

1 Samuel 14:49 Now the sons of Saul were Jonathan, and Ishui, and Melchi-shua: and the names of his two daughters were these; the name of the firstborn Merab, and the name of the younger Michal:

1 Samuel 14:50 And the name of Saul’s wife was Ahinoam, the daughter of Ahimaaz: and the name of the captain of his host was Abner, the son of Ner, Saul’s uncle.

1 Samuel 14:51 And Kish was the father of Saul; and Ner the father of Abner was the son of Abiel.

1 Samuel 14:52 And there was sore war against the Philistines all the days of Saul: and when Saul saw any strong man, or any valiant man, he took him unto him.
