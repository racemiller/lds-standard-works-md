# 1 Chronicles 21

1 Chronicles 21 (summary): David sins by numbering Israel—The Lord sends pestilence upon the people—David offers sacrifices and the plague is stayed.

1 Chronicles 21:1 And Satan stood up against Israel, and provoked David to number Israel.

1 Chronicles 21:2 And David said to Joab and to the rulers of the people, Go, number Israel from Beer-sheba even to Dan; and bring the number of them to me, that I may know it.

1 Chronicles 21:3 And Joab answered, The Lord make his people an hundred times so many more as they be: but, my lord the king, are they not all my lord’s servants? why then doth my lord require this thing? why will he be a cause of trespass to Israel?

1 Chronicles 21:4 Nevertheless the king’s word prevailed against Joab. Wherefore Joab departed, and went throughout all Israel, and came to Jerusalem.

1 Chronicles 21:5 And Joab gave the sum of the number of the people unto David. And all they of Israel were a thousand thousand and an hundred thousand men that drew sword: and Judah was four hundred threescore and ten thousand men that drew sword.

1 Chronicles 21:6 But Levi and Benjamin counted he not among them: for the king’s word was abominable to Joab.

1 Chronicles 21:7 And God was displeased with this thing; therefore he smote Israel.

1 Chronicles 21:8 And David said unto God, I have sinned greatly, because I have done this thing: but now, I beseech thee, do away the iniquity of thy servant; for I have done very foolishly.

1 Chronicles 21:9 And the Lord spake unto Gad, David’s seer, saying,

1 Chronicles 21:10 Go and tell David, saying, Thus saith the Lord, I offer thee three things: choose thee one of them, that I may do it unto thee.

1 Chronicles 21:11 So Gad came to David, and said unto him, Thus saith the Lord, Choose thee

1 Chronicles 21:12 Either three years’ famine; or three months to be destroyed before thy foes, while that the sword of thine enemies overtaketh thee; or else three days the sword of the Lord, even the pestilence, in the land, and the angel of the Lord destroying throughout all the coasts of Israel. Now therefore advise thyself what word I shall bring again to him that sent me.

1 Chronicles 21:13 And David said unto Gad, I am in a great strait: let me fall now into the hand of the Lord; for very great are his mercies: but let me not fall into the hand of man.

1 Chronicles 21:14 So the Lord sent pestilence upon Israel: and there fell of Israel seventy thousand men.

1 Chronicles 21:15 And God sent an angel unto Jerusalem to destroy it: and as he was destroying, the Lord beheld, and he repented him of the evil, and said to the angel that destroyed, It is enough, stay now thine hand. And the angel of the Lord stood by the threshingfloor of Ornan the Jebusite.

1 Chronicles 21:16 And David lifted up his eyes, and saw the angel of the Lord stand between the earth and the heaven, having a drawn sword in his hand stretched out over Jerusalem. Then David and the elders of Israel, who were clothed in sackcloth, fell upon their faces.

1 Chronicles 21:17 And David said unto God, Is it not I that commanded the people to be numbered? even I it is that have sinned and done evil indeed; but as for these sheep, what have they done? let thine hand, I pray thee, O Lord my God, be on me, and on my father’s house; but not on thy people, that they should be plagued.

1 Chronicles 21:18 Then the angel of the Lord commanded Gad to say to David, that David should go up, and set up an altar unto the Lord in the threshingfloor of Ornan the Jebusite.

1 Chronicles 21:19 And David went up at the saying of Gad, which he spake in the name of the Lord.

1 Chronicles 21:20 And Ornan turned back, and saw the angel; and his four sons with him hid themselves. Now Ornan was threshing wheat.

1 Chronicles 21:21 And as David came to Ornan, Ornan looked and saw David, and went out of the threshingfloor, and bowed himself to David with his face to the ground.

1 Chronicles 21:22 Then David said to Ornan, Grant me the place of this threshingfloor, that I may build an altar therein unto the Lord: thou shalt grant it me for the full price: that the plague may be stayed from the people.

1 Chronicles 21:23 And Ornan said unto David, Take it to thee, and let my lord the king do that which is good in his eyes: lo, I give thee the oxen also for burnt offerings, and the threshing instruments for wood, and the wheat for the meat offering; I give it all.

1 Chronicles 21:24 And king David said to Ornan, Nay; but I will verily buy it for the full price: for I will not take that which is thine for the Lord, nor offer burnt offerings without cost.

1 Chronicles 21:25 So David gave to Ornan for the place six hundred shekels of gold by weight.

1 Chronicles 21:26 And David built there an altar unto the Lord, and offered burnt offerings and peace offerings, and called upon the Lord; and he answered him from heaven by fire upon the altar of burnt offering.

1 Chronicles 21:27 And the Lord commanded the angel; and he put up his sword again into the sheath thereof.

1 Chronicles 21:28 At that time when David saw that the Lord had answered him in the threshingfloor of Ornan the Jebusite, then he sacrificed there.

1 Chronicles 21:29 For the tabernacle of the Lord, which Moses made in the wilderness, and the altar of the burnt offering, were at that season in the high place at Gibeon.

1 Chronicles 21:30 But David could not go before it to inquire of God: for he was afraid because of the sword of the angel of the Lord.
