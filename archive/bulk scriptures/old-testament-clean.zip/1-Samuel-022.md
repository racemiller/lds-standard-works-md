# 1 Samuel 22

1 Samuel 22 (summary): David gains followers—He goes from one place to another, fleeing from Saul—Saul slays the priests who showed kindness to David.

1 Samuel 22:1 David therefore departed thence, and escaped to the cave Adullam: and when his brethren and all his father’s house heard it, they went down thither to him.

1 Samuel 22:2 And every one that was in distress, and every one that was in debt, and every one that was discontented, gathered themselves unto him; and he became a captain over them: and there were with him about four hundred men.

1 Samuel 22:3 And David went thence to Mizpeh of Moab: and he said unto the king of Moab, Let my father and my mother, I pray thee, come forth, and be with you, till I know what God will do for me.

1 Samuel 22:4 And he brought them before the king of Moab: and they dwelt with him all the while that David was in the hold.

1 Samuel 22:5 And the prophet Gad said unto David, Abide not in the hold; depart, and get thee into the land of Judah. Then David departed, and came into the forest of Hareth.

1 Samuel 22:6 When Saul heard that David was discovered, and the men that were with him, (now Saul abode in Gibeah under a tree in Ramah, having his spear in his hand, and all his servants were standing about him;)

1 Samuel 22:7 Then Saul said unto his servants that stood about him, Hear now, ye Benjamites; will the son of Jesse give every one of you fields and vineyards, and make you all captains of thousands, and captains of hundreds;

1 Samuel 22:8 That all of you have conspired against me, and there is none that sheweth me that my son hath made a league with the son of Jesse, and there is none of you that is sorry for me, or sheweth unto me that my son hath stirred up my servant against me, to lie in wait, as at this day?

1 Samuel 22:9 Then answered Doeg the Edomite, which was set over the servants of Saul, and said, I saw the son of Jesse coming to Nob, to Ahimelech the son of Ahitub.

1 Samuel 22:10 And he inquired of the Lord for him, and gave him victuals, and gave him the sword of Goliath the Philistine.

1 Samuel 22:11 Then the king sent to call Ahimelech the priest, the son of Ahitub, and all his father’s house, the priests that were in Nob: and they came all of them to the king.

1 Samuel 22:12 And Saul said, Hear now, thou son of Ahitub. And he answered, Here I am, my lord.

1 Samuel 22:13 And Saul said unto him, Why have ye conspired against me, thou and the son of Jesse, in that thou hast given him bread, and a sword, and hast inquired of God for him, that he should rise against me, to lie in wait, as at this day?

1 Samuel 22:14 Then Ahimelech answered the king, and said, And who is so faithful among all thy servants as David, which is the king’s son in law, and goeth at thy bidding, and is honourable in thine house?

1 Samuel 22:15 Did I then begin to inquire of God for him? be it far from me: let not the king impute any thing unto his servant, nor to all the house of my father: for thy servant knew nothing of all this, less or more.

1 Samuel 22:16 And the king said, Thou shalt surely die, Ahimelech, thou, and all thy father’s house.

1 Samuel 22:17 And the king said unto the footmen that stood about him, Turn, and slay the priests of the Lord; because their hand also is with David, and because they knew when he fled, and did not shew it to me. But the servants of the king would not put forth their hand to fall upon the priests of the Lord.

1 Samuel 22:18 And the king said to Doeg, Turn thou, and fall upon the priests. And Doeg the Edomite turned, and he fell upon the priests, and slew on that day fourscore and five persons that did wear a linen ephod.

1 Samuel 22:19 And Nob, the city of the priests, smote he with the edge of the sword, both men and women, children and sucklings, and oxen, and asses, and sheep, with the edge of the sword.

1 Samuel 22:20 And one of the sons of Ahimelech the son of Ahitub, named Abiathar, escaped, and fled after David.

1 Samuel 22:21 And Abiathar shewed David that Saul had slain the Lord’s priests.

1 Samuel 22:22 And David said unto Abiathar, I knew it that day, when Doeg the Edomite was there, that he would surely tell Saul: I have occasioned the death of all the persons of thy father’s house.

1 Samuel 22:23 Abide thou with me, fear not: for he that seeketh my life seeketh thy life: but with me thou shalt be in safeguard.
