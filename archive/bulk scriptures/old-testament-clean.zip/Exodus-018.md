# Exodus 18

Exodus 18 (summary): Jethro comes to Moses bringing Moses’ wife and sons and offers sacrifices to the Lord—Moses sits in the judgment seat and hears all cases—Jethro counsels Moses to teach the law, to appoint lesser judges, and to delegate power to them.

Exodus 18:1 When Jethro, the priest of Midian, Moses’ father in law, heard of all that God had done for Moses, and for Israel his people, and that the Lord had brought Israel out of Egypt;

Exodus 18:2 Then Jethro, Moses’ father in law, took Zipporah, Moses’ wife, after he had sent her back,

Exodus 18:3 And her two sons; of which the name of the one was Gershom; for he said, I have been an alien in a strange land:

Exodus 18:4 And the name of the other was Eliezer; for the God of my father, said he, was mine help, and delivered me from the sword of Pharaoh:

Exodus 18:5 And Jethro, Moses’ father in law, came with his sons and his wife unto Moses into the wilderness, where he encamped at the mount of God:

Exodus 18:6 And he said unto Moses, I thy father in law Jethro am come unto thee, and thy wife, and her two sons with her.

Exodus 18:7 And Moses went out to meet his father in law, and did obeisance, and kissed him; and they asked each other of their welfare; and they came into the tent.

Exodus 18:8 And Moses told his father in law all that the Lord had done unto Pharaoh and to the Egyptians for Israel’s sake, and all the travail that had come upon them by the way, and how the Lord delivered them.

Exodus 18:9 And Jethro rejoiced for all the goodness which the Lord had done to Israel, whom he had delivered out of the hand of the Egyptians.

Exodus 18:10 And Jethro said, Blessed be the Lord, who hath delivered you out of the hand of the Egyptians, and out of the hand of Pharaoh, who hath delivered the people from under the hand of the Egyptians.

Exodus 18:11 Now I know that the Lord is greater than all gods: for in the thing wherein they dealt proudly he was above them.

Exodus 18:12 And Jethro, Moses’ father in law, took a burnt offering and sacrifices for God: and Aaron came, and all the elders of Israel, to eat bread with Moses’ father in law before God.

Exodus 18:13 And it came to pass on the morrow, that Moses sat to judge the people: and the people stood by Moses from the morning unto the evening.

Exodus 18:14 And when Moses’ father in law saw all that he did to the people, he said, What is this thing that thou doest to the people? why sittest thou thyself alone, and all the people stand by thee from morning unto even?

Exodus 18:15 And Moses said unto his father in law, Because the people come unto me to inquire of God:

Exodus 18:16 When they have a matter, they come unto me; and I judge between one and another, and I do make them know the statutes of God, and his laws.

Exodus 18:17 And Moses’ father in law said unto him, The thing that thou doest is not good.

Exodus 18:18 Thou wilt surely wear away, both thou, and this people that is with thee: for this thing is too heavy for thee; thou art not able to perform it thyself alone.

Exodus 18:19 Hearken now unto my voice, I will give thee counsel, and God shall be with thee: Be thou for the people to God-ward, that thou mayest bring the causes unto God:

Exodus 18:20 And thou shalt teach them ordinances and laws, and shalt shew them the way wherein they must walk, and the work that they must do.

Exodus 18:21 Moreover thou shalt provide out of all the people able men, such as fear God, men of truth, hating covetousness; and place such over them, to be rulers of thousands, and rulers of hundreds, rulers of fifties, and rulers of tens:

Exodus 18:22 And let them judge the people at all seasons: and it shall be, that every great matter they shall bring unto thee, but every small matter they shall judge: so shall it be easier for thyself, and they shall bear the burden with thee.

Exodus 18:23 If thou shalt do this thing, and God command thee so, then thou shalt be able to endure, and all this people shall also go to their place in peace.

Exodus 18:24 So Moses hearkened to the voice of his father in law, and did all that he had said.

Exodus 18:25 And Moses chose able men out of all Israel, and made them heads over the people, rulers of thousands, rulers of hundreds, rulers of fifties, and rulers of tens.

Exodus 18:26 And they judged the people at all seasons: the hard causes they brought unto Moses, but every small matter they judged themselves.

Exodus 18:27 And Moses let his father in law depart; and he went his way into his own land.
