# 2 Samuel 18

2 Samuel 18 (summary): The Israelites are smitten in the woods of Ephraim—Joab slays Absalom—Tidings of his death are taken to David, who mourns for his son.

2 Samuel 18:1 And David numbered the people that were with him, and set captains of thousands and captains of hundreds over them.

2 Samuel 18:2 And David sent forth a third part of the people under the hand of Joab, and a third part under the hand of Abishai the son of Zeruiah, Joab’s brother, and a third part under the hand of Ittai the Gittite. And the king said unto the people, I will surely go forth with you myself also.

2 Samuel 18:3 But the people answered, Thou shalt not go forth: for if we flee away, they will not care for us; neither if half of us die, will they care for us: but now thou art worth ten thousand of us: therefore now it is better that thou succour us out of the city.

2 Samuel 18:4 And the king said unto them, What seemeth you best I will do. And the king stood by the gate side, and all the people came out by hundreds and by thousands.

2 Samuel 18:5 And the king commanded Joab and Abishai and Ittai, saying, Deal gently for my sake with the young man, even with Absalom. And all the people heard when the king gave all the captains charge concerning Absalom.

2 Samuel 18:6 So the people went out into the field against Israel: and the battle was in the wood of Ephraim;

2 Samuel 18:7 Where the people of Israel were slain before the servants of David, and there was there a great slaughter that day of twenty thousand men.

2 Samuel 18:8 For the battle was there scattered over the face of all the country: and the wood devoured more people that day than the sword devoured.

2 Samuel 18:9 And Absalom met the servants of David. And Absalom rode upon a mule, and the mule went under the thick boughs of a great oak, and his head caught hold of the oak, and he was taken up between the heaven and the earth; and the mule that was under him went away.

2 Samuel 18:10 And a certain man saw it, and told Joab, and said, Behold, I saw Absalom hanged in an oak.

2 Samuel 18:11 And Joab said unto the man that told him, And, behold, thou sawest him, and why didst thou not smite him there to the ground? and I would have given thee ten shekels of silver, and a girdle.

2 Samuel 18:12 And the man said unto Joab, Though I should receive a thousand shekels of silver in mine hand, yet would I not put forth mine hand against the king’s son: for in our hearing the king charged thee and Abishai and Ittai, saying, Beware that none touch the young man Absalom.

2 Samuel 18:13 Otherwise I should have wrought falsehood against mine own life: for there is no matter hid from the king, and thou thyself wouldest have set thyself against me.

2 Samuel 18:14 Then said Joab, I may not tarry thus with thee. And he took three darts in his hand, and thrust them through the heart of Absalom, while he was yet alive in the midst of the oak.

2 Samuel 18:15 And ten young men that bare Joab’s armour compassed about and smote Absalom, and slew him.

2 Samuel 18:16 And Joab blew the trumpet, and the people returned from pursuing after Israel: for Joab held back the people.

2 Samuel 18:17 And they took Absalom, and cast him into a great pit in the wood, and laid a very great heap of stones upon him: and all Israel fled every one to his tent.

2 Samuel 18:18 Now Absalom in his lifetime had taken and reared up for himself a pillar, which is in the king’s dale: for he said, I have no son to keep my name in remembrance: and he called the pillar after his own name: and it is called unto this day, Absalom’s place.

2 Samuel 18:19 Then said Ahimaaz the son of Zadok, Let me now run, and bear the king tidings, how that the Lord hath avenged him of his enemies.

2 Samuel 18:20 And Joab said unto him, Thou shalt not bear tidings this day, but thou shalt bear tidings another day: but this day thou shalt bear no tidings, because the king’s son is dead.

2 Samuel 18:21 Then said Joab to Cushi, Go tell the king what thou hast seen. And Cushi bowed himself unto Joab, and ran.

2 Samuel 18:22 Then said Ahimaaz the son of Zadok yet again to Joab, But howsoever, let me, I pray thee, also run after Cushi. And Joab said, Wherefore wilt thou run, my son, seeing that thou hast no tidings ready?

2 Samuel 18:23 But howsoever, said he, let me run. And he said unto him, Run. Then Ahimaaz ran by the way of the plain, and overran Cushi.

2 Samuel 18:24 And David sat between the two gates: and the watchman went up to the roof over the gate unto the wall, and lifted up his eyes, and looked, and behold a man running alone.

2 Samuel 18:25 And the watchman cried, and told the king. And the king said, If he be alone, there is tidings in his mouth. And he came apace, and drew near.

2 Samuel 18:26 And the watchman saw another man running: and the watchman called unto the porter, and said, Behold another man running alone. And the king said, He also bringeth tidings.

2 Samuel 18:27 And the watchman said, Me thinketh the running of the foremost is like the running of Ahimaaz the son of Zadok. And the king said, He is a good man, and cometh with good tidings.

2 Samuel 18:28 And Ahimaaz called, and said unto the king, All is well. And he fell down to the earth upon his face before the king, and said, Blessed be the Lord thy God, which hath delivered up the men that lifted up their hand against my lord the king.

2 Samuel 18:29 And the king said, Is the young man Absalom safe? And Ahimaaz answered, When Joab sent the king’s servant, and me thy servant, I saw a great tumult, but I knew not what it was.

2 Samuel 18:30 And the king said unto him, Turn aside, and stand here. And he turned aside, and stood still.

2 Samuel 18:31 And, behold, Cushi came; and Cushi said, Tidings, my lord the king: for the Lord hath avenged thee this day of all them that rose up against thee.

2 Samuel 18:32 And the king said unto Cushi, Is the young man Absalom safe? And Cushi answered, The enemies of my lord the king, and all that rise against thee to do thee hurt, be as that young man is.

2 Samuel 18:33 And the king was much moved, and went up to the chamber over the gate, and wept: and as he went, thus he said, O my son Absalom, my son, my son Absalom! would God I had died for thee, O Absalom, my son, my son!
