# Genesis 14

Genesis 14 (summary): Lot is captured in the battles of the kings—He is rescued by Abram—Melchizedek administers bread and wine and blesses Abram—Abram pays tithes—He declines to accept the spoils of conquest.

Genesis 14:1 And it came to pass in the days of Amraphel king of Shinar, Arioch king of Ellasar, Chedorlaomer king of Elam, and Tidal king of nations;

Genesis 14:2 That these made war with Bera king of Sodom, and with Birsha king of Gomorrah, Shinab king of Admah, and Shemeber king of Zeboiim, and the king of Bela, which is Zoar.

Genesis 14:3 All these were joined together in the vale of Siddim, which is the salt sea.

Genesis 14:4 Twelve years they served Chedorlaomer, and in the thirteenth year they rebelled.

Genesis 14:5 And in the fourteenth year came Chedorlaomer, and the kings that were with him, and smote the Rephaims in Ashteroth Karnaim, and the Zuzims in Ham, and the Emims in Shaveh Kiriathaim,

Genesis 14:6 And the Horites in their mount Seir, unto El-paran, which is by the wilderness.

Genesis 14:7 And they returned, and came to En-mishpat, which is Kadesh, and smote all the country of the Amalekites, and also the Amorites, that dwelt in Hazezon-tamar.

Genesis 14:8 And there went out the king of Sodom, and the king of Gomorrah, and the king of Admah, and the king of Zeboiim, and the king of Bela (the same is Zoar;) and they joined battle with them in the vale of Siddim;

Genesis 14:9 With Chedorlaomer the king of Elam, and with Tidal king of nations, and Amraphel king of Shinar, and Arioch king of Ellasar; four kings with five.

Genesis 14:10 And the vale of Siddim was full of slimepits; and the kings of Sodom and Gomorrah fled, and fell there; and they that remained fled to the mountain.

Genesis 14:11 And they took all the goods of Sodom and Gomorrah, and all their victuals, and went their way.

Genesis 14:12 And they took Lot, Abram’s brother’s son, who dwelt in Sodom, and his goods, and departed.

Genesis 14:13 And there came one that had escaped, and told Abram the Hebrew; for he dwelt in the plain of Mamre the Amorite, brother of Eshcol, and brother of Aner: and these were confederate with Abram.

Genesis 14:14 And when Abram heard that his brother was taken captive, he armed his trained servants, born in his own house, three hundred and eighteen, and pursued them unto Dan.

Genesis 14:15 And he divided himself against them, he and his servants, by night, and smote them, and pursued them unto Hobah, which is on the left hand of Damascus.

Genesis 14:16 And he brought back all the goods, and also brought again his brother Lot, and his goods, and the women also, and the people.

Genesis 14:17 And the king of Sodom went out to meet him after his return from the slaughter of Chedorlaomer, and of the kings that were with him, at the valley of Shaveh, which is the king’s dale.

Genesis 14:18 And Melchizedek king of Salem brought forth bread and wine: and he was the priest of the most high God.

Genesis 14:19 And he blessed him, and said, Blessed be Abram of the most high God, possessor of heaven and earth:

Genesis 14:20 And blessed be the most high God, which hath delivered thine enemies into thy hand. And he gave him tithes of all.

Genesis 14:21 And the king of Sodom said unto Abram, Give me the persons, and take the goods to thyself.

Genesis 14:22 And Abram said to the king of Sodom, I have lift up mine hand unto the Lord, the most high God, the possessor of heaven and earth,

Genesis 14:23 That I will not take from a thread even to a shoelatchet, and that I will not take any thing that is thine, lest thou shouldest say, I have made Abram rich:

Genesis 14:24 Save only that which the young men have eaten, and the portion of the men which went with me, Aner, Eshcol, and Mamre; let them take their portion.
