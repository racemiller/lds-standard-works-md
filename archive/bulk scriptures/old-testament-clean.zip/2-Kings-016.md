# 2 Kings 16

2 Kings 16 (summary): Ahaz reigns in wickedness in Judah—He offers his son in heathen sacrifice—He makes a new altar, destroys the brazen sea, and changes the method for sacrificing in the temple.

2 Kings 16:1 In the seventeenth year of Pekah the son of Remaliah Ahaz the son of Jotham king of Judah began to reign.

2 Kings 16:2 Twenty years old was Ahaz when he began to reign, and reigned sixteen years in Jerusalem, and did not that which was right in the sight of the Lord his God, like David his father.

2 Kings 16:3 But he walked in the way of the kings of Israel, yea, and made his son to pass through the fire, according to the abominations of the heathen, whom the Lord cast out from before the children of Israel.

2 Kings 16:4 And he sacrificed and burnt incense in the high places, and on the hills, and under every green tree.

2 Kings 16:5 Then Rezin king of Syria and Pekah son of Remaliah king of Israel came up to Jerusalem to war: and they besieged Ahaz, but could not overcome him.

2 Kings 16:6 At that time Rezin king of Syria recovered Elath to Syria, and drave the Jews from Elath: and the Syrians came to Elath, and dwelt there unto this day.

2 Kings 16:7 So Ahaz sent messengers to Tiglath-pileser king of Assyria, saying, I am thy servant and thy son: come up, and save me out of the hand of the king of Syria, and out of the hand of the king of Israel, which rise up against me.

2 Kings 16:8 And Ahaz took the silver and gold that was found in the house of the Lord, and in the treasures of the king’s house, and sent it for a present to the king of Assyria.

2 Kings 16:9 And the king of Assyria hearkened unto him: for the king of Assyria went up against Damascus, and took it, and carried the people of it captive to Kir, and slew Rezin.

2 Kings 16:10 And king Ahaz went to Damascus to meet Tiglath-pileser king of Assyria, and saw an altar that was at Damascus: and king Ahaz sent to Urijah the priest the fashion of the altar, and the pattern of it, according to all the workmanship thereof.

2 Kings 16:11 And Urijah the priest built an altar according to all that king Ahaz had sent from Damascus: so Urijah the priest made it against king Ahaz came from Damascus.

2 Kings 16:12 And when the king was come from Damascus, the king saw the altar: and the king approached to the altar, and offered thereon.

2 Kings 16:13 And he burnt his burnt offering and his meat offering, and poured his drink offering, and sprinkled the blood of his peace offerings, upon the altar.

2 Kings 16:14 And he brought also the brasen altar, which was before the Lord, from the forefront of the house, from between the altar and the house of the Lord, and put it on the north side of the altar.

2 Kings 16:15 And king Ahaz commanded Urijah the priest, saying, Upon the great altar burn the morning burnt offering, and the evening meat offering, and the king’s burnt sacrifice, and his meat offering, with the burnt offering of all the people of the land, and their meat offering, and their drink offerings; and sprinkle upon it all the blood of the burnt offering, and all the blood of the sacrifice: and the brasen altar shall be for me to inquire by.

2 Kings 16:16 Thus did Urijah the priest, according to all that king Ahaz commanded.

2 Kings 16:17 And king Ahaz cut off the borders of the bases, and removed the laver from off them; and took down the sea from off the brasen oxen that were under it, and put it upon a pavement of stones.

2 Kings 16:18 And the covert for the sabbath that they had built in the house, and the king’s entry without, turned he from the house of the Lord for the king of Assyria.

2 Kings 16:19 Now the rest of the acts of Ahaz which he did, are they not written in the book of the chronicles of the kings of Judah?

2 Kings 16:20 And Ahaz slept with his fathers, and was buried with his fathers in the city of David: and Hezekiah his son reigned in his stead.
