# Psalms 5

Psalms 5 (summary): David asks the Lord to hear his voice—The Lord hates workers of iniquity—He blesses and shields the righteous.

Psalms 5:1 Give ear to my words, O Lord, consider my meditation.

Psalms 5:2 Hearken unto the voice of my cry, my King, and my God: for unto thee will I pray.

Psalms 5:3 My voice shalt thou hear in the morning, O Lord; in the morning will I direct my prayer unto thee, and will look up.

Psalms 5:4 For thou art not a God that hath pleasure in wickedness: neither shall evil dwell with thee.

Psalms 5:5 The foolish shall not stand in thy sight: thou hatest all workers of iniquity.

Psalms 5:6 Thou shalt destroy them that speak leasing: the Lord will abhor the bloody and deceitful man.

Psalms 5:7 But as for me, I will come into thy house in the multitude of thy mercy: and in thy fear will I worship toward thy holy temple.

Psalms 5:8 Lead me, O Lord, in thy righteousness because of mine enemies; make thy way straight before my face.

Psalms 5:9 For there is no faithfulness in their mouth; their inward part is very wickedness; their throat is an open sepulchre; they flatter with their tongue.

Psalms 5:10 Destroy thou them, O God; let them fall by their own counsels; cast them out in the multitude of their transgressions; for they have rebelled against thee.

Psalms 5:11 But let all those that put their trust in thee rejoice: let them ever shout for joy, because thou defendest them: let them also that love thy name be joyful in thee.

Psalms 5:12 For thou, Lord, wilt bless the righteous; with favour wilt thou compass him as with a shield.
