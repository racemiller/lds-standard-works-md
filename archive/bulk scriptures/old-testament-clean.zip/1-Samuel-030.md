# 1 Samuel 30

1 Samuel 30 (summary): The Amalekites spoil Ziklag and the borders of Judah—David smites Amalek and regains and divides the spoil.

1 Samuel 30:1 And it came to pass, when David and his men were come to Ziklag on the third day, that the Amalekites had invaded the south, and Ziklag, and smitten Ziklag, and burned it with fire;

1 Samuel 30:2 And had taken the women captives, that were therein: they slew not any, either great or small, but carried them away, and went on their way.

1 Samuel 30:3 So David and his men came to the city, and, behold, it was burned with fire; and their wives, and their sons, and their daughters, were taken captives.

1 Samuel 30:4 Then David and the people that were with him lifted up their voice and wept, until they had no more power to weep.

1 Samuel 30:5 And David’s two wives were taken captives, Ahinoam the Jezreelitess, and Abigail the wife of Nabal the Carmelite.

1 Samuel 30:6 And David was greatly distressed; for the people spake of stoning him, because the soul of all the people was grieved, every man for his sons and for his daughters: but David encouraged himself in the Lord his God.

1 Samuel 30:7 And David said to Abiathar the priest, Ahimelech’s son, I pray thee, bring me hither the ephod. And Abiathar brought thither the ephod to David.

1 Samuel 30:8 And David inquired at the Lord, saying, Shall I pursue after this troop? shall I overtake them? And he answered him, Pursue: for thou shalt surely overtake them, and without fail recover all.

1 Samuel 30:9 So David went, he and the six hundred men that were with him, and came to the brook Besor, where those that were left behind stayed.

1 Samuel 30:10 But David pursued, he and four hundred men: for two hundred abode behind, which were so faint that they could not go over the brook Besor.

1 Samuel 30:11 And they found an Egyptian in the field, and brought him to David, and gave him bread, and he did eat; and they made him drink water;

1 Samuel 30:12 And they gave him a piece of a cake of figs, and two clusters of raisins: and when he had eaten, his spirit came again to him: for he had eaten no bread, nor drunk any water, three days and three nights.

1 Samuel 30:13 And David said unto him, To whom belongest thou? and whence art thou? And he said, I am a young man of Egypt, servant to an Amalekite; and my master left me, because three days agone I fell sick.

1 Samuel 30:14 We made an invasion upon the south of the Cherethites, and upon the coast which belongeth to Judah, and upon the south of Caleb; and we burned Ziklag with fire.

1 Samuel 30:15 And David said to him, Canst thou bring me down to this company? And he said, Swear unto me by God, that thou wilt neither kill me, nor deliver me into the hands of my master, and I will bring thee down to this company.

1 Samuel 30:16 And when he had brought him down, behold, they were spread abroad upon all the earth, eating and drinking, and dancing, because of all the great spoil that they had taken out of the land of the Philistines, and out of the land of Judah.

1 Samuel 30:17 And David smote them from the twilight even unto the evening of the next day: and there escaped not a man of them, save four hundred young men, which rode upon camels, and fled.

1 Samuel 30:18 And David recovered all that the Amalekites had carried away: and David rescued his two wives.

1 Samuel 30:19 And there was nothing lacking to them, neither small nor great, neither sons nor daughters, neither spoil, nor any thing that they had taken to them: David recovered all.

1 Samuel 30:20 And David took all the flocks and the herds, which they drave before those other cattle, and said, This is David’s spoil.

1 Samuel 30:21 And David came to the two hundred men, which were so faint that they could not follow David, whom they had made also to abide at the brook Besor: and they went forth to meet David, and to meet the people that were with him: and when David came near to the people, he saluted them.

1 Samuel 30:22 Then answered all the wicked men and men of Belial, of those that went with David, and said, Because they went not with us, we will not give them ought of the spoil that we have recovered, save to every man his wife and his children, that they may lead them away, and depart.

1 Samuel 30:23 Then said David, Ye shall not do so, my brethren, with that which the Lord hath given us, who hath preserved us, and delivered the company that came against us into our hand.

1 Samuel 30:24 For who will hearken unto you in this matter? but as his part is that goeth down to the battle, so shall his part be that tarrieth by the stuff: they shall part alike.

1 Samuel 30:25 And it was so from that day forward, that he made it a statute and an ordinance for Israel unto this day.

1 Samuel 30:26 And when David came to Ziklag, he sent of the spoil unto the elders of Judah, even to his friends, saying, Behold a present for you of the spoil of the enemies of the Lord;

1 Samuel 30:27 To them which were in Beth-el, and to them which were in south Ramoth, and to them which were in Jattir,

1 Samuel 30:28 And to them which were in Aroer, and to them which were in Siphmoth, and to them which were in Eshtemoa,

1 Samuel 30:29 And to them which were in Rachal, and to them which were in the cities of the Jerahmeelites, and to them which were in the cities of the Kenites,

1 Samuel 30:30 And to them which were in Hormah, and to them which were in Chor-ashan, and to them which were in Athach,

1 Samuel 30:31 And to them which were in Hebron, and to all the places where David himself and his men were wont to haunt.
