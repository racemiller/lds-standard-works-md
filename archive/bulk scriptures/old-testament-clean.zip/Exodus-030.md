# Exodus 30

Exodus 30 (summary): An altar of incense is to be placed before the veil—Atonement is to be made with the blood of the sin offering—Atonement money is to be paid to ransom each male—Priests are to use holy anointing oil and perfume.

Exodus 30:1 And thou shalt make an altar to burn incense upon: of shittim wood shalt thou make it.

Exodus 30:2 A cubit shall be the length thereof, and a cubit the breadth thereof; foursquare shall it be: and two cubits shall be the height thereof: the horns thereof shall be of the same.

Exodus 30:3 And thou shalt overlay it with pure gold, the top thereof, and the sides thereof round about, and the horns thereof; and thou shalt make unto it a crown of gold round about.

Exodus 30:4 And two golden rings shalt thou make to it under the crown of it, by the two corners thereof, upon the two sides of it shalt thou make it; and they shall be for places for the staves to bear it withal.

Exodus 30:5 And thou shalt make the staves of shittim wood, and overlay them with gold.

Exodus 30:6 And thou shalt put it before the veil that is by the ark of the testimony, before the mercy seat that is over the testimony, where I will meet with thee.

Exodus 30:7 And Aaron shall burn thereon sweet incense every morning: when he dresseth the lamps, he shall burn incense upon it.

Exodus 30:8 And when Aaron lighteth the lamps at even, he shall burn incense upon it, a perpetual incense before the Lord throughout your generations.

Exodus 30:9 Ye shall offer no strange incense thereon, nor burnt sacrifice, nor meat offering; neither shall ye pour drink offering thereon.

Exodus 30:10 And Aaron shall make an atonement upon the horns of it once in a year with the blood of the sin offering of atonements: once in the year shall he make atonement upon it throughout your generations: it is most holy unto the Lord.

Exodus 30:11 And the Lord spake unto Moses, saying,

Exodus 30:12 When thou takest the sum of the children of Israel after their number, then shall they give every man a ransom for his soul unto the Lord, when thou numberest them; that there be no plague among them, when thou numberest them.

Exodus 30:13 This they shall give, every one that passeth among them that are numbered, half a shekel after the shekel of the sanctuary: (a shekel is twenty gerahs:) an half shekel shall be the offering of the Lord.

Exodus 30:14 Every one that passeth among them that are numbered, from twenty years old and above, shall give an offering unto the Lord.

Exodus 30:15 The rich shall not give more, and the poor shall not give less than half a shekel, when they give an offering unto the Lord, to make an atonement for your souls.

Exodus 30:16 And thou shalt take the atonement money of the children of Israel, and shalt appoint it for the service of the tabernacle of the congregation; that it may be a memorial unto the children of Israel before the Lord, to make an atonement for your souls.

Exodus 30:17 And the Lord spake unto Moses, saying,

Exodus 30:18 Thou shalt also make a laver of brass, and his foot also of brass, to wash withal: and thou shalt put it between the tabernacle of the congregation and the altar, and thou shalt put water therein.

Exodus 30:19 For Aaron and his sons shall wash their hands and their feet thereat:

Exodus 30:20 When they go into the tabernacle of the congregation, they shall wash with water, that they die not; or when they come near to the altar to minister, to burn offering made by fire unto the Lord:

Exodus 30:21 So they shall wash their hands and their feet, that they die not: and it shall be a statute for ever to them, even to him and to his seed throughout their generations.

Exodus 30:22 Moreover the Lord spake unto Moses, saying,

Exodus 30:23 Take thou also unto thee principal spices, of pure myrrh five hundred shekels, and of sweet cinnamon half so much, even two hundred and fifty shekels, and of sweet calamus two hundred and fifty shekels,

Exodus 30:24 And of cassia five hundred shekels, after the shekel of the sanctuary, and of oil olive an hin:

Exodus 30:25 And thou shalt make it an oil of holy ointment, an ointment compound after the art of the apothecary: it shall be an holy anointing oil.

Exodus 30:26 And thou shalt anoint the tabernacle of the congregation therewith, and the ark of the testimony,

Exodus 30:27 And the table and all his vessels, and the candlestick and his vessels, and the altar of incense,

Exodus 30:28 And the altar of burnt offering with all his vessels, and the laver and his foot.

Exodus 30:29 And thou shalt sanctify them, that they may be most holy: whatsoever toucheth them shall be holy.

Exodus 30:30 And thou shalt anoint Aaron and his sons, and consecrate them, that they may minister unto me in the priest’s office.

Exodus 30:31 And thou shalt speak unto the children of Israel, saying, This shall be an holy anointing oil unto me throughout your generations.

Exodus 30:32 Upon man’s flesh shall it not be poured, neither shall ye make any other like it, after the composition of it: it is holy, and it shall be holy unto you.

Exodus 30:33 Whosoever compoundeth any like it, or whosoever putteth any of it upon a stranger, shall even be cut off from his people.

Exodus 30:34 And the Lord said unto Moses, Take unto thee sweet spices, stacte, and onycha, and galbanum; these sweet spices with pure frankincense: of each shall there be a like weight:

Exodus 30:35 And thou shalt make it a perfume, a confection after the art of the apothecary, tempered together, pure and holy:

Exodus 30:36 And thou shalt beat some of it very small, and put of it before the testimony in the tabernacle of the congregation, where I will meet with thee: it shall be unto you most holy.

Exodus 30:37 And as for the perfume which thou shalt make, ye shall not make to yourselves according to the composition thereof: it shall be unto thee holy for the Lord.

Exodus 30:38 Whosoever shall make like unto that, to smell thereto, shall even be cut off from his people.
