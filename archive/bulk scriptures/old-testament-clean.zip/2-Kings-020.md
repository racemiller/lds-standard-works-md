# 2 Kings 20

2 Kings 20 (summary): Hezekiah is told he will die and pleads with the Lord; his life is lengthened fifteen years—The shadow goes back ten degrees on the sundial of Ahaz—Isaiah prophesies the Babylonian captivity of Judah.

2 Kings 20:1 In those days was Hezekiah sick unto death. And the prophet Isaiah the son of Amoz came to him, and said unto him, Thus saith the Lord, Set thine house in order; for thou shalt die, and not live.

2 Kings 20:2 Then he turned his face to the wall, and prayed unto the Lord, saying,

2 Kings 20:3 I beseech thee, O Lord, remember now how I have walked before thee in truth and with a perfect heart, and have done that which is good in thy sight. And Hezekiah wept sore.

2 Kings 20:4 And it came to pass, afore Isaiah was gone out into the middle court, that the word of the Lord came to him, saying,

2 Kings 20:5 Turn again, and tell Hezekiah the captain of my people, Thus saith the Lord, the God of David thy father, I have heard thy prayer, I have seen thy tears: behold, I will heal thee: on the third day thou shalt go up unto the house of the Lord.

2 Kings 20:6 And I will add unto thy days fifteen years; and I will deliver thee and this city out of the hand of the king of Assyria; and I will defend this city for mine own sake, and for my servant David’s sake.

2 Kings 20:7 And Isaiah said, Take a lump of figs. And they took and laid it on the boil, and he recovered.

2 Kings 20:8 And Hezekiah said unto Isaiah, What shall be the sign that the Lord will heal me, and that I shall go up into the house of the Lord the third day?

2 Kings 20:9 And Isaiah said, This sign shalt thou have of the Lord, that the Lord will do the thing that he hath spoken: shall the shadow go forward ten degrees, or go back ten degrees?

2 Kings 20:10 And Hezekiah answered, It is a light thing for the shadow to go down ten degrees: nay, but let the shadow return backward ten degrees.

2 Kings 20:11 And Isaiah the prophet cried unto the Lord: and he brought the shadow ten degrees backward, by which it had gone down in the dial of Ahaz.

2 Kings 20:12 At that time Berodach-baladan, the son of Baladan, king of Babylon, sent letters and a present unto Hezekiah: for he had heard that Hezekiah had been sick.

2 Kings 20:13 And Hezekiah hearkened unto them, and shewed them all the house of his precious things, the silver, and the gold, and the spices, and the precious ointment, and all the house of his armour, and all that was found in his treasures: there was nothing in his house, nor in all his dominion, that Hezekiah shewed them not.

2 Kings 20:14 Then came Isaiah the prophet unto king Hezekiah, and said unto him, What said these men? and from whence came they unto thee? And Hezekiah said, They are come from a far country, even from Babylon.

2 Kings 20:15 And he said, What have they seen in thine house? And Hezekiah answered, All the things that are in mine house have they seen: there is nothing among my treasures that I have not shewed them.

2 Kings 20:16 And Isaiah said unto Hezekiah, Hear the word of the Lord.

2 Kings 20:17 Behold, the days come, that all that is in thine house, and that which thy fathers have laid up in store unto this day, shall be carried into Babylon: nothing shall be left, saith the Lord.

2 Kings 20:18 And of thy sons that shall issue from thee, which thou shalt beget, shall they take away; and they shall be eunuchs in the palace of the king of Babylon.

2 Kings 20:19 Then said Hezekiah unto Isaiah, Good is the word of the Lord which thou hast spoken. And he said, Is it not good, if peace and truth be in my days?

2 Kings 20:20 And the rest of the acts of Hezekiah, and all his might, and how he made a pool, and a conduit, and brought water into the city, are they not written in the book of the chronicles of the kings of Judah?

2 Kings 20:21 And Hezekiah slept with his fathers: and Manasseh his son reigned in his stead.
