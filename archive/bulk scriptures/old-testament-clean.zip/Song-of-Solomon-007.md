# Song of Solomon 7

Song of Solomon 7 (summary): The song of love continues.

Song of Solomon 7:1 How beautiful are thy feet with shoes, O prince’s daughter! the joints of thy thighs are like jewels, the work of the hands of a cunning workman.

Song of Solomon 7:2 Thy navel is like a round goblet, which wanteth not liquor: thy belly is like an heap of wheat set about with lilies.

Song of Solomon 7:3 Thy two breasts are like two young roes that are twins.

Song of Solomon 7:4 Thy neck is as a tower of ivory; thine eyes like the fishpools in Heshbon, by the gate of Bath-rabbim: thy nose is as the tower of Lebanon which looketh toward Damascus.

Song of Solomon 7:5 Thine head upon thee is like Carmel, and the hair of thine head like purple; the king is held in the galleries.

Song of Solomon 7:6 How fair and how pleasant art thou, O love, for delights!

Song of Solomon 7:7 This thy stature is like to a palm tree, and thy breasts to clusters of grapes.

Song of Solomon 7:8 I said, I will go up to the palm tree, I will take hold of the boughs thereof: now also thy breasts shall be as clusters of the vine, and the smell of thy nose like apples;

Song of Solomon 7:9 And the roof of thy mouth like the best wine for my beloved, that goeth down sweetly, causing the lips of those that are asleep to speak.

Song of Solomon 7:10 I am my beloved’s, and his desire is toward me.

Song of Solomon 7:11 Come, my beloved, let us go forth into the field; let us lodge in the villages.

Song of Solomon 7:12 Let us get up early to the vineyards; let us see if the vine flourish, whether the tender grape appear, and the pomegranates bud forth: there will I give thee my loves.

Song of Solomon 7:13 The mandrakes give a smell, and at our gates are all manner of pleasant fruits, new and old, which I have laid up for thee, O my beloved.
