# 1 Chronicles 1

1 Chronicles 1 (summary): The genealogies and family ties from Adam to Abraham are given—The posterity of Abraham is listed.

1 Chronicles 1:1 Adam, Sheth, Enosh,

1 Chronicles 1:2 Kenan, Mahalaleel, Jered,

1 Chronicles 1:3 Henoch, Methuselah, Lamech,

1 Chronicles 1:4 Noah, Shem, Ham, and Japheth.

1 Chronicles 1:5 The sons of Japheth; Gomer, and Magog, and Madai, and Javan, and Tubal, and Meshech, and Tiras.

1 Chronicles 1:6 And the sons of Gomer; Ashchenaz, and Riphath, and Togarmah.

1 Chronicles 1:7 And the sons of Javan; Elishah, and Tarshish, Kittim, and Dodanim.

1 Chronicles 1:8 The sons of Ham; Cush, and Mizraim, Put, and Canaan.

1 Chronicles 1:9 And the sons of Cush; Seba, and Havilah, and Sabta, and Raamah, and Sabtecha. And the sons of Raamah; Sheba, and Dedan.

1 Chronicles 1:10 And Cush begat Nimrod: he began to be mighty upon the earth.

1 Chronicles 1:11 And Mizraim begat Ludim, and Anamim, and Lehabim, and Naphtuhim,

1 Chronicles 1:12 And Pathrusim, and Casluhim, (of whom came the Philistines,) and Caphthorim.

1 Chronicles 1:13 And Canaan begat Zidon his firstborn, and Heth,

1 Chronicles 1:14 The Jebusite also, and the Amorite, and the Girgashite,

1 Chronicles 1:15 And the Hivite, and the Arkite, and the Sinite,

1 Chronicles 1:16 And the Arvadite, and the Zemarite, and the Hamathite.

1 Chronicles 1:17 The sons of Shem; Elam, and Asshur, and Arphaxad, and Lud, and Aram, and Uz, and Hul, and Gether, and Meshech.

1 Chronicles 1:18 And Arphaxad begat Shelah, and Shelah begat Eber.

1 Chronicles 1:19 And unto Eber were born two sons: the name of the one was Peleg; because in his days the earth was divided: and his brother’s name was Joktan.

1 Chronicles 1:20 And Joktan begat Almodad, and Sheleph, and Hazarmaveth, and Jerah,

1 Chronicles 1:21 Hadoram also, and Uzal, and Diklah,

1 Chronicles 1:22 And Ebal, and Abimael, and Sheba,

1 Chronicles 1:23 And Ophir, and Havilah, and Jobab. All these were the sons of Joktan.

1 Chronicles 1:24 Shem, Arphaxad, Shelah,

1 Chronicles 1:25 Eber, Peleg, Reu,

1 Chronicles 1:26 Serug, Nahor, Terah,

1 Chronicles 1:27 Abram; the same is Abraham.

1 Chronicles 1:28 The sons of Abraham; Isaac, and Ishmael.

1 Chronicles 1:29 These are their generations: The firstborn of Ishmael, Nebaioth; then Kedar, and Adbeel, and Mibsam,

1 Chronicles 1:30 Mishma, and Dumah, Massa, Hadad, and Tema,

1 Chronicles 1:31 Jetur, Naphish, and Kedemah. These are the sons of Ishmael.

1 Chronicles 1:32 Now the sons of Keturah, Abraham’s concubine: she bare Zimran, and Jokshan, and Medan, and Midian, and Ishbak, and Shuah. And the sons of Jokshan; Sheba, and Dedan.

1 Chronicles 1:33 And the sons of Midian; Ephah, and Epher, and Henoch, and Abida, and Eldaah. All these are the sons of Keturah.

1 Chronicles 1:34 And Abraham begat Isaac. The sons of Isaac; Esau and Israel.

1 Chronicles 1:35 The sons of Esau; Eliphaz, Reuel, and Jeush, and Jaalam, and Korah.

1 Chronicles 1:36 The sons of Eliphaz; Teman, and Omar, Zephi, and Gatam, Kenaz, and Timna, and Amalek.

1 Chronicles 1:37 The sons of Reuel; Nahath, Zerah, Shammah, and Mizzah.

1 Chronicles 1:38 And the sons of Seir; Lotan, and Shobal, and Zibeon, and Anah, and Dishon, and Ezer, and Dishan.

1 Chronicles 1:39 And the sons of Lotan; Hori, and Homam: and Timna was Lotan’s sister.

1 Chronicles 1:40 The sons of Shobal; Alian, and Manahath, and Ebal, Shephi, and Onam. And the sons of Zibeon; Aiah, and Anah.

1 Chronicles 1:41 The sons of Anah; Dishon. And the sons of Dishon; Amram, and Eshban, and Ithran, and Cheran.

1 Chronicles 1:42 The sons of Ezer; Bilhan, and Zavan, and Jakan. The sons of Dishan; Uz, and Aran.

1 Chronicles 1:43 Now these are the kings that reigned in the land of Edom before any king reigned over the children of Israel; Bela the son of Beor: and the name of his city was Dinhabah.

1 Chronicles 1:44 And when Bela was dead, Jobab the son of Zerah of Bozrah reigned in his stead.

1 Chronicles 1:45 And when Jobab was dead, Husham of the land of the Temanites reigned in his stead.

1 Chronicles 1:46 And when Husham was dead, Hadad the son of Bedad, which smote Midian in the field of Moab, reigned in his stead: and the name of his city was Avith.

1 Chronicles 1:47 And when Hadad was dead, Samlah of Masrekah reigned in his stead.

1 Chronicles 1:48 And when Samlah was dead, Shaul of Rehoboth by the river reigned in his stead.

1 Chronicles 1:49 And when Shaul was dead, Baal-hanan the son of Achbor reigned in his stead.

1 Chronicles 1:50 And when Baal-hanan was dead, Hadad reigned in his stead: and the name of his city was Pai; and his wife’s name was Mehetabel, the daughter of Matred, the daughter of Mezahab.

1 Chronicles 1:51 Hadad died also. And the dukes of Edom were; duke Timnah, duke Aliah, duke Jetheth,

1 Chronicles 1:52 Duke Aholibamah, duke Elah, duke Pinon,

1 Chronicles 1:53 Duke Kenaz, duke Teman, duke Mibzar,

1 Chronicles 1:54 Duke Magdiel, duke Iram. These are the dukes of Edom.
