# Jeremiah 34

Jeremiah 34 (summary): Jeremiah prophesies the captivity of Zedekiah—The people of Judah will be removed into all the kingdoms of the earth.

Jeremiah 34:1 The word which came unto Jeremiah from the Lord, when Nebuchadnezzar king of Babylon, and all his army, and all the kingdoms of the earth of his dominion, and all the people, fought against Jerusalem, and against all the cities thereof, saying,

Jeremiah 34:2 Thus saith the Lord, the God of Israel; Go and speak to Zedekiah king of Judah, and tell him, Thus saith the Lord; Behold, I will give this city into the hand of the king of Babylon, and he shall burn it with fire:

Jeremiah 34:3 And thou shalt not escape out of his hand, but shalt surely be taken, and delivered into his hand; and thine eyes shall behold the eyes of the king of Babylon, and he shall speak with thee mouth to mouth, and thou shalt go to Babylon.

Jeremiah 34:4 Yet hear the word of the Lord, O Zedekiah king of Judah; Thus saith the Lord of thee, Thou shalt not die by the sword:

Jeremiah 34:5 But thou shalt die in peace: and with the burnings of thy fathers, the former kings which were before thee, so shall they burn odours for thee; and they will lament thee, saying, Ah lord! for I have pronounced the word, saith the Lord.

Jeremiah 34:6 Then Jeremiah the prophet spake all these words unto Zedekiah king of Judah in Jerusalem,

Jeremiah 34:7 When the king of Babylon’s army fought against Jerusalem, and against all the cities of Judah that were left, against Lachish, and against Azekah: for these defenced cities remained of the cities of Judah.

Jeremiah 34:8 This is the word that came unto Jeremiah from the Lord, after that the king Zedekiah had made a covenant with all the people which were at Jerusalem, to proclaim liberty unto them;

Jeremiah 34:9 That every man should let his manservant, and every man his maidservant, being an Hebrew or an Hebrewess, go free; that none should serve himself of them, to wit, of a Jew his brother.

Jeremiah 34:10 Now when all the princes, and all the people, which had entered into the covenant, heard that every one should let his manservant, and every one his maidservant, go free, that none should serve themselves of them any more, then they obeyed, and let them go.

Jeremiah 34:11 But afterward they turned, and caused the servants and the handmaids, whom they had let go free, to return, and brought them into subjection for servants and for handmaids.

Jeremiah 34:12 Therefore the word of the Lord came to Jeremiah from the Lord, saying,

Jeremiah 34:13 Thus saith the Lord, the God of Israel; I made a covenant with your fathers in the day that I brought them forth out of the land of Egypt, out of the house of bondmen, saying,

Jeremiah 34:14 At the end of seven years let ye go every man his brother an Hebrew, which hath been sold unto thee; and when he hath served thee six years, thou shalt let him go free from thee: but your fathers hearkened not unto me, neither inclined their ear.

Jeremiah 34:15 And ye were now turned, and had done right in my sight, in proclaiming liberty every man to his neighbour; and ye had made a covenant before me in the house which is called by my name:

Jeremiah 34:16 But ye turned and polluted my name, and caused every man his servant, and every man his handmaid, whom ye had set at liberty at their pleasure, to return, and brought them into subjection, to be unto you for servants and for handmaids.

Jeremiah 34:17 Therefore thus saith the Lord; Ye have not hearkened unto me, in proclaiming liberty, every one to his brother, and every man to his neighbour: behold, I proclaim a liberty for you, saith the Lord, to the sword, to the pestilence, and to the famine; and I will make you to be removed into all the kingdoms of the earth.

Jeremiah 34:18 And I will give the men that have transgressed my covenant, which have not performed the words of the covenant which they had made before me, when they cut the calf in twain, and passed between the parts thereof,

Jeremiah 34:19 The princes of Judah, and the princes of Jerusalem, the eunuchs, and the priests, and all the people of the land, which passed between the parts of the calf;

Jeremiah 34:20 I will even give them into the hand of their enemies, and into the hand of them that seek their life: and their dead bodies shall be for meat unto the fowls of the heaven, and to the beasts of the earth.

Jeremiah 34:21 And Zedekiah king of Judah and his princes will I give into the hand of their enemies, and into the hand of them that seek their life, and into the hand of the king of Babylon’s army, which are gone up from you.

Jeremiah 34:22 Behold, I will command, saith the Lord, and cause them to return to this city; and they shall fight against it, and take it, and burn it with fire: and I will make the cities of Judah a desolation without an inhabitant.
