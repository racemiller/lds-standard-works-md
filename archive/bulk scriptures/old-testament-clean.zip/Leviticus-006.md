# Leviticus 6

Leviticus 6 (summary): The people must first make restitution for sin, then offer a trespass offering, and thereby gain forgiveness through atonement made by the priests.

Leviticus 6:1 And the Lord spake unto Moses, saying,

Leviticus 6:2 If a soul sin, and commit a trespass against the Lord, and lie unto his neighbour in that which was delivered him to keep, or in fellowship, or in a thing taken away by violence, or hath deceived his neighbour;

Leviticus 6:3 Or have found that which was lost, and lieth concerning it, and sweareth falsely; in any of all these that a man doeth, sinning therein:

Leviticus 6:4 Then it shall be, because he hath sinned, and is guilty, that he shall restore that which he took violently away, or the thing which he hath deceitfully gotten, or that which was delivered him to keep, or the lost thing which he found,

Leviticus 6:5 Or all that about which he hath sworn falsely; he shall even restore it in the principal, and shall add the fifth part more thereto, and give it unto him to whom it appertaineth, in the day of his trespass offering.

Leviticus 6:6 And he shall bring his trespass offering unto the Lord, a ram without blemish out of the flock, with thy estimation, for a trespass offering, unto the priest:

Leviticus 6:7 And the priest shall make an atonement for him before the Lord: and it shall be forgiven him for any thing of all that he hath done in trespassing therein.

Leviticus 6:8 And the Lord spake unto Moses, saying,

Leviticus 6:9 Command Aaron and his sons, saying, This is the law of the burnt offering: It is the burnt offering, because of the burning upon the altar all night unto the morning, and the fire of the altar shall be burning in it.

Leviticus 6:10 And the priest shall put on his linen garment, and his linen breeches shall he put upon his flesh, and take up the ashes which the fire hath consumed with the burnt offering on the altar, and he shall put them beside the altar.

Leviticus 6:11 And he shall put off his garments, and put on other garments, and carry forth the ashes without the camp unto a clean place.

Leviticus 6:12 And the fire upon the altar shall be burning in it; it shall not be put out: and the priest shall burn wood on it every morning, and lay the burnt offering in order upon it; and he shall burn thereon the fat of the peace offerings.

Leviticus 6:13 The fire shall ever be burning upon the altar; it shall never go out.

Leviticus 6:14 And this is the law of the meat offering: the sons of Aaron shall offer it before the Lord, before the altar.

Leviticus 6:15 And he shall take of it his handful, of the flour of the meat offering, and of the oil thereof, and all the frankincense which is upon the meat offering, and shall burn it upon the altar for a sweet savour, even the memorial of it, unto the Lord.

Leviticus 6:16 And the remainder thereof shall Aaron and his sons eat: with unleavened bread shall it be eaten in the holy place; in the court of the tabernacle of the congregation they shall eat it.

Leviticus 6:17 It shall not be baken with leaven. I have given it unto them for their portion of my offerings made by fire; it is most holy, as is the sin offering, and as the trespass offering.

Leviticus 6:18 All the males among the children of Aaron shall eat of it. It shall be a statute for ever in your generations concerning the offerings of the Lord made by fire: every one that toucheth them shall be holy.

Leviticus 6:19 And the Lord spake unto Moses, saying,

Leviticus 6:20 This is the offering of Aaron and of his sons, which they shall offer unto the Lord in the day when he is anointed; the tenth part of an ephah of fine flour for a meat offering perpetual, half of it in the morning, and half thereof at night.

Leviticus 6:21 In a pan it shall be made with oil; and when it is baken, thou shalt bring it in: and the baken pieces of the meat offering shalt thou offer for a sweet savour unto the Lord.

Leviticus 6:22 And the priest of his sons that is anointed in his stead shall offer it: it is a statute for ever unto the Lord; it shall be wholly burnt.

Leviticus 6:23 For every meat offering for the priest shall be wholly burnt: it shall not be eaten.

Leviticus 6:24 And the Lord spake unto Moses, saying,

Leviticus 6:25 Speak unto Aaron and to his sons, saying, This is the law of the sin offering: In the place where the burnt offering is killed shall the sin offering be killed before the Lord: it is most holy.

Leviticus 6:26 The priest that offereth it for sin shall eat it: in the holy place shall it be eaten, in the court of the tabernacle of the congregation.

Leviticus 6:27 Whatsoever shall touch the flesh thereof shall be holy: and when there is sprinkled of the blood thereof upon any garment, thou shalt wash that whereon it was sprinkled in the holy place.

Leviticus 6:28 But the earthen vessel wherein it is sodden shall be broken: and if it be sodden in a brasen pot, it shall be both scoured, and rinsed in water.

Leviticus 6:29 All the males among the priests shall eat thereof: it is most holy.

Leviticus 6:30 And no sin offering, whereof any of the blood is brought into the tabernacle of the congregation to reconcile withal in the holy place, shall be eaten: it shall be burnt in the fire.
