# Ezekiel 28

Ezekiel 28 (summary): Tyre and Sidon will fall and be destroyed—The Lord will gather the people of Israel to their own land—They will then dwell safely.

Ezekiel 28:1 The word of the Lord came again unto me, saying,

Ezekiel 28:2 Son of man, say unto the prince of Tyrus, Thus saith the Lord God; Because thine heart is lifted up, and thou hast said, I am a God, I sit in the seat of God, in the midst of the seas; yet thou art a man, and not God, though thou set thine heart as the heart of God:

Ezekiel 28:3 Behold, thou art wiser than Daniel; there is no secret that they can hide from thee:

Ezekiel 28:4 With thy wisdom and with thine understanding thou hast gotten thee riches, and hast gotten gold and silver into thy treasures:

Ezekiel 28:5 By thy great wisdom and by thy traffick hast thou increased thy riches, and thine heart is lifted up because of thy riches:

Ezekiel 28:6 Therefore thus saith the Lord God; Because thou hast set thine heart as the heart of God;

Ezekiel 28:7 Behold, therefore I will bring strangers upon thee, the terrible of the nations: and they shall draw their swords against the beauty of thy wisdom, and they shall defile thy brightness.

Ezekiel 28:8 They shall bring thee down to the pit, and thou shalt die the deaths of them that are slain in the midst of the seas.

Ezekiel 28:9 Wilt thou yet say before him that slayeth thee, I am God? but thou shalt be a man, and no God, in the hand of him that slayeth thee.

Ezekiel 28:10 Thou shalt die the deaths of the uncircumcised by the hand of strangers: for I have spoken it, saith the Lord God.

Ezekiel 28:11 Moreover the word of the Lord came unto me, saying,

Ezekiel 28:12 Son of man, take up a lamentation upon the king of Tyrus, and say unto him, Thus saith the Lord God; Thou sealest up the sum, full of wisdom, and perfect in beauty.

Ezekiel 28:13 Thou hast been in Eden the garden of God; every precious stone was thy covering, the sardius, topaz, and the diamond, the beryl, the onyx, and the jasper, the sapphire, the emerald, and the carbuncle, and gold: the workmanship of thy tabrets and of thy pipes was prepared in thee in the day that thou wast created.

Ezekiel 28:14 Thou art the anointed cherub that covereth; and I have set thee so: thou wast upon the holy mountain of God; thou hast walked up and down in the midst of the stones of fire.

Ezekiel 28:15 Thou wast perfect in thy ways from the day that thou wast created, till iniquity was found in thee.

Ezekiel 28:16 By the multitude of thy merchandise they have filled the midst of thee with violence, and thou hast sinned: therefore I will cast thee as profane out of the mountain of God: and I will destroy thee, O covering cherub, from the midst of the stones of fire.

Ezekiel 28:17 Thine heart was lifted up because of thy beauty, thou hast corrupted thy wisdom by reason of thy brightness: I will cast thee to the ground, I will lay thee before kings, that they may behold thee.

Ezekiel 28:18 Thou hast defiled thy sanctuaries by the multitude of thine iniquities, by the iniquity of thy traffick; therefore will I bring forth a fire from the midst of thee, it shall devour thee, and I will bring thee to ashes upon the earth in the sight of all them that behold thee.

Ezekiel 28:19 All they that know thee among the people shall be astonished at thee: thou shalt be a terror, and never shalt thou be any more.

Ezekiel 28:20 Again the word of the Lord came unto me, saying,

Ezekiel 28:21 Son of man, set thy face against Zidon, and prophesy against it,

Ezekiel 28:22 And say, Thus saith the Lord God; Behold, I am against thee, O Zidon; and I will be glorified in the midst of thee: and they shall know that I am the Lord, when I shall have executed judgments in her, and shall be sanctified in her.

Ezekiel 28:23 For I will send into her pestilence, and blood into her streets; and the wounded shall be judged in the midst of her by the sword upon her on every side; and they shall know that I am the Lord.

Ezekiel 28:24 And there shall be no more a pricking brier unto the house of Israel, nor any grieving thorn of all that are round about them, that despised them; and they shall know that I am the Lord God.

Ezekiel 28:25 Thus saith the Lord God; When I shall have gathered the house of Israel from the people among whom they are scattered, and shall be sanctified in them in the sight of the heathen, then shall they dwell in their land that I have given to my servant Jacob.

Ezekiel 28:26 And they shall dwell safely therein, and shall build houses, and plant vineyards; yea, they shall dwell with confidence, when I have executed judgments upon all those that despise them round about them; and they shall know that I am the Lord their God.
