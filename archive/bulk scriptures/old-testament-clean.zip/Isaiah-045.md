# Isaiah 45

Isaiah 45 (summary): Cyrus will free the captives of Israel from Babylon—Come unto Jehovah (Christ) and be saved—To Him every knee will bow and every tongue will take an oath.

Isaiah 45:1 Thus saith the Lord to his anointed, to Cyrus, whose right hand I have holden, to subdue nations before him; and I will loose the loins of kings, to open before him the two leaved gates; and the gates shall not be shut;

Isaiah 45:2 I will go before thee, and make the crooked places straight: I will break in pieces the gates of brass, and cut in sunder the bars of iron:

Isaiah 45:3 And I will give thee the treasures of darkness, and hidden riches of secret places, that thou mayest know that I, the Lord, which call thee by thy name, am the God of Israel.

Isaiah 45:4 For Jacob my servant’s sake, and Israel mine elect, I have even called thee by thy name: I have surnamed thee, though thou hast not known me.

Isaiah 45:5 I am the Lord, and there is none else, there is no God beside me: I girded thee, though thou hast not known me:

Isaiah 45:6 That they may know from the rising of the sun, and from the west, that there is none beside me. I am the Lord, and there is none else.

Isaiah 45:7 I form the light, and create darkness: I make peace, and create evil: I the Lord do all these things.

Isaiah 45:8 Drop down, ye heavens, from above, and let the skies pour down righteousness: let the earth open, and let them bring forth salvation, and let righteousness spring up together; I the Lord have created it.

Isaiah 45:9 Woe unto him that striveth with his Maker! Let the potsherd strive with the potsherds of the earth. Shall the clay say to him that fashioneth it, What makest thou? or thy work, He hath no hands?

Isaiah 45:10 Woe unto him that saith unto his father, What begettest thou? or to the woman, What hast thou brought forth?

Isaiah 45:11 Thus saith the Lord, the Holy One of Israel, and his Maker, Ask me of things to come concerning my sons, and concerning the work of my hands command ye me.

Isaiah 45:12 I have made the earth, and created man upon it: I, even my hands, have stretched out the heavens, and all their host have I commanded.

Isaiah 45:13 I have raised him up in righteousness, and I will direct all his ways: he shall build my city, and he shall let go my captives, not for price nor reward, saith the Lord of hosts.

Isaiah 45:14 Thus saith the Lord, The labour of Egypt, and merchandise of Ethiopia and of the Sabeans, men of stature, shall come over unto thee, and they shall be thine: they shall come after thee; in chains they shall come over, and they shall fall down unto thee, they shall make supplication unto thee, saying, Surely God is in thee; and there is none else, there is no God.

Isaiah 45:15 Verily thou art a God that hidest thyself, O God of Israel, the Saviour.

Isaiah 45:16 They shall be ashamed, and also confounded, all of them: they shall go to confusion together that are makers of idols.

Isaiah 45:17 But Israel shall be saved in the Lord with an everlasting salvation: ye shall not be ashamed nor confounded world without end.

Isaiah 45:18 For thus saith the Lord that created the heavens; God himself that formed the earth and made it; he hath established it, he created it not in vain, he formed it to be inhabited: I am the Lord; and there is none else.

Isaiah 45:19 I have not spoken in secret, in a dark place of the earth: I said not unto the seed of Jacob, Seek ye me in vain: I the Lord speak righteousness, I declare things that are right.

Isaiah 45:20 Assemble yourselves and come; draw near together, ye that are escaped of the nations: they have no knowledge that set up the wood of their graven image, and pray unto a god that cannot save.

Isaiah 45:21 Tell ye, and bring them near; yea, let them take counsel together: who hath declared this from ancient time? who hath told it from that time? have not I the Lord? and there is no God else beside me; a just God and a Saviour; there is none beside me.

Isaiah 45:22 Look unto me, and be ye saved, all the ends of the earth: for I am God, and there is none else.

Isaiah 45:23 I have sworn by myself, the word is gone out of my mouth in righteousness, and shall not return, That unto me every knee shall bow, every tongue shall swear.

Isaiah 45:24 Surely, shall one say, in the Lord have I righteousness and strength: even to him shall men come; and all that are incensed against him shall be ashamed.

Isaiah 45:25 In the Lord shall all the seed of Israel be justified, and shall glory.
