# Psalms 43

Psalms 43 (summary): The righteous praise God and cry, Send out Thy light and Thy truth.

Psalms 43:1 Judge me, O God, and plead my cause against an ungodly nation: O deliver me from the deceitful and unjust man.

Psalms 43:2 For thou art the God of my strength: why dost thou cast me off? why go I mourning because of the oppression of the enemy?

Psalms 43:3 O send out thy light and thy truth: let them lead me; let them bring me unto thy holy hill, and to thy tabernacles.

Psalms 43:4 Then will I go unto the altar of God, unto God my exceeding joy: yea, upon the harp will I praise thee, O God my God.

Psalms 43:5 Why art thou cast down, O my soul? and why art thou disquieted within me? hope in God: for I shall yet praise him, who is the health of my countenance, and my God.
