# 2 Samuel 3

2 Samuel 3 (summary): The houses of David and Saul engage in a long war—David grows stronger—Abner joins David but is slain by Joab—David mourns for Abner.

2 Samuel 3:1 Now there was long war between the house of Saul and the house of David: but David waxed stronger and stronger, and the house of Saul waxed weaker and weaker.

2 Samuel 3:2 And unto David were sons born in Hebron: and his firstborn was Amnon, of Ahinoam the Jezreelitess;

2 Samuel 3:3 And his second, Chileab, of Abigail the wife of Nabal the Carmelite; and the third, Absalom the son of Maacah the daughter of Talmai king of Geshur;

2 Samuel 3:4 And the fourth, Adonijah the son of Haggith; and the fifth, Shephatiah the son of Abital;

2 Samuel 3:5 And the sixth, Ithream, by Eglah David’s wife. These were born to David in Hebron.

2 Samuel 3:6 And it came to pass, while there was war between the house of Saul and the house of David, that Abner made himself strong for the house of Saul.

2 Samuel 3:7 And Saul had a concubine, whose name was Rizpah, the daughter of Aiah: and Ish-bosheth said to Abner, Wherefore hast thou gone in unto my father’s concubine?

2 Samuel 3:8 Then was Abner very wroth for the words of Ish-bosheth, and said, Am I a dog’s head, which against Judah do shew kindness this day unto the house of Saul thy father, to his brethren, and to his friends, and have not delivered thee into the hand of David, that thou chargest me to day with a fault concerning this woman?

2 Samuel 3:9 So do God to Abner, and more also, except, as the Lord hath sworn to David, even so I do to him;

2 Samuel 3:10 To translate the kingdom from the house of Saul, and to set up the throne of David over Israel and over Judah, from Dan even to Beer-sheba.

2 Samuel 3:11 And he could not answer Abner a word again, because he feared him.

2 Samuel 3:12 And Abner sent messengers to David on his behalf, saying, Whose is the land? saying also, Make thy league with me, and, behold, my hand shall be with thee, to bring about all Israel unto thee.

2 Samuel 3:13 And he said, Well; I will make a league with thee: but one thing I require of thee, that is, Thou shalt not see my face, except thou first bring Michal Saul’s daughter, when thou comest to see my face.

2 Samuel 3:14 And David sent messengers to Ish-bosheth Saul’s son, saying, Deliver me my wife Michal, which I espoused to me for an hundred foreskins of the Philistines.

2 Samuel 3:15 And Ish-bosheth sent, and took her from her husband, even from Phaltiel the son of Laish.

2 Samuel 3:16 And her husband went with her along weeping behind her to Bahurim. Then said Abner unto him, Go, return. And he returned.

2 Samuel 3:17 And Abner had communication with the elders of Israel, saying, Ye sought for David in times past to be king over you:

2 Samuel 3:18 Now then do it: for the Lord hath spoken of David, saying, By the hand of my servant David I will save my people Israel out of the hand of the Philistines, and out of the hand of all their enemies.

2 Samuel 3:19 And Abner also spake in the ears of Benjamin: and Abner went also to speak in the ears of David in Hebron all that seemed good to Israel, and that seemed good to the whole house of Benjamin.

2 Samuel 3:20 So Abner came to David to Hebron, and twenty men with him. And David made Abner and the men that were with him a feast.

2 Samuel 3:21 And Abner said unto David, I will arise and go, and will gather all Israel unto my lord the king, that they may make a league with thee, and that thou mayest reign over all that thine heart desireth. And David sent Abner away; and he went in peace.

2 Samuel 3:22 And, behold, the servants of David and Joab came from pursuing a troop, and brought in a great spoil with them: but Abner was not with David in Hebron; for he had sent him away, and he was gone in peace.

2 Samuel 3:23 When Joab and all the host that was with him were come, they told Joab, saying, Abner the son of Ner came to the king, and he hath sent him away, and he is gone in peace.

2 Samuel 3:24 Then Joab came to the king, and said, What hast thou done? behold, Abner came unto thee; why is it that thou hast sent him away, and he is quite gone?

2 Samuel 3:25 Thou knowest Abner the son of Ner, that he came to deceive thee, and to know thy going out and thy coming in, and to know all that thou doest.

2 Samuel 3:26 And when Joab was come out from David, he sent messengers after Abner, which brought him again from the well of Sirah: but David knew it not.

2 Samuel 3:27 And when Abner was returned to Hebron, Joab took him aside in the gate to speak with him quietly, and smote him there under the fifth rib, that he died, for the blood of Asahel his brother.

2 Samuel 3:28 And afterward when David heard it, he said, I and my kingdom are guiltless before the Lord for ever from the blood of Abner the son of Ner:

2 Samuel 3:29 Let it rest on the head of Joab, and on all his father’s house; and let there not fail from the house of Joab one that hath an issue, or that is a leper, or that leaneth on a staff, or that falleth on the sword, or that lacketh bread.

2 Samuel 3:30 So Joab and Abishai his brother slew Abner, because he had slain their brother Asahel at Gibeon in the battle.

2 Samuel 3:31 And David said to Joab, and to all the people that were with him, Rend your clothes, and gird you with sackcloth, and mourn before Abner. And king David himself followed the bier.

2 Samuel 3:32 And they buried Abner in Hebron: and the king lifted up his voice, and wept at the grave of Abner; and all the people wept.

2 Samuel 3:33 And the king lamented over Abner, and said, Died Abner as a fool dieth?

2 Samuel 3:34 Thy hands were not bound, nor thy feet put into fetters: as a man falleth before wicked men, so fellest thou. And all the people wept again over him.

2 Samuel 3:35 And when all the people came to cause David to eat meat while it was yet day, David sware, saying, So do God to me, and more also, if I taste bread, or ought else, till the sun be down.

2 Samuel 3:36 And all the people took notice of it, and it pleased them: as whatsoever the king did pleased all the people.

2 Samuel 3:37 For all the people and all Israel understood that day that it was not of the king to slay Abner the son of Ner.

2 Samuel 3:38 And the king said unto his servants, Know ye not that there is a prince and a great man fallen this day in Israel?

2 Samuel 3:39 And I am this day weak, though anointed king; and these men the sons of Zeruiah be too hard for me: the Lord shall reward the doer of evil according to his wickedness.
