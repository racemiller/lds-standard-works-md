# Psalms 144

Psalms 144 (summary): David blesses the Lord for deliverance and temporal prosperity—Happy is that people whose God is the Lord.

Psalms 144:1 Blessed be the Lord my strength, which teacheth my hands to war, and my fingers to fight:

Psalms 144:2 My goodness, and my fortress; my high tower, and my deliverer; my shield, and he in whom I trust; who subdueth my people under me.

Psalms 144:3 Lord, what is man, that thou takest knowledge of him! or the son of man, that thou makest account of him!

Psalms 144:4 Man is like to vanity: his days are as a shadow that passeth away.

Psalms 144:5 Bow thy heavens, O Lord, and come down: touch the mountains, and they shall smoke.

Psalms 144:6 Cast forth lightning, and scatter them: shoot out thine arrows, and destroy them.

Psalms 144:7 Send thine hand from above; rid me, and deliver me out of great waters, from the hand of strange children;

Psalms 144:8 Whose mouth speaketh vanity, and their right hand is a right hand of falsehood.

Psalms 144:9 I will sing a new song unto thee, O God: upon a psaltery and an instrument of ten strings will I sing praises unto thee.

Psalms 144:10 It is he that giveth salvation unto kings: who delivereth David his servant from the hurtful sword.

Psalms 144:11 Rid me, and deliver me from the hand of strange children, whose mouth speaketh vanity, and their right hand is a right hand of falsehood:

Psalms 144:12 That our sons may be as plants grown up in their youth; that our daughters may be as corner stones, polished after the similitude of a palace:

Psalms 144:13 That our garners may be full, affording all manner of store: that our sheep may bring forth thousands and ten thousands in our streets:

Psalms 144:14 That our oxen may be strong to labour; that there be no breaking in, nor going out; that there be no complaining in our streets.

Psalms 144:15 Happy is that people, that is in such a case: yea, happy is that people, whose God is the Lord.
