# Zechariah 13

Zechariah 13 (summary): The Jews will gain forgiveness at the Second Coming—They will ask the Lord, What are these wounds in Thine hands?—The remnant, tried and refined, will be His people.

Zechariah 13:1 In that day there shall be a fountain opened to the house of David and to the inhabitants of Jerusalem for sin and for uncleanness.

Zechariah 13:2 And it shall come to pass in that day, saith the Lord of hosts, that I will cut off the names of the idols out of the land, and they shall no more be remembered: and also I will cause the prophets and the unclean spirit to pass out of the land.

Zechariah 13:3 And it shall come to pass, that when any shall yet prophesy, then his father and his mother that begat him shall say unto him, Thou shalt not live; for thou speakest lies in the name of the Lord: and his father and his mother that begat him shall thrust him through when he prophesieth.

Zechariah 13:4 And it shall come to pass in that day, that the prophets shall be ashamed every one of his vision, when he hath prophesied; neither shall they wear a rough garment to deceive:

Zechariah 13:5 But he shall say, I am no prophet, I am an husbandman; for man taught me to keep cattle from my youth.

Zechariah 13:6 And one shall say unto him, What are these wounds in thine hands? Then he shall answer, Those with which I was wounded in the house of my friends.

Zechariah 13:7 Awake, O sword, against my shepherd, and against the man that is my fellow, saith the Lord of hosts: smite the shepherd, and the sheep shall be scattered: and I will turn mine hand upon the little ones.

Zechariah 13:8 And it shall come to pass, that in all the land, saith the Lord, two parts therein shall be cut off and die; but the third shall be left therein.

Zechariah 13:9 And I will bring the third part through the fire, and will refine them as silver is refined, and will try them as gold is tried: they shall call on my name, and I will hear them: I will say, It is my people: and they shall say, The Lord is my God.
