# Ezekiel 3

Ezekiel 3 (summary): Ezekiel is made a watchman unto the house of Israel—The blood of Israel is required at his hand unless he raises the warning voice.

Ezekiel 3:1 Moreover he said unto me, Son of man, eat that thou findest; eat this roll, and go speak unto the house of Israel.

Ezekiel 3:2 So I opened my mouth, and he caused me to eat that roll.

Ezekiel 3:3 And he said unto me, Son of man, cause thy belly to eat, and fill thy bowels with this roll that I give thee. Then did I eat it; and it was in my mouth as honey for sweetness.

Ezekiel 3:4 And he said unto me, Son of man, go, get thee unto the house of Israel, and speak with my words unto them.

Ezekiel 3:5 For thou art not sent to a people of a strange speech and of an hard language, but to the house of Israel;

Ezekiel 3:6 Not to many people of a strange speech and of an hard language, whose words thou canst not understand. Surely, had I sent thee to them, they would have hearkened unto thee.

Ezekiel 3:7 But the house of Israel will not hearken unto thee; for they will not hearken unto me: for all the house of Israel are impudent and hardhearted.

Ezekiel 3:8 Behold, I have made thy face strong against their faces, and thy forehead strong against their foreheads.

Ezekiel 3:9 As an adamant harder than flint have I made thy forehead: fear them not, neither be dismayed at their looks, though they be a rebellious house.

Ezekiel 3:10 Moreover he said unto me, Son of man, all my words that I shall speak unto thee receive in thine heart, and hear with thine ears.

Ezekiel 3:11 And go, get thee to them of the captivity, unto the children of thy people, and speak unto them, and tell them, Thus saith the Lord God; whether they will hear, or whether they will forbear.

Ezekiel 3:12 Then the spirit took me up, and I heard behind me a voice of a great rushing, saying, Blessed be the glory of the Lord from his place.

Ezekiel 3:13 I heard also the noise of the wings of the living creatures that touched one another, and the noise of the wheels over against them, and a noise of a great rushing.

Ezekiel 3:14 So the spirit lifted me up, and took me away, and I went in bitterness, in the heat of my spirit; but the hand of the Lord was strong upon me.

Ezekiel 3:15 Then I came to them of the captivity at Tel-abib, that dwelt by the river of Chebar, and I sat where they sat, and remained there astonished among them seven days.

Ezekiel 3:16 And it came to pass at the end of seven days, that the word of the Lord came unto me, saying,

Ezekiel 3:17 Son of man, I have made thee a watchman unto the house of Israel: therefore hear the word at my mouth, and give them warning from me.

Ezekiel 3:18 When I say unto the wicked, Thou shalt surely die; and thou givest him not warning, nor speakest to warn the wicked from his wicked way, to save his life; the same wicked man shall die in his iniquity; but his blood will I require at thine hand.

Ezekiel 3:19 Yet if thou warn the wicked, and he turn not from his wickedness, nor from his wicked way, he shall die in his iniquity; but thou hast delivered thy soul.

Ezekiel 3:20 Again, When a righteous man doth turn from his righteousness, and commit iniquity, and I lay a stumblingblock before him, he shall die: because thou hast not given him warning, he shall die in his sin, and his righteousness which he hath done shall not be remembered; but his blood will I require at thine hand.

Ezekiel 3:21 Nevertheless if thou warn the righteous man, that the righteous sin not, and he doth not sin, he shall surely live, because he is warned; also thou hast delivered thy soul.

Ezekiel 3:22 And the hand of the Lord was there upon me; and he said unto me, Arise, go forth into the plain, and I will there talk with thee.

Ezekiel 3:23 Then I arose, and went forth into the plain: and, behold, the glory of the Lord stood there, as the glory which I saw by the river of Chebar: and I fell on my face.

Ezekiel 3:24 Then the spirit entered into me, and set me upon my feet, and spake with me, and said unto me, Go, shut thyself within thine house.

Ezekiel 3:25 But thou, O son of man, behold, they shall put bands upon thee, and shall bind thee with them, and thou shalt not go out among them:

Ezekiel 3:26 And I will make thy tongue cleave to the roof of thy mouth, that thou shalt be dumb, and shalt not be to them a reprover: for they are a rebellious house.

Ezekiel 3:27 But when I speak with thee, I will open thy mouth, and thou shalt say unto them, Thus saith the Lord God; He that heareth, let him hear; and he that forbeareth, let him forbear: for they are a rebellious house.
