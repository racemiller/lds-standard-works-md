# Ezekiel 45

Ezekiel 45 (summary): Portions of land will be provided for the sanctuary and the dwellings of the priests—The people are to offer their sacrifices and oblations and keep their feasts.

Ezekiel 45:1 Moreover, when ye shall divide by lot the land for inheritance, ye shall offer an oblation unto the Lord, an holy portion of the land: the length shall be the length of five and twenty thousand reeds, and the breadth shall be ten thousand. This shall be holy in all the borders thereof round about.

Ezekiel 45:2 Of this there shall be for the sanctuary five hundred in length, with five hundred in breadth, square round about; and fifty cubits round about for the suburbs thereof.

Ezekiel 45:3 And of this measure shalt thou measure the length of five and twenty thousand, and the breadth of ten thousand: and in it shall be the sanctuary and the most holy place.

Ezekiel 45:4 The holy portion of the land shall be for the priests the ministers of the sanctuary, which shall come near to minister unto the Lord: and it shall be a place for their houses, and an holy place for the sanctuary.

Ezekiel 45:5 And the five and twenty thousand of length, and the ten thousand of breadth, shall also the Levites, the ministers of the house, have for themselves, for a possession for twenty chambers.

Ezekiel 45:6 And ye shall appoint the possession of the city five thousand broad, and five and twenty thousand long, over against the oblation of the holy portion: it shall be for the whole house of Israel.

Ezekiel 45:7 And a portion shall be for the prince on the one side and on the other side of the oblation of the holy portion, and of the possession of the city, before the oblation of the holy portion, and before the possession of the city, from the west side westward, and from the east side eastward: and the length shall be over against one of the portions, from the west border unto the east border.

Ezekiel 45:8 In the land shall be his possession in Israel: and my princes shall no more oppress my people; and the rest of the land shall they give to the house of Israel according to their tribes.

Ezekiel 45:9 Thus saith the Lord God; Let it suffice you, O princes of Israel: remove violence and spoil, and execute judgment and justice, take away your exactions from my people, saith the Lord God.

Ezekiel 45:10 Ye shall have just balances, and a just ephah, and a just bath.

Ezekiel 45:11 The ephah and the bath shall be of one measure, that the bath may contain the tenth part of an homer, and the ephah the tenth part of an homer: the measure thereof shall be after the homer.

Ezekiel 45:12 And the shekel shall be twenty gerahs: twenty shekels, five and twenty shekels, fifteen shekels, shall be your maneh.

Ezekiel 45:13 This is the oblation that ye shall offer; the sixth part of an ephah of an homer of wheat, and ye shall give the sixth part of an ephah of an homer of barley:

Ezekiel 45:14 Concerning the ordinance of oil, the bath of oil, ye shall offer the tenth part of a bath out of the cor, which is an homer of ten baths; for ten baths are an homer:

Ezekiel 45:15 And one lamb out of the flock, out of two hundred, out of the fat pastures of Israel; for a meat offering, and for a burnt offering, and for peace offerings, to make reconciliation for them, saith the Lord God.

Ezekiel 45:16 All the people of the land shall give this oblation for the prince in Israel.

Ezekiel 45:17 And it shall be the prince’s part to give burnt offerings, and meat offerings, and drink offerings, in the feasts, and in the new moons, and in the sabbaths, in all solemnities of the house of Israel: he shall prepare the sin offering, and the meat offering, and the burnt offering, and the peace offerings, to make reconciliation for the house of Israel.

Ezekiel 45:18 Thus saith the Lord God; In the first month, in the first day of the month, thou shalt take a young bullock without blemish, and cleanse the sanctuary:

Ezekiel 45:19 And the priest shall take of the blood of the sin offering, and put it upon the posts of the house, and upon the four corners of the settle of the altar, and upon the posts of the gate of the inner court.

Ezekiel 45:20 And so thou shalt do the seventh day of the month for every one that erreth, and for him that is simple: so shall ye reconcile the house.

Ezekiel 45:21 In the first month, in the fourteenth day of the month, ye shall have the passover, a feast of seven days; unleavened bread shall be eaten.

Ezekiel 45:22 And upon that day shall the prince prepare for himself and for all the people of the land a bullock for a sin offering.

Ezekiel 45:23 And seven days of the feast he shall prepare a burnt offering to the Lord, seven bullocks and seven rams without blemish daily the seven days; and a kid of the goats daily for a sin offering.

Ezekiel 45:24 And he shall prepare a meat offering of an ephah for a bullock, and an ephah for a ram, and an hin of oil for an ephah.

Ezekiel 45:25 In the seventh month, in the fifteenth day of the month, shall he do the like in the feast of the seven days, according to the sin offering, according to the burnt offering, and according to the meat offering, and according to the oil.
