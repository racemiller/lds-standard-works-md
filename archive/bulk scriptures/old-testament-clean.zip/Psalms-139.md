# Psalms 139

Psalms 139 (summary): David says that the Lord knows all man’s thoughts and doings—He asks, Where can man go to escape from the spirit and presence of the Lord?—Man is fearfully and wonderfully made.

Psalms 139:1 O Lord, thou hast searched me, and known me.

Psalms 139:2 Thou knowest my downsitting and mine uprising, thou understandest my thought afar off.

Psalms 139:3 Thou compassest my path and my lying down, and art acquainted with all my ways.

Psalms 139:4 For there is not a word in my tongue, but, lo, O Lord, thou knowest it altogether.

Psalms 139:5 Thou hast beset me behind and before, and laid thine hand upon me.

Psalms 139:6 Such knowledge is too wonderful for me; it is high, I cannot attain unto it.

Psalms 139:7 Whither shall I go from thy spirit? or whither shall I flee from thy presence?

Psalms 139:8 If I ascend up into heaven, thou art there: if I make my bed in hell, behold, thou art there.

Psalms 139:9 If I take the wings of the morning, and dwell in the uttermost parts of the sea;

Psalms 139:10 Even there shall thy hand lead me, and thy right hand shall hold me.

Psalms 139:11 If I say, Surely the darkness shall cover me; even the night shall be light about me.

Psalms 139:12 Yea, the darkness hideth not from thee; but the night shineth as the day: the darkness and the light are both alike to thee.

Psalms 139:13 For thou hast possessed my reins: thou hast covered me in my mother’s womb.

Psalms 139:14 I will praise thee; for I am fearfully and wonderfully made: marvellous are thy works; and that my soul knoweth right well.

Psalms 139:15 My substance was not hid from thee, when I was made in secret, and curiously wrought in the lowest parts of the earth.

Psalms 139:16 Thine eyes did see my substance, yet being unperfect; and in thy book all my members were written, which in continuance were fashioned, when as yet there was none of them.

Psalms 139:17 How precious also are thy thoughts unto me, O God! how great is the sum of them!

Psalms 139:18 If I should count them, they are more in number than the sand: when I awake, I am still with thee.

Psalms 139:19 Surely thou wilt slay the wicked, O God: depart from me therefore, ye bloody men.

Psalms 139:20 For they speak against thee wickedly, and thine enemies take thy name in vain.

Psalms 139:21 Do not I hate them, O Lord, that hate thee? and am not I grieved with those that rise up against thee?

Psalms 139:22 I hate them with perfect hatred: I count them mine enemies.

Psalms 139:23 Search me, O God, and know my heart: try me, and know my thoughts:

Psalms 139:24 And see if there be any wicked way in me, and lead me in the way everlasting.
