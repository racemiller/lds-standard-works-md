# 1 Kings 5

1 Kings 5 (summary): Solomon solicits and gains Hiram’s help in getting timber to build the temple—The Israelites hew stones and cut timber for the temple.

1 Kings 5:1 And Hiram king of Tyre sent his servants unto Solomon; for he had heard that they had anointed him king in the room of his father: for Hiram was ever a lover of David.

1 Kings 5:2 And Solomon sent to Hiram, saying,

1 Kings 5:3 Thou knowest how that David my father could not build an house unto the name of the Lord his God for the wars which were about him on every side, until the Lord put them under the soles of his feet.

1 Kings 5:4 But now the Lord my God hath given me rest on every side, so that there is neither adversary nor evil occurrent.

1 Kings 5:5 And, behold, I purpose to build an house unto the name of the Lord my God, as the Lord spake unto David my father, saying, Thy son, whom I will set upon thy throne in thy room, he shall build an house unto my name.

1 Kings 5:6 Now therefore command thou that they hew me cedar trees out of Lebanon; and my servants shall be with thy servants: and unto thee will I give hire for thy servants according to all that thou shalt appoint: for thou knowest that there is not among us any that can skill to hew timber like unto the Sidonians.

1 Kings 5:7 And it came to pass, when Hiram heard the words of Solomon, that he rejoiced greatly, and said, Blessed be the Lord this day, which hath given unto David a wise son over this great people.

1 Kings 5:8 And Hiram sent to Solomon, saying, I have considered the things which thou sentest to me for: and I will do all thy desire concerning timber of cedar, and concerning timber of fir.

1 Kings 5:9 My servants shall bring them down from Lebanon unto the sea: and I will convey them by sea in floats unto the place that thou shalt appoint me, and will cause them to be discharged there, and thou shalt receive them: and thou shalt accomplish my desire, in giving food for my household.

1 Kings 5:10 So Hiram gave Solomon cedar trees and fir trees according to all his desire.

1 Kings 5:11 And Solomon gave Hiram twenty thousand measures of wheat for food to his household, and twenty measures of pure oil: thus gave Solomon to Hiram year by year.

1 Kings 5:12 And the Lord gave Solomon wisdom, as he promised him: and there was peace between Hiram and Solomon; and they two made a league together.

1 Kings 5:13 And king Solomon raised a levy out of all Israel; and the levy was thirty thousand men.

1 Kings 5:14 And he sent them to Lebanon, ten thousand a month by courses: a month they were in Lebanon, and two months at home: and Adoniram was over the levy.

1 Kings 5:15 And Solomon had threescore and ten thousand that bare burdens, and fourscore thousand hewers in the mountains;

1 Kings 5:16 Beside the chief of Solomon’s officers which were over the work, three thousand and three hundred, which ruled over the people that wrought in the work.

1 Kings 5:17 And the king commanded, and they brought great stones, costly stones, and hewed stones, to lay the foundation of the house.

1 Kings 5:18 And Solomon’s builders and Hiram’s builders did hew them, and the stonesquarers: so they prepared timber and stones to build the house.
