# Ecclesiastes 8

Ecclesiastes 8 (summary): None have power to avoid death—It will not be well with the wicked; he turns to pleasure and cannot find wisdom.

Ecclesiastes 8:1 Who is as the wise man? and who knoweth the interpretation of a thing? a man’s wisdom maketh his face to shine, and the boldness of his face shall be changed.

Ecclesiastes 8:2 I counsel thee to keep the king’s commandment, and that in regard of the oath of God.

Ecclesiastes 8:3 Be not hasty to go out of his sight: stand not in an evil thing; for he doeth whatsoever pleaseth him.

Ecclesiastes 8:4 Where the word of a king is, there is power: and who may say unto him, What doest thou?

Ecclesiastes 8:5 Whoso keepeth the commandment shall feel no evil thing: and a wise man’s heart discerneth both time and judgment.

Ecclesiastes 8:6 Because to every purpose there is time and judgment, therefore the misery of man is great upon him.

Ecclesiastes 8:7 For he knoweth not that which shall be: for who can tell him when it shall be?

Ecclesiastes 8:8 There is no man that hath power over the spirit to retain the spirit; neither hath he power in the day of death: and there is no discharge in that war; neither shall wickedness deliver those that are given to it.

Ecclesiastes 8:9 All this have I seen, and applied my heart unto every work that is done under the sun: there is a time wherein one man ruleth over another to his own hurt.

Ecclesiastes 8:10 And so I saw the wicked buried, who had come and gone from the place of the holy, and they were forgotten in the city where they had so done: this is also vanity.

Ecclesiastes 8:11 Because sentence against an evil work is not executed speedily, therefore the heart of the sons of men is fully set in them to do evil.

Ecclesiastes 8:12 Though a sinner do evil an hundred times, and his days be prolonged, yet surely I know that it shall be well with them that fear God, which fear before him:

Ecclesiastes 8:13 But it shall not be well with the wicked, neither shall he prolong his days, which are as a shadow; because he feareth not before God.

Ecclesiastes 8:14 There is a vanity which is done upon the earth; that there be just men, unto whom it happeneth according to the work of the wicked; again, there be wicked men, to whom it happeneth according to the work of the righteous: I said that this also is vanity.

Ecclesiastes 8:15 Then I commended mirth, because a man hath no better thing under the sun, than to eat, and to drink, and to be merry: for that shall abide with him of his labour the days of his life, which God giveth him under the sun.

Ecclesiastes 8:16 When I applied mine heart to know wisdom, and to see the business that is done upon the earth: (for also there is that neither day nor night seeth sleep with his eyes:)

Ecclesiastes 8:17 Then I beheld all the work of God, that a man cannot find out the work that is done under the sun: because though a man labour to seek it out, yet he shall not find it; yea further; though a wise man think to know it, yet shall he not be able to find it.
