# Exodus 4

Exodus 4 (summary): The Lord gives signs to Moses—Aaron is chosen as a spokesman—Israel is the Lord’s firstborn and must be released to serve Him—Moses’ son is circumcised—Moses and Aaron lead Israel in worship.

Exodus 4:1 And Moses answered and said, But, behold, they will not believe me, nor hearken unto my voice: for they will say, The Lord hath not appeared unto thee.

Exodus 4:2 And the Lord said unto him, What is that in thine hand? And he said, A rod.

Exodus 4:3 And he said, Cast it on the ground. And he cast it on the ground, and it became a serpent; and Moses fled from before it.

Exodus 4:4 And the Lord said unto Moses, Put forth thine hand, and take it by the tail. And he put forth his hand, and caught it, and it became a rod in his hand:

Exodus 4:5 That they may believe that the Lord God of their fathers, the God of Abraham, the God of Isaac, and the God of Jacob, hath appeared unto thee.

Exodus 4:6 And the Lord said furthermore unto him, Put now thine hand into thy bosom. And he put his hand into his bosom: and when he took it out, behold, his hand was leprous as snow.

Exodus 4:7 And he said, Put thine hand into thy bosom again. And he put his hand into his bosom again; and plucked it out of his bosom, and, behold, it was turned again as his other flesh.

Exodus 4:8 And it shall come to pass, if they will not believe thee, neither hearken to the voice of the first sign, that they will believe the voice of the latter sign.

Exodus 4:9 And it shall come to pass, if they will not believe also these two signs, neither hearken unto thy voice, that thou shalt take of the water of the river, and pour it upon the dry land: and the water which thou takest out of the river shall become blood upon the dry land.

Exodus 4:10 And Moses said unto the Lord, O my Lord, I am not eloquent, neither heretofore, nor since thou hast spoken unto thy servant: but I am slow of speech, and of a slow tongue.

Exodus 4:11 And the Lord said unto him, Who hath made man’s mouth? or who maketh the dumb, or deaf, or the seeing, or the blind? have not I the Lord?

Exodus 4:12 Now therefore go, and I will be with thy mouth, and teach thee what thou shalt say.

Exodus 4:13 And he said, O my Lord, send, I pray thee, by the hand of him whom thou wilt send.

Exodus 4:14 And the anger of the Lord was kindled against Moses, and he said, Is not Aaron the Levite thy brother? I know that he can speak well. And also, behold, he cometh forth to meet thee: and when he seeth thee, he will be glad in his heart.

Exodus 4:15 And thou shalt speak unto him, and put words in his mouth: and I will be with thy mouth, and with his mouth, and will teach you what ye shall do.

Exodus 4:16 And he shall be thy spokesman unto the people: and he shall be, even he shall be to thee instead of a mouth, and thou shalt be to him instead of God.

Exodus 4:17 And thou shalt take this rod in thine hand, wherewith thou shalt do signs.

Exodus 4:18 And Moses went and returned to Jethro his father in law, and said unto him, Let me go, I pray thee, and return unto my brethren which are in Egypt, and see whether they be yet alive. And Jethro said to Moses, Go in peace.

Exodus 4:19 And the Lord said unto Moses in Midian, Go, return into Egypt: for all the men are dead which sought thy life.

Exodus 4:20 And Moses took his wife and his sons, and set them upon an ass, and he returned to the land of Egypt: and Moses took the rod of God in his hand.

Exodus 4:21 And the Lord said unto Moses, When thou goest to return into Egypt, see that thou do all those wonders before Pharaoh, which I have put in thine hand: but I will harden his heart, that he shall not let the people go.

Exodus 4:22 And thou shalt say unto Pharaoh, Thus saith the Lord, Israel is my son, even my firstborn:

Exodus 4:23 And I say unto thee, Let my son go, that he may serve me: and if thou refuse to let him go, behold, I will slay thy son, even thy firstborn.

Exodus 4:24 And it came to pass by the way in the inn, that the Lord met him, and sought to kill him.

Exodus 4:25 Then Zipporah took a sharp stone, and cut off the foreskin of her son, and cast it at his feet, and said, Surely a bloody husband art thou to me.

Exodus 4:26 So he let him go: then she said, A bloody husband thou art, because of the circumcision.

Exodus 4:27 And the Lord said to Aaron, Go into the wilderness to meet Moses. And he went, and met him in the mount of God, and kissed him.

Exodus 4:28 And Moses told Aaron all the words of the Lord who had sent him, and all the signs which he had commanded him.

Exodus 4:29 And Moses and Aaron went and gathered together all the elders of the children of Israel:

Exodus 4:30 And Aaron spake all the words which the Lord had spoken unto Moses, and did the signs in the sight of the people.

Exodus 4:31 And the people believed: and when they heard that the Lord had visited the children of Israel, and that he had looked upon their affliction, then they bowed their heads and worshipped.
