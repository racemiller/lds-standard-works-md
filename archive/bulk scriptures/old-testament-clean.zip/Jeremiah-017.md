# Jeremiah 17

Jeremiah 17 (summary): The captivity of Judah comes because of sin and forsaking the Lord—Hallow the Sabbath day; doing so will save the people; otherwise they will be destroyed.

Jeremiah 17:1 The sin of Judah is written with a pen of iron, and with the point of a diamond: it is graven upon the table of their heart, and upon the horns of your altars;

Jeremiah 17:2 Whilst their children remember their altars and their groves by the green trees upon the high hills.

Jeremiah 17:3 O my mountain in the field, I will give thy substance and all thy treasures to the spoil, and thy high places for sin, throughout all thy borders.

Jeremiah 17:4 And thou, even thyself, shalt discontinue from thine heritage that I gave thee; and I will cause thee to serve thine enemies in the land which thou knowest not: for ye have kindled a fire in mine anger, which shall burn for ever.

Jeremiah 17:5 Thus saith the Lord; Cursed be the man that trusteth in man, and maketh flesh his arm, and whose heart departeth from the Lord.

Jeremiah 17:6 For he shall be like the heath in the desert, and shall not see when good cometh; but shall inhabit the parched places in the wilderness, in a salt land and not inhabited.

Jeremiah 17:7 Blessed is the man that trusteth in the Lord, and whose hope the Lord is.

Jeremiah 17:8 For he shall be as a tree planted by the waters, and that spreadeth out her roots by the river, and shall not see when heat cometh, but her leaf shall be green; and shall not be careful in the year of drought, neither shall cease from yielding fruit.

Jeremiah 17:9 The heart is deceitful above all things, and desperately wicked: who can know it?

Jeremiah 17:10 I the Lord search the heart, I try the reins, even to give every man according to his ways, and according to the fruit of his doings.

Jeremiah 17:11 As the partridge sitteth on eggs, and hatcheth them not; so he that getteth riches, and not by right, shall leave them in the midst of his days, and at his end shall be a fool.

Jeremiah 17:12 A glorious high throne from the beginning is the place of our sanctuary.

Jeremiah 17:13 O Lord, the hope of Israel, all that forsake thee shall be ashamed, and they that depart from me shall be written in the earth, because they have forsaken the Lord, the fountain of living waters.

Jeremiah 17:14 Heal me, O Lord, and I shall be healed; save me, and I shall be saved: for thou art my praise.

Jeremiah 17:15 Behold, they say unto me, Where is the word of the Lord? let it come now.

Jeremiah 17:16 As for me, I have not hastened from being a pastor to follow thee: neither have I desired the woeful day; thou knowest: that which came out of my lips was right before thee.

Jeremiah 17:17 Be not a terror unto me: thou art my hope in the day of evil.

Jeremiah 17:18 Let them be confounded that persecute me, but let not me be confounded: let them be dismayed, but let not me be dismayed: bring upon them the day of evil, and destroy them with double destruction.

Jeremiah 17:19 Thus said the Lord unto me; Go and stand in the gate of the children of the people, whereby the kings of Judah come in, and by the which they go out, and in all the gates of Jerusalem;

Jeremiah 17:20 And say unto them, Hear ye the word of the Lord, ye kings of Judah, and all Judah, and all the inhabitants of Jerusalem, that enter in by these gates:

Jeremiah 17:21 Thus saith the Lord; Take heed to yourselves, and bear no burden on the sabbath day, nor bring it in by the gates of Jerusalem;

Jeremiah 17:22 Neither carry forth a burden out of your houses on the sabbath day, neither do ye any work, but hallow ye the sabbath day, as I commanded your fathers.

Jeremiah 17:23 But they obeyed not, neither inclined their ear, but made their neck stiff, that they might not hear, nor receive instruction.

Jeremiah 17:24 And it shall come to pass, if ye diligently hearken unto me, saith the Lord, to bring in no burden through the gates of this city on the sabbath day, but hallow the sabbath day, to do no work therein;

Jeremiah 17:25 Then shall there enter into the gates of this city kings and princes sitting upon the throne of David, riding in chariots and on horses, they, and their princes, the men of Judah, and the inhabitants of Jerusalem: and this city shall remain for ever.

Jeremiah 17:26 And they shall come from the cities of Judah, and from the places about Jerusalem, and from the land of Benjamin, and from the plain, and from the mountains, and from the south, bringing burnt offerings, and sacrifices, and meat offerings, and incense, and bringing sacrifices of praise, unto the house of the Lord.

Jeremiah 17:27 But if ye will not hearken unto me to hallow the sabbath day, and not to bear a burden, even entering in at the gates of Jerusalem on the sabbath day; then will I kindle a fire in the gates thereof, and it shall devour the palaces of Jerusalem, and it shall not be quenched.
