# Judges 4

Judges 4 (summary): Deborah, a prophetess, judges Israel—She and Barak deliver Israel from the Canaanites—Jael, a woman, slays Sisera, the Canaanite.

Judges 4:1 And the children of Israel again did evil in the sight of the Lord, when Ehud was dead.

Judges 4:2 And the Lord sold them into the hand of Jabin king of Canaan, that reigned in Hazor; the captain of whose host was Sisera, which dwelt in Harosheth of the Gentiles.

Judges 4:3 And the children of Israel cried unto the Lord: for he had nine hundred chariots of iron; and twenty years he mightily oppressed the children of Israel.

Judges 4:4 And Deborah, a prophetess, the wife of Lapidoth, she judged Israel at that time.

Judges 4:5 And she dwelt under the palm tree of Deborah between Ramah and Beth-el in mount Ephraim: and the children of Israel came up to her for judgment.

Judges 4:6 And she sent and called Barak the son of Abinoam out of Kedesh-naphtali, and said unto him, Hath not the Lord God of Israel commanded, saying, Go and draw toward mount Tabor, and take with thee ten thousand men of the children of Naphtali and of the children of Zebulun?

Judges 4:7 And I will draw unto thee to the river Kishon Sisera, the captain of Jabin’s army, with his chariots and his multitude; and I will deliver him into thine hand.

Judges 4:8 And Barak said unto her, If thou wilt go with me, then I will go: but if thou wilt not go with me, then I will not go.

Judges 4:9 And she said, I will surely go with thee: notwithstanding the journey that thou takest shall not be for thine honour; for the Lord shall sell Sisera into the hand of a woman. And Deborah arose, and went with Barak to Kedesh.

Judges 4:10 And Barak called Zebulun and Naphtali to Kedesh; and he went up with ten thousand men at his feet: and Deborah went up with him.

Judges 4:11 Now Heber the Kenite, which was of the children of Hobab the father in law of Moses, had severed himself from the Kenites, and pitched his tent unto the plain of Zaanaim, which is by Kedesh.

Judges 4:12 And they shewed Sisera that Barak the son of Abinoam was gone up to mount Tabor.

Judges 4:13 And Sisera gathered together all his chariots, even nine hundred chariots of iron, and all the people that were with him, from Harosheth of the Gentiles unto the river of Kishon.

Judges 4:14 And Deborah said unto Barak, Up; for this is the day in which the Lord hath delivered Sisera into thine hand: is not the Lord gone out before thee? So Barak went down from mount Tabor, and ten thousand men after him.

Judges 4:15 And the Lord discomfited Sisera, and all his chariots, and all his host, with the edge of the sword before Barak; so that Sisera lighted down off his chariot, and fled away on his feet.

Judges 4:16 But Barak pursued after the chariots, and after the host, unto Harosheth of the Gentiles: and all the host of Sisera fell upon the edge of the sword; and there was not a man left.

Judges 4:17 Howbeit Sisera fled away on his feet to the tent of Jael the wife of Heber the Kenite: for there was peace between Jabin the king of Hazor and the house of Heber the Kenite.

Judges 4:18 And Jael went out to meet Sisera, and said unto him, Turn in, my lord, turn in to me; fear not. And when he had turned in unto her into the tent, she covered him with a mantle.

Judges 4:19 And he said unto her, Give me, I pray thee, a little water to drink; for I am thirsty. And she opened a bottle of milk, and gave him drink, and covered him.

Judges 4:20 Again he said unto her, Stand in the door of the tent, and it shall be, when any man doth come and inquire of thee, and say, Is there any man here? that thou shalt say, No.

Judges 4:21 Then Jael Heber’s wife took a nail of the tent, and took an hammer in her hand, and went softly unto him, and smote the nail into his temples, and fastened it into the ground: for he was fast asleep and weary. So he died.

Judges 4:22 And, behold, as Barak pursued Sisera, Jael came out to meet him, and said unto him, Come, and I will shew thee the man whom thou seekest. And when he came into her tent, behold, Sisera lay dead, and the nail was in his temples.

Judges 4:23 So God subdued on that day Jabin the king of Canaan before the children of Israel.

Judges 4:24 And the hand of the children of Israel prospered, and prevailed against Jabin the king of Canaan, until they had destroyed Jabin king of Canaan.
