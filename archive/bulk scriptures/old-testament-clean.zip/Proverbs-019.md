# Proverbs 19

Proverbs 19 (summary): A prudent wife is from the Lord—He who lends to the poor lends to the Lord—It is better to be a poor man than to be a liar.

Proverbs 19:1 Better is the poor that walketh in his integrity, than he that is perverse in his lips, and is a fool.

Proverbs 19:2 Also, that the soul be without knowledge, it is not good; and he that hasteth with his feet sinneth.

Proverbs 19:3 The foolishness of man perverteth his way: and his heart fretteth against the Lord.

Proverbs 19:4 Wealth maketh many friends; but the poor is separated from his neighbour.

Proverbs 19:5 A false witness shall not be unpunished, and he that speaketh lies shall not escape.

Proverbs 19:6 Many will entreat the favour of the prince: and every man is a friend to him that giveth gifts.

Proverbs 19:7 All the brethren of the poor do hate him: how much more do his friends go far from him? he pursueth them with words, yet they are wanting to him.

Proverbs 19:8 He that getteth wisdom loveth his own soul: he that keepeth understanding shall find good.

Proverbs 19:9 A false witness shall not be unpunished, and he that speaketh lies shall perish.

Proverbs 19:10 Delight is not seemly for a fool; much less for a servant to have rule over princes.

Proverbs 19:11 The discretion of a man deferreth his anger; and it is his glory to pass over a transgression.

Proverbs 19:12 The king’s wrath is as the roaring of a lion; but his favour is as dew upon the grass.

Proverbs 19:13 A foolish son is the calamity of his father: and the contentions of a wife are a continual dropping.

Proverbs 19:14 House and riches are the inheritance of fathers: and a prudent wife is from the Lord.

Proverbs 19:15 Slothfulness casteth into a deep sleep; and an idle soul shall suffer hunger.

Proverbs 19:16 He that keepeth the commandment keepeth his own soul; but he that despiseth his ways shall die.

Proverbs 19:17 He that hath pity upon the poor lendeth unto the Lord; and that which he hath given will he pay him again.

Proverbs 19:18 Chasten thy son while there is hope, and let not thy soul spare for his crying.

Proverbs 19:19 A man of great wrath shall suffer punishment: for if thou deliver him, yet thou must do it again.

Proverbs 19:20 Hear counsel, and receive instruction, that thou mayest be wise in thy latter end.

Proverbs 19:21 There are many devices in a man’s heart; nevertheless the counsel of the Lord, that shall stand.

Proverbs 19:22 The desire of a man is his kindness: and a poor man is better than a liar.

Proverbs 19:23 The fear of the Lord tendeth to life: and he that hath it shall abide satisfied; he shall not be visited with evil.

Proverbs 19:24 A slothful man hideth his hand in his bosom, and will not so much as bring it to his mouth again.

Proverbs 19:25 Smite a scorner, and the simple will beware: and reprove one that hath understanding, and he will understand knowledge.

Proverbs 19:26 He that wasteth his father, and chaseth away his mother, is a son that causeth shame, and bringeth reproach.

Proverbs 19:27 Cease, my son, to hear the instruction that causeth to err from the words of knowledge.

Proverbs 19:28 An ungodly witness scorneth judgment: and the mouth of the wicked devoureth iniquity.

Proverbs 19:29 Judgments are prepared for scorners, and stripes for the back of fools.
