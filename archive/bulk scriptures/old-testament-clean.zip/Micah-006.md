# Micah 6

Micah 6 (summary): In spite of all His goodness to them, the people have not served the Lord in spirit and in truth—They must act righteously, love mercy, and walk humbly before Him.

Micah 6:1 Hear ye now what the Lord saith; Arise, contend thou before the mountains, and let the hills hear thy voice.

Micah 6:2 Hear ye, O mountains, the Lord’s controversy, and ye strong foundations of the earth: for the Lord hath a controversy with his people, and he will plead with Israel.

Micah 6:3 O my people, what have I done unto thee? and wherein have I wearied thee? testify against me.

Micah 6:4 For I brought thee up out of the land of Egypt, and redeemed thee out of the house of servants; and I sent before thee Moses, Aaron, and Miriam.

Micah 6:5 O my people, remember now what Balak king of Moab consulted, and what Balaam the son of Beor answered him from Shittim unto Gilgal; that ye may know the righteousness of the Lord.

Micah 6:6 Wherewith shall I come before the Lord, and bow myself before the high God? shall I come before him with burnt offerings, with calves of a year old?

Micah 6:7 Will the Lord be pleased with thousands of rams, or with ten thousands of rivers of oil? shall I give my firstborn for my transgression, the fruit of my body for the sin of my soul?

Micah 6:8 He hath shewed thee, O man, what is good; and what doth the Lord require of thee, but to do justly, and to love mercy, and to walk humbly with thy God?

Micah 6:9 The Lord’s voice crieth unto the city, and the man of wisdom shall see thy name: hear ye the rod, and who hath appointed it.

Micah 6:10 Are there yet the treasures of wickedness in the house of the wicked, and the scant measure that is abominable?

Micah 6:11 Shall I count them pure with the wicked balances, and with the bag of deceitful weights?

Micah 6:12 For the rich men thereof are full of violence, and the inhabitants thereof have spoken lies, and their tongue is deceitful in their mouth.

Micah 6:13 Therefore also will I make thee sick in smiting thee, in making thee desolate because of thy sins.

Micah 6:14 Thou shalt eat, but not be satisfied; and thy casting down shall be in the midst of thee; and thou shalt take hold, but shalt not deliver; and that which thou deliverest will I give up to the sword.

Micah 6:15 Thou shalt sow, but thou shalt not reap; thou shalt tread the olives, but thou shalt not anoint thee with oil; and sweet wine, but shalt not drink wine.

Micah 6:16 For the statutes of Omri are kept, and all the works of the house of Ahab, and ye walk in their counsels; that I should make thee a desolation, and the inhabitants thereof an hissing: therefore ye shall bear the reproach of my people.
