# Amos 5

Amos 5 (summary): The people of Israel are exhorted to seek the Lord and do good so that they may live—Their sacrifices to false gods are abhorrent.

Amos 5:1 Hear ye this word which I take up against you, even a lamentation, O house of Israel.

Amos 5:2 The virgin of Israel is fallen; she shall no more rise: she is forsaken upon her land; there is none to raise her up.

Amos 5:3 For thus saith the Lord God; The city that went out by a thousand shall leave an hundred, and that which went forth by an hundred shall leave ten, to the house of Israel.

Amos 5:4 For thus saith the Lord unto the house of Israel, Seek ye me, and ye shall live:

Amos 5:5 But seek not Beth-el, nor enter into Gilgal, and pass not to Beer-sheba: for Gilgal shall surely go into captivity, and Beth-el shall come to nought.

Amos 5:6 Seek the Lord, and ye shall live; lest he break out like fire in the house of Joseph, and devour it, and there be none to quench it in Beth-el.

Amos 5:7 Ye who turn judgment to wormwood, and leave off righteousness in the earth,

Amos 5:8 Seek him that maketh the seven stars and Orion, and turneth the shadow of death into the morning, and maketh the day dark with night: that calleth for the waters of the sea, and poureth them out upon the face of the earth: The Lord is his name:

Amos 5:9 That strengtheneth the spoiled against the strong, so that the spoiled shall come against the fortress.

Amos 5:10 They hate him that rebuketh in the gate, and they abhor him that speaketh uprightly.

Amos 5:11 Forasmuch therefore as your treading is upon the poor, and ye take from him burdens of wheat: ye have built houses of hewn stone, but ye shall not dwell in them; ye have planted pleasant vineyards, but ye shall not drink wine of them.

Amos 5:12 For I know your manifold transgressions and your mighty sins: they afflict the just, they take a bribe, and they turn aside the poor in the gate from their right.

Amos 5:13 Therefore the prudent shall keep silence in that time; for it is an evil time.

Amos 5:14 Seek good, and not evil, that ye may live: and so the Lord, the God of hosts, shall be with you, as ye have spoken.

Amos 5:15 Hate the evil, and love the good, and establish judgment in the gate: it may be that the Lord God of hosts will be gracious unto the remnant of Joseph.

Amos 5:16 Therefore the Lord, the God of hosts, the Lord, saith thus; Wailing shall be in all streets; and they shall say in all the highways, Alas! alas! and they shall call the husbandman to mourning, and such as are skilful of lamentation to wailing.

Amos 5:17 And in all vineyards shall be wailing: for I will pass through thee, saith the Lord.

Amos 5:18 Woe unto you that desire the day of the Lord! to what end is it for you? the day of the Lord is darkness, and not light.

Amos 5:19 As if a man did flee from a lion, and a bear met him; or went into the house, and leaned his hand on the wall, and a serpent bit him.

Amos 5:20 Shall not the day of the Lord be darkness, and not light? even very dark, and no brightness in it?

Amos 5:21 I hate, I despise your feast days, and I will not smell in your solemn assemblies.

Amos 5:22 Though ye offer me burnt offerings and your meat offerings, I will not accept them: neither will I regard the peace offerings of your fat beasts.

Amos 5:23 Take thou away from me the noise of thy songs; for I will not hear the melody of thy viols.

Amos 5:24 But let judgment run down as waters, and righteousness as a mighty stream.

Amos 5:25 Have ye offered unto me sacrifices and offerings in the wilderness forty years, O house of Israel?

Amos 5:26 But ye have borne the tabernacle of your Moloch and Chiun your images, the star of your god, which ye made to yourselves.

Amos 5:27 Therefore will I cause you to go into captivity beyond Damascus, saith the Lord, whose name is The God of hosts.
