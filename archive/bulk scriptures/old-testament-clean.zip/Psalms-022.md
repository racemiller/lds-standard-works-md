# Psalms 22

Psalms 22 (summary): A messianic psalm of David—He foretells events in the Messiah’s life—The Messiah will say, My God, my God, why hast Thou forsaken me?—They will pierce His hands and feet—He will yet govern among all nations.

Psalms 22:1 My God, my God, why hast thou forsaken me? why art thou so far from helping me, and from the words of my roaring?

Psalms 22:2 O my God, I cry in the daytime, but thou hearest not; and in the night season, and am not silent.

Psalms 22:3 But thou art holy, O thou that inhabitest the praises of Israel.

Psalms 22:4 Our fathers trusted in thee: they trusted, and thou didst deliver them.

Psalms 22:5 They cried unto thee, and were delivered: they trusted in thee, and were not confounded.

Psalms 22:6 But I am a worm, and no man; a reproach of men, and despised of the people.

Psalms 22:7 All they that see me laugh me to scorn: they shoot out the lip, they shake the head, saying,

Psalms 22:8 He trusted on the Lord that he would deliver him: let him deliver him, seeing he delighted in him.

Psalms 22:9 But thou art he that took me out of the womb: thou didst make me hope when I was upon my mother’s breasts.

Psalms 22:10 I was cast upon thee from the womb: thou art my God from my mother’s belly.

Psalms 22:11 Be not far from me; for trouble is near; for there is none to help.

Psalms 22:12 Many bulls have compassed me: strong bulls of Bashan have beset me round.

Psalms 22:13 They gaped upon me with their mouths, as a ravening and a roaring lion.

Psalms 22:14 I am poured out like water, and all my bones are out of joint: my heart is like wax; it is melted in the midst of my bowels.

Psalms 22:15 My strength is dried up like a potsherd; and my tongue cleaveth to my jaws; and thou hast brought me into the dust of death.

Psalms 22:16 For dogs have compassed me: the assembly of the wicked have inclosed me: they pierced my hands and my feet.

Psalms 22:17 I may tell all my bones: they look and stare upon me.

Psalms 22:18 They part my garments among them, and cast lots upon my vesture.

Psalms 22:19 But be not thou far from me, O Lord: O my strength, haste thee to help me.

Psalms 22:20 Deliver my soul from the sword; my darling from the power of the dog.

Psalms 22:21 Save me from the lion’s mouth: for thou hast heard me from the horns of the unicorns.

Psalms 22:22 I will declare thy name unto my brethren: in the midst of the congregation will I praise thee.

Psalms 22:23 Ye that fear the Lord, praise him; all ye the seed of Jacob, glorify him; and fear him, all ye the seed of Israel.

Psalms 22:24 For he hath not despised nor abhorred the affliction of the afflicted; neither hath he hid his face from him; but when he cried unto him, he heard.

Psalms 22:25 My praise shall be of thee in the great congregation: I will pay my vows before them that fear him.

Psalms 22:26 The meek shall eat and be satisfied: they shall praise the Lord that seek him: your heart shall live for ever.

Psalms 22:27 All the ends of the world shall remember and turn unto the Lord: and all the kindreds of the nations shall worship before thee.

Psalms 22:28 For the kingdom is the Lord’s: and he is the governor among the nations.

Psalms 22:29 All they that be fat upon earth shall eat and worship: all they that go down to the dust shall bow before him: and none can keep alive his own soul.

Psalms 22:30 A seed shall serve him; it shall be accounted to the Lord for a generation.

Psalms 22:31 They shall come, and shall declare his righteousness unto a people that shall be born, that he hath done this.
