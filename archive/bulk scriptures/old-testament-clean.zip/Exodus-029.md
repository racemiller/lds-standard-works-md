# Exodus 29

Exodus 29 (summary): Aaron and his sons are to be washed, anointed, and consecrated—Various sacrificial rites are to be performed—Atonement is to be made for the sins of the people—The Lord promises to dwell among them.

Exodus 29:1 And this is the thing that thou shalt do unto them to hallow them, to minister unto me in the priest’s office: Take one young bullock, and two rams without blemish,

Exodus 29:2 And unleavened bread, and cakes unleavened tempered with oil, and wafers unleavened anointed with oil: of wheaten flour shalt thou make them.

Exodus 29:3 And thou shalt put them into one basket, and bring them in the basket, with the bullock and the two rams.

Exodus 29:4 And Aaron and his sons thou shalt bring unto the door of the tabernacle of the congregation, and shalt wash them with water.

Exodus 29:5 And thou shalt take the garments, and put upon Aaron the coat, and the robe of the ephod, and the ephod, and the breastplate, and gird him with the curious girdle of the ephod:

Exodus 29:6 And thou shalt put the mitre upon his head, and put the holy crown upon the mitre.

Exodus 29:7 Then shalt thou take the anointing oil, and pour it upon his head, and anoint him.

Exodus 29:8 And thou shalt bring his sons, and put coats upon them.

Exodus 29:9 And thou shalt gird them with girdles, Aaron and his sons, and put the bonnets on them: and the priest’s office shall be theirs for a perpetual statute: and thou shalt consecrate Aaron and his sons.

Exodus 29:10 And thou shalt cause a bullock to be brought before the tabernacle of the congregation: and Aaron and his sons shall put their hands upon the head of the bullock.

Exodus 29:11 And thou shalt kill the bullock before the Lord, by the door of the tabernacle of the congregation.

Exodus 29:12 And thou shalt take of the blood of the bullock, and put it upon the horns of the altar with thy finger, and pour all the blood beside the bottom of the altar.

Exodus 29:13 And thou shalt take all the fat that covereth the inwards, and the caul that is above the liver, and the two kidneys, and the fat that is upon them, and burn them upon the altar.

Exodus 29:14 But the flesh of the bullock, and his skin, and his dung, shalt thou burn with fire without the camp: it is a sin offering.

Exodus 29:15 Thou shalt also take one ram; and Aaron and his sons shall put their hands upon the head of the ram.

Exodus 29:16 And thou shalt slay the ram, and thou shalt take his blood, and sprinkle it round about upon the altar.

Exodus 29:17 And thou shalt cut the ram in pieces, and wash the inwards of him, and his legs, and put them unto his pieces, and unto his head.

Exodus 29:18 And thou shalt burn the whole ram upon the altar: it is a burnt offering unto the Lord: it is a sweet savour, an offering made by fire unto the Lord.

Exodus 29:19 And thou shalt take the other ram; and Aaron and his sons shall put their hands upon the head of the ram.

Exodus 29:20 Then shalt thou kill the ram, and take of his blood, and put it upon the tip of the right ear of Aaron, and upon the tip of the right ear of his sons, and upon the thumb of their right hand, and upon the great toe of their right foot, and sprinkle the blood upon the altar round about.

Exodus 29:21 And thou shalt take of the blood that is upon the altar, and of the anointing oil, and sprinkle it upon Aaron, and upon his garments, and upon his sons, and upon the garments of his sons with him: and he shall be hallowed, and his garments, and his sons, and his sons’ garments with him.

Exodus 29:22 Also thou shalt take of the ram the fat and the rump, and the fat that covereth the inwards, and the caul above the liver, and the two kidneys, and the fat that is upon them, and the right shoulder; for it is a ram of consecration:

Exodus 29:23 And one loaf of bread, and one cake of oiled bread, and one wafer out of the basket of the unleavened bread that is before the Lord:

Exodus 29:24 And thou shalt put all in the hands of Aaron, and in the hands of his sons; and shalt wave them for a wave offering before the Lord.

Exodus 29:25 And thou shalt receive them of their hands, and burn them upon the altar for a burnt offering, for a sweet savour before the Lord: it is an offering made by fire unto the Lord.

Exodus 29:26 And thou shalt take the breast of the ram of Aaron’s consecration, and wave it for a wave offering before the Lord: and it shall be thy part.

Exodus 29:27 And thou shalt sanctify the breast of the wave offering, and the shoulder of the heave offering, which is waved, and which is heaved up, of the ram of the consecration, even of that which is for Aaron, and of that which is for his sons:

Exodus 29:28 And it shall be Aaron’s and his sons’ by a statute for ever from the children of Israel: for it is an heave offering: and it shall be an heave offering from the children of Israel of the sacrifice of their peace offerings, even their heave offering unto the Lord.

Exodus 29:29 And the holy garments of Aaron shall be his sons’ after him, to be anointed therein, and to be consecrated in them.

Exodus 29:30 And that son that is priest in his stead shall put them on seven days, when he cometh into the tabernacle of the congregation to minister in the holy place.

Exodus 29:31 And thou shalt take the ram of the consecration, and seethe his flesh in the holy place.

Exodus 29:32 And Aaron and his sons shall eat the flesh of the ram, and the bread that is in the basket, by the door of the tabernacle of the congregation.

Exodus 29:33 And they shall eat those things wherewith the atonement was made, to consecrate and to sanctify them: but a stranger shall not eat thereof, because they are holy.

Exodus 29:34 And if ought of the flesh of the consecrations, or of the bread, remain unto the morning, then thou shalt burn the remainder with fire: it shall not be eaten, because it is holy.

Exodus 29:35 And thus shalt thou do unto Aaron, and to his sons, according to all things which I have commanded thee: seven days shalt thou consecrate them.

Exodus 29:36 And thou shalt offer every day a bullock for a sin offering for atonement: and thou shalt cleanse the altar, when thou hast made an atonement for it, and thou shalt anoint it, to sanctify it.

Exodus 29:37 Seven days thou shalt make an atonement for the altar, and sanctify it; and it shall be an altar most holy: whatsoever toucheth the altar shall be holy.

Exodus 29:38 Now this is that which thou shalt offer upon the altar; two lambs of the first year day by day continually.

Exodus 29:39 The one lamb thou shalt offer in the morning; and the other lamb thou shalt offer at even:

Exodus 29:40 And with the one lamb a tenth deal of flour mingled with the fourth part of an hin of beaten oil; and the fourth part of an hin of wine for a drink offering.

Exodus 29:41 And the other lamb thou shalt offer at even, and shalt do thereto according to the meat offering of the morning, and according to the drink offering thereof, for a sweet savour, an offering made by fire unto the Lord.

Exodus 29:42 This shall be a continual burnt offering throughout your generations at the door of the tabernacle of the congregation before the Lord: where I will meet you, to speak there unto thee.

Exodus 29:43 And there I will meet with the children of Israel, and the tabernacle shall be sanctified by my glory.

Exodus 29:44 And I will sanctify the tabernacle of the congregation, and the altar: I will sanctify also both Aaron and his sons, to minister to me in the priest’s office.

Exodus 29:45 And I will dwell among the children of Israel, and will be their God.

Exodus 29:46 And they shall know that I am the Lord their God, that brought them forth out of the land of Egypt, that I may dwell among them: I am the Lord their God.
