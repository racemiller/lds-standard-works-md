# Jeremiah 11

Jeremiah 11 (summary): The people of Judah are cursed for breaking the covenant of obedience—The Lord will not hear their prayers.

Jeremiah 11:1 The word that came to Jeremiah from the Lord, saying,

Jeremiah 11:2 Hear ye the words of this covenant, and speak unto the men of Judah, and to the inhabitants of Jerusalem;

Jeremiah 11:3 And say thou unto them, Thus saith the Lord God of Israel; Cursed be the man that obeyeth not the words of this covenant,

Jeremiah 11:4 Which I commanded your fathers in the day that I brought them forth out of the land of Egypt, from the iron furnace, saying, Obey my voice, and do them, according to all which I command you: so shall ye be my people, and I will be your God:

Jeremiah 11:5 That I may perform the oath which I have sworn unto your fathers, to give them a land flowing with milk and honey, as it is this day. Then answered I, and said, So be it, O Lord.

Jeremiah 11:6 Then the Lord said unto me, Proclaim all these words in the cities of Judah, and in the streets of Jerusalem, saying, Hear ye the words of this covenant, and do them.

Jeremiah 11:7 For I earnestly protested unto your fathers in the day that I brought them up out of the land of Egypt, even unto this day, rising early and protesting, saying, Obey my voice.

Jeremiah 11:8 Yet they obeyed not, nor inclined their ear, but walked every one in the imagination of their evil heart: therefore I will bring upon them all the words of this covenant, which I commanded them to do; but they did them not.

Jeremiah 11:9 And the Lord said unto me, A conspiracy is found among the men of Judah, and among the inhabitants of Jerusalem.

Jeremiah 11:10 They are turned back to the iniquities of their forefathers, which refused to hear my words; and they went after other gods to serve them: the house of Israel and the house of Judah have broken my covenant which I made with their fathers.

Jeremiah 11:11 Therefore thus saith the Lord, Behold, I will bring evil upon them, which they shall not be able to escape; and though they shall cry unto me, I will not hearken unto them.

Jeremiah 11:12 Then shall the cities of Judah and inhabitants of Jerusalem go, and cry unto the gods unto whom they offer incense: but they shall not save them at all in the time of their trouble.

Jeremiah 11:13 For according to the number of thy cities were thy gods, O Judah; and according to the number of the streets of Jerusalem have ye set up altars to that shameful thing, even altars to burn incense unto Baal.

Jeremiah 11:14 Therefore pray not thou for this people, neither lift up a cry or prayer for them: for I will not hear them in the time that they cry unto me for their trouble.

Jeremiah 11:15 What hath my beloved to do in mine house, seeing she hath wrought lewdness with many, and the holy flesh is passed from thee? when thou doest evil, then thou rejoicest.

Jeremiah 11:16 The Lord called thy name, A green olive tree, fair, and of goodly fruit: with the noise of a great tumult he hath kindled fire upon it, and the branches of it are broken.

Jeremiah 11:17 For the Lord of hosts, that planted thee, hath pronounced evil against thee, for the evil of the house of Israel and of the house of Judah, which they have done against themselves to provoke me to anger in offering incense unto Baal.

Jeremiah 11:18 And the Lord hath given me knowledge of it, and I know it: then thou shewedst me their doings.

Jeremiah 11:19 But I was like a lamb or an ox that is brought to the slaughter; and I knew not that they had devised devices against me, saying, Let us destroy the tree with the fruit thereof, and let us cut him off from the land of the living, that his name may be no more remembered.

Jeremiah 11:20 But, O Lord of hosts, that judgest righteously, that triest the reins and the heart, let me see thy vengeance on them: for unto thee have I revealed my cause.

Jeremiah 11:21 Therefore thus saith the Lord of the men of Anathoth, that seek thy life, saying, Prophesy not in the name of the Lord, that thou die not by our hand:

Jeremiah 11:22 Therefore thus saith the Lord of hosts, Behold, I will punish them: the young men shall die by the sword; their sons and their daughters shall die by famine:

Jeremiah 11:23 And there shall be no remnant of them: for I will bring evil upon the men of Anathoth, even the year of their visitation.
