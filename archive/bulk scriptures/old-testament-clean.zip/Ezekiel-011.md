# Ezekiel 11

Ezekiel 11 (summary): He sees in vision the destruction of Jerusalem and the captivity of the Jews—He prophesies the latter-day gathering of Israel.

Ezekiel 11:1 Moreover the spirit lifted me up, and brought me unto the east gate of the Lord’s house, which looketh eastward: and behold at the door of the gate five and twenty men; among whom I saw Jaazaniah the son of Azur, and Pelatiah the son of Benaiah, princes of the people.

Ezekiel 11:2 Then said he unto me, Son of man, these are the men that devise mischief, and give wicked counsel in this city:

Ezekiel 11:3 Which say, It is not near; let us build houses: this city is the caldron, and we be the flesh.

Ezekiel 11:4 Therefore prophesy against them, prophesy, O son of man.

Ezekiel 11:5 And the Spirit of the Lord fell upon me, and said unto me, Speak; Thus saith the Lord; Thus have ye said, O house of Israel: for I know the things that come into your mind, every one of them.

Ezekiel 11:6 Ye have multiplied your slain in this city, and ye have filled the streets thereof with the slain.

Ezekiel 11:7 Therefore thus saith the Lord God; Your slain whom ye have laid in the midst of it, they are the flesh, and this city is the caldron: but I will bring you forth out of the midst of it.

Ezekiel 11:8 Ye have feared the sword; and I will bring a sword upon you, saith the Lord God.

Ezekiel 11:9 And I will bring you out of the midst thereof, and deliver you into the hands of strangers, and will execute judgments among you.

Ezekiel 11:10 Ye shall fall by the sword; I will judge you in the border of Israel; and ye shall know that I am the Lord.

Ezekiel 11:11 This city shall not be your caldron, neither shall ye be the flesh in the midst thereof; but I will judge you in the border of Israel:

Ezekiel 11:12 And ye shall know that I am the Lord: for ye have not walked in my statutes, neither executed my judgments, but have done after the manners of the heathen that are round about you.

Ezekiel 11:13 And it came to pass, when I prophesied, that Pelatiah the son of Benaiah died. Then fell I down upon my face, and cried with a loud voice, and said, Ah Lord God! wilt thou make a full end of the remnant of Israel?

Ezekiel 11:14 Again the word of the Lord came unto me, saying,

Ezekiel 11:15 Son of man, thy brethren, even thy brethren, the men of thy kindred, and all the house of Israel wholly, are they unto whom the inhabitants of Jerusalem have said, Get you far from the Lord: unto us is this land given in possession.

Ezekiel 11:16 Therefore say, Thus saith the Lord God; Although I have cast them far off among the heathen, and although I have scattered them among the countries, yet will I be to them as a little sanctuary in the countries where they shall come.

Ezekiel 11:17 Therefore say, Thus saith the Lord God; I will even gather you from the people, and assemble you out of the countries where ye have been scattered, and I will give you the land of Israel.

Ezekiel 11:18 And they shall come thither, and they shall take away all the detestable things thereof and all the abominations thereof from thence.

Ezekiel 11:19 And I will give them one heart, and I will put a new spirit within you; and I will take the stony heart out of their flesh, and will give them an heart of flesh:

Ezekiel 11:20 That they may walk in my statutes, and keep mine ordinances, and do them: and they shall be my people, and I will be their God.

Ezekiel 11:21 But as for them whose heart walketh after the heart of their detestable things and their abominations, I will recompense their way upon their own heads, saith the Lord God.

Ezekiel 11:22 Then did the cherubims lift up their wings, and the wheels beside them; and the glory of the God of Israel was over them above.

Ezekiel 11:23 And the glory of the Lord went up from the midst of the city, and stood upon the mountain which is on the east side of the city.

Ezekiel 11:24 Afterwards the spirit took me up, and brought me in a vision by the Spirit of God into Chaldea, to them of the captivity. So the vision that I had seen went up from me.

Ezekiel 11:25 Then I spake unto them of the captivity all the things that the Lord had shewed me.
