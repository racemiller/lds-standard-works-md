# Isaiah 46

Isaiah 46 (summary): Idols are not to be compared with the Lord—He alone is God and will save Israel.

Isaiah 46:1 Bel boweth down, Nebo stoopeth, their idols were upon the beasts, and upon the cattle: your carriages were heavy loaden; they are a burden to the weary beast.

Isaiah 46:2 They stoop, they bow down together; they could not deliver the burden, but themselves are gone into captivity.

Isaiah 46:3 Hearken unto me, O house of Jacob, and all the remnant of the house of Israel, which are borne by me from the belly, which are carried from the womb:

Isaiah 46:4 And even to your old age I am he; and even to hoar hairs will I carry you: I have made, and I will bear; even I will carry, and will deliver you.

Isaiah 46:5 To whom will ye liken me, and make me equal, and compare me, that we may be like?

Isaiah 46:6 They lavish gold out of the bag, and weigh silver in the balance, and hire a goldsmith; and he maketh it a god: they fall down, yea, they worship.

Isaiah 46:7 They bear him upon the shoulder, they carry him, and set him in his place, and he standeth; from his place shall he not remove: yea, one shall cry unto him, yet can he not answer, nor save him out of his trouble.

Isaiah 46:8 Remember this, and shew yourselves men: bring it again to mind, O ye transgressors.

Isaiah 46:9 Remember the former things of old: for I am God, and there is none else; I am God, and there is none like me,

Isaiah 46:10 Declaring the end from the beginning, and from ancient times the things that are not yet done, saying, My counsel shall stand, and I will do all my pleasure:

Isaiah 46:11 Calling a ravenous bird from the east, the man that executeth my counsel from a far country: yea, I have spoken it, I will also bring it to pass; I have purposed it, I will also do it.

Isaiah 46:12 Hearken unto me, ye stouthearted, that are far from righteousness:

Isaiah 46:13 I bring near my righteousness; it shall not be far off, and my salvation shall not tarry: and I will place salvation in Zion for Israel my glory.
