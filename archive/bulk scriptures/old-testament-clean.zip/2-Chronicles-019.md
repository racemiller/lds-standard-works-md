# 2 Chronicles 19

2 Chronicles 19 (summary): Jehoshaphat is rebuked for helping ungodly Ahab—He helps the people return to the Lord, sets up judges, and administers justice.

2 Chronicles 19:1 And Jehoshaphat the king of Judah returned to his house in peace to Jerusalem.

2 Chronicles 19:2 And Jehu the son of Hanani the seer went out to meet him, and said to king Jehoshaphat, Shouldest thou help the ungodly, and love them that hate the Lord? therefore is wrath upon thee from before the Lord.

2 Chronicles 19:3 Nevertheless there are good things found in thee, in that thou hast taken away the groves out of the land, and hast prepared thine heart to seek God.

2 Chronicles 19:4 And Jehoshaphat dwelt at Jerusalem: and he went out again through the people from Beer-sheba to mount Ephraim, and brought them back unto the Lord God of their fathers.

2 Chronicles 19:5 And he set judges in the land throughout all the fenced cities of Judah, city by city,

2 Chronicles 19:6 And said to the judges, Take heed what ye do: for ye judge not for man, but for the Lord, who is with you in the judgment.

2 Chronicles 19:7 Wherefore now let the fear of the Lord be upon you; take heed and do it: for there is no iniquity with the Lord our God, nor respect of persons, nor taking of gifts.

2 Chronicles 19:8 Moreover in Jerusalem did Jehoshaphat set of the Levites, and of the priests, and of the chief of the fathers of Israel, for the judgment of the Lord, and for controversies, when they returned to Jerusalem.

2 Chronicles 19:9 And he charged them, saying, Thus shall ye do in the fear of the Lord, faithfully, and with a perfect heart.

2 Chronicles 19:10 And what cause soever shall come to you of your brethren that dwell in their cities, between blood and blood, between law and commandment, statutes and judgments, ye shall even warn them that they trespass not against the Lord, and so wrath come upon you, and upon your brethren: this do, and ye shall not trespass.

2 Chronicles 19:11 And, behold, Amariah the chief priest is over you in all matters of the Lord; and Zebadiah the son of Ishmael, the ruler of the house of Judah, for all the king’s matters: also the Levites shall be officers before you. Deal courageously, and the Lord shall be with the good.
