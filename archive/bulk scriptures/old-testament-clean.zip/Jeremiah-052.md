# Jeremiah 52

Jeremiah 52 (summary): Jerusalem is besieged and taken by the Chaldeans—Many people and the vessels of the house of the Lord are carried into Babylon.

Jeremiah 52:1 Zedekiah was one and twenty years old when he began to reign, and he reigned eleven years in Jerusalem. And his mother’s name was Hamutal the daughter of Jeremiah of Libnah.

Jeremiah 52:2 And he did that which was evil in the eyes of the Lord, according to all that Jehoiakim had done.

Jeremiah 52:3 For through the anger of the Lord it came to pass in Jerusalem and Judah, till he had cast them out from his presence, that Zedekiah rebelled against the king of Babylon.

Jeremiah 52:4 And it came to pass in the ninth year of his reign, in the tenth month, in the tenth day of the month, that Nebuchadrezzar king of Babylon came, he and all his army, against Jerusalem, and pitched against it, and built forts against it round about.

Jeremiah 52:5 So the city was besieged unto the eleventh year of king Zedekiah.

Jeremiah 52:6 And in the fourth month, in the ninth day of the month, the famine was sore in the city, so that there was no bread for the people of the land.

Jeremiah 52:7 Then the city was broken up, and all the men of war fled, and went forth out of the city by night by the way of the gate between the two walls, which was by the king’s garden; (now the Chaldeans were by the city round about:) and they went by the way of the plain.

Jeremiah 52:8 But the army of the Chaldeans pursued after the king, and overtook Zedekiah in the plains of Jericho; and all his army was scattered from him.

Jeremiah 52:9 Then they took the king, and carried him up unto the king of Babylon to Riblah in the land of Hamath; where he gave judgment upon him.

Jeremiah 52:10 And the king of Babylon slew the sons of Zedekiah before his eyes: he slew also all the princes of Judah in Riblah.

Jeremiah 52:11 Then he put out the eyes of Zedekiah; and the king of Babylon bound him in chains, and carried him to Babylon, and put him in prison till the day of his death.

Jeremiah 52:12 Now in the fifth month, in the tenth day of the month, which was the nineteenth year of Nebuchadrezzar king of Babylon, came Nebuzar-adan, captain of the guard, which served the king of Babylon, into Jerusalem,

Jeremiah 52:13 And burned the house of the Lord, and the king’s house; and all the houses of Jerusalem, and all the houses of the great men, burned he with fire:

Jeremiah 52:14 And all the army of the Chaldeans, that were with the captain of the guard, brake down all the walls of Jerusalem round about.

Jeremiah 52:15 Then Nebuzar-adan the captain of the guard carried away captive certain of the poor of the people, and the residue of the people that remained in the city, and those that fell away, that fell to the king of Babylon, and the rest of the multitude.

Jeremiah 52:16 But Nebuzar-adan the captain of the guard left certain of the poor of the land for vinedressers and for husbandmen.

Jeremiah 52:17 Also the pillars of brass that were in the house of the Lord, and the bases, and the brasen sea that was in the house of the Lord, the Chaldeans brake, and carried all the brass of them to Babylon.

Jeremiah 52:18 The caldrons also, and the shovels, and the snuffers, and the bowls, and the spoons, and all the vessels of brass wherewith they ministered, took they away.

Jeremiah 52:19 And the basins, and the firepans, and the bowls, and the caldrons, and the candlesticks, and the spoons, and the cups; that which was of gold in gold, and that which was of silver in silver, took the captain of the guard away.

Jeremiah 52:20 The two pillars, one sea, and twelve brasen bulls that were under the bases, which king Solomon had made in the house of the Lord: the brass of all these vessels was without weight.

Jeremiah 52:21 And concerning the pillars, the height of one pillar was eighteen cubits; and a fillet of twelve cubits did compass it; and the thickness thereof was four fingers: it was hollow.

Jeremiah 52:22 And a chapiter of brass was upon it; and the height of one chapiter was five cubits, with network and pomegranates upon the chapiters round about, all of brass. The second pillar also and the pomegranates were like unto these.

Jeremiah 52:23 And there were ninety and six pomegranates on a side; and all the pomegranates upon the network were an hundred round about.

Jeremiah 52:24 And the captain of the guard took Seraiah the chief priest, and Zephaniah the second priest, and the three keepers of the door:

Jeremiah 52:25 He took also out of the city an eunuch, which had the charge of the men of war; and seven men of them that were near the king’s person, which were found in the city; and the principal scribe of the host, who mustered the people of the land; and threescore men of the people of the land, that were found in the midst of the city.

Jeremiah 52:26 So Nebuzar-adan the captain of the guard took them, and brought them to the king of Babylon to Riblah.

Jeremiah 52:27 And the king of Babylon smote them, and put them to death in Riblah in the land of Hamath. Thus Judah was carried away captive out of his own land.

Jeremiah 52:28 This is the people whom Nebuchadrezzar carried away captive: in the seventh year three thousand Jews and three and twenty:

Jeremiah 52:29 In the eighteenth year of Nebuchadrezzar he carried away captive from Jerusalem eight hundred thirty and two persons:

Jeremiah 52:30 In the three and twentieth year of Nebuchadrezzar Nebuzar-adan the captain of the guard carried away captive of the Jews seven hundred forty and five persons: all the persons were four thousand and six hundred.

Jeremiah 52:31 And it came to pass in the seven and thirtieth year of the captivity of Jehoiachin king of Judah, in the twelfth month, in the five and twentieth day of the month, that Evil-merodach king of Babylon in the first year of his reign lifted up the head of Jehoiachin king of Judah, and brought him forth out of prison,

Jeremiah 52:32 And spake kindly unto him, and set his throne above the throne of the kings that were with him in Babylon,

Jeremiah 52:33 And changed his prison garments: and he did continually eat bread before him all the days of his life.

Jeremiah 52:34 And for his diet, there was a continual diet given him of the king of Babylon, every day a portion until the day of his death, all the days of his life.
