# Isaiah 7

Isaiah 7 (summary): Ephraim and Syria wage war against Judah—Christ will be born of a virgin—Compare 2 Nephi 17.

Isaiah 7:1 And it came to pass in the days of Ahaz the son of Jotham, the son of Uzziah, king of Judah, that Rezin the king of Syria, and Pekah the son of Remaliah, king of Israel, went up toward Jerusalem to war against it, but could not prevail against it.

Isaiah 7:2 And it was told the house of David, saying, Syria is confederate with Ephraim. And his heart was moved, and the heart of his people, as the trees of the wood are moved with the wind.

Isaiah 7:3 Then said the Lord unto Isaiah, Go forth now to meet Ahaz, thou, and Shear-jashub thy son, at the end of the conduit of the upper pool in the highway of the fuller’s field;

Isaiah 7:4 And say unto him, Take heed, and be quiet; fear not, neither be fainthearted for the two tails of these smoking firebrands, for the fierce anger of Rezin with Syria, and of the son of Remaliah.

Isaiah 7:5 Because Syria, Ephraim, and the son of Remaliah, have taken evil counsel against thee, saying,

Isaiah 7:6 Let us go up against Judah, and vex it, and let us make a breach therein for us, and set a king in the midst of it, even the son of Tabeal:

Isaiah 7:7 Thus saith the Lord God, It shall not stand, neither shall it come to pass.

Isaiah 7:8 For the head of Syria is Damascus, and the head of Damascus is Rezin; and within threescore and five years shall Ephraim be broken, that it be not a people.

Isaiah 7:9 And the head of Ephraim is Samaria, and the head of Samaria is Remaliah’s son. If ye will not believe, surely ye shall not be established.

Isaiah 7:10 Moreover the Lord spake again unto Ahaz, saying,

Isaiah 7:11 Ask thee a sign of the Lord thy God; ask it either in the depth, or in the height above.

Isaiah 7:12 But Ahaz said, I will not ask, neither will I tempt the Lord.

Isaiah 7:13 And he said, Hear ye now, O house of David; Is it a small thing for you to weary men, but will ye weary my God also?

Isaiah 7:14 Therefore the Lord himself shall give you a sign; Behold, a virgin shall conceive, and bear a son, and shall call his name Immanuel.

Isaiah 7:15 Butter and honey shall he eat, that he may know to refuse the evil, and choose the good.

Isaiah 7:16 For before the child shall know to refuse the evil, and choose the good, the land that thou abhorrest shall be forsaken of both her kings.

Isaiah 7:17 The Lord shall bring upon thee, and upon thy people, and upon thy father’s house, days that have not come, from the day that Ephraim departed from Judah; even the king of Assyria.

Isaiah 7:18 And it shall come to pass in that day, that the Lord shall hiss for the fly that is in the uttermost part of the rivers of Egypt, and for the bee that is in the land of Assyria.

Isaiah 7:19 And they shall come, and shall rest all of them in the desolate valleys, and in the holes of the rocks, and upon all thorns, and upon all bushes.

Isaiah 7:20 In the same day shall the Lord shave with a razor that is hired, namely, by them beyond the river, by the king of Assyria, the head, and the hair of the feet: and it shall also consume the beard.

Isaiah 7:21 And it shall come to pass in that day, that a man shall nourish a young cow, and two sheep;

Isaiah 7:22 And it shall come to pass, for the abundance of milk that they shall give he shall eat butter: for butter and honey shall every one eat that is left in the land.

Isaiah 7:23 And it shall come to pass in that day, that every place shall be, where there were a thousand vines at a thousand silverlings, it shall even be for briers and thorns.

Isaiah 7:24 With arrows and with bows shall men come thither; because all the land shall become briers and thorns.

Isaiah 7:25 And on all hills that shall be digged with the mattock, there shall not come thither the fear of briers and thorns: but it shall be for the sending forth of oxen, and for the treading of lesser cattle.
