# Ezekiel 20

Ezekiel 20 (summary): From the time of their deliverance from Egypt to the day of Ezekiel, the people of Israel have rebelled and failed to keep the commandments—In the last days, the Lord will gather Israel and restore His gospel covenant.

Ezekiel 20:1 And it came to pass in the seventh year, in the fifth month, the tenth day of the month, that certain of the elders of Israel came to inquire of the Lord, and sat before me.

Ezekiel 20:2 Then came the word of the Lord unto me, saying,

Ezekiel 20:3 Son of man, speak unto the elders of Israel, and say unto them, Thus saith the Lord God; Are ye come to inquire of me? As I live, saith the Lord God, I will not be inquired of by you.

Ezekiel 20:4 Wilt thou judge them, son of man, wilt thou judge them? cause them to know the abominations of their fathers:

Ezekiel 20:5 And say unto them, Thus saith the Lord God; In the day when I chose Israel, and lifted up mine hand unto the seed of the house of Jacob, and made myself known unto them in the land of Egypt, when I lifted up mine hand unto them, saying, I am the Lord your God;

Ezekiel 20:6 In the day that I lifted up mine hand unto them, to bring them forth of the land of Egypt into a land that I had espied for them, flowing with milk and honey, which is the glory of all lands:

Ezekiel 20:7 Then said I unto them, Cast ye away every man the abominations of his eyes, and defile not yourselves with the idols of Egypt: I am the Lord your God.

Ezekiel 20:8 But they rebelled against me, and would not hearken unto me: they did not every man cast away the abominations of their eyes, neither did they forsake the idols of Egypt: then I said, I will pour out my fury upon them, to accomplish my anger against them in the midst of the land of Egypt.

Ezekiel 20:9 But I wrought for my name’s sake, that it should not be polluted before the heathen, among whom they were, in whose sight I made myself known unto them, in bringing them forth out of the land of Egypt.

Ezekiel 20:10 Wherefore I caused them to go forth out of the land of Egypt, and brought them into the wilderness.

Ezekiel 20:11 And I gave them my statutes, and shewed them my judgments, which if a man do, he shall even live in them.

Ezekiel 20:12 Moreover also I gave them my sabbaths, to be a sign between me and them, that they might know that I am the Lord that sanctify them.

Ezekiel 20:13 But the house of Israel rebelled against me in the wilderness: they walked not in my statutes, and they despised my judgments, which if a man do, he shall even live in them; and my sabbaths they greatly polluted: then I said, I would pour out my fury upon them in the wilderness, to consume them.

Ezekiel 20:14 But I wrought for my name’s sake, that it should not be polluted before the heathen, in whose sight I brought them out.

Ezekiel 20:15 Yet also I lifted up my hand unto them in the wilderness, that I would not bring them into the land which I had given them, flowing with milk and honey, which is the glory of all lands;

Ezekiel 20:16 Because they despised my judgments, and walked not in my statutes, but polluted my sabbaths: for their heart went after their idols.

Ezekiel 20:17 Nevertheless mine eye spared them from destroying them, neither did I make an end of them in the wilderness.

Ezekiel 20:18 But I said unto their children in the wilderness, Walk ye not in the statutes of your fathers, neither observe their judgments, nor defile yourselves with their idols:

Ezekiel 20:19 I am the Lord your God; walk in my statutes, and keep my judgments, and do them;

Ezekiel 20:20 And hallow my sabbaths; and they shall be a sign between me and you, that ye may know that I am the Lord your God.

Ezekiel 20:21 Notwithstanding the children rebelled against me: they walked not in my statutes, neither kept my judgments to do them, which if a man do, he shall even live in them; they polluted my sabbaths: then I said, I would pour out my fury upon them, to accomplish my anger against them in the wilderness.

Ezekiel 20:22 Nevertheless I withdrew mine hand, and wrought for my name’s sake, that it should not be polluted in the sight of the heathen, in whose sight I brought them forth.

Ezekiel 20:23 I lifted up mine hand unto them also in the wilderness, that I would scatter them among the heathen, and disperse them through the countries;

Ezekiel 20:24 Because they had not executed my judgments, but had despised my statutes, and had polluted my sabbaths, and their eyes were after their fathers’ idols.

Ezekiel 20:25 Wherefore I gave them also statutes that were not good, and judgments whereby they should not live;

Ezekiel 20:26 And I polluted them in their own gifts, in that they caused to pass through the fire all that openeth the womb, that I might make them desolate, to the end that they might know that I am the Lord.

Ezekiel 20:27 Therefore, son of man, speak unto the house of Israel, and say unto them, Thus saith the Lord God; Yet in this your fathers have blasphemed me, in that they have committed a trespass against me.

Ezekiel 20:28 For when I had brought them into the land, for the which I lifted up mine hand to give it to them, then they saw every high hill, and all the thick trees, and they offered there their sacrifices, and there they presented the provocation of their offering: there also they made their sweet savour, and poured out there their drink offerings.

Ezekiel 20:29 Then I said unto them, What is the high place whereunto ye go? And the name thereof is called Bamah unto this day.

Ezekiel 20:30 Wherefore say unto the house of Israel, Thus saith the Lord God; Are ye polluted after the manner of your fathers? and commit ye whoredom after their abominations?

Ezekiel 20:31 For when ye offer your gifts, when ye make your sons to pass through the fire, ye pollute yourselves with all your idols, even unto this day: and shall I be inquired of by you, O house of Israel? As I live, saith the Lord God, I will not be inquired of by you.

Ezekiel 20:32 And that which cometh into your mind shall not be at all, that ye say, We will be as the heathen, as the families of the countries, to serve wood and stone.

Ezekiel 20:33 As I live, saith the Lord God, surely with a mighty hand, and with a stretched out arm, and with fury poured out, will I rule over you:

Ezekiel 20:34 And I will bring you out from the people, and will gather you out of the countries wherein ye are scattered, with a mighty hand, and with a stretched out arm, and with fury poured out.

Ezekiel 20:35 And I will bring you into the wilderness of the people, and there will I plead with you face to face.

Ezekiel 20:36 Like as I pleaded with your fathers in the wilderness of the land of Egypt, so will I plead with you, saith the Lord God.

Ezekiel 20:37 And I will cause you to pass under the rod, and I will bring you into the bond of the covenant:

Ezekiel 20:38 And I will purge out from among you the rebels, and them that transgress against me: I will bring them forth out of the country where they sojourn, and they shall not enter into the land of Israel: and ye shall know that I am the Lord.

Ezekiel 20:39 As for you, O house of Israel, thus saith the Lord God; Go ye, serve ye every one his idols, and hereafter also, if ye will not hearken unto me: but pollute ye my holy name no more with your gifts, and with your idols.

Ezekiel 20:40 For in mine holy mountain, in the mountain of the height of Israel, saith the Lord God, there shall all the house of Israel, all of them in the land, serve me: there will I accept them, and there will I require your offerings, and the firstfruits of your oblations, with all your holy things.

Ezekiel 20:41 I will accept you with your sweet savour, when I bring you out from the people, and gather you out of the countries wherein ye have been scattered; and I will be sanctified in you before the heathen.

Ezekiel 20:42 And ye shall know that I am the Lord, when I shall bring you into the land of Israel, into the country for the which I lifted up mine hand to give it to your fathers.

Ezekiel 20:43 And there shall ye remember your ways, and all your doings, wherein ye have been defiled; and ye shall lothe yourselves in your own sight for all your evils that ye have committed.

Ezekiel 20:44 And ye shall know that I am the Lord, when I have wrought with you for my name’s sake, not according to your wicked ways, nor according to your corrupt doings, O ye house of Israel, saith the Lord God.

Ezekiel 20:45 Moreover the word of the Lord came unto me, saying,

Ezekiel 20:46 Son of man, set thy face toward the south, and drop thy word toward the south, and prophesy against the forest of the south field;

Ezekiel 20:47 And say to the forest of the south, Hear the word of the Lord; Thus saith the Lord God; Behold, I will kindle a fire in thee, and it shall devour every green tree in thee, and every dry tree: the flaming flame shall not be quenched, and all faces from the south to the north shall be burned therein.

Ezekiel 20:48 And all flesh shall see that I the Lord have kindled it: it shall not be quenched.

Ezekiel 20:49 Then said I, Ah Lord God! they say of me, Doth he not speak parables?
