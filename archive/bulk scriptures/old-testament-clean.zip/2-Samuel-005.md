# 2 Samuel 5

2 Samuel 5 (summary): All Israel anoints David king—He takes Jerusalem and is blessed of the Lord—He conquers the Philistines.

2 Samuel 5:1 Then came all the tribes of Israel to David unto Hebron, and spake, saying, Behold, we are thy bone and thy flesh.

2 Samuel 5:2 Also in time past, when Saul was king over us, thou wast he that leddest out and broughtest in Israel: and the Lord said to thee, Thou shalt feed my people Israel, and thou shalt be a captain over Israel.

2 Samuel 5:3 So all the elders of Israel came to the king to Hebron; and king David made a league with them in Hebron before the Lord: and they anointed David king over Israel.

2 Samuel 5:4 David was thirty years old when he began to reign, and he reigned forty years.

2 Samuel 5:5 In Hebron he reigned over Judah seven years and six months: and in Jerusalem he reigned thirty and three years over all Israel and Judah.

2 Samuel 5:6 And the king and his men went to Jerusalem unto the Jebusites, the inhabitants of the land: which spake unto David, saying, Except thou take away the blind and the lame, thou shalt not come in hither: thinking, David cannot come in hither.

2 Samuel 5:7 Nevertheless David took the strong hold of Zion: the same is the city of David.

2 Samuel 5:8 And David said on that day, Whosoever getteth up to the gutter, and smiteth the Jebusites, and the lame and the blind, that are hated of David’s soul, he shall be chief and captain. Wherefore they said, The blind and the lame shall not come into the house.

2 Samuel 5:9 So David dwelt in the fort, and called it the city of David. And David built round about from Millo and inward.

2 Samuel 5:10 And David went on, and grew great, and the Lord God of hosts was with him.

2 Samuel 5:11 And Hiram king of Tyre sent messengers to David, and cedar trees, and carpenters, and masons: and they built David an house.

2 Samuel 5:12 And David perceived that the Lord had established him king over Israel, and that he had exalted his kingdom for his people Israel’s sake.

2 Samuel 5:13 And David took him more concubines and wives out of Jerusalem, after he was come from Hebron: and there were yet sons and daughters born to David.

2 Samuel 5:14 And these be the names of those that were born unto him in Jerusalem; Shammua, and Shobab, and Nathan, and Solomon,

2 Samuel 5:15 Ibhar also, and Elishua, and Nepheg, and Japhia,

2 Samuel 5:16 And Elishama, and Eliada, and Eliphalet.

2 Samuel 5:17 But when the Philistines heard that they had anointed David king over Israel, all the Philistines came up to seek David; and David heard of it, and went down to the hold.

2 Samuel 5:18 The Philistines also came and spread themselves in the valley of Rephaim.

2 Samuel 5:19 And David inquired of the Lord, saying, Shall I go up to the Philistines? wilt thou deliver them into mine hand? And the Lord said unto David, Go up: for I will doubtless deliver the Philistines into thine hand.

2 Samuel 5:20 And David came to Baal-perazim, and David smote them there, and said, The Lord hath broken forth upon mine enemies before me, as the breach of waters. Therefore he called the name of that place Baal-perazim.

2 Samuel 5:21 And there they left their images, and David and his men burned them.

2 Samuel 5:22 And the Philistines came up yet again, and spread themselves in the valley of Rephaim.

2 Samuel 5:23 And when David inquired of the Lord, he said, Thou shalt not go up; but fetch a compass behind them, and come upon them over against the mulberry trees.

2 Samuel 5:24 And let it be, when thou hearest the sound of a going in the tops of the mulberry trees, that then thou shalt bestir thyself: for then shall the Lord go out before thee, to smite the host of the Philistines.

2 Samuel 5:25 And David did so, as the Lord had commanded him; and smote the Philistines from Geba until thou come to Gazer.
