# Deuteronomy 22

Deuteronomy 22 (summary): Moses sets forth laws pertaining to lost property, wearing of proper clothes, caring for interests of others, marrying virgins, and sexual immorality.

Deuteronomy 22:1 Thou shalt not see thy brother’s ox or his sheep go astray, and hide thyself from them: thou shalt in any case bring them again unto thy brother.

Deuteronomy 22:2 And if thy brother be not nigh unto thee, or if thou know him not, then thou shalt bring it unto thine own house, and it shall be with thee until thy brother seek after it, and thou shalt restore it to him again.

Deuteronomy 22:3 In like manner shalt thou do with his ass; and so shalt thou do with his raiment; and with all lost thing of thy brother’s, which he hath lost, and thou hast found, shalt thou do likewise: thou mayest not hide thyself.

Deuteronomy 22:4 Thou shalt not see thy brother’s ass or his ox fall down by the way, and hide thyself from them: thou shalt surely help him to lift them up again.

Deuteronomy 22:5 The woman shall not wear that which pertaineth unto a man, neither shall a man put on a woman’s garment: for all that do so are abomination unto the Lord thy God.

Deuteronomy 22:6 If a bird’s nest chance to be before thee in the way in any tree, or on the ground, whether they be young ones, or eggs, and the dam sitting upon the young, or upon the eggs, thou shalt not take the dam with the young:

Deuteronomy 22:7 But thou shalt in any wise let the dam go, and take the young to thee; that it may be well with thee, and that thou mayest prolong thy days.

Deuteronomy 22:8 When thou buildest a new house, then thou shalt make a battlement for thy roof, that thou bring not blood upon thine house, if any man fall from thence.

Deuteronomy 22:9 Thou shalt not sow thy vineyard with divers seeds: lest the fruit of thy seed which thou hast sown, and the fruit of thy vineyard, be defiled.

Deuteronomy 22:10 Thou shalt not plow with an ox and an ass together.

Deuteronomy 22:11 Thou shalt not wear a garment of divers sorts, as of woollen and linen together.

Deuteronomy 22:12 Thou shalt make thee fringes upon the four quarters of thy vesture, wherewith thou coverest thyself.

Deuteronomy 22:13 If any man take a wife, and go in unto her, and hate her,

Deuteronomy 22:14 And give occasions of speech against her, and bring up an evil name upon her, and say, I took this woman, and when I came to her, I found her not a maid:

Deuteronomy 22:15 Then shall the father of the damsel, and her mother, take and bring forth the tokens of the damsel’s virginity unto the elders of the city in the gate:

Deuteronomy 22:16 And the damsel’s father shall say unto the elders, I gave my daughter unto this man to wife, and he hateth her;

Deuteronomy 22:17 And, lo, he hath given occasions of speech against her, saying, I found not thy daughter a maid; and yet these are the tokens of my daughter’s virginity. And they shall spread the cloth before the elders of the city.

Deuteronomy 22:18 And the elders of that city shall take that man and chastise him;

Deuteronomy 22:19 And they shall amerce him in an hundred shekels of silver, and give them unto the father of the damsel, because he hath brought up an evil name upon a virgin of Israel: and she shall be his wife; he may not put her away all his days.

Deuteronomy 22:20 But if this thing be true, and the tokens of virginity be not found for the damsel:

Deuteronomy 22:21 Then they shall bring out the damsel to the door of her father’s house, and the men of her city shall stone her with stones that she die: because she hath wrought folly in Israel, to play the whore in her father’s house: so shalt thou put evil away from among you.

Deuteronomy 22:22 If a man be found lying with a woman married to an husband, then they shall both of them die, both the man that lay with the woman, and the woman: so shalt thou put away evil from Israel.

Deuteronomy 22:23 If a damsel that is a virgin be betrothed unto an husband, and a man find her in the city, and lie with her;

Deuteronomy 22:24 Then ye shall bring them both out unto the gate of that city, and ye shall stone them with stones that they die; the damsel, because she cried not, being in the city; and the man, because he hath humbled his neighbour’s wife: so thou shalt put away evil from among you.

Deuteronomy 22:25 But if a man find a betrothed damsel in the field, and the man force her, and lie with her: then the man only that lay with her shall die:

Deuteronomy 22:26 But unto the damsel thou shalt do nothing; there is in the damsel no sin worthy of death: for as when a man riseth against his neighbour, and slayeth him, even so is this matter:

Deuteronomy 22:27 For he found her in the field, and the betrothed damsel cried, and there was none to save her.

Deuteronomy 22:28 If a man find a damsel that is a virgin, which is not betrothed, and lay hold on her, and lie with her, and they be found;

Deuteronomy 22:29 Then the man that lay with her shall give unto the damsel’s father fifty shekels of silver, and she shall be his wife; because he hath humbled her, he may not put her away all his days.

Deuteronomy 22:30 A man shall not take his father’s wife, nor discover his father’s skirt.
