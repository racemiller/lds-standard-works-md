# Genesis 2

Genesis 2 (summary): The Creation is completed—God rests on the seventh day—The prior spirit creation is explained—Adam and Eve are placed in the Garden of Eden—They are forbidden to eat of the tree of knowledge of good and evil—Adam names every living creature—Adam and Eve are married by the Lord.

Genesis 2:1 Thus the heavens and the earth were finished, and all the host of them.

Genesis 2:2 And on the seventh day God ended his work which he had made; and he rested on the seventh day from all his work which he had made.

Genesis 2:3 And God blessed the seventh day, and sanctified it: because that in it he had rested from all his work which God created and made.

Genesis 2:4 These are the generations of the heavens and of the earth when they were created, in the day that the Lord God made the earth and the heavens,

Genesis 2:5 And every plant of the field before it was in the earth, and every herb of the field before it grew: for the Lord God had not caused it to rain upon the earth, and there was not a man to till the ground.

Genesis 2:6 But there went up a mist from the earth, and watered the whole face of the ground.

Genesis 2:7 And the Lord God formed man of the dust of the ground, and breathed into his nostrils the breath of life; and man became a living soul.

Genesis 2:8 And the Lord God planted a garden eastward in Eden; and there he put the man whom he had formed.

Genesis 2:9 And out of the ground made the Lord God to grow every tree that is pleasant to the sight, and good for food; the tree of life also in the midst of the garden, and the tree of knowledge of good and evil.

Genesis 2:10 And a river went out of Eden to water the garden; and from thence it was parted, and became into four heads.

Genesis 2:11 The name of the first is Pison: that is it which compasseth the whole land of Havilah, where there is gold;

Genesis 2:12 And the gold of that land is good: there is bdellium and the onyx stone.

Genesis 2:13 And the name of the second river is Gihon: the same is it that compasseth the whole land of Ethiopia.

Genesis 2:14 And the name of the third river is Hiddekel: that is it which goeth toward the east of Assyria. And the fourth river is Euphrates.

Genesis 2:15 And the Lord God took the man, and put him into the garden of Eden to dress it and to keep it.

Genesis 2:16 And the Lord God commanded the man, saying, Of every tree of the garden thou mayest freely eat:

Genesis 2:17 But of the tree of the knowledge of good and evil, thou shalt not eat of it: for in the day that thou eatest thereof thou shalt surely die.

Genesis 2:18 And the Lord God said, It is not good that the man should be alone; I will make him an help meet for him.

Genesis 2:19 And out of the ground the Lord God formed every beast of the field, and every fowl of the air; and brought them unto Adam to see what he would call them: and whatsoever Adam called every living creature, that was the name thereof.

Genesis 2:20 And Adam gave names to all cattle, and to the fowl of the air, and to every beast of the field; but for Adam there was not found an help meet for him.

Genesis 2:21 And the Lord God caused a deep sleep to fall upon Adam, and he slept: and he took one of his ribs, and closed up the flesh instead thereof;

Genesis 2:22 And the rib, which the Lord God had taken from man, made he a woman, and brought her unto the man.

Genesis 2:23 And Adam said, This is now bone of my bones, and flesh of my flesh: she shall be called Woman, because she was taken out of Man.

Genesis 2:24 Therefore shall a man leave his father and his mother, and shall cleave unto his wife: and they shall be one flesh.

Genesis 2:25 And they were both naked, the man and his wife, and were not ashamed.
