# Psalms 89

Psalms 89 (summary): A messianic psalm—A song setting forth the mercy, greatness, justice, and righteousness of the Holy One of Israel—The Lord will establish David’s seed and throne forever—God’s Firstborn will be made higher than the kings of the earth.

Psalms 89:1 I will sing of the mercies of the Lord for ever: with my mouth will I make known thy faithfulness to all generations.

Psalms 89:2 For I have said, Mercy shall be built up for ever: thy faithfulness shalt thou establish in the very heavens.

Psalms 89:3 I have made a covenant with my chosen, I have sworn unto David my servant,

Psalms 89:4 Thy seed will I establish for ever, and build up thy throne to all generations. Selah.

Psalms 89:5 And the heavens shall praise thy wonders, O Lord: thy faithfulness also in the congregation of the saints.

Psalms 89:6 For who in the heaven can be compared unto the Lord? who among the sons of the mighty can be likened unto the Lord?

Psalms 89:7 God is greatly to be feared in the assembly of the saints, and to be had in reverence of all them that are about him.

Psalms 89:8 O Lord God of hosts, who is a strong Lord like unto thee? or to thy faithfulness round about thee?

Psalms 89:9 Thou rulest the raging of the sea: when the waves thereof arise, thou stillest them.

Psalms 89:10 Thou hast broken Rahab in pieces, as one that is slain; thou hast scattered thine enemies with thy strong arm.

Psalms 89:11 The heavens are thine, the earth also is thine: as for the world and the fulness thereof, thou hast founded them.

Psalms 89:12 The north and the south thou hast created them: Tabor and Hermon shall rejoice in thy name.

Psalms 89:13 Thou hast a mighty arm: strong is thy hand, and high is thy right hand.

Psalms 89:14 Justice and judgment are the habitation of thy throne: mercy and truth shall go before thy face.

Psalms 89:15 Blessed is the people that know the joyful sound: they shall walk, O Lord, in the light of thy countenance.

Psalms 89:16 In thy name shall they rejoice all the day: and in thy righteousness shall they be exalted.

Psalms 89:17 For thou art the glory of their strength: and in thy favour our horn shall be exalted.

Psalms 89:18 For the Lord is our defence; and the Holy One of Israel is our king.

Psalms 89:19 Then thou spakest in vision to thy holy one, and saidst, I have laid help upon one that is mighty; I have exalted one chosen out of the people.

Psalms 89:20 I have found David my servant; with my holy oil have I anointed him:

Psalms 89:21 With whom my hand shall be established: mine arm also shall strengthen him.

Psalms 89:22 The enemy shall not exact upon him; nor the son of wickedness afflict him.

Psalms 89:23 And I will beat down his foes before his face, and plague them that hate him.

Psalms 89:24 But my faithfulness and my mercy shall be with him: and in my name shall his horn be exalted.

Psalms 89:25 I will set his hand also in the sea, and his right hand in the rivers.

Psalms 89:26 He shall cry unto me, Thou art my father, my God, and the rock of my salvation.

Psalms 89:27 Also I will make him my firstborn, higher than the kings of the earth.

Psalms 89:28 My mercy will I keep for him for evermore, and my covenant shall stand fast with him.

Psalms 89:29 His seed also will I make to endure for ever, and his throne as the days of heaven.

Psalms 89:30 If his children forsake my law, and walk not in my judgments;

Psalms 89:31 If they break my statutes, and keep not my commandments;

Psalms 89:32 Then will I visit their transgression with the rod, and their iniquity with stripes.

Psalms 89:33 Nevertheless my lovingkindness will I not utterly take from him, nor suffer my faithfulness to fail.

Psalms 89:34 My covenant will I not break, nor alter the thing that is gone out of my lips.

Psalms 89:35 Once have I sworn by my holiness that I will not lie unto David.

Psalms 89:36 His seed shall endure for ever, and his throne as the sun before me.

Psalms 89:37 It shall be established for ever as the moon, and as a faithful witness in heaven. Selah.

Psalms 89:38 But thou hast cast off and abhorred, thou hast been wroth with thine anointed.

Psalms 89:39 Thou hast made void the covenant of thy servant: thou hast profaned his crown by casting it to the ground.

Psalms 89:40 Thou hast broken down all his hedges; thou hast brought his strong holds to ruin.

Psalms 89:41 All that pass by the way spoil him: he is a reproach to his neighbours.

Psalms 89:42 Thou hast set up the right hand of his adversaries; thou hast made all his enemies to rejoice.

Psalms 89:43 Thou hast also turned the edge of his sword, and hast not made him to stand in the battle.

Psalms 89:44 Thou hast made his glory to cease, and cast his throne down to the ground.

Psalms 89:45 The days of his youth hast thou shortened: thou hast covered him with shame. Selah.

Psalms 89:46 How long, Lord? wilt thou hide thyself for ever? shall thy wrath burn like fire?

Psalms 89:47 Remember how short my time is: wherefore hast thou made all men in vain?

Psalms 89:48 What man is he that liveth, and shall not see death? shall he deliver his soul from the hand of the grave? Selah.

Psalms 89:49 Lord, where are thy former lovingkindnesses, which thou swarest unto David in thy truth?

Psalms 89:50 Remember, Lord, the reproach of thy servants; how I do bear in my bosom the reproach of all the mighty people;

Psalms 89:51 Wherewith thine enemies have reproached, O Lord; wherewith they have reproached the footsteps of thine anointed.

Psalms 89:52 Blessed be the Lord for evermore. Amen, and Amen.
