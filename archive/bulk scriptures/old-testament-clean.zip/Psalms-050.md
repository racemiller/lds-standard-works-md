# Psalms 50

Psalms 50 (summary): Asaph speaks of the Second Coming—The Lord accepts the sacrifices of the righteous and will deliver them—Those whose conduct is right will see the salvation of God.

Psalms 50:1 The mighty God, even the Lord, hath spoken, and called the earth from the rising of the sun unto the going down thereof.

Psalms 50:2 Out of Zion, the perfection of beauty, God hath shined.

Psalms 50:3 Our God shall come, and shall not keep silence: a fire shall devour before him, and it shall be very tempestuous round about him.

Psalms 50:4 He shall call to the heavens from above, and to the earth, that he may judge his people.

Psalms 50:5 Gather my saints together unto me; those that have made a covenant with me by sacrifice.

Psalms 50:6 And the heavens shall declare his righteousness: for God is judge himself. Selah.

Psalms 50:7 Hear, O my people, and I will speak; O Israel, and I will testify against thee: I am God, even thy God.

Psalms 50:8 I will not reprove thee for thy sacrifices or thy burnt offerings, to have been continually before me.

Psalms 50:9 I will take no bullock out of thy house, nor he goats out of thy folds.

Psalms 50:10 For every beast of the forest is mine, and the cattle upon a thousand hills.

Psalms 50:11 I know all the fowls of the mountains: and the wild beasts of the field are mine.

Psalms 50:12 If I were hungry, I would not tell thee: for the world is mine, and the fulness thereof.

Psalms 50:13 Will I eat the flesh of bulls, or drink the blood of goats?

Psalms 50:14 Offer unto God thanksgiving; and pay thy vows unto the most High:

Psalms 50:15 And call upon me in the day of trouble: I will deliver thee, and thou shalt glorify me.

Psalms 50:16 But unto the wicked God saith, What hast thou to do to declare my statutes, or that thou shouldest take my covenant in thy mouth?

Psalms 50:17 Seeing thou hatest instruction, and castest my words behind thee.

Psalms 50:18 When thou sawest a thief, then thou consentedst with him, and hast been partaker with adulterers.

Psalms 50:19 Thou givest thy mouth to evil, and thy tongue frameth deceit.

Psalms 50:20 Thou sittest and speakest against thy brother; thou slanderest thine own mother’s son.

Psalms 50:21 These things hast thou done, and I kept silence; thou thoughtest that I was altogether such an one as thyself: but I will reprove thee, and set them in order before thine eyes.

Psalms 50:22 Now consider this, ye that forget God, lest I tear you in pieces, and there be none to deliver.

Psalms 50:23 Whoso offereth praise glorifieth me: and to him that ordereth his conversation aright will I shew the salvation of God.
