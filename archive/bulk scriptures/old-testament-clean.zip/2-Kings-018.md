# 2 Kings 18

2 Kings 18 (summary): Hezekiah reigns in righteousness in Judah—He destroys idolatry and breaks the brazen serpent made by Moses because the children of Israel burn incense to it—Sennacherib, king of Assyria, invades Judah—In a blasphemous speech, Rabshakeh asks Jerusalem to surrender to the Assyrians.

2 Kings 18:1 Now it came to pass in the third year of Hoshea son of Elah king of Israel, that Hezekiah the son of Ahaz king of Judah began to reign.

2 Kings 18:2 Twenty and five years old was he when he began to reign; and he reigned twenty and nine years in Jerusalem. His mother’s name also was Abi, the daughter of Zachariah.

2 Kings 18:3 And he did that which was right in the sight of the Lord, according to all that David his father did.

2 Kings 18:4 He removed the high places, and brake the images, and cut down the groves, and brake in pieces the brasen serpent that Moses had made: for unto those days the children of Israel did burn incense to it: and he called it Nehushtan.

2 Kings 18:5 He trusted in the Lord God of Israel; so that after him was none like him among all the kings of Judah, nor any that were before him.

2 Kings 18:6 For he clave to the Lord, and departed not from following him, but kept his commandments, which the Lord commanded Moses.

2 Kings 18:7 And the Lord was with him; and he prospered whithersoever he went forth: and he rebelled against the king of Assyria, and served him not.

2 Kings 18:8 He smote the Philistines, even unto Gaza, and the borders thereof, from the tower of the watchmen to the fenced city.

2 Kings 18:9 And it came to pass in the fourth year of king Hezekiah, which was the seventh year of Hoshea son of Elah king of Israel, that Shalmaneser king of Assyria came up against Samaria, and besieged it.

2 Kings 18:10 And at the end of three years they took it: even in the sixth year of Hezekiah, that is the ninth year of Hoshea king of Israel, Samaria was taken.

2 Kings 18:11 And the king of Assyria did carry away Israel unto Assyria, and put them in Halah and in Habor by the river of Gozan, and in the cities of the Medes:

2 Kings 18:12 Because they obeyed not the voice of the Lord their God, but transgressed his covenant, and all that Moses the servant of the Lord commanded, and would not hear them, nor do them.

2 Kings 18:13 Now in the fourteenth year of king Hezekiah did Sennacherib king of Assyria come up against all the fenced cities of Judah, and took them.

2 Kings 18:14 And Hezekiah king of Judah sent to the king of Assyria to Lachish, saying, I have offended; return from me: that which thou puttest on me will I bear. And the king of Assyria appointed unto Hezekiah king of Judah three hundred talents of silver and thirty talents of gold.

2 Kings 18:15 And Hezekiah gave him all the silver that was found in the house of the Lord, and in the treasures of the king’s house.

2 Kings 18:16 At that time did Hezekiah cut off the gold from the doors of the temple of the Lord, and from the pillars which Hezekiah king of Judah had overlaid, and gave it to the king of Assyria.

2 Kings 18:17 And the king of Assyria sent Tartan and Rabsaris and Rab-shakeh from Lachish to king Hezekiah with a great host against Jerusalem. And they went up and came to Jerusalem. And when they were come up, they came and stood by the conduit of the upper pool, which is in the highway of the fuller’s field.

2 Kings 18:18 And when they had called to the king, there came out to them Eliakim the son of Hilkiah, which was over the household, and Shebna the scribe, and Joah the son of Asaph the recorder.

2 Kings 18:19 And Rab-shakeh said unto them, Speak ye now to Hezekiah, Thus saith the great king, the king of Assyria, What confidence is this wherein thou trustest?

2 Kings 18:20 Thou sayest, (but they are but vain words,) I have counsel and strength for the war. Now on whom dost thou trust, that thou rebellest against me?

2 Kings 18:21 Now, behold, thou trustest upon the staff of this bruised reed, even upon Egypt, on which if a man lean, it will go into his hand, and pierce it: so is Pharaoh king of Egypt unto all that trust on him.

2 Kings 18:22 But if ye say unto me, We trust in the Lord our God: is not that he, whose high places and whose altars Hezekiah hath taken away, and hath said to Judah and Jerusalem, Ye shall worship before this altar in Jerusalem?

2 Kings 18:23 Now therefore, I pray thee, give pledges to my lord the king of Assyria, and I will deliver thee two thousand horses, if thou be able on thy part to set riders upon them.

2 Kings 18:24 How then wilt thou turn away the face of one captain of the least of my master’s servants, and put thy trust on Egypt for chariots and for horsemen?

2 Kings 18:25 Am I now come up without the Lord against this place to destroy it? The Lord said to me, Go up against this land, and destroy it.

2 Kings 18:26 Then said Eliakim the son of Hilkiah, and Shebna, and Joah, unto Rab-shakeh, Speak, I pray thee, to thy servants in the Syrian language; for we understand it: and talk not with us in the Jews’ language in the ears of the people that are on the wall.

2 Kings 18:27 But Rab-shakeh said unto them, Hath my master sent me to thy master, and to thee, to speak these words? hath he not sent me to the men which sit on the wall, that they may eat their own dung, and drink their own piss with you?

2 Kings 18:28 Then Rab-shakeh stood and cried with a loud voice in the Jews’ language, and spake, saying, Hear the word of the great king, the king of Assyria:

2 Kings 18:29 Thus saith the king, Let not Hezekiah deceive you: for he shall not be able to deliver you out of his hand:

2 Kings 18:30 Neither let Hezekiah make you trust in the Lord, saying, The Lord will surely deliver us, and this city shall not be delivered into the hand of the king of Assyria.

2 Kings 18:31 Hearken not to Hezekiah: for thus saith the king of Assyria, Make an agreement with me by a present, and come out to me, and then eat ye every man of his own vine, and every one of his fig tree, and drink ye every one the waters of his cistern:

2 Kings 18:32 Until I come and take you away to a land like your own land, a land of corn and wine, a land of bread and vineyards, a land of oil olive and of honey, that ye may live, and not die: and hearken not unto Hezekiah, when he persuadeth you, saying, The Lord will deliver us.

2 Kings 18:33 Hath any of the gods of the nations delivered at all his land out of the hand of the king of Assyria?

2 Kings 18:34 Where are the gods of Hamath, and of Arpad? where are the gods of Sepharvaim, Hena, and Ivah? have they delivered Samaria out of mine hand?

2 Kings 18:35 Who are they among all the gods of the countries, that have delivered their country out of mine hand, that the Lord should deliver Jerusalem out of mine hand?

2 Kings 18:36 But the people held their peace, and answered him not a word: for the king’s commandment was, saying, Answer him not.

2 Kings 18:37 Then came Eliakim the son of Hilkiah, which was over the household, and Shebna the scribe, and Joah the son of Asaph the recorder, to Hezekiah with their clothes rent, and told him the words of Rab-shakeh.
