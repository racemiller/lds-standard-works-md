# Exodus 10

Exodus 10 (summary): The Lord sends a plague of locusts—This is followed by thick darkness in all Egypt for three days—Moses is cast out from the presence of Pharaoh.

Exodus 10:1 And the Lord said unto Moses, Go in unto Pharaoh: for I have hardened his heart, and the heart of his servants, that I might shew these my signs before him:

Exodus 10:2 And that thou mayest tell in the ears of thy son, and of thy son’s son, what things I have wrought in Egypt, and my signs which I have done among them; that ye may know how that I am the Lord.

Exodus 10:3 And Moses and Aaron came in unto Pharaoh, and said unto him, Thus saith the Lord God of the Hebrews, How long wilt thou refuse to humble thyself before me? let my people go, that they may serve me.

Exodus 10:4 Else, if thou refuse to let my people go, behold, to morrow will I bring the locusts into thy coast:

Exodus 10:5 And they shall cover the face of the earth, that one cannot be able to see the earth: and they shall eat the residue of that which is escaped, which remaineth unto you from the hail, and shall eat every tree which groweth for you out of the field:

Exodus 10:6 And they shall fill thy houses, and the houses of all thy servants, and the houses of all the Egyptians; which neither thy fathers, nor thy fathers’ fathers have seen, since the day that they were upon the earth unto this day. And he turned himself, and went out from Pharaoh.

Exodus 10:7 And Pharaoh’s servants said unto him, How long shall this man be a snare unto us? let the men go, that they may serve the Lord their God: knowest thou not yet that Egypt is destroyed?

Exodus 10:8 And Moses and Aaron were brought again unto Pharaoh: and he said unto them, Go, serve the Lord your God: but who are they that shall go?

Exodus 10:9 And Moses said, We will go with our young and with our old, with our sons and with our daughters, with our flocks and with our herds will we go; for we must hold a feast unto the Lord.

Exodus 10:10 And he said unto them, Let the Lord be so with you, as I will let you go, and your little ones: look to it; for evil is before you.

Exodus 10:11 Not so: go now ye that are men, and serve the Lord; for that ye did desire. And they were driven out from Pharaoh’s presence.

Exodus 10:12 And the Lord said unto Moses, Stretch out thine hand over the land of Egypt for the locusts, that they may come up upon the land of Egypt, and eat every herb of the land, even all that the hail hath left.

Exodus 10:13 And Moses stretched forth his rod over the land of Egypt, and the Lord brought an east wind upon the land all that day, and all that night; and when it was morning, the east wind brought the locusts.

Exodus 10:14 And the locusts went up over all the land of Egypt, and rested in all the coasts of Egypt: very grievous were they; before them there were no such locusts as they, neither after them shall be such.

Exodus 10:15 For they covered the face of the whole earth, so that the land was darkened; and they did eat every herb of the land, and all the fruit of the trees which the hail had left: and there remained not any green thing in the trees, or in the herbs of the field, through all the land of Egypt.

Exodus 10:16 Then Pharaoh called for Moses and Aaron in haste; and he said, I have sinned against the Lord your God, and against you.

Exodus 10:17 Now therefore forgive, I pray thee, my sin only this once, and entreat the Lord your God, that he may take away from me this death only.

Exodus 10:18 And he went out from Pharaoh, and entreated the Lord.

Exodus 10:19 And the Lord turned a mighty strong west wind, which took away the locusts, and cast them into the Red sea; there remained not one locust in all the coasts of Egypt.

Exodus 10:20 But the Lord hardened Pharaoh’s heart, so that he would not let the children of Israel go.

Exodus 10:21 And the Lord said unto Moses, Stretch out thine hand toward heaven, that there may be darkness over the land of Egypt, even darkness which may be felt.

Exodus 10:22 And Moses stretched forth his hand toward heaven; and there was a thick darkness in all the land of Egypt three days:

Exodus 10:23 They saw not one another, neither rose any from his place for three days: but all the children of Israel had light in their dwellings.

Exodus 10:24 And Pharaoh called unto Moses, and said, Go ye, serve the Lord; only let your flocks and your herds be stayed: let your little ones also go with you.

Exodus 10:25 And Moses said, Thou must give us also sacrifices and burnt offerings, that we may sacrifice unto the Lord our God.

Exodus 10:26 Our cattle also shall go with us; there shall not an hoof be left behind; for thereof must we take to serve the Lord our God; and we know not with what we must serve the Lord, until we come thither.

Exodus 10:27 But the Lord hardened Pharaoh’s heart, and he would not let them go.

Exodus 10:28 And Pharaoh said unto him, Get thee from me, take heed to thyself, see my face no more; for in that day thou seest my face thou shalt die.

Exodus 10:29 And Moses said, Thou hast spoken well, I will see thy face again no more.
