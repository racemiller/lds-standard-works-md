# Malachi 3

Malachi 3 (summary): The Lord’s messenger will prepare the way for the Second Coming—The Lord will sit in judgment—The people of Israel are commanded to pay tithes and offerings—They keep a book of remembrance.

Malachi 3:1 Behold, I will send my messenger, and he shall prepare the way before me: and the Lord, whom ye seek, shall suddenly come to his temple, even the messenger of the covenant, whom ye delight in: behold, he shall come, saith the Lord of hosts.

Malachi 3:2 But who may abide the day of his coming? and who shall stand when he appeareth? for he is like a refiner’s fire, and like fullers’ soap:

Malachi 3:3 And he shall sit as a refiner and purifier of silver: and he shall purify the sons of Levi, and purge them as gold and silver, that they may offer unto the Lord an offering in righteousness.

Malachi 3:4 Then shall the offering of Judah and Jerusalem be pleasant unto the Lord, as in the days of old, and as in former years.

Malachi 3:5 And I will come near to you to judgment; and I will be a swift witness against the sorcerers, and against the adulterers, and against false swearers, and against those that oppress the hireling in his wages, the widow, and the fatherless, and that turn aside the stranger from his right, and fear not me, saith the Lord of hosts.

Malachi 3:6 For I am the Lord, I change not; therefore ye sons of Jacob are not consumed.

Malachi 3:7 Even from the days of your fathers ye are gone away from mine ordinances, and have not kept them. Return unto me, and I will return unto you, saith the Lord of hosts. But ye said, Wherein shall we return?

Malachi 3:8 Will a man rob God? Yet ye have robbed me. But ye say, Wherein have we robbed thee? In tithes and offerings.

Malachi 3:9 Ye are cursed with a curse: for ye have robbed me, even this whole nation.

Malachi 3:10 Bring ye all the tithes into the storehouse, that there may be meat in mine house, and prove me now herewith, saith the Lord of hosts, if I will not open you the windows of heaven, and pour you out a blessing, that there shall not be room enough to receive it.

Malachi 3:11 And I will rebuke the devourer for your sakes, and he shall not destroy the fruits of your ground; neither shall your vine cast her fruit before the time in the field, saith the Lord of hosts.

Malachi 3:12 And all nations shall call you blessed: for ye shall be a delightsome land, saith the Lord of hosts.

Malachi 3:13 Your words have been stout against me, saith the Lord. Yet ye say, What have we spoken so much against thee?

Malachi 3:14 Ye have said, It is vain to serve God: and what profit is it that we have kept his ordinance, and that we have walked mournfully before the Lord of hosts?

Malachi 3:15 And now we call the proud happy; yea, they that work wickedness are set up; yea, they that tempt God are even delivered.

Malachi 3:16 Then they that feared the Lord spake often one to another: and the Lord hearkened, and heard it, and a book of remembrance was written before him for them that feared the Lord, and that thought upon his name.

Malachi 3:17 And they shall be mine, saith the Lord of hosts, in that day when I make up my jewels; and I will spare them, as a man spareth his own son that serveth him.

Malachi 3:18 Then shall ye return, and discern between the righteous and the wicked, between him that serveth God and him that serveth him not.
