# Leviticus 17

Leviticus 17 (summary): Sacrifices are to be offered only to the Lord at the tabernacle of the congregation—Israel is forbidden to sacrifice to devils—All eating of blood is forbidden—Shedding of blood is required for an atonement for sins.

Leviticus 17:1 And the Lord spake unto Moses, saying,

Leviticus 17:2 Speak unto Aaron, and unto his sons, and unto all the children of Israel, and say unto them; This is the thing which the Lord hath commanded, saying,

Leviticus 17:3 What man soever there be of the house of Israel, that killeth an ox, or lamb, or goat, in the camp, or that killeth it out of the camp,

Leviticus 17:4 And bringeth it not unto the door of the tabernacle of the congregation, to offer an offering unto the Lord before the tabernacle of the Lord; blood shall be imputed unto that man; he hath shed blood; and that man shall be cut off from among his people:

Leviticus 17:5 To the end that the children of Israel may bring their sacrifices, which they offer in the open field, even that they may bring them unto the Lord, unto the door of the tabernacle of the congregation, unto the priest, and offer them for peace offerings unto the Lord.

Leviticus 17:6 And the priest shall sprinkle the blood upon the altar of the Lord at the door of the tabernacle of the congregation, and burn the fat for a sweet savour unto the Lord.

Leviticus 17:7 And they shall no more offer their sacrifices unto devils, after whom they have gone a whoring. This shall be a statute for ever unto them throughout their generations.

Leviticus 17:8 And thou shalt say unto them, Whatsoever man there be of the house of Israel, or of the strangers which sojourn among you, that offereth a burnt offering or sacrifice,

Leviticus 17:9 And bringeth it not unto the door of the tabernacle of the congregation, to offer it unto the Lord; even that man shall be cut off from among his people.

Leviticus 17:10 And whatsoever man there be of the house of Israel, or of the strangers that sojourn among you, that eateth any manner of blood; I will even set my face against that soul that eateth blood, and will cut him off from among his people.

Leviticus 17:11 For the life of the flesh is in the blood: and I have given it to you upon the altar to make an atonement for your souls: for it is the blood that maketh an atonement for the soul.

Leviticus 17:12 Therefore I said unto the children of Israel, No soul of you shall eat blood, neither shall any stranger that sojourneth among you eat blood.

Leviticus 17:13 And whatsoever man there be of the children of Israel, or of the strangers that sojourn among you, which hunteth and catcheth any beast or fowl that may be eaten; he shall even pour out the blood thereof, and cover it with dust.

Leviticus 17:14 For it is the life of all flesh; the blood of it is for the life thereof: therefore I said unto the children of Israel, Ye shall eat the blood of no manner of flesh: for the life of all flesh is the blood thereof: whosoever eateth it shall be cut off.

Leviticus 17:15 And every soul that eateth that which died of itself, or that which was torn with beasts, whether it be one of your own country, or a stranger, he shall both wash his clothes, and bathe himself in water, and be unclean until the even: then shall he be clean.

Leviticus 17:16 But if he wash them not, nor bathe his flesh; then he shall bear his iniquity.
