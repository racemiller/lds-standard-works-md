# Exodus 33

Exodus 33 (summary): The Lord promises to be with Israel and drive out the people of the land—The tabernacle of the congregation is moved away from the camp—The Lord speaks to Moses face to face in the tabernacle—Later, Moses sees the glory of God but not His face.

Exodus 33:1 And the Lord said unto Moses, Depart, and go up hence, thou and the people which thou hast brought up out of the land of Egypt, unto the land which I sware unto Abraham, to Isaac, and to Jacob, saying, Unto thy seed will I give it:

Exodus 33:2 And I will send an angel before thee; and I will drive out the Canaanite, the Amorite, and the Hittite, and the Perizzite, the Hivite, and the Jebusite:

Exodus 33:3 Unto a land flowing with milk and honey: for I will not go up in the midst of thee; for thou art a stiffnecked people: lest I consume thee in the way.

Exodus 33:4 And when the people heard these evil tidings, they mourned: and no man did put on him his ornaments.

Exodus 33:5 For the Lord had said unto Moses, Say unto the children of Israel, Ye are a stiffnecked people: I will come up into the midst of thee in a moment, and consume thee: therefore now put off thy ornaments from thee, that I may know what to do unto thee.

Exodus 33:6 And the children of Israel stripped themselves of their ornaments by the mount Horeb.

Exodus 33:7 And Moses took the tabernacle, and pitched it without the camp, afar off from the camp, and called it the Tabernacle of the congregation. And it came to pass, that every one which sought the Lord went out unto the tabernacle of the congregation, which was without the camp.

Exodus 33:8 And it came to pass, when Moses went out unto the tabernacle, that all the people rose up, and stood every man at his tent door, and looked after Moses, until he was gone into the tabernacle.

Exodus 33:9 And it came to pass, as Moses entered into the tabernacle, the cloudy pillar descended, and stood at the door of the tabernacle, and the Lord talked with Moses.

Exodus 33:10 And all the people saw the cloudy pillar stand at the tabernacle door: and all the people rose up and worshipped, every man in his tent door.

Exodus 33:11 And the Lord spake unto Moses face to face, as a man speaketh unto his friend. And he turned again into the camp: but his servant Joshua, the son of Nun, a young man, departed not out of the tabernacle.

Exodus 33:12 And Moses said unto the Lord, See, thou sayest unto me, Bring up this people: and thou hast not let me know whom thou wilt send with me. Yet thou hast said, I know thee by name, and thou hast also found grace in my sight.

Exodus 33:13 Now therefore, I pray thee, if I have found grace in thy sight, shew me now thy way, that I may know thee, that I may find grace in thy sight: and consider that this nation is thy people.

Exodus 33:14 And he said, My presence shall go with thee, and I will give thee rest.

Exodus 33:15 And he said unto him, If thy presence go not with me, carry us not up hence.

Exodus 33:16 For wherein shall it be known here that I and thy people have found grace in thy sight? is it not in that thou goest with us? so shall we be separated, I and thy people, from all the people that are upon the face of the earth.

Exodus 33:17 And the Lord said unto Moses, I will do this thing also that thou hast spoken: for thou hast found grace in my sight, and I know thee by name.

Exodus 33:18 And he said, I beseech thee, shew me thy glory.

Exodus 33:19 And he said, I will make all my goodness pass before thee, and I will proclaim the name of the Lord before thee; and will be gracious to whom I will be gracious, and will shew mercy on whom I will shew mercy.

Exodus 33:20 And he said, Thou canst not see my face: for there shall no man see me, and live.

Exodus 33:21 And the Lord said, Behold, there is a place by me, and thou shalt stand upon a rock:

Exodus 33:22 And it shall come to pass, while my glory passeth by, that I will put thee in a clift of the rock, and will cover thee with my hand while I pass by:

Exodus 33:23 And I will take away mine hand, and thou shalt see my back parts: but my face shall not be seen.
