# Ecclesiastes 5

Ecclesiastes 5 (summary): God is in heaven—A fool’s voice is known by a multitude of words—Keep your vows—Riches and wealth are the gift of God.

Ecclesiastes 5:1 Keep thy foot when thou goest to the house of God, and be more ready to hear, than to give the sacrifice of fools: for they consider not that they do evil.

Ecclesiastes 5:2 Be not rash with thy mouth, and let not thine heart be hasty to utter any thing before God: for God is in heaven, and thou upon earth: therefore let thy words be few.

Ecclesiastes 5:3 For a dream cometh through the multitude of business; and a fool’s voice is known by multitude of words.

Ecclesiastes 5:4 When thou vowest a vow unto God, defer not to pay it; for he hath no pleasure in fools: pay that which thou hast vowed.

Ecclesiastes 5:5 Better is it that thou shouldest not vow, than that thou shouldest vow and not pay.

Ecclesiastes 5:6 Suffer not thy mouth to cause thy flesh to sin; neither say thou before the angel, that it was an error: wherefore should God be angry at thy voice, and destroy the work of thine hands?

Ecclesiastes 5:7 For in the multitude of dreams and many words there are also divers vanities: but fear thou God.

Ecclesiastes 5:8 If thou seest the oppression of the poor, and violent perverting of judgment and justice in a province, marvel not at the matter: for he that is higher than the highest regardeth; and there be higher than they.

Ecclesiastes 5:9 Moreover the profit of the earth is for all: the king himself is served by the field.

Ecclesiastes 5:10 He that loveth silver shall not be satisfied with silver; nor he that loveth abundance with increase: this is also vanity.

Ecclesiastes 5:11 When goods increase, they are increased that eat them: and what good is there to the owners thereof, saving the beholding of them with their eyes?

Ecclesiastes 5:12 The sleep of a labouring man is sweet, whether he eat little or much: but the abundance of the rich will not suffer him to sleep.

Ecclesiastes 5:13 There is a sore evil which I have seen under the sun, namely, riches kept for the owners thereof to their hurt.

Ecclesiastes 5:14 But those riches perish by evil travail: and he begetteth a son, and there is nothing in his hand.

Ecclesiastes 5:15 As he came forth of his mother’s womb, naked shall he return to go as he came, and shall take nothing of his labour, which he may carry away in his hand.

Ecclesiastes 5:16 And this also is a sore evil, that in all points as he came, so shall he go: and what profit hath he that hath laboured for the wind?

Ecclesiastes 5:17 All his days also he eateth in darkness, and he hath much sorrow and wrath with his sickness.

Ecclesiastes 5:18 Behold that which I have seen: it is good and comely for one to eat and to drink, and to enjoy the good of all his labour that he taketh under the sun all the days of his life, which God giveth him: for it is his portion.

Ecclesiastes 5:19 Every man also to whom God hath given riches and wealth, and hath given him power to eat thereof, and to take his portion, and to rejoice in his labour; this is the gift of God.

Ecclesiastes 5:20 For he shall not much remember the days of his life; because God answereth him in the joy of his heart.
