# Genesis 30

Genesis 30 (summary): Jacob marries Bilhah, and she bears Dan and Naphtali—He marries Zilpah, and she bears Gad and Asher—Leah bears Issachar and Zebulun and a daughter, Dinah—Then Rachel conceives and bears Joseph—Jacob works for Laban for wages of cattle and sheep.

Genesis 30:1 And when Rachel saw that she bare Jacob no children, Rachel envied her sister; and said unto Jacob, Give me children, or else I die.

Genesis 30:2 And Jacob’s anger was kindled against Rachel: and he said, Am I in God’s stead, who hath withheld from thee the fruit of the womb?

Genesis 30:3 And she said, Behold my maid Bilhah, go in unto her; and she shall bear upon my knees, that I may also have children by her.

Genesis 30:4 And she gave him Bilhah her handmaid to wife: and Jacob went in unto her.

Genesis 30:5 And Bilhah conceived, and bare Jacob a son.

Genesis 30:6 And Rachel said, God hath judged me, and hath also heard my voice, and hath given me a son: therefore called she his name Dan.

Genesis 30:7 And Bilhah Rachel’s maid conceived again, and bare Jacob a second son.

Genesis 30:8 And Rachel said, With great wrestlings have I wrestled with my sister, and I have prevailed: and she called his name Naphtali.

Genesis 30:9 When Leah saw that she had left bearing, she took Zilpah her maid, and gave her Jacob to wife.

Genesis 30:10 And Zilpah Leah’s maid bare Jacob a son.

Genesis 30:11 And Leah said, A troop cometh: and she called his name Gad.

Genesis 30:12 And Zilpah Leah’s maid bare Jacob a second son.

Genesis 30:13 And Leah said, Happy am I, for the daughters will call me blessed: and she called his name Asher.

Genesis 30:14 And Reuben went in the days of wheat harvest, and found mandrakes in the field, and brought them unto his mother Leah. Then Rachel said to Leah, Give me, I pray thee, of thy son’s mandrakes.

Genesis 30:15 And she said unto her, Is it a small matter that thou hast taken my husband? and wouldest thou take away my son’s mandrakes also? And Rachel said, Therefore he shall lie with thee to night for thy son’s mandrakes.

Genesis 30:16 And Jacob came out of the field in the evening, and Leah went out to meet him, and said, Thou must come in unto me; for surely I have hired thee with my son’s mandrakes. And he lay with her that night.

Genesis 30:17 And God hearkened unto Leah, and she conceived, and bare Jacob the fifth son.

Genesis 30:18 And Leah said, God hath given me my hire, because I have given my maiden to my husband: and she called his name Issachar.

Genesis 30:19 And Leah conceived again, and bare Jacob the sixth son.

Genesis 30:20 And Leah said, God hath endued me with a good dowry; now will my husband dwell with me, because I have born him six sons: and she called his name Zebulun.

Genesis 30:21 And afterwards she bare a daughter, and called her name Dinah.

Genesis 30:22 And God remembered Rachel, and God hearkened to her, and opened her womb.

Genesis 30:23 And she conceived, and bare a son; and said, God hath taken away my reproach:

Genesis 30:24 And she called his name Joseph; and said, The Lord shall add to me another son.

Genesis 30:25 And it came to pass, when Rachel had born Joseph, that Jacob said unto Laban, Send me away, that I may go unto mine own place, and to my country.

Genesis 30:26 Give me my wives and my children, for whom I have served thee, and let me go: for thou knowest my service which I have done thee.

Genesis 30:27 And Laban said unto him, I pray thee, if I have found favour in thine eyes, tarry: for I have learned by experience that the Lord hath blessed me for thy sake.

Genesis 30:28 And he said, Appoint me thy wages, and I will give it.

Genesis 30:29 And he said unto him, Thou knowest how I have served thee, and how thy cattle was with me.

Genesis 30:30 For it was little which thou hadst before I came, and it is now increased unto a multitude; and the Lord hath blessed thee since my coming: and now when shall I provide for mine own house also?

Genesis 30:31 And he said, What shall I give thee? And Jacob said, Thou shalt not give me any thing: if thou wilt do this thing for me, I will again feed and keep thy flock:

Genesis 30:32 I will pass through all thy flock to day, removing from thence all the speckled and spotted cattle, and all the brown cattle among the sheep, and the spotted and speckled among the goats: and of such shall be my hire.

Genesis 30:33 So shall my righteousness answer for me in time to come, when it shall come for my hire before thy face: every one that is not speckled and spotted among the goats, and brown among the sheep, that shall be counted stolen with me.

Genesis 30:34 And Laban said, Behold, I would it might be according to thy word.

Genesis 30:35 And he removed that day the he goats that were ringstraked and spotted, and all the she goats that were speckled and spotted, and every one that had some white in it, and all the brown among the sheep, and gave them into the hand of his sons.

Genesis 30:36 And he set three days’ journey betwixt himself and Jacob: and Jacob fed the rest of Laban’s flocks.

Genesis 30:37 And Jacob took him rods of green poplar, and of the hazel and chestnut tree; and pilled white strakes in them, and made the white appear which was in the rods.

Genesis 30:38 And he set the rods which he had pilled before the flocks in the gutters in the watering troughs when the flocks came to drink, that they should conceive when they came to drink.

Genesis 30:39 And the flocks conceived before the rods, and brought forth cattle ringstraked, speckled, and spotted.

Genesis 30:40 And Jacob did separate the lambs, and set the faces of the flocks toward the ringstraked, and all the brown in the flock of Laban; and he put his own flocks by themselves, and put them not unto Laban’s cattle.

Genesis 30:41 And it came to pass, whensoever the stronger cattle did conceive, that Jacob laid the rods before the eyes of the cattle in the gutters, that they might conceive among the rods.

Genesis 30:42 But when the cattle were feeble, he put them not in: so the feebler were Laban’s, and the stronger Jacob’s.

Genesis 30:43 And the man increased exceedingly, and had much cattle, and maidservants, and menservants, and camels, and asses.
