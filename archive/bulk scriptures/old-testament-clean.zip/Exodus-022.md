# Exodus 22

Exodus 22 (summary): The Lord reveals His laws pertaining to stealing, destructions by fire, care of the property of others, borrowing, lascivious acts, sacrifices to false gods, afflicting widows, usury, reviling God, and the firstborn of men and of animals—The men of Israel are commanded to be holy.

Exodus 22:1 If a man shall steal an ox, or a sheep, and kill it, or sell it; he shall restore five oxen for an ox, and four sheep for a sheep.

Exodus 22:2 If a thief be found breaking up, and be smitten that he die, there shall no blood be shed for him.

Exodus 22:3 If the sun be risen upon him, there shall be blood shed for him; for he should make full restitution; if he have nothing, then he shall be sold for his theft.

Exodus 22:4 If the theft be certainly found in his hand alive, whether it be ox, or ass, or sheep; he shall restore double.

Exodus 22:5 If a man shall cause a field or vineyard to be eaten, and shall put in his beast, and shall feed in another man’s field; of the best of his own field, and of the best of his own vineyard, shall he make restitution.

Exodus 22:6 If fire break out, and catch in thorns, so that the stacks of corn, or the standing corn, or the field, be consumed therewith; he that kindled the fire shall surely make restitution.

Exodus 22:7 If a man shall deliver unto his neighbour money or stuff to keep, and it be stolen out of the man’s house; if the thief be found, let him pay double.

Exodus 22:8 If the thief be not found, then the master of the house shall be brought unto the judges, to see whether he have put his hand unto his neighbour’s goods.

Exodus 22:9 For all manner of trespass, whether it be for ox, for ass, for sheep, for raiment, or for any manner of lost thing, which another challengeth to be his, the cause of both parties shall come before the judges; and whom the judges shall condemn, he shall pay double unto his neighbour.

Exodus 22:10 If a man deliver unto his neighbour an ass, or an ox, or a sheep, or any beast, to keep; and it die, or be hurt, or driven away, no man seeing it:

Exodus 22:11 Then shall an oath of the Lord be between them both, that he hath not put his hand unto his neighbour’s goods; and the owner of it shall accept thereof, and he shall not make it good.

Exodus 22:12 And if it be stolen from him, he shall make restitution unto the owner thereof.

Exodus 22:13 If it be torn in pieces, then let him bring it for witness, and he shall not make good that which was torn.

Exodus 22:14 And if a man borrow ought of his neighbour, and it be hurt, or die, the owner thereof being not with it, he shall surely make it good.

Exodus 22:15 But if the owner thereof be with it, he shall not make it good: if it be an hired thing, it came for his hire.

Exodus 22:16 And if a man entice a maid that is not betrothed, and lie with her, he shall surely endow her to be his wife.

Exodus 22:17 If her father utterly refuse to give her unto him, he shall pay money according to the dowry of virgins.

Exodus 22:18 Thou shalt not suffer a witch to live.

Exodus 22:19 Whosoever lieth with a beast shall surely be put to death.

Exodus 22:20 He that sacrificeth unto any god, save unto the Lord only, he shall be utterly destroyed.

Exodus 22:21 Thou shalt neither vex a stranger, nor oppress him: for ye were strangers in the land of Egypt.

Exodus 22:22 Ye shall not afflict any widow, or fatherless child.

Exodus 22:23 If thou afflict them in any wise, and they cry at all unto me, I will surely hear their cry;

Exodus 22:24 And my wrath shall wax hot, and I will kill you with the sword; and your wives shall be widows, and your children fatherless.

Exodus 22:25 If thou lend money to any of my people that is poor by thee, thou shalt not be to him as an usurer, neither shalt thou lay upon him usury.

Exodus 22:26 If thou at all take thy neighbour’s raiment to pledge, thou shalt deliver it unto him by that the sun goeth down:

Exodus 22:27 For that is his covering only, it is his raiment for his skin: wherein shall he sleep? and it shall come to pass, when he crieth unto me, that I will hear; for I am gracious.

Exodus 22:28 Thou shalt not revile the gods, nor curse the ruler of thy people.

Exodus 22:29 Thou shalt not delay to offer the first of thy ripe fruits, and of thy liquors: the firstborn of thy sons shalt thou give unto me.

Exodus 22:30 Likewise shalt thou do with thine oxen, and with thy sheep: seven days it shall be with his dam; on the eighth day thou shalt give it me.

Exodus 22:31 And ye shall be holy men unto me: neither shall ye eat any flesh that is torn of beasts in the field; ye shall cast it to the dogs.
