# Leviticus 9

Leviticus 9 (summary): Aaron makes an atonement by sacrifice for himself and all Israel—He and his sons offer sacrifices—The glory of the Lord appears to all—Fire from the Lord consumes the offerings on the altar.

Leviticus 9:1 And it came to pass on the eighth day, that Moses called Aaron and his sons, and the elders of Israel;

Leviticus 9:2 And he said unto Aaron, Take thee a young calf for a sin offering, and a ram for a burnt offering, without blemish, and offer them before the Lord.

Leviticus 9:3 And unto the children of Israel thou shalt speak, saying, Take ye a kid of the goats for a sin offering; and a calf and a lamb, both of the first year, without blemish, for a burnt offering;

Leviticus 9:4 Also a bullock and a ram for peace offerings, to sacrifice before the Lord; and a meat offering mingled with oil: for to day the Lord will appear unto you.

Leviticus 9:5 And they brought that which Moses commanded before the tabernacle of the congregation: and all the congregation drew near and stood before the Lord.

Leviticus 9:6 And Moses said, This is the thing which the Lord commanded that ye should do: and the glory of the Lord shall appear unto you.

Leviticus 9:7 And Moses said unto Aaron, Go unto the altar, and offer thy sin offering, and thy burnt offering, and make an atonement for thyself, and for the people: and offer the offering of the people, and make an atonement for them; as the Lord commanded.

Leviticus 9:8 Aaron therefore went unto the altar, and slew the calf of the sin offering, which was for himself.

Leviticus 9:9 And the sons of Aaron brought the blood unto him: and he dipped his finger in the blood, and put it upon the horns of the altar, and poured out the blood at the bottom of the altar:

Leviticus 9:10 But the fat, and the kidneys, and the caul above the liver of the sin offering, he burnt upon the altar; as the Lord commanded Moses.

Leviticus 9:11 And the flesh and the hide he burnt with fire without the camp.

Leviticus 9:12 And he slew the burnt offering; and Aaron’s sons presented unto him the blood, which he sprinkled round about upon the altar.

Leviticus 9:13 And they presented the burnt offering unto him, with the pieces thereof, and the head: and he burnt them upon the altar.

Leviticus 9:14 And he did wash the inwards and the legs, and burnt them upon the burnt offering on the altar.

Leviticus 9:15 And he brought the people’s offering, and took the goat, which was the sin offering for the people, and slew it, and offered it for sin, as the first.

Leviticus 9:16 And he brought the burnt offering, and offered it according to the manner.

Leviticus 9:17 And he brought the meat offering, and took an handful thereof, and burnt it upon the altar, beside the burnt sacrifice of the morning.

Leviticus 9:18 He slew also the bullock and the ram for a sacrifice of peace offerings, which was for the people: and Aaron’s sons presented unto him the blood, which he sprinkled upon the altar round about,

Leviticus 9:19 And the fat of the bullock and of the ram, the rump, and that which covereth the inwards, and the kidneys, and the caul above the liver:

Leviticus 9:20 And they put the fat upon the breasts, and he burnt the fat upon the altar:

Leviticus 9:21 And the breasts and the right shoulder Aaron waved for a wave offering before the Lord; as Moses commanded.

Leviticus 9:22 And Aaron lifted up his hand toward the people, and blessed them, and came down from offering of the sin offering, and the burnt offering, and peace offerings.

Leviticus 9:23 And Moses and Aaron went into the tabernacle of the congregation, and came out, and blessed the people: and the glory of the Lord appeared unto all the people.

Leviticus 9:24 And there came a fire out from before the Lord, and consumed upon the altar the burnt offering and the fat: which when all the people saw, they shouted, and fell on their faces.
