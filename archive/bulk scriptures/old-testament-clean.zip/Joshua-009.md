# Joshua 9

Joshua 9 (summary): The Gibeonites by craft obtain a league with Israel—Joshua makes them servants to the congregation of Israel.

Joshua 9:1 And it came to pass, when all the kings which were on this side Jordan, in the hills, and in the valleys, and in all the coasts of the great sea over against Lebanon, the Hittite, and the Amorite, the Canaanite, the Perizzite, the Hivite, and the Jebusite, heard thereof;

Joshua 9:2 That they gathered themselves together, to fight with Joshua and with Israel, with one accord.

Joshua 9:3 And when the inhabitants of Gibeon heard what Joshua had done unto Jericho and to Ai,

Joshua 9:4 They did work wilily, and went and made as if they had been ambassadors, and took old sacks upon their asses, and wine bottles, old, and rent, and bound up;

Joshua 9:5 And old shoes and clouted upon their feet, and old garments upon them; and all the bread of their provision was dry and mouldy.

Joshua 9:6 And they went to Joshua unto the camp at Gilgal, and said unto him, and to the men of Israel, We be come from a far country: now therefore make ye a league with us.

Joshua 9:7 And the men of Israel said unto the Hivites, Peradventure ye dwell among us; and how shall we make a league with you?

Joshua 9:8 And they said unto Joshua, We are thy servants. And Joshua said unto them, Who are ye? and from whence come ye?

Joshua 9:9 And they said unto him, From a very far country thy servants are come because of the name of the Lord thy God: for we have heard the fame of him, and all that he did in Egypt,

Joshua 9:10 And all that he did to the two kings of the Amorites, that were beyond Jordan, to Sihon king of Heshbon, and to Og king of Bashan, which was at Ashtaroth.

Joshua 9:11 Wherefore our elders and all the inhabitants of our country spake to us, saying, Take victuals with you for the journey, and go to meet them, and say unto them, We are your servants: therefore now make ye a league with us.

Joshua 9:12 This our bread we took hot for our provision out of our houses on the day we came forth to go unto you; but now, behold, it is dry, and it is mouldy:

Joshua 9:13 And these bottles of wine, which we filled, were new; and, behold, they be rent: and these our garments and our shoes are become old by reason of the very long journey.

Joshua 9:14 And the men took of their victuals, and asked not counsel at the mouth of the Lord.

Joshua 9:15 And Joshua made peace with them, and made a league with them, to let them live: and the princes of the congregation sware unto them.

Joshua 9:16 And it came to pass at the end of three days after they had made a league with them, that they heard that they were their neighbours, and that they dwelt among them.

Joshua 9:17 And the children of Israel journeyed, and came unto their cities on the third day. Now their cities were Gibeon, and Chephirah, and Beeroth, and Kirjath-jearim.

Joshua 9:18 And the children of Israel smote them not, because the princes of the congregation had sworn unto them by the Lord God of Israel. And all the congregation murmured against the princes.

Joshua 9:19 But all the princes said unto all the congregation, We have sworn unto them by the Lord God of Israel: now therefore we may not touch them.

Joshua 9:20 This we will do to them; we will even let them live, lest wrath be upon us, because of the oath which we sware unto them.

Joshua 9:21 And the princes said unto them, Let them live; but let them be hewers of wood and drawers of water unto all the congregation; as the princes had promised them.

Joshua 9:22 And Joshua called for them, and he spake unto them, saying, Wherefore have ye beguiled us, saying, We are very far from you; when ye dwell among us?

Joshua 9:23 Now therefore ye are cursed, and there shall none of you be freed from being bondmen, and hewers of wood and drawers of water for the house of my God.

Joshua 9:24 And they answered Joshua, and said, Because it was certainly told thy servants, how that the Lord thy God commanded his servant Moses to give you all the land, and to destroy all the inhabitants of the land from before you, therefore we were sore afraid of our lives because of you, and have done this thing.

Joshua 9:25 And now, behold, we are in thine hand: as it seemeth good and right unto thee to do unto us, do.

Joshua 9:26 And so did he unto them, and delivered them out of the hand of the children of Israel, that they slew them not.

Joshua 9:27 And Joshua made them that day hewers of wood and drawers of water for the congregation, and for the altar of the Lord, even unto this day, in the place which he should choose.
