# Psalms 143

Psalms 143 (summary): David prays for favor in judgment—He meditates on the Lord’s works and trusts in Him.

Psalms 143:1 Hear my prayer, O Lord, give ear to my supplications: in thy faithfulness answer me, and in thy righteousness.

Psalms 143:2 And enter not into judgment with thy servant: for in thy sight shall no man living be justified.

Psalms 143:3 For the enemy hath persecuted my soul; he hath smitten my life down to the ground; he hath made me to dwell in darkness, as those that have been long dead.

Psalms 143:4 Therefore is my spirit overwhelmed within me; my heart within me is desolate.

Psalms 143:5 I remember the days of old; I meditate on all thy works; I muse on the work of thy hands.

Psalms 143:6 I stretch forth my hands unto thee: my soul thirsteth after thee, as a thirsty land. Selah.

Psalms 143:7 Hear me speedily, O Lord: my spirit faileth: hide not thy face from me, lest I be like unto them that go down into the pit.

Psalms 143:8 Cause me to hear thy lovingkindness in the morning; for in thee do I trust: cause me to know the way wherein I should walk; for I lift up my soul unto thee.

Psalms 143:9 Deliver me, O Lord, from mine enemies: I flee unto thee to hide me.

Psalms 143:10 Teach me to do thy will; for thou art my God: thy spirit is good; lead me into the land of uprightness.

Psalms 143:11 Quicken me, O Lord, for thy name’s sake: for thy righteousness’ sake bring my soul out of trouble.

Psalms 143:12 And of thy mercy cut off mine enemies, and destroy all them that afflict my soul: for I am thy servant.
