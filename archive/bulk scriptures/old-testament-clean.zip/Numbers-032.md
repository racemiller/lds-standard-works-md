# Numbers 32

Numbers 32 (summary): Reuben, Gad, and half the tribe of Manasseh receive their inheritances east of the Jordan—They covenant to join other tribes in conquering Canaan.

Numbers 32:1 Now the children of Reuben and the children of Gad had a very great multitude of cattle: and when they saw the land of Jazer, and the land of Gilead, that, behold, the place was a place for cattle;

Numbers 32:2 The children of Gad and the children of Reuben came and spake unto Moses, and to Eleazar the priest, and unto the princes of the congregation, saying,

Numbers 32:3 Ataroth, and Dibon, and Jazer, and Nimrah, and Heshbon, and Elealeh, and Shebam, and Nebo, and Beon,

Numbers 32:4 Even the country which the Lord smote before the congregation of Israel, is a land for cattle, and thy servants have cattle:

Numbers 32:5 Wherefore, said they, if we have found grace in thy sight, let this land be given unto thy servants for a possession, and bring us not over Jordan.

Numbers 32:6 And Moses said unto the children of Gad and to the children of Reuben, Shall your brethren go to war, and shall ye sit here?

Numbers 32:7 And wherefore discourage ye the heart of the children of Israel from going over into the land which the Lord hath given them?

Numbers 32:8 Thus did your fathers, when I sent them from Kadesh-barnea to see the land.

Numbers 32:9 For when they went up unto the valley of Eshcol, and saw the land, they discouraged the heart of the children of Israel, that they should not go into the land which the Lord had given them.

Numbers 32:10 And the Lord’s anger was kindled the same time, and he sware, saying,

Numbers 32:11 Surely none of the men that came up out of Egypt, from twenty years old and upward, shall see the land which I sware unto Abraham, unto Isaac, and unto Jacob; because they have not wholly followed me:

Numbers 32:12 Save Caleb the son of Jephunneh the Kenezite, and Joshua the son of Nun: for they have wholly followed the Lord.

Numbers 32:13 And the Lord’s anger was kindled against Israel, and he made them wander in the wilderness forty years, until all the generation, that had done evil in the sight of the Lord, was consumed.

Numbers 32:14 And, behold, ye are risen up in your fathers’ stead, an increase of sinful men, to augment yet the fierce anger of the Lord toward Israel.

Numbers 32:15 For if ye turn away from after him, he will yet again leave them in the wilderness; and ye shall destroy all this people.

Numbers 32:16 And they came near unto him, and said, We will build sheepfolds here for our cattle, and cities for our little ones:

Numbers 32:17 But we ourselves will go ready armed before the children of Israel, until we have brought them unto their place: and our little ones shall dwell in the fenced cities because of the inhabitants of the land.

Numbers 32:18 We will not return unto our houses, until the children of Israel have inherited every man his inheritance.

Numbers 32:19 For we will not inherit with them on yonder side Jordan, or forward; because our inheritance is fallen to us on this side Jordan eastward.

Numbers 32:20 And Moses said unto them, If ye will do this thing, if ye will go armed before the Lord to war,

Numbers 32:21 And will go all of you armed over Jordan before the Lord, until he hath driven out his enemies from before him,

Numbers 32:22 And the land be subdued before the Lord: then afterward ye shall return, and be guiltless before the Lord, and before Israel; and this land shall be your possession before the Lord.

Numbers 32:23 But if ye will not do so, behold, ye have sinned against the Lord: and be sure your sin will find you out.

Numbers 32:24 Build you cities for your little ones, and folds for your sheep; and do that which hath proceeded out of your mouth.

Numbers 32:25 And the children of Gad and the children of Reuben spake unto Moses, saying, Thy servants will do as my lord commandeth.

Numbers 32:26 Our little ones, our wives, our flocks, and all our cattle, shall be there in the cities of Gilead:

Numbers 32:27 But thy servants will pass over, every man armed for war, before the Lord to battle, as my lord saith.

Numbers 32:28 So concerning them Moses commanded Eleazar the priest, and Joshua the son of Nun, and the chief fathers of the tribes of the children of Israel:

Numbers 32:29 And Moses said unto them, If the children of Gad and the children of Reuben will pass with you over Jordan, every man armed to battle, before the Lord, and the land shall be subdued before you; then ye shall give them the land of Gilead for a possession:

Numbers 32:30 But if they will not pass over with you armed, they shall have possessions among you in the land of Canaan.

Numbers 32:31 And the children of Gad and the children of Reuben answered, saying, As the Lord hath said unto thy servants, so will we do.

Numbers 32:32 We will pass over armed before the Lord into the land of Canaan, that the possession of our inheritance on this side Jordan may be ours.

Numbers 32:33 And Moses gave unto them, even to the children of Gad, and to the children of Reuben, and unto half the tribe of Manasseh the son of Joseph, the kingdom of Sihon king of the Amorites, and the kingdom of Og king of Bashan, the land, with the cities thereof in the coasts, even the cities of the country round about.

Numbers 32:34 And the children of Gad built Dibon, and Ataroth, and Aroer,

Numbers 32:35 And Atroth, Shophan, and Jaazer, and Jogbehah,

Numbers 32:36 And Beth-nimrah, and Beth-haran, fenced cities: and folds for sheep.

Numbers 32:37 And the children of Reuben built Heshbon, and Elealeh, and Kirjathaim,

Numbers 32:38 And Nebo, and Baal-meon, (their names being changed,) and Shibmah: and gave other names unto the cities which they builded.

Numbers 32:39 And the children of Machir the son of Manasseh went to Gilead, and took it, and dispossessed the Amorite which was in it.

Numbers 32:40 And Moses gave Gilead unto Machir the son of Manasseh; and he dwelt therein.

Numbers 32:41 And Jair the son of Manasseh went and took the small towns thereof, and called them Havoth-jair.

Numbers 32:42 And Nobah went and took Kenath, and the villages thereof, and called it Nobah, after his own name.
