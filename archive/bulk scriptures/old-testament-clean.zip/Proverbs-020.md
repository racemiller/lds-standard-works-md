# Proverbs 20

Proverbs 20 (summary): Wine is a mocker, and strong drink is raging—Turn to the Lord, and He will save you.

Proverbs 20:1 Wine is a mocker, strong drink is raging: and whosoever is deceived thereby is not wise.

Proverbs 20:2 The fear of a king is as the roaring of a lion: whoso provoketh him to anger sinneth against his own soul.

Proverbs 20:3 It is an honour for a man to cease from strife: but every fool will be meddling.

Proverbs 20:4 The sluggard will not plow by reason of the cold; therefore shall he beg in harvest, and have nothing.

Proverbs 20:5 Counsel in the heart of man is like deep water; but a man of understanding will draw it out.

Proverbs 20:6 Most men will proclaim every one his own goodness: but a faithful man who can find?

Proverbs 20:7 The just man walketh in his integrity: his children are blessed after him.

Proverbs 20:8 A king that sitteth in the throne of judgment scattereth away all evil with his eyes.

Proverbs 20:9 Who can say, I have made my heart clean, I am pure from my sin?

Proverbs 20:10 Divers weights, and divers measures, both of them are alike abomination to the Lord.

Proverbs 20:11 Even a child is known by his doings, whether his work be pure, and whether it be right.

Proverbs 20:12 The hearing ear, and the seeing eye, the Lord hath made even both of them.

Proverbs 20:13 Love not sleep, lest thou come to poverty; open thine eyes, and thou shalt be satisfied with bread.

Proverbs 20:14 It is naught, it is naught, saith the buyer: but when he is gone his way, then he boasteth.

Proverbs 20:15 There is gold, and a multitude of rubies: but the lips of knowledge are a precious jewel.

Proverbs 20:16 Take his garment that is surety for a stranger: and take a pledge of him for a strange woman.

Proverbs 20:17 Bread of deceit is sweet to a man; but afterwards his mouth shall be filled with gravel.

Proverbs 20:18 Every purpose is established by counsel: and with good advice make war.

Proverbs 20:19 He that goeth about as a talebearer revealeth secrets: therefore meddle not with him that flattereth with his lips.

Proverbs 20:20 Whoso curseth his father or his mother, his lamp shall be put out in obscure darkness.

Proverbs 20:21 An inheritance may be gotten hastily at the beginning; but the end thereof shall not be blessed.

Proverbs 20:22 Say not thou, I will recompense evil; but wait on the Lord, and he shall save thee.

Proverbs 20:23 Divers weights are an abomination unto the Lord; and a false balance is not good.

Proverbs 20:24 Man’s goings are of the Lord; how can a man then understand his own way?

Proverbs 20:25 It is a snare to the man who devoureth that which is holy, and after vows to make inquiry.

Proverbs 20:26 A wise king scattereth the wicked, and bringeth the wheel over them.

Proverbs 20:27 The spirit of man is the candle of the Lord, searching all the inward parts of the belly.

Proverbs 20:28 Mercy and truth preserve the king: and his throne is upholden by mercy.

Proverbs 20:29 The glory of young men is their strength: and the beauty of old men is the gray head.

Proverbs 20:30 The blueness of a wound cleanseth away evil: so do stripes the inward parts of the belly.
