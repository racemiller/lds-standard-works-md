# 1 Samuel 20

1 Samuel 20 (summary): David and Jonathan make a covenant of friendship and peace—They take leave of each other.

1 Samuel 20:1 And David fled from Naioth in Ramah, and came and said before Jonathan, What have I done? what is mine iniquity? and what is my sin before thy father, that he seeketh my life?

1 Samuel 20:2 And he said unto him, God forbid; thou shalt not die: behold, my father will do nothing either great or small, but that he will shew it me: and why should my father hide this thing from me? it is not so.

1 Samuel 20:3 And David sware moreover, and said, Thy father certainly knoweth that I have found grace in thine eyes; and he saith, Let not Jonathan know this, lest he be grieved: but truly as the Lord liveth, and as thy soul liveth, there is but a step between me and death.

1 Samuel 20:4 Then said Jonathan unto David, Whatsoever thy soul desireth, I will even do it for thee.

1 Samuel 20:5 And David said unto Jonathan, Behold, to morrow is the new moon, and I should not fail to sit with the king at meat: but let me go, that I may hide myself in the field unto the third day at even.

1 Samuel 20:6 If thy father at all miss me, then say, David earnestly asked leave of me that he might run to Beth-lehem his city: for there is a yearly sacrifice there for all the family.

1 Samuel 20:7 If he say thus, It is well; thy servant shall have peace: but if he be very wroth, then be sure that evil is determined by him.

1 Samuel 20:8 Therefore thou shalt deal kindly with thy servant; for thou hast brought thy servant into a covenant of the Lord with thee: notwithstanding, if there be in me iniquity, slay me thyself; for why shouldest thou bring me to thy father?

1 Samuel 20:9 And Jonathan said, Far be it from thee: for if I knew certainly that evil were determined by my father to come upon thee, then would not I tell it thee?

1 Samuel 20:10 Then said David to Jonathan, Who shall tell me? or what if thy father answer thee roughly?

1 Samuel 20:11 And Jonathan said unto David, Come, and let us go out into the field. And they went out both of them into the field.

1 Samuel 20:12 And Jonathan said unto David, O Lord God of Israel, when I have sounded my father about to morrow any time, or the third day, and, behold, if there be good toward David, and I then send not unto thee, and shew it thee;

1 Samuel 20:13 The Lord do so and much more to Jonathan: but if it please my father to do thee evil, then I will shew it thee, and send thee away, that thou mayest go in peace: and the Lord be with thee, as he hath been with my father.

1 Samuel 20:14 And thou shalt not only while yet I live shew me the kindness of the Lord, that I die not:

1 Samuel 20:15 But also thou shalt not cut off thy kindness from my house for ever: no, not when the Lord hath cut off the enemies of David every one from the face of the earth.

1 Samuel 20:16 So Jonathan made a covenant with the house of David, saying, Let the Lord even require it at the hand of David’s enemies.

1 Samuel 20:17 And Jonathan caused David to swear again, because he loved him: for he loved him as he loved his own soul.

1 Samuel 20:18 Then Jonathan said to David, To morrow is the new moon: and thou shalt be missed, because thy seat will be empty.

1 Samuel 20:19 And when thou hast stayed three days, then thou shalt go down quickly, and come to the place where thou didst hide thyself when the business was in hand, and shalt remain by the stone Ezel.

1 Samuel 20:20 And I will shoot three arrows on the side thereof, as though I shot at a mark.

1 Samuel 20:21 And, behold, I will send a lad, saying, Go, find out the arrows. If I expressly say unto the lad, Behold, the arrows are on this side of thee, take them; then come thou: for there is peace to thee, and no hurt; as the Lord liveth.

1 Samuel 20:22 But if I say thus unto the young man, Behold, the arrows are beyond thee; go thy way: for the Lord hath sent thee away.

1 Samuel 20:23 And as touching the matter which thou and I have spoken of, behold, the Lord be between thee and me for ever.

1 Samuel 20:24 So David hid himself in the field: and when the new moon was come, the king sat him down to eat meat.

1 Samuel 20:25 And the king sat upon his seat, as at other times, even upon a seat by the wall: and Jonathan arose, and Abner sat by Saul’s side, and David’s place was empty.

1 Samuel 20:26 Nevertheless Saul spake not any thing that day: for he thought, Something hath befallen him, he is not clean; surely he is not clean.

1 Samuel 20:27 And it came to pass on the morrow, which was the second day of the month, that David’s place was empty: and Saul said unto Jonathan his son, Wherefore cometh not the son of Jesse to meat, neither yesterday, nor to day?

1 Samuel 20:28 And Jonathan answered Saul, David earnestly asked leave of me to go to Beth-lehem:

1 Samuel 20:29 And he said, Let me go, I pray thee; for our family hath a sacrifice in the city; and my brother, he hath commanded me to be there: and now, if I have found favour in thine eyes, let me get away, I pray thee, and see my brethren. Therefore he cometh not unto the king’s table.

1 Samuel 20:30 Then Saul’s anger was kindled against Jonathan, and he said unto him, Thou son of the perverse rebellious woman, do not I know that thou hast chosen the son of Jesse to thine own confusion, and unto the confusion of thy mother’s nakedness?

1 Samuel 20:31 For as long as the son of Jesse liveth upon the ground, thou shalt not be established, nor thy kingdom. Wherefore now send and fetch him unto me, for he shall surely die.

1 Samuel 20:32 And Jonathan answered Saul his father, and said unto him, Wherefore shall he be slain? what hath he done?

1 Samuel 20:33 And Saul cast a javelin at him to smite him: whereby Jonathan knew that it was determined of his father to slay David.

1 Samuel 20:34 So Jonathan arose from the table in fierce anger, and did eat no meat the second day of the month: for he was grieved for David, because his father had done him shame.

1 Samuel 20:35 And it came to pass in the morning, that Jonathan went out into the field at the time appointed with David, and a little lad with him.

1 Samuel 20:36 And he said unto his lad, Run, find out now the arrows which I shoot. And as the lad ran, he shot an arrow beyond him.

1 Samuel 20:37 And when the lad was come to the place of the arrow which Jonathan had shot, Jonathan cried after the lad, and said, Is not the arrow beyond thee?

1 Samuel 20:38 And Jonathan cried after the lad, Make speed, haste, stay not. And Jonathan’s lad gathered up the arrows, and came to his master.

1 Samuel 20:39 But the lad knew not any thing: only Jonathan and David knew the matter.

1 Samuel 20:40 And Jonathan gave his artillery unto his lad, and said unto him, Go, carry them to the city.

1 Samuel 20:41 And as soon as the lad was gone, David arose out of a place toward the south, and fell on his face to the ground, and bowed himself three times: and they kissed one another, and wept one with another, until David exceeded.

1 Samuel 20:42 And Jonathan said to David, Go in peace, forasmuch as we have sworn both of us in the name of the Lord, saying, The Lord be between me and thee, and between my seed and thy seed for ever. And he arose and departed: and Jonathan went into the city.
