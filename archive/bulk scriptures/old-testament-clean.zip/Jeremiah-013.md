# Jeremiah 13

Jeremiah 13 (summary): Israel and Judah will be as a rotted and decayed belt—The people are commanded to repent—Judah will be taken captive and scattered as stubble.

Jeremiah 13:1 Thus saith the Lord unto me, Go and get thee a linen girdle, and put it upon thy loins, and put it not in water.

Jeremiah 13:2 So I got a girdle according to the word of the Lord, and put it on my loins.

Jeremiah 13:3 And the word of the Lord came unto me the second time, saying,

Jeremiah 13:4 Take the girdle that thou hast got, which is upon thy loins, and arise, go to Euphrates, and hide it there in a hole of the rock.

Jeremiah 13:5 So I went, and hid it by Euphrates, as the Lord commanded me.

Jeremiah 13:6 And it came to pass after many days, that the Lord said unto me, Arise, go to Euphrates, and take the girdle from thence, which I commanded thee to hide there.

Jeremiah 13:7 Then I went to Euphrates, and digged, and took the girdle from the place where I had hid it: and, behold, the girdle was marred, it was profitable for nothing.

Jeremiah 13:8 Then the word of the Lord came unto me, saying,

Jeremiah 13:9 Thus saith the Lord, After this manner will I mar the pride of Judah, and the great pride of Jerusalem.

Jeremiah 13:10 This evil people, which refuse to hear my words, which walk in the imagination of their heart, and walk after other gods, to serve them, and to worship them, shall even be as this girdle, which is good for nothing.

Jeremiah 13:11 For as the girdle cleaveth to the loins of a man, so have I caused to cleave unto me the whole house of Israel and the whole house of Judah, saith the Lord; that they might be unto me for a people, and for a name, and for a praise, and for a glory: but they would not hear.

Jeremiah 13:12 Therefore thou shalt speak unto them this word; Thus saith the Lord God of Israel, Every bottle shall be filled with wine: and they shall say unto thee, Do we not certainly know that every bottle shall be filled with wine?

Jeremiah 13:13 Then shalt thou say unto them, Thus saith the Lord, Behold, I will fill all the inhabitants of this land, even the kings that sit upon David’s throne, and the priests, and the prophets, and all the inhabitants of Jerusalem, with drunkenness.

Jeremiah 13:14 And I will dash them one against another, even the fathers and the sons together, saith the Lord: I will not pity, nor spare, nor have mercy, but destroy them.

Jeremiah 13:15 Hear ye, and give ear; be not proud: for the Lord hath spoken.

Jeremiah 13:16 Give glory to the Lord your God, before he cause darkness, and before your feet stumble upon the dark mountains, and, while ye look for light, he turn it into the shadow of death, and make it gross darkness.

Jeremiah 13:17 But if ye will not hear it, my soul shall weep in secret places for your pride; and mine eye shall weep sore, and run down with tears, because the Lord’s flock is carried away captive.

Jeremiah 13:18 Say unto the king and to the queen, Humble yourselves, sit down: for your principalities shall come down, even the crown of your glory.

Jeremiah 13:19 The cities of the south shall be shut up, and none shall open them: Judah shall be carried away captive all of it, it shall be wholly carried away captive.

Jeremiah 13:20 Lift up your eyes, and behold them that come from the north: where is the flock that was given thee, thy beautiful flock?

Jeremiah 13:21 What wilt thou say when he shall punish thee? for thou hast taught them to be captains, and as chief over thee: shall not sorrows take thee, as a woman in travail?

Jeremiah 13:22 And if thou say in thine heart, Wherefore come these things upon me? For the greatness of thine iniquity are thy skirts discovered, and thy heels made bare.

Jeremiah 13:23 Can the Ethiopian change his skin, or the leopard his spots? then may ye also do good, that are accustomed to do evil.

Jeremiah 13:24 Therefore will I scatter them as the stubble that passeth away by the wind of the wilderness.

Jeremiah 13:25 This is thy lot, the portion of thy measures from me, saith the Lord; because thou hast forgotten me, and trusted in falsehood.

Jeremiah 13:26 Therefore will I discover thy skirts upon thy face, that thy shame may appear.

Jeremiah 13:27 I have seen thine adulteries, and thy neighings, the lewdness of thy whoredom, and thine abominations on the hills in the fields. Woe unto thee, O Jerusalem! wilt thou not be made clean? when shall it once be?
