# Ezekiel 24

Ezekiel 24 (summary): The irrevocable judgment of Jerusalem is foretold—As a sign to the Jews, Ezekiel does not weep at his wife’s death.

Ezekiel 24:1 Again in the ninth year, in the tenth month, in the tenth day of the month, the word of the Lord came unto me, saying,

Ezekiel 24:2 Son of man, write thee the name of the day, even of this same day: the king of Babylon set himself against Jerusalem this same day.

Ezekiel 24:3 And utter a parable unto the rebellious house, and say unto them, Thus saith the Lord God; Set on a pot, set it on, and also pour water into it:

Ezekiel 24:4 Gather the pieces thereof into it, even every good piece, the thigh, and the shoulder; fill it with the choice bones.

Ezekiel 24:5 Take the choice of the flock, and burn also the bones under it, and make it boil well, and let them seethe the bones of it therein.

Ezekiel 24:6 Wherefore thus saith the Lord God; Woe to the bloody city, to the pot whose scum is therein, and whose scum is not gone out of it! bring it out piece by piece; let no lot fall upon it.

Ezekiel 24:7 For her blood is in the midst of her; she set it upon the top of a rock; she poured it not upon the ground, to cover it with dust;

Ezekiel 24:8 That it might cause fury to come up to take vengeance; I have set her blood upon the top of a rock, that it should not be covered.

Ezekiel 24:9 Therefore thus saith the Lord God; Woe to the bloody city! I will even make the pile for fire great.

Ezekiel 24:10 Heap on wood, kindle the fire, consume the flesh, and spice it well, and let the bones be burned.

Ezekiel 24:11 Then set it empty upon the coals thereof, that the brass of it may be hot, and may burn, and that the filthiness of it may be molten in it, that the scum of it may be consumed.

Ezekiel 24:12 She hath wearied herself with lies, and her great scum went not forth out of her: her scum shall be in the fire.

Ezekiel 24:13 In thy filthiness is lewdness: because I have purged thee, and thou wast not purged, thou shalt not be purged from thy filthiness any more, till I have caused my fury to rest upon thee.

Ezekiel 24:14 I the Lord have spoken it: it shall come to pass, and I will do it; I will not go back, neither will I spare, neither will I repent; according to thy ways, and according to thy doings, shall they judge thee, saith the Lord God.

Ezekiel 24:15 Also the word of the Lord came unto me, saying,

Ezekiel 24:16 Son of man, behold, I take away from thee the desire of thine eyes with a stroke: yet neither shalt thou mourn nor weep, neither shall thy tears run down.

Ezekiel 24:17 Forbear to cry, make no mourning for the dead, bind the tire of thine head upon thee, and put on thy shoes upon thy feet, and cover not thy lips, and eat not the bread of men.

Ezekiel 24:18 So I spake unto the people in the morning: and at even my wife died; and I did in the morning as I was commanded.

Ezekiel 24:19 And the people said unto me, Wilt thou not tell us what these things are to us, that thou doest so?

Ezekiel 24:20 Then I answered them, The word of the Lord came unto me, saying,

Ezekiel 24:21 Speak unto the house of Israel, Thus saith the Lord God; Behold, I will profane my sanctuary, the excellency of your strength, the desire of your eyes, and that which your soul pitieth; and your sons and your daughters whom ye have left shall fall by the sword.

Ezekiel 24:22 And ye shall do as I have done: ye shall not cover your lips, nor eat the bread of men.

Ezekiel 24:23 And your tires shall be upon your heads, and your shoes upon your feet: ye shall not mourn nor weep; but ye shall pine away for your iniquities, and mourn one toward another.

Ezekiel 24:24 Thus Ezekiel is unto you a sign: according to all that he hath done shall ye do: and when this cometh, ye shall know that I am the Lord God.

Ezekiel 24:25 Also, thou son of man, shall it not be in the day when I take from them their strength, the joy of their glory, the desire of their eyes, and that whereupon they set their minds, their sons and their daughters,

Ezekiel 24:26 That he that escapeth in that day shall come unto thee, to cause thee to hear it with thine ears?

Ezekiel 24:27 In that day shall thy mouth be opened to him which is escaped, and thou shalt speak, and be no more dumb: and thou shalt be a sign unto them; and they shall know that I am the Lord.
