# 1 Samuel 16

1 Samuel 16 (summary): The Lord chooses David of Bethlehem as king—He is anointed by Samuel—Saul chooses David as his companion and armor bearer.

1 Samuel 16:1 And the Lord said unto Samuel, How long wilt thou mourn for Saul, seeing I have rejected him from reigning over Israel? fill thine horn with oil, and go, I will send thee to Jesse the Beth-lehemite: for I have provided me a king among his sons.

1 Samuel 16:2 And Samuel said, How can I go? if Saul hear it, he will kill me. And the Lord said, Take an heifer with thee, and say, I am come to sacrifice to the Lord.

1 Samuel 16:3 And call Jesse to the sacrifice, and I will shew thee what thou shalt do: and thou shalt anoint unto me him whom I name unto thee.

1 Samuel 16:4 And Samuel did that which the Lord spake, and came to Beth-lehem. And the elders of the town trembled at his coming, and said, Comest thou peaceably?

1 Samuel 16:5 And he said, Peaceably: I am come to sacrifice unto the Lord: sanctify yourselves, and come with me to the sacrifice. And he sanctified Jesse and his sons, and called them to the sacrifice.

1 Samuel 16:6 And it came to pass, when they were come, that he looked on Eliab, and said, Surely the Lord’s anointed is before him.

1 Samuel 16:7 But the Lord said unto Samuel, Look not on his countenance, or on the height of his stature; because I have refused him: for the Lord seeth not as man seeth; for man looketh on the outward appearance, but the Lord looketh on the heart.

1 Samuel 16:8 Then Jesse called Abinadab, and made him pass before Samuel. And he said, Neither hath the Lord chosen this.

1 Samuel 16:9 Then Jesse made Shammah to pass by. And he said, Neither hath the Lord chosen this.

1 Samuel 16:10 Again, Jesse made seven of his sons to pass before Samuel. And Samuel said unto Jesse, The Lord hath not chosen these.

1 Samuel 16:11 And Samuel said unto Jesse, Are here all thy children? And he said, There remaineth yet the youngest, and, behold, he keepeth the sheep. And Samuel said unto Jesse, Send and fetch him: for we will not sit down till he come hither.

1 Samuel 16:12 And he sent, and brought him in. Now he was ruddy, and withal of a beautiful countenance, and goodly to look to. And the Lord said, Arise, anoint him: for this is he.

1 Samuel 16:13 Then Samuel took the horn of oil, and anointed him in the midst of his brethren: and the Spirit of the Lord came upon David from that day forward. So Samuel rose up, and went to Ramah.

1 Samuel 16:14 But the Spirit of the Lord departed from Saul, and an evil spirit from the Lord troubled him.

1 Samuel 16:15 And Saul’s servants said unto him, Behold now, an evil spirit from God troubleth thee.

1 Samuel 16:16 Let our lord now command thy servants, which are before thee, to seek out a man, who is a cunning player on an harp: and it shall come to pass, when the evil spirit from God is upon thee, that he shall play with his hand, and thou shalt be well.

1 Samuel 16:17 And Saul said unto his servants, Provide me now a man that can play well, and bring him to me.

1 Samuel 16:18 Then answered one of the servants, and said, Behold, I have seen a son of Jesse the Beth-lehemite, that is cunning in playing, and a mighty valiant man, and a man of war, and prudent in matters, and a comely person, and the Lord is with him.

1 Samuel 16:19 Wherefore Saul sent messengers unto Jesse, and said, Send me David thy son, which is with the sheep.

1 Samuel 16:20 And Jesse took an ass laden with bread, and a bottle of wine, and a kid, and sent them by David his son unto Saul.

1 Samuel 16:21 And David came to Saul, and stood before him: and he loved him greatly; and he became his armourbearer.

1 Samuel 16:22 And Saul sent to Jesse, saying, Let David, I pray thee, stand before me; for he hath found favour in my sight.

1 Samuel 16:23 And it came to pass, when the evil spirit from God was upon Saul, that David took an harp, and played with his hand: so Saul was refreshed, and was well, and the evil spirit departed from him.
