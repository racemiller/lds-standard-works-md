# Deuteronomy 17

Deuteronomy 17 (summary): Those who worship false gods will be put to death—Priests and judges are to determine the hard cases—Kings are not to acquire horses, wives, or gold for themselves—The king must study the laws of God daily.

Deuteronomy 17:1 Thou shalt not sacrifice unto the Lord thy God any bullock, or sheep, wherein is blemish, or any evilfavouredness: for that is an abomination unto the Lord thy God.

Deuteronomy 17:2 If there be found among you, within any of thy gates which the Lord thy God giveth thee, man or woman, that hath wrought wickedness in the sight of the Lord thy God, in transgressing his covenant,

Deuteronomy 17:3 And hath gone and served other gods, and worshipped them, either the sun, or moon, or any of the host of heaven, which I have not commanded;

Deuteronomy 17:4 And it be told thee, and thou hast heard of it, and inquired diligently, and, behold, it be true, and the thing certain, that such abomination is wrought in Israel:

Deuteronomy 17:5 Then shalt thou bring forth that man or that woman, which have committed that wicked thing, unto thy gates, even that man or that woman, and shalt stone them with stones, till they die.

Deuteronomy 17:6 At the mouth of two witnesses, or three witnesses, shall he that is worthy of death be put to death; but at the mouth of one witness he shall not be put to death.

Deuteronomy 17:7 The hands of the witnesses shall be first upon him to put him to death, and afterward the hands of all the people. So thou shalt put the evil away from among you.

Deuteronomy 17:8 If there arise a matter too hard for thee in judgment, between blood and blood, between plea and plea, and between stroke and stroke, being matters of controversy within thy gates: then shalt thou arise, and get thee up into the place which the Lord thy God shall choose;

Deuteronomy 17:9 And thou shalt come unto the priests the Levites, and unto the judge that shall be in those days, and inquire; and they shall shew thee the sentence of judgment:

Deuteronomy 17:10 And thou shalt do according to the sentence, which they of that place which the Lord shall choose shall shew thee; and thou shalt observe to do according to all that they inform thee:

Deuteronomy 17:11 According to the sentence of the law which they shall teach thee, and according to the judgment which they shall tell thee, thou shalt do: thou shalt not decline from the sentence which they shall shew thee, to the right hand, nor to the left.

Deuteronomy 17:12 And the man that will do presumptuously, and will not hearken unto the priest that standeth to minister there before the Lord thy God, or unto the judge, even that man shall die: and thou shalt put away the evil from Israel.

Deuteronomy 17:13 And all the people shall hear, and fear, and do no more presumptuously.

Deuteronomy 17:14 When thou art come unto the land which the Lord thy God giveth thee, and shalt possess it, and shalt dwell therein, and shalt say, I will set a king over me, like as all the nations that are about me;

Deuteronomy 17:15 Thou shalt in any wise set him king over thee, whom the Lord thy God shall choose: one from among thy brethren shalt thou set king over thee: thou mayest not set a stranger over thee, which is not thy brother.

Deuteronomy 17:16 But he shall not multiply horses to himself, nor cause the people to return to Egypt, to the end that he should multiply horses: forasmuch as the Lord hath said unto you, Ye shall henceforth return no more that way.

Deuteronomy 17:17 Neither shall he multiply wives to himself, that his heart turn not away: neither shall he greatly multiply to himself silver and gold.

Deuteronomy 17:18 And it shall be, when he sitteth upon the throne of his kingdom, that he shall write him a copy of this law in a book out of that which is before the priests the Levites:

Deuteronomy 17:19 And it shall be with him, and he shall read therein all the days of his life: that he may learn to fear the Lord his God, to keep all the words of this law and these statutes, to do them:

Deuteronomy 17:20 That his heart be not lifted up above his brethren, and that he turn not aside from the commandment, to the right hand, or to the left: to the end that he may prolong his days in his kingdom, he, and his children, in the midst of Israel.
