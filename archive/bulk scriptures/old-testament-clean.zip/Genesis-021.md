# Genesis 21

Genesis 21 (summary): Sarah bears Isaac—He is circumcised—Hagar and her son are cast out of Abraham’s household—The Lord saves Hagar and Ishmael—Abraham and Abimelech deal honorably with each other.

Genesis 21:1 And the Lord visited Sarah as he had said, and the Lord did unto Sarah as he had spoken.

Genesis 21:2 For Sarah conceived, and bare Abraham a son in his old age, at the set time of which God had spoken to him.

Genesis 21:3 And Abraham called the name of his son that was born unto him, whom Sarah bare to him, Isaac.

Genesis 21:4 And Abraham circumcised his son Isaac being eight days old, as God had commanded him.

Genesis 21:5 And Abraham was an hundred years old, when his son Isaac was born unto him.

Genesis 21:6 And Sarah said, God hath made me to laugh, so that all that hear will laugh with me.

Genesis 21:7 And she said, Who would have said unto Abraham, that Sarah should have given children suck? for I have born him a son in his old age.

Genesis 21:8 And the child grew, and was weaned: and Abraham made a great feast the same day that Isaac was weaned.

Genesis 21:9 And Sarah saw the son of Hagar the Egyptian, which she had born unto Abraham, mocking.

Genesis 21:10 Wherefore she said unto Abraham, Cast out this bondwoman and her son: for the son of this bondwoman shall not be heir with my son, even with Isaac.

Genesis 21:11 And the thing was very grievous in Abraham’s sight because of his son.

Genesis 21:12 And God said unto Abraham, Let it not be grievous in thy sight because of the lad, and because of thy bondwoman; in all that Sarah hath said unto thee, hearken unto her voice; for in Isaac shall thy seed be called.

Genesis 21:13 And also of the son of the bondwoman will I make a nation, because he is thy seed.

Genesis 21:14 And Abraham rose up early in the morning, and took bread, and a bottle of water, and gave it unto Hagar, putting it on her shoulder, and the child, and sent her away: and she departed, and wandered in the wilderness of Beer-sheba.

Genesis 21:15 And the water was spent in the bottle, and she cast the child under one of the shrubs.

Genesis 21:16 And she went, and sat her down over against him a good way off, as it were a bowshot: for she said, Let me not see the death of the child. And she sat over against him, and lift up her voice, and wept.

Genesis 21:17 And God heard the voice of the lad; and the angel of God called to Hagar out of heaven, and said unto her, What aileth thee, Hagar? fear not; for God hath heard the voice of the lad where he is.

Genesis 21:18 Arise, lift up the lad, and hold him in thine hand; for I will make him a great nation.

Genesis 21:19 And God opened her eyes, and she saw a well of water; and she went, and filled the bottle with water, and gave the lad drink.

Genesis 21:20 And God was with the lad; and he grew, and dwelt in the wilderness, and became an archer.

Genesis 21:21 And he dwelt in the wilderness of Paran: and his mother took him a wife out of the land of Egypt.

Genesis 21:22 And it came to pass at that time, that Abimelech and Phichol the chief captain of his host spake unto Abraham, saying, God is with thee in all that thou doest:

Genesis 21:23 Now therefore swear unto me here by God that thou wilt not deal falsely with me, nor with my son, nor with my son’s son: but according to the kindness that I have done unto thee, thou shalt do unto me, and to the land wherein thou hast sojourned.

Genesis 21:24 And Abraham said, I will swear.

Genesis 21:25 And Abraham reproved Abimelech because of a well of water, which Abimelech’s servants had violently taken away.

Genesis 21:26 And Abimelech said, I wot not who hath done this thing: neither didst thou tell me, neither yet heard I of it, but to day.

Genesis 21:27 And Abraham took sheep and oxen, and gave them unto Abimelech; and both of them made a covenant.

Genesis 21:28 And Abraham set seven ewe lambs of the flock by themselves.

Genesis 21:29 And Abimelech said unto Abraham, What mean these seven ewe lambs which thou hast set by themselves?

Genesis 21:30 And he said, For these seven ewe lambs shalt thou take of my hand, that they may be a witness unto me, that I have digged this well.

Genesis 21:31 Wherefore he called that place Beer-sheba; because there they sware both of them.

Genesis 21:32 Thus they made a covenant at Beer-sheba: then Abimelech rose up, and Phichol the chief captain of his host, and they returned into the land of the Philistines.

Genesis 21:33 And Abraham planted a grove in Beer-sheba, and called there on the name of the Lord, the everlasting God.

Genesis 21:34 And Abraham sojourned in the Philistines’ land many days.
