# Joshua 7

Joshua 7 (summary): Israel is defeated by the people of Ai—Joshua complains to the Lord—Achan and his household are destroyed because he disobeyed the Lord by taking the spoils of Jericho.

Joshua 7:1 But the children of Israel committed a trespass in the accursed thing: for Achan, the son of Carmi, the son of Zabdi, the son of Zerah, of the tribe of Judah, took of the accursed thing: and the anger of the Lord was kindled against the children of Israel.

Joshua 7:2 And Joshua sent men from Jericho to Ai, which is beside Beth-aven, on the east side of Beth-el, and spake unto them, saying, Go up and view the country. And the men went up and viewed Ai.

Joshua 7:3 And they returned to Joshua, and said unto him, Let not all the people go up; but let about two or three thousand men go up and smite Ai; and make not all the people to labour thither; for they are but few.

Joshua 7:4 So there went up thither of the people about three thousand men: and they fled before the men of Ai.

Joshua 7:5 And the men of Ai smote of them about thirty and six men: for they chased them from before the gate even unto Shebarim, and smote them in the going down: wherefore the hearts of the people melted, and became as water.

Joshua 7:6 And Joshua rent his clothes, and fell to the earth upon his face before the ark of the Lord until the eventide, he and the elders of Israel, and put dust upon their heads.

Joshua 7:7 And Joshua said, Alas, O Lord God, wherefore hast thou at all brought this people over Jordan, to deliver us into the hand of the Amorites, to destroy us? would to God we had been content, and dwelt on the other side Jordan!

Joshua 7:8 O Lord, what shall I say, when Israel turneth their backs before their enemies!

Joshua 7:9 For the Canaanites and all the inhabitants of the land shall hear of it, and shall environ us round, and cut off our name from the earth: and what wilt thou do unto thy great name?

Joshua 7:10 And the Lord said unto Joshua, Get thee up; wherefore liest thou thus upon thy face?

Joshua 7:11 Israel hath sinned, and they have also transgressed my covenant which I commanded them: for they have even taken of the accursed thing, and have also stolen, and dissembled also, and they have put it even among their own stuff.

Joshua 7:12 Therefore the children of Israel could not stand before their enemies, but turned their backs before their enemies, because they were accursed: neither will I be with you any more, except ye destroy the accursed from among you.

Joshua 7:13 Up, sanctify the people, and say, Sanctify yourselves against to morrow: for thus saith the Lord God of Israel, There is an accursed thing in the midst of thee, O Israel: thou canst not stand before thine enemies, until ye take away the accursed thing from among you.

Joshua 7:14 In the morning therefore ye shall be brought according to your tribes: and it shall be, that the tribe which the Lord taketh shall come according to the families thereof; and the family which the Lord shall take shall come by households; and the household which the Lord shall take shall come man by man.

Joshua 7:15 And it shall be, that he that is taken with the accursed thing shall be burnt with fire, he and all that he hath: because he hath transgressed the covenant of the Lord, and because he hath wrought folly in Israel.

Joshua 7:16 So Joshua rose up early in the morning, and brought Israel by their tribes; and the tribe of Judah was taken:

Joshua 7:17 And he brought the family of Judah; and he took the family of the Zarhites: and he brought the family of the Zarhites man by man; and Zabdi was taken:

Joshua 7:18 And he brought his household man by man; and Achan, the son of Carmi, the son of Zabdi, the son of Zerah, of the tribe of Judah, was taken.

Joshua 7:19 And Joshua said unto Achan, My son, give, I pray thee, glory to the Lord God of Israel, and make confession unto him; and tell me now what thou hast done; hide it not from me.

Joshua 7:20 And Achan answered Joshua, and said, Indeed I have sinned against the Lord God of Israel, and thus and thus have I done:

Joshua 7:21 When I saw among the spoils a goodly Babylonish garment, and two hundred shekels of silver, and a wedge of gold of fifty shekels weight, then I coveted them, and took them; and, behold, they are hid in the earth in the midst of my tent, and the silver under it.

Joshua 7:22 So Joshua sent messengers, and they ran unto the tent; and, behold, it was hid in his tent, and the silver under it.

Joshua 7:23 And they took them out of the midst of the tent, and brought them unto Joshua, and unto all the children of Israel, and laid them out before the Lord.

Joshua 7:24 And Joshua, and all Israel with him, took Achan the son of Zerah, and the silver, and the garment, and the wedge of gold, and his sons, and his daughters, and his oxen, and his asses, and his sheep, and his tent, and all that he had: and they brought them unto the valley of Achor.

Joshua 7:25 And Joshua said, Why hast thou troubled us? the Lord shall trouble thee this day. And all Israel stoned him with stones, and burned them with fire, after they had stoned them with stones.

Joshua 7:26 And they raised over him a great heap of stones unto this day. So the Lord turned from the fierceness of his anger. Wherefore the name of that place was called, The valley of Achor, unto this day.
