# 1 Chronicles 8

1 Chronicles 8 (summary): The sons and chief men of Benjamin are named.

1 Chronicles 8:1 Now Benjamin begat Bela his firstborn, Ashbel the second, and Aharah the third,

1 Chronicles 8:2 Nohah the fourth, and Rapha the fifth.

1 Chronicles 8:3 And the sons of Bela were, Addar, and Gera, and Abihud,

1 Chronicles 8:4 And Abishua, and Naaman, and Ahoah,

1 Chronicles 8:5 And Gera, and Shephuphan, and Huram.

1 Chronicles 8:6 And these are the sons of Ehud: these are the heads of the fathers of the inhabitants of Geba, and they removed them to Manahath:

1 Chronicles 8:7 And Naaman, and Ahiah, and Gera, he removed them, and begat Uzza, and Ahihud.

1 Chronicles 8:8 And Shaharaim begat children in the country of Moab, after he had sent them away; Hushim and Baara were his wives.

1 Chronicles 8:9 And he begat of Hodesh his wife, Jobab, and Zibia, and Mesha, and Malcham,

1 Chronicles 8:10 And Jeuz, and Shachia, and Mirma. These were his sons, heads of the fathers.

1 Chronicles 8:11 And of Hushim he begat Abitub, and Elpaal.

1 Chronicles 8:12 The sons of Elpaal; Eber, and Misham, and Shamed, who built Ono, and Lod, with the towns thereof:

1 Chronicles 8:13 Beriah also, and Shema, who were heads of the fathers of the inhabitants of Aijalon, who drove away the inhabitants of Gath:

1 Chronicles 8:14 And Ahio, Shashak, and Jeremoth,

1 Chronicles 8:15 And Zebadiah, and Arad, and Ader,

1 Chronicles 8:16 And Michael, and Ispah, and Joha, the sons of Beriah;

1 Chronicles 8:17 And Zebadiah, and Meshullam, and Hezeki, and Heber,

1 Chronicles 8:18 Ishmerai also, and Jezliah, and Jobab, the sons of Elpaal;

1 Chronicles 8:19 And Jakim, and Zichri, and Zabdi,

1 Chronicles 8:20 And Elienai, and Zilthai, and Eliel,

1 Chronicles 8:21 And Adaiah, and Beraiah, and Shimrath, the sons of Shimhi;

1 Chronicles 8:22 And Ishpan, and Heber, and Eliel,

1 Chronicles 8:23 And Abdon, and Zichri, and Hanan,

1 Chronicles 8:24 And Hananiah, and Elam, and Antothijah,

1 Chronicles 8:25 And Iphedeiah, and Penuel, the sons of Shashak;

1 Chronicles 8:26 And Shamsherai, and Shehariah, and Athaliah,

1 Chronicles 8:27 And Jaresiah, and Eliah, and Zichri, the sons of Jeroham.

1 Chronicles 8:28 These were heads of the fathers, by their generations, chief men. These dwelt in Jerusalem.

1 Chronicles 8:29 And at Gibeon dwelt the father of Gibeon; whose wife’s name was Maachah:

1 Chronicles 8:30 And his firstborn son Abdon, and Zur, and Kish, and Baal, and Nadab,

1 Chronicles 8:31 And Gedor, and Ahio, and Zacher.

1 Chronicles 8:32 And Mikloth begat Shimeah. And these also dwelt with their brethren in Jerusalem, over against them.

1 Chronicles 8:33 And Ner begat Kish, and Kish begat Saul, and Saul begat Jonathan, and Malchi-shua, and Abinadab, and Esh-baal.

1 Chronicles 8:34 And the son of Jonathan was Merib-baal; and Merib-baal begat Micah.

1 Chronicles 8:35 And the sons of Micah were, Pithon, and Melech, and Tarea, and Ahaz.

1 Chronicles 8:36 And Ahaz begat Jehoadah; and Jehoadah begat Alemeth, and Azmaveth, and Zimri; and Zimri begat Moza,

1 Chronicles 8:37 And Moza begat Binea: Rapha was his son, Eleasah his son, Azel his son:

1 Chronicles 8:38 And Azel had six sons, whose names are these, Azrikam, Bocheru, and Ishmael, and Sheariah, and Obadiah, and Hanan. All these were the sons of Azel.

1 Chronicles 8:39 And the sons of Eshek his brother were, Ulam his firstborn, Jehush the second, and Eliphelet the third.

1 Chronicles 8:40 And the sons of Ulam were mighty men of valour, archers, and had many sons, and sons’ sons, an hundred and fifty. All these are of the sons of Benjamin.
