# 1 Samuel 4

1 Samuel 4 (summary): The Israelites are smitten and defeated by the Philistines, who also capture the ark of God—Eli’s sons are slain, Eli dies in an accident, and his daughter-in-law dies in childbirth.

1 Samuel 4:1 And the word of Samuel came to all Israel. Now Israel went out against the Philistines to battle, and pitched beside Eben-ezer: and the Philistines pitched in Aphek.

1 Samuel 4:2 And the Philistines put themselves in array against Israel: and when they joined battle, Israel was smitten before the Philistines: and they slew of the army in the field about four thousand men.

1 Samuel 4:3 And when the people were come into the camp, the elders of Israel said, Wherefore hath the Lord smitten us to day before the Philistines? Let us fetch the ark of the covenant of the Lord out of Shiloh unto us, that, when it cometh among us, it may save us out of the hand of our enemies.

1 Samuel 4:4 So the people sent to Shiloh, that they might bring from thence the ark of the covenant of the Lord of hosts, which dwelleth between the cherubims: and the two sons of Eli, Hophni and Phinehas, were there with the ark of the covenant of God.

1 Samuel 4:5 And when the ark of the covenant of the Lord came into the camp, all Israel shouted with a great shout, so that the earth rang again.

1 Samuel 4:6 And when the Philistines heard the noise of the shout, they said, What meaneth the noise of this great shout in the camp of the Hebrews? And they understood that the ark of the Lord was come into the camp.

1 Samuel 4:7 And the Philistines were afraid, for they said, God is come into the camp. And they said, Woe unto us! for there hath not been such a thing heretofore.

1 Samuel 4:8 Woe unto us! who shall deliver us out of the hand of these mighty Gods? these are the Gods that smote the Egyptians with all the plagues in the wilderness.

1 Samuel 4:9 Be strong, and quit yourselves like men, O ye Philistines, that ye be not servants unto the Hebrews, as they have been to you: quit yourselves like men, and fight.

1 Samuel 4:10 And the Philistines fought, and Israel was smitten, and they fled every man into his tent: and there was a very great slaughter; for there fell of Israel thirty thousand footmen.

1 Samuel 4:11 And the ark of God was taken; and the two sons of Eli, Hophni and Phinehas, were slain.

1 Samuel 4:12 And there ran a man of Benjamin out of the army, and came to Shiloh the same day with his clothes rent, and with earth upon his head.

1 Samuel 4:13 And when he came, lo, Eli sat upon a seat by the wayside watching: for his heart trembled for the ark of God. And when the man came into the city, and told it, all the city cried out.

1 Samuel 4:14 And when Eli heard the noise of the crying, he said, What meaneth the noise of this tumult? And the man came in hastily, and told Eli.

1 Samuel 4:15 Now Eli was ninety and eight years old; and his eyes were dim, that he could not see.

1 Samuel 4:16 And the man said unto Eli, I am he that came out of the army, and I fled to day out of the army. And he said, What is there done, my son?

1 Samuel 4:17 And the messenger answered and said, Israel is fled before the Philistines, and there hath been also a great slaughter among the people, and thy two sons also, Hophni and Phinehas, are dead, and the ark of God is taken.

1 Samuel 4:18 And it came to pass, when he made mention of the ark of God, that he fell from off the seat backward by the side of the gate, and his neck brake, and he died: for he was an old man, and heavy. And he had judged Israel forty years.

1 Samuel 4:19 And his daughter in law, Phinehas’ wife, was with child, near to be delivered: and when she heard the tidings that the ark of God was taken, and that her father in law and her husband were dead, she bowed herself and travailed; for her pains came upon her.

1 Samuel 4:20 And about the time of her death the women that stood by her said unto her, Fear not; for thou hast born a son. But she answered not, neither did she regard it.

1 Samuel 4:21 And she named the child I-chabod, saying, The glory is departed from Israel: because the ark of God was taken, and because of her father in law and her husband.

1 Samuel 4:22 And she said, The glory is departed from Israel: for the ark of God is taken.
