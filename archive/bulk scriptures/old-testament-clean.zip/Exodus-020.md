# Exodus 20

Exodus 20 (summary): The Lord reveals the Ten Commandments—Israel is to bear witness that the Lord has spoken from heaven—The children of Israel are forbidden to make gods of silver or gold—They are to make altars of unhewn stones and sacrifice to the Lord thereon.

Exodus 20:1 And God spake all these words, saying,

Exodus 20:2 I am the Lord thy God, which have brought thee out of the land of Egypt, out of the house of bondage.

Exodus 20:3 Thou shalt have no other gods before me.

Exodus 20:4 Thou shalt not make unto thee any graven image, or any likeness of any thing that is in heaven above, or that is in the earth beneath, or that is in the water under the earth:

Exodus 20:5 Thou shalt not bow down thyself to them, nor serve them: for I the Lord thy God am a jealous God, visiting the iniquity of the fathers upon the children unto the third and fourth generation of them that hate me;

Exodus 20:6 And shewing mercy unto thousands of them that love me, and keep my commandments.

Exodus 20:7 Thou shalt not take the name of the Lord thy God in vain; for the Lord will not hold him guiltless that taketh his name in vain.

Exodus 20:8 Remember the sabbath day, to keep it holy.

Exodus 20:9 Six days shalt thou labour, and do all thy work:

Exodus 20:10 But the seventh day is the sabbath of the Lord thy God: in it thou shalt not do any work, thou, nor thy son, nor thy daughter, thy manservant, nor thy maidservant, nor thy cattle, nor thy stranger that is within thy gates:

Exodus 20:11 For in six days the Lord made heaven and earth, the sea, and all that in them is, and rested the seventh day: wherefore the Lord blessed the sabbath day, and hallowed it.

Exodus 20:12 Honour thy father and thy mother: that thy days may be long upon the land which the Lord thy God giveth thee.

Exodus 20:13 Thou shalt not kill.

Exodus 20:14 Thou shalt not commit adultery.

Exodus 20:15 Thou shalt not steal.

Exodus 20:16 Thou shalt not bear false witness against thy neighbour.

Exodus 20:17 Thou shalt not covet thy neighbour’s house, thou shalt not covet thy neighbour’s wife, nor his manservant, nor his maidservant, nor his ox, nor his ass, nor any thing that is thy neighbour’s.

Exodus 20:18 And all the people saw the thunderings, and the lightnings, and the noise of the trumpet, and the mountain smoking: and when the people saw it, they removed, and stood afar off.

Exodus 20:19 And they said unto Moses, Speak thou with us, and we will hear: but let not God speak with us, lest we die.

Exodus 20:20 And Moses said unto the people, Fear not: for God is come to prove you, and that his fear may be before your faces, that ye sin not.

Exodus 20:21 And the people stood afar off, and Moses drew near unto the thick darkness where God was.

Exodus 20:22 And the Lord said unto Moses, Thus thou shalt say unto the children of Israel, Ye have seen that I have talked with you from heaven.

Exodus 20:23 Ye shall not make with me gods of silver, neither shall ye make unto you gods of gold.

Exodus 20:24 An altar of earth thou shalt make unto me, and shalt sacrifice thereon thy burnt offerings, and thy peace offerings, thy sheep, and thine oxen: in all places where I record my name I will come unto thee, and I will bless thee.

Exodus 20:25 And if thou wilt make me an altar of stone, thou shalt not build it of hewn stone: for if thou lift up thy tool upon it, thou hast polluted it.

Exodus 20:26 Neither shalt thou go up by steps unto mine altar, that thy nakedness be not discovered thereon.
