# Isaiah 21

Isaiah 21 (summary): Babylon is fallen, is fallen!—Other nations also are destroyed.

Isaiah 21:1 The burden of the desert of the sea. As whirlwinds in the south pass through; so it cometh from the desert, from a terrible land.

Isaiah 21:2 A grievous vision is declared unto me; the treacherous dealer dealeth treacherously, and the spoiler spoileth. Go up, O Elam: besiege, O Media; all the sighing thereof have I made to cease.

Isaiah 21:3 Therefore are my loins filled with pain: pangs have taken hold upon me, as the pangs of a woman that travaileth: I was bowed down at the hearing of it; I was dismayed at the seeing of it.

Isaiah 21:4 My heart panted, fearfulness affrighted me: the night of my pleasure hath he turned into fear unto me.

Isaiah 21:5 Prepare the table, watch in the watchtower, eat, drink: arise, ye princes, and anoint the shield.

Isaiah 21:6 For thus hath the Lord said unto me, Go, set a watchman, let him declare what he seeth.

Isaiah 21:7 And he saw a chariot with a couple of horsemen, a chariot of asses, and a chariot of camels; and he hearkened diligently with much heed:

Isaiah 21:8 And he cried, A lion: My lord, I stand continually upon the watchtower in the daytime, and I am set in my ward whole nights:

Isaiah 21:9 And, behold, here cometh a chariot of men, with a couple of horsemen. And he answered and said, Babylon is fallen, is fallen; and all the graven images of her gods he hath broken unto the ground.

Isaiah 21:10 O my threshing, and the corn of my floor: that which I have heard of the Lord of hosts, the God of Israel, have I declared unto you.

Isaiah 21:11 The burden of Dumah. He calleth to me out of Seir, Watchman, what of the night? Watchman, what of the night?

Isaiah 21:12 The watchman said, The morning cometh, and also the night: if ye will inquire, inquire ye: return, come.

Isaiah 21:13 The burden upon Arabia. In the forest in Arabia shall ye lodge, O ye travelling companies of Dedanim.

Isaiah 21:14 The inhabitants of the land of Tema brought water to him that was thirsty, they prevented with their bread him that fled.

Isaiah 21:15 For they fled from the swords, from the drawn sword, and from the bent bow, and from the grievousness of war.

Isaiah 21:16 For thus hath the Lord said unto me, Within a year, according to the years of an hireling, and all the glory of Kedar shall fail:

Isaiah 21:17 And the residue of the number of archers, the mighty men of the children of Kedar, shall be diminished: for the Lord God of Israel hath spoken it.
