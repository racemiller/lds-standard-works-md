# 2 Chronicles 9

2 Chronicles 9 (summary): The queen of Sheba visits Solomon—He excels in wisdom, wealth, and magnificence—After reigning forty years, Solomon dies, and Rehoboam becomes king.

2 Chronicles 9:1 And when the queen of Sheba heard of the fame of Solomon, she came to prove Solomon with hard questions at Jerusalem, with a very great company, and camels that bare spices, and gold in abundance, and precious stones: and when she was come to Solomon, she communed with him of all that was in her heart.

2 Chronicles 9:2 And Solomon told her all her questions: and there was nothing hid from Solomon which he told her not.

2 Chronicles 9:3 And when the queen of Sheba had seen the wisdom of Solomon, and the house that he had built,

2 Chronicles 9:4 And the meat of his table, and the sitting of his servants, and the attendance of his ministers, and their apparel; his cupbearers also, and their apparel; and his ascent by which he went up into the house of the Lord; there was no more spirit in her.

2 Chronicles 9:5 And she said to the king, It was a true report which I heard in mine own land of thine acts, and of thy wisdom:

2 Chronicles 9:6 Howbeit I believed not their words, until I came, and mine eyes had seen it: and, behold, the one half of the greatness of thy wisdom was not told me: for thou exceedest the fame that I heard.

2 Chronicles 9:7 Happy are thy men, and happy are these thy servants, which stand continually before thee, and hear thy wisdom.

2 Chronicles 9:8 Blessed be the Lord thy God, which delighted in thee to set thee on his throne, to be king for the Lord thy God: because thy God loved Israel, to establish them for ever, therefore made he thee king over them, to do judgment and justice.

2 Chronicles 9:9 And she gave the king an hundred and twenty talents of gold, and of spices great abundance, and precious stones: neither was there any such spice as the queen of Sheba gave king Solomon.

2 Chronicles 9:10 And the servants also of Huram, and the servants of Solomon, which brought gold from Ophir, brought algum trees and precious stones.

2 Chronicles 9:11 And the king made of the algum trees terraces to the house of the Lord, and to the king’s palace, and harps and psalteries for singers: and there were none such seen before in the land of Judah.

2 Chronicles 9:12 And king Solomon gave to the queen of Sheba all her desire, whatsoever she asked, beside that which she had brought unto the king. So she turned, and went away to her own land, she and her servants.

2 Chronicles 9:13 Now the weight of gold that came to Solomon in one year was six hundred and threescore and six talents of gold;

2 Chronicles 9:14 Beside that which chapmen and merchants brought. And all the kings of Arabia and governors of the country brought gold and silver to Solomon.

2 Chronicles 9:15 And king Solomon made two hundred targets of beaten gold: six hundred shekels of beaten gold went to one target.

2 Chronicles 9:16 And three hundred shields made he of beaten gold: three hundred shekels of gold went to one shield. And the king put them in the house of the forest of Lebanon.

2 Chronicles 9:17 Moreover the king made a great throne of ivory, and overlaid it with pure gold.

2 Chronicles 9:18 And there were six steps to the throne, with a footstool of gold, which were fastened to the throne, and stays on each side of the sitting place, and two lions standing by the stays:

2 Chronicles 9:19 And twelve lions stood there on the one side and on the other upon the six steps. There was not the like made in any kingdom.

2 Chronicles 9:20 And all the drinking vessels of king Solomon were of gold, and all the vessels of the house of the forest of Lebanon were of pure gold: none were of silver; it was not any thing accounted of in the days of Solomon.

2 Chronicles 9:21 For the king’s ships went to Tarshish with the servants of Huram: every three years once came the ships of Tarshish bringing gold, and silver, ivory, and apes, and peacocks.

2 Chronicles 9:22 And king Solomon passed all the kings of the earth in riches and wisdom.

2 Chronicles 9:23 And all the kings of the earth sought the presence of Solomon, to hear his wisdom, that God had put in his heart.

2 Chronicles 9:24 And they brought every man his present, vessels of silver, and vessels of gold, and raiment, harness, and spices, horses, and mules, a rate year by year.

2 Chronicles 9:25 And Solomon had four thousand stalls for horses and chariots, and twelve thousand horsemen; whom he bestowed in the chariot cities, and with the king at Jerusalem.

2 Chronicles 9:26 And he reigned over all the kings from the river even unto the land of the Philistines, and to the border of Egypt.

2 Chronicles 9:27 And the king made silver in Jerusalem as stones, and cedar trees made he as the sycomore trees that are in the low plains in abundance.

2 Chronicles 9:28 And they brought unto Solomon horses out of Egypt, and out of all lands.

2 Chronicles 9:29 Now the rest of the acts of Solomon, first and last, are they not written in the book of Nathan the prophet, and in the prophecy of Ahijah the Shilonite, and in the visions of Iddo the seer against Jeroboam the son of Nebat?

2 Chronicles 9:30 And Solomon reigned in Jerusalem over all Israel forty years.

2 Chronicles 9:31 And Solomon slept with his fathers, and he was buried in the city of David his father: and Rehoboam his son reigned in his stead.
