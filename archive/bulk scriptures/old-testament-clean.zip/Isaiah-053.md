# Isaiah 53

Isaiah 53 (summary): Isaiah speaks about the Messiah—His humiliation and sufferings are described—He makes His soul an offering for sin and makes intercession for the transgressors—Compare Mosiah 14.

Isaiah 53:1 Who hath believed our report? and to whom is the arm of the Lord revealed?

Isaiah 53:2 For he shall grow up before him as a tender plant, and as a root out of a dry ground: he hath no form nor comeliness; and when we shall see him, there is no beauty that we should desire him.

Isaiah 53:3 He is despised and rejected of men; a man of sorrows, and acquainted with grief: and we hid as it were our faces from him; he was despised, and we esteemed him not.

Isaiah 53:4 Surely he hath borne our griefs, and carried our sorrows: yet we did esteem him stricken, smitten of God, and afflicted.

Isaiah 53:5 But he was wounded for our transgressions, he was bruised for our iniquities: the chastisement of our peace was upon him; and with his stripes we are healed.

Isaiah 53:6 All we like sheep have gone astray; we have turned every one to his own way; and the Lord hath laid on him the iniquity of us all.

Isaiah 53:7 He was oppressed, and he was afflicted, yet he opened not his mouth: he is brought as a lamb to the slaughter, and as a sheep before her shearers is dumb, so he openeth not his mouth.

Isaiah 53:8 He was taken from prison and from judgment: and who shall declare his generation? for he was cut off out of the land of the living: for the transgression of my people was he stricken.

Isaiah 53:9 And he made his grave with the wicked, and with the rich in his death; because he had done no violence, neither was any deceit in his mouth.

Isaiah 53:10 Yet it pleased the Lord to bruise him; he hath put him to grief: when thou shalt make his soul an offering for sin, he shall see his seed, he shall prolong his days, and the pleasure of the Lord shall prosper in his hand.

Isaiah 53:11 He shall see of the travail of his soul, and shall be satisfied: by his knowledge shall my righteous servant justify many; for he shall bear their iniquities.

Isaiah 53:12 Therefore will I divide him a portion with the great, and he shall divide the spoil with the strong; because he hath poured out his soul unto death: and he was numbered with the transgressors; and he bare the sin of many, and made intercession for the transgressors.
