# Genesis 46

Genesis 46 (summary): The Lord sends Jacob and his family of seventy souls to Egypt—The descendants of Jacob are named—Joseph meets Jacob.

Genesis 46:1 And Israel took his journey with all that he had, and came to Beer-sheba, and offered sacrifices unto the God of his father Isaac.

Genesis 46:2 And God spake unto Israel in the visions of the night, and said, Jacob, Jacob. And he said, Here am I.

Genesis 46:3 And he said, I am God, the God of thy father: fear not to go down into Egypt; for I will there make of thee a great nation:

Genesis 46:4 I will go down with thee into Egypt; and I will also surely bring thee up again: and Joseph shall put his hand upon thine eyes.

Genesis 46:5 And Jacob rose up from Beer-sheba: and the sons of Israel carried Jacob their father, and their little ones, and their wives, in the wagons which Pharaoh had sent to carry him.

Genesis 46:6 And they took their cattle, and their goods, which they had gotten in the land of Canaan, and came into Egypt, Jacob, and all his seed with him:

Genesis 46:7 His sons, and his sons’ sons with him, his daughters, and his sons’ daughters, and all his seed brought he with him into Egypt.

Genesis 46:8 And these are the names of the children of Israel, which came into Egypt, Jacob and his sons: Reuben, Jacob’s firstborn.

Genesis 46:9 And the sons of Reuben; Hanoch, and Phallu, and Hezron, and Carmi.

Genesis 46:10 And the sons of Simeon; Jemuel, and Jamin, and Ohad, and Jachin, and Zohar, and Shaul the son of a Canaanitish woman.

Genesis 46:11 And the sons of Levi; Gershon, Kohath, and Merari.

Genesis 46:12 And the sons of Judah; Er, and Onan, and Shelah, and Pharez, and Zerah: but Er and Onan died in the land of Canaan. And the sons of Pharez were Hezron and Hamul.

Genesis 46:13 And the sons of Issachar; Tola, and Phuvah, and Job, and Shimron.

Genesis 46:14 And the sons of Zebulun; Sered, and Elon, and Jahleel.

Genesis 46:15 These be the sons of Leah, which she bare unto Jacob in Padan-aram, with his daughter Dinah: all the souls of his sons and his daughters were thirty and three.

Genesis 46:16 And the sons of Gad; Ziphion, and Haggi, Shuni, and Ezbon, Eri, and Arodi, and Areli.

Genesis 46:17 And the sons of Asher; Jimnah, and Ishuah, and Isui, and Beriah, and Serah their sister: and the sons of Beriah; Heber, and Malchiel.

Genesis 46:18 These are the sons of Zilpah, whom Laban gave to Leah his daughter, and these she bare unto Jacob, even sixteen souls.

Genesis 46:19 The sons of Rachel Jacob’s wife; Joseph, and Benjamin.

Genesis 46:20 And unto Joseph in the land of Egypt were born Manasseh and Ephraim, which Asenath the daughter of Poti-pherah priest of On bare unto him.

Genesis 46:21 And the sons of Benjamin were Belah, and Becher, and Ashbel, Gera, and Naaman, Ehi, and Rosh, Muppim, and Huppim, and Ard.

Genesis 46:22 These are the sons of Rachel, which were born to Jacob: all the souls were fourteen.

Genesis 46:23 And the sons of Dan; Hushim.

Genesis 46:24 And the sons of Naphtali; Jahzeel, and Guni, and Jezer, and Shillem.

Genesis 46:25 These are the sons of Bilhah, which Laban gave unto Rachel his daughter, and she bare these unto Jacob: all the souls were seven.

Genesis 46:26 All the souls that came with Jacob into Egypt, which came out of his loins, besides Jacob’s sons’ wives, all the souls were threescore and six;

Genesis 46:27 And the sons of Joseph, which were born him in Egypt, were two souls: all the souls of the house of Jacob, which came into Egypt, were threescore and ten.

Genesis 46:28 And he sent Judah before him unto Joseph, to direct his face unto Goshen; and they came into the land of Goshen.

Genesis 46:29 And Joseph made ready his chariot, and went up to meet Israel his father, to Goshen, and presented himself unto him; and he fell on his neck, and wept on his neck a good while.

Genesis 46:30 And Israel said unto Joseph, Now let me die, since I have seen thy face, because thou art yet alive.

Genesis 46:31 And Joseph said unto his brethren, and unto his father’s house, I will go up, and shew Pharaoh, and say unto him, My brethren, and my father’s house, which were in the land of Canaan, are come unto me;

Genesis 46:32 And the men are shepherds, for their trade hath been to feed cattle; and they have brought their flocks, and their herds, and all that they have.

Genesis 46:33 And it shall come to pass, when Pharaoh shall call you, and shall say, What is your occupation?

Genesis 46:34 That ye shall say, Thy servants’ trade hath been about cattle from our youth even until now, both we, and also our fathers: that ye may dwell in the land of Goshen; for every shepherd is an abomination unto the Egyptians.
