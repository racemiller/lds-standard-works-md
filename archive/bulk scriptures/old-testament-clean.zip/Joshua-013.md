# Joshua 13

Joshua 13 (summary): There remain some lands yet to be possessed—Some inhabitants are not expelled—The inheritances of Reuben, Gad, and one half of Manasseh are confirmed.

Joshua 13:1 Now Joshua was old and stricken in years; and the Lord said unto him, Thou art old and stricken in years, and there remaineth yet very much land to be possessed.

Joshua 13:2 This is the land that yet remaineth: all the borders of the Philistines, and all Geshuri,

Joshua 13:3 From Sihor, which is before Egypt, even unto the borders of Ekron northward, which is counted to the Canaanite: five lords of the Philistines; the Gazathites, and the Ashdothites, the Eshkalonites, the Gittites, and the Ekronites; also the Avites:

Joshua 13:4 From the south, all the land of the Canaanites, and Mearah that is beside the Sidonians, unto Aphek, to the borders of the Amorites:

Joshua 13:5 And the land of the Giblites, and all Lebanon, toward the sunrising, from Baal-gad under mount Hermon unto the entering into Hamath.

Joshua 13:6 All the inhabitants of the hill country from Lebanon unto Misrephoth-maim, and all the Sidonians, them will I drive out from before the children of Israel: only divide thou it by lot unto the Israelites for an inheritance, as I have commanded thee.

Joshua 13:7 Now therefore divide this land for an inheritance unto the nine tribes, and the half tribe of Manasseh,

Joshua 13:8 With whom the Reubenites and the Gadites have received their inheritance, which Moses gave them, beyond Jordan eastward, even as Moses the servant of the Lord gave them;

Joshua 13:9 From Aroer, that is upon the bank of the river Arnon, and the city that is in the midst of the river, and all the plain of Medeba unto Dibon;

Joshua 13:10 And all the cities of Sihon king of the Amorites, which reigned in Heshbon, unto the border of the children of Ammon;

Joshua 13:11 And Gilead, and the border of the Geshurites and Maachathites, and all mount Hermon, and all Bashan unto Salcah;

Joshua 13:12 All the kingdom of Og in Bashan, which reigned in Ashtaroth and in Edrei, who remained of the remnant of the giants: for these did Moses smite, and cast them out.

Joshua 13:13 Nevertheless the children of Israel expelled not the Geshurites, nor the Maachathites: but the Geshurites and the Maachathites dwell among the Israelites until this day.

Joshua 13:14 Only unto the tribe of Levi he gave none inheritance; the sacrifices of the Lord God of Israel made by fire are their inheritance, as he said unto them.

Joshua 13:15 And Moses gave unto the tribe of the children of Reuben inheritance according to their families.

Joshua 13:16 And their coast was from Aroer, that is on the bank of the river Arnon, and the city that is in the midst of the river, and all the plain by Medeba;

Joshua 13:17 Heshbon, and all her cities that are in the plain; Dibon, and Bamoth-baal, and Beth-baal-meon,

Joshua 13:18 And Jahazah, and Kedemoth, and Mephaath,

Joshua 13:19 And Kirjathaim, and Sibmah, and Zareth-shahar in the mount of the valley,

Joshua 13:20 And Beth-peor, and Ashdoth-pisgah, and Beth-jeshimoth,

Joshua 13:21 And all the cities of the plain, and all the kingdom of Sihon king of the Amorites, which reigned in Heshbon, whom Moses smote with the princes of Midian, Evi, and Rekem, and Zur, and Hur, and Reba, which were dukes of Sihon, dwelling in the country.

Joshua 13:22 Balaam also the son of Beor, the soothsayer, did the children of Israel slay with the sword among them that were slain by them.

Joshua 13:23 And the border of the children of Reuben was Jordan, and the border thereof. This was the inheritance of the children of Reuben after their families, the cities and the villages thereof.

Joshua 13:24 And Moses gave inheritance unto the tribe of Gad, even unto the children of Gad according to their families.

Joshua 13:25 And their coast was Jazer, and all the cities of Gilead, and half the land of the children of Ammon, unto Aroer that is before Rabbah;

Joshua 13:26 And from Heshbon unto Ramath-mizpeh, and Betonim; and from Mahanaim unto the border of Debir;

Joshua 13:27 And in the valley, Beth-aram, and Beth-nimrah, and Succoth, and Zaphon, the rest of the kingdom of Sihon king of Heshbon, Jordan and his border, even unto the edge of the sea of Chinnereth on the other side Jordan eastward.

Joshua 13:28 This is the inheritance of the children of Gad after their families, the cities, and their villages.

Joshua 13:29 And Moses gave inheritance unto the half tribe of Manasseh: and this was the possession of the half tribe of the children of Manasseh by their families.

Joshua 13:30 And their coast was from Mahanaim, all Bashan, all the kingdom of Og king of Bashan, and all the towns of Jair, which are in Bashan, threescore cities:

Joshua 13:31 And half Gilead, and Ashtaroth, and Edrei, cities of the kingdom of Og in Bashan, were pertaining unto the children of Machir the son of Manasseh, even to the one half of the children of Machir by their families.

Joshua 13:32 These are the countries which Moses did distribute for inheritance in the plains of Moab, on the other side Jordan, by Jericho, eastward.

Joshua 13:33 But unto the tribe of Levi Moses gave not any inheritance: the Lord God of Israel was their inheritance, as he said unto them.
