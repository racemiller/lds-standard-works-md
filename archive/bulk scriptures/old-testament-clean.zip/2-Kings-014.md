# 2 Kings 14

2 Kings 14 (summary): Amaziah reigns well in Judah—Israel defeats Judah in battle—Jeroboam reigns in wickedness in Israel.

2 Kings 14:1 In the second year of Joash son of Jehoahaz king of Israel reigned Amaziah the son of Joash king of Judah.

2 Kings 14:2 He was twenty and five years old when he began to reign, and reigned twenty and nine years in Jerusalem. And his mother’s name was Jehoaddan of Jerusalem.

2 Kings 14:3 And he did that which was right in the sight of the Lord, yet not like David his father: he did according to all things as Joash his father did.

2 Kings 14:4 Howbeit the high places were not taken away: as yet the people did sacrifice and burnt incense on the high places.

2 Kings 14:5 And it came to pass, as soon as the kingdom was confirmed in his hand, that he slew his servants which had slain the king his father.

2 Kings 14:6 But the children of the murderers he slew not: according unto that which is written in the book of the law of Moses, wherein the Lord commanded, saying, The fathers shall not be put to death for the children, nor the children be put to death for the fathers; but every man shall be put to death for his own sin.

2 Kings 14:7 He slew of Edom in the valley of salt ten thousand, and took Selah by war, and called the name of it Joktheel unto this day.

2 Kings 14:8 Then Amaziah sent messengers to Jehoash, the son of Jehoahaz son of Jehu, king of Israel, saying, Come, let us look one another in the face.

2 Kings 14:9 And Jehoash the king of Israel sent to Amaziah king of Judah, saying, The thistle that was in Lebanon sent to the cedar that was in Lebanon, saying, Give thy daughter to my son to wife: and there passed by a wild beast that was in Lebanon, and trode down the thistle.

2 Kings 14:10 Thou hast indeed smitten Edom, and thine heart hath lifted thee up: glory of this, and tarry at home: for why shouldest thou meddle to thy hurt, that thou shouldest fall, even thou, and Judah with thee?

2 Kings 14:11 But Amaziah would not hear. Therefore Jehoash king of Israel went up; and he and Amaziah king of Judah looked one another in the face at Beth-shemesh, which belongeth to Judah.

2 Kings 14:12 And Judah was put to the worse before Israel; and they fled every man to their tents.

2 Kings 14:13 And Jehoash king of Israel took Amaziah king of Judah, the son of Jehoash the son of Ahaziah, at Beth-shemesh, and came to Jerusalem, and brake down the wall of Jerusalem from the gate of Ephraim unto the corner gate, four hundred cubits.

2 Kings 14:14 And he took all the gold and silver, and all the vessels that were found in the house of the Lord, and in the treasures of the king’s house, and hostages, and returned to Samaria.

2 Kings 14:15 Now the rest of the acts of Jehoash which he did, and his might, and how he fought with Amaziah king of Judah, are they not written in the book of the chronicles of the kings of Israel?

2 Kings 14:16 And Jehoash slept with his fathers, and was buried in Samaria with the kings of Israel; and Jeroboam his son reigned in his stead.

2 Kings 14:17 And Amaziah the son of Joash king of Judah lived after the death of Jehoash son of Jehoahaz king of Israel fifteen years.

2 Kings 14:18 And the rest of the acts of Amaziah, are they not written in the book of the chronicles of the kings of Judah?

2 Kings 14:19 Now they made a conspiracy against him in Jerusalem: and he fled to Lachish; but they sent after him to Lachish, and slew him there.

2 Kings 14:20 And they brought him on horses: and he was buried at Jerusalem with his fathers in the city of David.

2 Kings 14:21 And all the people of Judah took Azariah, which was sixteen years old, and made him king instead of his father Amaziah.

2 Kings 14:22 He built Elath, and restored it to Judah, after that the king slept with his fathers.

2 Kings 14:23 In the fifteenth year of Amaziah the son of Joash king of Judah Jeroboam the son of Joash king of Israel began to reign in Samaria, and reigned forty and one years.

2 Kings 14:24 And he did that which was evil in the sight of the Lord: he departed not from all the sins of Jeroboam the son of Nebat, who made Israel to sin.

2 Kings 14:25 He restored the coast of Israel from the entering of Hamath unto the sea of the plain, according to the word of the Lord God of Israel, which he spake by the hand of his servant Jonah, the son of Amittai, the prophet, which was of Gath-hepher.

2 Kings 14:26 For the Lord saw the affliction of Israel, that it was very bitter: for there was not any shut up, nor any left, nor any helper for Israel.

2 Kings 14:27 And the Lord said not that he would blot out the name of Israel from under heaven: but he saved them by the hand of Jeroboam the son of Joash.

2 Kings 14:28 Now the rest of the acts of Jeroboam, and all that he did, and his might, how he warred, and how he recovered Damascus, and Hamath, which belonged to Judah, for Israel, are they not written in the book of the chronicles of the kings of Israel?

2 Kings 14:29 And Jeroboam slept with his fathers, even with the kings of Israel; and Zachariah his son reigned in his stead.
