# Isaiah 15

Isaiah 15 (summary): Moab will be laid waste, and her people will howl and weep.

Isaiah 15:1 The burden of Moab. Because in the night Ar of Moab is laid waste, and brought to silence; because in the night Kir of Moab is laid waste, and brought to silence;

Isaiah 15:2 He is gone up to Bajith, and to Dibon, the high places, to weep: Moab shall howl over Nebo, and over Medeba: on all their heads shall be baldness, and every beard cut off.

Isaiah 15:3 In their streets they shall gird themselves with sackcloth: on the tops of their houses, and in their streets, every one shall howl, weeping abundantly.

Isaiah 15:4 And Heshbon shall cry, and Elealeh: their voice shall be heard even unto Jahaz: therefore the armed soldiers of Moab shall cry out; his life shall be grievous unto him.

Isaiah 15:5 My heart shall cry out for Moab; his fugitives shall flee unto Zoar, an heifer of three years old: for by the mounting up of Luhith with weeping shall they go it up; for in the way of Horonaim they shall raise up a cry of destruction.

Isaiah 15:6 For the waters of Nimrim shall be desolate: for the hay is withered away, the grass faileth, there is no green thing.

Isaiah 15:7 Therefore the abundance they have gotten, and that which they have laid up, shall they carry away to the brook of the willows.

Isaiah 15:8 For the cry is gone round about the borders of Moab; the howling thereof unto Eglaim, and the howling thereof unto Beer-elim.

Isaiah 15:9 For the waters of Dimon shall be full of blood: for I will bring more upon Dimon, lions upon him that escapeth of Moab, and upon the remnant of the land.
