# 1 Samuel 5

1 Samuel 5 (summary): The Philistines place the ark in the house of Dagon, their god—The Philistines in Ashdod, then Gath, and then Ekron are plagued and slain because the ark is lodged with them.

1 Samuel 5:1 And the Philistines took the ark of God, and brought it from Eben-ezer unto Ashdod.

1 Samuel 5:2 When the Philistines took the ark of God, they brought it into the house of Dagon, and set it by Dagon.

1 Samuel 5:3 And when they of Ashdod arose early on the morrow, behold, Dagon was fallen upon his face to the earth before the ark of the Lord. And they took Dagon, and set him in his place again.

1 Samuel 5:4 And when they arose early on the morrow morning, behold, Dagon was fallen upon his face to the ground before the ark of the Lord; and the head of Dagon and both the palms of his hands were cut off upon the threshold; only the stump of Dagon was left to him.

1 Samuel 5:5 Therefore neither the priests of Dagon, nor any that come into Dagon’s house, tread on the threshold of Dagon in Ashdod unto this day.

1 Samuel 5:6 But the hand of the Lord was heavy upon them of Ashdod, and he destroyed them, and smote them with emerods, even Ashdod and the coasts thereof.

1 Samuel 5:7 And when the men of Ashdod saw that it was so, they said, The ark of the God of Israel shall not abide with us: for his hand is sore upon us, and upon Dagon our god.

1 Samuel 5:8 They sent therefore and gathered all the lords of the Philistines unto them, and said, What shall we do with the ark of the God of Israel? And they answered, Let the ark of the God of Israel be carried about unto Gath. And they carried the ark of the God of Israel about thither.

1 Samuel 5:9 And it was so, that, after they had carried it about, the hand of the Lord was against the city with a very great destruction: and he smote the men of the city, both small and great, and they had emerods in their secret parts.

1 Samuel 5:10 Therefore they sent the ark of God to Ekron. And it came to pass, as the ark of God came to Ekron, that the Ekronites cried out, saying, They have brought about the ark of the God of Israel to us, to slay us and our people.

1 Samuel 5:11 So they sent and gathered together all the lords of the Philistines, and said, Send away the ark of the God of Israel, and let it go again to his own place, that it slay us not, and our people: for there was a deadly destruction throughout all the city; the hand of God was very heavy there.

1 Samuel 5:12 And the men that died not were smitten with the emerods: and the cry of the city went up to heaven.
