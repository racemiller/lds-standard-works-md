# 1 Kings 20

1 Kings 20 (summary): Benhadad of Syria makes war with Israel—The Syrians are defeated twice—Ahab lets Benhadad go free, contrary to the will of the Lord.

1 Kings 20:1 And Ben-hadad the king of Syria gathered all his host together: and there were thirty and two kings with him, and horses, and chariots: and he went up and besieged Samaria, and warred against it.

1 Kings 20:2 And he sent messengers to Ahab king of Israel into the city, and said unto him, Thus saith Ben-hadad,

1 Kings 20:3 Thy silver and thy gold is mine; thy wives also and thy children, even the goodliest, are mine.

1 Kings 20:4 And the king of Israel answered and said, My lord, O king, according to thy saying, I am thine, and all that I have.

1 Kings 20:5 And the messengers came again, and said, Thus speaketh Ben-hadad, saying, Although I have sent unto thee, saying, Thou shalt deliver me thy silver, and thy gold, and thy wives, and thy children;

1 Kings 20:6 Yet I will send my servants unto thee to morrow about this time, and they shall search thine house, and the houses of thy servants; and it shall be, that whatsoever is pleasant in thine eyes, they shall put it in their hand, and take it away.

1 Kings 20:7 Then the king of Israel called all the elders of the land, and said, Mark, I pray you, and see how this man seeketh mischief: for he sent unto me for my wives, and for my children, and for my silver, and for my gold; and I denied him not.

1 Kings 20:8 And all the elders and all the people said unto him, Hearken not unto him, nor consent.

1 Kings 20:9 Wherefore he said unto the messengers of Ben-hadad, Tell my lord the king, All that thou didst send for to thy servant at the first I will do: but this thing I may not do. And the messengers departed, and brought him word again.

1 Kings 20:10 And Ben-hadad sent unto him, and said, The gods do so unto me, and more also, if the dust of Samaria shall suffice for handfuls for all the people that follow me.

1 Kings 20:11 And the king of Israel answered and said, Tell him, Let not him that girdeth on his harness boast himself as he that putteth it off.

1 Kings 20:12 And it came to pass, when Ben-hadad heard this message, as he was drinking, he and the kings in the pavilions, that he said unto his servants, Set yourselves in array. And they set themselves in array against the city.

1 Kings 20:13 And, behold, there came a prophet unto Ahab king of Israel, saying, Thus saith the Lord, Hast thou seen all this great multitude? behold, I will deliver it into thine hand this day; and thou shalt know that I am the Lord.

1 Kings 20:14 And Ahab said, By whom? And he said, Thus saith the Lord, Even by the young men of the princes of the provinces. Then he said, Who shall order the battle? And he answered, Thou.

1 Kings 20:15 Then he numbered the young men of the princes of the provinces, and they were two hundred and thirty two: and after them he numbered all the people, even all the children of Israel, being seven thousand.

1 Kings 20:16 And they went out at noon. But Ben-hadad was drinking himself drunk in the pavilions, he and the kings, the thirty and two kings that helped him.

1 Kings 20:17 And the young men of the princes of the provinces went out first; and Ben-hadad sent out, and they told him, saying, There are men come out of Samaria.

1 Kings 20:18 And he said, Whether they be come out for peace, take them alive; or whether they be come out for war, take them alive.

1 Kings 20:19 So these young men of the princes of the provinces came out of the city, and the army which followed them.

1 Kings 20:20 And they slew every one his man: and the Syrians fled; and Israel pursued them: and Ben-hadad the king of Syria escaped on an horse with the horsemen.

1 Kings 20:21 And the king of Israel went out, and smote the horses and chariots, and slew the Syrians with a great slaughter.

1 Kings 20:22 And the prophet came to the king of Israel, and said unto him, Go, strengthen thyself, and mark, and see what thou doest: for at the return of the year the king of Syria will come up against thee.

1 Kings 20:23 And the servants of the king of Syria said unto him, Their gods are gods of the hills; therefore they were stronger than we; but let us fight against them in the plain, and surely we shall be stronger than they.

1 Kings 20:24 And do this thing, Take the kings away, every man out of his place, and put captains in their rooms:

1 Kings 20:25 And number thee an army, like the army that thou hast lost, horse for horse, and chariot for chariot: and we will fight against them in the plain, and surely we shall be stronger than they. And he hearkened unto their voice, and did so.

1 Kings 20:26 And it came to pass at the return of the year, that Ben-hadad numbered the Syrians, and went up to Aphek, to fight against Israel.

1 Kings 20:27 And the children of Israel were numbered, and were all present, and went against them: and the children of Israel pitched before them like two little flocks of kids; but the Syrians filled the country.

1 Kings 20:28 And there came a man of God, and spake unto the king of Israel, and said, Thus saith the Lord, Because the Syrians have said, The Lord is God of the hills, but he is not God of the valleys, therefore will I deliver all this great multitude into thine hand, and ye shall know that I am the Lord.

1 Kings 20:29 And they pitched one over against the other seven days. And so it was, that in the seventh day the battle was joined: and the children of Israel slew of the Syrians an hundred thousand footmen in one day.

1 Kings 20:30 But the rest fled to Aphek, into the city; and there a wall fell upon twenty and seven thousand of the men that were left. And Ben-hadad fled, and came into the city, into an inner chamber.

1 Kings 20:31 And his servants said unto him, Behold now, we have heard that the kings of the house of Israel are merciful kings: let us, I pray thee, put sackcloth on our loins, and ropes upon our heads, and go out to the king of Israel: peradventure he will save thy life.

1 Kings 20:32 So they girded sackcloth on their loins, and put ropes on their heads, and came to the king of Israel, and said, Thy servant Ben-hadad saith, I pray thee, let me live. And he said, Is he yet alive? he is my brother.

1 Kings 20:33 Now the men did diligently observe whether any thing would come from him, and did hastily catch it: and they said, Thy brother Ben-hadad. Then he said, Go ye, bring him. Then Ben-hadad came forth to him; and he caused him to come up into the chariot.

1 Kings 20:34 And Ben-hadad said unto him, The cities, which my father took from thy father, I will restore; and thou shalt make streets for thee in Damascus, as my father made in Samaria. Then said Ahab, I will send thee away with this covenant. So he made a covenant with him, and sent him away.

1 Kings 20:35 And a certain man of the sons of the prophets said unto his neighbour in the word of the Lord, Smite me, I pray thee. And the man refused to smite him.

1 Kings 20:36 Then said he unto him, Because thou hast not obeyed the voice of the Lord, behold, as soon as thou art departed from me, a lion shall slay thee. And as soon as he was departed from him, a lion found him, and slew him.

1 Kings 20:37 Then he found another man, and said, Smite me, I pray thee. And the man smote him, so that in smiting he wounded him.

1 Kings 20:38 So the prophet departed, and waited for the king by the way, and disguised himself with ashes upon his face.

1 Kings 20:39 And as the king passed by, he cried unto the king: and he said, Thy servant went out into the midst of the battle; and, behold, a man turned aside, and brought a man unto me, and said, Keep this man: if by any means he be missing, then shall thy life be for his life, or else thou shalt pay a talent of silver.

1 Kings 20:40 And as thy servant was busy here and there, he was gone. And the king of Israel said unto him, So shall thy judgment be; thyself hast decided it.

1 Kings 20:41 And he hasted, and took the ashes away from his face; and the king of Israel discerned him that he was of the prophets.

1 Kings 20:42 And he said unto him, Thus saith the Lord, Because thou hast let go out of thy hand a man whom I appointed to utter destruction, therefore thy life shall go for his life, and thy people for his people.

1 Kings 20:43 And the king of Israel went to his house heavy and displeased, and came to Samaria.
