# Psalms 56

Psalms 56 (summary): David seeks mercy, trusts in and praises the Lord, and thanks Him for deliverance.

Psalms 56:1 Be merciful unto me, O God: for man would swallow me up; he fighting daily oppresseth me.

Psalms 56:2 Mine enemies would daily swallow me up: for they be many that fight against me, O thou most High.

Psalms 56:3 What time I am afraid, I will trust in thee.

Psalms 56:4 In God I will praise his word, in God I have put my trust; I will not fear what flesh can do unto me.

Psalms 56:5 Every day they wrest my words: all their thoughts are against me for evil.

Psalms 56:6 They gather themselves together, they hide themselves, they mark my steps, when they wait for my soul.

Psalms 56:7 Shall they escape by iniquity? in thine anger cast down the people, O God.

Psalms 56:8 Thou tellest my wanderings: put thou my tears into thy bottle: are they not in thy book?

Psalms 56:9 When I cry unto thee, then shall mine enemies turn back: this I know; for God is for me.

Psalms 56:10 In God will I praise his word: in the Lord will I praise his word.

Psalms 56:11 In God have I put my trust: I will not be afraid what man can do unto me.

Psalms 56:12 Thy vows are upon me, O God: I will render praises unto thee.

Psalms 56:13 For thou hast delivered my soul from death: wilt not thou deliver my feet from falling, that I may walk before God in the light of the living?
