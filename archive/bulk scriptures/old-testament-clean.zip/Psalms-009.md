# Psalms 9

Psalms 9 (summary): A messianic psalm of David—He praises the Lord for rebuking the nations—The Lord will judge the world in righteousness—He will dwell in Zion—The wicked will be sent to hell.

Psalms 9:1 I will praise thee, O Lord, with my whole heart; I will shew forth all thy marvellous works.

Psalms 9:2 I will be glad and rejoice in thee: I will sing praise to thy name, O thou most High.

Psalms 9:3 When mine enemies are turned back, they shall fall and perish at thy presence.

Psalms 9:4 For thou hast maintained my right and my cause; thou satest in the throne judging right.

Psalms 9:5 Thou hast rebuked the heathen, thou hast destroyed the wicked, thou hast put out their name for ever and ever.

Psalms 9:6 O thou enemy, destructions are come to a perpetual end: and thou hast destroyed cities; their memorial is perished with them.

Psalms 9:7 But the Lord shall endure for ever: he hath prepared his throne for judgment.

Psalms 9:8 And he shall judge the world in righteousness, he shall minister judgment to the people in uprightness.

Psalms 9:9 The Lord also will be a refuge for the oppressed, a refuge in times of trouble.

Psalms 9:10 And they that know thy name will put their trust in thee: for thou, Lord, hast not forsaken them that seek thee.

Psalms 9:11 Sing praises to the Lord, which dwelleth in Zion: declare among the people his doings.

Psalms 9:12 When he maketh inquisition for blood, he remembereth them: he forgetteth not the cry of the humble.

Psalms 9:13 Have mercy upon me, O Lord; consider my trouble which I suffer of them that hate me, thou that liftest me up from the gates of death:

Psalms 9:14 That I may shew forth all thy praise in the gates of the daughter of Zion: I will rejoice in thy salvation.

Psalms 9:15 The heathen are sunk down in the pit that they made: in the net which they hid is their own foot taken.

Psalms 9:16 The Lord is known by the judgment which he executeth: the wicked is snared in the work of his own hands. Higgaion. Selah.

Psalms 9:17 The wicked shall be turned into hell, and all the nations that forget God.

Psalms 9:18 For the needy shall not alway be forgotten: the expectation of the poor shall not perish for ever.

Psalms 9:19 Arise, O Lord; let not man prevail: let the heathen be judged in thy sight.

Psalms 9:20 Put them in fear, O Lord: that the nations may know themselves to be but men. Selah.
