# Proverbs 15

Proverbs 15 (summary): A soft answer turns away wrath—A wise son makes a glad father—The thoughts of the wicked are an abomination to the Lord—Before honor comes humility.

Proverbs 15:1 A soft answer turneth away wrath: but grievous words stir up anger.

Proverbs 15:2 The tongue of the wise useth knowledge aright: but the mouth of fools poureth out foolishness.

Proverbs 15:3 The eyes of the Lord are in every place, beholding the evil and the good.

Proverbs 15:4 A wholesome tongue is a tree of life: but perverseness therein is a breach in the spirit.

Proverbs 15:5 A fool despiseth his father’s instruction: but he that regardeth reproof is prudent.

Proverbs 15:6 In the house of the righteous is much treasure: but in the revenues of the wicked is trouble.

Proverbs 15:7 The lips of the wise disperse knowledge: but the heart of the foolish doeth not so.

Proverbs 15:8 The sacrifice of the wicked is an abomination to the Lord: but the prayer of the upright is his delight.

Proverbs 15:9 The way of the wicked is an abomination unto the Lord: but he loveth him that followeth after righteousness.

Proverbs 15:10 Correction is grievous unto him that forsaketh the way: and he that hateth reproof shall die.

Proverbs 15:11 Hell and destruction are before the Lord: how much more then the hearts of the children of men?

Proverbs 15:12 A scorner loveth not one that reproveth him: neither will he go unto the wise.

Proverbs 15:13 A merry heart maketh a cheerful countenance: but by sorrow of the heart the spirit is broken.

Proverbs 15:14 The heart of him that hath understanding seeketh knowledge: but the mouth of fools feedeth on foolishness.

Proverbs 15:15 All the days of the afflicted are evil: but he that is of a merry heart hath a continual feast.

Proverbs 15:16 Better is little with the fear of the Lord than great treasure and trouble therewith.

Proverbs 15:17 Better is a dinner of herbs where love is, than a stalled ox and hatred therewith.

Proverbs 15:18 A wrathful man stirreth up strife: but he that is slow to anger appeaseth strife.

Proverbs 15:19 The way of the slothful man is as an hedge of thorns: but the way of the righteous is made plain.

Proverbs 15:20 A wise son maketh a glad father: but a foolish man despiseth his mother.

Proverbs 15:21 Folly is joy to him that is destitute of wisdom: but a man of understanding walketh uprightly.

Proverbs 15:22 Without counsel purposes are disappointed: but in the multitude of counsellors they are established.

Proverbs 15:23 A man hath joy by the answer of his mouth: and a word spoken in due season, how good is it!

Proverbs 15:24 The way of life is above to the wise, that he may depart from hell beneath.

Proverbs 15:25 The Lord will destroy the house of the proud: but he will establish the border of the widow.

Proverbs 15:26 The thoughts of the wicked are an abomination to the Lord: but the words of the pure are pleasant words.

Proverbs 15:27 He that is greedy of gain troubleth his own house; but he that hateth gifts shall live.

Proverbs 15:28 The heart of the righteous studieth to answer: but the mouth of the wicked poureth out evil things.

Proverbs 15:29 The Lord is far from the wicked: but he heareth the prayer of the righteous.

Proverbs 15:30 The light of the eyes rejoiceth the heart: and a good report maketh the bones fat.

Proverbs 15:31 The ear that heareth the reproof of life abideth among the wise.

Proverbs 15:32 He that refuseth instruction despiseth his own soul: but he that heareth reproof getteth understanding.

Proverbs 15:33 The fear of the Lord is the instruction of wisdom; and before honour is humility.
