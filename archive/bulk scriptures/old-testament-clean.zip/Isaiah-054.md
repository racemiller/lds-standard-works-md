# Isaiah 54

Isaiah 54 (summary): In the last days, Zion and her stakes will be established, and Israel will be gathered in mercy and tenderness—Israel will triumph—Compare 3 Nephi 22.

Isaiah 54:1 Sing, O barren, thou that didst not bear; break forth into singing, and cry aloud, thou that didst not travail with child: for more are the children of the desolate than the children of the married wife, saith the Lord.

Isaiah 54:2 Enlarge the place of thy tent, and let them stretch forth the curtains of thine habitations: spare not, lengthen thy cords, and strengthen thy stakes;

Isaiah 54:3 For thou shalt break forth on the right hand and on the left; and thy seed shall inherit the Gentiles, and make the desolate cities to be inhabited.

Isaiah 54:4 Fear not; for thou shalt not be ashamed: neither be thou confounded; for thou shalt not be put to shame: for thou shalt forget the shame of thy youth, and shalt not remember the reproach of thy widowhood any more.

Isaiah 54:5 For thy Maker is thine husband; the Lord of hosts is his name; and thy Redeemer the Holy One of Israel; The God of the whole earth shall he be called.

Isaiah 54:6 For the Lord hath called thee as a woman forsaken and grieved in spirit, and a wife of youth, when thou wast refused, saith thy God.

Isaiah 54:7 For a small moment have I forsaken thee; but with great mercies will I gather thee.

Isaiah 54:8 In a little wrath I hid my face from thee for a moment; but with everlasting kindness will I have mercy on thee, saith the Lord thy Redeemer.

Isaiah 54:9 For this is as the waters of Noah unto me: for as I have sworn that the waters of Noah should no more go over the earth; so have I sworn that I would not be wroth with thee, nor rebuke thee.

Isaiah 54:10 For the mountains shall depart, and the hills be removed; but my kindness shall not depart from thee, neither shall the covenant of my peace be removed, saith the Lord that hath mercy on thee.

Isaiah 54:11 O thou afflicted, tossed with tempest, and not comforted, behold, I will lay thy stones with fair colours, and lay thy foundations with sapphires.

Isaiah 54:12 And I will make thy windows of agates, and thy gates of carbuncles, and all thy borders of pleasant stones.

Isaiah 54:13 And all thy children shall be taught of the Lord; and great shall be the peace of thy children.

Isaiah 54:14 In righteousness shalt thou be established: thou shalt be far from oppression; for thou shalt not fear: and from terror; for it shall not come near thee.

Isaiah 54:15 Behold, they shall surely gather together, but not by me: whosoever shall gather together against thee shall fall for thy sake.

Isaiah 54:16 Behold, I have created the smith that bloweth the coals in the fire, and that bringeth forth an instrument for his work; and I have created the waster to destroy.

Isaiah 54:17 No weapon that is formed against thee shall prosper; and every tongue that shall rise against thee in judgment thou shalt condemn. This is the heritage of the servants of the Lord, and their righteousness is of me, saith the Lord.
