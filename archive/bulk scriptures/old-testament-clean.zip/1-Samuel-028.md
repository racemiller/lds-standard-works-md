# 1 Samuel 28

1 Samuel 28 (summary): Saul inquires of the witch of Endor for revelation—She foretells his death, the death of his sons, and the defeat of Israel by the Philistines.

1 Samuel 28:1 And it came to pass in those days, that the Philistines gathered their armies together for warfare, to fight with Israel. And Achish said unto David, Know thou assuredly, that thou shalt go out with me to battle, thou and thy men.

1 Samuel 28:2 And David said to Achish, Surely thou shalt know what thy servant can do. And Achish said to David, Therefore will I make thee keeper of mine head for ever.

1 Samuel 28:3 Now Samuel was dead, and all Israel had lamented him, and buried him in Ramah, even in his own city. And Saul had put away those that had familiar spirits, and the wizards, out of the land.

1 Samuel 28:4 And the Philistines gathered themselves together, and came and pitched in Shunem: and Saul gathered all Israel together, and they pitched in Gilboa.

1 Samuel 28:5 And when Saul saw the host of the Philistines, he was afraid, and his heart greatly trembled.

1 Samuel 28:6 And when Saul inquired of the Lord, the Lord answered him not, neither by dreams, nor by Urim, nor by prophets.

1 Samuel 28:7 Then said Saul unto his servants, Seek me a woman that hath a familiar spirit, that I may go to her, and inquire of her. And his servants said to him, Behold, there is a woman that hath a familiar spirit at En-dor.

1 Samuel 28:8 And Saul disguised himself, and put on other raiment, and he went, and two men with him, and they came to the woman by night: and he said, I pray thee, divine unto me by the familiar spirit, and bring me him up, whom I shall name unto thee.

1 Samuel 28:9 And the woman said unto him, Behold, thou knowest what Saul hath done, how he hath cut off those that have familiar spirits, and the wizards, out of the land: wherefore then layest thou a snare for my life, to cause me to die?

1 Samuel 28:10 And Saul sware to her by the Lord, saying, As the Lord liveth, there shall no punishment happen to thee for this thing.

1 Samuel 28:11 Then said the woman, Whom shall I bring up unto thee? And he said, Bring me up Samuel.

1 Samuel 28:12 And when the woman saw Samuel, she cried with a loud voice: and the woman spake to Saul, saying, Why hast thou deceived me? for thou art Saul.

1 Samuel 28:13 And the king said unto her, Be not afraid: for what sawest thou? And the woman said unto Saul, I saw gods ascending out of the earth.

1 Samuel 28:14 And he said unto her, What form is he of? And she said, An old man cometh up; and he is covered with a mantle. And Saul perceived that it was Samuel, and he stooped with his face to the ground, and bowed himself.

1 Samuel 28:15 And Samuel said to Saul, Why hast thou disquieted me, to bring me up? And Saul answered, I am sore distressed; for the Philistines make war against me, and God is departed from me, and answereth me no more, neither by prophets, nor by dreams: therefore I have called thee, that thou mayest make known unto me what I shall do.

1 Samuel 28:16 Then said Samuel, Wherefore then dost thou ask of me, seeing the Lord is departed from thee, and is become thine enemy?

1 Samuel 28:17 And the Lord hath done to him, as he spake by me: for the Lord hath rent the kingdom out of thine hand, and given it to thy neighbour, even to David:

1 Samuel 28:18 Because thou obeyedst not the voice of the Lord, nor executedst his fierce wrath upon Amalek, therefore hath the Lord done this thing unto thee this day.

1 Samuel 28:19 Moreover the Lord will also deliver Israel with thee into the hand of the Philistines: and to morrow shalt thou and thy sons be with me: the Lord also shall deliver the host of Israel into the hand of the Philistines.

1 Samuel 28:20 Then Saul fell straightway all along on the earth, and was sore afraid, because of the words of Samuel: and there was no strength in him; for he had eaten no bread all the day, nor all the night.

1 Samuel 28:21 And the woman came unto Saul, and saw that he was sore troubled, and said unto him, Behold, thine handmaid hath obeyed thy voice, and I have put my life in my hand, and have hearkened unto thy words which thou spakest unto me.

1 Samuel 28:22 Now therefore, I pray thee, hearken thou also unto the voice of thine handmaid, and let me set a morsel of bread before thee; and eat, that thou mayest have strength, when thou goest on thy way.

1 Samuel 28:23 But he refused, and said, I will not eat. But his servants, together with the woman, compelled him; and he hearkened unto their voice. So he arose from the earth, and sat upon the bed.

1 Samuel 28:24 And the woman had a fat calf in the house; and she hasted, and killed it, and took flour, and kneaded it, and did bake unleavened bread thereof:

1 Samuel 28:25 And she brought it before Saul, and before his servants; and they did eat. Then they rose up, and went away that night.
