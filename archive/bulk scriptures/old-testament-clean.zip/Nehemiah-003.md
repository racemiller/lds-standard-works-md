# Nehemiah 3

Nehemiah 3 (summary): The names and order of those who help to build the walls and gates of Jerusalem are listed.

Nehemiah 3:1 Then Eliashib the high priest rose up with his brethren the priests, and they builded the sheep gate; they sanctified it, and set up the doors of it; even unto the tower of Meah they sanctified it, unto the tower of Hananeel.

Nehemiah 3:2 And next unto him builded the men of Jericho. And next to them builded Zaccur the son of Imri.

Nehemiah 3:3 But the fish gate did the sons of Hassenaah build, who also laid the beams thereof, and set up the doors thereof, the locks thereof, and the bars thereof.

Nehemiah 3:4 And next unto them repaired Meremoth the son of Urijah, the son of Koz. And next unto them repaired Meshullam the son of Berechiah, the son of Meshezabeel. And next unto them repaired Zadok the son of Baana.

Nehemiah 3:5 And next unto them the Tekoites repaired; but their nobles put not their necks to the work of their Lord.

Nehemiah 3:6 Moreover the old gate repaired Jehoiada the son of Paseah, and Meshullam the son of Besodeiah; they laid the beams thereof, and set up the doors thereof, and the locks thereof, and the bars thereof.

Nehemiah 3:7 And next unto them repaired Melatiah the Gibeonite, and Jadon the Meronothite, the men of Gibeon, and of Mizpah, unto the throne of the governor on this side the river.

Nehemiah 3:8 Next unto him repaired Uzziel the son of Harhaiah, of the goldsmiths. Next unto him also repaired Hananiah the son of one of the apothecaries, and they fortified Jerusalem unto the broad wall.

Nehemiah 3:9 And next unto them repaired Rephaiah the son of Hur, the ruler of the half part of Jerusalem.

Nehemiah 3:10 And next unto them repaired Jedaiah the son of Harumaph, even over against his house. And next unto him repaired Hattush the son of Hashabniah.

Nehemiah 3:11 Malchijah the son of Harim, and Hashub the son of Pahath-moab, repaired the other piece, and the tower of the furnaces.

Nehemiah 3:12 And next unto him repaired Shallum the son of Halohesh, the ruler of the half part of Jerusalem, he and his daughters.

Nehemiah 3:13 The valley gate repaired Hanun, and the inhabitants of Zanoah; they built it, and set up the doors thereof, the locks thereof, and the bars thereof, and a thousand cubits on the wall unto the dung gate.

Nehemiah 3:14 But the dung gate repaired Malchiah the son of Rechab, the ruler of part of Beth-haccerem; he built it, and set up the doors thereof, the locks thereof, and the bars thereof.

Nehemiah 3:15 But the gate of the fountain repaired Shallun the son of Col-hozeh, the ruler of part of Mizpah; he built it, and covered it, and set up the doors thereof, the locks thereof, and the bars thereof, and the wall of the pool of Siloah by the king’s garden, and unto the stairs that go down from the city of David.

Nehemiah 3:16 After him repaired Nehemiah the son of Azbuk, the ruler of the half part of Beth-zur, unto the place over against the sepulchres of David, and to the pool that was made, and unto the house of the mighty.

Nehemiah 3:17 After him repaired the Levites, Rehum the son of Bani. Next unto him repaired Hashabiah, the ruler of the half part of Keilah, in his part.

Nehemiah 3:18 After him repaired their brethren, Bavai the son of Henadad, the ruler of the half part of Keilah.

Nehemiah 3:19 And next to him repaired Ezer the son of Jeshua, the ruler of Mizpah, another piece over against the going up to the armoury at the turning of the wall.

Nehemiah 3:20 After him Baruch the son of Zabbai earnestly repaired the other piece, from the turning of the wall unto the door of the house of Eliashib the high priest.

Nehemiah 3:21 After him repaired Meremoth the son of Urijah the son of Koz another piece, from the door of the house of Eliashib even to the end of the house of Eliashib.

Nehemiah 3:22 And after him repaired the priests, the men of the plain.

Nehemiah 3:23 After him repaired Benjamin and Hashub over against their house. After him repaired Azariah the son of Maaseiah the son of Ananiah by his house.

Nehemiah 3:24 After him repaired Binnui the son of Henadad another piece, from the house of Azariah unto the turning of the wall, even unto the corner.

Nehemiah 3:25 Palal the son of Uzai, over against the turning of the wall, and the tower which lieth out from the king’s high house, that was by the court of the prison. After him Pedaiah the son of Parosh.

Nehemiah 3:26 Moreover the Nethinims dwelt in Ophel, unto the place over against the water gate toward the east, and the tower that lieth out.

Nehemiah 3:27 After them the Tekoites repaired another piece, over against the great tower that lieth out, even unto the wall of Ophel.

Nehemiah 3:28 From above the horse gate repaired the priests, every one over against his house.

Nehemiah 3:29 After them repaired Zadok the son of Immer over against his house. After him repaired also Shemaiah the son of Shechaniah, the keeper of the east gate.

Nehemiah 3:30 After him repaired Hananiah the son of Shelemiah, and Hanun the sixth son of Zalaph, another piece. After him repaired Meshullam the son of Berechiah over against his chamber.

Nehemiah 3:31 After him repaired Malchiah the goldsmith’s son unto the place of the Nethinims, and of the merchants, over against the gate Miphkad, and to the going up of the corner.

Nehemiah 3:32 And between the going up of the corner unto the sheep gate repaired the goldsmiths and the merchants.
