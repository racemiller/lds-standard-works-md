# Psalms 66

Psalms 66 (summary): Praise and worship the Lord—He tests and tries men—Sacrifices are to be offered in His house.

Psalms 66:1 Make a joyful noise unto God, all ye lands:

Psalms 66:2 Sing forth the honour of his name: make his praise glorious.

Psalms 66:3 Say unto God, How terrible art thou in thy works! through the greatness of thy power shall thine enemies submit themselves unto thee.

Psalms 66:4 All the earth shall worship thee, and shall sing unto thee; they shall sing to thy name. Selah.

Psalms 66:5 Come and see the works of God: he is terrible in his doing toward the children of men.

Psalms 66:6 He turned the sea into dry land: they went through the flood on foot: there did we rejoice in him.

Psalms 66:7 He ruleth by his power for ever; his eyes behold the nations: let not the rebellious exalt themselves. Selah.

Psalms 66:8 O bless our God, ye people, and make the voice of his praise to be heard:

Psalms 66:9 Which holdeth our soul in life, and suffereth not our feet to be moved.

Psalms 66:10 For thou, O God, hast proved us: thou hast tried us, as silver is tried.

Psalms 66:11 Thou broughtest us into the net; thou laidst affliction upon our loins.

Psalms 66:12 Thou hast caused men to ride over our heads; we went through fire and through water: but thou broughtest us out into a wealthy place.

Psalms 66:13 I will go into thy house with burnt offerings: I will pay thee my vows,

Psalms 66:14 Which my lips have uttered, and my mouth hath spoken, when I was in trouble.

Psalms 66:15 I will offer unto thee burnt sacrifices of fatlings, with the incense of rams; I will offer bullocks with goats. Selah.

Psalms 66:16 Come and hear, all ye that fear God, and I will declare what he hath done for my soul.

Psalms 66:17 I cried unto him with my mouth, and he was extolled with my tongue.

Psalms 66:18 If I regard iniquity in my heart, the Lord will not hear me:

Psalms 66:19 But verily God hath heard me; he hath attended to the voice of my prayer.

Psalms 66:20 Blessed be God, which hath not turned away my prayer, nor his mercy from me.
