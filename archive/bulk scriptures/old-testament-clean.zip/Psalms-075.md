# Psalms 75

Psalms 75 (summary): The righteous praise and thank the God of Jacob—They will be exalted—God is the judge, and the wicked will be condemned.

Psalms 75:1 Unto thee, O God, do we give thanks, unto thee do we give thanks: for that thy name is near thy wondrous works declare.

Psalms 75:2 When I shall receive the congregation I will judge uprightly.

Psalms 75:3 The earth and all the inhabitants thereof are dissolved: I bear up the pillars of it. Selah.

Psalms 75:4 I said unto the fools, Deal not foolishly: and to the wicked, Lift not up the horn:

Psalms 75:5 Lift not up your horn on high: speak not with a stiff neck.

Psalms 75:6 For promotion cometh neither from the east, nor from the west, nor from the south.

Psalms 75:7 But God is the judge: he putteth down one, and setteth up another.

Psalms 75:8 For in the hand of the Lord there is a cup, and the wine is red; it is full of mixture; and he poureth out of the same: but the dregs thereof, all the wicked of the earth shall wring them out, and drink them.

Psalms 75:9 But I will declare for ever; I will sing praises to the God of Jacob.

Psalms 75:10 All the horns of the wicked also will I cut off; but the horns of the righteous shall be exalted.
