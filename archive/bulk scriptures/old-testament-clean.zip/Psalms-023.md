# Psalms 23

Psalms 23 (summary): David declares, The Lord is my shepherd.

Psalms 23:1 The Lord is my shepherd; I shall not want.

Psalms 23:2 He maketh me to lie down in green pastures: he leadeth me beside the still waters.

Psalms 23:3 He restoreth my soul: he leadeth me in the paths of righteousness for his name’s sake.

Psalms 23:4 Yea, though I walk through the valley of the shadow of death, I will fear no evil: for thou art with me; thy rod and thy staff they comfort me.

Psalms 23:5 Thou preparest a table before me in the presence of mine enemies: thou anointest my head with oil; my cup runneth over.

Psalms 23:6 Surely goodness and mercy shall follow me all the days of my life: and I will dwell in the house of the Lord for ever.
