# Psalms 107

Psalms 107 (summary): The people of Israel are to praise and thank the Lord when they are gathered and redeemed—Oh, that men would praise the Lord!—The Lord’s providences prevail in the lives of men.

Psalms 107:1 O give thanks unto the Lord, for he is good: for his mercy endureth for ever.

Psalms 107:2 Let the redeemed of the Lord say so, whom he hath redeemed from the hand of the enemy;

Psalms 107:3 And gathered them out of the lands, from the east, and from the west, from the north, and from the south.

Psalms 107:4 They wandered in the wilderness in a solitary way; they found no city to dwell in.

Psalms 107:5 Hungry and thirsty, their soul fainted in them.

Psalms 107:6 Then they cried unto the Lord in their trouble, and he delivered them out of their distresses.

Psalms 107:7 And he led them forth by the right way, that they might go to a city of habitation.

Psalms 107:8 Oh that men would praise the Lord for his goodness, and for his wonderful works to the children of men!

Psalms 107:9 For he satisfieth the longing soul, and filleth the hungry soul with goodness.

Psalms 107:10 Such as sit in darkness and in the shadow of death, being bound in affliction and iron;

Psalms 107:11 Because they rebelled against the words of God, and contemned the counsel of the most High:

Psalms 107:12 Therefore he brought down their heart with labour; they fell down, and there was none to help.

Psalms 107:13 Then they cried unto the Lord in their trouble, and he saved them out of their distresses.

Psalms 107:14 He brought them out of darkness and the shadow of death, and brake their bands in sunder.

Psalms 107:15 Oh that men would praise the Lord for his goodness, and for his wonderful works to the children of men!

Psalms 107:16 For he hath broken the gates of brass, and cut the bars of iron in sunder.

Psalms 107:17 Fools because of their transgression, and because of their iniquities, are afflicted.

Psalms 107:18 Their soul abhorreth all manner of meat; and they draw near unto the gates of death.

Psalms 107:19 Then they cry unto the Lord in their trouble, and he saveth them out of their distresses.

Psalms 107:20 He sent his word, and healed them, and delivered them from their destructions.

Psalms 107:21 Oh that men would praise the Lord for his goodness, and for his wonderful works to the children of men!

Psalms 107:22 And let them sacrifice the sacrifices of thanksgiving, and declare his works with rejoicing.

Psalms 107:23 They that go down to the sea in ships, that do business in great waters;

Psalms 107:24 These see the works of the Lord, and his wonders in the deep.

Psalms 107:25 For he commandeth, and raiseth the stormy wind, which lifteth up the waves thereof.

Psalms 107:26 They mount up to the heaven, they go down again to the depths: their soul is melted because of trouble.

Psalms 107:27 They reel to and fro, and stagger like a drunken man, and are at their wits’ end.

Psalms 107:28 Then they cry unto the Lord in their trouble, and he bringeth them out of their distresses.

Psalms 107:29 He maketh the storm a calm, so that the waves thereof are still.

Psalms 107:30 Then are they glad because they be quiet; so he bringeth them unto their desired haven.

Psalms 107:31 Oh that men would praise the Lord for his goodness, and for his wonderful works to the children of men!

Psalms 107:32 Let them exalt him also in the congregation of the people, and praise him in the assembly of the elders.

Psalms 107:33 He turneth rivers into a wilderness, and the watersprings into dry ground;

Psalms 107:34 A fruitful land into barrenness, for the wickedness of them that dwell therein.

Psalms 107:35 He turneth the wilderness into a standing water, and dry ground into watersprings.

Psalms 107:36 And there he maketh the hungry to dwell, that they may prepare a city for habitation;

Psalms 107:37 And sow the fields, and plant vineyards, which may yield fruits of increase.

Psalms 107:38 He blesseth them also, so that they are multiplied greatly; and suffereth not their cattle to decrease.

Psalms 107:39 Again, they are minished and brought low through oppression, affliction, and sorrow.

Psalms 107:40 He poureth contempt upon princes, and causeth them to wander in the wilderness, where there is no way.

Psalms 107:41 Yet setteth he the poor on high from affliction, and maketh him families like a flock.

Psalms 107:42 The righteous shall see it, and rejoice: and all iniquity shall stop her mouth.

Psalms 107:43 Whoso is wise, and will observe these things, even they shall understand the lovingkindness of the Lord.
