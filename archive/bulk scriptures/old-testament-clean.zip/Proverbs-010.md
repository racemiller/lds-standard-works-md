# Proverbs 10

Proverbs 10 (summary): A wise son makes a glad father—The mouth of a righteous man is a well of life—He who utters slander is a fool—The desire of the righteous will be granted.

Proverbs 10:1 The proverbs of Solomon. A wise son maketh a glad father: but a foolish son is the heaviness of his mother.

Proverbs 10:2 Treasures of wickedness profit nothing: but righteousness delivereth from death.

Proverbs 10:3 The Lord will not suffer the soul of the righteous to famish: but he casteth away the substance of the wicked.

Proverbs 10:4 He becometh poor that dealeth with a slack hand: but the hand of the diligent maketh rich.

Proverbs 10:5 He that gathereth in summer is a wise son: but he that sleepeth in harvest is a son that causeth shame.

Proverbs 10:6 Blessings are upon the head of the just: but violence covereth the mouth of the wicked.

Proverbs 10:7 The memory of the just is blessed: but the name of the wicked shall rot.

Proverbs 10:8 The wise in heart will receive commandments: but a prating fool shall fall.

Proverbs 10:9 He that walketh uprightly walketh surely: but he that perverteth his ways shall be known.

Proverbs 10:10 He that winketh with the eye causeth sorrow: but a prating fool shall fall.

Proverbs 10:11 The mouth of a righteous man is a well of life: but violence covereth the mouth of the wicked.

Proverbs 10:12 Hatred stirreth up strifes: but love covereth all sins.

Proverbs 10:13 In the lips of him that hath understanding wisdom is found: but a rod is for the back of him that is void of understanding.

Proverbs 10:14 Wise men lay up knowledge: but the mouth of the foolish is near destruction.

Proverbs 10:15 The rich man’s wealth is his strong city: the destruction of the poor is their poverty.

Proverbs 10:16 The labour of the righteous tendeth to life: the fruit of the wicked to sin.

Proverbs 10:17 He is in the way of life that keepeth instruction: but he that refuseth reproof erreth.

Proverbs 10:18 He that hideth hatred with lying lips, and he that uttereth a slander, is a fool.

Proverbs 10:19 In the multitude of words there wanteth not sin: but he that refraineth his lips is wise.

Proverbs 10:20 The tongue of the just is as choice silver: the heart of the wicked is little worth.

Proverbs 10:21 The lips of the righteous feed many: but fools die for want of wisdom.

Proverbs 10:22 The blessing of the Lord, it maketh rich, and he addeth no sorrow with it.

Proverbs 10:23 It is as sport to a fool to do mischief: but a man of understanding hath wisdom.

Proverbs 10:24 The fear of the wicked, it shall come upon him: but the desire of the righteous shall be granted.

Proverbs 10:25 As the whirlwind passeth, so is the wicked no more: but the righteous is an everlasting foundation.

Proverbs 10:26 As vinegar to the teeth, and as smoke to the eyes, so is the sluggard to them that send him.

Proverbs 10:27 The fear of the Lord prolongeth days: but the years of the wicked shall be shortened.

Proverbs 10:28 The hope of the righteous shall be gladness: but the expectation of the wicked shall perish.

Proverbs 10:29 The way of the Lord is strength to the upright: but destruction shall be to the workers of iniquity.

Proverbs 10:30 The righteous shall never be removed: but the wicked shall not inhabit the earth.

Proverbs 10:31 The mouth of the just bringeth forth wisdom: but the froward tongue shall be cut out.

Proverbs 10:32 The lips of the righteous know what is acceptable: but the mouth of the wicked speaketh frowardness.
