# Hosea 5

Hosea 5 (summary): The kingdoms of Judah and Israel will both fall because of their iniquities.

Hosea 5:1 Hear ye this, O priests; and hearken, ye house of Israel; and give ye ear, O house of the king; for judgment is toward you, because ye have been a snare on Mizpah, and a net spread upon Tabor.

Hosea 5:2 And the revolters are profound to make slaughter, though I have been a rebuker of them all.

Hosea 5:3 I know Ephraim, and Israel is not hid from me: for now, O Ephraim, thou committest whoredom, and Israel is defiled.

Hosea 5:4 They will not frame their doings to turn unto their God: for the spirit of whoredoms is in the midst of them, and they have not known the Lord.

Hosea 5:5 And the pride of Israel doth testify to his face: therefore shall Israel and Ephraim fall in their iniquity; Judah also shall fall with them.

Hosea 5:6 They shall go with their flocks and with their herds to seek the Lord; but they shall not find him; he hath withdrawn himself from them.

Hosea 5:7 They have dealt treacherously against the Lord: for they have begotten strange children: now shall a month devour them with their portions.

Hosea 5:8 Blow ye the cornet in Gibeah, and the trumpet in Ramah: cry aloud at Beth-aven, after thee, O Benjamin.

Hosea 5:9 Ephraim shall be desolate in the day of rebuke: among the tribes of Israel have I made known that which shall surely be.

Hosea 5:10 The princes of Judah were like them that remove the bound: therefore I will pour out my wrath upon them like water.

Hosea 5:11 Ephraim is oppressed and broken in judgment, because he willingly walked after the commandment.

Hosea 5:12 Therefore will I be unto Ephraim as a moth, and to the house of Judah as rottenness.

Hosea 5:13 When Ephraim saw his sickness, and Judah saw his wound, then went Ephraim to the Assyrian, and sent to king Jareb: yet could he not heal you, nor cure you of your wound.

Hosea 5:14 For I will be unto Ephraim as a lion, and as a young lion to the house of Judah: I, even I, will tear and go away; I will take away, and none shall rescue him.

Hosea 5:15 I will go and return to my place, till they acknowledge their offence, and seek my face: in their affliction they will seek me early.
