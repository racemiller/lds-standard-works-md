# Ezekiel 34

Ezekiel 34 (summary): The Lord reproves those shepherds who do not feed the flock—In the last days, the Lord will gather the lost sheep of Israel—The Messiah will be their Shepherd—The Lord will make His gospel covenant with them.

Ezekiel 34:1 And the word of the Lord came unto me, saying,

Ezekiel 34:2 Son of man, prophesy against the shepherds of Israel, prophesy, and say unto them, Thus saith the Lord God unto the shepherds; Woe be to the shepherds of Israel that do feed themselves! should not the shepherds feed the flocks?

Ezekiel 34:3 Ye eat the fat, and ye clothe you with the wool, ye kill them that are fed: but ye feed not the flock.

Ezekiel 34:4 The diseased have ye not strengthened, neither have ye healed that which was sick, neither have ye bound up that which was broken, neither have ye brought again that which was driven away, neither have ye sought that which was lost; but with force and with cruelty have ye ruled them.

Ezekiel 34:5 And they were scattered, because there is no shepherd: and they became meat to all the beasts of the field, when they were scattered.

Ezekiel 34:6 My sheep wandered through all the mountains, and upon every high hill: yea, my flock was scattered upon all the face of the earth, and none did search or seek after them.

Ezekiel 34:7 Therefore, ye shepherds, hear the word of the Lord;

Ezekiel 34:8 As I live, saith the Lord God, surely because my flock became a prey, and my flock became meat to every beast of the field, because there was no shepherd, neither did my shepherds search for my flock, but the shepherds fed themselves, and fed not my flock;

Ezekiel 34:9 Therefore, O ye shepherds, hear the word of the Lord;

Ezekiel 34:10 Thus saith the Lord God; Behold, I am against the shepherds; and I will require my flock at their hand, and cause them to cease from feeding the flock; neither shall the shepherds feed themselves any more; for I will deliver my flock from their mouth, that they may not be meat for them.

Ezekiel 34:11 For thus saith the Lord God; Behold, I, even I, will both search my sheep, and seek them out.

Ezekiel 34:12 As a shepherd seeketh out his flock in the day that he is among his sheep that are scattered; so will I seek out my sheep, and will deliver them out of all places where they have been scattered in the cloudy and dark day.

Ezekiel 34:13 And I will bring them out from the people, and gather them from the countries, and will bring them to their own land, and feed them upon the mountains of Israel by the rivers, and in all the inhabited places of the country.

Ezekiel 34:14 I will feed them in a good pasture, and upon the high mountains of Israel shall their fold be: there shall they lie in a good fold, and in a fat pasture shall they feed upon the mountains of Israel.

Ezekiel 34:15 I will feed my flock, and I will cause them to lie down, saith the Lord God.

Ezekiel 34:16 I will seek that which was lost, and bring again that which was driven away, and will bind up that which was broken, and will strengthen that which was sick: but I will destroy the fat and the strong; I will feed them with judgment.

Ezekiel 34:17 And as for you, O my flock, thus saith the Lord God; Behold, I judge between cattle and cattle, between the rams and the he goats.

Ezekiel 34:18 Seemeth it a small thing unto you to have eaten up the good pasture, but ye must tread down with your feet the residue of your pastures? and to have drunk of the deep waters, but ye must foul the residue with your feet?

Ezekiel 34:19 And as for my flock, they eat that which ye have trodden with your feet; and they drink that which ye have fouled with your feet.

Ezekiel 34:20 Therefore thus saith the Lord God unto them; Behold, I, even I, will judge between the fat cattle and between the lean cattle.

Ezekiel 34:21 Because ye have thrust with side and with shoulder, and pushed all the diseased with your horns, till ye have scattered them abroad;

Ezekiel 34:22 Therefore will I save my flock, and they shall no more be a prey; and I will judge between cattle and cattle.

Ezekiel 34:23 And I will set up one shepherd over them, and he shall feed them, even my servant David; he shall feed them, and he shall be their shepherd.

Ezekiel 34:24 And I the Lord will be their God, and my servant David a prince among them; I the Lord have spoken it.

Ezekiel 34:25 And I will make with them a covenant of peace, and will cause the evil beasts to cease out of the land: and they shall dwell safely in the wilderness, and sleep in the woods.

Ezekiel 34:26 And I will make them and the places round about my hill a blessing; and I will cause the shower to come down in his season; there shall be showers of blessing.

Ezekiel 34:27 And the tree of the field shall yield her fruit, and the earth shall yield her increase, and they shall be safe in their land, and shall know that I am the Lord, when I have broken the bands of their yoke, and delivered them out of the hand of those that served themselves of them.

Ezekiel 34:28 And they shall no more be a prey to the heathen, neither shall the beast of the land devour them; but they shall dwell safely, and none shall make them afraid.

Ezekiel 34:29 And I will raise up for them a plant of renown, and they shall be no more consumed with hunger in the land, neither bear the shame of the heathen any more.

Ezekiel 34:30 Thus shall they know that I the Lord their God am with them, and that they, even the house of Israel, are my people, saith the Lord God.

Ezekiel 34:31 And ye my flock, the flock of my pasture, are men, and I am your God, saith the Lord God.
