# Isaiah 26

Isaiah 26 (summary): Trust in the Lord forever—Jehovah will die and be resurrected—All men will rise in the Resurrection.

Isaiah 26:1 In that day shall this song be sung in the land of Judah; We have a strong city; salvation will God appoint for walls and bulwarks.

Isaiah 26:2 Open ye the gates, that the righteous nation which keepeth the truth may enter in.

Isaiah 26:3 Thou wilt keep him in perfect peace, whose mind is stayed on thee: because he trusteth in thee.

Isaiah 26:4 Trust ye in the Lord for ever: for in the Lord Jehovah is everlasting strength:

Isaiah 26:5 For he bringeth down them that dwell on high; the lofty city, he layeth it low; he layeth it low, even to the ground; he bringeth it even to the dust.

Isaiah 26:6 The foot shall tread it down, even the feet of the poor, and the steps of the needy.

Isaiah 26:7 The way of the just is uprightness: thou, most upright, dost weigh the path of the just.

Isaiah 26:8 Yea, in the way of thy judgments, O Lord, have we waited for thee; the desire of our soul is to thy name, and to the remembrance of thee.

Isaiah 26:9 With my soul have I desired thee in the night; yea, with my spirit within me will I seek thee early: for when thy judgments are in the earth, the inhabitants of the world will learn righteousness.

Isaiah 26:10 Let favour be shewed to the wicked, yet will he not learn righteousness: in the land of uprightness will he deal unjustly, and will not behold the majesty of the Lord.

Isaiah 26:11 Lord, when thy hand is lifted up, they will not see: but they shall see, and be ashamed for their envy at the people; yea, the fire of thine enemies shall devour them.

Isaiah 26:12 Lord, thou wilt ordain peace for us: for thou also hast wrought all our works in us.

Isaiah 26:13 O Lord our God, other lords beside thee have had dominion over us: but by thee only will we make mention of thy name.

Isaiah 26:14 They are dead, they shall not live; they are deceased, they shall not rise: therefore hast thou visited and destroyed them, and made all their memory to perish.

Isaiah 26:15 Thou hast increased the nation, O Lord, thou hast increased the nation: thou art glorified: thou hadst removed it far unto all the ends of the earth.

Isaiah 26:16 Lord, in trouble have they visited thee, they poured out a prayer when thy chastening was upon them.

Isaiah 26:17 Like as a woman with child, that draweth near the time of her delivery, is in pain, and crieth out in her pangs; so have we been in thy sight, O Lord.

Isaiah 26:18 We have been with child, we have been in pain, we have as it were brought forth wind; we have not wrought any deliverance in the earth; neither have the inhabitants of the world fallen.

Isaiah 26:19 Thy dead men shall live, together with my dead body shall they arise. Awake and sing, ye that dwell in dust: for thy dew is as the dew of herbs, and the earth shall cast out the dead.

Isaiah 26:20 Come, my people, enter thou into thy chambers, and shut thy doors about thee: hide thyself as it were for a little moment, until the indignation be overpast.

Isaiah 26:21 For, behold, the Lord cometh out of his place to punish the inhabitants of the earth for their iniquity: the earth also shall disclose her blood, and shall no more cover her slain.
