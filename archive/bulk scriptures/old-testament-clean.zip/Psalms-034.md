# Psalms 34

Psalms 34 (summary): David blesses the Lord at all times—He counsels, Keep your tongue from evil; do good and seek peace—He says that not one of the Messiah’s bones will be broken.

Psalms 34:1 I will bless the Lord at all times: his praise shall continually be in my mouth.

Psalms 34:2 My soul shall make her boast in the Lord: the humble shall hear thereof, and be glad.

Psalms 34:3 O magnify the Lord with me, and let us exalt his name together.

Psalms 34:4 I sought the Lord, and he heard me, and delivered me from all my fears.

Psalms 34:5 They looked unto him, and were lightened: and their faces were not ashamed.

Psalms 34:6 This poor man cried, and the Lord heard him, and saved him out of all his troubles.

Psalms 34:7 The angel of the Lord encampeth round about them that fear him, and delivereth them.

Psalms 34:8 O taste and see that the Lord is good: blessed is the man that trusteth in him.

Psalms 34:9 O fear the Lord, ye his saints: for there is no want to them that fear him.

Psalms 34:10 The young lions do lack, and suffer hunger: but they that seek the Lord shall not want any good thing.

Psalms 34:11 Come, ye children, hearken unto me: I will teach you the fear of the Lord.

Psalms 34:12 What man is he that desireth life, and loveth many days, that he may see good?

Psalms 34:13 Keep thy tongue from evil, and thy lips from speaking guile.

Psalms 34:14 Depart from evil, and do good; seek peace, and pursue it.

Psalms 34:15 The eyes of the Lord are upon the righteous, and his ears are open unto their cry.

Psalms 34:16 The face of the Lord is against them that do evil, to cut off the remembrance of them from the earth.

Psalms 34:17 The righteous cry, and the Lord heareth, and delivereth them out of all their troubles.

Psalms 34:18 The Lord is nigh unto them that are of a broken heart; and saveth such as be of a contrite spirit.

Psalms 34:19 Many are the afflictions of the righteous: but the Lord delivereth him out of them all.

Psalms 34:20 He keepeth all his bones: not one of them is broken.

Psalms 34:21 Evil shall slay the wicked: and they that hate the righteous shall be desolate.

Psalms 34:22 The Lord redeemeth the soul of his servants: and none of them that trust in him shall be desolate.
