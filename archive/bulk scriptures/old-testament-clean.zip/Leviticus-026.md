# Leviticus 26

Leviticus 26 (summary): Temporal and spiritual blessings will abound in Israel if the people keep the commandments—Cursing, scourging, and desolation will be theirs if they disobey the Lord—When His people repent, the Lord will show mercy unto them.

Leviticus 26:1 Ye shall make you no idols nor graven image, neither rear you up a standing image, neither shall ye set up any image of stone in your land, to bow down unto it: for I am the Lord your God.

Leviticus 26:2 Ye shall keep my sabbaths, and reverence my sanctuary: I am the Lord.

Leviticus 26:3 If ye walk in my statutes, and keep my commandments, and do them;

Leviticus 26:4 Then I will give you rain in due season, and the land shall yield her increase, and the trees of the field shall yield their fruit.

Leviticus 26:5 And your threshing shall reach unto the vintage, and the vintage shall reach unto the sowing time: and ye shall eat your bread to the full, and dwell in your land safely.

Leviticus 26:6 And I will give peace in the land, and ye shall lie down, and none shall make you afraid: and I will rid evil beasts out of the land, neither shall the sword go through your land.

Leviticus 26:7 And ye shall chase your enemies, and they shall fall before you by the sword.

Leviticus 26:8 And five of you shall chase an hundred, and an hundred of you shall put ten thousand to flight: and your enemies shall fall before you by the sword.

Leviticus 26:9 For I will have respect unto you, and make you fruitful, and multiply you, and establish my covenant with you.

Leviticus 26:10 And ye shall eat old store, and bring forth the old because of the new.

Leviticus 26:11 And I will set my tabernacle among you: and my soul shall not abhor you.

Leviticus 26:12 And I will walk among you, and will be your God, and ye shall be my people.

Leviticus 26:13 I am the Lord your God, which brought you forth out of the land of Egypt, that ye should not be their bondmen; and I have broken the bands of your yoke, and made you go upright.

Leviticus 26:14 But if ye will not hearken unto me, and will not do all these commandments;

Leviticus 26:15 And if ye shall despise my statutes, or if your soul abhor my judgments, so that ye will not do all my commandments, but that ye break my covenant:

Leviticus 26:16 I also will do this unto you; I will even appoint over you terror, consumption, and the burning ague, that shall consume the eyes, and cause sorrow of heart: and ye shall sow your seed in vain, for your enemies shall eat it.

Leviticus 26:17 And I will set my face against you, and ye shall be slain before your enemies: they that hate you shall reign over you; and ye shall flee when none pursueth you.

Leviticus 26:18 And if ye will not yet for all this hearken unto me, then I will punish you seven times more for your sins.

Leviticus 26:19 And I will break the pride of your power; and I will make your heaven as iron, and your earth as brass:

Leviticus 26:20 And your strength shall be spent in vain: for your land shall not yield her increase, neither shall the trees of the land yield their fruits.

Leviticus 26:21 And if ye walk contrary unto me, and will not hearken unto me; I will bring seven times more plagues upon you according to your sins.

Leviticus 26:22 I will also send wild beasts among you, which shall rob you of your children, and destroy your cattle, and make you few in number; and your high ways shall be desolate.

Leviticus 26:23 And if ye will not be reformed by me by these things, but will walk contrary unto me;

Leviticus 26:24 Then will I also walk contrary unto you, and will punish you yet seven times for your sins.

Leviticus 26:25 And I will bring a sword upon you, that shall avenge the quarrel of my covenant: and when ye are gathered together within your cities, I will send the pestilence among you; and ye shall be delivered into the hand of the enemy.

Leviticus 26:26 And when I have broken the staff of your bread, ten women shall bake your bread in one oven, and they shall deliver you your bread again by weight: and ye shall eat, and not be satisfied.

Leviticus 26:27 And if ye will not for all this hearken unto me, but walk contrary unto me;

Leviticus 26:28 Then I will walk contrary unto you also in fury; and I, even I, will chastise you seven times for your sins.

Leviticus 26:29 And ye shall eat the flesh of your sons, and the flesh of your daughters shall ye eat.

Leviticus 26:30 And I will destroy your high places, and cut down your images, and cast your carcases upon the carcases of your idols, and my soul shall abhor you.

Leviticus 26:31 And I will make your cities waste, and bring your sanctuaries unto desolation, and I will not smell the savour of your sweet odours.

Leviticus 26:32 And I will bring the land into desolation: and your enemies which dwell therein shall be astonished at it.

Leviticus 26:33 And I will scatter you among the heathen, and will draw out a sword after you: and your land shall be desolate, and your cities waste.

Leviticus 26:34 Then shall the land enjoy her sabbaths, as long as it lieth desolate, and ye be in your enemies’ land; even then shall the land rest, and enjoy her sabbaths.

Leviticus 26:35 As long as it lieth desolate it shall rest; because it did not rest in your sabbaths, when ye dwelt upon it.

Leviticus 26:36 And upon them that are left alive of you I will send a faintness into their hearts in the lands of their enemies; and the sound of a shaken leaf shall chase them; and they shall flee, as fleeing from a sword; and they shall fall when none pursueth.

Leviticus 26:37 And they shall fall one upon another, as it were before a sword, when none pursueth: and ye shall have no power to stand before your enemies.

Leviticus 26:38 And ye shall perish among the heathen, and the land of your enemies shall eat you up.

Leviticus 26:39 And they that are left of you shall pine away in their iniquity in your enemies’ lands; and also in the iniquities of their fathers shall they pine away with them.

Leviticus 26:40 If they shall confess their iniquity, and the iniquity of their fathers, with their trespass which they trespassed against me, and that also they have walked contrary unto me;

Leviticus 26:41 And that I also have walked contrary unto them, and have brought them into the land of their enemies; if then their uncircumcised hearts be humbled, and they then accept of the punishment of their iniquity:

Leviticus 26:42 Then will I remember my covenant with Jacob, and also my covenant with Isaac, and also my covenant with Abraham will I remember; and I will remember the land.

Leviticus 26:43 The land also shall be left of them, and shall enjoy her sabbaths, while she lieth desolate without them: and they shall accept of the punishment of their iniquity: because, even because they despised my judgments, and because their soul abhorred my statutes.

Leviticus 26:44 And yet for all that, when they be in the land of their enemies, I will not cast them away, neither will I abhor them, to destroy them utterly, and to break my covenant with them: for I am the Lord their God.

Leviticus 26:45 But I will for their sakes remember the covenant of their ancestors, whom I brought forth out of the land of Egypt in the sight of the heathen, that I might be their God: I am the Lord.

Leviticus 26:46 These are the statutes and judgments and laws, which the Lord made between him and the children of Israel in mount Sinai by the hand of Moses.
