# 1 Chronicles 3

1 Chronicles 3 (summary): David’s sons are named—The successors of Solomon to Jeconiah and beyond are listed.

1 Chronicles 3:1 Now these were the sons of David, which were born unto him in Hebron; the firstborn Amnon, of Ahinoam the Jezreelitess; the second Daniel, of Abigail the Carmelitess:

1 Chronicles 3:2 The third, Absalom the son of Maachah the daughter of Talmai king of Geshur: the fourth, Adonijah the son of Haggith:

1 Chronicles 3:3 The fifth, Shephatiah of Abital: the sixth, Ithream by Eglah his wife.

1 Chronicles 3:4 These six were born unto him in Hebron; and there he reigned seven years and six months: and in Jerusalem he reigned thirty and three years.

1 Chronicles 3:5 And these were born unto him in Jerusalem; Shimea, and Shobab, and Nathan, and Solomon, four, of Bath-shua the daughter of Ammiel:

1 Chronicles 3:6 Ibhar also, and Elishama, and Eliphelet,

1 Chronicles 3:7 And Nogah, and Nepheg, and Japhia,

1 Chronicles 3:8 And Elishama, and Eliada, and Eliphelet, nine.

1 Chronicles 3:9 These were all the sons of David, beside the sons of the concubines, and Tamar their sister.

1 Chronicles 3:10 And Solomon’s son was Rehoboam, Abia his son, Asa his son, Jehoshaphat his son,

1 Chronicles 3:11 Joram his son, Ahaziah his son, Joash his son,

1 Chronicles 3:12 Amaziah his son, Azariah his son, Jotham his son,

1 Chronicles 3:13 Ahaz his son, Hezekiah his son, Manasseh his son,

1 Chronicles 3:14 Amon his son, Josiah his son.

1 Chronicles 3:15 And the sons of Josiah were, the firstborn Johanan, the second Jehoiakim, the third Zedekiah, the fourth Shallum.

1 Chronicles 3:16 And the sons of Jehoiakim: Jeconiah his son, Zedekiah his son.

1 Chronicles 3:17 And the sons of Jeconiah; Assir, Salathiel his son,

1 Chronicles 3:18 Malchiram also, and Pedaiah, and Shenazar, Jecamiah, Hoshama, and Nedabiah.

1 Chronicles 3:19 And the sons of Pedaiah were, Zerubbabel, and Shimei: and the sons of Zerubbabel; Meshullam, and Hananiah, and Shelomith their sister:

1 Chronicles 3:20 And Hashubah, and Ohel, and Berechiah, and Hasadiah, Jushab-hesed, five.

1 Chronicles 3:21 And the sons of Hananiah; Pelatiah, and Jesaiah: the sons of Rephaiah, the sons of Arnan, the sons of Obadiah, the sons of Shechaniah.

1 Chronicles 3:22 And the sons of Shechaniah; Shemaiah: and the sons of Shemaiah; Hattush, and Igeal, and Bariah, and Neariah, and Shaphat, six.

1 Chronicles 3:23 And the sons of Neariah; Elioenai, and Hezekiah, and Azrikam, three.

1 Chronicles 3:24 And the sons of Elioenai were, Hodaiah, and Eliashib, and Pelaiah, and Akkub, and Johanan, and Dalaiah, and Anani, seven.
