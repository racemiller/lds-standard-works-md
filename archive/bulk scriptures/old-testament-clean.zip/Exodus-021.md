# Exodus 21

Exodus 21 (summary): The Lord reveals His laws pertaining to servants, marriage, the death penalty for various offenses, the giving of an eye for an eye and a tooth for a tooth, and the damage done by oxen.

Exodus 21:1 Now these are the judgments which thou shalt set before them.

Exodus 21:2 If thou buy an Hebrew servant, six years he shall serve: and in the seventh he shall go out free for nothing.

Exodus 21:3 If he came in by himself, he shall go out by himself: if he were married, then his wife shall go out with him.

Exodus 21:4 If his master have given him a wife, and she have born him sons or daughters; the wife and her children shall be her master’s, and he shall go out by himself.

Exodus 21:5 And if the servant shall plainly say, I love my master, my wife, and my children; I will not go out free:

Exodus 21:6 Then his master shall bring him unto the judges; he shall also bring him to the door, or unto the door post; and his master shall bore his ear through with an awl; and he shall serve him for ever.

Exodus 21:7 And if a man sell his daughter to be a maidservant, she shall not go out as the menservants do.

Exodus 21:8 If she please not her master, who hath betrothed her to himself, then shall he let her be redeemed: to sell her unto a strange nation he shall have no power, seeing he hath dealt deceitfully with her.

Exodus 21:9 And if he have betrothed her unto his son, he shall deal with her after the manner of daughters.

Exodus 21:10 If he take him another wife; her food, her raiment, and her duty of marriage, shall he not diminish.

Exodus 21:11 And if he do not these three unto her, then shall she go out free without money.

Exodus 21:12 He that smiteth a man, so that he die, shall be surely put to death.

Exodus 21:13 And if a man lie not in wait, but God deliver him into his hand; then I will appoint thee a place whither he shall flee.

Exodus 21:14 But if a man come presumptuously upon his neighbour, to slay him with guile; thou shalt take him from mine altar, that he may die.

Exodus 21:15 And he that smiteth his father, or his mother, shall be surely put to death.

Exodus 21:16 And he that stealeth a man, and selleth him, or if he be found in his hand, he shall surely be put to death.

Exodus 21:17 And he that curseth his father, or his mother, shall surely be put to death.

Exodus 21:18 And if men strive together, and one smite another with a stone, or with his fist, and he die not, but keepeth his bed:

Exodus 21:19 If he rise again, and walk abroad upon his staff, then shall he that smote him be quit: only he shall pay for the loss of his time, and shall cause him to be thoroughly healed.

Exodus 21:20 And if a man smite his servant, or his maid, with a rod, and he die under his hand; he shall be surely punished.

Exodus 21:21 Notwithstanding, if he continue a day or two, he shall not be punished: for he is his money.

Exodus 21:22 If men strive, and hurt a woman with child, so that her fruit depart from her, and yet no mischief follow: he shall be surely punished, according as the woman’s husband will lay upon him; and he shall pay as the judges determine.

Exodus 21:23 And if any mischief follow, then thou shalt give life for life,

Exodus 21:24 Eye for eye, tooth for tooth, hand for hand, foot for foot,

Exodus 21:25 Burning for burning, wound for wound, stripe for stripe.

Exodus 21:26 And if a man smite the eye of his servant, or the eye of his maid, that it perish; he shall let him go free for his eye’s sake.

Exodus 21:27 And if he smite out his manservant’s tooth, or his maidservant’s tooth; he shall let him go free for his tooth’s sake.

Exodus 21:28 If an ox gore a man or a woman, that they die: then the ox shall be surely stoned, and his flesh shall not be eaten; but the owner of the ox shall be quit.

Exodus 21:29 But if the ox were wont to push with his horn in time past, and it hath been testified to his owner, and he hath not kept him in, but that he hath killed a man or a woman; the ox shall be stoned, and his owner also shall be put to death.

Exodus 21:30 If there be laid on him a sum of money, then he shall give for the ransom of his life whatsoever is laid upon him.

Exodus 21:31 Whether he have gored a son, or have gored a daughter, according to this judgment shall it be done unto him.

Exodus 21:32 If the ox shall push a manservant or a maidservant; he shall give unto their master thirty shekels of silver, and the ox shall be stoned.

Exodus 21:33 And if a man shall open a pit, or if a man shall dig a pit, and not cover it, and an ox or an ass fall therein;

Exodus 21:34 The owner of the pit shall make it good, and give money unto the owner of them; and the dead beast shall be his.

Exodus 21:35 And if one man’s ox hurt another’s, that he die; then they shall sell the live ox, and divide the money of it; and the dead ox also they shall divide.

Exodus 21:36 Or if it be known that the ox hath used to push in time past, and his owner hath not kept him in; he shall surely pay ox for ox; and the dead shall be his own.
