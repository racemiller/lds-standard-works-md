# Exodus 5

Exodus 5 (summary): Moses and Aaron ask Pharaoh to free Israel—Pharaoh responds, Who is the Lord?—He places greater burdens upon the children of Israel.

Exodus 5:1 And afterward Moses and Aaron went in, and told Pharaoh, Thus saith the Lord God of Israel, Let my people go, that they may hold a feast unto me in the wilderness.

Exodus 5:2 And Pharaoh said, Who is the Lord, that I should obey his voice to let Israel go? I know not the Lord, neither will I let Israel go.

Exodus 5:3 And they said, The God of the Hebrews hath met with us: let us go, we pray thee, three days’ journey into the desert, and sacrifice unto the Lord our God; lest he fall upon us with pestilence, or with the sword.

Exodus 5:4 And the king of Egypt said unto them, Wherefore do ye, Moses and Aaron, let the people from their works? get you unto your burdens.

Exodus 5:5 And Pharaoh said, Behold, the people of the land now are many, and ye make them rest from their burdens.

Exodus 5:6 And Pharaoh commanded the same day the taskmasters of the people, and their officers, saying,

Exodus 5:7 Ye shall no more give the people straw to make brick, as heretofore: let them go and gather straw for themselves.

Exodus 5:8 And the tale of the bricks, which they did make heretofore, ye shall lay upon them; ye shall not diminish ought thereof: for they be idle; therefore they cry, saying, Let us go and sacrifice to our God.

Exodus 5:9 Let there more work be laid upon the men, that they may labour therein; and let them not regard vain words.

Exodus 5:10 And the taskmasters of the people went out, and their officers, and they spake to the people, saying, Thus saith Pharaoh, I will not give you straw.

Exodus 5:11 Go ye, get you straw where ye can find it: yet not ought of your work shall be diminished.

Exodus 5:12 So the people were scattered abroad throughout all the land of Egypt to gather stubble instead of straw.

Exodus 5:13 And the taskmasters hasted them, saying, Fulfil your works, your daily tasks, as when there was straw.

Exodus 5:14 And the officers of the children of Israel, which Pharaoh’s taskmasters had set over them, were beaten, and demanded, Wherefore have ye not fulfilled your task in making brick both yesterday and to day, as heretofore?

Exodus 5:15 Then the officers of the children of Israel came and cried unto Pharaoh, saying, Wherefore dealest thou thus with thy servants?

Exodus 5:16 There is no straw given unto thy servants, and they say to us, Make brick: and, behold, thy servants are beaten; but the fault is in thine own people.

Exodus 5:17 But he said, Ye are idle, ye are idle: therefore ye say, Let us go and do sacrifice to the Lord.

Exodus 5:18 Go therefore now, and work; for there shall no straw be given you, yet shall ye deliver the tale of bricks.

Exodus 5:19 And the officers of the children of Israel did see that they were in evil case, after it was said, Ye shall not minish ought from your bricks of your daily task.

Exodus 5:20 And they met Moses and Aaron, who stood in the way, as they came forth from Pharaoh:

Exodus 5:21 And they said unto them, The Lord look upon you, and judge; because ye have made our savour to be abhorred in the eyes of Pharaoh, and in the eyes of his servants, to put a sword in their hand to slay us.

Exodus 5:22 And Moses returned unto the Lord, and said, Lord, wherefore hast thou so evil entreated this people? why is it that thou hast sent me?

Exodus 5:23 For since I came to Pharaoh to speak in thy name, he hath done evil to this people; neither hast thou delivered thy people at all.
