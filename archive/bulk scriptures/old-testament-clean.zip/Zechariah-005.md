# Zechariah 5

Zechariah 5 (summary): An angel reveals truths to Zechariah by the use of symbolic representations.

Zechariah 5:1 Then I turned, and lifted up mine eyes, and looked, and behold a flying roll.

Zechariah 5:2 And he said unto me, What seest thou? And I answered, I see a flying roll; the length thereof is twenty cubits, and the breadth thereof ten cubits.

Zechariah 5:3 Then said he unto me, This is the curse that goeth forth over the face of the whole earth: for every one that stealeth shall be cut off as on this side according to it; and every one that sweareth shall be cut off as on that side according to it.

Zechariah 5:4 I will bring it forth, saith the Lord of hosts, and it shall enter into the house of the thief, and into the house of him that sweareth falsely by my name: and it shall remain in the midst of his house, and shall consume it with the timber thereof and the stones thereof.

Zechariah 5:5 Then the angel that talked with me went forth, and said unto me, Lift up now thine eyes, and see what is this that goeth forth.

Zechariah 5:6 And I said, What is it? And he said, This is an ephah that goeth forth. He said moreover, This is their resemblance through all the earth.

Zechariah 5:7 And, behold, there was lifted up a talent of lead: and this is a woman that sitteth in the midst of the ephah.

Zechariah 5:8 And he said, This is wickedness. And he cast it into the midst of the ephah; and he cast the weight of lead upon the mouth thereof.

Zechariah 5:9 Then lifted I up mine eyes, and looked, and, behold, there came out two women, and the wind was in their wings; for they had wings like the wings of a stork: and they lifted up the ephah between the earth and the heaven.

Zechariah 5:10 Then said I to the angel that talked with me, Whither do these bear the ephah?

Zechariah 5:11 And he said unto me, To build it an house in the land of Shinar: and it shall be established, and set there upon her own base.
