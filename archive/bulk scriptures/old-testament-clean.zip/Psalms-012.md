# Psalms 12

Psalms 12 (summary): David decries flattering lips and proud tongues—He says, The words of the Lord are pure words.

Psalms 12:1 Help, Lord; for the godly man ceaseth; for the faithful fail from among the children of men.

Psalms 12:2 They speak vanity every one with his neighbour: with flattering lips and with a double heart do they speak.

Psalms 12:3 The Lord shall cut off all flattering lips, and the tongue that speaketh proud things:

Psalms 12:4 Who have said, With our tongue will we prevail; our lips are our own: who is lord over us?

Psalms 12:5 For the oppression of the poor, for the sighing of the needy, now will I arise, saith the Lord; I will set him in safety from him that puffeth at him.

Psalms 12:6 The words of the Lord are pure words: as silver tried in a furnace of earth, purified seven times.

Psalms 12:7 Thou shalt keep them, O Lord, thou shalt preserve them from this generation for ever.

Psalms 12:8 The wicked walk on every side, when the vilest men are exalted.
