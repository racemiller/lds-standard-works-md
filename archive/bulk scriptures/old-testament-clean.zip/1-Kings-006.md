# 1 Kings 6

1 Kings 6 (summary): Solomon builds the temple—The Lord promises to dwell among the Israelites if they are obedient—The ornaments of the temple are described.

1 Kings 6:1 And it came to pass in the four hundred and eightieth year after the children of Israel were come out of the land of Egypt, in the fourth year of Solomon’s reign over Israel, in the month Zif, which is the second month, that he began to build the house of the Lord.

1 Kings 6:2 And the house which king Solomon built for the Lord, the length thereof was threescore cubits, and the breadth thereof twenty cubits, and the height thereof thirty cubits.

1 Kings 6:3 And the porch before the temple of the house, twenty cubits was the length thereof, according to the breadth of the house; and ten cubits was the breadth thereof before the house.

1 Kings 6:4 And for the house he made windows of narrow lights.

1 Kings 6:5 And against the wall of the house he built chambers round about, against the walls of the house round about, both of the temple and of the oracle: and he made chambers round about:

1 Kings 6:6 The nethermost chamber was five cubits broad, and the middle was six cubits broad, and the third was seven cubits broad: for without in the wall of the house he made narrowed rests round about, that the beams should not be fastened in the walls of the house.

1 Kings 6:7 And the house, when it was in building, was built of stone made ready before it was brought thither: so that there was neither hammer nor axe nor any tool of iron heard in the house, while it was in building.

1 Kings 6:8 The door for the middle chamber was in the right side of the house: and they went up with winding stairs into the middle chamber, and out of the middle into the third.

1 Kings 6:9 So he built the house, and finished it; and covered the house with beams and boards of cedar.

1 Kings 6:10 And then he built chambers against all the house, five cubits high: and they rested on the house with timber of cedar.

1 Kings 6:11 And the word of the Lord came to Solomon, saying,

1 Kings 6:12 Concerning this house which thou art in building, if thou wilt walk in my statutes, and execute my judgments, and keep all my commandments to walk in them; then will I perform my word with thee, which I spake unto David thy father:

1 Kings 6:13 And I will dwell among the children of Israel, and will not forsake my people Israel.

1 Kings 6:14 So Solomon built the house, and finished it.

1 Kings 6:15 And he built the walls of the house within with boards of cedar, both the floor of the house, and the walls of the ceiling: and he covered them on the inside with wood, and covered the floor of the house with planks of fir.

1 Kings 6:16 And he built twenty cubits on the sides of the house, both the floor and the walls with boards of cedar: he even built them for it within, even for the oracle, even for the most holy place.

1 Kings 6:17 And the house, that is, the temple before it, was forty cubits long.

1 Kings 6:18 And the cedar of the house within was carved with knops and open flowers: all was cedar; there was no stone seen.

1 Kings 6:19 And the oracle he prepared in the house within, to set there the ark of the covenant of the Lord.

1 Kings 6:20 And the oracle in the forepart was twenty cubits in length, and twenty cubits in breadth, and twenty cubits in the height thereof: and he overlaid it with pure gold; and so covered the altar which was of cedar.

1 Kings 6:21 So Solomon overlaid the house within with pure gold: and he made a partition by the chains of gold before the oracle; and he overlaid it with gold.

1 Kings 6:22 And the whole house he overlaid with gold, until he had finished all the house: also the whole altar that was by the oracle he overlaid with gold.

1 Kings 6:23 And within the oracle he made two cherubims of olive tree, each ten cubits high.

1 Kings 6:24 And five cubits was the one wing of the cherub, and five cubits the other wing of the cherub: from the uttermost part of the one wing unto the uttermost part of the other were ten cubits.

1 Kings 6:25 And the other cherub was ten cubits: both the cherubims were of one measure and one size.

1 Kings 6:26 The height of the one cherub was ten cubits, and so was it of the other cherub.

1 Kings 6:27 And he set the cherubims within the inner house: and they stretched forth the wings of the cherubims, so that the wing of the one touched the one wall, and the wing of the other cherub touched the other wall; and their wings touched one another in the midst of the house.

1 Kings 6:28 And he overlaid the cherubims with gold.

1 Kings 6:29 And he carved all the walls of the house round about with carved figures of cherubims and palm trees and open flowers, within and without.

1 Kings 6:30 And the floor of the house he overlaid with gold, within and without.

1 Kings 6:31 And for the entering of the oracle he made doors of olive tree: the lintel and side posts were a fifth part of the wall.

1 Kings 6:32 The two doors also were of olive tree; and he carved upon them carvings of cherubims and palm trees and open flowers, and overlaid them with gold, and spread gold upon the cherubims, and upon the palm trees.

1 Kings 6:33 So also made he for the door of the temple posts of olive tree, a fourth part of the wall.

1 Kings 6:34 And the two doors were of fir tree: the two leaves of the one door were folding, and the two leaves of the other door were folding.

1 Kings 6:35 And he carved thereon cherubims and palm trees and open flowers: and covered them with gold fitted upon the carved work.

1 Kings 6:36 And he built the inner court with three rows of hewed stone, and a row of cedar beams.

1 Kings 6:37 In the fourth year was the foundation of the house of the Lord laid, in the month Zif:

1 Kings 6:38 And in the eleventh year, in the month Bul, which is the eighth month, was the house finished throughout all the parts thereof, and according to all the fashion of it. So was he seven years in building it.
