# Jeremiah 22

Jeremiah 22 (summary): David’s throne stands or falls according to the obedience of the kings—The judgments of the Lord rest upon the kings of Judah.

Jeremiah 22:1 Thus saith the Lord; Go down to the house of the king of Judah, and speak there this word,

Jeremiah 22:2 And say, Hear the word of the Lord, O king of Judah, that sittest upon the throne of David, thou, and thy servants, and thy people that enter in by these gates:

Jeremiah 22:3 Thus saith the Lord; Execute ye judgment and righteousness, and deliver the spoiled out of the hand of the oppressor: and do no wrong, do no violence to the stranger, the fatherless, nor the widow, neither shed innocent blood in this place.

Jeremiah 22:4 For if ye do this thing indeed, then shall there enter in by the gates of this house kings sitting upon the throne of David, riding in chariots and on horses, he, and his servants, and his people.

Jeremiah 22:5 But if ye will not hear these words, I swear by myself, saith the Lord, that this house shall become a desolation.

Jeremiah 22:6 For thus saith the Lord unto the king’s house of Judah; Thou art Gilead unto me, and the head of Lebanon: yet surely I will make thee a wilderness, and cities which are not inhabited.

Jeremiah 22:7 And I will prepare destroyers against thee, every one with his weapons: and they shall cut down thy choice cedars, and cast them into the fire.

Jeremiah 22:8 And many nations shall pass by this city, and they shall say every man to his neighbour, Wherefore hath the Lord done thus unto this great city?

Jeremiah 22:9 Then they shall answer, Because they have forsaken the covenant of the Lord their God, and worshipped other gods, and served them.

Jeremiah 22:10 Weep ye not for the dead, neither bemoan him: but weep sore for him that goeth away: for he shall return no more, nor see his native country.

Jeremiah 22:11 For thus saith the Lord touching Shallum the son of Josiah king of Judah, which reigned instead of Josiah his father, which went forth out of this place; He shall not return thither any more:

Jeremiah 22:12 But he shall die in the place whither they have led him captive, and shall see this land no more.

Jeremiah 22:13 Woe unto him that buildeth his house by unrighteousness, and his chambers by wrong; that useth his neighbour’s service without wages, and giveth him not for his work;

Jeremiah 22:14 That saith, I will build me a wide house and large chambers, and cutteth him out windows; and it is ceiled with cedar, and painted with vermilion.

Jeremiah 22:15 Shalt thou reign, because thou closest thyself in cedar? did not thy father eat and drink, and do judgment and justice, and then it was well with him?

Jeremiah 22:16 He judged the cause of the poor and needy; then it was well with him: was not this to know me? saith the Lord.

Jeremiah 22:17 But thine eyes and thine heart are not but for thy covetousness, and for to shed innocent blood, and for oppression, and for violence, to do it.

Jeremiah 22:18 Therefore thus saith the Lord concerning Jehoiakim the son of Josiah king of Judah; They shall not lament for him, saying, Ah my brother! or, Ah sister! they shall not lament for him, saying, Ah lord! or, Ah his glory!

Jeremiah 22:19 He shall be buried with the burial of an ass, drawn and cast forth beyond the gates of Jerusalem.

Jeremiah 22:20 Go up to Lebanon, and cry; and lift up thy voice in Bashan, and cry from the passages: for all thy lovers are destroyed.

Jeremiah 22:21 I spake unto thee in thy prosperity; but thou saidst, I will not hear. This hath been thy manner from thy youth, that thou obeyedst not my voice.

Jeremiah 22:22 The wind shall eat up all thy pastors, and thy lovers shall go into captivity: surely then shalt thou be ashamed and confounded for all thy wickedness.

Jeremiah 22:23 O inhabitant of Lebanon, that makest thy nest in the cedars, how gracious shalt thou be when pangs come upon thee, the pain as of a woman in travail!

Jeremiah 22:24 As I live, saith the Lord, though Coniah the son of Jehoiakim king of Judah were the signet upon my right hand, yet would I pluck thee thence;

Jeremiah 22:25 And I will give thee into the hand of them that seek thy life, and into the hand of them whose face thou fearest, even into the hand of Nebuchadrezzar king of Babylon, and into the hand of the Chaldeans.

Jeremiah 22:26 And I will cast thee out, and thy mother that bare thee, into another country, where ye were not born; and there shall ye die.

Jeremiah 22:27 But to the land whereunto they desire to return, thither shall they not return.

Jeremiah 22:28 Is this man Coniah a despised broken idol? is he a vessel wherein is no pleasure? wherefore are they cast out, he and his seed, and are cast into a land which they know not?

Jeremiah 22:29 O earth, earth, earth, hear the word of the Lord.

Jeremiah 22:30 Thus saith the Lord, Write ye this man childless, a man that shall not prosper in his days: for no man of his seed shall prosper, sitting upon the throne of David, and ruling any more in Judah.
