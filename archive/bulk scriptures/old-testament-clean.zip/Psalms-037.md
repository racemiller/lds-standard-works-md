# Psalms 37

Psalms 37 (summary): David counsels, Trust in the Lord and do good—Rest in the Lord and wait patiently for Him—Cease from anger and forsake wrath—The meek will inherit the earth—The Lord loves justice and does not forsake His Saints.

Psalms 37:1 Fret not thyself because of evildoers, neither be thou envious against the workers of iniquity.

Psalms 37:2 For they shall soon be cut down like the grass, and wither as the green herb.

Psalms 37:3 Trust in the Lord, and do good; so shalt thou dwell in the land, and verily thou shalt be fed.

Psalms 37:4 Delight thyself also in the Lord; and he shall give thee the desires of thine heart.

Psalms 37:5 Commit thy way unto the Lord; trust also in him; and he shall bring it to pass.

Psalms 37:6 And he shall bring forth thy righteousness as the light, and thy judgment as the noonday.

Psalms 37:7 Rest in the Lord, and wait patiently for him: fret not thyself because of him who prospereth in his way, because of the man who bringeth wicked devices to pass.

Psalms 37:8 Cease from anger, and forsake wrath: fret not thyself in any wise to do evil.

Psalms 37:9 For evildoers shall be cut off: but those that wait upon the Lord, they shall inherit the earth.

Psalms 37:10 For yet a little while, and the wicked shall not be: yea, thou shalt diligently consider his place, and it shall not be.

Psalms 37:11 But the meek shall inherit the earth; and shall delight themselves in the abundance of peace.

Psalms 37:12 The wicked plotteth against the just, and gnasheth upon him with his teeth.

Psalms 37:13 The Lord shall laugh at him: for he seeth that his day is coming.

Psalms 37:14 The wicked have drawn out the sword, and have bent their bow, to cast down the poor and needy, and to slay such as be of upright conversation.

Psalms 37:15 Their sword shall enter into their own heart, and their bows shall be broken.

Psalms 37:16 A little that a righteous man hath is better than the riches of many wicked.

Psalms 37:17 For the arms of the wicked shall be broken: but the Lord upholdeth the righteous.

Psalms 37:18 The Lord knoweth the days of the upright: and their inheritance shall be for ever.

Psalms 37:19 They shall not be ashamed in the evil time: and in the days of famine they shall be satisfied.

Psalms 37:20 But the wicked shall perish, and the enemies of the Lord shall be as the fat of lambs: they shall consume; into smoke shall they consume away.

Psalms 37:21 The wicked borroweth, and payeth not again: but the righteous sheweth mercy, and giveth.

Psalms 37:22 For such as be blessed of him shall inherit the earth; and they that be cursed of him shall be cut off.

Psalms 37:23 The steps of a good man are ordered by the Lord: and he delighteth in his way.

Psalms 37:24 Though he fall, he shall not be utterly cast down: for the Lord upholdeth him with his hand.

Psalms 37:25 I have been young, and now am old; yet have I not seen the righteous forsaken, nor his seed begging bread.

Psalms 37:26 He is ever merciful, and lendeth; and his seed is blessed.

Psalms 37:27 Depart from evil, and do good; and dwell for evermore.

Psalms 37:28 For the Lord loveth judgment, and forsaketh not his saints; they are preserved for ever: but the seed of the wicked shall be cut off.

Psalms 37:29 The righteous shall inherit the land, and dwell therein for ever.

Psalms 37:30 The mouth of the righteous speaketh wisdom, and his tongue talketh of judgment.

Psalms 37:31 The law of his God is in his heart; none of his steps shall slide.

Psalms 37:32 The wicked watcheth the righteous, and seeketh to slay him.

Psalms 37:33 The Lord will not leave him in his hand, nor condemn him when he is judged.

Psalms 37:34 Wait on the Lord, and keep his way, and he shall exalt thee to inherit the land: when the wicked are cut off, thou shalt see it.

Psalms 37:35 I have seen the wicked in great power, and spreading himself like a green bay tree.

Psalms 37:36 Yet he passed away, and, lo, he was not: yea, I sought him, but he could not be found.

Psalms 37:37 Mark the perfect man, and behold the upright: for the end of that man is peace.

Psalms 37:38 But the transgressors shall be destroyed together: the end of the wicked shall be cut off.

Psalms 37:39 But the salvation of the righteous is of the Lord: he is their strength in the time of trouble.

Psalms 37:40 And the Lord shall help them, and deliver them: he shall deliver them from the wicked, and save them, because they trust in him.
