# Psalms 76

Psalms 76 (summary): God is known in Judah and dwells in Zion—He will save the meek of the earth.

Psalms 76:1 In Judah is God known: his name is great in Israel.

Psalms 76:2 In Salem also is his tabernacle, and his dwelling place in Zion.

Psalms 76:3 There brake he the arrows of the bow, the shield, and the sword, and the battle. Selah.

Psalms 76:4 Thou art more glorious and excellent than the mountains of prey.

Psalms 76:5 The stouthearted are spoiled, they have slept their sleep: and none of the men of might have found their hands.

Psalms 76:6 At thy rebuke, O God of Jacob, both the chariot and horse are cast into a dead sleep.

Psalms 76:7 Thou, even thou, art to be feared: and who may stand in thy sight when once thou art angry?

Psalms 76:8 Thou didst cause judgment to be heard from heaven; the earth feared, and was still,

Psalms 76:9 When God arose to judgment, to save all the meek of the earth. Selah.

Psalms 76:10 Surely the wrath of man shall praise thee: the remainder of wrath shalt thou restrain.

Psalms 76:11 Vow, and pay unto the Lord your God: let all that be round about him bring presents unto him that ought to be feared.

Psalms 76:12 He shall cut off the spirit of princes: he is terrible to the kings of the earth.
