# Exodus 24

Exodus 24 (summary): Israel accepts the word of the Lord by covenant—Moses sprinkles the blood of the covenant—He, Aaron, Nadab, Abihu, and seventy of the elders of Israel see God—The Lord calls Moses on to the mount to receive the tables of stone and commandments.

Exodus 24:1 And he said unto Moses, Come up unto the Lord, thou, and Aaron, Nadab, and Abihu, and seventy of the elders of Israel; and worship ye afar off.

Exodus 24:2 And Moses alone shall come near the Lord: but they shall not come nigh; neither shall the people go up with him.

Exodus 24:3 And Moses came and told the people all the words of the Lord, and all the judgments: and all the people answered with one voice, and said, All the words which the Lord hath said will we do.

Exodus 24:4 And Moses wrote all the words of the Lord, and rose up early in the morning, and builded an altar under the hill, and twelve pillars, according to the twelve tribes of Israel.

Exodus 24:5 And he sent young men of the children of Israel, which offered burnt offerings, and sacrificed peace offerings of oxen unto the Lord.

Exodus 24:6 And Moses took half of the blood, and put it in basins; and half of the blood he sprinkled on the altar.

Exodus 24:7 And he took the book of the covenant, and read in the audience of the people: and they said, All that the Lord hath said will we do, and be obedient.

Exodus 24:8 And Moses took the blood, and sprinkled it on the people, and said, Behold the blood of the covenant, which the Lord hath made with you concerning all these words.

Exodus 24:9 Then went up Moses, and Aaron, Nadab, and Abihu, and seventy of the elders of Israel:

Exodus 24:10 And they saw the God of Israel: and there was under his feet as it were a paved work of a sapphire stone, and as it were the body of heaven in his clearness.

Exodus 24:11 And upon the nobles of the children of Israel he laid not his hand: also they saw God, and did eat and drink.

Exodus 24:12 And the Lord said unto Moses, Come up to me into the mount, and be there: and I will give thee tables of stone, and a law, and commandments which I have written; that thou mayest teach them.

Exodus 24:13 And Moses rose up, and his minister Joshua: and Moses went up into the mount of God.

Exodus 24:14 And he said unto the elders, Tarry ye here for us, until we come again unto you: and, behold, Aaron and Hur are with you: if any man have any matters to do, let him come unto them.

Exodus 24:15 And Moses went up into the mount, and a cloud covered the mount.

Exodus 24:16 And the glory of the Lord abode upon mount Sinai, and the cloud covered it six days: and the seventh day he called unto Moses out of the midst of the cloud.

Exodus 24:17 And the sight of the glory of the Lord was like devouring fire on the top of the mount in the eyes of the children of Israel.

Exodus 24:18 And Moses went into the midst of the cloud, and gat him up into the mount: and Moses was in the mount forty days and forty nights.
