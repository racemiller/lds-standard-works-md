# Judges 5

Judges 5 (summary): Deborah and Barak sing a song of praise because Israel is delivered from Canaanite bondage.

Judges 5:1 Then sang Deborah and Barak the son of Abinoam on that day, saying,

Judges 5:2 Praise ye the Lord for the avenging of Israel, when the people willingly offered themselves.

Judges 5:3 Hear, O ye kings; give ear, O ye princes; I, even I, will sing unto the Lord; I will sing praise to the Lord God of Israel.

Judges 5:4 Lord, when thou wentest out of Seir, when thou marchedst out of the field of Edom, the earth trembled, and the heavens dropped, the clouds also dropped water.

Judges 5:5 The mountains melted from before the Lord, even that Sinai from before the Lord God of Israel.

Judges 5:6 In the days of Shamgar the son of Anath, in the days of Jael, the highways were unoccupied, and the travellers walked through byways.

Judges 5:7 The inhabitants of the villages ceased, they ceased in Israel, until that I Deborah arose, that I arose a mother in Israel.

Judges 5:8 They chose new gods; then was war in the gates: was there a shield or spear seen among forty thousand in Israel?

Judges 5:9 My heart is toward the governors of Israel, that offered themselves willingly among the people. Bless ye the Lord.

Judges 5:10 Speak, ye that ride on white asses, ye that sit in judgment, and walk by the way.

Judges 5:11 They that are delivered from the noise of archers in the places of drawing water, there shall they rehearse the righteous acts of the Lord, even the righteous acts toward the inhabitants of his villages in Israel: then shall the people of the Lord go down to the gates.

Judges 5:12 Awake, awake, Deborah: awake, awake, utter a song: arise, Barak, and lead thy captivity captive, thou son of Abinoam.

Judges 5:13 Then he made him that remaineth have dominion over the nobles among the people: the Lord made me have dominion over the mighty.

Judges 5:14 Out of Ephraim was there a root of them against Amalek; after thee, Benjamin, among thy people; out of Machir came down governors, and out of Zebulun they that handle the pen of the writer.

Judges 5:15 And the princes of Issachar were with Deborah; even Issachar, and also Barak: he was sent on foot into the valley. For the divisions of Reuben there were great thoughts of heart.

Judges 5:16 Why abodest thou among the sheepfolds, to hear the bleatings of the flocks? For the divisions of Reuben there were great searchings of heart.

Judges 5:17 Gilead abode beyond Jordan: and why did Dan remain in ships? Asher continued on the sea shore, and abode in his breaches.

Judges 5:18 Zebulun and Naphtali were a people that jeoparded their lives unto the death in the high places of the field.

Judges 5:19 The kings came and fought, then fought the kings of Canaan in Taanach by the waters of Megiddo; they took no gain of money.

Judges 5:20 They fought from heaven; the stars in their courses fought against Sisera.

Judges 5:21 The river of Kishon swept them away, that ancient river, the river Kishon. O my soul, thou hast trodden down strength.

Judges 5:22 Then were the horsehoofs broken by the means of the pransings, the pransings of their mighty ones.

Judges 5:23 Curse ye Meroz, said the angel of the Lord, curse ye bitterly the inhabitants thereof; because they came not to the help of the Lord, to the help of the Lord against the mighty.

Judges 5:24 Blessed above women shall Jael the wife of Heber the Kenite be, blessed shall she be above women in the tent.

Judges 5:25 He asked water, and she gave him milk; she brought forth butter in a lordly dish.

Judges 5:26 She put her hand to the nail, and her right hand to the workmen’s hammer; and with the hammer she smote Sisera, she smote off his head, when she had pierced and stricken through his temples.

Judges 5:27 At her feet he bowed, he fell, he lay down: at her feet he bowed, he fell: where he bowed, there he fell down dead.

Judges 5:28 The mother of Sisera looked out at a window, and cried through the lattice, Why is his chariot so long in coming? why tarry the wheels of his chariots?

Judges 5:29 Her wise ladies answered her, yea, she returned answer to herself,

Judges 5:30 Have they not sped? have they not divided the prey; to every man a damsel or two; to Sisera a prey of divers colours, a prey of divers colours of needlework, of divers colours of needlework on both sides, meet for the necks of them that take the spoil?

Judges 5:31 So let all thine enemies perish, O Lord: but let them that love him be as the sun when he goeth forth in his might. And the land had rest forty years.
