# Jeremiah 39

Jeremiah 39 (summary): Jerusalem is taken, and the people are taken captive—Jeremiah and Ebed-melech, the Ethiopian, are preserved.

Jeremiah 39:1 In the ninth year of Zedekiah king of Judah, in the tenth month, came Nebuchadrezzar king of Babylon and all his army against Jerusalem, and they besieged it.

Jeremiah 39:2 And in the eleventh year of Zedekiah, in the fourth month, the ninth day of the month, the city was broken up.

Jeremiah 39:3 And all the princes of the king of Babylon came in, and sat in the middle gate, even Nergal-sharezer, Samgar-nebo, Sarsechim, Rab-saris, Nergal-sharezer, Rab-mag, with all the residue of the princes of the king of Babylon.

Jeremiah 39:4 And it came to pass, that when Zedekiah the king of Judah saw them, and all the men of war, then they fled, and went forth out of the city by night, by the way of the king’s garden, by the gate betwixt the two walls: and he went out the way of the plain.

Jeremiah 39:5 But the Chaldeans’ army pursued after them, and overtook Zedekiah in the plains of Jericho: and when they had taken him, they brought him up to Nebuchadnezzar king of Babylon to Riblah in the land of Hamath, where he gave judgment upon him.

Jeremiah 39:6 Then the king of Babylon slew the sons of Zedekiah in Riblah before his eyes: also the king of Babylon slew all the nobles of Judah.

Jeremiah 39:7 Moreover he put out Zedekiah’s eyes, and bound him with chains, to carry him to Babylon.

Jeremiah 39:8 And the Chaldeans burned the king’s house, and the houses of the people, with fire, and brake down the walls of Jerusalem.

Jeremiah 39:9 Then Nebuzar-adan the captain of the guard carried away captive into Babylon the remnant of the people that remained in the city, and those that fell away, that fell to him, with the rest of the people that remained.

Jeremiah 39:10 But Nebuzar-adan the captain of the guard left of the poor of the people, which had nothing, in the land of Judah, and gave them vineyards and fields at the same time.

Jeremiah 39:11 Now Nebuchadrezzar king of Babylon gave charge concerning Jeremiah to Nebuzar-adan the captain of the guard, saying,

Jeremiah 39:12 Take him, and look well to him, and do him no harm; but do unto him even as he shall say unto thee.

Jeremiah 39:13 So Nebuzar-adan the captain of the guard sent, and Nebushasban, Rab-saris, and Nergal-sharezer, Rab-mag, and all the king of Babylon’s princes;

Jeremiah 39:14 Even they sent, and took Jeremiah out of the court of the prison, and committed him unto Gedaliah the son of Ahikam the son of Shaphan, that he should carry him home: so he dwelt among the people.

Jeremiah 39:15 Now the word of the Lord came unto Jeremiah, while he was shut up in the court of the prison, saying,

Jeremiah 39:16 Go and speak to Ebed-melech the Ethiopian, saying, Thus saith the Lord of hosts, the God of Israel; Behold, I will bring my words upon this city for evil, and not for good; and they shall be accomplished in that day before thee.

Jeremiah 39:17 But I will deliver thee in that day, saith the Lord: and thou shalt not be given into the hand of the men of whom thou art afraid.

Jeremiah 39:18 For I will surely deliver thee, and thou shalt not fall by the sword, but thy life shall be for a prey unto thee: because thou hast put thy trust in me, saith the Lord.
