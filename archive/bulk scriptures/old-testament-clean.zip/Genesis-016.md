# Genesis 16

Genesis 16 (summary): Sarai gives Hagar to Abram as his wife—Hagar flees from Sarai—An angel commands Hagar to return and submit herself to Sarai—Hagar bears Ishmael.

Genesis 16:1 Now Sarai Abram’s wife bare him no children: and she had an handmaid, an Egyptian, whose name was Hagar.

Genesis 16:2 And Sarai said unto Abram, Behold now, the Lord hath restrained me from bearing: I pray thee, go in unto my maid; it may be that I may obtain children by her. And Abram hearkened to the voice of Sarai.

Genesis 16:3 And Sarai Abram’s wife took Hagar her maid the Egyptian, after Abram had dwelt ten years in the land of Canaan, and gave her to her husband Abram to be his wife.

Genesis 16:4 And he went in unto Hagar, and she conceived: and when she saw that she had conceived, her mistress was despised in her eyes.

Genesis 16:5 And Sarai said unto Abram, My wrong be upon thee: I have given my maid into thy bosom; and when she saw that she had conceived, I was despised in her eyes: the Lord judge between me and thee.

Genesis 16:6 But Abram said unto Sarai, Behold, thy maid is in thy hand; do to her as it pleaseth thee. And when Sarai dealt hardly with her, she fled from her face.

Genesis 16:7 And the angel of the Lord found her by a fountain of water in the wilderness, by the fountain in the way to Shur.

Genesis 16:8 And he said, Hagar, Sarai’s maid, whence camest thou? and whither wilt thou go? And she said, I flee from the face of my mistress Sarai.

Genesis 16:9 And the angel of the Lord said unto her, Return to thy mistress, and submit thyself under her hands.

Genesis 16:10 And the angel of the Lord said unto her, I will multiply thy seed exceedingly, that it shall not be numbered for multitude.

Genesis 16:11 And the angel of the Lord said unto her, Behold, thou art with child, and shalt bear a son, and shalt call his name Ishmael; because the Lord hath heard thy affliction.

Genesis 16:12 And he will be a wild man; his hand will be against every man, and every man’s hand against him; and he shall dwell in the presence of all his brethren.

Genesis 16:13 And she called the name of the Lord that spake unto her, Thou God seest me: for she said, Have I also here looked after him that seeth me?

Genesis 16:14 Wherefore the well was called Beer-lahai-roi; behold, it is between Kadesh and Bered.

Genesis 16:15 And Hagar bare Abram a son: and Abram called his son’s name, which Hagar bare, Ishmael.

Genesis 16:16 And Abram was fourscore and six years old, when Hagar bare Ishmael to Abram.
