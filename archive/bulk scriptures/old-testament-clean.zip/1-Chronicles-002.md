# 1 Chronicles 2

1 Chronicles 2 (summary): The descendants of Israel, Judah, Jesse, Caleb, and others are listed.

1 Chronicles 2:1 These are the sons of Israel; Reuben, Simeon, Levi, and Judah, Issachar, and Zebulun,

1 Chronicles 2:2 Dan, Joseph, and Benjamin, Naphtali, Gad, and Asher.

1 Chronicles 2:3 The sons of Judah; Er, and Onan, and Shelah: which three were born unto him of the daughter of Shua the Canaanitess. And Er, the firstborn of Judah, was evil in the sight of the Lord; and he slew him.

1 Chronicles 2:4 And Tamar his daughter in law bare him Pharez and Zerah. All the sons of Judah were five.

1 Chronicles 2:5 The sons of Pharez; Hezron, and Hamul.

1 Chronicles 2:6 And the sons of Zerah; Zimri, and Ethan, and Heman, and Calcol, and Dara: five of them in all.

1 Chronicles 2:7 And the sons of Carmi; Achar, the troubler of Israel, who transgressed in the thing accursed.

1 Chronicles 2:8 And the sons of Ethan; Azariah.

1 Chronicles 2:9 The sons also of Hezron, that were born unto him; Jerahmeel, and Ram, and Chelubai.

1 Chronicles 2:10 And Ram begat Amminadab; and Amminadab begat Nahshon, prince of the children of Judah;

1 Chronicles 2:11 And Nahshon begat Salma, and Salma begat Boaz,

1 Chronicles 2:12 And Boaz begat Obed, and Obed begat Jesse,

1 Chronicles 2:13 And Jesse begat his firstborn Eliab, and Abinadab the second, and Shimma the third,

1 Chronicles 2:14 Nethaneel the fourth, Raddai the fifth,

1 Chronicles 2:15 Ozem the sixth, David the seventh:

1 Chronicles 2:16 Whose sisters were Zeruiah, and Abigail. And the sons of Zeruiah; Abishai, and Joab, and Asahel, three.

1 Chronicles 2:17 And Abigail bare Amasa: and the father of Amasa was Jether the Ishmeelite.

1 Chronicles 2:18 And Caleb the son of Hezron begat children of Azubah his wife, and of Jerioth: her sons are these; Jesher, and Shobab, and Ardon.

1 Chronicles 2:19 And when Azubah was dead, Caleb took unto him Ephrath, which bare him Hur.

1 Chronicles 2:20 And Hur begat Uri, and Uri begat Bezaleel.

1 Chronicles 2:21 And afterward Hezron went in to the daughter of Machir the father of Gilead, whom he married when he was threescore years old; and she bare him Segub.

1 Chronicles 2:22 And Segub begat Jair, who had three and twenty cities in the land of Gilead.

1 Chronicles 2:23 And he took Geshur, and Aram, with the towns of Jair, from them, with Kenath, and the towns thereof, even threescore cities. All these belonged to the sons of Machir the father of Gilead.

1 Chronicles 2:24 And after that Hezron was dead in Caleb-ephratah, then Abiah Hezron’s wife bare him Ashur the father of Tekoa.

1 Chronicles 2:25 And the sons of Jerahmeel the firstborn of Hezron were, Ram the firstborn, and Bunah, and Oren, and Ozem, and Ahijah.

1 Chronicles 2:26 Jerahmeel had also another wife, whose name was Atarah; she was the mother of Onam.

1 Chronicles 2:27 And the sons of Ram the firstborn of Jerahmeel were, Maaz, and Jamin, and Eker.

1 Chronicles 2:28 And the sons of Onam were, Shammai, and Jada. And the sons of Shammai; Nadab, and Abishur.

1 Chronicles 2:29 And the name of the wife of Abishur was Abihail, and she bare him Ahban, and Molid.

1 Chronicles 2:30 And the sons of Nadab; Seled, and Appaim: but Seled died without children.

1 Chronicles 2:31 And the sons of Appaim; Ishi. And the sons of Ishi; Sheshan. And the children of Sheshan; Ahlai.

1 Chronicles 2:32 And the sons of Jada the brother of Shammai; Jether, and Jonathan: and Jether died without children.

1 Chronicles 2:33 And the sons of Jonathan; Peleth, and Zaza. These were the sons of Jerahmeel.

1 Chronicles 2:34 Now Sheshan had no sons, but daughters. And Sheshan had a servant, an Egyptian, whose name was Jarha.

1 Chronicles 2:35 And Sheshan gave his daughter to Jarha his servant to wife; and she bare him Attai.

1 Chronicles 2:36 And Attai begat Nathan, and Nathan begat Zabad,

1 Chronicles 2:37 And Zabad begat Ephlal, and Ephlal begat Obed,

1 Chronicles 2:38 And Obed begat Jehu, and Jehu begat Azariah,

1 Chronicles 2:39 And Azariah begat Helez, and Helez begat Eleasah,

1 Chronicles 2:40 And Eleasah begat Sisamai, and Sisamai begat Shallum,

1 Chronicles 2:41 And Shallum begat Jekamiah, and Jekamiah begat Elishama.

1 Chronicles 2:42 Now the sons of Caleb the brother of Jerahmeel were, Mesha his firstborn, which was the father of Ziph; and the sons of Mareshah the father of Hebron.

1 Chronicles 2:43 And the sons of Hebron; Korah, and Tappuah, and Rekem, and Shema.

1 Chronicles 2:44 And Shema begat Raham, the father of Jorkoam: and Rekem begat Shammai.

1 Chronicles 2:45 And the son of Shammai was Maon: and Maon was the father of Beth-zur.

1 Chronicles 2:46 And Ephah, Caleb’s concubine, bare Haran, and Moza, and Gazez: and Haran begat Gazez.

1 Chronicles 2:47 And the sons of Jahdai; Regem, and Jotham, and Geshan, and Pelet, and Ephah, and Shaaph.

1 Chronicles 2:48 Maachah, Caleb’s concubine, bare Sheber, and Tirhanah.

1 Chronicles 2:49 She bare also Shaaph the father of Madmannah, Sheva the father of Machbenah, and the father of Gibea: and the daughter of Caleb was Achsah.

1 Chronicles 2:50 These were the sons of Caleb the son of Hur, the firstborn of Ephratah; Shobal the father of Kirjath-jearim,

1 Chronicles 2:51 Salma the father of Beth-lehem, Hareph the father of Beth-gader.

1 Chronicles 2:52 And Shobal the father of Kirjath-jearim had sons; Haroeh, and half of the Manahethites.

1 Chronicles 2:53 And the families of Kirjath-jearim; the Ithrites, and the Puhites, and the Shumathites, and the Mishraites; of them came the Zareathites, and the Eshtaulites.

1 Chronicles 2:54 The sons of Salma; Beth-lehem, and the Netophathites, Ataroth, the house of Joab, and half of the Manahethites, the Zorites.

1 Chronicles 2:55 And the families of the scribes which dwelt at Jabez; the Tirathites, the Shimeathites, and Suchathites. These are the Kenites that came of Hemath, the father of the house of Rechab.
