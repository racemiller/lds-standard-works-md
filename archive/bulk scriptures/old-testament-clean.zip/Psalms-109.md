# Psalms 109

Psalms 109 (summary): David speaks of the cursings due to the wicked and deceitful—He prays that his enemies will be confounded.

Psalms 109:1 Hold not thy peace, O God of my praise;

Psalms 109:2 For the mouth of the wicked and the mouth of the deceitful are opened against me: they have spoken against me with a lying tongue.

Psalms 109:3 They compassed me about also with words of hatred; and fought against me without a cause.

Psalms 109:4 For my love they are my adversaries: but I give myself unto prayer.

Psalms 109:5 And they have rewarded me evil for good, and hatred for my love.

Psalms 109:6 Set thou a wicked man over him: and let Satan stand at his right hand.

Psalms 109:7 When he shall be judged, let him be condemned: and let his prayer become sin.

Psalms 109:8 Let his days be few; and let another take his office.

Psalms 109:9 Let his children be fatherless, and his wife a widow.

Psalms 109:10 Let his children be continually vagabonds, and beg: let them seek their bread also out of their desolate places.

Psalms 109:11 Let the extortioner catch all that he hath; and let the strangers spoil his labour.

Psalms 109:12 Let there be none to extend mercy unto him: neither let there be any to favour his fatherless children.

Psalms 109:13 Let his posterity be cut off; and in the generation following let their name be blotted out.

Psalms 109:14 Let the iniquity of his fathers be remembered with the Lord; and let not the sin of his mother be blotted out.

Psalms 109:15 Let them be before the Lord continually, that he may cut off the memory of them from the earth.

Psalms 109:16 Because that he remembered not to shew mercy, but persecuted the poor and needy man, that he might even slay the broken in heart.

Psalms 109:17 As he loved cursing, so let it come unto him: as he delighted not in blessing, so let it be far from him.

Psalms 109:18 As he clothed himself with cursing like as with his garment, so let it come into his bowels like water, and like oil into his bones.

Psalms 109:19 Let it be unto him as the garment which covereth him, and for a girdle wherewith he is girded continually.

Psalms 109:20 Let this be the reward of mine adversaries from the Lord, and of them that speak evil against my soul.

Psalms 109:21 But do thou for me, O God the Lord, for thy name’s sake: because thy mercy is good, deliver thou me.

Psalms 109:22 For I am poor and needy, and my heart is wounded within me.

Psalms 109:23 I am gone like the shadow when it declineth: I am tossed up and down as the locust.

Psalms 109:24 My knees are weak through fasting; and my flesh faileth of fatness.

Psalms 109:25 I became also a reproach unto them: when they looked upon me they shaked their heads.

Psalms 109:26 Help me, O Lord my God: O save me according to thy mercy:

Psalms 109:27 That they may know that this is thy hand; that thou, Lord, hast done it.

Psalms 109:28 Let them curse, but bless thou: when they arise, let them be ashamed; but let thy servant rejoice.

Psalms 109:29 Let mine adversaries be clothed with shame, and let them cover themselves with their own confusion, as with a mantle.

Psalms 109:30 I will greatly praise the Lord with my mouth; yea, I will praise him among the multitude.

Psalms 109:31 For he shall stand at the right hand of the poor, to save him from those that condemn his soul.
