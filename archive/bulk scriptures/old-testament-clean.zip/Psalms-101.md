# Psalms 101

Psalms 101 (summary): David sings of mercy and justice—He will forsake the company of evildoers.

Psalms 101:1 I will sing of mercy and judgment: unto thee, O Lord, will I sing.

Psalms 101:2 I will behave myself wisely in a perfect way. O when wilt thou come unto me? I will walk within my house with a perfect heart.

Psalms 101:3 I will set no wicked thing before mine eyes: I hate the work of them that turn aside; it shall not cleave to me.

Psalms 101:4 A froward heart shall depart from me: I will not know a wicked person.

Psalms 101:5 Whoso privily slandereth his neighbour, him will I cut off: him that hath an high look and a proud heart will not I suffer.

Psalms 101:6 Mine eyes shall be upon the faithful of the land, that they may dwell with me: he that walketh in a perfect way, he shall serve me.

Psalms 101:7 He that worketh deceit shall not dwell within my house: he that telleth lies shall not tarry in my sight.

Psalms 101:8 I will early destroy all the wicked of the land; that I may cut off all wicked doers from the city of the Lord.
