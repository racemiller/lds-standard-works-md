# Joshua 3

Joshua 3 (summary): Joshua leads Israel to the Jordan—The Lord cuts off the water of the Jordan; it stands up as a heap, and Israel passes over on dry ground.

Joshua 3:1 And Joshua rose early in the morning; and they removed from Shittim, and came to Jordan, he and all the children of Israel, and lodged there before they passed over.

Joshua 3:2 And it came to pass after three days, that the officers went through the host;

Joshua 3:3 And they commanded the people, saying, When ye see the ark of the covenant of the Lord your God, and the priests the Levites bearing it, then ye shall remove from your place, and go after it.

Joshua 3:4 Yet there shall be a space between you and it, about two thousand cubits by measure: come not near unto it, that ye may know the way by which ye must go: for ye have not passed this way heretofore.

Joshua 3:5 And Joshua said unto the people, Sanctify yourselves: for to morrow the Lord will do wonders among you.

Joshua 3:6 And Joshua spake unto the priests, saying, Take up the ark of the covenant, and pass over before the people. And they took up the ark of the covenant, and went before the people.

Joshua 3:7 And the Lord said unto Joshua, This day will I begin to magnify thee in the sight of all Israel, that they may know that, as I was with Moses, so I will be with thee.

Joshua 3:8 And thou shalt command the priests that bear the ark of the covenant, saying, When ye are come to the brink of the water of Jordan, ye shall stand still in Jordan.

Joshua 3:9 And Joshua said unto the children of Israel, Come hither, and hear the words of the Lord your God.

Joshua 3:10 And Joshua said, Hereby ye shall know that the living God is among you, and that he will without fail drive out from before you the Canaanites, and the Hittites, and the Hivites, and the Perizzites, and the Girgashites, and the Amorites, and the Jebusites.

Joshua 3:11 Behold, the ark of the covenant of the Lord of all the earth passeth over before you into Jordan.

Joshua 3:12 Now therefore take you twelve men out of the tribes of Israel, out of every tribe a man.

Joshua 3:13 And it shall come to pass, as soon as the soles of the feet of the priests that bear the ark of the Lord, the Lord of all the earth, shall rest in the waters of Jordan, that the waters of Jordan shall be cut off from the waters that come down from above; and they shall stand upon an heap.

Joshua 3:14 And it came to pass, when the people removed from their tents, to pass over Jordan, and the priests bearing the ark of the covenant before the people;

Joshua 3:15 And as they that bare the ark were come unto Jordan, and the feet of the priests that bare the ark were dipped in the brim of the water, (for Jordan overfloweth all his banks all the time of harvest,)

Joshua 3:16 That the waters which came down from above stood and rose up upon an heap very far from the city Adam, that is beside Zaretan: and those that came down toward the sea of the plain, even the salt sea, failed, and were cut off: and the people passed over right against Jericho.

Joshua 3:17 And the priests that bare the ark of the covenant of the Lord stood firm on dry ground in the midst of Jordan, and all the Israelites passed over on dry ground, until all the people were passed clean over Jordan.
