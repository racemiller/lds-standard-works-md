# Zechariah 7

Zechariah 7 (summary): The Lord reproves hypocrisy in fasts—He calls upon the people to show mercy and compassion and to live godly lives.

Zechariah 7:1 And it came to pass in the fourth year of king Darius, that the word of the Lord came unto Zechariah in the fourth day of the ninth month, even in Chisleu;

Zechariah 7:2 When they had sent unto the house of God Sherezer and Regem-melech, and their men, to pray before the Lord,

Zechariah 7:3 And to speak unto the priests which were in the house of the Lord of hosts, and to the prophets, saying, Should I weep in the fifth month, separating myself, as I have done these so many years?

Zechariah 7:4 Then came the word of the Lord of hosts unto me, saying,

Zechariah 7:5 Speak unto all the people of the land, and to the priests, saying, When ye fasted and mourned in the fifth and seventh month, even those seventy years, did ye at all fast unto me, even to me?

Zechariah 7:6 And when ye did eat, and when ye did drink, did not ye eat for yourselves, and drink for yourselves?

Zechariah 7:7 Should ye not hear the words which the Lord hath cried by the former prophets, when Jerusalem was inhabited and in prosperity, and the cities thereof round about her, when men inhabited the south and the plain?

Zechariah 7:8 And the word of the Lord came unto Zechariah, saying,

Zechariah 7:9 Thus speaketh the Lord of hosts, saying, Execute true judgment, and shew mercy and compassions every man to his brother:

Zechariah 7:10 And oppress not the widow, nor the fatherless, the stranger, nor the poor; and let none of you imagine evil against his brother in your heart.

Zechariah 7:11 But they refused to hearken, and pulled away the shoulder, and stopped their ears, that they should not hear.

Zechariah 7:12 Yea, they made their hearts as an adamant stone, lest they should hear the law, and the words which the Lord of hosts hath sent in his spirit by the former prophets: therefore came a great wrath from the Lord of hosts.

Zechariah 7:13 Therefore it is come to pass, that as he cried, and they would not hear; so they cried, and I would not hear, saith the Lord of hosts:

Zechariah 7:14 But I scattered them with a whirlwind among all the nations whom they knew not. Thus the land was desolate after them, that no man passed through nor returned: for they laid the pleasant land desolate.
