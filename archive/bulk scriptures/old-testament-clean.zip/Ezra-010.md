# Ezra 10

Ezra 10 (summary): The Jews covenant to put away their wives taken from the Canaanites and others—Ezra assembles the people at Jerusalem—The Levites who married non-Israelite women are listed.

Ezra 10:1 Now when Ezra had prayed, and when he had confessed, weeping and casting himself down before the house of God, there assembled unto him out of Israel a very great congregation of men and women and children: for the people wept very sore.

Ezra 10:2 And Shechaniah the son of Jehiel, one of the sons of Elam, answered and said unto Ezra, We have trespassed against our God, and have taken strange wives of the people of the land: yet now there is hope in Israel concerning this thing.

Ezra 10:3 Now therefore let us make a covenant with our God to put away all the wives, and such as are born of them, according to the counsel of my lord, and of those that tremble at the commandment of our God; and let it be done according to the law.

Ezra 10:4 Arise; for this matter belongeth unto thee: we also will be with thee: be of good courage, and do it.

Ezra 10:5 Then arose Ezra, and made the chief priests, the Levites, and all Israel, to swear that they should do according to this word. And they sware.

Ezra 10:6 Then Ezra rose up from before the house of God, and went into the chamber of Johanan the son of Eliashib: and when he came thither, he did eat no bread, nor drink water: for he mourned because of the transgression of them that had been carried away.

Ezra 10:7 And they made proclamation throughout Judah and Jerusalem unto all the children of the captivity, that they should gather themselves together unto Jerusalem;

Ezra 10:8 And that whosoever would not come within three days, according to the counsel of the princes and the elders, all his substance should be forfeited, and himself separated from the congregation of those that had been carried away.

Ezra 10:9 Then all the men of Judah and Benjamin gathered themselves together unto Jerusalem within three days. It was the ninth month, on the twentieth day of the month; and all the people sat in the street of the house of God, trembling because of this matter, and for the great rain.

Ezra 10:10 And Ezra the priest stood up, and said unto them, Ye have transgressed, and have taken strange wives, to increase the trespass of Israel.

Ezra 10:11 Now therefore make confession unto the Lord God of your fathers, and do his pleasure: and separate yourselves from the people of the land, and from the strange wives.

Ezra 10:12 Then all the congregation answered and said with a loud voice, As thou hast said, so must we do.

Ezra 10:13 But the people are many, and it is a time of much rain, and we are not able to stand without, neither is this a work of one day or two: for we are many that have transgressed in this thing.

Ezra 10:14 Let now our rulers of all the congregation stand, and let all them which have taken strange wives in our cities come at appointed times, and with them the elders of every city, and the judges thereof, until the fierce wrath of our God for this matter be turned from us.

Ezra 10:15 Only Jonathan the son of Asahel and Jahaziah the son of Tikvah were employed about this matter: and Meshullam and Shabbethai the Levite helped them.

Ezra 10:16 And the children of the captivity did so. And Ezra the priest, with certain chief of the fathers, after the house of their fathers, and all of them by their names, were separated, and sat down in the first day of the tenth month to examine the matter.

Ezra 10:17 And they made an end with all the men that had taken strange wives by the first day of the first month.

Ezra 10:18 And among the sons of the priests there were found that had taken strange wives: namely, of the sons of Jeshua the son of Jozadak, and his brethren; Maaseiah, and Eliezer, and Jarib, and Gedaliah.

Ezra 10:19 And they gave their hands that they would put away their wives; and being guilty, they offered a ram of the flock for their trespass.

Ezra 10:20 And of the sons of Immer; Hanani, and Zebadiah.

Ezra 10:21 And of the sons of Harim; Maaseiah, and Elijah, and Shemaiah, and Jehiel, and Uzziah.

Ezra 10:22 And of the sons of Pashur; Elioenai, Maaseiah, Ishmael, Nethaneel, Jozabad, and Elasah.

Ezra 10:23 Also of the Levites; Jozabad, and Shimei, and Kelaiah, (the same is Kelita,) Pethahiah, Judah, and Eliezer.

Ezra 10:24 Of the singers also; Eliashib: and of the porters; Shallum, and Telem, and Uri.

Ezra 10:25 Moreover of Israel: of the sons of Parosh; Ramiah, and Jeziah, and Malchiah, and Miamin, and Eleazar, and Malchijah, and Benaiah.

Ezra 10:26 And of the sons of Elam; Mattaniah, Zechariah, and Jehiel, and Abdi, and Jeremoth, and Eliah.

Ezra 10:27 And of the sons of Zattu; Elioenai, Eliashib, Mattaniah, and Jeremoth, and Zabad, and Aziza.

Ezra 10:28 Of the sons also of Bebai; Jehohanan, Hananiah, Zabbai, and Athlai.

Ezra 10:29 And of the sons of Bani; Meshullam, Malluch, and Adaiah, Jashub, and Sheal, and Ramoth.

Ezra 10:30 And of the sons of Pahath-moab; Adna, and Chelal, Benaiah, Maaseiah, Mattaniah, Bezaleel, and Binnui, and Manasseh.

Ezra 10:31 And of the sons of Harim; Eliezer, Ishijah, Malchiah, Shemaiah, Shimeon,

Ezra 10:32 Benjamin, Malluch, and Shemariah.

Ezra 10:33 Of the sons of Hashum; Mattenai, Mattathah, Zabad, Eliphelet, Jeremai, Manasseh, and Shimei.

Ezra 10:34 Of the sons of Bani; Maadai, Amram, and Uel,

Ezra 10:35 Benaiah, Bedeiah, Chelluh,

Ezra 10:36 Vaniah, Meremoth, Eliashib,

Ezra 10:37 Mattaniah, Mattenai, and Jaasau,

Ezra 10:38 And Bani, and Binnui, Shimei,

Ezra 10:39 And Shelemiah, and Nathan, and Adaiah,

Ezra 10:40 Machnadebai, Shashai, Sharai,

Ezra 10:41 Azareel, and Shelemiah, Shemariah,

Ezra 10:42 Shallum, Amariah, and Joseph.

Ezra 10:43 Of the sons of Nebo; Jeiel, Mattithiah, Zabad, Zebina, Jadau, and Joel, Benaiah.

Ezra 10:44 All these had taken strange wives: and some of them had wives by whom they had children.
