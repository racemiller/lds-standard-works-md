# Hosea 14

Hosea 14 (summary): In the last days, Ephraim will repent and return unto the Lord.

Hosea 14:1 O Israel, return unto the Lord thy God; for thou hast fallen by thine iniquity.

Hosea 14:2 Take with you words, and turn to the Lord: say unto him, Take away all iniquity, and receive us graciously: so will we render the calves of our lips.

Hosea 14:3 Asshur shall not save us; we will not ride upon horses: neither will we say any more to the work of our hands, Ye are our gods: for in thee the fatherless findeth mercy.

Hosea 14:4 I will heal their backsliding, I will love them freely: for mine anger is turned away from him.

Hosea 14:5 I will be as the dew unto Israel: he shall grow as the lily, and cast forth his roots as Lebanon.

Hosea 14:6 His branches shall spread, and his beauty shall be as the olive tree, and his smell as Lebanon.

Hosea 14:7 They that dwell under his shadow shall return; they shall revive as the corn, and grow as the vine: the scent thereof shall be as the wine of Lebanon.

Hosea 14:8 Ephraim shall say, What have I to do any more with idols? I have heard him, and observed him: I am like a green fir tree. From me is thy fruit found.

Hosea 14:9 Who is wise, and he shall understand these things? prudent, and he shall know them? for the ways of the Lord are right, and the just shall walk in them: but the transgressors shall fall therein.
