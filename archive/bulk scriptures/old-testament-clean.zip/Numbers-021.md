# Numbers 21

Numbers 21 (summary): The children of Israel destroy those Canaanites who fight against them—The Israelites are plagued with fiery serpents—Moses lifts up a serpent of brass to save those who look thereon—Israel defeats the Amorites, destroys the people of Bashan, and occupies their lands.

Numbers 21:1 And when king Arad the Canaanite, which dwelt in the south, heard tell that Israel came by the way of the spies; then he fought against Israel, and took some of them prisoners.

Numbers 21:2 And Israel vowed a vow unto the Lord, and said, If thou wilt indeed deliver this people into my hand, then I will utterly destroy their cities.

Numbers 21:3 And the Lord hearkened to the voice of Israel, and delivered up the Canaanites; and they utterly destroyed them and their cities: and he called the name of the place Hormah.

Numbers 21:4 And they journeyed from mount Hor by the way of the Red sea, to compass the land of Edom: and the soul of the people was much discouraged because of the way.

Numbers 21:5 And the people spake against God, and against Moses, Wherefore have ye brought us up out of Egypt to die in the wilderness? for there is no bread, neither is there any water; and our soul loatheth this light bread.

Numbers 21:6 And the Lord sent fiery serpents among the people, and they bit the people; and much people of Israel died.

Numbers 21:7 Therefore the people came to Moses, and said, We have sinned, for we have spoken against the Lord, and against thee; pray unto the Lord, that he take away the serpents from us. And Moses prayed for the people.

Numbers 21:8 And the Lord said unto Moses, Make thee a fiery serpent, and set it upon a pole: and it shall come to pass, that every one that is bitten, when he looketh upon it, shall live.

Numbers 21:9 And Moses made a serpent of brass, and put it upon a pole, and it came to pass, that if a serpent had bitten any man, when he beheld the serpent of brass, he lived.

Numbers 21:10 And the children of Israel set forward, and pitched in Oboth.

Numbers 21:11 And they journeyed from Oboth, and pitched at Ije-abarim, in the wilderness which is before Moab, toward the sunrising.

Numbers 21:12 From thence they removed, and pitched in the valley of Zared.

Numbers 21:13 From thence they removed, and pitched on the other side of Arnon, which is in the wilderness that cometh out of the coasts of the Amorites: for Arnon is the border of Moab, between Moab and the Amorites.

Numbers 21:14 Wherefore it is said in the book of the wars of the Lord, What he did in the Red sea, and in the brooks of Arnon,

Numbers 21:15 And at the stream of the brooks that goeth down to the dwelling of Ar, and lieth upon the border of Moab.

Numbers 21:16 And from thence they went to Beer: that is the well whereof the Lord spake unto Moses, Gather the people together, and I will give them water.

Numbers 21:17 Then Israel sang this song, Spring up, O well; sing ye unto it:

Numbers 21:18 The princes digged the well, the nobles of the people digged it, by the direction of the lawgiver, with their staves. And from the wilderness they went to Mattanah:

Numbers 21:19 And from Mattanah to Nahaliel: and from Nahaliel to Bamoth:

Numbers 21:20 And from Bamoth in the valley, that is in the country of Moab, to the top of Pisgah, which looketh toward Jeshimon.

Numbers 21:21 And Israel sent messengers unto Sihon king of the Amorites, saying,

Numbers 21:22 Let me pass through thy land: we will not turn into the fields, or into the vineyards; we will not drink of the waters of the well: but we will go along by the king’s high way, until we be past thy borders.

Numbers 21:23 And Sihon would not suffer Israel to pass through his border: but Sihon gathered all his people together, and went out against Israel into the wilderness: and he came to Jahaz, and fought against Israel.

Numbers 21:24 And Israel smote him with the edge of the sword, and possessed his land from Arnon unto Jabbok, even unto the children of Ammon: for the border of the children of Ammon was strong.

Numbers 21:25 And Israel took all these cities: and Israel dwelt in all the cities of the Amorites, in Heshbon, and in all the villages thereof.

Numbers 21:26 For Heshbon was the city of Sihon the king of the Amorites, who had fought against the former king of Moab, and taken all his land out of his hand, even unto Arnon.

Numbers 21:27 Wherefore they that speak in proverbs say, Come into Heshbon, let the city of Sihon be built and prepared:

Numbers 21:28 For there is a fire gone out of Heshbon, a flame from the city of Sihon: it hath consumed Ar of Moab, and the lords of the high places of Arnon.

Numbers 21:29 Woe to thee, Moab! thou art undone, O people of Chemosh: he hath given his sons that escaped, and his daughters, into captivity unto Sihon king of the Amorites.

Numbers 21:30 We have shot at them; Heshbon is perished even unto Dibon, and we have laid them waste even unto Nophah, which reacheth unto Medeba.

Numbers 21:31 Thus Israel dwelt in the land of the Amorites.

Numbers 21:32 And Moses sent to spy out Jaazer, and they took the villages thereof, and drove out the Amorites that were there.

Numbers 21:33 And they turned and went up by the way of Bashan: and Og the king of Bashan went out against them, he, and all his people, to the battle at Edrei.

Numbers 21:34 And the Lord said unto Moses, Fear him not: for I have delivered him into thy hand, and all his people, and his land; and thou shalt do to him as thou didst unto Sihon king of the Amorites, which dwelt at Heshbon.

Numbers 21:35 So they smote him, and his sons, and all his people, until there was none left him alive: and they possessed his land.
