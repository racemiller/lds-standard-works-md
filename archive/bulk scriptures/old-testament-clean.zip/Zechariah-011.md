# Zechariah 11

Zechariah 11 (summary): Zechariah speaks about the Messiah—The Messiah will be betrayed for thirty pieces of silver—They will be cast to the potter in the house of the Lord.

Zechariah 11:1 Open thy doors, O Lebanon, that the fire may devour thy cedars.

Zechariah 11:2 Howl, fir tree; for the cedar is fallen; because the mighty are spoiled: howl, O ye oaks of Bashan; for the forest of the vintage is come down.

Zechariah 11:3 There is a voice of the howling of the shepherds; for their glory is spoiled: a voice of the roaring of young lions; for the pride of Jordan is spoiled.

Zechariah 11:4 Thus saith the Lord my God; Feed the flock of the slaughter;

Zechariah 11:5 Whose possessors slay them, and hold themselves not guilty: and they that sell them say, Blessed be the Lord; for I am rich: and their own shepherds pity them not.

Zechariah 11:6 For I will no more pity the inhabitants of the land, saith the Lord: but, lo, I will deliver the men every one into his neighbour’s hand, and into the hand of his king: and they shall smite the land, and out of their hand I will not deliver them.

Zechariah 11:7 And I will feed the flock of slaughter, even you, O poor of the flock. And I took unto me two staves; the one I called Beauty, and the other I called Bands; and I fed the flock.

Zechariah 11:8 Three shepherds also I cut off in one month; and my soul lothed them, and their soul also abhorred me.

Zechariah 11:9 Then said I, I will not feed you: that that dieth, let it die; and that that is to be cut off, let it be cut off; and let the rest eat every one the flesh of another.

Zechariah 11:10 And I took my staff, even Beauty, and cut it asunder, that I might break my covenant which I had made with all the people.

Zechariah 11:11 And it was broken in that day: and so the poor of the flock that waited upon me knew that it was the word of the Lord.

Zechariah 11:12 And I said unto them, If ye think good, give me my price; and if not, forbear. So they weighed for my price thirty pieces of silver.

Zechariah 11:13 And the Lord said unto me, Cast it unto the potter: a goodly price that I was prised at of them. And I took the thirty pieces of silver, and cast them to the potter in the house of the Lord.

Zechariah 11:14 Then I cut asunder mine other staff, even Bands, that I might break the brotherhood between Judah and Israel.

Zechariah 11:15 And the Lord said unto me, Take unto thee yet the instruments of a foolish shepherd.

Zechariah 11:16 For, lo, I will raise up a shepherd in the land, which shall not visit those that be cut off, neither shall seek the young one, nor heal that that is broken, nor feed that that standeth still: but he shall eat the flesh of the fat, and tear their claws in pieces.

Zechariah 11:17 Woe to the idol shepherd that leaveth the flock! the sword shall be upon his arm, and upon his right eye: his arm shall be clean dried up, and his right eye shall be utterly darkened.
