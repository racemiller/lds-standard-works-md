# 1 Chronicles 13

1 Chronicles 13 (summary): David fetches the ark from Kirjath-jearim—Uzza is slain by the Lord when he steadies the ark—The house of Obed-edom prospers because they care for the ark.

1 Chronicles 13:1 And David consulted with the captains of thousands and hundreds, and with every leader.

1 Chronicles 13:2 And David said unto all the congregation of Israel, If it seem good unto you, and that it be of the Lord our God, let us send abroad unto our brethren every where, that are left in all the land of Israel, and with them also to the priests and Levites which are in their cities and suburbs, that they may gather themselves unto us:

1 Chronicles 13:3 And let us bring again the ark of our God to us: for we inquired not at it in the days of Saul.

1 Chronicles 13:4 And all the congregation said that they would do so: for the thing was right in the eyes of all the people.

1 Chronicles 13:5 So David gathered all Israel together, from Shihor of Egypt even unto the entering of Hemath, to bring the ark of God from Kirjath-jearim.

1 Chronicles 13:6 And David went up, and all Israel, to Baalah, that is, to Kirjath-jearim, which belonged to Judah, to bring up thence the ark of God the Lord, that dwelleth between the cherubims, whose name is called on it.

1 Chronicles 13:7 And they carried the ark of God in a new cart out of the house of Abinadab: and Uzza and Ahio drave the cart.

1 Chronicles 13:8 And David and all Israel played before God with all their might, and with singing, and with harps, and with psalteries, and with timbrels, and with cymbals, and with trumpets.

1 Chronicles 13:9 And when they came unto the threshingfloor of Chidon, Uzza put forth his hand to hold the ark; for the oxen stumbled.

1 Chronicles 13:10 And the anger of the Lord was kindled against Uzza, and he smote him, because he put his hand to the ark: and there he died before God.

1 Chronicles 13:11 And David was displeased, because the Lord had made a breach upon Uzza: wherefore that place is called Perez-uzza to this day.

1 Chronicles 13:12 And David was afraid of God that day, saying, How shall I bring the ark of God home to me?

1 Chronicles 13:13 So David brought not the ark home to himself to the city of David, but carried it aside into the house of Obed-edom the Gittite.

1 Chronicles 13:14 And the ark of God remained with the family of Obed-edom in his house three months. And the Lord blessed the house of Obed-edom, and all that he had.
