# 2 Kings 3

2 Kings 3 (summary): Jehoram of Israel and Jehoshaphat of Judah join forces against Moab—Elisha promises them water for their animals and victory in the war—The Moabites are defeated.

2 Kings 3:1 Now Jehoram the son of Ahab began to reign over Israel in Samaria the eighteenth year of Jehoshaphat king of Judah, and reigned twelve years.

2 Kings 3:2 And he wrought evil in the sight of the Lord; but not like his father, and like his mother: for he put away the image of Baal that his father had made.

2 Kings 3:3 Nevertheless he cleaved unto the sins of Jeroboam the son of Nebat, which made Israel to sin; he departed not therefrom.

2 Kings 3:4 And Mesha king of Moab was a sheepmaster, and rendered unto the king of Israel an hundred thousand lambs, and an hundred thousand rams, with the wool.

2 Kings 3:5 But it came to pass, when Ahab was dead, that the king of Moab rebelled against the king of Israel.

2 Kings 3:6 And king Jehoram went out of Samaria the same time, and numbered all Israel.

2 Kings 3:7 And he went and sent to Jehoshaphat the king of Judah, saying, The king of Moab hath rebelled against me: wilt thou go with me against Moab to battle? And he said, I will go up: I am as thou art, my people as thy people, and my horses as thy horses.

2 Kings 3:8 And he said, Which way shall we go up? And he answered, The way through the wilderness of Edom.

2 Kings 3:9 So the king of Israel went, and the king of Judah, and the king of Edom: and they fetched a compass of seven days’ journey: and there was no water for the host, and for the cattle that followed them.

2 Kings 3:10 And the king of Israel said, Alas! that the Lord hath called these three kings together, to deliver them into the hand of Moab!

2 Kings 3:11 But Jehoshaphat said, Is there not here a prophet of the Lord, that we may inquire of the Lord by him? And one of the king of Israel’s servants answered and said, Here is Elisha the son of Shaphat, which poured water on the hands of Elijah.

2 Kings 3:12 And Jehoshaphat said, The word of the Lord is with him. So the king of Israel and Jehoshaphat and the king of Edom went down to him.

2 Kings 3:13 And Elisha said unto the king of Israel, What have I to do with thee? get thee to the prophets of thy father, and to the prophets of thy mother. And the king of Israel said unto him, Nay: for the Lord hath called these three kings together, to deliver them into the hand of Moab.

2 Kings 3:14 And Elisha said, As the Lord of hosts liveth, before whom I stand, surely, were it not that I regard the presence of Jehoshaphat the king of Judah, I would not look toward thee, nor see thee.

2 Kings 3:15 But now bring me a minstrel. And it came to pass, when the minstrel played, that the hand of the Lord came upon him.

2 Kings 3:16 And he said, Thus saith the Lord, Make this valley full of ditches.

2 Kings 3:17 For thus saith the Lord, Ye shall not see wind, neither shall ye see rain; yet that valley shall be filled with water, that ye may drink, both ye, and your cattle, and your beasts.

2 Kings 3:18 And this is but a light thing in the sight of the Lord: he will deliver the Moabites also into your hand.

2 Kings 3:19 And ye shall smite every fenced city, and every choice city, and shall fell every good tree, and stop all wells of water, and mar every good piece of land with stones.

2 Kings 3:20 And it came to pass in the morning, when the meat offering was offered, that, behold, there came water by the way of Edom, and the country was filled with water.

2 Kings 3:21 And when all the Moabites heard that the kings were come up to fight against them, they gathered all that were able to put on armour, and upward, and stood in the border.

2 Kings 3:22 And they rose up early in the morning, and the sun shone upon the water, and the Moabites saw the water on the other side as red as blood:

2 Kings 3:23 And they said, This is blood: the kings are surely slain, and they have smitten one another: now therefore, Moab, to the spoil.

2 Kings 3:24 And when they came to the camp of Israel, the Israelites rose up and smote the Moabites, so that they fled before them: but they went forward smiting the Moabites, even in their country.

2 Kings 3:25 And they beat down the cities, and on every good piece of land cast every man his stone, and filled it; and they stopped all the wells of water, and felled all the good trees: only in Kir-haraseth left they the stones thereof; howbeit the slingers went about it, and smote it.

2 Kings 3:26 And when the king of Moab saw that the battle was too sore for him, he took with him seven hundred men that drew swords, to break through even unto the king of Edom: but they could not.

2 Kings 3:27 Then he took his eldest son that should have reigned in his stead, and offered him for a burnt offering upon the wall. And there was great indignation against Israel: and they departed from him, and returned to their own land.
