# Isaiah 31

Isaiah 31 (summary): Israel is reproved for turning to Egypt for help—When the Lord comes, He will defend and preserve His people.

Isaiah 31:1 Woe to them that go down to Egypt for help; and stay on horses, and trust in chariots, because they are many; and in horsemen, because they are very strong; but they look not unto the Holy One of Israel, neither seek the Lord!

Isaiah 31:2 Yet he also is wise, and will bring evil, and will not call back his words: but will arise against the house of the evildoers, and against the help of them that work iniquity.

Isaiah 31:3 Now the Egyptians are men, and not God; and their horses flesh, and not spirit. When the Lord shall stretch out his hand, both he that helpeth shall fall, and he that is holpen shall fall down, and they all shall fail together.

Isaiah 31:4 For thus hath the Lord spoken unto me, Like as the lion and the young lion roaring on his prey, when a multitude of shepherds is called forth against him, he will not be afraid of their voice, nor abase himself for the noise of them: so shall the Lord of hosts come down to fight for mount Zion, and for the hill thereof.

Isaiah 31:5 As birds flying, so will the Lord of hosts defend Jerusalem; defending also he will deliver it; and passing over he will preserve it.

Isaiah 31:6 Turn ye unto him from whom the children of Israel have deeply revolted.

Isaiah 31:7 For in that day every man shall cast away his idols of silver, and his idols of gold, which your own hands have made unto you for a sin.

Isaiah 31:8 Then shall the Assyrian fall with the sword, not of a mighty man; and the sword, not of a mean man, shall devour him: but he shall flee from the sword, and his young men shall be discomfited.

Isaiah 31:9 And he shall pass over to his strong hold for fear, and his princes shall be afraid of the ensign, saith the Lord, whose fire is in Zion, and his furnace in Jerusalem.
