# 2 Samuel 20

2 Samuel 20 (summary): Sheba leads the tribes of Israel away from David—Joab slays Amasa and pursues Sheba—A wise woman intercedes—The death of Sheba ends the insurrection.

2 Samuel 20:1 And there happened to be there a man of Belial, whose name was Sheba, the son of Bichri, a Benjamite: and he blew a trumpet, and said, We have no part in David, neither have we inheritance in the son of Jesse: every man to his tents, O Israel.

2 Samuel 20:2 So every man of Israel went up from after David, and followed Sheba the son of Bichri: but the men of Judah clave unto their king, from Jordan even to Jerusalem.

2 Samuel 20:3 And David came to his house at Jerusalem; and the king took the ten women his concubines, whom he had left to keep the house, and put them in ward, and fed them, but went not in unto them. So they were shut up unto the day of their death, living in widowhood.

2 Samuel 20:4 Then said the king to Amasa, Assemble me the men of Judah within three days, and be thou here present.

2 Samuel 20:5 So Amasa went to assemble the men of Judah: but he tarried longer than the set time which he had appointed him.

2 Samuel 20:6 And David said to Abishai, Now shall Sheba the son of Bichri do us more harm than did Absalom: take thou thy lord’s servants, and pursue after him, lest he get him fenced cities, and escape us.

2 Samuel 20:7 And there went out after him Joab’s men, and the Cherethites, and the Pelethites, and all the mighty men: and they went out of Jerusalem, to pursue after Sheba the son of Bichri.

2 Samuel 20:8 When they were at the great stone which is in Gibeon, Amasa went before them. And Joab’s garment that he had put on was girded unto him, and upon it a girdle with a sword fastened upon his loins in the sheath thereof; and as he went forth it fell out.

2 Samuel 20:9 And Joab said to Amasa, Art thou in health, my brother? And Joab took Amasa by the beard with the right hand to kiss him.

2 Samuel 20:10 But Amasa took no heed to the sword that was in Joab’s hand: so he smote him therewith in the fifth rib, and shed out his bowels to the ground, and struck him not again; and he died. So Joab and Abishai his brother pursued after Sheba the son of Bichri.

2 Samuel 20:11 And one of Joab’s men stood by him, and said, He that favoureth Joab, and he that is for David, let him go after Joab.

2 Samuel 20:12 And Amasa wallowed in blood in the midst of the highway. And when the man saw that all the people stood still, he removed Amasa out of the highway into the field, and cast a cloth upon him, when he saw that every one that came by him stood still.

2 Samuel 20:13 When he was removed out of the highway, all the people went on after Joab, to pursue after Sheba the son of Bichri.

2 Samuel 20:14 And he went through all the tribes of Israel unto Abel, and to Beth-maachah, and all the Berites: and they were gathered together, and went also after him.

2 Samuel 20:15 And they came and besieged him in Abel of Beth-maachah, and they cast up a bank against the city, and it stood in the trench: and all the people that were with Joab battered the wall, to throw it down.

2 Samuel 20:16 Then cried a wise woman out of the city, Hear, hear; say, I pray you, unto Joab, Come near hither, that I may speak with thee.

2 Samuel 20:17 And when he was come near unto her, the woman said, Art thou Joab? And he answered, I am he. Then she said unto him, Hear the words of thine handmaid. And he answered, I do hear.

2 Samuel 20:18 Then she spake, saying, They were wont to speak in old time, saying, They shall surely ask counsel at Abel: and so they ended the matter.

2 Samuel 20:19 I am one of them that are peaceable and faithful in Israel: thou seekest to destroy a city and a mother in Israel: why wilt thou swallow up the inheritance of the Lord?

2 Samuel 20:20 And Joab answered and said, Far be it, far be it from me, that I should swallow up or destroy.

2 Samuel 20:21 The matter is not so: but a man of mount Ephraim, Sheba the son of Bichri by name, hath lifted up his hand against the king, even against David: deliver him only, and I will depart from the city. And the woman said unto Joab, Behold, his head shall be thrown to thee over the wall.

2 Samuel 20:22 Then the woman went unto all the people in her wisdom. And they cut off the head of Sheba the son of Bichri, and cast it out to Joab. And he blew a trumpet, and they retired from the city, every man to his tent. And Joab returned to Jerusalem unto the king.

2 Samuel 20:23 Now Joab was over all the host of Israel: and Benaiah the son of Jehoiada was over the Cherethites and over the Pelethites:

2 Samuel 20:24 And Adoram was over the tribute: and Jehoshaphat the son of Ahilud was recorder:

2 Samuel 20:25 And Sheva was scribe: and Zadok and Abiathar were the priests:

2 Samuel 20:26 And Ira also the Jairite was a chief ruler about David.
