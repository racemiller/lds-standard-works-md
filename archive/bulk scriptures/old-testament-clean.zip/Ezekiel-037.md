# Ezekiel 37

Ezekiel 37 (summary): Ezekiel is shown the valley of dry bones—Israel will inherit the land in the Resurrection—The stick of Judah (the Bible) and the stick of Joseph (the Book of Mormon) will become one in the Lord’s hand—The children of Israel will be gathered and cleansed—David (the Messiah) will reign over them—They will receive the everlasting gospel covenant.

Ezekiel 37:1 The hand of the Lord was upon me, and carried me out in the spirit of the Lord, and set me down in the midst of the valley which was full of bones,

Ezekiel 37:2 And caused me to pass by them round about: and, behold, there were very many in the open valley; and, lo, they were very dry.

Ezekiel 37:3 And he said unto me, Son of man, can these bones live? And I answered, O Lord God, thou knowest.

Ezekiel 37:4 Again he said unto me, Prophesy upon these bones, and say unto them, O ye dry bones, hear the word of the Lord.

Ezekiel 37:5 Thus saith the Lord God unto these bones; Behold, I will cause breath to enter into you, and ye shall live:

Ezekiel 37:6 And I will lay sinews upon you, and will bring up flesh upon you, and cover you with skin, and put breath in you, and ye shall live; and ye shall know that I am the Lord.

Ezekiel 37:7 So I prophesied as I was commanded: and as I prophesied, there was a noise, and behold a shaking, and the bones came together, bone to his bone.

Ezekiel 37:8 And when I beheld, lo, the sinews and the flesh came up upon them, and the skin covered them above: but there was no breath in them.

Ezekiel 37:9 Then said he unto me, Prophesy unto the wind, prophesy, son of man, and say to the wind, Thus saith the Lord God; Come from the four winds, O breath, and breathe upon these slain, that they may live.

Ezekiel 37:10 So I prophesied as he commanded me, and the breath came into them, and they lived, and stood up upon their feet, an exceeding great army.

Ezekiel 37:11 Then he said unto me, Son of man, these bones are the whole house of Israel: behold, they say, Our bones are dried, and our hope is lost: we are cut off for our parts.

Ezekiel 37:12 Therefore prophesy and say unto them, Thus saith the Lord God; Behold, O my people, I will open your graves, and cause you to come up out of your graves, and bring you into the land of Israel.

Ezekiel 37:13 And ye shall know that I am the Lord, when I have opened your graves, O my people, and brought you up out of your graves,

Ezekiel 37:14 And shall put my spirit in you, and ye shall live, and I shall place you in your own land: then shall ye know that I the Lord have spoken it, and performed it, saith the Lord.

Ezekiel 37:15 The word of the Lord came again unto me, saying,

Ezekiel 37:16 Moreover, thou son of man, take thee one stick, and write upon it, For Judah, and for the children of Israel his companions: then take another stick, and write upon it, For Joseph, the stick of Ephraim, and for all the house of Israel his companions:

Ezekiel 37:17 And join them one to another into one stick; and they shall become one in thine hand.

Ezekiel 37:18 And when the children of thy people shall speak unto thee, saying, Wilt thou not shew us what thou meanest by these?

Ezekiel 37:19 Say unto them, Thus saith the Lord God; Behold, I will take the stick of Joseph, which is in the hand of Ephraim, and the tribes of Israel his fellows, and will put them with him, even with the stick of Judah, and make them one stick, and they shall be one in mine hand.

Ezekiel 37:20 And the sticks whereon thou writest shall be in thine hand before their eyes.

Ezekiel 37:21 And say unto them, Thus saith the Lord God; Behold, I will take the children of Israel from among the heathen, whither they be gone, and will gather them on every side, and bring them into their own land:

Ezekiel 37:22 And I will make them one nation in the land upon the mountains of Israel; and one king shall be king to them all: and they shall be no more two nations, neither shall they be divided into two kingdoms any more at all:

Ezekiel 37:23 Neither shall they defile themselves any more with their idols, nor with their detestable things, nor with any of their transgressions: but I will save them out of all their dwellingplaces, wherein they have sinned, and will cleanse them: so shall they be my people, and I will be their God.

Ezekiel 37:24 And David my servant shall be king over them; and they all shall have one shepherd: they shall also walk in my judgments, and observe my statutes, and do them.

Ezekiel 37:25 And they shall dwell in the land that I have given unto Jacob my servant, wherein your fathers have dwelt; and they shall dwell therein, even they, and their children, and their children’s children for ever: and my servant David shall be their prince for ever.

Ezekiel 37:26 Moreover I will make a covenant of peace with them; it shall be an everlasting covenant with them: and I will place them, and multiply them, and will set my sanctuary in the midst of them for evermore.

Ezekiel 37:27 My tabernacle also shall be with them: yea, I will be their God, and they shall be my people.

Ezekiel 37:28 And the heathen shall know that I the Lord do sanctify Israel, when my sanctuary shall be in the midst of them for evermore.
