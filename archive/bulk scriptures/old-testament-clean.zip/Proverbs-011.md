# Proverbs 11

Proverbs 11 (summary): The state and rewards of the righteous and the wicked are contrasted—When a wicked man dies, his expectations perish—He who wins souls is wise.

Proverbs 11:1 A false balance is abomination to the Lord: but a just weight is his delight.

Proverbs 11:2 When pride cometh, then cometh shame: but with the lowly is wisdom.

Proverbs 11:3 The integrity of the upright shall guide them: but the perverseness of transgressors shall destroy them.

Proverbs 11:4 Riches profit not in the day of wrath: but righteousness delivereth from death.

Proverbs 11:5 The righteousness of the perfect shall direct his way: but the wicked shall fall by his own wickedness.

Proverbs 11:6 The righteousness of the upright shall deliver them: but transgressors shall be taken in their own naughtiness.

Proverbs 11:7 When a wicked man dieth, his expectation shall perish: and the hope of unjust men perisheth.

Proverbs 11:8 The righteous is delivered out of trouble, and the wicked cometh in his stead.

Proverbs 11:9 An hypocrite with his mouth destroyeth his neighbour: but through knowledge shall the just be delivered.

Proverbs 11:10 When it goeth well with the righteous, the city rejoiceth: and when the wicked perish, there is shouting.

Proverbs 11:11 By the blessing of the upright the city is exalted: but it is overthrown by the mouth of the wicked.

Proverbs 11:12 He that is void of wisdom despiseth his neighbour: but a man of understanding holdeth his peace.

Proverbs 11:13 A talebearer revealeth secrets: but he that is of a faithful spirit concealeth the matter.

Proverbs 11:14 Where no counsel is, the people fall: but in the multitude of counsellors there is safety.

Proverbs 11:15 He that is surety for a stranger shall smart for it: and he that hateth suretiship is sure.

Proverbs 11:16 A gracious woman retaineth honour: and strong men retain riches.

Proverbs 11:17 The merciful man doeth good to his own soul: but he that is cruel troubleth his own flesh.

Proverbs 11:18 The wicked worketh a deceitful work: but to him that soweth righteousness shall be a sure reward.

Proverbs 11:19 As righteousness tendeth to life: so he that pursueth evil pursueth it to his own death.

Proverbs 11:20 They that are of a froward heart are abomination to the Lord: but such as are upright in their way are his delight.

Proverbs 11:21 Though hand join in hand, the wicked shall not be unpunished: but the seed of the righteous shall be delivered.

Proverbs 11:22 As a jewel of gold in a swine’s snout, so is a fair woman which is without discretion.

Proverbs 11:23 The desire of the righteous is only good: but the expectation of the wicked is wrath.

Proverbs 11:24 There is that scattereth, and yet increaseth; and there is that withholdeth more than is meet, but it tendeth to poverty.

Proverbs 11:25 The liberal soul shall be made fat: and he that watereth shall be watered also himself.

Proverbs 11:26 He that withholdeth corn, the people shall curse him: but blessing shall be upon the head of him that selleth it.

Proverbs 11:27 He that diligently seeketh good procureth favour: but he that seeketh mischief, it shall come unto him.

Proverbs 11:28 He that trusteth in his riches shall fall: but the righteous shall flourish as a branch.

Proverbs 11:29 He that troubleth his own house shall inherit the wind: and the fool shall be servant to the wise of heart.

Proverbs 11:30 The fruit of the righteous is a tree of life; and he that winneth souls is wise.

Proverbs 11:31 Behold, the righteous shall be recompensed in the earth: much more the wicked and the sinner.
