# Isaiah 28

Isaiah 28 (summary): Woe to the drunkards of Ephraim!—Revelation comes line upon line and precept upon precept—Christ, the sure foundation, is promised.

Isaiah 28:1 Woe to the crown of pride, to the drunkards of Ephraim, whose glorious beauty is a fading flower, which are on the head of the fat valleys of them that are overcome with wine!

Isaiah 28:2 Behold, the Lord hath a mighty and strong one, which as a tempest of hail and a destroying storm, as a flood of mighty waters overflowing, shall cast down to the earth with the hand.

Isaiah 28:3 The crown of pride, the drunkards of Ephraim, shall be trodden under feet:

Isaiah 28:4 And the glorious beauty, which is on the head of the fat valley, shall be a fading flower, and as the hasty fruit before the summer; which when he that looketh upon it seeth, while it is yet in his hand he eateth it up.

Isaiah 28:5 In that day shall the Lord of hosts be for a crown of glory, and for a diadem of beauty, unto the residue of his people,

Isaiah 28:6 And for a spirit of judgment to him that sitteth in judgment, and for strength to them that turn the battle to the gate.

Isaiah 28:7 But they also have erred through wine, and through strong drink are out of the way; the priest and the prophet have erred through strong drink, they are swallowed up of wine, they are out of the way through strong drink; they err in vision, they stumble in judgment.

Isaiah 28:8 For all tables are full of vomit and filthiness, so that there is no place clean.

Isaiah 28:9 Whom shall he teach knowledge? and whom shall he make to understand doctrine? them that are weaned from the milk, and drawn from the breasts.

Isaiah 28:10 For precept must be upon precept, precept upon precept; line upon line, line upon line; here a little, and there a little:

Isaiah 28:11 For with stammering lips and another tongue will he speak to this people.

Isaiah 28:12 To whom he said, This is the rest wherewith ye may cause the weary to rest; and this is the refreshing: yet they would not hear.

Isaiah 28:13 But the word of the Lord was unto them precept upon precept, precept upon precept; line upon line, line upon line; here a little, and there a little; that they might go, and fall backward, and be broken, and snared, and taken.

Isaiah 28:14 Wherefore hear the word of the Lord, ye scornful men, that rule this people which is in Jerusalem.

Isaiah 28:15 Because ye have said, We have made a covenant with death, and with hell are we at agreement; when the overflowing scourge shall pass through, it shall not come unto us: for we have made lies our refuge, and under falsehood have we hid ourselves:

Isaiah 28:16 Therefore thus saith the Lord God, Behold, I lay in Zion for a foundation a stone, a tried stone, a precious corner stone, a sure foundation: he that believeth shall not make haste.

Isaiah 28:17 Judgment also will I lay to the line, and righteousness to the plummet: and the hail shall sweep away the refuge of lies, and the waters shall overflow the hiding place.

Isaiah 28:18 And your covenant with death shall be disannulled, and your agreement with hell shall not stand; when the overflowing scourge shall pass through, then ye shall be trodden down by it.

Isaiah 28:19 From the time that it goeth forth it shall take you: for morning by morning shall it pass over, by day and by night: and it shall be a vexation only to understand the report.

Isaiah 28:20 For the bed is shorter than that a man can stretch himself on it: and the covering narrower than that he can wrap himself in it.

Isaiah 28:21 For the Lord shall rise up as in mount Perazim, he shall be wroth as in the valley of Gibeon, that he may do his work, his strange work; and bring to pass his act, his strange act.

Isaiah 28:22 Now therefore be ye not mockers, lest your bands be made strong: for I have heard from the Lord God of hosts a consumption, even determined upon the whole earth.

Isaiah 28:23 Give ye ear, and hear my voice; hearken, and hear my speech.

Isaiah 28:24 Doth the plowman plow all day to sow? doth he open and break the clods of his ground?

Isaiah 28:25 When he hath made plain the face thereof, doth he not cast abroad the fitches, and scatter the cummin, and cast in the principal wheat and the appointed barley and the rie in their place?

Isaiah 28:26 For his God doth instruct him to discretion, and doth teach him.

Isaiah 28:27 For the fitches are not threshed with a threshing instrument, neither is a cart wheel turned about upon the cummin; but the fitches are beaten out with a staff, and the cummin with a rod.

Isaiah 28:28 Bread corn is bruised; because he will not ever be threshing it, nor break it with the wheel of his cart, nor bruise it with his horsemen.

Isaiah 28:29 This also cometh forth from the Lord of hosts, which is wonderful in counsel, and excellent in working.
