# 1 Samuel 12

1 Samuel 12 (summary): Samuel testifies of his own just dealings in Israel—He reproves the people for their ingratitude—He exhorts them to keep the commandments lest the Lord consume them and their king.

1 Samuel 12:1 And Samuel said unto all Israel, Behold, I have hearkened unto your voice in all that ye said unto me, and have made a king over you.

1 Samuel 12:2 And now, behold, the king walketh before you: and I am old and grayheaded; and, behold, my sons are with you: and I have walked before you from my childhood unto this day.

1 Samuel 12:3 Behold, here I am: witness against me before the Lord, and before his anointed: whose ox have I taken? or whose ass have I taken? or whom have I defrauded? whom have I oppressed? or of whose hand have I received any bribe to blind mine eyes therewith? and I will restore it you.

1 Samuel 12:4 And they said, Thou hast not defrauded us, nor oppressed us, neither hast thou taken ought of any man’s hand.

1 Samuel 12:5 And he said unto them, The Lord is witness against you, and his anointed is witness this day, that ye have not found ought in my hand. And they answered, He is witness.

1 Samuel 12:6 And Samuel said unto the people, It is the Lord that advanced Moses and Aaron, and that brought your fathers up out of the land of Egypt.

1 Samuel 12:7 Now therefore stand still, that I may reason with you before the Lord of all the righteous acts of the Lord, which he did to you and to your fathers.

1 Samuel 12:8 When Jacob was come into Egypt, and your fathers cried unto the Lord, then the Lord sent Moses and Aaron, which brought forth your fathers out of Egypt, and made them dwell in this place.

1 Samuel 12:9 And when they forgat the Lord their God, he sold them into the hand of Sisera, captain of the host of Hazor, and into the hand of the Philistines, and into the hand of the king of Moab, and they fought against them.

1 Samuel 12:10 And they cried unto the Lord, and said, We have sinned, because we have forsaken the Lord, and have served Baalim and Ashtaroth: but now deliver us out of the hand of our enemies, and we will serve thee.

1 Samuel 12:11 And the Lord sent Jerubbaal, and Bedan, and Jephthah, and Samuel, and delivered you out of the hand of your enemies on every side, and ye dwelled safe.

1 Samuel 12:12 And when ye saw that Nahash the king of the children of Ammon came against you, ye said unto me, Nay; but a king shall reign over us: when the Lord your God was your king.

1 Samuel 12:13 Now therefore behold the king whom ye have chosen, and whom ye have desired! and, behold, the Lord hath set a king over you.

1 Samuel 12:14 If ye will fear the Lord, and serve him, and obey his voice, and not rebel against the commandment of the Lord, then shall both ye and also the king that reigneth over you continue following the Lord your God:

1 Samuel 12:15 But if ye will not obey the voice of the Lord, but rebel against the commandment of the Lord, then shall the hand of the Lord be against you, as it was against your fathers.

1 Samuel 12:16 Now therefore stand and see this great thing, which the Lord will do before your eyes.

1 Samuel 12:17 Is it not wheat harvest to day? I will call unto the Lord, and he shall send thunder and rain; that ye may perceive and see that your wickedness is great, which ye have done in the sight of the Lord, in asking you a king.

1 Samuel 12:18 So Samuel called unto the Lord; and the Lord sent thunder and rain that day: and all the people greatly feared the Lord and Samuel.

1 Samuel 12:19 And all the people said unto Samuel, Pray for thy servants unto the Lord thy God, that we die not: for we have added unto all our sins this evil, to ask us a king.

1 Samuel 12:20 And Samuel said unto the people, Fear not: ye have done all this wickedness: yet turn not aside from following the Lord, but serve the Lord with all your heart;

1 Samuel 12:21 And turn ye not aside: for then should ye go after vain things, which cannot profit nor deliver; for they are vain.

1 Samuel 12:22 For the Lord will not forsake his people for his great name’s sake: because it hath pleased the Lord to make you his people.

1 Samuel 12:23 Moreover as for me, God forbid that I should sin against the Lord in ceasing to pray for you: but I will teach you the good and the right way:

1 Samuel 12:24 Only fear the Lord, and serve him in truth with all your heart: for consider how great things he hath done for you.

1 Samuel 12:25 But if ye shall still do wickedly, ye shall be consumed, both ye and your king.
