# Micah 7

Micah 7 (summary): Though the people of Israel have rebelled, yet in the last days the Lord will have mercy on them—He will have compassion and pardon their iniquities.

Micah 7:1 Woe is me! for I am as when they have gathered the summer fruits, as the grapegleanings of the vintage: there is no cluster to eat: my soul desired the firstripe fruit.

Micah 7:2 The good man is perished out of the earth: and there is none upright among men: they all lie in wait for blood; they hunt every man his brother with a net.

Micah 7:3 That they may do evil with both hands earnestly, the prince asketh, and the judge asketh for a reward; and the great man, he uttereth his mischievous desire: so they wrap it up.

Micah 7:4 The best of them is as a brier: the most upright is sharper than a thorn hedge: the day of thy watchmen and thy visitation cometh; now shall be their perplexity.

Micah 7:5 Trust ye not in a friend, put ye not confidence in a guide: keep the doors of thy mouth from her that lieth in thy bosom.

Micah 7:6 For the son dishonoureth the father, the daughter riseth up against her mother, the daughter in law against her mother in law; a man’s enemies are the men of his own house.

Micah 7:7 Therefore I will look unto the Lord; I will wait for the God of my salvation: my God will hear me.

Micah 7:8 Rejoice not against me, O mine enemy: when I fall, I shall arise; when I sit in darkness, the Lord shall be a light unto me.

Micah 7:9 I will bear the indignation of the Lord, because I have sinned against him, until he plead my cause, and execute judgment for me: he will bring me forth to the light, and I shall behold his righteousness.

Micah 7:10 Then she that is mine enemy shall see it, and shame shall cover her which said unto me, Where is the Lord thy God? mine eyes shall behold her: now shall she be trodden down as the mire of the streets.

Micah 7:11 In the day that thy walls are to be built, in that day shall the decree be far removed.

Micah 7:12 In that day also he shall come even to thee from Assyria, and from the fortified cities, and from the fortress even to the river, and from sea to sea, and from mountain to mountain.

Micah 7:13 Notwithstanding the land shall be desolate because of them that dwell therein, for the fruit of their doings.

Micah 7:14 Feed thy people with thy rod, the flock of thine heritage, which dwell solitarily in the wood, in the midst of Carmel: let them feed in Bashan and Gilead, as in the days of old.

Micah 7:15 According to the days of thy coming out of the land of Egypt will I shew unto him marvellous things.

Micah 7:16 The nations shall see and be confounded at all their might: they shall lay their hand upon their mouth, their ears shall be deaf.

Micah 7:17 They shall lick the dust like a serpent, they shall move out of their holes like worms of the earth: they shall be afraid of the Lord our God, and shall fear because of thee.

Micah 7:18 Who is a God like unto thee, that pardoneth iniquity, and passeth by the transgression of the remnant of his heritage? he retaineth not his anger for ever, because he delighteth in mercy.

Micah 7:19 He will turn again, he will have compassion upon us; he will subdue our iniquities; and thou wilt cast all their sins into the depths of the sea.

Micah 7:20 Thou wilt perform the truth to Jacob, and the mercy to Abraham, which thou hast sworn unto our fathers from the days of old.
