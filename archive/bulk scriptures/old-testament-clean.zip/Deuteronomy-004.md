# Deuteronomy 4

Deuteronomy 4 (summary): Moses exhorts the children of Israel to keep the commandments, to teach them to their children, and to be exemplary before all nations—They are forbidden to make graven images or worship other gods—They are to witness that they have heard the voice of God—They will be scattered among all nations when they worship other gods—They will be gathered again in the latter days when they seek the Lord their God—Moses extols the mercy and goodness of God to Israel.

Deuteronomy 4:1 Now therefore hearken, O Israel, unto the statutes and unto the judgments, which I teach you, for to do them, that ye may live, and go in and possess the land which the Lord God of your fathers giveth you.

Deuteronomy 4:2 Ye shall not add unto the word which I command you, neither shall ye diminish ought from it, that ye may keep the commandments of the Lord your God which I command you.

Deuteronomy 4:3 Your eyes have seen what the Lord did because of Baal-peor: for all the men that followed Baal-peor, the Lord thy God hath destroyed them from among you.

Deuteronomy 4:4 But ye that did cleave unto the Lord your God are alive every one of you this day.

Deuteronomy 4:5 Behold, I have taught you statutes and judgments, even as the Lord my God commanded me, that ye should do so in the land whither ye go to possess it.

Deuteronomy 4:6 Keep therefore and do them; for this is your wisdom and your understanding in the sight of the nations, which shall hear all these statutes, and say, Surely this great nation is a wise and understanding people.

Deuteronomy 4:7 For what nation is there so great, who hath God so nigh unto them, as the Lord our God is in all things that we call upon him for?

Deuteronomy 4:8 And what nation is there so great, that hath statutes and judgments so righteous as all this law, which I set before you this day?

Deuteronomy 4:9 Only take heed to thyself, and keep thy soul diligently, lest thou forget the things which thine eyes have seen, and lest they depart from thy heart all the days of thy life: but teach them thy sons, and thy sons’ sons;

Deuteronomy 4:10 Specially the day that thou stoodest before the Lord thy God in Horeb, when the Lord said unto me, Gather me the people together, and I will make them hear my words, that they may learn to fear me all the days that they shall live upon the earth, and that they may teach their children.

Deuteronomy 4:11 And ye came near and stood under the mountain; and the mountain burned with fire unto the midst of heaven, with darkness, clouds, and thick darkness.

Deuteronomy 4:12 And the Lord spake unto you out of the midst of the fire: ye heard the voice of the words, but saw no similitude; only ye heard a voice.

Deuteronomy 4:13 And he declared unto you his covenant, which he commanded you to perform, even ten commandments; and he wrote them upon two tables of stone.

Deuteronomy 4:14 And the Lord commanded me at that time to teach you statutes and judgments, that ye might do them in the land whither ye go over to possess it.

Deuteronomy 4:15 Take ye therefore good heed unto yourselves; for ye saw no manner of similitude on the day that the Lord spake unto you in Horeb out of the midst of the fire:

Deuteronomy 4:16 Lest ye corrupt yourselves, and make you a graven image, the similitude of any figure, the likeness of male or female,

Deuteronomy 4:17 The likeness of any beast that is on the earth, the likeness of any winged fowl that flieth in the air,

Deuteronomy 4:18 The likeness of any thing that creepeth on the ground, the likeness of any fish that is in the waters beneath the earth:

Deuteronomy 4:19 And lest thou lift up thine eyes unto heaven, and when thou seest the sun, and the moon, and the stars, even all the host of heaven, shouldest be driven to worship them, and serve them, which the Lord thy God hath divided unto all nations under the whole heaven.

Deuteronomy 4:20 But the Lord hath taken you, and brought you forth out of the iron furnace, even out of Egypt, to be unto him a people of inheritance, as ye are this day.

Deuteronomy 4:21 Furthermore the Lord was angry with me for your sakes, and sware that I should not go over Jordan, and that I should not go in unto that good land, which the Lord thy God giveth thee for an inheritance:

Deuteronomy 4:22 But I must die in this land, I must not go over Jordan: but ye shall go over, and possess that good land.

Deuteronomy 4:23 Take heed unto yourselves, lest ye forget the covenant of the Lord your God, which he made with you, and make you a graven image, or the likeness of any thing, which the Lord thy God hath forbidden thee.

Deuteronomy 4:24 For the Lord thy God is a consuming fire, even a jealous God.

Deuteronomy 4:25 When thou shalt beget children, and children’s children, and ye shall have remained long in the land, and shall corrupt yourselves, and make a graven image, or the likeness of any thing, and shall do evil in the sight of the Lord thy God, to provoke him to anger:

Deuteronomy 4:26 I call heaven and earth to witness against you this day, that ye shall soon utterly perish from off the land whereunto ye go over Jordan to possess it; ye shall not prolong your days upon it, but shall utterly be destroyed.

Deuteronomy 4:27 And the Lord shall scatter you among the nations, and ye shall be left few in number among the heathen, whither the Lord shall lead you.

Deuteronomy 4:28 And there ye shall serve gods, the work of men’s hands, wood and stone, which neither see, nor hear, nor eat, nor smell.

Deuteronomy 4:29 But if from thence thou shalt seek the Lord thy God, thou shalt find him, if thou seek him with all thy heart and with all thy soul.

Deuteronomy 4:30 When thou art in tribulation, and all these things are come upon thee, even in the latter days, if thou turn to the Lord thy God, and shalt be obedient unto his voice;

Deuteronomy 4:31 (For the Lord thy God is a merciful God;) he will not forsake thee, neither destroy thee, nor forget the covenant of thy fathers which he sware unto them.

Deuteronomy 4:32 For ask now of the days that are past, which were before thee, since the day that God created man upon the earth, and ask from the one side of heaven unto the other, whether there hath been any such thing as this great thing is, or hath been heard like it?

Deuteronomy 4:33 Did ever people hear the voice of God speaking out of the midst of the fire, as thou hast heard, and live?

Deuteronomy 4:34 Or hath God assayed to go and take him a nation from the midst of another nation, by temptations, by signs, and by wonders, and by war, and by a mighty hand, and by a stretched out arm, and by great terrors, according to all that the Lord your God did for you in Egypt before your eyes?

Deuteronomy 4:35 Unto thee it was shewed, that thou mightest know that the Lord he is God; there is none else beside him.

Deuteronomy 4:36 Out of heaven he made thee to hear his voice, that he might instruct thee: and upon earth he shewed thee his great fire; and thou heardest his words out of the midst of the fire.

Deuteronomy 4:37 And because he loved thy fathers, therefore he chose their seed after them, and brought thee out in his sight with his mighty power out of Egypt;

Deuteronomy 4:38 To drive out nations from before thee greater and mightier than thou art, to bring thee in, to give thee their land for an inheritance, as it is this day.

Deuteronomy 4:39 Know therefore this day, and consider it in thine heart, that the Lord he is God in heaven above, and upon the earth beneath: there is none else.

Deuteronomy 4:40 Thou shalt keep therefore his statutes, and his commandments, which I command thee this day, that it may go well with thee, and with thy children after thee, and that thou mayest prolong thy days upon the earth, which the Lord thy God giveth thee, for ever.

Deuteronomy 4:41 Then Moses severed three cities on this side Jordan toward the sunrising;

Deuteronomy 4:42 That the slayer might flee thither, which should kill his neighbour unawares, and hated him not in times past; and that fleeing unto one of these cities he might live:

Deuteronomy 4:43 Namely, Bezer in the wilderness, in the plain country, of the Reubenites; and Ramoth in Gilead, of the Gadites; and Golan in Bashan, of the Manassites.

Deuteronomy 4:44 And this is the law which Moses set before the children of Israel:

Deuteronomy 4:45 These are the testimonies, and the statutes, and the judgments, which Moses spake unto the children of Israel, after they came forth out of Egypt,

Deuteronomy 4:46 On this side Jordan, in the valley over against Beth-peor, in the land of Sihon king of the Amorites, who dwelt at Heshbon, whom Moses and the children of Israel smote, after they were come forth out of Egypt:

Deuteronomy 4:47 And they possessed his land, and the land of Og king of Bashan, two kings of the Amorites, which were on this side Jordan toward the sunrising;

Deuteronomy 4:48 From Aroer, which is by the bank of the river Arnon, even unto mount Sion, which is Hermon,

Deuteronomy 4:49 And all the plain on this side Jordan eastward, even unto the sea of the plain, under the springs of Pisgah.
