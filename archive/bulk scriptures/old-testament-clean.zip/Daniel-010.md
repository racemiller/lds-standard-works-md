# Daniel 10

Daniel 10 (summary): Daniel sees the Lord and others in a glorious vision—He is shown what is to be in the latter days.

Daniel 10:1 In the third year of Cyrus king of Persia a thing was revealed unto Daniel, whose name was called Belteshazzar; and the thing was true, but the time appointed was long: and he understood the thing, and had understanding of the vision.

Daniel 10:2 In those days I Daniel was mourning three full weeks.

Daniel 10:3 I ate no pleasant bread, neither came flesh nor wine in my mouth, neither did I anoint myself at all, till three whole weeks were fulfilled.

Daniel 10:4 And in the four and twentieth day of the first month, as I was by the side of the great river, which is Hiddekel;

Daniel 10:5 Then I lifted up mine eyes, and looked, and behold a certain man clothed in linen, whose loins were girded with fine gold of Uphaz:

Daniel 10:6 His body also was like the beryl, and his face as the appearance of lightning, and his eyes as lamps of fire, and his arms and his feet like in colour to polished brass, and the voice of his words like the voice of a multitude.

Daniel 10:7 And I Daniel alone saw the vision: for the men that were with me saw not the vision; but a great quaking fell upon them, so that they fled to hide themselves.

Daniel 10:8 Therefore I was left alone, and saw this great vision, and there remained no strength in me: for my comeliness was turned in me into corruption, and I retained no strength.

Daniel 10:9 Yet heard I the voice of his words: and when I heard the voice of his words, then was I in a deep sleep on my face, and my face toward the ground.

Daniel 10:10 And, behold, an hand touched me, which set me upon my knees and upon the palms of my hands.

Daniel 10:11 And he said unto me, O Daniel, a man greatly beloved, understand the words that I speak unto thee, and stand upright: for unto thee am I now sent. And when he had spoken this word unto me, I stood trembling.

Daniel 10:12 Then said he unto me, Fear not, Daniel: for from the first day that thou didst set thine heart to understand, and to chasten thyself before thy God, thy words were heard, and I am come for thy words.

Daniel 10:13 But the prince of the kingdom of Persia withstood me one and twenty days: but, lo, Michael, one of the chief princes, came to help me; and I remained there with the kings of Persia.

Daniel 10:14 Now I am come to make thee understand what shall befall thy people in the latter days: for yet the vision is for many days.

Daniel 10:15 And when he had spoken such words unto me, I set my face toward the ground, and I became dumb.

Daniel 10:16 And, behold, one like the similitude of the sons of men touched my lips: then I opened my mouth, and spake, and said unto him that stood before me, O my lord, by the vision my sorrows are turned upon me, and I have retained no strength.

Daniel 10:17 For how can the servant of this my lord talk with this my lord? for as for me, straightway there remained no strength in me, neither is there breath left in me.

Daniel 10:18 Then there came again and touched me one like the appearance of a man, and he strengthened me,

Daniel 10:19 And said, O man greatly beloved, fear not: peace be unto thee, be strong, yea, be strong. And when he had spoken unto me, I was strengthened, and said, Let my lord speak; for thou hast strengthened me.

Daniel 10:20 Then said he, Knowest thou wherefore I come unto thee? and now will I return to fight with the prince of Persia: and when I am gone forth, lo, the prince of Grecia shall come.

Daniel 10:21 But I will shew thee that which is noted in the scripture of truth: and there is none that holdeth with me in these things, but Michael your prince.
