# Psalms 105

Psalms 105 (summary): Make the Lord’s doings known among all men—Show His covenant with Abraham and His dealings with Israel—Touch not His anointed, and do His prophets no harm—Israel is to observe His statutes and keep His laws.

Psalms 105:1 O give thanks unto the Lord; call upon his name: make known his deeds among the people.

Psalms 105:2 Sing unto him, sing psalms unto him: talk ye of all his wondrous works.

Psalms 105:3 Glory ye in his holy name: let the heart of them rejoice that seek the Lord.

Psalms 105:4 Seek the Lord, and his strength: seek his face evermore.

Psalms 105:5 Remember his marvellous works that he hath done; his wonders, and the judgments of his mouth;

Psalms 105:6 O ye seed of Abraham his servant, ye children of Jacob his chosen.

Psalms 105:7 He is the Lord our God: his judgments are in all the earth.

Psalms 105:8 He hath remembered his covenant for ever, the word which he commanded to a thousand generations.

Psalms 105:9 Which covenant he made with Abraham, and his oath unto Isaac;

Psalms 105:10 And confirmed the same unto Jacob for a law, and to Israel for an everlasting covenant:

Psalms 105:11 Saying, Unto thee will I give the land of Canaan, the lot of your inheritance:

Psalms 105:12 When they were but a few men in number; yea, very few, and strangers in it.

Psalms 105:13 When they went from one nation to another, from one kingdom to another people;

Psalms 105:14 He suffered no man to do them wrong: yea, he reproved kings for their sakes;

Psalms 105:15 Saying, Touch not mine anointed, and do my prophets no harm.

Psalms 105:16 Moreover he called for a famine upon the land: he brake the whole staff of bread.

Psalms 105:17 He sent a man before them, even Joseph, who was sold for a servant:

Psalms 105:18 Whose feet they hurt with fetters: he was laid in iron:

Psalms 105:19 Until the time that his word came: the word of the Lord tried him.

Psalms 105:20 The king sent and loosed him; even the ruler of the people, and let him go free.

Psalms 105:21 He made him lord of his house, and ruler of all his substance:

Psalms 105:22 To bind his princes at his pleasure; and teach his senators wisdom.

Psalms 105:23 Israel also came into Egypt; and Jacob sojourned in the land of Ham.

Psalms 105:24 And he increased his people greatly; and made them stronger than their enemies.

Psalms 105:25 He turned their heart to hate his people, to deal subtilly with his servants.

Psalms 105:26 He sent Moses his servant; and Aaron whom he had chosen.

Psalms 105:27 They shewed his signs among them, and wonders in the land of Ham.

Psalms 105:28 He sent darkness, and made it dark; and they rebelled not against his word.

Psalms 105:29 He turned their waters into blood, and slew their fish.

Psalms 105:30 Their land brought forth frogs in abundance, in the chambers of their kings.

Psalms 105:31 He spake, and there came divers sorts of flies, and lice in all their coasts.

Psalms 105:32 He gave them hail for rain, and flaming fire in their land.

Psalms 105:33 He smote their vines also and their fig trees; and brake the trees of their coasts.

Psalms 105:34 He spake, and the locusts came, and caterpillers, and that without number,

Psalms 105:35 And did eat up all the herbs in their land, and devoured the fruit of their ground.

Psalms 105:36 He smote also all the firstborn in their land, the chief of all their strength.

Psalms 105:37 He brought them forth also with silver and gold: and there was not one feeble person among their tribes.

Psalms 105:38 Egypt was glad when they departed: for the fear of them fell upon them.

Psalms 105:39 He spread a cloud for a covering; and fire to give light in the night.

Psalms 105:40 The people asked, and he brought quails, and satisfied them with the bread of heaven.

Psalms 105:41 He opened the rock, and the waters gushed out; they ran in the dry places like a river.

Psalms 105:42 For he remembered his holy promise, and Abraham his servant.

Psalms 105:43 And he brought forth his people with joy, and his chosen with gladness:

Psalms 105:44 And gave them the lands of the heathen: and they inherited the labour of the people;

Psalms 105:45 That they might observe his statutes, and keep his laws. Praise ye the Lord.
