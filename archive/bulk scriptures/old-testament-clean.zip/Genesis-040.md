# Genesis 40

Genesis 40 (summary): Joseph interprets the dreams of Pharaoh’s chief butler and chief baker—The butler fails to tell Pharaoh about Joseph.

Genesis 40:1 And it came to pass after these things, that the butler of the king of Egypt and his baker had offended their lord the king of Egypt.

Genesis 40:2 And Pharaoh was wroth against two of his officers, against the chief of the butlers, and against the chief of the bakers.

Genesis 40:3 And he put them in ward in the house of the captain of the guard, into the prison, the place where Joseph was bound.

Genesis 40:4 And the captain of the guard charged Joseph with them, and he served them: and they continued a season in ward.

Genesis 40:5 And they dreamed a dream both of them, each man his dream in one night, each man according to the interpretation of his dream, the butler and the baker of the king of Egypt, which were bound in the prison.

Genesis 40:6 And Joseph came in unto them in the morning, and looked upon them, and, behold, they were sad.

Genesis 40:7 And he asked Pharaoh’s officers that were with him in the ward of his lord’s house, saying, Wherefore look ye so sadly to day?

Genesis 40:8 And they said unto him, We have dreamed a dream, and there is no interpreter of it. And Joseph said unto them, Do not interpretations belong to God? tell me them, I pray you.

Genesis 40:9 And the chief butler told his dream to Joseph, and said to him, In my dream, behold, a vine was before me;

Genesis 40:10 And in the vine were three branches: and it was as though it budded, and her blossoms shot forth; and the clusters thereof brought forth ripe grapes:

Genesis 40:11 And Pharaoh’s cup was in my hand: and I took the grapes, and pressed them into Pharaoh’s cup, and I gave the cup into Pharaoh’s hand.

Genesis 40:12 And Joseph said unto him, This is the interpretation of it: The three branches are three days:

Genesis 40:13 Yet within three days shall Pharaoh lift up thine head, and restore thee unto thy place: and thou shalt deliver Pharaoh’s cup into his hand, after the former manner when thou wast his butler.

Genesis 40:14 But think on me when it shall be well with thee, and shew kindness, I pray thee, unto me, and make mention of me unto Pharaoh, and bring me out of this house:

Genesis 40:15 For indeed I was stolen away out of the land of the Hebrews: and here also have I done nothing that they should put me into the dungeon.

Genesis 40:16 When the chief baker saw that the interpretation was good, he said unto Joseph, I also was in my dream, and, behold, I had three white baskets on my head:

Genesis 40:17 And in the uppermost basket there was of all manner of bakemeats for Pharaoh; and the birds did eat them out of the basket upon my head.

Genesis 40:18 And Joseph answered and said, This is the interpretation thereof: The three baskets are three days:

Genesis 40:19 Yet within three days shall Pharaoh lift up thy head from off thee, and shall hang thee on a tree; and the birds shall eat thy flesh from off thee.

Genesis 40:20 And it came to pass the third day, which was Pharaoh’s birthday, that he made a feast unto all his servants: and he lifted up the head of the chief butler and of the chief baker among his servants.

Genesis 40:21 And he restored the chief butler unto his butlership again; and he gave the cup into Pharaoh’s hand:

Genesis 40:22 But he hanged the chief baker: as Joseph had interpreted to them.

Genesis 40:23 Yet did not the chief butler remember Joseph, but forgat him.
