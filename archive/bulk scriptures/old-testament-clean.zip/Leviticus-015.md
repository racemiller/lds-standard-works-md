# Leviticus 15

Leviticus 15 (summary): Laws, rites, and sacrifices are revealed for cleansing those who have a discharge and other types of uncleanness.

Leviticus 15:1 And the Lord spake unto Moses and to Aaron, saying,

Leviticus 15:2 Speak unto the children of Israel, and say unto them, When any man hath a running issue out of his flesh, because of his issue he is unclean.

Leviticus 15:3 And this shall be his uncleanness in his issue: whether his flesh run with his issue, or his flesh be stopped from his issue, it is his uncleanness.

Leviticus 15:4 Every bed, whereon he lieth that hath the issue, is unclean: and every thing, whereon he sitteth, shall be unclean.

Leviticus 15:5 And whosoever toucheth his bed shall wash his clothes, and bathe himself in water, and be unclean until the even.

Leviticus 15:6 And he that sitteth on any thing whereon he sat that hath the issue shall wash his clothes, and bathe himself in water, and be unclean until the even.

Leviticus 15:7 And he that toucheth the flesh of him that hath the issue shall wash his clothes, and bathe himself in water, and be unclean until the even.

Leviticus 15:8 And if he that hath the issue spit upon him that is clean; then he shall wash his clothes, and bathe himself in water, and be unclean until the even.

Leviticus 15:9 And what saddle soever he rideth upon that hath the issue shall be unclean.

Leviticus 15:10 And whosoever toucheth any thing that was under him shall be unclean until the even: and he that beareth any of those things shall wash his clothes, and bathe himself in water, and be unclean until the even.

Leviticus 15:11 And whomsoever he toucheth that hath the issue, and hath not rinsed his hands in water, he shall wash his clothes, and bathe himself in water, and be unclean until the even.

Leviticus 15:12 And the vessel of earth, that he toucheth which hath the issue, shall be broken: and every vessel of wood shall be rinsed in water.

Leviticus 15:13 And when he that hath an issue is cleansed of his issue; then he shall number to himself seven days for his cleansing, and wash his clothes, and bathe his flesh in running water, and shall be clean.

Leviticus 15:14 And on the eighth day he shall take to him two turtledoves, or two young pigeons, and come before the Lord unto the door of the tabernacle of the congregation, and give them unto the priest:

Leviticus 15:15 And the priest shall offer them, the one for a sin offering, and the other for a burnt offering; and the priest shall make an atonement for him before the Lord for his issue.

Leviticus 15:16 And if any man’s seed of copulation go out from him, then he shall wash all his flesh in water, and be unclean until the even.

Leviticus 15:17 And every garment, and every skin, whereon is the seed of copulation, shall be washed with water, and be unclean until the even.

Leviticus 15:18 The woman also with whom man shall lie with seed of copulation, they shall both bathe themselves in water, and be unclean until the even.

Leviticus 15:19 And if a woman have an issue, and her issue in her flesh be blood, she shall be put apart seven days: and whosoever toucheth her shall be unclean until the even.

Leviticus 15:20 And every thing that she lieth upon in her separation shall be unclean: every thing also that she sitteth upon shall be unclean.

Leviticus 15:21 And whosoever toucheth her bed shall wash his clothes, and bathe himself in water, and be unclean until the even.

Leviticus 15:22 And whosoever toucheth any thing that she sat upon shall wash his clothes, and bathe himself in water, and be unclean until the even.

Leviticus 15:23 And if it be on her bed, or on any thing whereon she sitteth, when he toucheth it, he shall be unclean until the even.

Leviticus 15:24 And if any man lie with her at all, and her flowers be upon him, he shall be unclean seven days; and all the bed whereon he lieth shall be unclean.

Leviticus 15:25 And if a woman have an issue of her blood many days out of the time of her separation, or if it run beyond the time of her separation; all the days of the issue of her uncleanness shall be as the days of her separation: she shall be unclean.

Leviticus 15:26 Every bed whereon she lieth all the days of her issue shall be unto her as the bed of her separation: and whatsoever she sitteth upon shall be unclean, as the uncleanness of her separation.

Leviticus 15:27 And whosoever toucheth those things shall be unclean, and shall wash his clothes, and bathe himself in water, and be unclean until the even.

Leviticus 15:28 But if she be cleansed of her issue, then she shall number to herself seven days, and after that she shall be clean.

Leviticus 15:29 And on the eighth day she shall take unto her two turtles, or two young pigeons, and bring them unto the priest, to the door of the tabernacle of the congregation.

Leviticus 15:30 And the priest shall offer the one for a sin offering, and the other for a burnt offering; and the priest shall make an atonement for her before the Lord for the issue of her uncleanness.

Leviticus 15:31 Thus shall ye separate the children of Israel from their uncleanness; that they die not in their uncleanness, when they defile my tabernacle that is among them.

Leviticus 15:32 This is the law of him that hath an issue, and of him whose seed goeth from him, and is defiled therewith;

Leviticus 15:33 And of her that is sick of her flowers, and of him that hath an issue, of the man, and of the woman, and of him that lieth with her that is unclean.
