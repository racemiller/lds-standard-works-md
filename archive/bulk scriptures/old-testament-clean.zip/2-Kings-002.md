# 2 Kings 2

2 Kings 2 (summary): Elisha and the prophets know that Elijah is to be translated—Elijah divides the waters of the Jordan and is taken up into heaven in a whirlwind—The mantle of Elijah falls on Elisha, who also divides the waters of the Jordan—Elisha heals the waters of Jericho—Youths are torn by bears for mocking Elisha.

2 Kings 2:1 And it came to pass, when the Lord would take up Elijah into heaven by a whirlwind, that Elijah went with Elisha from Gilgal.

2 Kings 2:2 And Elijah said unto Elisha, Tarry here, I pray thee; for the Lord hath sent me to Beth-el. And Elisha said unto him, As the Lord liveth, and as thy soul liveth, I will not leave thee. So they went down to Beth-el.

2 Kings 2:3 And the sons of the prophets that were at Beth-el came forth to Elisha, and said unto him, Knowest thou that the Lord will take away thy master from thy head to day? And he said, Yea, I know it; hold ye your peace.

2 Kings 2:4 And Elijah said unto him, Elisha, tarry here, I pray thee; for the Lord hath sent me to Jericho. And he said, As the Lord liveth, and as thy soul liveth, I will not leave thee. So they came to Jericho.

2 Kings 2:5 And the sons of the prophets that were at Jericho came to Elisha, and said unto him, Knowest thou that the Lord will take away thy master from thy head to day? And he answered, Yea, I know it; hold ye your peace.

2 Kings 2:6 And Elijah said unto him, Tarry, I pray thee, here; for the Lord hath sent me to Jordan. And he said, As the Lord liveth, and as thy soul liveth, I will not leave thee. And they two went on.

2 Kings 2:7 And fifty men of the sons of the prophets went, and stood to view afar off: and they two stood by Jordan.

2 Kings 2:8 And Elijah took his mantle, and wrapped it together, and smote the waters, and they were divided hither and thither, so that they two went over on dry ground.

2 Kings 2:9 And it came to pass, when they were gone over, that Elijah said unto Elisha, Ask what I shall do for thee, before I be taken away from thee. And Elisha said, I pray thee, let a double portion of thy spirit be upon me.

2 Kings 2:10 And he said, Thou hast asked a hard thing: nevertheless, if thou see me when I am taken from thee, it shall be so unto thee; but if not, it shall not be so.

2 Kings 2:11 And it came to pass, as they still went on, and talked, that, behold, there appeared a chariot of fire, and horses of fire, and parted them both asunder; and Elijah went up by a whirlwind into heaven.

2 Kings 2:12 And Elisha saw it, and he cried, My father, my father, the chariot of Israel, and the horsemen thereof. And he saw him no more: and he took hold of his own clothes, and rent them in two pieces.

2 Kings 2:13 He took up also the mantle of Elijah that fell from him, and went back, and stood by the bank of Jordan;

2 Kings 2:14 And he took the mantle of Elijah that fell from him, and smote the waters, and said, Where is the Lord God of Elijah? and when he also had smitten the waters, they parted hither and thither: and Elisha went over.

2 Kings 2:15 And when the sons of the prophets which were to view at Jericho saw him, they said, The spirit of Elijah doth rest on Elisha. And they came to meet him, and bowed themselves to the ground before him.

2 Kings 2:16 And they said unto him, Behold now, there be with thy servants fifty strong men; let them go, we pray thee, and seek thy master: lest peradventure the Spirit of the Lord hath taken him up, and cast him upon some mountain, or into some valley. And he said, Ye shall not send.

2 Kings 2:17 And when they urged him till he was ashamed, he said, Send. They sent therefore fifty men; and they sought three days, but found him not.

2 Kings 2:18 And when they came again to him, (for he tarried at Jericho,) he said unto them, Did I not say unto you, Go not?

2 Kings 2:19 And the men of the city said unto Elisha, Behold, I pray thee, the situation of this city is pleasant, as my lord seeth: but the water is naught, and the ground barren.

2 Kings 2:20 And he said, Bring me a new cruse, and put salt therein. And they brought it to him.

2 Kings 2:21 And he went forth unto the spring of the waters, and cast the salt in there, and said, Thus saith the Lord, I have healed these waters; there shall not be from thence any more death or barren land.

2 Kings 2:22 So the waters were healed unto this day, according to the saying of Elisha which he spake.

2 Kings 2:23 And he went up from thence unto Beth-el: and as he was going up by the way, there came forth little children out of the city, and mocked him, and said unto him, Go up, thou bald head; go up, thou bald head.

2 Kings 2:24 And he turned back, and looked on them, and cursed them in the name of the Lord. And there came forth two she bears out of the wood, and tare forty and two children of them.

2 Kings 2:25 And he went from thence to mount Carmel, and from thence he returned to Samaria.
