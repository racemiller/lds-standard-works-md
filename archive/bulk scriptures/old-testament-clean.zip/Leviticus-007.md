# Leviticus 7

Leviticus 7 (summary): Laws governing various sacrifices are listed—The children of Israel are forbidden to eat fat or blood—They worship by sacrifice—Through sacrifice they gain forgiveness, make vows, consecrate their property, render thanks, and are reconciled to God.

Leviticus 7:1 Likewise this is the law of the trespass offering: it is most holy.

Leviticus 7:2 In the place where they kill the burnt offering shall they kill the trespass offering: and the blood thereof shall he sprinkle round about upon the altar.

Leviticus 7:3 And he shall offer of it all the fat thereof; the rump, and the fat that covereth the inwards,

Leviticus 7:4 And the two kidneys, and the fat that is on them, which is by the flanks, and the caul that is above the liver, with the kidneys, it shall he take away:

Leviticus 7:5 And the priest shall burn them upon the altar for an offering made by fire unto the Lord: it is a trespass offering.

Leviticus 7:6 Every male among the priests shall eat thereof: it shall be eaten in the holy place: it is most holy.

Leviticus 7:7 As the sin offering is, so is the trespass offering: there is one law for them: the priest that maketh atonement therewith shall have it.

Leviticus 7:8 And the priest that offereth any man’s burnt offering, even the priest shall have to himself the skin of the burnt offering which he hath offered.

Leviticus 7:9 And all the meat offering that is baken in the oven, and all that is dressed in the fryingpan, and in the pan, shall be the priest’s that offereth it.

Leviticus 7:10 And every meat offering, mingled with oil, and dry, shall all the sons of Aaron have, one as much as another.

Leviticus 7:11 And this is the law of the sacrifice of peace offerings, which he shall offer unto the Lord.

Leviticus 7:12 If he offer it for a thanksgiving, then he shall offer with the sacrifice of thanksgiving unleavened cakes mingled with oil, and unleavened wafers anointed with oil, and cakes mingled with oil, of fine flour, fried.

Leviticus 7:13 Besides the cakes, he shall offer for his offering leavened bread with the sacrifice of thanksgiving of his peace offerings.

Leviticus 7:14 And of it he shall offer one out of the whole oblation for an heave offering unto the Lord, and it shall be the priest’s that sprinkleth the blood of the peace offerings.

Leviticus 7:15 And the flesh of the sacrifice of his peace offerings for thanksgiving shall be eaten the same day that it is offered; he shall not leave any of it until the morning.

Leviticus 7:16 But if the sacrifice of his offering be a vow, or a voluntary offering, it shall be eaten the same day that he offereth his sacrifice: and on the morrow also the remainder of it shall be eaten:

Leviticus 7:17 But the remainder of the flesh of the sacrifice on the third day shall be burnt with fire.

Leviticus 7:18 And if any of the flesh of the sacrifice of his peace offerings be eaten at all on the third day, it shall not be accepted, neither shall it be imputed unto him that offereth it: it shall be an abomination, and the soul that eateth of it shall bear his iniquity.

Leviticus 7:19 And the flesh that toucheth any unclean thing shall not be eaten; it shall be burnt with fire: and as for the flesh, all that be clean shall eat thereof.

Leviticus 7:20 But the soul that eateth of the flesh of the sacrifice of peace offerings, that pertain unto the Lord, having his uncleanness upon him, even that soul shall be cut off from his people.

Leviticus 7:21 Moreover the soul that shall touch any unclean thing, as the uncleanness of man, or any unclean beast, or any abominable unclean thing, and eat of the flesh of the sacrifice of peace offerings, which pertain unto the Lord, even that soul shall be cut off from his people.

Leviticus 7:22 And the Lord spake unto Moses, saying,

Leviticus 7:23 Speak unto the children of Israel, saying, Ye shall eat no manner of fat, of ox, or of sheep, or of goat.

Leviticus 7:24 And the fat of the beast that dieth of itself, and the fat of that which is torn with beasts, may be used in any other use: but ye shall in no wise eat of it.

Leviticus 7:25 For whosoever eateth the fat of the beast, of which men offer an offering made by fire unto the Lord, even the soul that eateth it shall be cut off from his people.

Leviticus 7:26 Moreover ye shall eat no manner of blood, whether it be of fowl or of beast, in any of your dwellings.

Leviticus 7:27 Whatsoever soul it be that eateth any manner of blood, even that soul shall be cut off from his people.

Leviticus 7:28 And the Lord spake unto Moses, saying,

Leviticus 7:29 Speak unto the children of Israel, saying, He that offereth the sacrifice of his peace offerings unto the Lord shall bring his oblation unto the Lord of the sacrifice of his peace offerings.

Leviticus 7:30 His own hands shall bring the offerings of the Lord made by fire, the fat with the breast, it shall he bring, that the breast may be waved for a wave offering before the Lord.

Leviticus 7:31 And the priest shall burn the fat upon the altar: but the breast shall be Aaron’s and his sons’.

Leviticus 7:32 And the right shoulder shall ye give unto the priest for an heave offering of the sacrifices of your peace offerings.

Leviticus 7:33 He among the sons of Aaron, that offereth the blood of the peace offerings, and the fat, shall have the right shoulder for his part.

Leviticus 7:34 For the wave breast and the heave shoulder have I taken of the children of Israel from off the sacrifices of their peace offerings, and have given them unto Aaron the priest and unto his sons by a statute for ever from among the children of Israel.

Leviticus 7:35 This is the portion of the anointing of Aaron, and of the anointing of his sons, out of the offerings of the Lord made by fire, in the day when he presented them to minister unto the Lord in the priest’s office;

Leviticus 7:36 Which the Lord commanded to be given them of the children of Israel, in the day that he anointed them, by a statute for ever throughout their generations.

Leviticus 7:37 This is the law of the burnt offering, of the meat offering, and of the sin offering, and of the trespass offering, and of the consecrations, and of the sacrifice of the peace offerings;

Leviticus 7:38 Which the Lord commanded Moses in mount Sinai, in the day that he commanded the children of Israel to offer their oblations unto the Lord, in the wilderness of Sinai.
