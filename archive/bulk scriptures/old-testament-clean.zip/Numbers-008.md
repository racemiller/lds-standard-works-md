# Numbers 8

Numbers 8 (summary): The Levites are washed, consecrated, and set apart by the laying on of hands—They are the Lord’s in place of the firstborn of every family—They are a gift to Aaron and his sons to do the service of the tabernacle.

Numbers 8:1 And the Lord spake unto Moses, saying,

Numbers 8:2 Speak unto Aaron, and say unto him, When thou lightest the lamps, the seven lamps shall give light over against the candlestick.

Numbers 8:3 And Aaron did so; he lighted the lamps thereof over against the candlestick, as the Lord commanded Moses.

Numbers 8:4 And this work of the candlestick was of beaten gold, unto the shaft thereof, unto the flowers thereof, was beaten work: according unto the pattern which the Lord had shewed Moses, so he made the candlestick.

Numbers 8:5 And the Lord spake unto Moses, saying,

Numbers 8:6 Take the Levites from among the children of Israel, and cleanse them.

Numbers 8:7 And thus shalt thou do unto them, to cleanse them: Sprinkle water of purifying upon them, and let them shave all their flesh, and let them wash their clothes, and so make themselves clean.

Numbers 8:8 Then let them take a young bullock with his meat offering, even fine flour mingled with oil, and another young bullock shalt thou take for a sin offering.

Numbers 8:9 And thou shalt bring the Levites before the tabernacle of the congregation: and thou shalt gather the whole assembly of the children of Israel together:

Numbers 8:10 And thou shalt bring the Levites before the Lord: and the children of Israel shall put their hands upon the Levites:

Numbers 8:11 And Aaron shall offer the Levites before the Lord for an offering of the children of Israel, that they may execute the service of the Lord.

Numbers 8:12 And the Levites shall lay their hands upon the heads of the bullocks: and thou shalt offer the one for a sin offering, and the other for a burnt offering, unto the Lord, to make an atonement for the Levites.

Numbers 8:13 And thou shalt set the Levites before Aaron, and before his sons, and offer them for an offering unto the Lord.

Numbers 8:14 Thus shalt thou separate the Levites from among the children of Israel: and the Levites shall be mine.

Numbers 8:15 And after that shall the Levites go in to do the service of the tabernacle of the congregation: and thou shalt cleanse them, and offer them for an offering.

Numbers 8:16 For they are wholly given unto me from among the children of Israel; instead of such as open every womb, even instead of the firstborn of all the children of Israel, have I taken them unto me.

Numbers 8:17 For all the firstborn of the children of Israel are mine, both man and beast: on the day that I smote every firstborn in the land of Egypt I sanctified them for myself.

Numbers 8:18 And I have taken the Levites for all the firstborn of the children of Israel.

Numbers 8:19 And I have given the Levites as a gift to Aaron and to his sons from among the children of Israel, to do the service of the children of Israel in the tabernacle of the congregation, and to make an atonement for the children of Israel: that there be no plague among the children of Israel, when the children of Israel come nigh unto the sanctuary.

Numbers 8:20 And Moses, and Aaron, and all the congregation of the children of Israel, did to the Levites according unto all that the Lord commanded Moses concerning the Levites, so did the children of Israel unto them.

Numbers 8:21 And the Levites were purified, and they washed their clothes; and Aaron offered them as an offering before the Lord; and Aaron made an atonement for them to cleanse them.

Numbers 8:22 And after that went the Levites in to do their service in the tabernacle of the congregation before Aaron, and before his sons: as the Lord had commanded Moses concerning the Levites, so did they unto them.

Numbers 8:23 And the Lord spake unto Moses, saying,

Numbers 8:24 This is it that belongeth unto the Levites: from twenty and five years old and upward they shall go in to wait upon the service of the tabernacle of the congregation:

Numbers 8:25 And from the age of fifty years they shall cease waiting upon the service thereof, and shall serve no more:

Numbers 8:26 But shall minister with their brethren in the tabernacle of the congregation, to keep the charge, and shall do no service. Thus shalt thou do unto the Levites touching their charge.
