# Proverbs 3

Proverbs 3 (summary): Write mercy and truth upon the tablet of your heart—Trust in the Lord—Honor Him with your substance—Whom the Lord loves He corrects—Happy is the man who finds wisdom.

Proverbs 3:1 My son, forget not my law; but let thine heart keep my commandments:

Proverbs 3:2 For length of days, and long life, and peace, shall they add to thee.

Proverbs 3:3 Let not mercy and truth forsake thee: bind them about thy neck; write them upon the table of thine heart:

Proverbs 3:4 So shalt thou find favour and good understanding in the sight of God and man.

Proverbs 3:5 Trust in the Lord with all thine heart; and lean not unto thine own understanding.

Proverbs 3:6 In all thy ways acknowledge him, and he shall direct thy paths.

Proverbs 3:7 Be not wise in thine own eyes: fear the Lord, and depart from evil.

Proverbs 3:8 It shall be health to thy navel, and marrow to thy bones.

Proverbs 3:9 Honour the Lord with thy substance, and with the firstfruits of all thine increase:

Proverbs 3:10 So shall thy barns be filled with plenty, and thy presses shall burst out with new wine.

Proverbs 3:11 My son, despise not the chastening of the Lord; neither be weary of his correction:

Proverbs 3:12 For whom the Lord loveth he correcteth; even as a father the son in whom he delighteth.

Proverbs 3:13 Happy is the man that findeth wisdom, and the man that getteth understanding.

Proverbs 3:14 For the merchandise of it is better than the merchandise of silver, and the gain thereof than fine gold.

Proverbs 3:15 She is more precious than rubies: and all the things thou canst desire are not to be compared unto her.

Proverbs 3:16 Length of days is in her right hand; and in her left hand riches and honour.

Proverbs 3:17 Her ways are ways of pleasantness, and all her paths are peace.

Proverbs 3:18 She is a tree of life to them that lay hold upon her: and happy is every one that retaineth her.

Proverbs 3:19 The Lord by wisdom hath founded the earth; by understanding hath he established the heavens.

Proverbs 3:20 By his knowledge the depths are broken up, and the clouds drop down the dew.

Proverbs 3:21 My son, let not them depart from thine eyes: keep sound wisdom and discretion:

Proverbs 3:22 So shall they be life unto thy soul, and grace to thy neck.

Proverbs 3:23 Then shalt thou walk in thy way safely, and thy foot shall not stumble.

Proverbs 3:24 When thou liest down, thou shalt not be afraid: yea, thou shalt lie down, and thy sleep shall be sweet.

Proverbs 3:25 Be not afraid of sudden fear, neither of the desolation of the wicked, when it cometh.

Proverbs 3:26 For the Lord shall be thy confidence, and shall keep thy foot from being taken.

Proverbs 3:27 Withhold not good from them to whom it is due, when it is in the power of thine hand to do it.

Proverbs 3:28 Say not unto thy neighbour, Go, and come again, and to morrow I will give; when thou hast it by thee.

Proverbs 3:29 Devise not evil against thy neighbour, seeing he dwelleth securely by thee.

Proverbs 3:30 Strive not with a man without cause, if he have done thee no harm.

Proverbs 3:31 Envy thou not the oppressor, and choose none of his ways.

Proverbs 3:32 For the froward is abomination to the Lord: but his secret is with the righteous.

Proverbs 3:33 The curse of the Lord is in the house of the wicked: but he blesseth the habitation of the just.

Proverbs 3:34 Surely he scorneth the scorners: but he giveth grace unto the lowly.

Proverbs 3:35 The wise shall inherit glory: but shame shall be the promotion of fools.
