# Exodus 17

Exodus 17 (summary): Israel murmurs for want of water—Moses smites a rock in Horeb, and water gushes forth—Aaron and Hur uphold Moses’ hands so that Joshua prevails against Amalek.

Exodus 17:1 And all the congregation of the children of Israel journeyed from the wilderness of Sin, after their journeys, according to the commandment of the Lord, and pitched in Rephidim: and there was no water for the people to drink.

Exodus 17:2 Wherefore the people did chide with Moses, and said, Give us water that we may drink. And Moses said unto them, Why chide ye with me? wherefore do ye tempt the Lord?

Exodus 17:3 And the people thirsted there for water; and the people murmured against Moses, and said, Wherefore is this that thou hast brought us up out of Egypt, to kill us and our children and our cattle with thirst?

Exodus 17:4 And Moses cried unto the Lord, saying, What shall I do unto this people? they be almost ready to stone me.

Exodus 17:5 And the Lord said unto Moses, Go on before the people, and take with thee of the elders of Israel; and thy rod, wherewith thou smotest the river, take in thine hand, and go.

Exodus 17:6 Behold, I will stand before thee there upon the rock in Horeb; and thou shalt smite the rock, and there shall come water out of it, that the people may drink. And Moses did so in the sight of the elders of Israel.

Exodus 17:7 And he called the name of the place Massah, and Meribah, because of the chiding of the children of Israel, and because they tempted the Lord, saying, Is the Lord among us, or not?

Exodus 17:8 Then came Amalek, and fought with Israel in Rephidim.

Exodus 17:9 And Moses said unto Joshua, Choose us out men, and go out, fight with Amalek: to morrow I will stand on the top of the hill with the rod of God in mine hand.

Exodus 17:10 So Joshua did as Moses had said to him, and fought with Amalek: and Moses, Aaron, and Hur went up to the top of the hill.

Exodus 17:11 And it came to pass, when Moses held up his hand, that Israel prevailed: and when he let down his hand, Amalek prevailed.

Exodus 17:12 But Moses’ hands were heavy; and they took a stone, and put it under him, and he sat thereon; and Aaron and Hur stayed up his hands, the one on the one side, and the other on the other side; and his hands were steady until the going down of the sun.

Exodus 17:13 And Joshua discomfited Amalek and his people with the edge of the sword.

Exodus 17:14 And the Lord said unto Moses, Write this for a memorial in a book, and rehearse it in the ears of Joshua: for I will utterly put out the remembrance of Amalek from under heaven.

Exodus 17:15 And Moses built an altar, and called the name of it Jehovah-nissi:

Exodus 17:16 For he said, Because the Lord hath sworn that the Lord will have war with Amalek from generation to generation.
