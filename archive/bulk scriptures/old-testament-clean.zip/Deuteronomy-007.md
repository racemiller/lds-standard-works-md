# Deuteronomy 7

Deuteronomy 7 (summary): Israel is to destroy the seven nations of Canaan—Marriages with them are forbidden lest apostasy result—Israel has a mission as a holy and chosen people—The Lord shows mercy unto those who love Him and keep His commandments—He promises to remove sickness from the children of Israel if they obey.

Deuteronomy 7:1 When the Lord thy God shall bring thee into the land whither thou goest to possess it, and hath cast out many nations before thee, the Hittites, and the Girgashites, and the Amorites, and the Canaanites, and the Perizzites, and the Hivites, and the Jebusites, seven nations greater and mightier than thou;

Deuteronomy 7:2 And when the Lord thy God shall deliver them before thee; thou shalt smite them, and utterly destroy them; thou shalt make no covenant with them, nor shew mercy unto them:

Deuteronomy 7:3 Neither shalt thou make marriages with them; thy daughter thou shalt not give unto his son, nor his daughter shalt thou take unto thy son.

Deuteronomy 7:4 For they will turn away thy son from following me, that they may serve other gods: so will the anger of the Lord be kindled against you, and destroy thee suddenly.

Deuteronomy 7:5 But thus shall ye deal with them; ye shall destroy their altars, and break down their images, and cut down their groves, and burn their graven images with fire.

Deuteronomy 7:6 For thou art an holy people unto the Lord thy God: the Lord thy God hath chosen thee to be a special people unto himself, above all people that are upon the face of the earth.

Deuteronomy 7:7 The Lord did not set his love upon you, nor choose you, because ye were more in number than any people; for ye were the fewest of all people:

Deuteronomy 7:8 But because the Lord loved you, and because he would keep the oath which he had sworn unto your fathers, hath the Lord brought you out with a mighty hand, and redeemed you out of the house of bondmen, from the hand of Pharaoh king of Egypt.

Deuteronomy 7:9 Know therefore that the Lord thy God, he is God, the faithful God, which keepeth covenant and mercy with them that love him and keep his commandments to a thousand generations;

Deuteronomy 7:10 And repayeth them that hate him to their face, to destroy them: he will not be slack to him that hateth him, he will repay him to his face.

Deuteronomy 7:11 Thou shalt therefore keep the commandments, and the statutes, and the judgments, which I command thee this day, to do them.

Deuteronomy 7:12 Wherefore it shall come to pass, if ye hearken to these judgments, and keep, and do them, that the Lord thy God shall keep unto thee the covenant and the mercy which he sware unto thy fathers:

Deuteronomy 7:13 And he will love thee, and bless thee, and multiply thee: he will also bless the fruit of thy womb, and the fruit of thy land, thy corn, and thy wine, and thine oil, the increase of thy kine, and the flocks of thy sheep, in the land which he sware unto thy fathers to give thee.

Deuteronomy 7:14 Thou shalt be blessed above all people: there shall not be male or female barren among you, or among your cattle.

Deuteronomy 7:15 And the Lord will take away from thee all sickness, and will put none of the evil diseases of Egypt, which thou knowest, upon thee; but will lay them upon all them that hate thee.

Deuteronomy 7:16 And thou shalt consume all the people which the Lord thy God shall deliver thee; thine eye shall have no pity upon them: neither shalt thou serve their gods; for that will be a snare unto thee.

Deuteronomy 7:17 If thou shalt say in thine heart, These nations are more than I; how can I dispossess them?

Deuteronomy 7:18 Thou shalt not be afraid of them: but shalt well remember what the Lord thy God did unto Pharaoh, and unto all Egypt;

Deuteronomy 7:19 The great temptations which thine eyes saw, and the signs, and the wonders, and the mighty hand, and the stretched out arm, whereby the Lord thy God brought thee out: so shall the Lord thy God do unto all the people of whom thou art afraid.

Deuteronomy 7:20 Moreover the Lord thy God will send the hornet among them, until they that are left, and hide themselves from thee, be destroyed.

Deuteronomy 7:21 Thou shalt not be affrighted at them: for the Lord thy God is among you, a mighty God and terrible.

Deuteronomy 7:22 And the Lord thy God will put out those nations before thee by little and little: thou mayest not consume them at once, lest the beasts of the field increase upon thee.

Deuteronomy 7:23 But the Lord thy God shall deliver them unto thee, and shall destroy them with a mighty destruction, until they be destroyed.

Deuteronomy 7:24 And he shall deliver their kings into thine hand, and thou shalt destroy their name from under heaven: there shall no man be able to stand before thee, until thou have destroyed them.

Deuteronomy 7:25 The graven images of their gods shall ye burn with fire: thou shalt not desire the silver or gold that is on them, nor take it unto thee, lest thou be snared therein: for it is an abomination to the Lord thy God.

Deuteronomy 7:26 Neither shalt thou bring an abomination into thine house, lest thou be a cursed thing like it: but thou shalt utterly detest it, and thou shalt utterly abhor it; for it is a cursed thing.
