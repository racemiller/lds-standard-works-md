# 2 Chronicles 7

2 Chronicles 7 (summary): Fire comes down from heaven and consumes the sacrifices and burnt offerings—The Lord appears to Solomon and promises to bless the people—The Israelites will prosper if they keep the commandments.

2 Chronicles 7:1 Now when Solomon had made an end of praying, the fire came down from heaven, and consumed the burnt offering and the sacrifices; and the glory of the Lord filled the house.

2 Chronicles 7:2 And the priests could not enter into the house of the Lord, because the glory of the Lord had filled the Lord’s house.

2 Chronicles 7:3 And when all the children of Israel saw how the fire came down, and the glory of the Lord upon the house, they bowed themselves with their faces to the ground upon the pavement, and worshipped, and praised the Lord, saying, For he is good; for his mercy endureth for ever.

2 Chronicles 7:4 Then the king and all the people offered sacrifices before the Lord.

2 Chronicles 7:5 And king Solomon offered a sacrifice of twenty and two thousand oxen, and an hundred and twenty thousand sheep: so the king and all the people dedicated the house of God.

2 Chronicles 7:6 And the priests waited on their offices: the Levites also with instruments of musick of the Lord, which David the king had made to praise the Lord, because his mercy endureth for ever, when David praised by their ministry; and the priests sounded trumpets before them, and all Israel stood.

2 Chronicles 7:7 Moreover Solomon hallowed the middle of the court that was before the house of the Lord: for there he offered burnt offerings, and the fat of the peace offerings, because the brasen altar which Solomon had made was not able to receive the burnt offerings, and the meat offerings, and the fat.

2 Chronicles 7:8 Also at the same time Solomon kept the feast seven days, and all Israel with him, a very great congregation, from the entering in of Hamath unto the river of Egypt.

2 Chronicles 7:9 And in the eighth day they made a solemn assembly: for they kept the dedication of the altar seven days, and the feast seven days.

2 Chronicles 7:10 And on the three and twentieth day of the seventh month he sent the people away into their tents, glad and merry in heart for the goodness that the Lord had shewed unto David, and to Solomon, and to Israel his people.

2 Chronicles 7:11 Thus Solomon finished the house of the Lord, and the king’s house: and all that came into Solomon’s heart to make in the house of the Lord, and in his own house, he prosperously effected.

2 Chronicles 7:12 And the Lord appeared to Solomon by night, and said unto him, I have heard thy prayer, and have chosen this place to myself for an house of sacrifice.

2 Chronicles 7:13 If I shut up heaven that there be no rain, or if I command the locusts to devour the land, or if I send pestilence among my people;

2 Chronicles 7:14 If my people, which are called by my name, shall humble themselves, and pray, and seek my face, and turn from their wicked ways; then will I hear from heaven, and will forgive their sin, and will heal their land.

2 Chronicles 7:15 Now mine eyes shall be open, and mine ears attent unto the prayer that is made in this place.

2 Chronicles 7:16 For now have I chosen and sanctified this house, that my name may be there for ever: and mine eyes and mine heart shall be there perpetually.

2 Chronicles 7:17 And as for thee, if thou wilt walk before me, as David thy father walked, and do according to all that I have commanded thee, and shalt observe my statutes and my judgments;

2 Chronicles 7:18 Then will I stablish the throne of thy kingdom, according as I have covenanted with David thy father, saying, There shall not fail thee a man to be ruler in Israel.

2 Chronicles 7:19 But if ye turn away, and forsake my statutes and my commandments, which I have set before you, and shall go and serve other gods, and worship them;

2 Chronicles 7:20 Then will I pluck them up by the roots out of my land which I have given them; and this house, which I have sanctified for my name, will I cast out of my sight, and will make it to be a proverb and a byword among all nations.

2 Chronicles 7:21 And this house, which is high, shall be an astonishment to every one that passeth by it; so that he shall say, Why hath the Lord done thus unto this land, and unto this house?

2 Chronicles 7:22 And it shall be answered, Because they forsook the Lord God of their fathers, which brought them forth out of the land of Egypt, and laid hold on other gods, and worshipped them, and served them: therefore hath he brought all this evil upon them.
