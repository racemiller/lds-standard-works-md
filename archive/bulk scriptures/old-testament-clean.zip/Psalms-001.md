# Psalms 1

Psalms 1 (summary): Blessed are the righteous—The ungodly will perish.

Psalms 1:1 Blessed is the man that walketh not in the counsel of the ungodly, nor standeth in the way of sinners, nor sitteth in the seat of the scornful.

Psalms 1:2 But his delight is in the law of the Lord; and in his law doth he meditate day and night.

Psalms 1:3 And he shall be like a tree planted by the rivers of water, that bringeth forth his fruit in his season; his leaf also shall not wither; and whatsoever he doeth shall prosper.

Psalms 1:4 The ungodly are not so: but are like the chaff which the wind driveth away.

Psalms 1:5 Therefore the ungodly shall not stand in the judgment, nor sinners in the congregation of the righteous.

Psalms 1:6 For the Lord knoweth the way of the righteous: but the way of the ungodly shall perish.
