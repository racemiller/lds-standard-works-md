# Deuteronomy 26

Deuteronomy 26 (summary): The children of Israel are to offer to the Lord a basket of the firstfruits of Canaan—They are commanded to keep the law of tithing—They covenant to keep the commandments, and the Lord promises to make them a holy people and a great nation.

Deuteronomy 26:1 And it shall be, when thou art come in unto the land which the Lord thy God giveth thee for an inheritance, and possessest it, and dwellest therein;

Deuteronomy 26:2 That thou shalt take of the first of all the fruit of the earth, which thou shalt bring of thy land that the Lord thy God giveth thee, and shalt put it in a basket, and shalt go unto the place which the Lord thy God shall choose to place his name there.

Deuteronomy 26:3 And thou shalt go unto the priest that shall be in those days, and say unto him, I profess this day unto the Lord thy God, that I am come unto the country which the Lord sware unto our fathers for to give us.

Deuteronomy 26:4 And the priest shall take the basket out of thine hand, and set it down before the altar of the Lord thy God.

Deuteronomy 26:5 And thou shalt speak and say before the Lord thy God, A Syrian ready to perish was my father, and he went down into Egypt, and sojourned there with a few, and became there a nation, great, mighty, and populous:

Deuteronomy 26:6 And the Egyptians evil entreated us, and afflicted us, and laid upon us hard bondage:

Deuteronomy 26:7 And when we cried unto the Lord God of our fathers, the Lord heard our voice, and looked on our affliction, and our labour, and our oppression:

Deuteronomy 26:8 And the Lord brought us forth out of Egypt with a mighty hand, and with an outstretched arm, and with great terribleness, and with signs, and with wonders:

Deuteronomy 26:9 And he hath brought us into this place, and hath given us this land, even a land that floweth with milk and honey.

Deuteronomy 26:10 And now, behold, I have brought the firstfruits of the land, which thou, O Lord, hast given me. And thou shalt set it before the Lord thy God, and worship before the Lord thy God:

Deuteronomy 26:11 And thou shalt rejoice in every good thing which the Lord thy God hath given unto thee, and unto thine house, thou, and the Levite, and the stranger that is among you.

Deuteronomy 26:12 When thou hast made an end of tithing all the tithes of thine increase the third year, which is the year of tithing, and hast given it unto the Levite, the stranger, the fatherless, and the widow, that they may eat within thy gates, and be filled;

Deuteronomy 26:13 Then thou shalt say before the Lord thy God, I have brought away the hallowed things out of mine house, and also have given them unto the Levite, and unto the stranger, to the fatherless, and to the widow, according to all thy commandments which thou hast commanded me: I have not transgressed thy commandments, neither have I forgotten them:

Deuteronomy 26:14 I have not eaten thereof in my mourning, neither have I taken away ought thereof for any unclean use, nor given ought thereof for the dead: but I have hearkened to the voice of the Lord my God, and have done according to all that thou hast commanded me.

Deuteronomy 26:15 Look down from thy holy habitation, from heaven, and bless thy people Israel, and the land which thou hast given us, as thou swarest unto our fathers, a land that floweth with milk and honey.

Deuteronomy 26:16 This day the Lord thy God hath commanded thee to do these statutes and judgments: thou shalt therefore keep and do them with all thine heart, and with all thy soul.

Deuteronomy 26:17 Thou hast avouched the Lord this day to be thy God, and to walk in his ways, and to keep his statutes, and his commandments, and his judgments, and to hearken unto his voice:

Deuteronomy 26:18 And the Lord hath avouched thee this day to be his peculiar people, as he hath promised thee, and that thou shouldest keep all his commandments;

Deuteronomy 26:19 And to make thee high above all nations which he hath made, in praise, and in name, and in honour; and that thou mayest be an holy people unto the Lord thy God, as he hath spoken.
