# Ezekiel 14

Ezekiel 14 (summary): The Lord will not answer those who worship false gods and work iniquity—Ezekiel preaches repentance—The people would not be saved though Noah, Daniel, and Job ministered among them.

Ezekiel 14:1 Then came certain of the elders of Israel unto me, and sat before me.

Ezekiel 14:2 And the word of the Lord came unto me, saying,

Ezekiel 14:3 Son of man, these men have set up their idols in their heart, and put the stumblingblock of their iniquity before their face: should I be inquired of at all by them?

Ezekiel 14:4 Therefore speak unto them, and say unto them, Thus saith the Lord God; Every man of the house of Israel that setteth up his idols in his heart, and putteth the stumblingblock of his iniquity before his face, and cometh to the prophet; I the Lord will answer him that cometh according to the multitude of his idols;

Ezekiel 14:5 That I may take the house of Israel in their own heart, because they are all estranged from me through their idols.

Ezekiel 14:6 Therefore say unto the house of Israel, Thus saith the Lord God; Repent, and turn yourselves from your idols; and turn away your faces from all your abominations.

Ezekiel 14:7 For every one of the house of Israel, or of the stranger that sojourneth in Israel, which separateth himself from me, and setteth up his idols in his heart, and putteth the stumblingblock of his iniquity before his face, and cometh to a prophet to inquire of him concerning me; I the Lord will answer him by myself:

Ezekiel 14:8 And I will set my face against that man, and will make him a sign and a proverb, and I will cut him off from the midst of my people; and ye shall know that I am the Lord.

Ezekiel 14:9 And if the prophet be deceived when he hath spoken a thing, I the Lord have deceived that prophet, and I will stretch out my hand upon him, and will destroy him from the midst of my people Israel.

Ezekiel 14:10 And they shall bear the punishment of their iniquity: the punishment of the prophet shall be even as the punishment of him that seeketh unto him;

Ezekiel 14:11 That the house of Israel may go no more astray from me, neither be polluted any more with all their transgressions; but that they may be my people, and I may be their God, saith the Lord God.

Ezekiel 14:12 The word of the Lord came again to me, saying,

Ezekiel 14:13 Son of man, when the land sinneth against me by trespassing grievously, then will I stretch out mine hand upon it, and will break the staff of the bread thereof, and will send famine upon it, and will cut off man and beast from it:

Ezekiel 14:14 Though these three men, Noah, Daniel, and Job, were in it, they should deliver but their own souls by their righteousness, saith the Lord God.

Ezekiel 14:15 If I cause noisome beasts to pass through the land, and they spoil it, so that it be desolate, that no man may pass through because of the beasts:

Ezekiel 14:16 Though these three men were in it, as I live, saith the Lord God, they shall deliver neither sons nor daughters; they only shall be delivered, but the land shall be desolate.

Ezekiel 14:17 Or if I bring a sword upon that land, and say, Sword, go through the land; so that I cut off man and beast from it:

Ezekiel 14:18 Though these three men were in it, as I live, saith the Lord God, they shall deliver neither sons nor daughters, but they only shall be delivered themselves.

Ezekiel 14:19 Or if I send a pestilence into that land, and pour out my fury upon it in blood, to cut off from it man and beast:

Ezekiel 14:20 Though Noah, Daniel, and Job, were in it, as I live, saith the Lord God, they shall deliver neither son nor daughter; they shall but deliver their own souls by their righteousness.

Ezekiel 14:21 For thus saith the Lord God; How much more when I send my four sore judgments upon Jerusalem, the sword, and the famine, and the noisome beast, and the pestilence, to cut off from it man and beast?

Ezekiel 14:22 Yet, behold, therein shall be left a remnant that shall be brought forth, both sons and daughters: behold, they shall come forth unto you, and ye shall see their way and their doings: and ye shall be comforted concerning the evil that I have brought upon Jerusalem, even concerning all that I have brought upon it.

Ezekiel 14:23 And they shall comfort you, when ye see their ways and their doings: and ye shall know that I have not done without cause all that I have done in it, saith the Lord God.
