# Numbers 9

Numbers 9 (summary): Israel is again commanded to keep the Passover—A cloud rests upon the tabernacle by day and by night, plus a fire by night—When the cloud rests, Israel camps; when it lifts, they journey.

Numbers 9:1 And the Lord spake unto Moses in the wilderness of Sinai, in the first month of the second year after they were come out of the land of Egypt, saying,

Numbers 9:2 Let the children of Israel also keep the passover at his appointed season.

Numbers 9:3 In the fourteenth day of this month, at even, ye shall keep it in his appointed season: according to all the rites of it, and according to all the ceremonies thereof, shall ye keep it.

Numbers 9:4 And Moses spake unto the children of Israel, that they should keep the passover.

Numbers 9:5 And they kept the passover on the fourteenth day of the first month at even in the wilderness of Sinai: according to all that the Lord commanded Moses, so did the children of Israel.

Numbers 9:6 And there were certain men, who were defiled by the dead body of a man, that they could not keep the passover on that day: and they came before Moses and before Aaron on that day:

Numbers 9:7 And those men said unto him, We are defiled by the dead body of a man: wherefore are we kept back, that we may not offer an offering of the Lord in his appointed season among the children of Israel?

Numbers 9:8 And Moses said unto them, Stand still, and I will hear what the Lord will command concerning you.

Numbers 9:9 And the Lord spake unto Moses, saying,

Numbers 9:10 Speak unto the children of Israel, saying, If any man of you or of your posterity shall be unclean by reason of a dead body, or be in a journey afar off, yet he shall keep the passover unto the Lord.

Numbers 9:11 The fourteenth day of the second month at even they shall keep it, and eat it with unleavened bread and bitter herbs.

Numbers 9:12 They shall leave none of it unto the morning, nor break any bone of it: according to all the ordinances of the passover they shall keep it.

Numbers 9:13 But the man that is clean, and is not in a journey, and forbeareth to keep the passover, even the same soul shall be cut off from among his people: because he brought not the offering of the Lord in his appointed season, that man shall bear his sin.

Numbers 9:14 And if a stranger shall sojourn among you, and will keep the passover unto the Lord; according to the ordinance of the passover, and according to the manner thereof, so shall he do: ye shall have one ordinance, both for the stranger, and for him that was born in the land.

Numbers 9:15 And on the day that the tabernacle was reared up the cloud covered the tabernacle, namely, the tent of the testimony: and at even there was upon the tabernacle as it were the appearance of fire, until the morning.

Numbers 9:16 So it was alway: the cloud covered it by day, and the appearance of fire by night.

Numbers 9:17 And when the cloud was taken up from the tabernacle, then after that the children of Israel journeyed: and in the place where the cloud abode, there the children of Israel pitched their tents.

Numbers 9:18 At the commandment of the Lord the children of Israel journeyed, and at the commandment of the Lord they pitched: as long as the cloud abode upon the tabernacle they rested in their tents.

Numbers 9:19 And when the cloud tarried long upon the tabernacle many days, then the children of Israel kept the charge of the Lord, and journeyed not.

Numbers 9:20 And so it was, when the cloud was a few days upon the tabernacle; according to the commandment of the Lord they abode in their tents, and according to the commandment of the Lord they journeyed.

Numbers 9:21 And so it was, when the cloud abode from even unto the morning, and that the cloud was taken up in the morning, then they journeyed: whether it was by day or by night that the cloud was taken up, they journeyed.

Numbers 9:22 Or whether it were two days, or a month, or a year, that the cloud tarried upon the tabernacle, remaining thereon, the children of Israel abode in their tents, and journeyed not: but when it was taken up, they journeyed.

Numbers 9:23 At the commandment of the Lord they rested in the tents, and at the commandment of the Lord they journeyed: they kept the charge of the Lord, at the commandment of the Lord by the hand of Moses.
