# Ezra 1

Ezra 1 (summary): King Cyrus of Persia lets the Jews go back to Jerusalem to build the temple—Cyrus returns the vessels of the house of the Lord taken by Nebuchadnezzar.

Ezra 1:1 Now in the first year of Cyrus king of Persia, that the word of the Lord by the mouth of Jeremiah might be fulfilled, the Lord stirred up the spirit of Cyrus king of Persia, that he made a proclamation throughout all his kingdom, and put it also in writing, saying,

Ezra 1:2 Thus saith Cyrus king of Persia, The Lord God of heaven hath given me all the kingdoms of the earth; and he hath charged me to build him an house at Jerusalem, which is in Judah.

Ezra 1:3 Who is there among you of all his people? his God be with him, and let him go up to Jerusalem, which is in Judah, and build the house of the Lord God of Israel, (he is the God,) which is in Jerusalem.

Ezra 1:4 And whosoever remaineth in any place where he sojourneth, let the men of his place help him with silver, and with gold, and with goods, and with beasts, beside the freewill offering for the house of God that is in Jerusalem.

Ezra 1:5 Then rose up the chief of the fathers of Judah and Benjamin, and the priests, and the Levites, with all them whose spirit God had raised, to go up to build the house of the Lord which is in Jerusalem.

Ezra 1:6 And all they that were about them strengthened their hands with vessels of silver, with gold, with goods, and with beasts, and with precious things, beside all that was willingly offered.

Ezra 1:7 Also Cyrus the king brought forth the vessels of the house of the Lord, which Nebuchadnezzar had brought forth out of Jerusalem, and had put them in the house of his gods;

Ezra 1:8 Even those did Cyrus king of Persia bring forth by the hand of Mithredath the treasurer, and numbered them unto Sheshbazzar, the prince of Judah.

Ezra 1:9 And this is the number of them: thirty chargers of gold, a thousand chargers of silver, nine and twenty knives,

Ezra 1:10 Thirty basins of gold, silver basins of a second sort four hundred and ten, and other vessels a thousand.

Ezra 1:11 All the vessels of gold and of silver were five thousand and four hundred. All these did Sheshbazzar bring up with them of the captivity that were brought up from Babylon unto Jerusalem.
