# Psalms 17

Psalms 17 (summary): David pleads with the Lord to hear his voice and to preserve him from men of the world—David hopes to behold the Lord’s face in righteousness.

Psalms 17:1 Hear the right, O Lord, attend unto my cry, give ear unto my prayer, that goeth not out of feigned lips.

Psalms 17:2 Let my sentence come forth from thy presence; let thine eyes behold the things that are equal.

Psalms 17:3 Thou hast proved mine heart; thou hast visited me in the night; thou hast tried me, and shalt find nothing; I am purposed that my mouth shall not transgress.

Psalms 17:4 Concerning the works of men, by the word of thy lips I have kept me from the paths of the destroyer.

Psalms 17:5 Hold up my goings in thy paths, that my footsteps slip not.

Psalms 17:6 I have called upon thee, for thou wilt hear me, O God: incline thine ear unto me, and hear my speech.

Psalms 17:7 Shew thy marvellous lovingkindness, O thou that savest by thy right hand them which put their trust in thee from those that rise up against them.

Psalms 17:8 Keep me as the apple of the eye, hide me under the shadow of thy wings,

Psalms 17:9 From the wicked that oppress me, from my deadly enemies, who compass me about.

Psalms 17:10 They are inclosed in their own fat: with their mouth they speak proudly.

Psalms 17:11 They have now compassed us in our steps: they have set their eyes bowing down to the earth;

Psalms 17:12 Like as a lion that is greedy of his prey, and as it were a young lion lurking in secret places.

Psalms 17:13 Arise, O Lord, disappoint him, cast him down: deliver my soul from the wicked, which is thy sword:

Psalms 17:14 From men which are thy hand, O Lord, from men of the world, which have their portion in this life, and whose belly thou fillest with thy hid treasure: they are full of children, and leave the rest of their substance to their babes.

Psalms 17:15 As for me, I will behold thy face in righteousness: I shall be satisfied, when I awake, with thy likeness.
