# Psalms 147

Psalms 147 (summary): Praise the Lord for His power—His understanding is infinite—He sends His commandments, His word, His statutes, and His judgments unto Israel.

Psalms 147:1 Praise ye the Lord: for it is good to sing praises unto our God; for it is pleasant; and praise is comely.

Psalms 147:2 The Lord doth build up Jerusalem: he gathereth together the outcasts of Israel.

Psalms 147:3 He healeth the broken in heart, and bindeth up their wounds.

Psalms 147:4 He telleth the number of the stars; he calleth them all by their names.

Psalms 147:5 Great is our Lord, and of great power: his understanding is infinite.

Psalms 147:6 The Lord lifteth up the meek: he casteth the wicked down to the ground.

Psalms 147:7 Sing unto the Lord with thanksgiving; sing praise upon the harp unto our God:

Psalms 147:8 Who covereth the heaven with clouds, who prepareth rain for the earth, who maketh grass to grow upon the mountains.

Psalms 147:9 He giveth to the beast his food, and to the young ravens which cry.

Psalms 147:10 He delighteth not in the strength of the horse: he taketh not pleasure in the legs of a man.

Psalms 147:11 The Lord taketh pleasure in them that fear him, in those that hope in his mercy.

Psalms 147:12 Praise the Lord, O Jerusalem; praise thy God, O Zion.

Psalms 147:13 For he hath strengthened the bars of thy gates; he hath blessed thy children within thee.

Psalms 147:14 He maketh peace in thy borders, and filleth thee with the finest of the wheat.

Psalms 147:15 He sendeth forth his commandment upon earth: his word runneth very swiftly.

Psalms 147:16 He giveth snow like wool: he scattereth the hoarfrost like ashes.

Psalms 147:17 He casteth forth his ice like morsels: who can stand before his cold?

Psalms 147:18 He sendeth out his word, and melteth them: he causeth his wind to blow, and the waters flow.

Psalms 147:19 He sheweth his word unto Jacob, his statutes and his judgments unto Israel.

Psalms 147:20 He hath not dealt so with any nation: and as for his judgments, they have not known them. Praise ye the Lord.
