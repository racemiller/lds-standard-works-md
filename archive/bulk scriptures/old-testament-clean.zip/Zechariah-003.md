# Zechariah 3

Zechariah 3 (summary): Zechariah speaks about the Messiah—The Branch will come—At the Second Coming, iniquity will be removed in one day.

Zechariah 3:1 And he shewed me Joshua the high priest standing before the angel of the Lord, and Satan standing at his right hand to resist him.

Zechariah 3:2 And the Lord said unto Satan, The Lord rebuke thee, O Satan; even the Lord that hath chosen Jerusalem rebuke thee: is not this a brand plucked out of the fire?

Zechariah 3:3 Now Joshua was clothed with filthy garments, and stood before the angel.

Zechariah 3:4 And he answered and spake unto those that stood before him, saying, Take away the filthy garments from him. And unto him he said, Behold, I have caused thine iniquity to pass from thee, and I will clothe thee with change of raiment.

Zechariah 3:5 And I said, Let them set a fair mitre upon his head. So they set a fair mitre upon his head, and clothed him with garments. And the angel of the Lord stood by.

Zechariah 3:6 And the angel of the Lord protested unto Joshua, saying,

Zechariah 3:7 Thus saith the Lord of hosts; If thou wilt walk in my ways, and if thou wilt keep my charge, then thou shalt also judge my house, and shalt also keep my courts, and I will give thee places to walk among these that stand by.

Zechariah 3:8 Hear now, O Joshua the high priest, thou, and thy fellows that sit before thee: for they are men wondered at: for, behold, I will bring forth my servant the Branch.

Zechariah 3:9 For behold the stone that I have laid before Joshua; upon one stone shall be seven eyes: behold, I will engrave the graving thereof, saith the Lord of hosts, and I will remove the iniquity of that land in one day.

Zechariah 3:10 In that day, saith the Lord of hosts, shall ye call every man his neighbour under the vine and under the fig tree.
