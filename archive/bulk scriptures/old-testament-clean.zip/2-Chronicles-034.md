# 2 Chronicles 34

2 Chronicles 34 (summary): Josiah destroys idolatry in Judah—The people of Judah repair the house of the Lord—Hilkiah finds a book of the law—Huldah the prophetess reveals the desolations to come upon the people—Josiah and the people covenant to serve the Lord.

2 Chronicles 34:1 Josiah was eight years old when he began to reign, and he reigned in Jerusalem one and thirty years.

2 Chronicles 34:2 And he did that which was right in the sight of the Lord, and walked in the ways of David his father, and declined neither to the right hand, nor to the left.

2 Chronicles 34:3 For in the eighth year of his reign, while he was yet young, he began to seek after the God of David his father: and in the twelfth year he began to purge Judah and Jerusalem from the high places, and the groves, and the carved images, and the molten images.

2 Chronicles 34:4 And they brake down the altars of Baalim in his presence; and the images, that were on high above them, he cut down; and the groves, and the carved images, and the molten images, he brake in pieces, and made dust of them, and strowed it upon the graves of them that had sacrificed unto them.

2 Chronicles 34:5 And he burnt the bones of the priests upon their altars, and cleansed Judah and Jerusalem.

2 Chronicles 34:6 And so did he in the cities of Manasseh, and Ephraim, and Simeon, even unto Naphtali, with their mattocks round about.

2 Chronicles 34:7 And when he had broken down the altars and the groves, and had beaten the graven images into powder, and cut down all the idols throughout all the land of Israel, he returned to Jerusalem.

2 Chronicles 34:8 Now in the eighteenth year of his reign, when he had purged the land, and the house, he sent Shaphan the son of Azaliah, and Maaseiah the governor of the city, and Joah the son of Joahaz the recorder, to repair the house of the Lord his God.

2 Chronicles 34:9 And when they came to Hilkiah the high priest, they delivered the money that was brought into the house of God, which the Levites that kept the doors had gathered of the hand of Manasseh and Ephraim, and of all the remnant of Israel, and of all Judah and Benjamin; and they returned to Jerusalem.

2 Chronicles 34:10 And they put it in the hand of the workmen that had the oversight of the house of the Lord, and they gave it to the workmen that wrought in the house of the Lord, to repair and amend the house:

2 Chronicles 34:11 Even to the artificers and builders gave they it, to buy hewn stone, and timber for couplings, and to floor the houses which the kings of Judah had destroyed.

2 Chronicles 34:12 And the men did the work faithfully: and the overseers of them were Jahath and Obadiah, the Levites, of the sons of Merari; and Zechariah and Meshullam, of the sons of the Kohathites, to set it forward; and other of the Levites, all that could skill of instruments of musick.

2 Chronicles 34:13 Also they were over the bearers of burdens, and were overseers of all that wrought the work in any manner of service: and of the Levites there were scribes, and officers, and porters.

2 Chronicles 34:14 And when they brought out the money that was brought into the house of the Lord, Hilkiah the priest found a book of the law of the Lord given by Moses.

2 Chronicles 34:15 And Hilkiah answered and said to Shaphan the scribe, I have found the book of the law in the house of the Lord. And Hilkiah delivered the book to Shaphan.

2 Chronicles 34:16 And Shaphan carried the book to the king, and brought the king word back again, saying, All that was committed to thy servants, they do it.

2 Chronicles 34:17 And they have gathered together the money that was found in the house of the Lord, and have delivered it into the hand of the overseers, and to the hand of the workmen.

2 Chronicles 34:18 Then Shaphan the scribe told the king, saying, Hilkiah the priest hath given me a book. And Shaphan read it before the king.

2 Chronicles 34:19 And it came to pass, when the king had heard the words of the law, that he rent his clothes.

2 Chronicles 34:20 And the king commanded Hilkiah, and Ahikam the son of Shaphan, and Abdon the son of Micah, and Shaphan the scribe, and Asaiah a servant of the king’s, saying,

2 Chronicles 34:21 Go, inquire of the Lord for me, and for them that are left in Israel and in Judah, concerning the words of the book that is found: for great is the wrath of the Lord that is poured out upon us, because our fathers have not kept the word of the Lord, to do after all that is written in this book.

2 Chronicles 34:22 And Hilkiah, and they that the king had appointed, went to Huldah the prophetess, the wife of Shallum the son of Tikvath, the son of Hasrah, keeper of the wardrobe; (now she dwelt in Jerusalem in the college:) and they spake to her to that effect.

2 Chronicles 34:23 And she answered them, Thus saith the Lord God of Israel, Tell ye the man that sent you to me,

2 Chronicles 34:24 Thus saith the Lord, Behold, I will bring evil upon this place, and upon the inhabitants thereof, even all the curses that are written in the book which they have read before the king of Judah:

2 Chronicles 34:25 Because they have forsaken me, and have burned incense unto other gods, that they might provoke me to anger with all the works of their hands; therefore my wrath shall be poured out upon this place, and shall not be quenched.

2 Chronicles 34:26 And as for the king of Judah, who sent you to inquire of the Lord, so shall ye say unto him, Thus saith the Lord God of Israel concerning the words which thou hast heard;

2 Chronicles 34:27 Because thine heart was tender, and thou didst humble thyself before God, when thou heardest his words against this place, and against the inhabitants thereof, and humbledst thyself before me, and didst rend thy clothes, and weep before me; I have even heard thee also, saith the Lord.

2 Chronicles 34:28 Behold, I will gather thee to thy fathers, and thou shalt be gathered to thy grave in peace, neither shall thine eyes see all the evil that I will bring upon this place, and upon the inhabitants of the same. So they brought the king word again.

2 Chronicles 34:29 Then the king sent and gathered together all the elders of Judah and Jerusalem.

2 Chronicles 34:30 And the king went up into the house of the Lord, and all the men of Judah, and the inhabitants of Jerusalem, and the priests, and the Levites, and all the people, great and small: and he read in their ears all the words of the book of the covenant that was found in the house of the Lord.

2 Chronicles 34:31 And the king stood in his place, and made a covenant before the Lord, to walk after the Lord, and to keep his commandments, and his testimonies, and his statutes, with all his heart, and with all his soul, to perform the words of the covenant which are written in this book.

2 Chronicles 34:32 And he caused all that were present in Jerusalem and Benjamin to stand to it. And the inhabitants of Jerusalem did according to the covenant of God, the God of their fathers.

2 Chronicles 34:33 And Josiah took away all the abominations out of all the countries that pertained to the children of Israel, and made all that were present in Israel to serve, even to serve the Lord their God. And all his days they departed not from following the Lord, the God of their fathers.
