# Psalms 85

Psalms 85 (summary): The Lord speaks peace to His people—Truth will spring out of the earth (the Book of Mormon), and righteousness will look down from heaven.

Psalms 85:1 Lord, thou hast been favourable unto thy land: thou hast brought back the captivity of Jacob.

Psalms 85:2 Thou hast forgiven the iniquity of thy people, thou hast covered all their sin. Selah.

Psalms 85:3 Thou hast taken away all thy wrath: thou hast turned thyself from the fierceness of thine anger.

Psalms 85:4 Turn us, O God of our salvation, and cause thine anger toward us to cease.

Psalms 85:5 Wilt thou be angry with us for ever? wilt thou draw out thine anger to all generations?

Psalms 85:6 Wilt thou not revive us again: that thy people may rejoice in thee?

Psalms 85:7 Shew us thy mercy, O Lord, and grant us thy salvation.

Psalms 85:8 I will hear what God the Lord will speak: for he will speak peace unto his people, and to his saints: but let them not turn again to folly.

Psalms 85:9 Surely his salvation is nigh them that fear him; that glory may dwell in our land.

Psalms 85:10 Mercy and truth are met together; righteousness and peace have kissed each other.

Psalms 85:11 Truth shall spring out of the earth; and righteousness shall look down from heaven.

Psalms 85:12 Yea, the Lord shall give that which is good; and our land shall yield her increase.

Psalms 85:13 Righteousness shall go before him; and shall set us in the way of his steps.
