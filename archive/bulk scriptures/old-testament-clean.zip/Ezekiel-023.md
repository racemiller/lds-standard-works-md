# Ezekiel 23

Ezekiel 23 (summary): Two sisters, Samaria and Jerusalem, committed whoredoms by worshipping idols—Both are destroyed for their lewdness.

Ezekiel 23:1 The word of the Lord came again unto me, saying,

Ezekiel 23:2 Son of man, there were two women, the daughters of one mother:

Ezekiel 23:3 And they committed whoredoms in Egypt; they committed whoredoms in their youth: there were their breasts pressed, and there they bruised the teats of their virginity.

Ezekiel 23:4 And the names of them were Aholah the elder, and Aholibah her sister: and they were mine, and they bare sons and daughters. Thus were their names; Samaria is Aholah, and Jerusalem Aholibah.

Ezekiel 23:5 And Aholah played the harlot when she was mine; and she doted on her lovers, on the Assyrians her neighbours,

Ezekiel 23:6 Which were clothed with blue, captains and rulers, all of them desirable young men, horsemen riding upon horses.

Ezekiel 23:7 Thus she committed her whoredoms with them, with all them that were the chosen men of Assyria, and with all on whom she doted: with all their idols she defiled herself.

Ezekiel 23:8 Neither left she her whoredoms brought from Egypt: for in her youth they lay with her, and they bruised the breasts of her virginity, and poured their whoredom upon her.

Ezekiel 23:9 Wherefore I have delivered her into the hand of her lovers, into the hand of the Assyrians, upon whom she doted.

Ezekiel 23:10 These discovered her nakedness: they took her sons and her daughters, and slew her with the sword: and she became famous among women; for they had executed judgment upon her.

Ezekiel 23:11 And when her sister Aholibah saw this, she was more corrupt in her inordinate love than she, and in her whoredoms more than her sister in her whoredoms.

Ezekiel 23:12 She doted upon the Assyrians her neighbours, captains and rulers clothed most gorgeously, horsemen riding upon horses, all of them desirable young men.

Ezekiel 23:13 Then I saw that she was defiled, that they took both one way,

Ezekiel 23:14 And that she increased her whoredoms: for when she saw men portrayed upon the wall, the images of the Chaldeans portrayed with vermilion,

Ezekiel 23:15 Girded with girdles upon their loins, exceeding in dyed attire upon their heads, all of them princes to look to, after the manner of the Babylonians of Chaldea, the land of their nativity:

Ezekiel 23:16 And as soon as she saw them with her eyes, she doted upon them, and sent messengers unto them into Chaldea.

Ezekiel 23:17 And the Babylonians came to her into the bed of love, and they defiled her with their whoredom, and she was polluted with them, and her mind was alienated from them.

Ezekiel 23:18 So she discovered her whoredoms, and discovered her nakedness: then my mind was alienated from her, like as my mind was alienated from her sister.

Ezekiel 23:19 Yet she multiplied her whoredoms, in calling to remembrance the days of her youth, wherein she had played the harlot in the land of Egypt.

Ezekiel 23:20 For she doted upon their paramours, whose flesh is as the flesh of asses, and whose issue is like the issue of horses.

Ezekiel 23:21 Thus thou calledst to remembrance the lewdness of thy youth, in bruising thy teats by the Egyptians for the paps of thy youth.

Ezekiel 23:22 Therefore, O Aholibah, thus saith the Lord God; Behold, I will raise up thy lovers against thee, from whom thy mind is alienated, and I will bring them against thee on every side;

Ezekiel 23:23 The Babylonians, and all the Chaldeans, Pekod, and Shoa, and Koa, and all the Assyrians with them: all of them desirable young men, captains and rulers, great lords and renowned, all of them riding upon horses.

Ezekiel 23:24 And they shall come against thee with chariots, wagons, and wheels, and with an assembly of people, which shall set against thee buckler and shield and helmet round about: and I will set judgment before them, and they shall judge thee according to their judgments.

Ezekiel 23:25 And I will set my jealousy against thee, and they shall deal furiously with thee: they shall take away thy nose and thine ears; and thy remnant shall fall by the sword: they shall take thy sons and thy daughters; and thy residue shall be devoured by the fire.

Ezekiel 23:26 They shall also strip thee out of thy clothes, and take away thy fair jewels.

Ezekiel 23:27 Thus will I make thy lewdness to cease from thee, and thy whoredom brought from the land of Egypt: so that thou shalt not lift up thine eyes unto them, nor remember Egypt any more.

Ezekiel 23:28 For thus saith the Lord God; Behold, I will deliver thee into the hand of them whom thou hatest, into the hand of them from whom thy mind is alienated:

Ezekiel 23:29 And they shall deal with thee hatefully, and shall take away all thy labour, and shall leave thee naked and bare: and the nakedness of thy whoredoms shall be discovered, both thy lewdness and thy whoredoms.

Ezekiel 23:30 I will do these things unto thee, because thou hast gone a whoring after the heathen, and because thou art polluted with their idols.

Ezekiel 23:31 Thou hast walked in the way of thy sister; therefore will I give her cup into thine hand.

Ezekiel 23:32 Thus saith the Lord God; Thou shalt drink of thy sister’s cup deep and large: thou shalt be laughed to scorn and had in derision; it containeth much.

Ezekiel 23:33 Thou shalt be filled with drunkenness and sorrow, with the cup of astonishment and desolation, with the cup of thy sister Samaria.

Ezekiel 23:34 Thou shalt even drink it and suck it out, and thou shalt break the sherds thereof, and pluck off thine own breasts: for I have spoken it, saith the Lord God.

Ezekiel 23:35 Therefore thus saith the Lord God; Because thou hast forgotten me, and cast me behind thy back, therefore bear thou also thy lewdness and thy whoredoms.

Ezekiel 23:36 The Lord said moreover unto me; Son of man, wilt thou judge Aholah and Aholibah? yea, declare unto them their abominations;

Ezekiel 23:37 That they have committed adultery, and blood is in their hands, and with their idols have they committed adultery, and have also caused their sons, whom they bare unto me, to pass for them through the fire, to devour them.

Ezekiel 23:38 Moreover this they have done unto me: they have defiled my sanctuary in the same day, and have profaned my sabbaths.

Ezekiel 23:39 For when they had slain their children to their idols, then they came the same day into my sanctuary to profane it; and, lo, thus have they done in the midst of mine house.

Ezekiel 23:40 And furthermore, that ye have sent for men to come from far, unto whom a messenger was sent; and, lo, they came: for whom thou didst wash thyself, paintedst thy eyes, and deckedst thyself with ornaments,

Ezekiel 23:41 And satest upon a stately bed, and a table prepared before it, whereupon thou hast set mine incense and mine oil.

Ezekiel 23:42 And a voice of a multitude being at ease was with her: and with the men of the common sort were brought Sabeans from the wilderness, which put bracelets upon their hands, and beautiful crowns upon their heads.

Ezekiel 23:43 Then said I unto her that was old in adulteries, Will they now commit whoredoms with her, and she with them?

Ezekiel 23:44 Yet they went in unto her, as they go in unto a woman that playeth the harlot: so went they in unto Aholah and unto Aholibah, the lewd women.

Ezekiel 23:45 And the righteous men, they shall judge them after the manner of adulteresses, and after the manner of women that shed blood; because they are adulteresses, and blood is in their hands.

Ezekiel 23:46 For thus saith the Lord God; I will bring up a company upon them, and will give them to be removed and spoiled.

Ezekiel 23:47 And the company shall stone them with stones, and dispatch them with their swords; they shall slay their sons and their daughters, and burn up their houses with fire.

Ezekiel 23:48 Thus will I cause lewdness to cease out of the land, that all women may be taught not to do after your lewdness.

Ezekiel 23:49 And they shall recompense your lewdness upon you, and ye shall bear the sins of your idols: and ye shall know that I am the Lord God.
