# 1 Chronicles 15

1 Chronicles 15 (summary): David prepares a place for the ark—The Levites bring the ark to Jerusalem—They sing and minister before the Lord.

1 Chronicles 15:1 And David made him houses in the city of David, and prepared a place for the ark of God, and pitched for it a tent.

1 Chronicles 15:2 Then David said, None ought to carry the ark of God but the Levites: for them hath the Lord chosen to carry the ark of God, and to minister unto him for ever.

1 Chronicles 15:3 And David gathered all Israel together to Jerusalem, to bring up the ark of the Lord unto his place, which he had prepared for it.

1 Chronicles 15:4 And David assembled the children of Aaron, and the Levites:

1 Chronicles 15:5 Of the sons of Kohath; Uriel the chief, and his brethren an hundred and twenty:

1 Chronicles 15:6 Of the sons of Merari; Asaiah the chief, and his brethren two hundred and twenty:

1 Chronicles 15:7 Of the sons of Gershom; Joel the chief, and his brethren an hundred and thirty:

1 Chronicles 15:8 Of the sons of Elizaphan; Shemaiah the chief, and his brethren two hundred:

1 Chronicles 15:9 Of the sons of Hebron; Eliel the chief, and his brethren fourscore:

1 Chronicles 15:10 Of the sons of Uzziel; Amminadab the chief, and his brethren an hundred and twelve.

1 Chronicles 15:11 And David called for Zadok and Abiathar the priests, and for the Levites, for Uriel, Asaiah, and Joel, Shemaiah, and Eliel, and Amminadab,

1 Chronicles 15:12 And said unto them, Ye are the chief of the fathers of the Levites: sanctify yourselves, both ye and your brethren, that ye may bring up the ark of the Lord God of Israel unto the place that I have prepared for it.

1 Chronicles 15:13 For because ye did it not at the first, the Lord our God made a breach upon us, for that we sought him not after the due order.

1 Chronicles 15:14 So the priests and the Levites sanctified themselves to bring up the ark of the Lord God of Israel.

1 Chronicles 15:15 And the children of the Levites bare the ark of God upon their shoulders with the staves thereon, as Moses commanded according to the word of the Lord.

1 Chronicles 15:16 And David spake to the chief of the Levites to appoint their brethren to be the singers with instruments of musick, psalteries and harps and cymbals, sounding, by lifting up the voice with joy.

1 Chronicles 15:17 So the Levites appointed Heman the son of Joel; and of his brethren, Asaph the son of Berechiah; and of the sons of Merari their brethren, Ethan the son of Kushaiah;

1 Chronicles 15:18 And with them their brethren of the second degree, Zechariah, Ben, and Jaaziel, and Shemiramoth, and Jehiel, and Unni, Eliab, and Benaiah, and Maaseiah, and Mattithiah, and Elipheleh, and Mikneiah, and Obed-edom, and Jeiel, the porters.

1 Chronicles 15:19 So the singers, Heman, Asaph, and Ethan, were appointed to sound with cymbals of brass;

1 Chronicles 15:20 And Zechariah, and Aziel, and Shemiramoth, and Jehiel, and Unni, and Eliab, and Maaseiah, and Benaiah, with psalteries on Alamoth;

1 Chronicles 15:21 And Mattithiah, and Elipheleh, and Mikneiah, and Obed-edom, and Jeiel, and Azaziah, with harps on the Sheminith to excel.

1 Chronicles 15:22 And Chenaniah, chief of the Levites, was for song: he instructed about the song, because he was skilful.

1 Chronicles 15:23 And Berechiah and Elkanah were doorkeepers for the ark.

1 Chronicles 15:24 And Shebaniah, and Jehoshaphat, and Nethaneel, and Amasai, and Zechariah, and Benaiah, and Eliezer, the priests, did blow with the trumpets before the ark of God: and Obed-edom and Jehiah were doorkeepers for the ark.

1 Chronicles 15:25 So David, and the elders of Israel, and the captains over thousands, went to bring up the ark of the covenant of the Lord out of the house of Obed-edom with joy.

1 Chronicles 15:26 And it came to pass, when God helped the Levites that bare the ark of the covenant of the Lord, that they offered seven bullocks and seven rams.

1 Chronicles 15:27 And David was clothed with a robe of fine linen, and all the Levites that bare the ark, and the singers, and Chenaniah the master of the song with the singers: David also had upon him an ephod of linen.

1 Chronicles 15:28 Thus all Israel brought up the ark of the covenant of the Lord with shouting, and with sound of the cornet, and with trumpets, and with cymbals, making a noise with psalteries and harps.

1 Chronicles 15:29 And it came to pass, as the ark of the covenant of the Lord came to the city of David, that Michal the daughter of Saul looking out at a window saw king David dancing and playing: and she despised him in her heart.
