# Genesis 48

Genesis 48 (summary): Jacob tells of the appearance of God to him in Luz—He adopts Ephraim and Manasseh as his own children—Jacob blesses Joseph—He puts Ephraim before Manasseh—The seed of Ephraim will become a multitude of nations—The children of Israel will come again into the land of their fathers.

Genesis 48:1 And it came to pass after these things, that one told Joseph, Behold, thy father is sick: and he took with him his two sons, Manasseh and Ephraim.

Genesis 48:2 And one told Jacob, and said, Behold, thy son Joseph cometh unto thee: and Israel strengthened himself, and sat upon the bed.

Genesis 48:3 And Jacob said unto Joseph, God Almighty appeared unto me at Luz in the land of Canaan, and blessed me,

Genesis 48:4 And said unto me, Behold, I will make thee fruitful, and multiply thee, and I will make of thee a multitude of people; and will give this land to thy seed after thee for an everlasting possession.

Genesis 48:5 And now thy two sons, Ephraim and Manasseh, which were born unto thee in the land of Egypt before I came unto thee into Egypt, are mine; as Reuben and Simeon, they shall be mine.

Genesis 48:6 And thy issue, which thou begettest after them, shall be thine, and shall be called after the name of their brethren in their inheritance.

Genesis 48:7 And as for me, when I came from Padan, Rachel died by me in the land of Canaan in the way, when yet there was but a little way to come unto Ephrath: and I buried her there in the way of Ephrath; the same is Beth-lehem.

Genesis 48:8 And Israel beheld Joseph’s sons, and said, Who are these?

Genesis 48:9 And Joseph said unto his father, They are my sons, whom God hath given me in this place. And he said, Bring them, I pray thee, unto me, and I will bless them.

Genesis 48:10 Now the eyes of Israel were dim for age, so that he could not see. And he brought them near unto him; and he kissed them, and embraced them.

Genesis 48:11 And Israel said unto Joseph, I had not thought to see thy face: and, lo, God hath shewed me also thy seed.

Genesis 48:12 And Joseph brought them out from between his knees, and he bowed himself with his face to the earth.

Genesis 48:13 And Joseph took them both, Ephraim in his right hand toward Israel’s left hand, and Manasseh in his left hand toward Israel’s right hand, and brought them near unto him.

Genesis 48:14 And Israel stretched out his right hand, and laid it upon Ephraim’s head, who was the younger, and his left hand upon Manasseh’s head, guiding his hands wittingly; for Manasseh was the firstborn.

Genesis 48:15 And he blessed Joseph, and said, God, before whom my fathers Abraham and Isaac did walk, the God which fed me all my life long unto this day,

Genesis 48:16 The Angel which redeemed me from all evil, bless the lads; and let my name be named on them, and the name of my fathers Abraham and Isaac; and let them grow into a multitude in the midst of the earth.

Genesis 48:17 And when Joseph saw that his father laid his right hand upon the head of Ephraim, it displeased him: and he held up his father’s hand, to remove it from Ephraim’s head unto Manasseh’s head.

Genesis 48:18 And Joseph said unto his father, Not so, my father: for this is the firstborn; put thy right hand upon his head.

Genesis 48:19 And his father refused, and said, I know it, my son, I know it: he also shall become a people, and he also shall be great: but truly his younger brother shall be greater than he, and his seed shall become a multitude of nations.

Genesis 48:20 And he blessed them that day, saying, In thee shall Israel bless, saying, God make thee as Ephraim and as Manasseh: and he set Ephraim before Manasseh.

Genesis 48:21 And Israel said unto Joseph, Behold, I die: but God shall be with you, and bring you again unto the land of your fathers.

Genesis 48:22 Moreover I have given to thee one portion above thy brethren, which I took out of the hand of the Amorite with my sword and with my bow.
