# Psalms 102

Psalms 102 (summary): The psalmist offers a prayer of the afflicted—Zion will be built up when the Lord appears in His glory—Though the heaven and earth perish, the Lord who created them will endure forever.

Psalms 102:1 Hear my prayer, O Lord, and let my cry come unto thee.

Psalms 102:2 Hide not thy face from me in the day when I am in trouble; incline thine ear unto me: in the day when I call answer me speedily.

Psalms 102:3 For my days are consumed like smoke, and my bones are burned as an hearth.

Psalms 102:4 My heart is smitten, and withered like grass; so that I forget to eat my bread.

Psalms 102:5 By reason of the voice of my groaning my bones cleave to my skin.

Psalms 102:6 I am like a pelican of the wilderness: I am like an owl of the desert.

Psalms 102:7 I watch, and am as a sparrow alone upon the house top.

Psalms 102:8 Mine enemies reproach me all the day; and they that are mad against me are sworn against me.

Psalms 102:9 For I have eaten ashes like bread, and mingled my drink with weeping,

Psalms 102:10 Because of thine indignation and thy wrath: for thou hast lifted me up, and cast me down.

Psalms 102:11 My days are like a shadow that declineth; and I am withered like grass.

Psalms 102:12 But thou, O Lord, shalt endure for ever; and thy remembrance unto all generations.

Psalms 102:13 Thou shalt arise, and have mercy upon Zion: for the time to favour her, yea, the set time, is come.

Psalms 102:14 For thy servants take pleasure in her stones, and favour the dust thereof.

Psalms 102:15 So the heathen shall fear the name of the Lord, and all the kings of the earth thy glory.

Psalms 102:16 When the Lord shall build up Zion, he shall appear in his glory.

Psalms 102:17 He will regard the prayer of the destitute, and not despise their prayer.

Psalms 102:18 This shall be written for the generation to come: and the people which shall be created shall praise the Lord.

Psalms 102:19 For he hath looked down from the height of his sanctuary; from heaven did the Lord behold the earth;

Psalms 102:20 To hear the groaning of the prisoner; to loose those that are appointed to death;

Psalms 102:21 To declare the name of the Lord in Zion, and his praise in Jerusalem;

Psalms 102:22 When the people are gathered together, and the kingdoms, to serve the Lord.

Psalms 102:23 He weakened my strength in the way; he shortened my days.

Psalms 102:24 I said, O my God, take me not away in the midst of my days: thy years are throughout all generations.

Psalms 102:25 Of old hast thou laid the foundation of the earth: and the heavens are the work of thy hands.

Psalms 102:26 They shall perish, but thou shalt endure: yea, all of them shall wax old like a garment; as a vesture shalt thou change them, and they shall be changed:

Psalms 102:27 But thou art the same, and thy years shall have no end.

Psalms 102:28 The children of thy servants shall continue, and their seed shall be established before thee.
