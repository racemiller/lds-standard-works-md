# Ecclesiastes 9

Ecclesiastes 9 (summary): God’s providence rules over all—All men are subject to time and chance—Wisdom is better than strength—One sinner destroys much good.

Ecclesiastes 9:1 For all this I considered in my heart even to declare all this, that the righteous, and the wise, and their works, are in the hand of God: no man knoweth either love or hatred by all that is before them.

Ecclesiastes 9:2 All things come alike to all: there is one event to the righteous, and to the wicked; to the good and to the clean, and to the unclean; to him that sacrificeth, and to him that sacrificeth not: as is the good, so is the sinner; and he that sweareth, as he that feareth an oath.

Ecclesiastes 9:3 This is an evil among all things that are done under the sun, that there is one event unto all: yea, also the heart of the sons of men is full of evil, and madness is in their heart while they live, and after that they go to the dead.

Ecclesiastes 9:4 For to him that is joined to all the living there is hope: for a living dog is better than a dead lion.

Ecclesiastes 9:5 For the living know that they shall die: but the dead know not any thing, neither have they any more a reward; for the memory of them is forgotten.

Ecclesiastes 9:6 Also their love, and their hatred, and their envy, is now perished; neither have they any more a portion for ever in any thing that is done under the sun.

Ecclesiastes 9:7 Go thy way, eat thy bread with joy, and drink thy wine with a merry heart; for God now accepteth thy works.

Ecclesiastes 9:8 Let thy garments be always white; and let thy head lack no ointment.

Ecclesiastes 9:9 Live joyfully with the wife whom thou lovest all the days of the life of thy vanity, which he hath given thee under the sun, all the days of thy vanity: for that is thy portion in this life, and in thy labour which thou takest under the sun.

Ecclesiastes 9:10 Whatsoever thy hand findeth to do, do it with thy might; for there is no work, nor device, nor knowledge, nor wisdom, in the grave, whither thou goest.

Ecclesiastes 9:11 I returned, and saw under the sun, that the race is not to the swift, nor the battle to the strong, neither yet bread to the wise, nor yet riches to men of understanding, nor yet favour to men of skill; but time and chance happeneth to them all.

Ecclesiastes 9:12 For man also knoweth not his time: as the fishes that are taken in an evil net, and as the birds that are caught in the snare; so are the sons of men snared in an evil time, when it falleth suddenly upon them.

Ecclesiastes 9:13 This wisdom have I seen also under the sun, and it seemed great unto me:

Ecclesiastes 9:14 There was a little city, and few men within it; and there came a great king against it, and besieged it, and built great bulwarks against it:

Ecclesiastes 9:15 Now there was found in it a poor wise man, and he by his wisdom delivered the city; yet no man remembered that same poor man.

Ecclesiastes 9:16 Then said I, Wisdom is better than strength: nevertheless the poor man’s wisdom is despised, and his words are not heard.

Ecclesiastes 9:17 The words of wise men are heard in quiet more than the cry of him that ruleth among fools.

Ecclesiastes 9:18 Wisdom is better than weapons of war: but one sinner destroyeth much good.
