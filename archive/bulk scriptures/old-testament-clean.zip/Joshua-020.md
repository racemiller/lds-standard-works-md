# Joshua 20

Joshua 20 (summary): Six cities of refuge are appointed for those guilty of manslaughter.

Joshua 20:1 The Lord also spake unto Joshua, saying,

Joshua 20:2 Speak to the children of Israel, saying, Appoint out for you cities of refuge, whereof I spake unto you by the hand of Moses:

Joshua 20:3 That the slayer that killeth any person unawares and unwittingly may flee thither: and they shall be your refuge from the avenger of blood.

Joshua 20:4 And when he that doth flee unto one of those cities shall stand at the entering of the gate of the city, and shall declare his cause in the ears of the elders of that city, they shall take him into the city unto them, and give him a place, that he may dwell among them.

Joshua 20:5 And if the avenger of blood pursue after him, then they shall not deliver the slayer up into his hand; because he smote his neighbour unwittingly, and hated him not beforetime.

Joshua 20:6 And he shall dwell in that city, until he stand before the congregation for judgment, and until the death of the high priest that shall be in those days: then shall the slayer return, and come unto his own city, and unto his own house, unto the city from whence he fled.

Joshua 20:7 And they appointed Kedesh in Galilee in mount Naphtali, and Shechem in mount Ephraim, and Kirjath-arba, which is Hebron, in the mountain of Judah.

Joshua 20:8 And on the other side Jordan by Jericho eastward, they assigned Bezer in the wilderness upon the plain out of the tribe of Reuben, and Ramoth in Gilead out of the tribe of Gad, and Golan in Bashan out of the tribe of Manasseh.

Joshua 20:9 These were the cities appointed for all the children of Israel, and for the stranger that sojourneth among them, that whosoever killeth any person at unawares might flee thither, and not die by the hand of the avenger of blood, until he stood before the congregation.
