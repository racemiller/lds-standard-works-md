# Numbers 5

Numbers 5 (summary): Lepers are put out of the camp—Sinners must confess and make restitution to gain forgiveness—Women believed to be immoral undergo a trial of jealousy before the priests.

Numbers 5:1 And the Lord spake unto Moses, saying,

Numbers 5:2 Command the children of Israel, that they put out of the camp every leper, and every one that hath an issue, and whosoever is defiled by the dead:

Numbers 5:3 Both male and female shall ye put out, without the camp shall ye put them; that they defile not their camps, in the midst whereof I dwell.

Numbers 5:4 And the children of Israel did so, and put them out without the camp: as the Lord spake unto Moses, so did the children of Israel.

Numbers 5:5 And the Lord spake unto Moses, saying,

Numbers 5:6 Speak unto the children of Israel, When a man or woman shall commit any sin that men commit, to do a trespass against the Lord, and that person be guilty;

Numbers 5:7 Then they shall confess their sin which they have done: and he shall recompense his trespass with the principal thereof, and add unto it the fifth part thereof, and give it unto him against whom he hath trespassed.

Numbers 5:8 But if the man have no kinsman to recompense the trespass unto, let the trespass be recompensed unto the Lord, even to the priest; beside the ram of the atonement, whereby an atonement shall be made for him.

Numbers 5:9 And every offering of all the holy things of the children of Israel, which they bring unto the priest, shall be his.

Numbers 5:10 And every man’s hallowed things shall be his: whatsoever any man giveth the priest, it shall be his.

Numbers 5:11 And the Lord spake unto Moses, saying,

Numbers 5:12 Speak unto the children of Israel, and say unto them, If any man’s wife go aside, and commit a trespass against him,

Numbers 5:13 And a man lie with her carnally, and it be hid from the eyes of her husband, and be kept close, and she be defiled, and there be no witness against her, neither she be taken with the manner;

Numbers 5:14 And the spirit of jealousy come upon him, and he be jealous of his wife, and she be defiled: or if the spirit of jealousy come upon him, and he be jealous of his wife, and she be not defiled:

Numbers 5:15 Then shall the man bring his wife unto the priest, and he shall bring her offering for her, the tenth part of an ephah of barley meal; he shall pour no oil upon it, nor put frankincense thereon; for it is an offering of jealousy, an offering of memorial, bringing iniquity to remembrance.

Numbers 5:16 And the priest shall bring her near, and set her before the Lord:

Numbers 5:17 And the priest shall take holy water in an earthen vessel; and of the dust that is in the floor of the tabernacle the priest shall take, and put it into the water:

Numbers 5:18 And the priest shall set the woman before the Lord, and uncover the woman’s head, and put the offering of memorial in her hands, which is the jealousy offering: and the priest shall have in his hand the bitter water that causeth the curse:

Numbers 5:19 And the priest shall charge her by an oath, and say unto the woman, If no man have lain with thee, and if thou hast not gone aside to uncleanness with another instead of thy husband, be thou free from this bitter water that causeth the curse:

Numbers 5:20 But if thou hast gone aside to another instead of thy husband, and if thou be defiled, and some man have lain with thee beside thine husband:

Numbers 5:21 Then the priest shall charge the woman with an oath of cursing, and the priest shall say unto the woman, The Lord make thee a curse and an oath among thy people, when the Lord doth make thy thigh to rot, and thy belly to swell;

Numbers 5:22 And this water that causeth the curse shall go into thy bowels, to make thy belly to swell, and thy thigh to rot: And the woman shall say, Amen, amen.

Numbers 5:23 And the priest shall write these curses in a book, and he shall blot them out with the bitter water:

Numbers 5:24 And he shall cause the woman to drink the bitter water that causeth the curse: and the water that causeth the curse shall enter into her, and become bitter.

Numbers 5:25 Then the priest shall take the jealousy offering out of the woman’s hand, and shall wave the offering before the Lord, and offer it upon the altar:

Numbers 5:26 And the priest shall take an handful of the offering, even the memorial thereof, and burn it upon the altar, and afterward shall cause the woman to drink the water.

Numbers 5:27 And when he hath made her to drink the water, then it shall come to pass, that, if she be defiled, and have done trespass against her husband, that the water that causeth the curse shall enter into her, and become bitter, and her belly shall swell, and her thigh shall rot: and the woman shall be a curse among her people.

Numbers 5:28 And if the woman be not defiled, but be clean; then she shall be free, and shall conceive seed.

Numbers 5:29 This is the law of jealousies, when a wife goeth aside to another instead of her husband, and is defiled;

Numbers 5:30 Or when the spirit of jealousy cometh upon him, and he be jealous over his wife, and shall set the woman before the Lord, and the priest shall execute upon her all this law.

Numbers 5:31 Then shall the man be guiltless from iniquity, and this woman shall bear her iniquity.
