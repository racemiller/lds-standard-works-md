# Psalms 45

Psalms 45 (summary): A messianic psalm—The Messiah is fairer than the children of men—He is anointed with the oil of gladness above His fellows—His name will be remembered in all generations.

Psalms 45:1 My heart is inditing a good matter: I speak of the things which I have made touching the king: my tongue is the pen of a ready writer.

Psalms 45:2 Thou art fairer than the children of men: grace is poured into thy lips: therefore God hath blessed thee for ever.

Psalms 45:3 Gird thy sword upon thy thigh, O most mighty, with thy glory and thy majesty.

Psalms 45:4 And in thy majesty ride prosperously because of truth and meekness and righteousness; and thy right hand shall teach thee terrible things.

Psalms 45:5 Thine arrows are sharp in the heart of the king’s enemies; whereby the people fall under thee.

Psalms 45:6 Thy throne, O God, is for ever and ever: the sceptre of thy kingdom is a right sceptre.

Psalms 45:7 Thou lovest righteousness, and hatest wickedness: therefore God, thy God, hath anointed thee with the oil of gladness above thy fellows.

Psalms 45:8 All thy garments smell of myrrh, and aloes, and cassia, out of the ivory palaces, whereby they have made thee glad.

Psalms 45:9 Kings’ daughters were among thy honourable women: upon thy right hand did stand the queen in gold of Ophir.

Psalms 45:10 Hearken, O daughter, and consider, and incline thine ear; forget also thine own people, and thy father’s house;

Psalms 45:11 So shall the king greatly desire thy beauty: for he is thy Lord; and worship thou him.

Psalms 45:12 And the daughter of Tyre shall be there with a gift; even the rich among the people shall entreat thy favour.

Psalms 45:13 The king’s daughter is all glorious within: her clothing is of wrought gold.

Psalms 45:14 She shall be brought unto the king in raiment of needlework: the virgins her companions that follow her shall be brought unto thee.

Psalms 45:15 With gladness and rejoicing shall they be brought: they shall enter into the king’s palace.

Psalms 45:16 Instead of thy fathers shall be thy children, whom thou mayest make princes in all the earth.

Psalms 45:17 I will make thy name to be remembered in all generations: therefore shall the people praise thee for ever and ever.
