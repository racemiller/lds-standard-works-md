# Deuteronomy 24

Deuteronomy 24 (summary): Laws are given concerning divorce, newly married persons, making merchandise of men, taking pledges, leprosy, oppression of servants, and leaving gleanings of crops.

Deuteronomy 24:1 When a man hath taken a wife, and married her, and it come to pass that she find no favour in his eyes, because he hath found some uncleanness in her: then let him write her a bill of divorcement, and give it in her hand, and send her out of his house.

Deuteronomy 24:2 And when she is departed out of his house, she may go and be another man’s wife.

Deuteronomy 24:3 And if the latter husband hate her, and write her a bill of divorcement, and giveth it in her hand, and sendeth her out of his house; or if the latter husband die, which took her to be his wife;

Deuteronomy 24:4 Her former husband, which sent her away, may not take her again to be his wife, after that she is defiled; for that is abomination before the Lord: and thou shalt not cause the land to sin, which the Lord thy God giveth thee for an inheritance.

Deuteronomy 24:5 When a man hath taken a new wife, he shall not go out to war, neither shall he be charged with any business: but he shall be free at home one year, and shall cheer up his wife which he hath taken.

Deuteronomy 24:6 No man shall take the nether or the upper millstone to pledge: for he taketh a man’s life to pledge.

Deuteronomy 24:7 If a man be found stealing any of his brethren of the children of Israel, and maketh merchandise of him, or selleth him; then that thief shall die; and thou shalt put evil away from among you.

Deuteronomy 24:8 Take heed in the plague of leprosy, that thou observe diligently, and do according to all that the priests the Levites shall teach you: as I commanded them, so ye shall observe to do.

Deuteronomy 24:9 Remember what the Lord thy God did unto Miriam by the way, after that ye were come forth out of Egypt.

Deuteronomy 24:10 When thou dost lend thy brother any thing, thou shalt not go into his house to fetch his pledge.

Deuteronomy 24:11 Thou shalt stand abroad, and the man to whom thou dost lend shall bring out the pledge abroad unto thee.

Deuteronomy 24:12 And if the man be poor, thou shalt not sleep with his pledge:

Deuteronomy 24:13 In any case thou shalt deliver him the pledge again when the sun goeth down, that he may sleep in his own raiment, and bless thee: and it shall be righteousness unto thee before the Lord thy God.

Deuteronomy 24:14 Thou shalt not oppress an hired servant that is poor and needy, whether he be of thy brethren, or of thy strangers that are in thy land within thy gates:

Deuteronomy 24:15 At his day thou shalt give him his hire, neither shall the sun go down upon it; for he is poor, and setteth his heart upon it: lest he cry against thee unto the Lord, and it be sin unto thee.

Deuteronomy 24:16 The fathers shall not be put to death for the children, neither shall the children be put to death for the fathers: every man shall be put to death for his own sin.

Deuteronomy 24:17 Thou shalt not pervert the judgment of the stranger, nor of the fatherless; nor take a widow’s raiment to pledge:

Deuteronomy 24:18 But thou shalt remember that thou wast a bondman in Egypt, and the Lord thy God redeemed thee thence: therefore I command thee to do this thing.

Deuteronomy 24:19 When thou cuttest down thine harvest in thy field, and hast forgot a sheaf in the field, thou shalt not go again to fetch it: it shall be for the stranger, for the fatherless, and for the widow: that the Lord thy God may bless thee in all the work of thine hands.

Deuteronomy 24:20 When thou beatest thine olive tree, thou shalt not go over the boughs again: it shall be for the stranger, for the fatherless, and for the widow.

Deuteronomy 24:21 When thou gatherest the grapes of thy vineyard, thou shalt not glean it afterward: it shall be for the stranger, for the fatherless, and for the widow.

Deuteronomy 24:22 And thou shalt remember that thou wast a bondman in the land of Egypt: therefore I command thee to do this thing.
