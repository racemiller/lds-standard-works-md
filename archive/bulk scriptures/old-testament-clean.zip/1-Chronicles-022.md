# 1 Chronicles 22

1 Chronicles 22 (summary): David prepares gold, silver, brass, iron, stone, and cedar wood for the temple—He charges Solomon to do the work of building it.

1 Chronicles 22:1 Then David said, This is the house of the Lord God, and this is the altar of the burnt offering for Israel.

1 Chronicles 22:2 And David commanded to gather together the strangers that were in the land of Israel; and he set masons to hew wrought stones to build the house of God.

1 Chronicles 22:3 And David prepared iron in abundance for the nails for the doors of the gates, and for the joinings; and brass in abundance without weight;

1 Chronicles 22:4 Also cedar trees in abundance: for the Zidonians and they of Tyre brought much cedar wood to David.

1 Chronicles 22:5 And David said, Solomon my son is young and tender, and the house that is to be builded for the Lord must be exceeding magnifical, of fame and of glory throughout all countries: I will therefore now make preparation for it. So David prepared abundantly before his death.

1 Chronicles 22:6 Then he called for Solomon his son, and charged him to build an house for the Lord God of Israel.

1 Chronicles 22:7 And David said to Solomon, My son, as for me, it was in my mind to build an house unto the name of the Lord my God:

1 Chronicles 22:8 But the word of the Lord came to me, saying, Thou hast shed blood abundantly, and hast made great wars: thou shalt not build an house unto my name, because thou hast shed much blood upon the earth in my sight.

1 Chronicles 22:9 Behold, a son shall be born to thee, who shall be a man of rest; and I will give him rest from all his enemies round about: for his name shall be Solomon, and I will give peace and quietness unto Israel in his days.

1 Chronicles 22:10 He shall build an house for my name; and he shall be my son, and I will be his father; and I will establish the throne of his kingdom over Israel for ever.

1 Chronicles 22:11 Now, my son, the Lord be with thee; and prosper thou, and build the house of the Lord thy God, as he hath said of thee.

1 Chronicles 22:12 Only the Lord give thee wisdom and understanding, and give thee charge concerning Israel, that thou mayest keep the law of the Lord thy God.

1 Chronicles 22:13 Then shalt thou prosper, if thou takest heed to fulfil the statutes and judgments which the Lord charged Moses with concerning Israel: be strong, and of good courage; dread not, nor be dismayed.

1 Chronicles 22:14 Now, behold, in my trouble I have prepared for the house of the Lord an hundred thousand talents of gold, and a thousand thousand talents of silver; and of brass and iron without weight; for it is in abundance: timber also and stone have I prepared; and thou mayest add thereto.

1 Chronicles 22:15 Moreover there are workmen with thee in abundance, hewers and workers of stone and timber, and all manner of cunning men for every manner of work.

1 Chronicles 22:16 Of the gold, the silver, and the brass, and the iron, there is no number. Arise therefore, and be doing, and the Lord be with thee.

1 Chronicles 22:17 David also commanded all the princes of Israel to help Solomon his son, saying,

1 Chronicles 22:18 Is not the Lord your God with you? and hath he not given you rest on every side? for he hath given the inhabitants of the land into mine hand; and the land is subdued before the Lord, and before his people.

1 Chronicles 22:19 Now set your heart and your soul to seek the Lord your God; arise therefore, and build ye the sanctuary of the Lord God, to bring the ark of the covenant of the Lord, and the holy vessels of God, into the house that is to be built to the name of the Lord.
