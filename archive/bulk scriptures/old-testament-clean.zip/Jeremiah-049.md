# Jeremiah 49

Jeremiah 49 (summary): Judgment and destruction will come upon the people of Ammon, Edom, Kedar, Hazor, and Elam.

Jeremiah 49:1 Concerning the Ammonites, thus saith the Lord; Hath Israel no sons? hath he no heir? why then doth their king inherit Gad, and his people dwell in his cities?

Jeremiah 49:2 Therefore, behold, the days come, saith the Lord, that I will cause an alarm of war to be heard in Rabbah of the Ammonites; and it shall be a desolate heap, and her daughters shall be burned with fire: then shall Israel be heir unto them that were his heirs, saith the Lord.

Jeremiah 49:3 Howl, O Heshbon, for Ai is spoiled: cry, ye daughters of Rabbah, gird you with sackcloth; lament, and run to and fro by the hedges; for their king shall go into captivity, and his priests and his princes together.

Jeremiah 49:4 Wherefore gloriest thou in the valleys, thy flowing valley, O backsliding daughter? that trusted in her treasures, saying, Who shall come unto me?

Jeremiah 49:5 Behold, I will bring a fear upon thee, saith the Lord God of hosts, from all those that be about thee; and ye shall be driven out every man right forth; and none shall gather up him that wandereth.

Jeremiah 49:6 And afterward I will bring again the captivity of the children of Ammon, saith the Lord.

Jeremiah 49:7 Concerning Edom, thus saith the Lord of hosts; Is wisdom no more in Teman? is counsel perished from the prudent? is their wisdom vanished?

Jeremiah 49:8 Flee ye, turn back, dwell deep, O inhabitants of Dedan; for I will bring the calamity of Esau upon him, the time that I will visit him.

Jeremiah 49:9 If grapegatherers come to thee, would they not leave some gleaning grapes? if thieves by night, they will destroy till they have enough.

Jeremiah 49:10 But I have made Esau bare, I have uncovered his secret places, and he shall not be able to hide himself: his seed is spoiled, and his brethren, and his neighbours, and he is not.

Jeremiah 49:11 Leave thy fatherless children, I will preserve them alive; and let thy widows trust in me.

Jeremiah 49:12 For thus saith the Lord; Behold, they whose judgment was not to drink of the cup have assuredly drunken; and art thou he that shall altogether go unpunished? thou shalt not go unpunished, but thou shalt surely drink of it.

Jeremiah 49:13 For I have sworn by myself, saith the Lord, that Bozrah shall become a desolation, a reproach, a waste, and a curse; and all the cities thereof shall be perpetual wastes.

Jeremiah 49:14 I have heard a rumour from the Lord, and an ambassador is sent unto the heathen, saying, Gather ye together, and come against her, and rise up to the battle.

Jeremiah 49:15 For, lo, I will make thee small among the heathen, and despised among men.

Jeremiah 49:16 Thy terribleness hath deceived thee, and the pride of thine heart, O thou that dwellest in the clefts of the rock, that holdest the height of the hill: though thou shouldest make thy nest as high as the eagle, I will bring thee down from thence, saith the Lord.

Jeremiah 49:17 Also Edom shall be a desolation: every one that goeth by it shall be astonished, and shall hiss at all the plagues thereof.

Jeremiah 49:18 As in the overthrow of Sodom and Gomorrah and the neighbour cities thereof, saith the Lord, no man shall abide there, neither shall a son of man dwell in it.

Jeremiah 49:19 Behold, he shall come up like a lion from the swelling of Jordan against the habitation of the strong: but I will suddenly make him run away from her: and who is a chosen man, that I may appoint over her? for who is like me? and who will appoint me the time? and who is that shepherd that will stand before me?

Jeremiah 49:20 Therefore hear the counsel of the Lord, that he hath taken against Edom; and his purposes, that he hath purposed against the inhabitants of Teman: Surely the least of the flock shall draw them out: surely he shall make their habitations desolate with them.

Jeremiah 49:21 The earth is moved at the noise of their fall, at the cry the noise thereof was heard in the Red sea.

Jeremiah 49:22 Behold, he shall come up and fly as the eagle, and spread his wings over Bozrah: and at that day shall the heart of the mighty men of Edom be as the heart of a woman in her pangs.

Jeremiah 49:23 Concerning Damascus. Hamath is confounded, and Arpad: for they have heard evil tidings: they are fainthearted; there is sorrow on the sea; it cannot be quiet.

Jeremiah 49:24 Damascus is waxed feeble, and turneth herself to flee, and fear hath seized on her: anguish and sorrows have taken her, as a woman in travail.

Jeremiah 49:25 How is the city of praise not left, the city of my joy!

Jeremiah 49:26 Therefore her young men shall fall in her streets, and all the men of war shall be cut off in that day, saith the Lord of hosts.

Jeremiah 49:27 And I will kindle a fire in the wall of Damascus, and it shall consume the palaces of Ben-hadad.

Jeremiah 49:28 Concerning Kedar, and concerning the kingdoms of Hazor, which Nebuchadrezzar king of Babylon shall smite, thus saith the Lord; Arise ye, go up to Kedar, and spoil the men of the east.

Jeremiah 49:29 Their tents and their flocks shall they take away: they shall take to themselves their curtains, and all their vessels, and their camels; and they shall cry unto them, Fear is on every side.

Jeremiah 49:30 Flee, get you far off, dwell deep, O ye inhabitants of Hazor, saith the Lord; for Nebuchadrezzar king of Babylon hath taken counsel against you, and hath conceived a purpose against you.

Jeremiah 49:31 Arise, get you up unto the wealthy nation, that dwelleth without care, saith the Lord, which have neither gates nor bars, which dwell alone.

Jeremiah 49:32 And their camels shall be a booty, and the multitude of their cattle a spoil: and I will scatter into all winds them that are in the utmost corners; and I will bring their calamity from all sides thereof, saith the Lord.

Jeremiah 49:33 And Hazor shall be a dwelling for dragons, and a desolation for ever: there shall no man abide there, nor any son of man dwell in it.

Jeremiah 49:34 The word of the Lord that came to Jeremiah the prophet against Elam in the beginning of the reign of Zedekiah king of Judah, saying,

Jeremiah 49:35 Thus saith the Lord of hosts; Behold, I will break the bow of Elam, the chief of their might.

Jeremiah 49:36 And upon Elam will I bring the four winds from the four quarters of heaven, and will scatter them toward all those winds; and there shall be no nation whither the outcasts of Elam shall not come.

Jeremiah 49:37 For I will cause Elam to be dismayed before their enemies, and before them that seek their life: and I will bring evil upon them, even my fierce anger, saith the Lord; and I will send the sword after them, till I have consumed them:

Jeremiah 49:38 And I will set my throne in Elam, and will destroy from thence the king and the princes, saith the Lord.

Jeremiah 49:39 But it shall come to pass in the latter days, that I will bring again the captivity of Elam, saith the Lord.
