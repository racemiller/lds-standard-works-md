# 2 Chronicles 28

2 Chronicles 28 (summary): Ahaz reigns in wickedness and practices idolatry; his people are defeated by Israel—The captives are freed by the command of a prophet—The Edomites and Philistines attack Judah—Ahaz continues his idolatrous ways.

2 Chronicles 28:1 Ahaz was twenty years old when he began to reign, and he reigned sixteen years in Jerusalem: but he did not that which was right in the sight of the Lord, like David his father:

2 Chronicles 28:2 For he walked in the ways of the kings of Israel, and made also molten images for Baalim.

2 Chronicles 28:3 Moreover he burnt incense in the valley of the son of Hinnom, and burnt his children in the fire, after the abominations of the heathen whom the Lord had cast out before the children of Israel.

2 Chronicles 28:4 He sacrificed also and burnt incense in the high places, and on the hills, and under every green tree.

2 Chronicles 28:5 Wherefore the Lord his God delivered him into the hand of the king of Syria; and they smote him, and carried away a great multitude of them captives, and brought them to Damascus. And he was also delivered into the hand of the king of Israel, who smote him with a great slaughter.

2 Chronicles 28:6 For Pekah the son of Remaliah slew in Judah an hundred and twenty thousand in one day, which were all valiant men; because they had forsaken the Lord God of their fathers.

2 Chronicles 28:7 And Zichri, a mighty man of Ephraim, slew Maaseiah the king’s son, and Azrikam the governor of the house, and Elkanah that was next to the king.

2 Chronicles 28:8 And the children of Israel carried away captive of their brethren two hundred thousand, women, sons, and daughters, and took also away much spoil from them, and brought the spoil to Samaria.

2 Chronicles 28:9 But a prophet of the Lord was there, whose name was Oded: and he went out before the host that came to Samaria, and said unto them, Behold, because the Lord God of your fathers was wroth with Judah, he hath delivered them into your hand, and ye have slain them in a rage that reacheth up unto heaven.

2 Chronicles 28:10 And now ye purpose to keep under the children of Judah and Jerusalem for bondmen and bondwomen unto you: but are there not with you, even with you, sins against the Lord your God?

2 Chronicles 28:11 Now hear me therefore, and deliver the captives again, which ye have taken captive of your brethren: for the fierce wrath of the Lord is upon you.

2 Chronicles 28:12 Then certain of the heads of the children of Ephraim, Azariah the son of Johanan, Berechiah the son of Meshillemoth, and Jehizkiah the son of Shallum, and Amasa the son of Hadlai, stood up against them that came from the war,

2 Chronicles 28:13 And said unto them, Ye shall not bring in the captives hither: for whereas we have offended against the Lord already, ye intend to add more to our sins and to our trespass: for our trespass is great, and there is fierce wrath against Israel.

2 Chronicles 28:14 So the armed men left the captives and the spoil before the princes and all the congregation.

2 Chronicles 28:15 And the men which were expressed by name rose up, and took the captives, and with the spoil clothed all that were naked among them, and arrayed them, and shod them, and gave them to eat and to drink, and anointed them, and carried all the feeble of them upon asses, and brought them to Jericho, the city of palm trees, to their brethren: then they returned to Samaria.

2 Chronicles 28:16 At that time did king Ahaz send unto the kings of Assyria to help him.

2 Chronicles 28:17 For again the Edomites had come and smitten Judah, and carried away captives.

2 Chronicles 28:18 The Philistines also had invaded the cities of the low country, and of the south of Judah, and had taken Beth-shemesh, and Ajalon, and Gederoth, and Shocho with the villages thereof, and Timnah with the villages thereof, Gimzo also and the villages thereof: and they dwelt there.

2 Chronicles 28:19 For the Lord brought Judah low because of Ahaz king of Israel; for he made Judah naked, and transgressed sore against the Lord.

2 Chronicles 28:20 And Tilgath-pilneser king of Assyria came unto him, and distressed him, but strengthened him not.

2 Chronicles 28:21 For Ahaz took away a portion out of the house of the Lord, and out of the house of the king, and of the princes, and gave it unto the king of Assyria: but he helped him not.

2 Chronicles 28:22 And in the time of his distress did he trespass yet more against the Lord: this is that king Ahaz.

2 Chronicles 28:23 For he sacrificed unto the gods of Damascus, which smote him: and he said, Because the gods of the kings of Syria help them, therefore will I sacrifice to them, that they may help me. But they were the ruin of him, and of all Israel.

2 Chronicles 28:24 And Ahaz gathered together the vessels of the house of God, and cut in pieces the vessels of the house of God, and shut up the doors of the house of the Lord, and he made him altars in every corner of Jerusalem.

2 Chronicles 28:25 And in every several city of Judah he made high places to burn incense unto other gods, and provoked to anger the Lord God of his fathers.

2 Chronicles 28:26 Now the rest of his acts and of all his ways, first and last, behold, they are written in the book of the kings of Judah and Israel.

2 Chronicles 28:27 And Ahaz slept with his fathers, and they buried him in the city, even in Jerusalem: but they brought him not into the sepulchres of the kings of Israel: and Hezekiah his son reigned in his stead.
