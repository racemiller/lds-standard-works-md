# Genesis 7

Genesis 7 (summary): Noah’s family and various beasts and fowl enter the ark—The Flood comes, and water covers the whole earth—All other life that breathes is destroyed.

Genesis 7:1 And the Lord said unto Noah, Come thou and all thy house into the ark; for thee have I seen righteous before me in this generation.

Genesis 7:2 Of every clean beast thou shalt take to thee by sevens, the male and his female: and of beasts that are not clean by two, the male and his female.

Genesis 7:3 Of fowls also of the air by sevens, the male and the female; to keep seed alive upon the face of all the earth.

Genesis 7:4 For yet seven days, and I will cause it to rain upon the earth forty days and forty nights; and every living substance that I have made will I destroy from off the face of the earth.

Genesis 7:5 And Noah did according unto all that the Lord commanded him.

Genesis 7:6 And Noah was six hundred years old when the flood of waters was upon the earth.

Genesis 7:7 And Noah went in, and his sons, and his wife, and his sons’ wives with him, into the ark, because of the waters of the flood.

Genesis 7:8 Of clean beasts, and of beasts that are not clean, and of fowls, and of every thing that creepeth upon the earth,

Genesis 7:9 There went in two and two unto Noah into the ark, the male and the female, as God had commanded Noah.

Genesis 7:10 And it came to pass after seven days, that the waters of the flood were upon the earth.

Genesis 7:11 In the six hundredth year of Noah’s life, in the second month, the seventeenth day of the month, the same day were all the fountains of the great deep broken up, and the windows of heaven were opened.

Genesis 7:12 And the rain was upon the earth forty days and forty nights.

Genesis 7:13 In the selfsame day entered Noah, and Shem, and Ham, and Japheth, the sons of Noah, and Noah’s wife, and the three wives of his sons with them, into the ark;

Genesis 7:14 They, and every beast after his kind, and all the cattle after their kind, and every creeping thing that creepeth upon the earth after his kind, and every fowl after his kind, every bird of every sort.

Genesis 7:15 And they went in unto Noah into the ark, two and two of all flesh, wherein is the breath of life.

Genesis 7:16 And they that went in, went in male and female of all flesh, as God had commanded him: and the Lord shut him in.

Genesis 7:17 And the flood was forty days upon the earth; and the waters increased, and bare up the ark, and it was lift up above the earth.

Genesis 7:18 And the waters prevailed, and were increased greatly upon the earth; and the ark went upon the face of the waters.

Genesis 7:19 And the waters prevailed exceedingly upon the earth; and all the high hills, that were under the whole heaven, were covered.

Genesis 7:20 Fifteen cubits upward did the waters prevail; and the mountains were covered.

Genesis 7:21 And all flesh died that moved upon the earth, both of fowl, and of cattle, and of beast, and of every creeping thing that creepeth upon the earth, and every man:

Genesis 7:22 All in whose nostrils was the breath of life, of all that was in the dry land, died.

Genesis 7:23 And every living substance was destroyed which was upon the face of the ground, both man, and cattle, and the creeping things, and the fowl of the heaven; and they were destroyed from the earth: and Noah only remained alive, and they that were with him in the ark.

Genesis 7:24 And the waters prevailed upon the earth an hundred and fifty days.
