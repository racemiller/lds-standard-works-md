# Jeremiah 25

Jeremiah 25 (summary): Captive Judah will serve Babylon for seventy years—Various nations will be overthrown—In the last days, all the inhabitants of the earth will be at war.

Jeremiah 25:1 The word that came to Jeremiah concerning all the people of Judah in the fourth year of Jehoiakim the son of Josiah king of Judah, that was the first year of Nebuchadrezzar king of Babylon;

Jeremiah 25:2 The which Jeremiah the prophet spake unto all the people of Judah, and to all the inhabitants of Jerusalem, saying,

Jeremiah 25:3 From the thirteenth year of Josiah the son of Amon king of Judah, even unto this day, that is the three and twentieth year, the word of the Lord hath come unto me, and I have spoken unto you, rising early and speaking; but ye have not hearkened.

Jeremiah 25:4 And the Lord hath sent unto you all his servants the prophets, rising early and sending them; but ye have not hearkened, nor inclined your ear to hear.

Jeremiah 25:5 They said, Turn ye again now every one from his evil way, and from the evil of your doings, and dwell in the land that the Lord hath given unto you and to your fathers for ever and ever:

Jeremiah 25:6 And go not after other gods to serve them, and to worship them, and provoke me not to anger with the works of your hands; and I will do you no hurt.

Jeremiah 25:7 Yet ye have not hearkened unto me, saith the Lord; that ye might provoke me to anger with the works of your hands to your own hurt.

Jeremiah 25:8 Therefore thus saith the Lord of hosts; Because ye have not heard my words,

Jeremiah 25:9 Behold, I will send and take all the families of the north, saith the Lord, and Nebuchadrezzar the king of Babylon, my servant, and will bring them against this land, and against the inhabitants thereof, and against all these nations round about, and will utterly destroy them, and make them an astonishment, and an hissing, and perpetual desolations.

Jeremiah 25:10 Moreover I will take from them the voice of mirth, and the voice of gladness, the voice of the bridegroom, and the voice of the bride, the sound of the millstones, and the light of the candle.

Jeremiah 25:11 And this whole land shall be a desolation, and an astonishment; and these nations shall serve the king of Babylon seventy years.

Jeremiah 25:12 And it shall come to pass, when seventy years are accomplished, that I will punish the king of Babylon, and that nation, saith the Lord, for their iniquity, and the land of the Chaldeans, and will make it perpetual desolations.

Jeremiah 25:13 And I will bring upon that land all my words which I have pronounced against it, even all that is written in this book, which Jeremiah hath prophesied against all the nations.

Jeremiah 25:14 For many nations and great kings shall serve themselves of them also: and I will recompense them according to their deeds, and according to the works of their own hands.

Jeremiah 25:15 For thus saith the Lord God of Israel unto me; Take the wine cup of this fury at my hand, and cause all the nations, to whom I send thee, to drink it.

Jeremiah 25:16 And they shall drink, and be moved, and be mad, because of the sword that I will send among them.

Jeremiah 25:17 Then took I the cup at the Lord’s hand, and made all the nations to drink, unto whom the Lord had sent me:

Jeremiah 25:18 To wit, Jerusalem, and the cities of Judah, and the kings thereof, and the princes thereof, to make them a desolation, an astonishment, an hissing, and a curse; as it is this day;

Jeremiah 25:19 Pharaoh king of Egypt, and his servants, and his princes, and all his people;

Jeremiah 25:20 And all the mingled people, and all the kings of the land of Uz, and all the kings of the land of the Philistines, and Ashkelon, and Azzah, and Ekron, and the remnant of Ashdod,

Jeremiah 25:21 Edom, and Moab, and the children of Ammon,

Jeremiah 25:22 And all the kings of Tyrus, and all the kings of Zidon, and the kings of the isles which are beyond the sea,

Jeremiah 25:23 Dedan, and Tema, and Buz, and all that are in the utmost corners,

Jeremiah 25:24 And all the kings of Arabia, and all the kings of the mingled people that dwell in the desert,

Jeremiah 25:25 And all the kings of Zimri, and all the kings of Elam, and all the kings of the Medes,

Jeremiah 25:26 And all the kings of the north, far and near, one with another, and all the kingdoms of the world, which are upon the face of the earth: and the king of Sheshach shall drink after them.

Jeremiah 25:27 Therefore thou shalt say unto them, Thus saith the Lord of hosts, the God of Israel; Drink ye, and be drunken, and spue, and fall, and rise no more, because of the sword which I will send among you.

Jeremiah 25:28 And it shall be, if they refuse to take the cup at thine hand to drink, then shalt thou say unto them, Thus saith the Lord of hosts; Ye shall certainly drink.

Jeremiah 25:29 For, lo, I begin to bring evil on the city which is called by my name, and should ye be utterly unpunished? Ye shall not be unpunished: for I will call for a sword upon all the inhabitants of the earth, saith the Lord of hosts.

Jeremiah 25:30 Therefore prophesy thou against them all these words, and say unto them, The Lord shall roar from on high, and utter his voice from his holy habitation; he shall mightily roar upon his habitation; he shall give a shout, as they that tread the grapes, against all the inhabitants of the earth.

Jeremiah 25:31 A noise shall come even to the ends of the earth; for the Lord hath a controversy with the nations, he will plead with all flesh; he will give them that are wicked to the sword, saith the Lord.

Jeremiah 25:32 Thus saith the Lord of hosts, Behold, evil shall go forth from nation to nation, and a great whirlwind shall be raised up from the coasts of the earth.

Jeremiah 25:33 And the slain of the Lord shall be at that day from one end of the earth even unto the other end of the earth: they shall not be lamented, neither gathered, nor buried; they shall be dung upon the ground.

Jeremiah 25:34 Howl, ye shepherds, and cry; and wallow yourselves in the ashes, ye principal of the flock: for the days of your slaughter and of your dispersions are accomplished; and ye shall fall like a pleasant vessel.

Jeremiah 25:35 And the shepherds shall have no way to flee, nor the principal of the flock to escape.

Jeremiah 25:36 A voice of the cry of the shepherds, and an howling of the principal of the flock, shall be heard: for the Lord hath spoiled their pasture.

Jeremiah 25:37 And the peaceable habitations are cut down because of the fierce anger of the Lord.

Jeremiah 25:38 He hath forsaken his covert, as the lion: for their land is desolate because of the fierceness of the oppressor, and because of his fierce anger.
