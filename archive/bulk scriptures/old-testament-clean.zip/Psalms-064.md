# Psalms 64

Psalms 64 (summary): David prays for safety—The righteous will be glad in heart.

Psalms 64:1 Hear my voice, O God, in my prayer: preserve my life from fear of the enemy.

Psalms 64:2 Hide me from the secret counsel of the wicked; from the insurrection of the workers of iniquity:

Psalms 64:3 Who whet their tongue like a sword, and bend their bows to shoot their arrows, even bitter words:

Psalms 64:4 That they may shoot in secret at the perfect: suddenly do they shoot at him, and fear not.

Psalms 64:5 They encourage themselves in an evil matter: they commune of laying snares privily; they say, Who shall see them?

Psalms 64:6 They search out iniquities; they accomplish a diligent search: both the inward thought of every one of them, and the heart, is deep.

Psalms 64:7 But God shall shoot at them with an arrow; suddenly shall they be wounded.

Psalms 64:8 So they shall make their own tongue to fall upon themselves: all that see them shall flee away.

Psalms 64:9 And all men shall fear, and shall declare the work of God; for they shall wisely consider of his doing.

Psalms 64:10 The righteous shall be glad in the Lord, and shall trust in him; and all the upright in heart shall glory.
