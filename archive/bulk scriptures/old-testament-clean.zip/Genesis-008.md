# Genesis 8

Genesis 8 (summary): The Flood ceases—Noah sends forth a dove, which returns with an olive leaf—He releases all living things from the ark—He offers sacrifices—Seedtime, harvest, and seasons are ensured.

Genesis 8:1 And God remembered Noah, and every living thing, and all the cattle that was with him in the ark: and God made a wind to pass over the earth, and the waters assuaged;

Genesis 8:2 The fountains also of the deep and the windows of heaven were stopped, and the rain from heaven was restrained;

Genesis 8:3 And the waters returned from off the earth continually: and after the end of the hundred and fifty days the waters were abated.

Genesis 8:4 And the ark rested in the seventh month, on the seventeenth day of the month, upon the mountains of Ararat.

Genesis 8:5 And the waters decreased continually until the tenth month: in the tenth month, on the first day of the month, were the tops of the mountains seen.

Genesis 8:6 And it came to pass at the end of forty days, that Noah opened the window of the ark which he had made:

Genesis 8:7 And he sent forth a raven, which went forth to and fro, until the waters were dried up from off the earth.

Genesis 8:8 Also he sent forth a dove from him, to see if the waters were abated from off the face of the ground;

Genesis 8:9 But the dove found no rest for the sole of her foot, and she returned unto him into the ark, for the waters were on the face of the whole earth: then he put forth his hand, and took her, and pulled her in unto him into the ark.

Genesis 8:10 And he stayed yet other seven days; and again he sent forth the dove out of the ark;

Genesis 8:11 And the dove came in to him in the evening; and, lo, in her mouth was an olive leaf plucked off: so Noah knew that the waters were abated from off the earth.

Genesis 8:12 And he stayed yet other seven days; and sent forth the dove; which returned not again unto him any more.

Genesis 8:13 And it came to pass in the six hundredth and first year, in the first month, the first day of the month, the waters were dried up from off the earth: and Noah removed the covering of the ark, and looked, and, behold, the face of the ground was dry.

Genesis 8:14 And in the second month, on the seven and twentieth day of the month, was the earth dried.

Genesis 8:15 And God spake unto Noah, saying,

Genesis 8:16 Go forth of the ark, thou, and thy wife, and thy sons, and thy sons’ wives with thee.

Genesis 8:17 Bring forth with thee every living thing that is with thee, of all flesh, both of fowl, and of cattle, and of every creeping thing that creepeth upon the earth; that they may breed abundantly in the earth, and be fruitful, and multiply upon the earth.

Genesis 8:18 And Noah went forth, and his sons, and his wife, and his sons’ wives with him:

Genesis 8:19 Every beast, every creeping thing, and every fowl, and whatsoever creepeth upon the earth, after their kinds, went forth out of the ark.

Genesis 8:20 And Noah builded an altar unto the Lord; and took of every clean beast, and of every clean fowl, and offered burnt offerings on the altar.

Genesis 8:21 And the Lord smelled a sweet savour; and the Lord said in his heart, I will not again curse the ground any more for man’s sake; for the imagination of man’s heart is evil from his youth; neither will I again smite any more every thing living, as I have done.

Genesis 8:22 While the earth remaineth, seedtime and harvest, and cold and heat, and summer and winter, and day and night shall not cease.
