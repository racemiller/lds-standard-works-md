# 1 Kings 21

1 Kings 21 (summary): Ahab desires the vineyard of Naboth—Jezebel arranges for false witnesses, and Naboth is stoned for blasphemy—Elijah prophesies that Ahab and Jezebel and their house will be destroyed.

1 Kings 21:1 And it came to pass after these things, that Naboth the Jezreelite had a vineyard, which was in Jezreel, hard by the palace of Ahab king of Samaria.

1 Kings 21:2 And Ahab spake unto Naboth, saying, Give me thy vineyard, that I may have it for a garden of herbs, because it is near unto my house: and I will give thee for it a better vineyard than it; or, if it seem good to thee, I will give thee the worth of it in money.

1 Kings 21:3 And Naboth said to Ahab, The Lord forbid it me, that I should give the inheritance of my fathers unto thee.

1 Kings 21:4 And Ahab came into his house heavy and displeased because of the word which Naboth the Jezreelite had spoken to him: for he had said, I will not give thee the inheritance of my fathers. And he laid him down upon his bed, and turned away his face, and would eat no bread.

1 Kings 21:5 But Jezebel his wife came to him, and said unto him, Why is thy spirit so sad, that thou eatest no bread?

1 Kings 21:6 And he said unto her, Because I spake unto Naboth the Jezreelite, and said unto him, Give me thy vineyard for money; or else, if it please thee, I will give thee another vineyard for it: and he answered, I will not give thee my vineyard.

1 Kings 21:7 And Jezebel his wife said unto him, Dost thou now govern the kingdom of Israel? arise, and eat bread, and let thine heart be merry: I will give thee the vineyard of Naboth the Jezreelite.

1 Kings 21:8 So she wrote letters in Ahab’s name, and sealed them with his seal, and sent the letters unto the elders and to the nobles that were in his city, dwelling with Naboth.

1 Kings 21:9 And she wrote in the letters, saying, Proclaim a fast, and set Naboth on high among the people:

1 Kings 21:10 And set two men, sons of Belial, before him, to bear witness against him, saying, Thou didst blaspheme God and the king. And then carry him out, and stone him, that he may die.

1 Kings 21:11 And the men of his city, even the elders and the nobles who were the inhabitants in his city, did as Jezebel had sent unto them, and as it was written in the letters which she had sent unto them.

1 Kings 21:12 They proclaimed a fast, and set Naboth on high among the people.

1 Kings 21:13 And there came in two men, children of Belial, and sat before him: and the men of Belial witnessed against him, even against Naboth, in the presence of the people, saying, Naboth did blaspheme God and the king. Then they carried him forth out of the city, and stoned him with stones, that he died.

1 Kings 21:14 Then they sent to Jezebel, saying, Naboth is stoned, and is dead.

1 Kings 21:15 And it came to pass, when Jezebel heard that Naboth was stoned, and was dead, that Jezebel said to Ahab, Arise, take possession of the vineyard of Naboth the Jezreelite, which he refused to give thee for money: for Naboth is not alive, but dead.

1 Kings 21:16 And it came to pass, when Ahab heard that Naboth was dead, that Ahab rose up to go down to the vineyard of Naboth the Jezreelite, to take possession of it.

1 Kings 21:17 And the word of the Lord came to Elijah the Tishbite, saying,

1 Kings 21:18 Arise, go down to meet Ahab king of Israel, which is in Samaria: behold, he is in the vineyard of Naboth, whither he is gone down to possess it.

1 Kings 21:19 And thou shalt speak unto him, saying, Thus saith the Lord, Hast thou killed, and also taken possession? And thou shalt speak unto him, saying, Thus saith the Lord, In the place where dogs licked the blood of Naboth shall dogs lick thy blood, even thine.

1 Kings 21:20 And Ahab said to Elijah, Hast thou found me, O mine enemy? And he answered, I have found thee: because thou hast sold thyself to work evil in the sight of the Lord.

1 Kings 21:21 Behold, I will bring evil upon thee, and will take away thy posterity, and will cut off from Ahab him that pisseth against the wall, and him that is shut up and left in Israel,

1 Kings 21:22 And will make thine house like the house of Jeroboam the son of Nebat, and like the house of Baasha the son of Ahijah, for the provocation wherewith thou hast provoked me to anger, and made Israel to sin.

1 Kings 21:23 And of Jezebel also spake the Lord, saying, The dogs shall eat Jezebel by the wall of Jezreel.

1 Kings 21:24 Him that dieth of Ahab in the city the dogs shall eat; and him that dieth in the field shall the fowls of the air eat.

1 Kings 21:25 But there was none like unto Ahab, which did sell himself to work wickedness in the sight of the Lord, whom Jezebel his wife stirred up.

1 Kings 21:26 And he did very abominably in following idols, according to all things as did the Amorites, whom the Lord cast out before the children of Israel.

1 Kings 21:27 And it came to pass, when Ahab heard those words, that he rent his clothes, and put sackcloth upon his flesh, and fasted, and lay in sackcloth, and went softly.

1 Kings 21:28 And the word of the Lord came to Elijah the Tishbite, saying,

1 Kings 21:29 Seest thou how Ahab humbleth himself before me? because he humbleth himself before me, I will not bring the evil in his days: but in his son’s days will I bring the evil upon his house.
