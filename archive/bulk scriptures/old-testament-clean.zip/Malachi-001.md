# Malachi 1

Malachi 1 (summary): The Jews despise the Lord by offering polluted bread upon the altar and by sacrificing animals with blemishes—The Lord’s name will be great among the Gentiles.

Malachi 1:1 The burden of the word of the Lord to Israel by Malachi.

Malachi 1:2 I have loved you, saith the Lord. Yet ye say, Wherein hast thou loved us? Was not Esau Jacob’s brother? saith the Lord: yet I loved Jacob,

Malachi 1:3 And I hated Esau, and laid his mountains and his heritage waste for the dragons of the wilderness.

Malachi 1:4 Whereas Edom saith, We are impoverished, but we will return and build the desolate places; thus saith the Lord of hosts, They shall build, but I will throw down; and they shall call them, The border of wickedness, and, The people against whom the Lord hath indignation for ever.

Malachi 1:5 And your eyes shall see, and ye shall say, The Lord will be magnified from the border of Israel.

Malachi 1:6 A son honoureth his father, and a servant his master: if then I be a father, where is mine honour? and if I be a master, where is my fear? saith the Lord of hosts unto you, O priests, that despise my name. And ye say, Wherein have we despised thy name?

Malachi 1:7 Ye offer polluted bread upon mine altar; and ye say, Wherein have we polluted thee? In that ye say, The table of the Lord is contemptible.

Malachi 1:8 And if ye offer the blind for sacrifice, is it not evil? and if ye offer the lame and sick, is it not evil? offer it now unto thy governor; will he be pleased with thee, or accept thy person? saith the Lord of hosts.

Malachi 1:9 And now, I pray you, beseech God that he will be gracious unto us: this hath been by your means: will he regard your persons? saith the Lord of hosts.

Malachi 1:10 Who is there even among you that would shut the doors for nought? neither do ye kindle fire on mine altar for nought. I have no pleasure in you, saith the Lord of hosts, neither will I accept an offering at your hand.

Malachi 1:11 For from the rising of the sun even unto the going down of the same my name shall be great among the Gentiles; and in every place incense shall be offered unto my name, and a pure offering: for my name shall be great among the heathen, saith the Lord of hosts.

Malachi 1:12 But ye have profaned it, in that ye say, The table of the Lord is polluted; and the fruit thereof, even his meat, is contemptible.

Malachi 1:13 Ye said also, Behold, what a weariness is it! and ye have snuffed at it, saith the Lord of hosts; and ye brought that which was torn, and the lame, and the sick; thus ye brought an offering: should I accept this of your hand? saith the Lord.

Malachi 1:14 But cursed be the deceiver, which hath in his flock a male, and voweth, and sacrificeth unto the Lord a corrupt thing: for I am a great King, saith the Lord of hosts, and my name is dreadful among the heathen.
