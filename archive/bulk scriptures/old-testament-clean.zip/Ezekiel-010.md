# Ezekiel 10

Ezekiel 10 (summary): He sees in vision, as before, the wheels, the cherubims, and the throne and the glory of God.

Ezekiel 10:1 Then I looked, and, behold, in the firmament that was above the head of the cherubims there appeared over them as it were a sapphire stone, as the appearance of the likeness of a throne.

Ezekiel 10:2 And he spake unto the man clothed with linen, and said, Go in between the wheels, even under the cherub, and fill thine hand with coals of fire from between the cherubims, and scatter them over the city. And he went in in my sight.

Ezekiel 10:3 Now the cherubims stood on the right side of the house, when the man went in; and the cloud filled the inner court.

Ezekiel 10:4 Then the glory of the Lord went up from the cherub, and stood over the threshold of the house; and the house was filled with the cloud, and the court was full of the brightness of the Lord’s glory.

Ezekiel 10:5 And the sound of the cherubims’ wings was heard even to the outer court, as the voice of the Almighty God when he speaketh.

Ezekiel 10:6 And it came to pass, that when he had commanded the man clothed with linen, saying, Take fire from between the wheels, from between the cherubims; then he went in, and stood beside the wheels.

Ezekiel 10:7 And one cherub stretched forth his hand from between the cherubims unto the fire that was between the cherubims, and took thereof, and put it into the hands of him that was clothed with linen: who took it, and went out.

Ezekiel 10:8 And there appeared in the cherubims the form of a man’s hand under their wings.

Ezekiel 10:9 And when I looked, behold the four wheels by the cherubims, one wheel by one cherub, and another wheel by another cherub: and the appearance of the wheels was as the colour of a beryl stone.

Ezekiel 10:10 And as for their appearances, they four had one likeness, as if a wheel had been in the midst of a wheel.

Ezekiel 10:11 When they went, they went upon their four sides; they turned not as they went, but to the place whither the head looked they followed it; they turned not as they went.

Ezekiel 10:12 And their whole body, and their backs, and their hands, and their wings, and the wheels, were full of eyes round about, even the wheels that they four had.

Ezekiel 10:13 As for the wheels, it was cried unto them in my hearing, O wheel.

Ezekiel 10:14 And every one had four faces: the first face was the face of a cherub, and the second face was the face of a man, and the third the face of a lion, and the fourth the face of an eagle.

Ezekiel 10:15 And the cherubims were lifted up. This is the living creature that I saw by the river of Chebar.

Ezekiel 10:16 And when the cherubims went, the wheels went by them: and when the cherubims lifted up their wings to mount up from the earth, the same wheels also turned not from beside them.

Ezekiel 10:17 When they stood, these stood; and when they were lifted up, these lifted up themselves also: for the spirit of the living creature was in them.

Ezekiel 10:18 Then the glory of the Lord departed from off the threshold of the house, and stood over the cherubims.

Ezekiel 10:19 And the cherubims lifted up their wings, and mounted up from the earth in my sight: when they went out, the wheels also were beside them, and every one stood at the door of the east gate of the Lord’s house; and the glory of the God of Israel was over them above.

Ezekiel 10:20 This is the living creature that I saw under the God of Israel by the river of Chebar; and I knew that they were the cherubims.

Ezekiel 10:21 Every one had four faces apiece, and every one four wings; and the likeness of the hands of a man was under their wings.

Ezekiel 10:22 And the likeness of their faces was the same faces which I saw by the river of Chebar, their appearances and themselves: they went every one straight forward.
