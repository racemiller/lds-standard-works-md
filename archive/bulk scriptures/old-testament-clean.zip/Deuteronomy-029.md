# Deuteronomy 29

Deuteronomy 29 (summary): The children of Israel make a covenant with the Lord under which they will be blessed if they are obedient, and cursed if they are disobedient—If they are disobedient, their land will be as brimstone and salt.

Deuteronomy 29:1 These are the words of the covenant, which the Lord commanded Moses to make with the children of Israel in the land of Moab, beside the covenant which he made with them in Horeb.

Deuteronomy 29:2 And Moses called unto all Israel, and said unto them, Ye have seen all that the Lord did before your eyes in the land of Egypt unto Pharaoh, and unto all his servants, and unto all his land;

Deuteronomy 29:3 The great temptations which thine eyes have seen, the signs, and those great miracles:

Deuteronomy 29:4 Yet the Lord hath not given you an heart to perceive, and eyes to see, and ears to hear, unto this day.

Deuteronomy 29:5 And I have led you forty years in the wilderness: your clothes are not waxen old upon you, and thy shoe is not waxen old upon thy foot.

Deuteronomy 29:6 Ye have not eaten bread, neither have ye drunk wine or strong drink: that ye might know that I am the Lord your God.

Deuteronomy 29:7 And when ye came unto this place, Sihon the king of Heshbon, and Og the king of Bashan, came out against us unto battle, and we smote them:

Deuteronomy 29:8 And we took their land, and gave it for an inheritance unto the Reubenites, and to the Gadites, and to the half tribe of Manasseh.

Deuteronomy 29:9 Keep therefore the words of this covenant, and do them, that ye may prosper in all that ye do.

Deuteronomy 29:10 Ye stand this day all of you before the Lord your God; your captains of your tribes, your elders, and your officers, with all the men of Israel,

Deuteronomy 29:11 Your little ones, your wives, and thy stranger that is in thy camp, from the hewer of thy wood unto the drawer of thy water:

Deuteronomy 29:12 That thou shouldest enter into covenant with the Lord thy God, and into his oath, which the Lord thy God maketh with thee this day:

Deuteronomy 29:13 That he may establish thee to day for a people unto himself, and that he may be unto thee a God, as he hath said unto thee, and as he hath sworn unto thy fathers, to Abraham, to Isaac, and to Jacob.

Deuteronomy 29:14 Neither with you only do I make this covenant and this oath;

Deuteronomy 29:15 But with him that standeth here with us this day before the Lord our God, and also with him that is not here with us this day:

Deuteronomy 29:16 (For ye know how we have dwelt in the land of Egypt; and how we came through the nations which ye passed by;

Deuteronomy 29:17 And ye have seen their abominations, and their idols, wood and stone, silver and gold, which were among them:)

Deuteronomy 29:18 Lest there should be among you man, or woman, or family, or tribe, whose heart turneth away this day from the Lord our God, to go and serve the gods of these nations; lest there should be among you a root that beareth gall and wormwood;

Deuteronomy 29:19 And it come to pass, when he heareth the words of this curse, that he bless himself in his heart, saying, I shall have peace, though I walk in the imagination of mine heart, to add drunkenness to thirst:

Deuteronomy 29:20 The Lord will not spare him, but then the anger of the Lord and his jealousy shall smoke against that man, and all the curses that are written in this book shall lie upon him, and the Lord shall blot out his name from under heaven.

Deuteronomy 29:21 And the Lord shall separate him unto evil out of all the tribes of Israel, according to all the curses of the covenant that are written in this book of the law:

Deuteronomy 29:22 So that the generation to come of your children that shall rise up after you, and the stranger that shall come from a far land, shall say, when they see the plagues of that land, and the sicknesses which the Lord hath laid upon it;

Deuteronomy 29:23 And that the whole land thereof is brimstone, and salt, and burning, that it is not sown, nor beareth, nor any grass groweth therein, like the overthrow of Sodom, and Gomorrah, Admah, and Zeboim, which the Lord overthrew in his anger, and in his wrath:

Deuteronomy 29:24 Even all nations shall say, Wherefore hath the Lord done thus unto this land? what meaneth the heat of this great anger?

Deuteronomy 29:25 Then men shall say, Because they have forsaken the covenant of the Lord God of their fathers, which he made with them when he brought them forth out of the land of Egypt:

Deuteronomy 29:26 For they went and served other gods, and worshipped them, gods whom they knew not, and whom he had not given unto them:

Deuteronomy 29:27 And the anger of the Lord was kindled against this land, to bring upon it all the curses that are written in this book:

Deuteronomy 29:28 And the Lord rooted them out of their land in anger, and in wrath, and in great indignation, and cast them into another land, as it is this day.

Deuteronomy 29:29 The secret things belong unto the Lord our God: but those things which are revealed belong unto us and to our children for ever, that we may do all the words of this law.
