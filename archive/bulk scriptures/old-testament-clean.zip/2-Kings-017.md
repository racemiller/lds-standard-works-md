# 2 Kings 17

2 Kings 17 (summary): Hoshea reigns in Israel and is subject to the Assyrians—The Israelites forsake the Lord, worship idols, serve Baal, and reject all that the Lord has given them—The ten tribes are carried away captive by the kings of Assyria—The land of Israel (Samaria) is repopulated by other people—Many forms of false worship are found among the Samaritans.

2 Kings 17:1 In the twelfth year of Ahaz king of Judah began Hoshea the son of Elah to reign in Samaria over Israel nine years.

2 Kings 17:2 And he did that which was evil in the sight of the Lord, but not as the kings of Israel that were before him.

2 Kings 17:3 Against him came up Shalmaneser king of Assyria; and Hoshea became his servant, and gave him presents.

2 Kings 17:4 And the king of Assyria found conspiracy in Hoshea: for he had sent messengers to So king of Egypt, and brought no present to the king of Assyria, as he had done year by year: therefore the king of Assyria shut him up, and bound him in prison.

2 Kings 17:5 Then the king of Assyria came up throughout all the land, and went up to Samaria, and besieged it three years.

2 Kings 17:6 In the ninth year of Hoshea the king of Assyria took Samaria, and carried Israel away into Assyria, and placed them in Halah and in Habor by the river of Gozan, and in the cities of the Medes.

2 Kings 17:7 For so it was, that the children of Israel had sinned against the Lord their God, which had brought them up out of the land of Egypt, from under the hand of Pharaoh king of Egypt, and had feared other gods,

2 Kings 17:8 And walked in the statutes of the heathen, whom the Lord cast out from before the children of Israel, and of the kings of Israel, which they had made.

2 Kings 17:9 And the children of Israel did secretly those things that were not right against the Lord their God, and they built them high places in all their cities, from the tower of the watchmen to the fenced city.

2 Kings 17:10 And they set them up images and groves in every high hill, and under every green tree:

2 Kings 17:11 And there they burnt incense in all the high places, as did the heathen whom the Lord carried away before them; and wrought wicked things to provoke the Lord to anger:

2 Kings 17:12 For they served idols, whereof the Lord had said unto them, Ye shall not do this thing.

2 Kings 17:13 Yet the Lord testified against Israel, and against Judah, by all the prophets, and by all the seers, saying, Turn ye from your evil ways, and keep my commandments and my statutes, according to all the law which I commanded your fathers, and which I sent to you by my servants the prophets.

2 Kings 17:14 Notwithstanding they would not hear, but hardened their necks, like to the neck of their fathers, that did not believe in the Lord their God.

2 Kings 17:15 And they rejected his statutes, and his covenant that he made with their fathers, and his testimonies which he testified against them; and they followed vanity, and became vain, and went after the heathen that were round about them, concerning whom the Lord had charged them, that they should not do like them.

2 Kings 17:16 And they left all the commandments of the Lord their God, and made them molten images, even two calves, and made a grove, and worshipped all the host of heaven, and served Baal.

2 Kings 17:17 And they caused their sons and their daughters to pass through the fire, and used divination and enchantments, and sold themselves to do evil in the sight of the Lord, to provoke him to anger.

2 Kings 17:18 Therefore the Lord was very angry with Israel, and removed them out of his sight: there was none left but the tribe of Judah only.

2 Kings 17:19 Also Judah kept not the commandments of the Lord their God, but walked in the statutes of Israel which they made.

2 Kings 17:20 And the Lord rejected all the seed of Israel, and afflicted them, and delivered them into the hand of spoilers, until he had cast them out of his sight.

2 Kings 17:21 For he rent Israel from the house of David; and they made Jeroboam the son of Nebat king: and Jeroboam drave Israel from following the Lord, and made them sin a great sin.

2 Kings 17:22 For the children of Israel walked in all the sins of Jeroboam which he did; they departed not from them;

2 Kings 17:23 Until the Lord removed Israel out of his sight, as he had said by all his servants the prophets. So was Israel carried away out of their own land to Assyria unto this day.

2 Kings 17:24 And the king of Assyria brought men from Babylon, and from Cuthah, and from Ava, and from Hamath, and from Sepharvaim, and placed them in the cities of Samaria instead of the children of Israel: and they possessed Samaria, and dwelt in the cities thereof.

2 Kings 17:25 And so it was at the beginning of their dwelling there, that they feared not the Lord: therefore the Lord sent lions among them, which slew some of them.

2 Kings 17:26 Wherefore they spake to the king of Assyria, saying, The nations which thou hast removed, and placed in the cities of Samaria, know not the manner of the God of the land: therefore he hath sent lions among them, and, behold, they slay them, because they know not the manner of the God of the land.

2 Kings 17:27 Then the king of Assyria commanded, saying, Carry thither one of the priests whom ye brought from thence; and let them go and dwell there, and let him teach them the manner of the God of the land.

2 Kings 17:28 Then one of the priests whom they had carried away from Samaria came and dwelt in Beth-el, and taught them how they should fear the Lord.

2 Kings 17:29 Howbeit every nation made gods of their own, and put them in the houses of the high places which the Samaritans had made, every nation in their cities wherein they dwelt.

2 Kings 17:30 And the men of Babylon made Succoth-benoth, and the men of Cuth made Nergal, and the men of Hamath made Ashima,

2 Kings 17:31 And the Avites made Nibhaz and Tartak, and the Sepharvites burnt their children in fire to Adrammelech and Anammelech, the gods of Sepharvaim.

2 Kings 17:32 So they feared the Lord, and made unto themselves of the lowest of them priests of the high places, which sacrificed for them in the houses of the high places.

2 Kings 17:33 They feared the Lord, and served their own gods, after the manner of the nations whom they carried away from thence.

2 Kings 17:34 Unto this day they do after the former manners: they fear not the Lord, neither do they after their statutes, or after their ordinances, or after the law and commandment which the Lord commanded the children of Jacob, whom he named Israel;

2 Kings 17:35 With whom the Lord had made a covenant, and charged them, saying, Ye shall not fear other gods, nor bow yourselves to them, nor serve them, nor sacrifice to them:

2 Kings 17:36 But the Lord, who brought you up out of the land of Egypt with great power and a stretched out arm, him shall ye fear, and him shall ye worship, and to him shall ye do sacrifice.

2 Kings 17:37 And the statutes, and the ordinances, and the law, and the commandment, which he wrote for you, ye shall observe to do for evermore; and ye shall not fear other gods.

2 Kings 17:38 And the covenant that I have made with you ye shall not forget; neither shall ye fear other gods.

2 Kings 17:39 But the Lord your God ye shall fear; and he shall deliver you out of the hand of all your enemies.

2 Kings 17:40 Howbeit they did not hearken, but they did after their former manner.

2 Kings 17:41 So these nations feared the Lord, and served their graven images, both their children, and their children’s children: as did their fathers, so do they unto this day.
