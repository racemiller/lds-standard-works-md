# Psalms 26

Psalms 26 (summary): David says that he has walked in integrity and obedience—He loves the Lord’s house.

Psalms 26:1 Judge me, O Lord; for I have walked in mine integrity: I have trusted also in the Lord; therefore I shall not slide.

Psalms 26:2 Examine me, O Lord, and prove me; try my reins and my heart.

Psalms 26:3 For thy lovingkindness is before mine eyes: and I have walked in thy truth.

Psalms 26:4 I have not sat with vain persons, neither will I go in with dissemblers.

Psalms 26:5 I have hated the congregation of evil doers; and will not sit with the wicked.

Psalms 26:6 I will wash mine hands in innocency: so will I compass thine altar, O Lord:

Psalms 26:7 That I may publish with the voice of thanksgiving, and tell of all thy wondrous works.

Psalms 26:8 Lord, I have loved the habitation of thy house, and the place where thine honour dwelleth.

Psalms 26:9 Gather not my soul with sinners, nor my life with bloody men:

Psalms 26:10 In whose hands is mischief, and their right hand is full of bribes.

Psalms 26:11 But as for me, I will walk in mine integrity: redeem me, and be merciful unto me.

Psalms 26:12 My foot standeth in an even place: in the congregations will I bless the Lord.
