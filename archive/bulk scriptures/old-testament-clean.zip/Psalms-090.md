# Psalms 90

Psalms 90 (summary): A prayer of Moses, the man of God—God is from everlasting to everlasting—Man’s days last but seventy years—Moses implores the Lord to give mercy and blessings to His people.

Psalms 90:1 Lord, thou hast been our dwelling place in all generations.

Psalms 90:2 Before the mountains were brought forth, or ever thou hadst formed the earth and the world, even from everlasting to everlasting, thou art God.

Psalms 90:3 Thou turnest man to destruction; and sayest, Return, ye children of men.

Psalms 90:4 For a thousand years in thy sight are but as yesterday when it is past, and as a watch in the night.

Psalms 90:5 Thou carriest them away as with a flood; they are as a sleep: in the morning they are like grass which groweth up.

Psalms 90:6 In the morning it flourisheth, and groweth up; in the evening it is cut down, and withereth.

Psalms 90:7 For we are consumed by thine anger, and by thy wrath are we troubled.

Psalms 90:8 Thou hast set our iniquities before thee, our secret sins in the light of thy countenance.

Psalms 90:9 For all our days are passed away in thy wrath: we spend our years as a tale that is told.

Psalms 90:10 The days of our years are threescore years and ten; and if by reason of strength they be fourscore years, yet is their strength labour and sorrow; for it is soon cut off, and we fly away.

Psalms 90:11 Who knoweth the power of thine anger? even according to thy fear, so is thy wrath.

Psalms 90:12 So teach us to number our days, that we may apply our hearts unto wisdom.

Psalms 90:13 Return, O Lord, how long? and let it repent thee concerning thy servants.

Psalms 90:14 O satisfy us early with thy mercy; that we may rejoice and be glad all our days.

Psalms 90:15 Make us glad according to the days wherein thou hast afflicted us, and the years wherein we have seen evil.

Psalms 90:16 Let thy work appear unto thy servants, and thy glory unto their children.

Psalms 90:17 And let the beauty of the Lord our God be upon us: and establish thou the work of our hands upon us; yea, the work of our hands establish thou it.
