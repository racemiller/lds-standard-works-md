# Isaiah 66

Isaiah 66 (summary): At the Second Coming, Israel, as a nation, will be born in a day; the wicked will be destroyed; and the Gentiles will hear the gospel.

Isaiah 66:1 Thus saith the Lord, The heaven is my throne, and the earth is my footstool: where is the house that ye build unto me? and where is the place of my rest?

Isaiah 66:2 For all those things hath mine hand made, and all those things have been, saith the Lord: but to this man will I look, even to him that is poor and of a contrite spirit, and trembleth at my word.

Isaiah 66:3 He that killeth an ox is as if he slew a man; he that sacrificeth a lamb, as if he cut off a dog’s neck; he that offereth an oblation, as if he offered swine’s blood; he that burneth incense, as if he blessed an idol. Yea, they have chosen their own ways, and their soul delighteth in their abominations.

Isaiah 66:4 I also will choose their delusions, and will bring their fears upon them; because when I called, none did answer; when I spake, they did not hear: but they did evil before mine eyes, and chose that in which I delighted not.

Isaiah 66:5 Hear the word of the Lord, ye that tremble at his word; Your brethren that hated you, that cast you out for my name’s sake, said, Let the Lord be glorified: but he shall appear to your joy, and they shall be ashamed.

Isaiah 66:6 A voice of noise from the city, a voice from the temple, a voice of the Lord that rendereth recompence to his enemies.

Isaiah 66:7 Before she travailed, she brought forth; before her pain came, she was delivered of a man child.

Isaiah 66:8 Who hath heard such a thing? who hath seen such things? Shall the earth be made to bring forth in one day? or shall a nation be born at once? for as soon as Zion travailed, she brought forth her children.

Isaiah 66:9 Shall I bring to the birth, and not cause to bring forth? saith the Lord: shall I cause to bring forth, and shut the womb? saith thy God.

Isaiah 66:10 Rejoice ye with Jerusalem, and be glad with her, all ye that love her: rejoice for joy with her, all ye that mourn for her:

Isaiah 66:11 That ye may suck, and be satisfied with the breasts of her consolations; that ye may milk out, and be delighted with the abundance of her glory.

Isaiah 66:12 For thus saith the Lord, Behold, I will extend peace to her like a river, and the glory of the Gentiles like a flowing stream: then shall ye suck, ye shall be borne upon her sides, and be dandled upon her knees.

Isaiah 66:13 As one whom his mother comforteth, so will I comfort you; and ye shall be comforted in Jerusalem.

Isaiah 66:14 And when ye see this, your heart shall rejoice, and your bones shall flourish like an herb: and the hand of the Lord shall be known toward his servants, and his indignation toward his enemies.

Isaiah 66:15 For, behold, the Lord will come with fire, and with his chariots like a whirlwind, to render his anger with fury, and his rebuke with flames of fire.

Isaiah 66:16 For by fire and by his sword will the Lord plead with all flesh: and the slain of the Lord shall be many.

Isaiah 66:17 They that sanctify themselves, and purify themselves in the gardens behind one tree in the midst, eating swine’s flesh, and the abomination, and the mouse, shall be consumed together, saith the Lord.

Isaiah 66:18 For I know their works and their thoughts: it shall come, that I will gather all nations and tongues; and they shall come, and see my glory.

Isaiah 66:19 And I will set a sign among them, and I will send those that escape of them unto the nations, to Tarshish, Pul, and Lud, that draw the bow, to Tubal, and Javan, to the isles afar off, that have not heard my fame, neither have seen my glory; and they shall declare my glory among the Gentiles.

Isaiah 66:20 And they shall bring all your brethren for an offering unto the Lord out of all nations upon horses, and in chariots, and in litters, and upon mules, and upon swift beasts, to my holy mountain Jerusalem, saith the Lord, as the children of Israel bring an offering in a clean vessel into the house of the Lord.

Isaiah 66:21 And I will also take of them for priests and for Levites, saith the Lord.

Isaiah 66:22 For as the new heavens and the new earth, which I will make, shall remain before me, saith the Lord, so shall your seed and your name remain.

Isaiah 66:23 And it shall come to pass, that from one new moon to another, and from one sabbath to another, shall all flesh come to worship before me, saith the Lord.

Isaiah 66:24 And they shall go forth, and look upon the carcases of the men that have transgressed against me: for their worm shall not die, neither shall their fire be quenched; and they shall be an abhorring unto all flesh.
