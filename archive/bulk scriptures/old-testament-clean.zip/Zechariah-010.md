# Zechariah 10

Zechariah 10 (summary): Judah and Joseph will be scattered among the people in far countries—The Lord will hiss for them, gather them, and redeem them.

Zechariah 10:1 Ask ye of the Lord rain in the time of the latter rain; so the Lord shall make bright clouds, and give them showers of rain, to every one grass in the field.

Zechariah 10:2 For the idols have spoken vanity, and the diviners have seen a lie, and have told false dreams; they comfort in vain: therefore they went their way as a flock, they were troubled, because there was no shepherd.

Zechariah 10:3 Mine anger was kindled against the shepherds, and I punished the goats: for the Lord of hosts hath visited his flock the house of Judah, and hath made them as his goodly horse in the battle.

Zechariah 10:4 Out of him came forth the corner, out of him the nail, out of him the battle bow, out of him every oppressor together.

Zechariah 10:5 And they shall be as mighty men, which tread down their enemies in the mire of the streets in the battle: and they shall fight, because the Lord is with them, and the riders on horses shall be confounded.

Zechariah 10:6 And I will strengthen the house of Judah, and I will save the house of Joseph, and I will bring them again to place them; for I have mercy upon them: and they shall be as though I had not cast them off: for I am the Lord their God, and will hear them.

Zechariah 10:7 And they of Ephraim shall be like a mighty man, and their heart shall rejoice as through wine: yea, their children shall see it, and be glad; their heart shall rejoice in the Lord.

Zechariah 10:8 I will hiss for them, and gather them; for I have redeemed them: and they shall increase as they have increased.

Zechariah 10:9 And I will sow them among the people: and they shall remember me in far countries; and they shall live with their children, and turn again.

Zechariah 10:10 I will bring them again also out of the land of Egypt, and gather them out of Assyria; and I will bring them into the land of Gilead and Lebanon; and place shall not be found for them.

Zechariah 10:11 And he shall pass through the sea with affliction, and shall smite the waves in the sea, and all the deeps of the river shall dry up: and the pride of Assyria shall be brought down, and the sceptre of Egypt shall depart away.

Zechariah 10:12 And I will strengthen them in the Lord; and they shall walk up and down in his name, saith the Lord.
