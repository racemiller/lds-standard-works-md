# Hosea 4

Hosea 4 (summary): Israel loses all truth, mercy, and knowledge of God and goes whoring after false gods.

Hosea 4:1 Hear the word of the Lord, ye children of Israel: for the Lord hath a controversy with the inhabitants of the land, because there is no truth, nor mercy, nor knowledge of God in the land.

Hosea 4:2 By swearing, and lying, and killing, and stealing, and committing adultery, they break out, and blood toucheth blood.

Hosea 4:3 Therefore shall the land mourn, and every one that dwelleth therein shall languish, with the beasts of the field, and with the fowls of heaven; yea, the fishes of the sea also shall be taken away.

Hosea 4:4 Yet let no man strive, nor reprove another: for thy people are as they that strive with the priest.

Hosea 4:5 Therefore shalt thou fall in the day, and the prophet also shall fall with thee in the night, and I will destroy thy mother.

Hosea 4:6 My people are destroyed for lack of knowledge: because thou hast rejected knowledge, I will also reject thee, that thou shalt be no priest to me: seeing thou hast forgotten the law of thy God, I will also forget thy children.

Hosea 4:7 As they were increased, so they sinned against me: therefore will I change their glory into shame.

Hosea 4:8 They eat up the sin of my people, and they set their heart on their iniquity.

Hosea 4:9 And there shall be, like people, like priest: and I will punish them for their ways, and reward them their doings.

Hosea 4:10 For they shall eat, and not have enough: they shall commit whoredom, and shall not increase: because they have left off to take heed to the Lord.

Hosea 4:11 Whoredom and wine and new wine take away the heart.

Hosea 4:12 My people ask counsel at their stocks, and their staff declareth unto them: for the spirit of whoredoms hath caused them to err, and they have gone a whoring from under their God.

Hosea 4:13 They sacrifice upon the tops of the mountains, and burn incense upon the hills, under oaks and poplars and elms, because the shadow thereof is good: therefore your daughters shall commit whoredom, and your spouses shall commit adultery.

Hosea 4:14 I will not punish your daughters when they commit whoredom, nor your spouses when they commit adultery: for themselves are separated with whores, and they sacrifice with harlots: therefore the people that doth not understand shall fall.

Hosea 4:15 Though thou, Israel, play the harlot, yet let not Judah offend; and come not ye unto Gilgal, neither go ye up to Beth-aven, nor swear, The Lord liveth.

Hosea 4:16 For Israel slideth back as a backsliding heifer: now the Lord will feed them as a lamb in a large place.

Hosea 4:17 Ephraim is joined to idols: let him alone.

Hosea 4:18 Their drink is sour: they have committed whoredom continually: her rulers with shame do love, Give ye.

Hosea 4:19 The wind hath bound her up in her wings, and they shall be ashamed because of their sacrifices.
