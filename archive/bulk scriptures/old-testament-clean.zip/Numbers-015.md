# Numbers 15

Numbers 15 (summary): Various sacrificial ordinances bring forgiveness to repentant Israel—Those who sin willfully are cut off from among the people—A man is stoned for gathering sticks on the Sabbath day—The Israelites are to look on the fringes of their garments and remember the commandments.

Numbers 15:1 And the Lord spake unto Moses, saying,

Numbers 15:2 Speak unto the children of Israel, and say unto them, When ye be come into the land of your habitations, which I give unto you,

Numbers 15:3 And will make an offering by fire unto the Lord, a burnt offering, or a sacrifice in performing a vow, or in a freewill offering, or in your solemn feasts, to make a sweet savour unto the Lord, of the herd, or of the flock:

Numbers 15:4 Then shall he that offereth his offering unto the Lord bring a meat offering of a tenth deal of flour mingled with the fourth part of an hin of oil.

Numbers 15:5 And the fourth part of an hin of wine for a drink offering shalt thou prepare with the burnt offering or sacrifice, for one lamb.

Numbers 15:6 Or for a ram, thou shalt prepare for a meat offering two tenth deals of flour mingled with the third part of an hin of oil.

Numbers 15:7 And for a drink offering thou shalt offer the third part of an hin of wine, for a sweet savour unto the Lord.

Numbers 15:8 And when thou preparest a bullock for a burnt offering, or for a sacrifice in performing a vow, or peace offerings unto the Lord:

Numbers 15:9 Then shall he bring with a bullock a meat offering of three tenth deals of flour mingled with half an hin of oil.

Numbers 15:10 And thou shalt bring for a drink offering half an hin of wine, for an offering made by fire, of a sweet savour unto the Lord.

Numbers 15:11 Thus shall it be done for one bullock, or for one ram, or for a lamb, or a kid.

Numbers 15:12 According to the number that ye shall prepare, so shall ye do to every one according to their number.

Numbers 15:13 All that are born of the country shall do these things after this manner, in offering an offering made by fire, of a sweet savour unto the Lord.

Numbers 15:14 And if a stranger sojourn with you, or whosoever be among you in your generations, and will offer an offering made by fire, of a sweet savour unto the Lord; as ye do, so he shall do.

Numbers 15:15 One ordinance shall be both for you of the congregation, and also for the stranger that sojourneth with you, an ordinance for ever in your generations: as ye are, so shall the stranger be before the Lord.

Numbers 15:16 One law and one manner shall be for you, and for the stranger that sojourneth with you.

Numbers 15:17 And the Lord spake unto Moses, saying,

Numbers 15:18 Speak unto the children of Israel, and say unto them, When ye come into the land whither I bring you,

Numbers 15:19 Then it shall be, that, when ye eat of the bread of the land, ye shall offer up an heave offering unto the Lord.

Numbers 15:20 Ye shall offer up a cake of the first of your dough for an heave offering: as ye do the heave offering of the threshingfloor, so shall ye heave it.

Numbers 15:21 Of the first of your dough ye shall give unto the Lord an heave offering in your generations.

Numbers 15:22 And if ye have erred, and not observed all these commandments, which the Lord hath spoken unto Moses,

Numbers 15:23 Even all that the Lord hath commanded you by the hand of Moses, from the day that the Lord commanded Moses, and henceforward among your generations;

Numbers 15:24 Then it shall be, if ought be committed by ignorance without the knowledge of the congregation, that all the congregation shall offer one young bullock for a burnt offering, for a sweet savour unto the Lord, with his meat offering, and his drink offering, according to the manner, and one kid of the goats for a sin offering.

Numbers 15:25 And the priest shall make an atonement for all the congregation of the children of Israel, and it shall be forgiven them; for it is ignorance: and they shall bring their offering, a sacrifice made by fire unto the Lord, and their sin offering before the Lord, for their ignorance:

Numbers 15:26 And it shall be forgiven all the congregation of the children of Israel, and the stranger that sojourneth among them; seeing all the people were in ignorance.

Numbers 15:27 And if any soul sin through ignorance, then he shall bring a she goat of the first year for a sin offering.

Numbers 15:28 And the priest shall make an atonement for the soul that sinneth ignorantly, when he sinneth by ignorance before the Lord, to make an atonement for him; and it shall be forgiven him.

Numbers 15:29 Ye shall have one law for him that sinneth through ignorance, both for him that is born among the children of Israel, and for the stranger that sojourneth among them.

Numbers 15:30 But the soul that doeth ought presumptuously, whether he be born in the land, or a stranger, the same reproacheth the Lord; and that soul shall be cut off from among his people.

Numbers 15:31 Because he hath despised the word of the Lord, and hath broken his commandment, that soul shall utterly be cut off; his iniquity shall be upon him.

Numbers 15:32 And while the children of Israel were in the wilderness, they found a man that gathered sticks upon the sabbath day.

Numbers 15:33 And they that found him gathering sticks brought him unto Moses and Aaron, and unto all the congregation.

Numbers 15:34 And they put him in ward, because it was not declared what should be done to him.

Numbers 15:35 And the Lord said unto Moses, The man shall be surely put to death: all the congregation shall stone him with stones without the camp.

Numbers 15:36 And all the congregation brought him without the camp, and stoned him with stones, and he died; as the Lord commanded Moses.

Numbers 15:37 And the Lord spake unto Moses, saying,

Numbers 15:38 Speak unto the children of Israel, and bid them that they make them fringes in the borders of their garments throughout their generations, and that they put upon the fringe of the borders a ribband of blue:

Numbers 15:39 And it shall be unto you for a fringe, that ye may look upon it, and remember all the commandments of the Lord, and do them; and that ye seek not after your own heart and your own eyes, after which ye use to go a whoring:

Numbers 15:40 That ye may remember, and do all my commandments, and be holy unto your God.

Numbers 15:41 I am the Lord your God, which brought you out of the land of Egypt, to be your God: I am the Lord your God.
