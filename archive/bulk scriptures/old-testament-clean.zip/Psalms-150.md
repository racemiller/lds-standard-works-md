# Psalms 150

Psalms 150 (summary): Praise God in His sanctuary—Let everything that has breath praise the Lord.

Psalms 150:1 Praise ye the Lord. Praise God in his sanctuary: praise him in the firmament of his power.

Psalms 150:2 Praise him for his mighty acts: praise him according to his excellent greatness.

Psalms 150:3 Praise him with the sound of the trumpet: praise him with the psaltery and harp.

Psalms 150:4 Praise him with the timbrel and dance: praise him with stringed instruments and organs.

Psalms 150:5 Praise him upon the loud cymbals: praise him upon the high sounding cymbals.

Psalms 150:6 Let every thing that hath breath praise the Lord. Praise ye the Lord.
