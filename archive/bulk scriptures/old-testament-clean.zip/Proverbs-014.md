# Proverbs 14

Proverbs 14 (summary): Go from the presence of a foolish man—A true witness delivers souls—Righteousness exalts a nation.

Proverbs 14:1 Every wise woman buildeth her house: but the foolish plucketh it down with her hands.

Proverbs 14:2 He that walketh in his uprightness feareth the Lord: but he that is perverse in his ways despiseth him.

Proverbs 14:3 In the mouth of the foolish is a rod of pride: but the lips of the wise shall preserve them.

Proverbs 14:4 Where no oxen are, the crib is clean: but much increase is by the strength of the ox.

Proverbs 14:5 A faithful witness will not lie: but a false witness will utter lies.

Proverbs 14:6 A scorner seeketh wisdom, and findeth it not: but knowledge is easy unto him that understandeth.

Proverbs 14:7 Go from the presence of a foolish man, when thou perceivest not in him the lips of knowledge.

Proverbs 14:8 The wisdom of the prudent is to understand his way: but the folly of fools is deceit.

Proverbs 14:9 Fools make a mock at sin: but among the righteous there is favour.

Proverbs 14:10 The heart knoweth his own bitterness; and a stranger doth not intermeddle with his joy.

Proverbs 14:11 The house of the wicked shall be overthrown: but the tabernacle of the upright shall flourish.

Proverbs 14:12 There is a way which seemeth right unto a man, but the end thereof are the ways of death.

Proverbs 14:13 Even in laughter the heart is sorrowful; and the end of that mirth is heaviness.

Proverbs 14:14 The backslider in heart shall be filled with his own ways: and a good man shall be satisfied from himself.

Proverbs 14:15 The simple believeth every word: but the prudent man looketh well to his going.

Proverbs 14:16 A wise man feareth, and departeth from evil: but the fool rageth, and is confident.

Proverbs 14:17 He that is soon angry dealeth foolishly: and a man of wicked devices is hated.

Proverbs 14:18 The simple inherit folly: but the prudent are crowned with knowledge.

Proverbs 14:19 The evil bow before the good; and the wicked at the gates of the righteous.

Proverbs 14:20 The poor is hated even of his own neighbour: but the rich hath many friends.

Proverbs 14:21 He that despiseth his neighbour sinneth: but he that hath mercy on the poor, happy is he.

Proverbs 14:22 Do they not err that devise evil? but mercy and truth shall be to them that devise good.

Proverbs 14:23 In all labour there is profit: but the talk of the lips tendeth only to penury.

Proverbs 14:24 The crown of the wise is their riches: but the foolishness of fools is folly.

Proverbs 14:25 A true witness delivereth souls: but a deceitful witness speaketh lies.

Proverbs 14:26 In the fear of the Lord is strong confidence: and his children shall have a place of refuge.

Proverbs 14:27 The fear of the Lord is a fountain of life, to depart from the snares of death.

Proverbs 14:28 In the multitude of people is the king’s honour: but in the want of people is the destruction of the prince.

Proverbs 14:29 He that is slow to wrath is of great understanding: but he that is hasty of spirit exalteth folly.

Proverbs 14:30 A sound heart is the life of the flesh: but envy the rottenness of the bones.

Proverbs 14:31 He that oppresseth the poor reproacheth his Maker: but he that honoureth him hath mercy on the poor.

Proverbs 14:32 The wicked is driven away in his wickedness: but the righteous hath hope in his death.

Proverbs 14:33 Wisdom resteth in the heart of him that hath understanding: but that which is in the midst of fools is made known.

Proverbs 14:34 Righteousness exalteth a nation: but sin is a reproach to any people.

Proverbs 14:35 The king’s favour is toward a wise servant: but his wrath is against him that causeth shame.
