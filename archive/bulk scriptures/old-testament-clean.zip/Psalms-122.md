# Psalms 122

Psalms 122 (summary): David says, Go into the house of the Lord—Give thanks unto Him.

Psalms 122:1 I was glad when they said unto me, Let us go into the house of the Lord.

Psalms 122:2 Our feet shall stand within thy gates, O Jerusalem.

Psalms 122:3 Jerusalem is builded as a city that is compact together:

Psalms 122:4 Whither the tribes go up, the tribes of the Lord, unto the testimony of Israel, to give thanks unto the name of the Lord.

Psalms 122:5 For there are set thrones of judgment, the thrones of the house of David.

Psalms 122:6 Pray for the peace of Jerusalem: they shall prosper that love thee.

Psalms 122:7 Peace be within thy walls, and prosperity within thy palaces.

Psalms 122:8 For my brethren and companions’ sakes, I will now say, Peace be within thee.

Psalms 122:9 Because of the house of the Lord our God I will seek thy good.
