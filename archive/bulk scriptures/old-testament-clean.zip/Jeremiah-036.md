# Jeremiah 36

Jeremiah 36 (summary): Baruch writes the prophecies of Jeremiah and reads them in the house of the Lord—Jehoiakim, the king, burns the book, and judgment comes upon him—Jeremiah dictates the prophecies again and adds many more.

Jeremiah 36:1 And it came to pass in the fourth year of Jehoiakim the son of Josiah king of Judah, that this word came unto Jeremiah from the Lord, saying,

Jeremiah 36:2 Take thee a roll of a book, and write therein all the words that I have spoken unto thee against Israel, and against Judah, and against all the nations, from the day I spake unto thee, from the days of Josiah, even unto this day.

Jeremiah 36:3 It may be that the house of Judah will hear all the evil which I purpose to do unto them; that they may return every man from his evil way; that I may forgive their iniquity and their sin.

Jeremiah 36:4 Then Jeremiah called Baruch the son of Neriah: and Baruch wrote from the mouth of Jeremiah all the words of the Lord, which he had spoken unto him, upon a roll of a book.

Jeremiah 36:5 And Jeremiah commanded Baruch, saying, I am shut up; I cannot go into the house of the Lord:

Jeremiah 36:6 Therefore go thou, and read in the roll, which thou hast written from my mouth, the words of the Lord in the ears of the people in the Lord’s house upon the fasting day: and also thou shalt read them in the ears of all Judah that come out of their cities.

Jeremiah 36:7 It may be they will present their supplication before the Lord, and will return every one from his evil way: for great is the anger and the fury that the Lord hath pronounced against this people.

Jeremiah 36:8 And Baruch the son of Neriah did according to all that Jeremiah the prophet commanded him, reading in the book the words of the Lord in the Lord’s house.

Jeremiah 36:9 And it came to pass in the fifth year of Jehoiakim the son of Josiah king of Judah, in the ninth month, that they proclaimed a fast before the Lord to all the people in Jerusalem, and to all the people that came from the cities of Judah unto Jerusalem.

Jeremiah 36:10 Then read Baruch in the book the words of Jeremiah in the house of the Lord, in the chamber of Gemariah the son of Shaphan the scribe, in the higher court, at the entry of the new gate of the Lord’s house, in the ears of all the people.

Jeremiah 36:11 When Michaiah the son of Gemariah, the son of Shaphan, had heard out of the book all the words of the Lord,

Jeremiah 36:12 Then he went down into the king’s house, into the scribe’s chamber: and, lo, all the princes sat there, even Elishama the scribe, and Delaiah the son of Shemaiah, and Elnathan the son of Achbor, and Gemariah the son of Shaphan, and Zedekiah the son of Hananiah, and all the princes.

Jeremiah 36:13 Then Michaiah declared unto them all the words that he had heard, when Baruch read the book in the ears of the people.

Jeremiah 36:14 Therefore all the princes sent Jehudi the son of Nethaniah, the son of Shelemiah, the son of Cushi, unto Baruch, saying, Take in thine hand the roll wherein thou hast read in the ears of the people, and come. So Baruch the son of Neriah took the roll in his hand, and came unto them.

Jeremiah 36:15 And they said unto him, Sit down now, and read it in our ears. So Baruch read it in their ears.

Jeremiah 36:16 Now it came to pass, when they had heard all the words, they were afraid both one and other, and said unto Baruch, We will surely tell the king of all these words.

Jeremiah 36:17 And they asked Baruch, saying, Tell us now, How didst thou write all these words at his mouth?

Jeremiah 36:18 Then Baruch answered them, He pronounced all these words unto me with his mouth, and I wrote them with ink in the book.

Jeremiah 36:19 Then said the princes unto Baruch, Go, hide thee, thou and Jeremiah; and let no man know where ye be.

Jeremiah 36:20 And they went in to the king into the court, but they laid up the roll in the chamber of Elishama the scribe, and told all the words in the ears of the king.

Jeremiah 36:21 So the king sent Jehudi to fetch the roll: and he took it out of Elishama the scribe’s chamber. And Jehudi read it in the ears of the king, and in the ears of all the princes which stood beside the king.

Jeremiah 36:22 Now the king sat in the winterhouse in the ninth month: and there was a fire on the hearth burning before him.

Jeremiah 36:23 And it came to pass, that when Jehudi had read three or four leaves, he cut it with the penknife, and cast it into the fire that was on the hearth, until all the roll was consumed in the fire that was on the hearth.

Jeremiah 36:24 Yet they were not afraid, nor rent their garments, neither the king, nor any of his servants that heard all these words.

Jeremiah 36:25 Nevertheless Elnathan and Delaiah and Gemariah had made intercession to the king that he would not burn the roll: but he would not hear them.

Jeremiah 36:26 But the king commanded Jerahmeel the son of Hammelech, and Seraiah the son of Azriel, and Shelemiah the son of Abdeel, to take Baruch the scribe and Jeremiah the prophet: but the Lord hid them.

Jeremiah 36:27 Then the word of the Lord came to Jeremiah, after that the king had burned the roll, and the words which Baruch wrote at the mouth of Jeremiah, saying,

Jeremiah 36:28 Take thee again another roll, and write in it all the former words that were in the first roll, which Jehoiakim the king of Judah hath burned.

Jeremiah 36:29 And thou shalt say to Jehoiakim king of Judah, Thus saith the Lord; Thou hast burned this roll, saying, Why hast thou written therein, saying, The king of Babylon shall certainly come and destroy this land, and shall cause to cease from thence man and beast?

Jeremiah 36:30 Therefore thus saith the Lord of Jehoiakim king of Judah; He shall have none to sit upon the throne of David: and his dead body shall be cast out in the day to the heat, and in the night to the frost.

Jeremiah 36:31 And I will punish him and his seed and his servants for their iniquity; and I will bring upon them, and upon the inhabitants of Jerusalem, and upon the men of Judah, all the evil that I have pronounced against them; but they hearkened not.

Jeremiah 36:32 Then took Jeremiah another roll, and gave it to Baruch the scribe, the son of Neriah; who wrote therein from the mouth of Jeremiah all the words of the book which Jehoiakim king of Judah had burned in the fire: and there were added besides unto them many like words.
