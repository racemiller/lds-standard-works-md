# Psalms 3

Psalms 3 (summary): David cries unto the Lord and is heard—Salvation is of the Lord.

Psalms 3:1 Lord, how are they increased that trouble me! many are they that rise up against me.

Psalms 3:2 Many there be which say of my soul, There is no help for him in God. Selah.

Psalms 3:3 But thou, O Lord, art a shield for me; my glory, and the lifter up of mine head.

Psalms 3:4 I cried unto the Lord with my voice, and he heard me out of his holy hill. Selah.

Psalms 3:5 I laid me down and slept; I awaked; for the Lord sustained me.

Psalms 3:6 I will not be afraid of ten thousands of people, that have set themselves against me round about.

Psalms 3:7 Arise, O Lord; save me, O my God: for thou hast smitten all mine enemies upon the cheek bone; thou hast broken the teeth of the ungodly.

Psalms 3:8 Salvation belongeth unto the Lord: thy blessing is upon thy people. Selah.
