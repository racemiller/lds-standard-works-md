# Psalms 132

Psalms 132 (summary): A messianic psalm—Of the fruit of David’s loins will the Lord set One upon His throne—The Lord will bless Zion, and her Saints will shout for joy.

Psalms 132:1 Lord, remember David, and all his afflictions:

Psalms 132:2 How he sware unto the Lord, and vowed unto the mighty God of Jacob;

Psalms 132:3 Surely I will not come into the tabernacle of my house, nor go up into my bed;

Psalms 132:4 I will not give sleep to mine eyes, or slumber to mine eyelids,

Psalms 132:5 Until I find out a place for the Lord, an habitation for the mighty God of Jacob.

Psalms 132:6 Lo, we heard of it at Ephratah: we found it in the fields of the wood.

Psalms 132:7 We will go into his tabernacles: we will worship at his footstool.

Psalms 132:8 Arise, O Lord, into thy rest; thou, and the ark of thy strength.

Psalms 132:9 Let thy priests be clothed with righteousness; and let thy saints shout for joy.

Psalms 132:10 For thy servant David’s sake turn not away the face of thine anointed.

Psalms 132:11 The Lord hath sworn in truth unto David; he will not turn from it; Of the fruit of thy body will I set upon thy throne.

Psalms 132:12 If thy children will keep my covenant and my testimony that I shall teach them, their children shall also sit upon thy throne for evermore.

Psalms 132:13 For the Lord hath chosen Zion; he hath desired it for his habitation.

Psalms 132:14 This is my rest for ever: here will I dwell; for I have desired it.

Psalms 132:15 I will abundantly bless her provision: I will satisfy her poor with bread.

Psalms 132:16 I will also clothe her priests with salvation: and her saints shall shout aloud for joy.

Psalms 132:17 There will I make the horn of David to bud: I have ordained a lamp for mine anointed.

Psalms 132:18 His enemies will I clothe with shame: but upon himself shall his crown flourish.
