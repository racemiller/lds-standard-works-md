# Jonah 1

Jonah 1 (summary): Jonah is sent to call Nineveh to repentance—He flees on a ship, is cast into the sea, and is swallowed by a great fish.

Jonah 1:1 Now the word of the Lord came unto Jonah the son of Amittai, saying,

Jonah 1:2 Arise, go to Nineveh, that great city, and cry against it; for their wickedness is come up before me.

Jonah 1:3 But Jonah rose up to flee unto Tarshish from the presence of the Lord, and went down to Joppa; and he found a ship going to Tarshish: so he paid the fare thereof, and went down into it, to go with them unto Tarshish from the presence of the Lord.

Jonah 1:4 But the Lord sent out a great wind into the sea, and there was a mighty tempest in the sea, so that the ship was like to be broken.

Jonah 1:5 Then the mariners were afraid, and cried every man unto his god, and cast forth the wares that were in the ship into the sea, to lighten it of them. But Jonah was gone down into the sides of the ship; and he lay, and was fast asleep.

Jonah 1:6 So the shipmaster came to him, and said unto him, What meanest thou, O sleeper? arise, call upon thy God, if so be that God will think upon us, that we perish not.

Jonah 1:7 And they said every one to his fellow, Come, and let us cast lots, that we may know for whose cause this evil is upon us. So they cast lots, and the lot fell upon Jonah.

Jonah 1:8 Then said they unto him, Tell us, we pray thee, for whose cause this evil is upon us; What is thine occupation? and whence comest thou? what is thy country? and of what people art thou?

Jonah 1:9 And he said unto them, I am an Hebrew; and I fear the Lord, the God of heaven, which hath made the sea and the dry land.

Jonah 1:10 Then were the men exceedingly afraid, and said unto him, Why hast thou done this? For the men knew that he fled from the presence of the Lord, because he had told them.

Jonah 1:11 Then said they unto him, What shall we do unto thee, that the sea may be calm unto us? for the sea wrought, and was tempestuous.

Jonah 1:12 And he said unto them, Take me up, and cast me forth into the sea; so shall the sea be calm unto you: for I know that for my sake this great tempest is upon you.

Jonah 1:13 Nevertheless the men rowed hard to bring it to the land; but they could not: for the sea wrought, and was tempestuous against them.

Jonah 1:14 Wherefore they cried unto the Lord, and said, We beseech thee, O Lord, we beseech thee, let us not perish for this man’s life, and lay not upon us innocent blood: for thou, O Lord, hast done as it pleased thee.

Jonah 1:15 So they took up Jonah, and cast him forth into the sea: and the sea ceased from her raging.

Jonah 1:16 Then the men feared the Lord exceedingly, and offered a sacrifice unto the Lord, and made vows.

Jonah 1:17 Now the Lord had prepared a great fish to swallow up Jonah. And Jonah was in the belly of the fish three days and three nights.
