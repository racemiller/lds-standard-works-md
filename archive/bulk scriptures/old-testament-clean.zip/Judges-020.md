# Judges 20

Judges 20 (summary): All Israel arises against the Benjamites, who refuse to deliver up the men of Gibeah—The Benjamites are smitten and destroyed.

Judges 20:1 Then all the children of Israel went out, and the congregation was gathered together as one man, from Dan even to Beer-sheba, with the land of Gilead, unto the Lord in Mizpeh.

Judges 20:2 And the chief of all the people, even of all the tribes of Israel, presented themselves in the assembly of the people of God, four hundred thousand footmen that drew sword.

Judges 20:3 (Now the children of Benjamin heard that the children of Israel were gone up to Mizpeh.) Then said the children of Israel, Tell us, how was this wickedness?

Judges 20:4 And the Levite, the husband of the woman that was slain, answered and said, I came into Gibeah that belongeth to Benjamin, I and my concubine, to lodge.

Judges 20:5 And the men of Gibeah rose against me, and beset the house round about upon me by night, and thought to have slain me: and my concubine have they forced, that she is dead.

Judges 20:6 And I took my concubine, and cut her in pieces, and sent her throughout all the country of the inheritance of Israel: for they have committed lewdness and folly in Israel.

Judges 20:7 Behold, ye are all children of Israel; give here your advice and counsel.

Judges 20:8 And all the people arose as one man, saying, We will not any of us go to his tent, neither will we any of us turn into his house.

Judges 20:9 But now this shall be the thing which we will do to Gibeah; we will go up by lot against it;

Judges 20:10 And we will take ten men of an hundred throughout all the tribes of Israel, and an hundred of a thousand, and a thousand out of ten thousand, to fetch victual for the people, that they may do, when they come to Gibeah of Benjamin, according to all the folly that they have wrought in Israel.

Judges 20:11 So all the men of Israel were gathered against the city, knit together as one man.

Judges 20:12 And the tribes of Israel sent men through all the tribe of Benjamin, saying, What wickedness is this that is done among you?

Judges 20:13 Now therefore deliver us the men, the children of Belial, which are in Gibeah, that we may put them to death, and put away evil from Israel. But the children of Benjamin would not hearken to the voice of their brethren the children of Israel:

Judges 20:14 But the children of Benjamin gathered themselves together out of the cities unto Gibeah, to go out to battle against the children of Israel.

Judges 20:15 And the children of Benjamin were numbered at that time out of the cities twenty and six thousand men that drew sword, beside the inhabitants of Gibeah, which were numbered seven hundred chosen men.

Judges 20:16 Among all this people there were seven hundred chosen men lefthanded; every one could sling stones at an hair breadth, and not miss.

Judges 20:17 And the men of Israel, beside Benjamin, were numbered four hundred thousand men that drew sword: all these were men of war.

Judges 20:18 And the children of Israel arose, and went up to the house of God, and asked counsel of God, and said, Which of us shall go up first to the battle against the children of Benjamin? And the Lord said, Judah shall go up first.

Judges 20:19 And the children of Israel rose up in the morning, and encamped against Gibeah.

Judges 20:20 And the men of Israel went out to battle against Benjamin; and the men of Israel put themselves in array to fight against them at Gibeah.

Judges 20:21 And the children of Benjamin came forth out of Gibeah, and destroyed down to the ground of the Israelites that day twenty and two thousand men.

Judges 20:22 And the people the men of Israel encouraged themselves, and set their battle again in array in the place where they put themselves in array the first day.

Judges 20:23 (And the children of Israel went up and wept before the Lord until even, and asked counsel of the Lord, saying, Shall I go up again to battle against the children of Benjamin my brother? And the Lord said, Go up against him.)

Judges 20:24 And the children of Israel came near against the children of Benjamin the second day.

Judges 20:25 And Benjamin went forth against them out of Gibeah the second day, and destroyed down to the ground of the children of Israel again eighteen thousand men; all these drew the sword.

Judges 20:26 Then all the children of Israel, and all the people, went up, and came unto the house of God, and wept, and sat there before the Lord, and fasted that day until even, and offered burnt offerings and peace offerings before the Lord.

Judges 20:27 And the children of Israel inquired of the Lord, (for the ark of the covenant of God was there in those days,

Judges 20:28 And Phinehas, the son of Eleazar, the son of Aaron, stood before it in those days,) saying, Shall I yet again go out to battle against the children of Benjamin my brother, or shall I cease? And the Lord said, Go up; for to morrow I will deliver them into thine hand.

Judges 20:29 And Israel set liers in wait round about Gibeah.

Judges 20:30 And the children of Israel went up against the children of Benjamin on the third day, and put themselves in array against Gibeah, as at other times.

Judges 20:31 And the children of Benjamin went out against the people, and were drawn away from the city; and they began to smite of the people, and kill, as at other times, in the highways, of which one goeth up to the house of God, and the other to Gibeah in the field, about thirty men of Israel.

Judges 20:32 And the children of Benjamin said, They are smitten down before us, as at the first. But the children of Israel said, Let us flee, and draw them from the city unto the highways.

Judges 20:33 And all the men of Israel rose up out of their place, and put themselves in array at Baal-tamar: and the liers in wait of Israel came forth out of their places, even out of the meadows of Gibeah.

Judges 20:34 And there came against Gibeah ten thousand chosen men out of all Israel, and the battle was sore: but they knew not that evil was near them.

Judges 20:35 And the Lord smote Benjamin before Israel: and the children of Israel destroyed of the Benjamites that day twenty and five thousand and an hundred men: all these drew the sword.

Judges 20:36 So the children of Benjamin saw that they were smitten: for the men of Israel gave place to the Benjamites, because they trusted unto the liers in wait which they had set beside Gibeah.

Judges 20:37 And the liers in wait hasted, and rushed upon Gibeah; and the liers in wait drew themselves along, and smote all the city with the edge of the sword.

Judges 20:38 Now there was an appointed sign between the men of Israel and the liers in wait, that they should make a great flame with smoke rise up out of the city.

Judges 20:39 And when the men of Israel retired in the battle, Benjamin began to smite and kill of the men of Israel about thirty persons: for they said, Surely they are smitten down before us, as in the first battle.

Judges 20:40 But when the flame began to arise up out of the city with a pillar of smoke, the Benjamites looked behind them, and, behold, the flame of the city ascended up to heaven.

Judges 20:41 And when the men of Israel turned again, the men of Benjamin were amazed: for they saw that evil was come upon them.

Judges 20:42 Therefore they turned their backs before the men of Israel unto the way of the wilderness; but the battle overtook them; and them which came out of the cities they destroyed in the midst of them.

Judges 20:43 Thus they inclosed the Benjamites round about, and chased them, and trode them down with ease over against Gibeah toward the sunrising.

Judges 20:44 And there fell of Benjamin eighteen thousand men; all these were men of valour.

Judges 20:45 And they turned and fled toward the wilderness unto the rock of Rimmon: and they gleaned of them in the highways five thousand men; and pursued hard after them unto Gidom, and slew two thousand men of them.

Judges 20:46 So that all which fell that day of Benjamin were twenty and five thousand men that drew the sword; all these were men of valour.

Judges 20:47 But six hundred men turned and fled to the wilderness unto the rock Rimmon, and abode in the rock Rimmon four months.

Judges 20:48 And the men of Israel turned again upon the children of Benjamin, and smote them with the edge of the sword, as well the men of every city, as the beast, and all that came to hand: also they set on fire all the cities that they came to.
