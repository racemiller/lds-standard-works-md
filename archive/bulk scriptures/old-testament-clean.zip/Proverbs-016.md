# Proverbs 16

Proverbs 16 (summary): It is better to get wisdom than gold—Pride goes before destruction—The gray hair of the righteous person is a crown of glory.

Proverbs 16:1 The preparations of the heart in man, and the answer of the tongue, is from the Lord.

Proverbs 16:2 All the ways of a man are clean in his own eyes; but the Lord weigheth the spirits.

Proverbs 16:3 Commit thy works unto the Lord, and thy thoughts shall be established.

Proverbs 16:4 The Lord hath made all things for himself: yea, even the wicked for the day of evil.

Proverbs 16:5 Every one that is proud in heart is an abomination to the Lord: though hand join in hand, he shall not be unpunished.

Proverbs 16:6 By mercy and truth iniquity is purged: and by the fear of the Lord men depart from evil.

Proverbs 16:7 When a man’s ways please the Lord, he maketh even his enemies to be at peace with him.

Proverbs 16:8 Better is a little with righteousness than great revenues without right.

Proverbs 16:9 A man’s heart deviseth his way: but the Lord directeth his steps.

Proverbs 16:10 A divine sentence is in the lips of the king: his mouth transgresseth not in judgment.

Proverbs 16:11 A just weight and balance are the Lord’s: all the weights of the bag are his work.

Proverbs 16:12 It is an abomination to kings to commit wickedness: for the throne is established by righteousness.

Proverbs 16:13 Righteous lips are the delight of kings; and they love him that speaketh right.

Proverbs 16:14 The wrath of a king is as messengers of death: but a wise man will pacify it.

Proverbs 16:15 In the light of the king’s countenance is life; and his favour is as a cloud of the latter rain.

Proverbs 16:16 How much better is it to get wisdom than gold! and to get understanding rather to be chosen than silver!

Proverbs 16:17 The highway of the upright is to depart from evil: he that keepeth his way preserveth his soul.

Proverbs 16:18 Pride goeth before destruction, and an haughty spirit before a fall.

Proverbs 16:19 Better it is to be of an humble spirit with the lowly, than to divide the spoil with the proud.

Proverbs 16:20 He that handleth a matter wisely shall find good: and whoso trusteth in the Lord, happy is he.

Proverbs 16:21 The wise in heart shall be called prudent: and the sweetness of the lips increaseth learning.

Proverbs 16:22 Understanding is a wellspring of life unto him that hath it: but the instruction of fools is folly.

Proverbs 16:23 The heart of the wise teacheth his mouth, and addeth learning to his lips.

Proverbs 16:24 Pleasant words are as an honeycomb, sweet to the soul, and health to the bones.

Proverbs 16:25 There is a way that seemeth right unto a man, but the end thereof are the ways of death.

Proverbs 16:26 He that laboureth laboureth for himself; for his mouth craveth it of him.

Proverbs 16:27 An ungodly man diggeth up evil: and in his lips there is as a burning fire.

Proverbs 16:28 A froward man soweth strife: and a whisperer separateth chief friends.

Proverbs 16:29 A violent man enticeth his neighbour, and leadeth him into the way that is not good.

Proverbs 16:30 He shutteth his eyes to devise froward things: moving his lips he bringeth evil to pass.

Proverbs 16:31 The hoary head is a crown of glory, if it be found in the way of righteousness.

Proverbs 16:32 He that is slow to anger is better than the mighty; and he that ruleth his spirit than he that taketh a city.

Proverbs 16:33 The lot is cast into the lap; but the whole disposing thereof is of the Lord.
