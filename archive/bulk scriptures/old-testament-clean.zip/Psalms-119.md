# Psalms 119

Psalms 119 (summary): ## א Aleph

Psalms 119:1 Blessed are the undefiled in the way, who walk in the law of the Lord.

Psalms 119:2 Blessed are they that keep his testimonies, and that seek him with the whole heart.

Psalms 119:3 They also do no iniquity: they walk in his ways.

Psalms 119:4 Thou hast commanded us to keep thy precepts diligently.

Psalms 119:5 O that my ways were directed to keep thy statutes!

Psalms 119:6 Then shall I not be ashamed, when I have respect unto all thy commandments.

Psalms 119:7 I will praise thee with uprightness of heart, when I shall have learned thy righteous judgments.

Psalms 119:8 I will keep thy statutes: O forsake me not utterly.

Psalms 119:9 Wherewithal shall a young man cleanse his way? by taking heed thereto according to thy word.

Psalms 119:10 With my whole heart have I sought thee: O let me not wander from thy commandments.

Psalms 119:11 Thy word have I hid in mine heart, that I might not sin against thee.

Psalms 119:12 Blessed art thou, O Lord: teach me thy statutes.

Psalms 119:13 With my lips have I declared all the judgments of thy mouth.

Psalms 119:14 I have rejoiced in the way of thy testimonies, as much as in all riches.

Psalms 119:15 I will meditate in thy precepts, and have respect unto thy ways.

Psalms 119:16 I will delight myself in thy statutes: I will not forget thy word.

Psalms 119:17 Deal bountifully with thy servant, that I may live, and keep thy word.

Psalms 119:18 Open thou mine eyes, that I may behold wondrous things out of thy law.

Psalms 119:19 I am a stranger in the earth: hide not thy commandments from me.

Psalms 119:20 My soul breaketh for the longing that it hath unto thy judgments at all times.

Psalms 119:21 Thou hast rebuked the proud that are cursed, which do err from thy commandments.

Psalms 119:22 Remove from me reproach and contempt; for I have kept thy testimonies.

Psalms 119:23 Princes also did sit and speak against me: but thy servant did meditate in thy statutes.

Psalms 119:24 Thy testimonies also are my delight and my counsellors.

Psalms 119:25 My soul cleaveth unto the dust: quicken thou me according to thy word.

Psalms 119:26 I have declared my ways, and thou heardest me: teach me thy statutes.

Psalms 119:27 Make me to understand the way of thy precepts: so shall I talk of thy wondrous works.

Psalms 119:28 My soul melteth for heaviness: strengthen thou me according unto thy word.

Psalms 119:29 Remove from me the way of lying: and grant me thy law graciously.

Psalms 119:30 I have chosen the way of truth: thy judgments have I laid before me.

Psalms 119:31 I have stuck unto thy testimonies: O Lord, put me not to shame.

Psalms 119:32 I will run the way of thy commandments, when thou shalt enlarge my heart.

Psalms 119:33 Teach me, O Lord, the way of thy statutes; and I shall keep it unto the end.

Psalms 119:34 Give me understanding, and I shall keep thy law; yea, I shall observe it with my whole heart.

Psalms 119:35 Make me to go in the path of thy commandments; for therein do I delight.

Psalms 119:36 Incline my heart unto thy testimonies, and not to covetousness.

Psalms 119:37 Turn away mine eyes from beholding vanity; and quicken thou me in thy way.

Psalms 119:38 Stablish thy word unto thy servant, who is devoted to thy fear.

Psalms 119:39 Turn away my reproach which I fear: for thy judgments are good.

Psalms 119:40 Behold, I have longed after thy precepts: quicken me in thy righteousness.

Psalms 119:41 Let thy mercies come also unto me, O Lord, even thy salvation, according to thy word.

Psalms 119:42 So shall I have wherewith to answer him that reproacheth me: for I trust in thy word.

Psalms 119:43 And take not the word of truth utterly out of my mouth; for I have hoped in thy judgments.

Psalms 119:44 So shall I keep thy law continually for ever and ever.

Psalms 119:45 And I will walk at liberty: for I seek thy precepts.

Psalms 119:46 I will speak of thy testimonies also before kings, and will not be ashamed.

Psalms 119:47 And I will delight myself in thy commandments, which I have loved.

Psalms 119:48 My hands also will I lift up unto thy commandments, which I have loved; and I will meditate in thy statutes.

Psalms 119:49 Remember the word unto thy servant, upon which thou hast caused me to hope.

Psalms 119:50 This is my comfort in my affliction: for thy word hath quickened me.

Psalms 119:51 The proud have had me greatly in derision: yet have I not declined from thy law.

Psalms 119:52 I remembered thy judgments of old, O Lord; and have comforted myself.

Psalms 119:53 Horror hath taken hold upon me because of the wicked that forsake thy law.

Psalms 119:54 Thy statutes have been my songs in the house of my pilgrimage.

Psalms 119:55 I have remembered thy name, O Lord, in the night, and have kept thy law.

Psalms 119:56 This I had, because I kept thy precepts.

Psalms 119:57 Thou art my portion, O Lord: I have said that I would keep thy words.

Psalms 119:58 I entreated thy favour with my whole heart: be merciful unto me according to thy word.

Psalms 119:59 I thought on my ways, and turned my feet unto thy testimonies.

Psalms 119:60 I made haste, and delayed not to keep thy commandments.

Psalms 119:61 The bands of the wicked have robbed me: but I have not forgotten thy law.

Psalms 119:62 At midnight I will rise to give thanks unto thee because of thy righteous judgments.

Psalms 119:63 I am a companion of all them that fear thee, and of them that keep thy precepts.

Psalms 119:64 The earth, O Lord, is full of thy mercy: teach me thy statutes.

Psalms 119:65 Thou hast dealt well with thy servant, O Lord, according unto thy word.

Psalms 119:66 Teach me good judgment and knowledge: for I have believed thy commandments.

Psalms 119:67 Before I was afflicted I went astray: but now have I kept thy word.

Psalms 119:68 Thou art good, and doest good; teach me thy statutes.

Psalms 119:69 The proud have forged a lie against me: but I will keep thy precepts with my whole heart.

Psalms 119:70 Their heart is as fat as grease; but I delight in thy law.

Psalms 119:71 It is good for me that I have been afflicted; that I might learn thy statutes.

Psalms 119:72 The law of thy mouth is better unto me than thousands of gold and silver.

Psalms 119:73 Thy hands have made me and fashioned me: give me understanding, that I may learn thy commandments.

Psalms 119:74 They that fear thee will be glad when they see me; because I have hoped in thy word.

Psalms 119:75 I know, O Lord, that thy judgments are right, and that thou in faithfulness hast afflicted me.

Psalms 119:76 Let, I pray thee, thy merciful kindness be for my comfort, according to thy word unto thy servant.

Psalms 119:77 Let thy tender mercies come unto me, that I may live: for thy law is my delight.

Psalms 119:78 Let the proud be ashamed; for they dealt perversely with me without a cause: but I will meditate in thy precepts.

Psalms 119:79 Let those that fear thee turn unto me, and those that have known thy testimonies.

Psalms 119:80 Let my heart be sound in thy statutes; that I be not ashamed.

Psalms 119:81 My soul fainteth for thy salvation: but I hope in thy word.

Psalms 119:82 Mine eyes fail for thy word, saying, When wilt thou comfort me?

Psalms 119:83 For I am become like a bottle in the smoke; yet do I not forget thy statutes.

Psalms 119:84 How many are the days of thy servant? when wilt thou execute judgment on them that persecute me?

Psalms 119:85 The proud have digged pits for me, which are not after thy law.

Psalms 119:86 All thy commandments are faithful: they persecute me wrongfully; help thou me.

Psalms 119:87 They had almost consumed me upon earth; but I forsook not thy precepts.

Psalms 119:88 Quicken me after thy lovingkindness; so shall I keep the testimony of thy mouth.

Psalms 119:89 For ever, O Lord, thy word is settled in heaven.

Psalms 119:90 Thy faithfulness is unto all generations: thou hast established the earth, and it abideth.

Psalms 119:91 They continue this day according to thine ordinances: for all are thy servants.

Psalms 119:92 Unless thy law had been my delights, I should then have perished in mine affliction.

Psalms 119:93 I will never forget thy precepts: for with them thou hast quickened me.

Psalms 119:94 I am thine, save me; for I have sought thy precepts.

Psalms 119:95 The wicked have waited for me to destroy me: but I will consider thy testimonies.

Psalms 119:96 I have seen an end of all perfection: but thy commandment is exceeding broad.

Psalms 119:97 O how love I thy law! it is my meditation all the day.

Psalms 119:98 Thou through thy commandments hast made me wiser than mine enemies: for they are ever with me.

Psalms 119:99 I have more understanding than all my teachers: for thy testimonies are my meditation.

Psalms 119:100 I understand more than the ancients, because I keep thy precepts.

Psalms 119:101 I have refrained my feet from every evil way, that I might keep thy word.

Psalms 119:102 I have not departed from thy judgments: for thou hast taught me.

Psalms 119:103 How sweet are thy words unto my taste! yea, sweeter than honey to my mouth!

Psalms 119:104 Through thy precepts I get understanding: therefore I hate every false way.

Psalms 119:105 Thy word is a lamp unto my feet, and a light unto my path.

Psalms 119:106 I have sworn, and I will perform it, that I will keep thy righteous judgments.

Psalms 119:107 I am afflicted very much: quicken me, O Lord, according unto thy word.

Psalms 119:108 Accept, I beseech thee, the freewill offerings of my mouth, O Lord, and teach me thy judgments.

Psalms 119:109 My soul is continually in my hand: yet do I not forget thy law.

Psalms 119:110 The wicked have laid a snare for me: yet I erred not from thy precepts.

Psalms 119:111 Thy testimonies have I taken as an heritage for ever: for they are the rejoicing of my heart.

Psalms 119:112 I have inclined mine heart to perform thy statutes alway, even unto the end.

Psalms 119:113 I hate vain thoughts: but thy law do I love.

Psalms 119:114 Thou art my hiding place and my shield: I hope in thy word.

Psalms 119:115 Depart from me, ye evildoers: for I will keep the commandments of my God.

Psalms 119:116 Uphold me according unto thy word, that I may live: and let me not be ashamed of my hope.

Psalms 119:117 Hold thou me up, and I shall be safe: and I will have respect unto thy statutes continually.

Psalms 119:118 Thou hast trodden down all them that err from thy statutes: for their deceit is falsehood.

Psalms 119:119 Thou puttest away all the wicked of the earth like dross: therefore I love thy testimonies.

Psalms 119:120 My flesh trembleth for fear of thee; and I am afraid of thy judgments.

Psalms 119:121 I have done judgment and justice: leave me not to mine oppressors.

Psalms 119:122 Be surety for thy servant for good: let not the proud oppress me.

Psalms 119:123 Mine eyes fail for thy salvation, and for the word of thy righteousness.

Psalms 119:124 Deal with thy servant according unto thy mercy, and teach me thy statutes.

Psalms 119:125 I am thy servant; give me understanding, that I may know thy testimonies.

Psalms 119:126 It is time for thee, Lord, to work: for they have made void thy law.

Psalms 119:127 Therefore I love thy commandments above gold; yea, above fine gold.

Psalms 119:128 Therefore I esteem all thy precepts concerning all things to be right; and I hate every false way.

Psalms 119:129 Thy testimonies are wonderful: therefore doth my soul keep them.

Psalms 119:130 The entrance of thy words giveth light; it giveth understanding unto the simple.

Psalms 119:131 I opened my mouth, and panted: for I longed for thy commandments.

Psalms 119:132 Look thou upon me, and be merciful unto me, as thou usest to do unto those that love thy name.

Psalms 119:133 Order my steps in thy word: and let not any iniquity have dominion over me.

Psalms 119:134 Deliver me from the oppression of man: so will I keep thy precepts.

Psalms 119:135 Make thy face to shine upon thy servant; and teach me thy statutes.

Psalms 119:136 Rivers of waters run down mine eyes, because they keep not thy law.

Psalms 119:137 Righteous art thou, O Lord, and upright are thy judgments.

Psalms 119:138 Thy testimonies that thou hast commanded are righteous and very faithful.

Psalms 119:139 My zeal hath consumed me, because mine enemies have forgotten thy words.

Psalms 119:140 Thy word is very pure: therefore thy servant loveth it.

Psalms 119:141 I am small and despised: yet do not I forget thy precepts.

Psalms 119:142 Thy righteousness is an everlasting righteousness, and thy law is the truth.

Psalms 119:143 Trouble and anguish have taken hold on me: yet thy commandments are my delights.

Psalms 119:144 The righteousness of thy testimonies is everlasting: give me understanding, and I shall live.

Psalms 119:145 I cried with my whole heart; hear me, O Lord: I will keep thy statutes.

Psalms 119:146 I cried unto thee; save me, and I shall keep thy testimonies.

Psalms 119:147 I prevented the dawning of the morning, and cried: I hoped in thy word.

Psalms 119:148 Mine eyes prevent the night watches, that I might meditate in thy word.

Psalms 119:149 Hear my voice according unto thy lovingkindness: O Lord, quicken me according to thy judgment.

Psalms 119:150 They draw nigh that follow after mischief: they are far from thy law.

Psalms 119:151 Thou art near, O Lord; and all thy commandments are truth.

Psalms 119:152 Concerning thy testimonies, I have known of old that thou hast founded them for ever.

Psalms 119:153 Consider mine affliction, and deliver me: for I do not forget thy law.

Psalms 119:154 Plead my cause, and deliver me: quicken me according to thy word.

Psalms 119:155 Salvation is far from the wicked: for they seek not thy statutes.

Psalms 119:156 Great are thy tender mercies, O Lord: quicken me according to thy judgments.

Psalms 119:157 Many are my persecutors and mine enemies; yet do I not decline from thy testimonies.

Psalms 119:158 I beheld the transgressors, and was grieved; because they kept not thy word.

Psalms 119:159 Consider how I love thy precepts: quicken me, O Lord, according to thy lovingkindness.

Psalms 119:160 Thy word is true from the beginning: and every one of thy righteous judgments endureth for ever.

Psalms 119:161 Princes have persecuted me without a cause: but my heart standeth in awe of thy word.

Psalms 119:162 I rejoice at thy word, as one that findeth great spoil.

Psalms 119:163 I hate and abhor lying: but thy law do I love.

Psalms 119:164 Seven times a day do I praise thee because of thy righteous judgments.

Psalms 119:165 Great peace have they which love thy law: and nothing shall offend them.

Psalms 119:166 Lord, I have hoped for thy salvation, and done thy commandments.

Psalms 119:167 My soul hath kept thy testimonies; and I love them exceedingly.

Psalms 119:168 I have kept thy precepts and thy testimonies: for all my ways are before thee.

Psalms 119:169 Let my cry come near before thee, O Lord: give me understanding according to thy word.

Psalms 119:170 Let my supplication come before thee: deliver me according to thy word.

Psalms 119:171 My lips shall utter praise, when thou hast taught me thy statutes.

Psalms 119:172 My tongue shall speak of thy word: for all thy commandments are righteousness.

Psalms 119:173 Let thine hand help me; for I have chosen thy precepts.

Psalms 119:174 I have longed for thy salvation, O Lord; and thy law is my delight.

Psalms 119:175 Let my soul live, and it shall praise thee; and let thy judgments help me.

Psalms 119:176 I have gone astray like a lost sheep; seek thy servant; for I do not forget thy commandments.
