# Isaiah 19

Isaiah 19 (summary): The Lord will smite and destroy Egypt—Finally He will heal her, and Egypt and Assyria will be blessed with Israel.

Isaiah 19:1 The burden of Egypt. Behold, the Lord rideth upon a swift cloud, and shall come into Egypt: and the idols of Egypt shall be moved at his presence, and the heart of Egypt shall melt in the midst of it.

Isaiah 19:2 And I will set the Egyptians against the Egyptians: and they shall fight every one against his brother, and every one against his neighbour; city against city, and kingdom against kingdom.

Isaiah 19:3 And the spirit of Egypt shall fail in the midst thereof; and I will destroy the counsel thereof: and they shall seek to the idols, and to the charmers, and to them that have familiar spirits, and to the wizards.

Isaiah 19:4 And the Egyptians will I give over into the hand of a cruel lord; and a fierce king shall rule over them, saith the Lord, the Lord of hosts.

Isaiah 19:5 And the waters shall fail from the sea, and the river shall be wasted and dried up.

Isaiah 19:6 And they shall turn the rivers far away; and the brooks of defence shall be emptied and dried up: the reeds and flags shall wither.

Isaiah 19:7 The paper reeds by the brooks, by the mouth of the brooks, and every thing sown by the brooks, shall wither, be driven away, and be no more.

Isaiah 19:8 The fishers also shall mourn, and all they that cast angle into the brooks shall lament, and they that spread nets upon the waters shall languish.

Isaiah 19:9 Moreover they that work in fine flax, and they that weave networks, shall be confounded.

Isaiah 19:10 And they shall be broken in the purposes thereof, all that make sluices and ponds for fish.

Isaiah 19:11 Surely the princes of Zoan are fools, the counsel of the wise counsellors of Pharaoh is become brutish: how say ye unto Pharaoh, I am the son of the wise, the son of ancient kings?

Isaiah 19:12 Where are they? where are thy wise men? and let them tell thee now, and let them know what the Lord of hosts hath purposed upon Egypt.

Isaiah 19:13 The princes of Zoan are become fools, the princes of Noph are deceived; they have also seduced Egypt, even they that are the stay of the tribes thereof.

Isaiah 19:14 The Lord hath mingled a perverse spirit in the midst thereof: and they have caused Egypt to err in every work thereof, as a drunken man staggereth in his vomit.

Isaiah 19:15 Neither shall there be any work for Egypt, which the head or tail, branch or rush, may do.

Isaiah 19:16 In that day shall Egypt be like unto women: and it shall be afraid and fear because of the shaking of the hand of the Lord of hosts, which he shaketh over it.

Isaiah 19:17 And the land of Judah shall be a terror unto Egypt, every one that maketh mention thereof shall be afraid in himself, because of the counsel of the Lord of hosts, which he hath determined against it.

Isaiah 19:18 In that day shall five cities in the land of Egypt speak the language of Canaan, and swear to the Lord of hosts; one shall be called, The city of destruction.

Isaiah 19:19 In that day shall there be an altar to the Lord in the midst of the land of Egypt, and a pillar at the border thereof to the Lord.

Isaiah 19:20 And it shall be for a sign and for a witness unto the Lord of hosts in the land of Egypt: for they shall cry unto the Lord because of the oppressors, and he shall send them a saviour, and a great one, and he shall deliver them.

Isaiah 19:21 And the Lord shall be known to Egypt, and the Egyptians shall know the Lord in that day, and shall do sacrifice and oblation; yea, they shall vow a vow unto the Lord, and perform it.

Isaiah 19:22 And the Lord shall smite Egypt: he shall smite and heal it: and they shall return even to the Lord, and he shall be entreated of them, and shall heal them.

Isaiah 19:23 In that day shall there be a highway out of Egypt to Assyria, and the Assyrian shall come into Egypt, and the Egyptian into Assyria, and the Egyptians shall serve with the Assyrians.

Isaiah 19:24 In that day shall Israel be the third with Egypt and with Assyria, even a blessing in the midst of the land:

Isaiah 19:25 Whom the Lord of hosts shall bless, saying, Blessed be Egypt my people, and Assyria the work of my hands, and Israel mine inheritance.
