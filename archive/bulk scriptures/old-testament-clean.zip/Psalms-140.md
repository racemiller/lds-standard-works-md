# Psalms 140

Psalms 140 (summary): David prays for deliverance from his enemies—The Lord maintains the cause of the poor and afflicted.

Psalms 140:1 Deliver me, O Lord, from the evil man: preserve me from the violent man;

Psalms 140:2 Which imagine mischiefs in their heart; continually are they gathered together for war.

Psalms 140:3 They have sharpened their tongues like a serpent; adders’ poison is under their lips. Selah.

Psalms 140:4 Keep me, O Lord, from the hands of the wicked; preserve me from the violent man; who have purposed to overthrow my goings.

Psalms 140:5 The proud have hid a snare for me, and cords; they have spread a net by the wayside; they have set gins for me. Selah.

Psalms 140:6 I said unto the Lord, Thou art my God: hear the voice of my supplications, O Lord.

Psalms 140:7 O God the Lord, the strength of my salvation, thou hast covered my head in the day of battle.

Psalms 140:8 Grant not, O Lord, the desires of the wicked: further not his wicked device; lest they exalt themselves. Selah.

Psalms 140:9 As for the head of those that compass me about, let the mischief of their own lips cover them.

Psalms 140:10 Let burning coals fall upon them: let them be cast into the fire; into deep pits, that they rise not up again.

Psalms 140:11 Let not an evil speaker be established in the earth: evil shall hunt the violent man to overthrow him.

Psalms 140:12 I know that the Lord will maintain the cause of the afflicted, and the right of the poor.

Psalms 140:13 Surely the righteous shall give thanks unto thy name: the upright shall dwell in thy presence.
