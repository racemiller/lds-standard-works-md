# Exodus 15

Exodus 15 (summary): The children of Israel sing the song of Moses—They extol the Lord as a man of war and rejoice in their deliverance from Egypt—The waters of Marah are healed—The Lord promises to free Israel from the diseases of Egypt.

Exodus 15:1 Then sang Moses and the children of Israel this song unto the Lord, and spake, saying, I will sing unto the Lord, for he hath triumphed gloriously: the horse and his rider hath he thrown into the sea.

Exodus 15:2 The Lord is my strength and song, and he is become my salvation: he is my God, and I will prepare him an habitation; my father’s God, and I will exalt him.

Exodus 15:3 The Lord is a man of war: the Lord is his name.

Exodus 15:4 Pharaoh’s chariots and his host hath he cast into the sea: his chosen captains also are drowned in the Red sea.

Exodus 15:5 The depths have covered them: they sank into the bottom as a stone.

Exodus 15:6 Thy right hand, O Lord, is become glorious in power: thy right hand, O Lord, hath dashed in pieces the enemy.

Exodus 15:7 And in the greatness of thine excellency thou hast overthrown them that rose up against thee: thou sentest forth thy wrath, which consumed them as stubble.

Exodus 15:8 And with the blast of thy nostrils the waters were gathered together, the floods stood upright as an heap, and the depths were congealed in the heart of the sea.

Exodus 15:9 The enemy said, I will pursue, I will overtake, I will divide the spoil; my lust shall be satisfied upon them; I will draw my sword, my hand shall destroy them.

Exodus 15:10 Thou didst blow with thy wind, the sea covered them: they sank as lead in the mighty waters.

Exodus 15:11 Who is like unto thee, O Lord, among the gods? who is like thee, glorious in holiness, fearful in praises, doing wonders?

Exodus 15:12 Thou stretchedst out thy right hand, the earth swallowed them.

Exodus 15:13 Thou in thy mercy hast led forth the people which thou hast redeemed: thou hast guided them in thy strength unto thy holy habitation.

Exodus 15:14 The people shall hear, and be afraid: sorrow shall take hold on the inhabitants of Palestina.

Exodus 15:15 Then the dukes of Edom shall be amazed; the mighty men of Moab, trembling shall take hold upon them; all the inhabitants of Canaan shall melt away.

Exodus 15:16 Fear and dread shall fall upon them; by the greatness of thine arm they shall be as still as a stone; till thy people pass over, O Lord, till the people pass over, which thou hast purchased.

Exodus 15:17 Thou shalt bring them in, and plant them in the mountain of thine inheritance, in the place, O Lord, which thou hast made for thee to dwell in, in the Sanctuary, O Lord, which thy hands have established.

Exodus 15:18 The Lord shall reign for ever and ever.

Exodus 15:19 For the horse of Pharaoh went in with his chariots and with his horsemen into the sea, and the Lord brought again the waters of the sea upon them; but the children of Israel went on dry land in the midst of the sea.

Exodus 15:20 And Miriam the prophetess, the sister of Aaron, took a timbrel in her hand; and all the women went out after her with timbrels and with dances.

Exodus 15:21 And Miriam answered them, Sing ye to the Lord, for he hath triumphed gloriously; the horse and his rider hath he thrown into the sea.

Exodus 15:22 So Moses brought Israel from the Red sea, and they went out into the wilderness of Shur; and they went three days in the wilderness, and found no water.

Exodus 15:23 And when they came to Marah, they could not drink of the waters of Marah, for they were bitter: therefore the name of it was called Marah.

Exodus 15:24 And the people murmured against Moses, saying, What shall we drink?

Exodus 15:25 And he cried unto the Lord; and the Lord shewed him a tree, which when he had cast into the waters, the waters were made sweet: there he made for them a statute and an ordinance, and there he proved them,

Exodus 15:26 And said, If thou wilt diligently hearken to the voice of the Lord thy God, and wilt do that which is right in his sight, and wilt give ear to his commandments, and keep all his statutes, I will put none of these diseases upon thee, which I have brought upon the Egyptians: for I am the Lord that healeth thee.

Exodus 15:27 And they came to Elim, where were twelve wells of water, and threescore and ten palm trees: and they encamped there by the waters.
