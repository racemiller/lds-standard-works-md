# Jeremiah 31

Jeremiah 31 (summary): In the last days, Israel will be gathered—The Lord declares that Ephraim has the birthright as the firstborn—The Lord will make a new covenant with Israel, to be inscribed in the heart—Then all Israel will know the Lord.

Jeremiah 31:1 At the same time, saith the Lord, will I be the God of all the families of Israel, and they shall be my people.

Jeremiah 31:2 Thus saith the Lord, The people which were left of the sword found grace in the wilderness; even Israel, when I went to cause him to rest.

Jeremiah 31:3 The Lord hath appeared of old unto me, saying, Yea, I have loved thee with an everlasting love: therefore with lovingkindness have I drawn thee.

Jeremiah 31:4 Again I will build thee, and thou shalt be built, O virgin of Israel: thou shalt again be adorned with thy tabrets, and shalt go forth in the dances of them that make merry.

Jeremiah 31:5 Thou shalt yet plant vines upon the mountains of Samaria: the planters shall plant, and shall eat them as common things.

Jeremiah 31:6 For there shall be a day, that the watchmen upon the mount Ephraim shall cry, Arise ye, and let us go up to Zion unto the Lord our God.

Jeremiah 31:7 For thus saith the Lord; Sing with gladness for Jacob, and shout among the chief of the nations: publish ye, praise ye, and say, O Lord, save thy people, the remnant of Israel.

Jeremiah 31:8 Behold, I will bring them from the north country, and gather them from the coasts of the earth, and with them the blind and the lame, the woman with child and her that travaileth with child together: a great company shall return thither.

Jeremiah 31:9 They shall come with weeping, and with supplications will I lead them: I will cause them to walk by the rivers of waters in a straight way, wherein they shall not stumble: for I am a father to Israel, and Ephraim is my firstborn.

Jeremiah 31:10 Hear the word of the Lord, O ye nations, and declare it in the isles afar off, and say, He that scattered Israel will gather him, and keep him, as a shepherd doth his flock.

Jeremiah 31:11 For the Lord hath redeemed Jacob, and ransomed him from the hand of him that was stronger than he.

Jeremiah 31:12 Therefore they shall come and sing in the height of Zion, and shall flow together to the goodness of the Lord, for wheat, and for wine, and for oil, and for the young of the flock and of the herd: and their soul shall be as a watered garden; and they shall not sorrow any more at all.

Jeremiah 31:13 Then shall the virgin rejoice in the dance, both young men and old together: for I will turn their mourning into joy, and will comfort them, and make them rejoice from their sorrow.

Jeremiah 31:14 And I will satiate the soul of the priests with fatness, and my people shall be satisfied with my goodness, saith the Lord.

Jeremiah 31:15 Thus saith the Lord; A voice was heard in Ramah, lamentation, and bitter weeping; Rahel weeping for her children refused to be comforted for her children, because they were not.

Jeremiah 31:16 Thus saith the Lord; Refrain thy voice from weeping, and thine eyes from tears: for thy work shall be rewarded, saith the Lord; and they shall come again from the land of the enemy.

Jeremiah 31:17 And there is hope in thine end, saith the Lord, that thy children shall come again to their own border.

Jeremiah 31:18 I have surely heard Ephraim bemoaning himself thus; Thou hast chastised me, and I was chastised, as a bullock unaccustomed to the yoke: turn thou me, and I shall be turned; for thou art the Lord my God.

Jeremiah 31:19 Surely after that I was turned, I repented; and after that I was instructed, I smote upon my thigh: I was ashamed, yea, even confounded, because I did bear the reproach of my youth.

Jeremiah 31:20 Is Ephraim my dear son? is he a pleasant child? for since I spake against him, I do earnestly remember him still: therefore my bowels are troubled for him; I will surely have mercy upon him, saith the Lord.

Jeremiah 31:21 Set thee up waymarks, make thee high heaps: set thine heart toward the highway, even the way which thou wentest: turn again, O virgin of Israel, turn again to these thy cities.

Jeremiah 31:22 How long wilt thou go about, O thou backsliding daughter? for the Lord hath created a new thing in the earth, A woman shall compass a man.

Jeremiah 31:23 Thus saith the Lord of hosts, the God of Israel; As yet they shall use this speech in the land of Judah and in the cities thereof, when I shall bring again their captivity; The Lord bless thee, O habitation of justice, and mountain of holiness.

Jeremiah 31:24 And there shall dwell in Judah itself, and in all the cities thereof together, husbandmen, and they that go forth with flocks.

Jeremiah 31:25 For I have satiated the weary soul, and I have replenished every sorrowful soul.

Jeremiah 31:26 Upon this I awaked, and beheld; and my sleep was sweet unto me.

Jeremiah 31:27 Behold, the days come, saith the Lord, that I will sow the house of Israel and the house of Judah with the seed of man, and with the seed of beast.

Jeremiah 31:28 And it shall come to pass, that like as I have watched over them, to pluck up, and to break down, and to throw down, and to destroy, and to afflict; so will I watch over them, to build, and to plant, saith the Lord.

Jeremiah 31:29 In those days they shall say no more, The fathers have eaten a sour grape, and the children’s teeth are set on edge.

Jeremiah 31:30 But every one shall die for his own iniquity: every man that eateth the sour grape, his teeth shall be set on edge.

Jeremiah 31:31 Behold, the days come, saith the Lord, that I will make a new covenant with the house of Israel, and with the house of Judah:

Jeremiah 31:32 Not according to the covenant that I made with their fathers in the day that I took them by the hand to bring them out of the land of Egypt; which my covenant they brake, although I was an husband unto them, saith the Lord:

Jeremiah 31:33 But this shall be the covenant that I will make with the house of Israel; After those days, saith the Lord, I will put my law in their inward parts, and write it in their hearts; and will be their God, and they shall be my people.

Jeremiah 31:34 And they shall teach no more every man his neighbour, and every man his brother, saying, Know the Lord: for they shall all know me, from the least of them unto the greatest of them, saith the Lord: for I will forgive their iniquity, and I will remember their sin no more.

Jeremiah 31:35 Thus saith the Lord, which giveth the sun for a light by day, and the ordinances of the moon and of the stars for a light by night, which divideth the sea when the waves thereof roar; The Lord of hosts is his name:

Jeremiah 31:36 If those ordinances depart from before me, saith the Lord, then the seed of Israel also shall cease from being a nation before me for ever.

Jeremiah 31:37 Thus saith the Lord; If heaven above can be measured, and the foundations of the earth searched out beneath, I will also cast off all the seed of Israel for all that they have done, saith the Lord.

Jeremiah 31:38 Behold, the days come, saith the Lord, that the city shall be built to the Lord from the tower of Hananeel unto the gate of the corner.

Jeremiah 31:39 And the measuring line shall yet go forth over against it upon the hill Gareb, and shall compass about to Goath.

Jeremiah 31:40 And the whole valley of the dead bodies, and of the ashes, and all the fields unto the brook of Kidron, unto the corner of the horse gate toward the east, shall be holy unto the Lord; it shall not be plucked up, nor thrown down any more for ever.
