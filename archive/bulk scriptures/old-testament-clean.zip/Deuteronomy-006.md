# Deuteronomy 6

Deuteronomy 6 (summary): Moses proclaims, The Lord our God is one Lord, and, Thou shalt love the Lord thy God—The children of Israel are commanded to teach their children—Moses exhorts them to keep the commandments, testimonies, and statutes of the Lord that they may prosper.

Deuteronomy 6:1 Now these are the commandments, the statutes, and the judgments, which the Lord your God commanded to teach you, that ye might do them in the land whither ye go to possess it:

Deuteronomy 6:2 That thou mightest fear the Lord thy God, to keep all his statutes and his commandments, which I command thee, thou, and thy son, and thy son’s son, all the days of thy life; and that thy days may be prolonged.

Deuteronomy 6:3 Hear therefore, O Israel, and observe to do it; that it may be well with thee, and that ye may increase mightily, as the Lord God of thy fathers hath promised thee, in the land that floweth with milk and honey.

Deuteronomy 6:4 Hear, O Israel: The Lord our God is one Lord:

Deuteronomy 6:5 And thou shalt love the Lord thy God with all thine heart, and with all thy soul, and with all thy might.

Deuteronomy 6:6 And these words, which I command thee this day, shall be in thine heart:

Deuteronomy 6:7 And thou shalt teach them diligently unto thy children, and shalt talk of them when thou sittest in thine house, and when thou walkest by the way, and when thou liest down, and when thou risest up.

Deuteronomy 6:8 And thou shalt bind them for a sign upon thine hand, and they shall be as frontlets between thine eyes.

Deuteronomy 6:9 And thou shalt write them upon the posts of thy house, and on thy gates.

Deuteronomy 6:10 And it shall be, when the Lord thy God shall have brought thee into the land which he sware unto thy fathers, to Abraham, to Isaac, and to Jacob, to give thee great and goodly cities, which thou buildedst not,

Deuteronomy 6:11 And houses full of all good things, which thou filledst not, and wells digged, which thou diggedst not, vineyards and olive trees, which thou plantedst not; when thou shalt have eaten and be full;

Deuteronomy 6:12 Then beware lest thou forget the Lord, which brought thee forth out of the land of Egypt, from the house of bondage.

Deuteronomy 6:13 Thou shalt fear the Lord thy God, and serve him, and shalt swear by his name.

Deuteronomy 6:14 Ye shall not go after other gods, of the gods of the people which are round about you;

Deuteronomy 6:15 (For the Lord thy God is a jealous God among you) lest the anger of the Lord thy God be kindled against thee, and destroy thee from off the face of the earth.

Deuteronomy 6:16 Ye shall not tempt the Lord your God, as ye tempted him in Massah.

Deuteronomy 6:17 Ye shall diligently keep the commandments of the Lord your God, and his testimonies, and his statutes, which he hath commanded thee.

Deuteronomy 6:18 And thou shalt do that which is right and good in the sight of the Lord: that it may be well with thee, and that thou mayest go in and possess the good land which the Lord sware unto thy fathers,

Deuteronomy 6:19 To cast out all thine enemies from before thee, as the Lord hath spoken.

Deuteronomy 6:20 And when thy son asketh thee in time to come, saying, What mean the testimonies, and the statutes, and the judgments, which the Lord our God hath commanded you?

Deuteronomy 6:21 Then thou shalt say unto thy son, We were Pharaoh’s bondmen in Egypt; and the Lord brought us out of Egypt with a mighty hand:

Deuteronomy 6:22 And the Lord shewed signs and wonders, great and sore, upon Egypt, upon Pharaoh, and upon all his household, before our eyes:

Deuteronomy 6:23 And he brought us out from thence, that he might bring us in, to give us the land which he sware unto our fathers.

Deuteronomy 6:24 And the Lord commanded us to do all these statutes, to fear the Lord our God, for our good always, that he might preserve us alive, as it is at this day.

Deuteronomy 6:25 And it shall be our righteousness, if we observe to do all these commandments before the Lord our God, as he hath commanded us.
