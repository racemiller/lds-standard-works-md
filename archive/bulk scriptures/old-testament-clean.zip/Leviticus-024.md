# Leviticus 24

Leviticus 24 (summary): A perpetual fire is to burn outside the veil in the tabernacle—A blasphemer is put to death by stoning—Israel’s law is one of an eye for an eye and a tooth for a tooth.

Leviticus 24:1 And the Lord spake unto Moses, saying,

Leviticus 24:2 Command the children of Israel, that they bring unto thee pure oil olive beaten for the light, to cause the lamps to burn continually.

Leviticus 24:3 Without the veil of the testimony, in the tabernacle of the congregation, shall Aaron order it from the evening unto the morning before the Lord continually: it shall be a statute for ever in your generations.

Leviticus 24:4 He shall order the lamps upon the pure candlestick before the Lord continually.

Leviticus 24:5 And thou shalt take fine flour, and bake twelve cakes thereof: two tenth deals shall be in one cake.

Leviticus 24:6 And thou shalt set them in two rows, six on a row, upon the pure table before the Lord.

Leviticus 24:7 And thou shalt put pure frankincense upon each row, that it may be on the bread for a memorial, even an offering made by fire unto the Lord.

Leviticus 24:8 Every sabbath he shall set it in order before the Lord continually, being taken from the children of Israel by an everlasting covenant.

Leviticus 24:9 And it shall be Aaron’s and his sons’; and they shall eat it in the holy place: for it is most holy unto him of the offerings of the Lord made by fire by a perpetual statute.

Leviticus 24:10 And the son of an Israelitish woman, whose father was an Egyptian, went out among the children of Israel: and this son of the Israelitish woman and a man of Israel strove together in the camp;

Leviticus 24:11 And the Israelitish woman’s son blasphemed the name of the Lord, and cursed. And they brought him unto Moses: (and his mother’s name was Shelomith, the daughter of Dibri, of the tribe of Dan:)

Leviticus 24:12 And they put him in ward, that the mind of the Lord might be shewed them.

Leviticus 24:13 And the Lord spake unto Moses, saying,

Leviticus 24:14 Bring forth him that hath cursed without the camp; and let all that heard him lay their hands upon his head, and let all the congregation stone him.

Leviticus 24:15 And thou shalt speak unto the children of Israel, saying, Whosoever curseth his God shall bear his sin.

Leviticus 24:16 And he that blasphemeth the name of the Lord, he shall surely be put to death, and all the congregation shall certainly stone him: as well the stranger, as he that is born in the land, when he blasphemeth the name of the Lord, shall be put to death.

Leviticus 24:17 And he that killeth any man shall surely be put to death.

Leviticus 24:18 And he that killeth a beast shall make it good; beast for beast.

Leviticus 24:19 And if a man cause a blemish in his neighbour; as he hath done, so shall it be done to him;

Leviticus 24:20 Breach for breach, eye for eye, tooth for tooth: as he hath caused a blemish in a man, so shall it be done to him again.

Leviticus 24:21 And he that killeth a beast, he shall restore it: and he that killeth a man, he shall be put to death.

Leviticus 24:22 Ye shall have one manner of law, as well for the stranger, as for one of your own country: for I am the Lord your God.

Leviticus 24:23 And Moses spake to the children of Israel, that they should bring forth him that had cursed out of the camp, and stone him with stones. And the children of Israel did as the Lord commanded Moses.
