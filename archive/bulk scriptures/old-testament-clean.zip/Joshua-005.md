# Joshua 5

Joshua 5 (summary): The inhabitants of Canaan fear Israel—The males of Israel are circumcised—Israel keeps the Passover, eats the fruit of the land, and manna ceases—The captain of the Lord’s host appears to Joshua.

Joshua 5:1 And it came to pass, when all the kings of the Amorites, which were on the side of Jordan westward, and all the kings of the Canaanites, which were by the sea, heard that the Lord had dried up the waters of Jordan from before the children of Israel, until we were passed over, that their heart melted, neither was there spirit in them any more, because of the children of Israel.

Joshua 5:2 At that time the Lord said unto Joshua, Make thee sharp knives, and circumcise again the children of Israel the second time.

Joshua 5:3 And Joshua made him sharp knives, and circumcised the children of Israel at the hill of the foreskins.

Joshua 5:4 And this is the cause why Joshua did circumcise: All the people that came out of Egypt, that were males, even all the men of war, died in the wilderness by the way, after they came out of Egypt.

Joshua 5:5 Now all the people that came out were circumcised: but all the people that were born in the wilderness by the way as they came forth out of Egypt, them they had not circumcised.

Joshua 5:6 For the children of Israel walked forty years in the wilderness, till all the people that were men of war, which came out of Egypt, were consumed, because they obeyed not the voice of the Lord: unto whom the Lord sware that he would not shew them the land, which the Lord sware unto their fathers that he would give us, a land that floweth with milk and honey.

Joshua 5:7 And their children, whom he raised up in their stead, them Joshua circumcised: for they were uncircumcised, because they had not circumcised them by the way.

Joshua 5:8 And it came to pass, when they had done circumcising all the people, that they abode in their places in the camp, till they were whole.

Joshua 5:9 And the Lord said unto Joshua, This day have I rolled away the reproach of Egypt from off you. Wherefore the name of the place is called Gilgal unto this day.

Joshua 5:10 And the children of Israel encamped in Gilgal, and kept the passover on the fourteenth day of the month at even in the plains of Jericho.

Joshua 5:11 And they did eat of the old corn of the land on the morrow after the passover, unleavened cakes, and parched corn in the selfsame day.

Joshua 5:12 And the manna ceased on the morrow after they had eaten of the old corn of the land; neither had the children of Israel manna any more; but they did eat of the fruit of the land of Canaan that year.

Joshua 5:13 And it came to pass, when Joshua was by Jericho, that he lifted up his eyes and looked, and, behold, there stood a man over against him with his sword drawn in his hand: and Joshua went unto him, and said unto him, Art thou for us, or for our adversaries?

Joshua 5:14 And he said, Nay; but as captain of the host of the Lord am I now come. And Joshua fell on his face to the earth, and did worship, and said unto him, What saith my lord unto his servant?

Joshua 5:15 And the captain of the Lord’s host said unto Joshua, Loose thy shoe from off thy foot; for the place whereon thou standest is holy. And Joshua did so.
