# 1 Chronicles 9

1 Chronicles 9 (summary): The inhabitants of Jerusalem are listed—The responsibilities of the Levites and the areas where they are to serve are listed—The family of Saul is named.

1 Chronicles 9:1 So all Israel were reckoned by genealogies; and, behold, they were written in the book of the kings of Israel and Judah, who were carried away to Babylon for their transgression.

1 Chronicles 9:2 Now the first inhabitants that dwelt in their possessions in their cities were, the Israelites, the priests, Levites, and the Nethinims.

1 Chronicles 9:3 And in Jerusalem dwelt of the children of Judah, and of the children of Benjamin, and of the children of Ephraim, and Manasseh;

1 Chronicles 9:4 Uthai the son of Ammihud, the son of Omri, the son of Imri, the son of Bani, of the children of Pharez the son of Judah.

1 Chronicles 9:5 And of the Shilonites; Asaiah the firstborn, and his sons.

1 Chronicles 9:6 And of the sons of Zerah; Jeuel, and their brethren, six hundred and ninety.

1 Chronicles 9:7 And of the sons of Benjamin; Sallu the son of Meshullam, the son of Hodaviah, the son of Hasenuah,

1 Chronicles 9:8 And Ibneiah the son of Jeroham, and Elah the son of Uzzi, the son of Michri, and Meshullam the son of Shephathiah, the son of Reuel, the son of Ibnijah;

1 Chronicles 9:9 And their brethren, according to their generations, nine hundred and fifty and six. All these men were chief of the fathers in the house of their fathers.

1 Chronicles 9:10 And of the priests; Jedaiah, and Jehoiarib, and Jachin,

1 Chronicles 9:11 And Azariah the son of Hilkiah, the son of Meshullam, the son of Zadok, the son of Meraioth, the son of Ahitub, the ruler of the house of God;

1 Chronicles 9:12 And Adaiah the son of Jeroham, the son of Pashur, the son of Malchijah, and Maasiai the son of Adiel, the son of Jahzerah, the son of Meshullam, the son of Meshillemith, the son of Immer;

1 Chronicles 9:13 And their brethren, heads of the house of their fathers, a thousand and seven hundred and threescore; very able men for the work of the service of the house of God.

1 Chronicles 9:14 And of the Levites; Shemaiah the son of Hasshub, the son of Azrikam, the son of Hashabiah, of the sons of Merari;

1 Chronicles 9:15 And Bakbakkar, Heresh, and Galal, and Mattaniah the son of Micah, the son of Zichri, the son of Asaph;

1 Chronicles 9:16 And Obadiah the son of Shemaiah, the son of Galal, the son of Jeduthun, and Berechiah the son of Asa, the son of Elkanah, that dwelt in the villages of the Netophathites.

1 Chronicles 9:17 And the porters were, Shallum, and Akkub, and Talmon, and Ahiman, and their brethren: Shallum was the chief;

1 Chronicles 9:18 Who hitherto waited in the king’s gate eastward: they were porters in the companies of the children of Levi.

1 Chronicles 9:19 And Shallum the son of Kore, the son of Ebiasaph, the son of Korah, and his brethren, of the house of his father, the Korahites, were over the work of the service, keepers of the gates of the tabernacle: and their fathers, being over the host of the Lord, were keepers of the entry.

1 Chronicles 9:20 And Phinehas the son of Eleazar was the ruler over them in time past, and the Lord was with him.

1 Chronicles 9:21 And Zechariah the son of Meshelemiah was porter of the door of the tabernacle of the congregation.

1 Chronicles 9:22 All these which were chosen to be porters in the gates were two hundred and twelve. These were reckoned by their genealogy in their villages, whom David and Samuel the seer did ordain in their set office.

1 Chronicles 9:23 So they and their children had the oversight of the gates of the house of the Lord, namely, the house of the tabernacle, by wards.

1 Chronicles 9:24 In four quarters were the porters, toward the east, west, north, and south.

1 Chronicles 9:25 And their brethren, which were in their villages, were to come after seven days from time to time with them.

1 Chronicles 9:26 For these Levites, the four chief porters, were in their set office, and were over the chambers and treasuries of the house of God.

1 Chronicles 9:27 And they lodged round about the house of God, because the charge was upon them, and the opening thereof every morning pertained to them.

1 Chronicles 9:28 And certain of them had the charge of the ministering vessels, that they should bring them in and out by tale.

1 Chronicles 9:29 Some of them also were appointed to oversee the vessels, and all the instruments of the sanctuary, and the fine flour, and the wine, and the oil, and the frankincense, and the spices.

1 Chronicles 9:30 And some of the sons of the priests made the ointment of the spices.

1 Chronicles 9:31 And Mattithiah, one of the Levites, who was the firstborn of Shallum the Korahite, had the set office over the things that were made in the pans.

1 Chronicles 9:32 And other of their brethren, of the sons of the Kohathites, were over the shewbread, to prepare it every sabbath.

1 Chronicles 9:33 And these are the singers, chief of the fathers of the Levites, who remaining in the chambers were free: for they were employed in that work day and night.

1 Chronicles 9:34 These chief fathers of the Levites were chief throughout their generations; these dwelt at Jerusalem.

1 Chronicles 9:35 And in Gibeon dwelt the father of Gibeon, Jehiel, whose wife’s name was Maachah:

1 Chronicles 9:36 And his firstborn son Abdon, then Zur, and Kish, and Baal, and Ner, and Nadab,

1 Chronicles 9:37 And Gedor, and Ahio, and Zechariah, and Mikloth.

1 Chronicles 9:38 And Mikloth begat Shimeam. And they also dwelt with their brethren at Jerusalem, over against their brethren.

1 Chronicles 9:39 And Ner begat Kish; and Kish begat Saul; and Saul begat Jonathan, and Malchi-shua, and Abinadab, and Esh-baal.

1 Chronicles 9:40 And the son of Jonathan was Merib-baal: and Merib-baal begat Micah.

1 Chronicles 9:41 And the sons of Micah were, Pithon, and Melech, and Tahrea, and Ahaz.

1 Chronicles 9:42 And Ahaz begat Jarah; and Jarah begat Alemeth, and Azmaveth, and Zimri; and Zimri begat Moza;

1 Chronicles 9:43 And Moza begat Binea; and Rephaiah his son, Eleasah his son, Azel his son.

1 Chronicles 9:44 And Azel had six sons, whose names are these, Azrikam, Bocheru, and Ishmael, and Sheariah, and Obadiah, and Hanan: these were the sons of Azel.
