# Hosea 13

Hosea 13 (summary): Ephraim’s sins provoke the Lord—There is no Savior beside the Lord—He ransoms from the grave and redeems from death.

Hosea 13:1 When Ephraim spake trembling, he exalted himself in Israel; but when he offended in Baal, he died.

Hosea 13:2 And now they sin more and more, and have made them molten images of their silver, and idols according to their own understanding, all of it the work of the craftsmen: they say of them, Let the men that sacrifice kiss the calves.

Hosea 13:3 Therefore they shall be as the morning cloud, and as the early dew that passeth away, as the chaff that is driven with the whirlwind out of the floor, and as the smoke out of the chimney.

Hosea 13:4 Yet I am the Lord thy God from the land of Egypt, and thou shalt know no god but me: for there is no saviour beside me.

Hosea 13:5 I did know thee in the wilderness, in the land of great drought.

Hosea 13:6 According to their pasture, so were they filled; they were filled, and their heart was exalted; therefore have they forgotten me.

Hosea 13:7 Therefore I will be unto them as a lion: as a leopard by the way will I observe them:

Hosea 13:8 I will meet them as a bear that is bereaved of her whelps, and will rend the caul of their heart, and there will I devour them like a lion: the wild beast shall tear them.

Hosea 13:9 O Israel, thou hast destroyed thyself; but in me is thine help.

Hosea 13:10 I will be thy king: where is any other that may save thee in all thy cities? and thy judges of whom thou saidst, Give me a king and princes?

Hosea 13:11 I gave thee a king in mine anger, and took him away in my wrath.

Hosea 13:12 The iniquity of Ephraim is bound up; his sin is hid.

Hosea 13:13 The sorrows of a travailing woman shall come upon him: he is an unwise son; for he should not stay long in the place of the breaking forth of children.

Hosea 13:14 I will ransom them from the power of the grave; I will redeem them from death: O death, I will be thy plagues; O grave, I will be thy destruction: repentance shall be hid from mine eyes.

Hosea 13:15 Though he be fruitful among his brethren, an east wind shall come, the wind of the Lord shall come up from the wilderness, and his spring shall become dry, and his fountain shall be dried up: he shall spoil the treasure of all pleasant vessels.

Hosea 13:16 Samaria shall become desolate; for she hath rebelled against her God: they shall fall by the sword: their infants shall be dashed in pieces, and their women with child shall be ripped up.
