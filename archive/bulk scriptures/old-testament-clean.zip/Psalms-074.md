# Psalms 74

Psalms 74 (summary): O God, remember Thy chosen congregation—The wicked destroy the sanctuary and burn the synagogues—O God, remember them for their deeds, and save Thy people.

Psalms 74:1 O God, why hast thou cast us off for ever? why doth thine anger smoke against the sheep of thy pasture?

Psalms 74:2 Remember thy congregation, which thou hast purchased of old; the rod of thine inheritance, which thou hast redeemed; this mount Zion, wherein thou hast dwelt.

Psalms 74:3 Lift up thy feet unto the perpetual desolations; even all that the enemy hath done wickedly in the sanctuary.

Psalms 74:4 Thine enemies roar in the midst of thy congregations; they set up their ensigns for signs.

Psalms 74:5 A man was famous according as he had lifted up axes upon the thick trees.

Psalms 74:6 But now they break down the carved work thereof at once with axes and hammers.

Psalms 74:7 They have cast fire into thy sanctuary, they have defiled by casting down the dwelling place of thy name to the ground.

Psalms 74:8 They said in their hearts, Let us destroy them together: they have burned up all the synagogues of God in the land.

Psalms 74:9 We see not our signs: there is no more any prophet: neither is there among us any that knoweth how long.

Psalms 74:10 O God, how long shall the adversary reproach? shall the enemy blaspheme thy name for ever?

Psalms 74:11 Why withdrawest thou thy hand, even thy right hand? pluck it out of thy bosom.

Psalms 74:12 For God is my King of old, working salvation in the midst of the earth.

Psalms 74:13 Thou didst divide the sea by thy strength: thou brakest the heads of the dragons in the waters.

Psalms 74:14 Thou brakest the heads of leviathan in pieces, and gavest him to be meat to the people inhabiting the wilderness.

Psalms 74:15 Thou didst cleave the fountain and the flood: thou driedst up mighty rivers.

Psalms 74:16 The day is thine, the night also is thine: thou hast prepared the light and the sun.

Psalms 74:17 Thou hast set all the borders of the earth: thou hast made summer and winter.

Psalms 74:18 Remember this, that the enemy hath reproached, O Lord, and that the foolish people have blasphemed thy name.

Psalms 74:19 O deliver not the soul of thy turtledove unto the multitude of the wicked: forget not the congregation of thy poor for ever.

Psalms 74:20 Have respect unto the covenant: for the dark places of the earth are full of the habitations of cruelty.

Psalms 74:21 O let not the oppressed return ashamed: let the poor and needy praise thy name.

Psalms 74:22 Arise, O God, plead thine own cause: remember how the foolish man reproacheth thee daily.

Psalms 74:23 Forget not the voice of thine enemies: the tumult of those that rise up against thee increaseth continually.
