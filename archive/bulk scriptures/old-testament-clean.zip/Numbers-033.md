# Numbers 33

Numbers 33 (summary): Israel’s journeys from Egypt to Canaan are reviewed—The people are commanded to drive out the inhabitants of the land—Any remaining inhabitants will vex Israel.

Numbers 33:1 These are the journeys of the children of Israel, which went forth out of the land of Egypt with their armies under the hand of Moses and Aaron.

Numbers 33:2 And Moses wrote their goings out according to their journeys by the commandment of the Lord: and these are their journeys according to their goings out.

Numbers 33:3 And they departed from Rameses in the first month, on the fifteenth day of the first month; on the morrow after the passover the children of Israel went out with an high hand in the sight of all the Egyptians.

Numbers 33:4 For the Egyptians buried all their firstborn, which the Lord had smitten among them: upon their gods also the Lord executed judgments.

Numbers 33:5 And the children of Israel removed from Rameses, and pitched in Succoth.

Numbers 33:6 And they departed from Succoth, and pitched in Etham, which is in the edge of the wilderness.

Numbers 33:7 And they removed from Etham, and turned again unto Pi-hahiroth, which is before Baal-zephon: and they pitched before Migdol.

Numbers 33:8 And they departed from before Pi-hahiroth, and passed through the midst of the sea into the wilderness, and went three days’ journey in the wilderness of Etham, and pitched in Marah.

Numbers 33:9 And they removed from Marah, and came unto Elim: and in Elim were twelve fountains of water, and threescore and ten palm trees; and they pitched there.

Numbers 33:10 And they removed from Elim, and encamped by the Red sea.

Numbers 33:11 And they removed from the Red sea, and encamped in the wilderness of Sin.

Numbers 33:12 And they took their journey out of the wilderness of Sin, and encamped in Dophkah.

Numbers 33:13 And they departed from Dophkah, and encamped in Alush.

Numbers 33:14 And they removed from Alush, and encamped at Rephidim, where was no water for the people to drink.

Numbers 33:15 And they departed from Rephidim, and pitched in the wilderness of Sinai.

Numbers 33:16 And they removed from the desert of Sinai, and pitched at Kibroth-hattaavah.

Numbers 33:17 And they departed from Kibroth-hattaavah, and encamped at Hazeroth.

Numbers 33:18 And they departed from Hazeroth, and pitched in Rithmah.

Numbers 33:19 And they departed from Rithmah, and pitched at Rimmon-parez.

Numbers 33:20 And they departed from Rimmon-parez, and pitched in Libnah.

Numbers 33:21 And they removed from Libnah, and pitched at Rissah.

Numbers 33:22 And they journeyed from Rissah, and pitched in Kehelathah.

Numbers 33:23 And they went from Kehelathah, and pitched in mount Shapher.

Numbers 33:24 And they removed from mount Shapher, and encamped in Haradah.

Numbers 33:25 And they removed from Haradah, and pitched in Makheloth.

Numbers 33:26 And they removed from Makheloth, and encamped at Tahath.

Numbers 33:27 And they departed from Tahath, and pitched at Tarah.

Numbers 33:28 And they removed from Tarah, and pitched in Mithcah.

Numbers 33:29 And they went from Mithcah, and pitched in Hashmonah.

Numbers 33:30 And they departed from Hashmonah, and encamped at Moseroth.

Numbers 33:31 And they departed from Moseroth, and pitched in Bene-jaakan.

Numbers 33:32 And they removed from Bene-jaakan, and encamped at Hor-hagidgad.

Numbers 33:33 And they went from Hor-hagidgad, and pitched in Jotbathah.

Numbers 33:34 And they removed from Jotbathah, and encamped at Ebronah.

Numbers 33:35 And they departed from Ebronah, and encamped at Ezion-gaber.

Numbers 33:36 And they removed from Ezion-gaber, and pitched in the wilderness of Zin, which is Kadesh.

Numbers 33:37 And they removed from Kadesh, and pitched in mount Hor, in the edge of the land of Edom.

Numbers 33:38 And Aaron the priest went up into mount Hor at the commandment of the Lord, and died there, in the fortieth year after the children of Israel were come out of the land of Egypt, in the first day of the fifth month.

Numbers 33:39 And Aaron was an hundred and twenty and three years old when he died in mount Hor.

Numbers 33:40 And king Arad the Canaanite, which dwelt in the south in the land of Canaan, heard of the coming of the children of Israel.

Numbers 33:41 And they departed from mount Hor, and pitched in Zalmonah.

Numbers 33:42 And they departed from Zalmonah, and pitched in Punon.

Numbers 33:43 And they departed from Punon, and pitched in Oboth.

Numbers 33:44 And they departed from Oboth, and pitched in Ije-abarim, in the border of Moab.

Numbers 33:45 And they departed from Iim, and pitched in Dibon-gad.

Numbers 33:46 And they removed from Dibon-gad, and encamped in Almon-diblathaim.

Numbers 33:47 And they removed from Almon-diblathaim, and pitched in the mountains of Abarim, before Nebo.

Numbers 33:48 And they departed from the mountains of Abarim, and pitched in the plains of Moab by Jordan near Jericho.

Numbers 33:49 And they pitched by Jordan, from Beth-jesimoth even unto Abel-shittim in the plains of Moab.

Numbers 33:50 And the Lord spake unto Moses in the plains of Moab by Jordan near Jericho, saying,

Numbers 33:51 Speak unto the children of Israel, and say unto them, When ye are passed over Jordan into the land of Canaan;

Numbers 33:52 Then ye shall drive out all the inhabitants of the land from before you, and destroy all their pictures, and destroy all their molten images, and quite pluck down all their high places:

Numbers 33:53 And ye shall dispossess the inhabitants of the land, and dwell therein: for I have given you the land to possess it.

Numbers 33:54 And ye shall divide the land by lot for an inheritance among your families: and to the more ye shall give the more inheritance, and to the fewer ye shall give the less inheritance: every man’s inheritance shall be in the place where his lot falleth; according to the tribes of your fathers ye shall inherit.

Numbers 33:55 But if ye will not drive out the inhabitants of the land from before you; then it shall come to pass, that those which ye let remain of them shall be pricks in your eyes, and thorns in your sides, and shall vex you in the land wherein ye dwell.

Numbers 33:56 Moreover it shall come to pass, that I shall do unto you, as I thought to do unto them.
