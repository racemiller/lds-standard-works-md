# 1 Samuel 31

1 Samuel 31 (summary): The Philistines defeat Israel—Saul and his three sons are slain—Their bodies are retrieved by the Gileadites and burned.

1 Samuel 31:1 Now the Philistines fought against Israel: and the men of Israel fled from before the Philistines, and fell down slain in mount Gilboa.

1 Samuel 31:2 And the Philistines followed hard upon Saul and upon his sons; and the Philistines slew Jonathan, and Abinadab, and Malchi-shua, Saul’s sons.

1 Samuel 31:3 And the battle went sore against Saul, and the archers hit him; and he was sore wounded of the archers.

1 Samuel 31:4 Then said Saul unto his armourbearer, Draw thy sword, and thrust me through therewith; lest these uncircumcised come and thrust me through, and abuse me. But his armourbearer would not; for he was sore afraid. Therefore Saul took a sword, and fell upon it.

1 Samuel 31:5 And when his armourbearer saw that Saul was dead, he fell likewise upon his sword, and died with him.

1 Samuel 31:6 So Saul died, and his three sons, and his armourbearer, and all his men, that same day together.

1 Samuel 31:7 And when the men of Israel that were on the other side of the valley, and they that were on the other side Jordan, saw that the men of Israel fled, and that Saul and his sons were dead, they forsook the cities, and fled; and the Philistines came and dwelt in them.

1 Samuel 31:8 And it came to pass on the morrow, when the Philistines came to strip the slain, that they found Saul and his three sons fallen in mount Gilboa.

1 Samuel 31:9 And they cut off his head, and stripped off his armour, and sent into the land of the Philistines round about, to publish it in the house of their idols, and among the people.

1 Samuel 31:10 And they put his armour in the house of Ashtaroth: and they fastened his body to the wall of Beth-shan.

1 Samuel 31:11 And when the inhabitants of Jabesh-gilead heard of that which the Philistines had done to Saul;

1 Samuel 31:12 All the valiant men arose, and went all night, and took the body of Saul and the bodies of his sons from the wall of Beth-shan, and came to Jabesh, and burnt them there.

1 Samuel 31:13 And they took their bones, and buried them under a tree at Jabesh, and fasted seven days.
