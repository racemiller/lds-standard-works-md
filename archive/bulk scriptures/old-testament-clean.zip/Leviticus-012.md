# Leviticus 12

Leviticus 12 (summary): The Lord reveals the law of purification of women after childbirth, including a sin offering.

Leviticus 12:1 And the Lord spake unto Moses, saying,

Leviticus 12:2 Speak unto the children of Israel, saying, If a woman have conceived seed, and born a man child: then she shall be unclean seven days; according to the days of the separation for her infirmity shall she be unclean.

Leviticus 12:3 And in the eighth day the flesh of his foreskin shall be circumcised.

Leviticus 12:4 And she shall then continue in the blood of her purifying three and thirty days; she shall touch no hallowed thing, nor come into the sanctuary, until the days of her purifying be fulfilled.

Leviticus 12:5 But if she bear a maid child, then she shall be unclean two weeks, as in her separation: and she shall continue in the blood of her purifying threescore and six days.

Leviticus 12:6 And when the days of her purifying are fulfilled, for a son, or for a daughter, she shall bring a lamb of the first year for a burnt offering, and a young pigeon, or a turtledove, for a sin offering, unto the door of the tabernacle of the congregation, unto the priest:

Leviticus 12:7 Who shall offer it before the Lord, and make an atonement for her; and she shall be cleansed from the issue of her blood. This is the law for her that hath born a male or a female.

Leviticus 12:8 And if she be not able to bring a lamb, then she shall bring two turtles, or two young pigeons; the one for the burnt offering, and the other for a sin offering: and the priest shall make an atonement for her, and she shall be clean.
