# Genesis 26

Genesis 26 (summary): The Lord promises Isaac posterity as the stars of heaven in number—In his seed, all nations will be blessed—The Lord prospers Isaac, temporally and spiritually, for Abraham’s sake—Isaac offers sacrifices—Esau marries Hittite wives to the sorrow of his parents.

Genesis 26:1 And there was a famine in the land, beside the first famine that was in the days of Abraham. And Isaac went unto Abimelech king of the Philistines unto Gerar.

Genesis 26:2 And the Lord appeared unto him, and said, Go not down into Egypt; dwell in the land which I shall tell thee of:

Genesis 26:3 Sojourn in this land, and I will be with thee, and will bless thee; for unto thee, and unto thy seed, I will give all these countries, and I will perform the oath which I sware unto Abraham thy father;

Genesis 26:4 And I will make thy seed to multiply as the stars of heaven, and will give unto thy seed all these countries; and in thy seed shall all the nations of the earth be blessed;

Genesis 26:5 Because that Abraham obeyed my voice, and kept my charge, my commandments, my statutes, and my laws.

Genesis 26:6 And Isaac dwelt in Gerar:

Genesis 26:7 And the men of the place asked him of his wife; and he said, She is my sister: for he feared to say, She is my wife; lest, said he, the men of the place should kill me for Rebekah; because she was fair to look upon.

Genesis 26:8 And it came to pass, when he had been there a long time, that Abimelech king of the Philistines looked out at a window, and saw, and, behold, Isaac was sporting with Rebekah his wife.

Genesis 26:9 And Abimelech called Isaac, and said, Behold, of a surety she is thy wife: and how saidst thou, She is my sister? And Isaac said unto him, Because I said, Lest I die for her.

Genesis 26:10 And Abimelech said, What is this thou hast done unto us? one of the people might lightly have lien with thy wife, and thou shouldest have brought guiltiness upon us.

Genesis 26:11 And Abimelech charged all his people, saying, He that toucheth this man or his wife shall surely be put to death.

Genesis 26:12 Then Isaac sowed in that land, and received in the same year an hundredfold: and the Lord blessed him.

Genesis 26:13 And the man waxed great, and went forward, and grew until he became very great:

Genesis 26:14 For he had possession of flocks, and possession of herds, and great store of servants: and the Philistines envied him.

Genesis 26:15 For all the wells which his father’s servants had digged in the days of Abraham his father, the Philistines had stopped them, and filled them with earth.

Genesis 26:16 And Abimelech said unto Isaac, Go from us; for thou art much mightier than we.

Genesis 26:17 And Isaac departed thence, and pitched his tent in the valley of Gerar, and dwelt there.

Genesis 26:18 And Isaac digged again the wells of water, which they had digged in the days of Abraham his father; for the Philistines had stopped them after the death of Abraham: and he called their names after the names by which his father had called them.

Genesis 26:19 And Isaac’s servants digged in the valley, and found there a well of springing water.

Genesis 26:20 And the herdmen of Gerar did strive with Isaac’s herdmen, saying, The water is ours: and he called the name of the well Esek; because they strove with him.

Genesis 26:21 And they digged another well, and strove for that also: and he called the name of it Sitnah.

Genesis 26:22 And he removed from thence, and digged another well; and for that they strove not: and he called the name of it Rehoboth; and he said, For now the Lord hath made room for us, and we shall be fruitful in the land.

Genesis 26:23 And he went up from thence to Beer-sheba.

Genesis 26:24 And the Lord appeared unto him the same night, and said, I am the God of Abraham thy father: fear not, for I am with thee, and will bless thee, and multiply thy seed for my servant Abraham’s sake.

Genesis 26:25 And he builded an altar there, and called upon the name of the Lord, and pitched his tent there: and there Isaac’s servants digged a well.

Genesis 26:26 Then Abimelech went to him from Gerar, and Ahuzzath one of his friends, and Phichol the chief captain of his army.

Genesis 26:27 And Isaac said unto them, Wherefore come ye to me, seeing ye hate me, and have sent me away from you?

Genesis 26:28 And they said, We saw certainly that the Lord was with thee: and we said, Let there be now an oath betwixt us, even betwixt us and thee, and let us make a covenant with thee;

Genesis 26:29 That thou wilt do us no hurt, as we have not touched thee, and as we have done unto thee nothing but good, and have sent thee away in peace: thou art now the blessed of the Lord.

Genesis 26:30 And he made them a feast, and they did eat and drink.

Genesis 26:31 And they rose up betimes in the morning, and sware one to another: and Isaac sent them away, and they departed from him in peace.

Genesis 26:32 And it came to pass the same day, that Isaac’s servants came, and told him concerning the well which they had digged, and said unto him, We have found water.

Genesis 26:33 And he called it Shebah: therefore the name of the city is Beer-sheba unto this day.

Genesis 26:34 And Esau was forty years old when he took to wife Judith the daughter of Beeri the Hittite, and Bashemath the daughter of Elon the Hittite:

Genesis 26:35 Which were a grief of mind unto Isaac and to Rebekah.
