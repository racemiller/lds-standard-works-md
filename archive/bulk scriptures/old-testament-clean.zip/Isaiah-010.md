# Isaiah 10

Isaiah 10 (summary): The destruction of Assyria is a type of the destruction of the wicked at the Second Coming—Few people will be left after the Lord comes again—The remnant of Jacob will return in that day—Compare 2 Nephi 20.

Isaiah 10:1 Woe unto them that decree unrighteous decrees, and that write grievousness which they have prescribed;

Isaiah 10:2 To turn aside the needy from judgment, and to take away the right from the poor of my people, that widows may be their prey, and that they may rob the fatherless!

Isaiah 10:3 And what will ye do in the day of visitation, and in the desolation which shall come from far? to whom will ye flee for help? and where will ye leave your glory?

Isaiah 10:4 Without me they shall bow down under the prisoners, and they shall fall under the slain. For all this his anger is not turned away, but his hand is stretched out still.

Isaiah 10:5 O Assyrian, the rod of mine anger, and the staff in their hand is mine indignation.

Isaiah 10:6 I will send him against an hypocritical nation, and against the people of my wrath will I give him a charge, to take the spoil, and to take the prey, and to tread them down like the mire of the streets.

Isaiah 10:7 Howbeit he meaneth not so, neither doth his heart think so; but it is in his heart to destroy and cut off nations not a few.

Isaiah 10:8 For he saith, Are not my princes altogether kings?

Isaiah 10:9 Is not Calno as Carchemish? is not Hamath as Arpad? is not Samaria as Damascus?

Isaiah 10:10 As my hand hath found the kingdoms of the idols, and whose graven images did excel them of Jerusalem and of Samaria;

Isaiah 10:11 Shall I not, as I have done unto Samaria and her idols, so do to Jerusalem and her idols?

Isaiah 10:12 Wherefore it shall come to pass, that when the Lord hath performed his whole work upon mount Zion and on Jerusalem, I will punish the fruit of the stout heart of the king of Assyria, and the glory of his high looks.

Isaiah 10:13 For he saith, By the strength of my hand I have done it, and by my wisdom; for I am prudent: and I have removed the bounds of the people, and have robbed their treasures, and I have put down the inhabitants like a valiant man:

Isaiah 10:14 And my hand hath found as a nest the riches of the people: and as one gathereth eggs that are left, have I gathered all the earth; and there was none that moved the wing, or opened the mouth, or peeped.

Isaiah 10:15 Shall the axe boast itself against him that heweth therewith? or shall the saw magnify itself against him that shaketh it? as if the rod should shake itself against them that lift it up, or as if the staff should lift up itself, as if it were no wood.

Isaiah 10:16 Therefore shall the Lord, the Lord of hosts, send among his fat ones leanness; and under his glory he shall kindle a burning like the burning of a fire.

Isaiah 10:17 And the light of Israel shall be for a fire, and his Holy One for a flame: and it shall burn and devour his thorns and his briers in one day;

Isaiah 10:18 And shall consume the glory of his forest, and of his fruitful field, both soul and body: and they shall be as when a standardbearer fainteth.

Isaiah 10:19 And the rest of the trees of his forest shall be few, that a child may write them.

Isaiah 10:20 And it shall come to pass in that day, that the remnant of Israel, and such as are escaped of the house of Jacob, shall no more again stay upon him that smote them; but shall stay upon the Lord, the Holy One of Israel, in truth.

Isaiah 10:21 The remnant shall return, even the remnant of Jacob, unto the mighty God.

Isaiah 10:22 For though thy people Israel be as the sand of the sea, yet a remnant of them shall return: the consumption decreed shall overflow with righteousness.

Isaiah 10:23 For the Lord God of hosts shall make a consumption, even determined, in the midst of all the land.

Isaiah 10:24 Therefore thus saith the Lord God of hosts, O my people that dwellest in Zion, be not afraid of the Assyrian: he shall smite thee with a rod, and shall lift up his staff against thee, after the manner of Egypt.

Isaiah 10:25 For yet a very little while, and the indignation shall cease, and mine anger in their destruction.

Isaiah 10:26 And the Lord of hosts shall stir up a scourge for him according to the slaughter of Midian at the rock of Oreb: and as his rod was upon the sea, so shall he lift it up after the manner of Egypt.

Isaiah 10:27 And it shall come to pass in that day, that his burden shall be taken away from off thy shoulder, and his yoke from off thy neck, and the yoke shall be destroyed because of the anointing.

Isaiah 10:28 He is come to Aiath, he is passed to Migron; at Michmash he hath laid up his carriages:

Isaiah 10:29 They are gone over the passage: they have taken up their lodging at Geba; Ramah is afraid; Gibeah of Saul is fled.

Isaiah 10:30 Lift up thy voice, O daughter of Gallim: cause it to be heard unto Laish, O poor Anathoth.

Isaiah 10:31 Madmenah is removed; the inhabitants of Gebim gather themselves to flee.

Isaiah 10:32 As yet shall he remain at Nob that day: he shall shake his hand against the mount of the daughter of Zion, the hill of Jerusalem.

Isaiah 10:33 Behold, the Lord, the Lord of hosts, shall lop the bough with terror: and the high ones of stature shall be hewn down, and the haughty shall be humbled.

Isaiah 10:34 And he shall cut down the thickets of the forest with iron, and Lebanon shall fall by a mighty one.
