# Amos 2

Amos 2 (summary): The Lord will pour out judgments upon Moab, Judah, and Israel for their unrighteousness.

Amos 2:1 Thus saith the Lord; For three transgressions of Moab, and for four, I will not turn away the punishment thereof; because he burned the bones of the king of Edom into lime:

Amos 2:2 But I will send a fire upon Moab, and it shall devour the palaces of Kerioth: and Moab shall die with tumult, with shouting, and with the sound of the trumpet:

Amos 2:3 And I will cut off the judge from the midst thereof, and will slay all the princes thereof with him, saith the Lord.

Amos 2:4 Thus saith the Lord; For three transgressions of Judah, and for four, I will not turn away the punishment thereof; because they have despised the law of the Lord, and have not kept his commandments, and their lies caused them to err, after the which their fathers have walked:

Amos 2:5 But I will send a fire upon Judah, and it shall devour the palaces of Jerusalem.

Amos 2:6 Thus saith the Lord; For three transgressions of Israel, and for four, I will not turn away the punishment thereof; because they sold the righteous for silver, and the poor for a pair of shoes;

Amos 2:7 That pant after the dust of the earth on the head of the poor, and turn aside the way of the meek: and a man and his father will go in unto the same maid, to profane my holy name:

Amos 2:8 And they lay themselves down upon clothes laid to pledge by every altar, and they drink the wine of the condemned in the house of their god.

Amos 2:9 Yet destroyed I the Amorite before them, whose height was like the height of the cedars, and he was strong as the oaks; yet I destroyed his fruit from above, and his roots from beneath.

Amos 2:10 Also I brought you up from the land of Egypt, and led you forty years through the wilderness, to possess the land of the Amorite.

Amos 2:11 And I raised up of your sons for prophets, and of your young men for Nazarites. Is it not even thus, O ye children of Israel? saith the Lord.

Amos 2:12 But ye gave the Nazarites wine to drink; and commanded the prophets, saying, Prophesy not.

Amos 2:13 Behold, I am pressed under you, as a cart is pressed that is full of sheaves.

Amos 2:14 Therefore the flight shall perish from the swift, and the strong shall not strengthen his force, neither shall the mighty deliver himself:

Amos 2:15 Neither shall he stand that handleth the bow; and he that is swift of foot shall not deliver himself: neither shall he that rideth the horse deliver himself.

Amos 2:16 And he that is courageous among the mighty shall flee away naked in that day, saith the Lord.
