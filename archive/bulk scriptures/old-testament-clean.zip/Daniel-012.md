# Daniel 12

Daniel 12 (summary): In the last days, Michael will deliver Israel from their troubles—Daniel tells of the two resurrections—The wise will know the times and meanings of his visions.

Daniel 12:1 And at that time shall Michael stand up, the great prince which standeth for the children of thy people: and there shall be a time of trouble, such as never was since there was a nation even to that same time: and at that time thy people shall be delivered, every one that shall be found written in the book.

Daniel 12:2 And many of them that sleep in the dust of the earth shall awake, some to everlasting life, and some to shame and everlasting contempt.

Daniel 12:3 And they that be wise shall shine as the brightness of the firmament; and they that turn many to righteousness as the stars for ever and ever.

Daniel 12:4 But thou, O Daniel, shut up the words, and seal the book, even to the time of the end: many shall run to and fro, and knowledge shall be increased.

Daniel 12:5 Then I Daniel looked, and, behold, there stood other two, the one on this side of the bank of the river, and the other on that side of the bank of the river.

Daniel 12:6 And one said to the man clothed in linen, which was upon the waters of the river, How long shall it be to the end of these wonders?

Daniel 12:7 And I heard the man clothed in linen, which was upon the waters of the river, when he held up his right hand and his left hand unto heaven, and sware by him that liveth for ever that it shall be for a time, times, and an half; and when he shall have accomplished to scatter the power of the holy people, all these things shall be finished.

Daniel 12:8 And I heard, but I understood not: then said I, O my Lord, what shall be the end of these things?

Daniel 12:9 And he said, Go thy way, Daniel: for the words are closed up and sealed till the time of the end.

Daniel 12:10 Many shall be purified, and made white, and tried; but the wicked shall do wickedly: and none of the wicked shall understand; but the wise shall understand.

Daniel 12:11 And from the time that the daily sacrifice shall be taken away, and the abomination that maketh desolate set up, there shall be a thousand two hundred and ninety days.

Daniel 12:12 Blessed is he that waiteth, and cometh to the thousand three hundred and five and thirty days.

Daniel 12:13 But go thou thy way till the end be: for thou shalt rest, and stand in thy lot at the end of the days.
