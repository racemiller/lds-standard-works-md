# Psalms 69

Psalms 69 (summary): A messianic psalm of David—The zeal of the Lord’s house has eaten Him up—Reproach has broken His heart—He is given gall and vinegar to drink—He is persecuted—He will save Zion.

Psalms 69:1 Save me, O God; for the waters are come in unto my soul.

Psalms 69:2 I sink in deep mire, where there is no standing: I am come into deep waters, where the floods overflow me.

Psalms 69:3 I am weary of my crying: my throat is dried: mine eyes fail while I wait for my God.

Psalms 69:4 They that hate me without a cause are more than the hairs of mine head: they that would destroy me, being mine enemies wrongfully, are mighty: then I restored that which I took not away.

Psalms 69:5 O God, thou knowest my foolishness; and my sins are not hid from thee.

Psalms 69:6 Let not them that wait on thee, O Lord God of hosts, be ashamed for my sake: let not those that seek thee be confounded for my sake, O God of Israel.

Psalms 69:7 Because for thy sake I have borne reproach; shame hath covered my face.

Psalms 69:8 I am become a stranger unto my brethren, and an alien unto my mother’s children.

Psalms 69:9 For the zeal of thine house hath eaten me up; and the reproaches of them that reproached thee are fallen upon me.

Psalms 69:10 When I wept, and chastened my soul with fasting, that was to my reproach.

Psalms 69:11 I made sackcloth also my garment; and I became a proverb to them.

Psalms 69:12 They that sit in the gate speak against me; and I was the song of the drunkards.

Psalms 69:13 But as for me, my prayer is unto thee, O Lord, in an acceptable time: O God, in the multitude of thy mercy hear me, in the truth of thy salvation.

Psalms 69:14 Deliver me out of the mire, and let me not sink: let me be delivered from them that hate me, and out of the deep waters.

Psalms 69:15 Let not the waterflood overflow me, neither let the deep swallow me up, and let not the pit shut her mouth upon me.

Psalms 69:16 Hear me, O Lord; for thy lovingkindness is good: turn unto me according to the multitude of thy tender mercies.

Psalms 69:17 And hide not thy face from thy servant; for I am in trouble: hear me speedily.

Psalms 69:18 Draw nigh unto my soul, and redeem it: deliver me because of mine enemies.

Psalms 69:19 Thou hast known my reproach, and my shame, and my dishonour: mine adversaries are all before thee.

Psalms 69:20 Reproach hath broken my heart; and I am full of heaviness: and I looked for some to take pity, but there was none; and for comforters, but I found none.

Psalms 69:21 They gave me also gall for my meat; and in my thirst they gave me vinegar to drink.

Psalms 69:22 Let their table become a snare before them: and that which should have been for their welfare, let it become a trap.

Psalms 69:23 Let their eyes be darkened, that they see not; and make their loins continually to shake.

Psalms 69:24 Pour out thine indignation upon them, and let thy wrathful anger take hold of them.

Psalms 69:25 Let their habitation be desolate; and let none dwell in their tents.

Psalms 69:26 For they persecute him whom thou hast smitten; and they talk to the grief of those whom thou hast wounded.

Psalms 69:27 Add iniquity unto their iniquity: and let them not come into thy righteousness.

Psalms 69:28 Let them be blotted out of the book of the living, and not be written with the righteous.

Psalms 69:29 But I am poor and sorrowful: let thy salvation, O God, set me up on high.

Psalms 69:30 I will praise the name of God with a song, and will magnify him with thanksgiving.

Psalms 69:31 This also shall please the Lord better than an ox or bullock that hath horns and hoofs.

Psalms 69:32 The humble shall see this, and be glad: and your heart shall live that seek God.

Psalms 69:33 For the Lord heareth the poor, and despiseth not his prisoners.

Psalms 69:34 Let the heaven and earth praise him, the seas, and every thing that moveth therein.

Psalms 69:35 For God will save Zion, and will build the cities of Judah: that they may dwell there, and have it in possession.

Psalms 69:36 The seed also of his servants shall inherit it: and they that love his name shall dwell therein.
