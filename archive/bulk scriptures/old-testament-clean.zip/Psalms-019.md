# Psalms 19

Psalms 19 (summary): David testifies, The heavens declare the glory of God, the law of the Lord is perfect, and the judgments of the Lord are true and righteous altogether.

Psalms 19:1 The heavens declare the glory of God; and the firmament sheweth his handywork.

Psalms 19:2 Day unto day uttereth speech, and night unto night sheweth knowledge.

Psalms 19:3 There is no speech nor language, where their voice is not heard.

Psalms 19:4 Their line is gone out through all the earth, and their words to the end of the world. In them hath he set a tabernacle for the sun,

Psalms 19:5 Which is as a bridegroom coming out of his chamber, and rejoiceth as a strong man to run a race.

Psalms 19:6 His going forth is from the end of the heaven, and his circuit unto the ends of it: and there is nothing hid from the heat thereof.

Psalms 19:7 The law of the Lord is perfect, converting the soul: the testimony of the Lord is sure, making wise the simple.

Psalms 19:8 The statutes of the Lord are right, rejoicing the heart: the commandment of the Lord is pure, enlightening the eyes.

Psalms 19:9 The fear of the Lord is clean, enduring for ever: the judgments of the Lord are true and righteous altogether.

Psalms 19:10 More to be desired are they than gold, yea, than much fine gold: sweeter also than honey and the honeycomb.

Psalms 19:11 Moreover by them is thy servant warned: and in keeping of them there is great reward.

Psalms 19:12 Who can understand his errors? cleanse thou me from secret faults.

Psalms 19:13 Keep back thy servant also from presumptuous sins; let them not have dominion over me: then shall I be upright, and I shall be innocent from the great transgression.

Psalms 19:14 Let the words of my mouth, and the meditation of my heart, be acceptable in thy sight, O Lord, my strength, and my redeemer.
