# Leviticus 4

Leviticus 4 (summary): Sinners are forgiven through sin offerings of animals without blemish—Priests thereby make an atonement for the sins of the people.

Leviticus 4:1 And the Lord spake unto Moses, saying,

Leviticus 4:2 Speak unto the children of Israel, saying, If a soul shall sin through ignorance against any of the commandments of the Lord concerning things which ought not to be done, and shall do against any of them:

Leviticus 4:3 If the priest that is anointed do sin according to the sin of the people; then let him bring for his sin, which he hath sinned, a young bullock without blemish unto the Lord for a sin offering.

Leviticus 4:4 And he shall bring the bullock unto the door of the tabernacle of the congregation before the Lord; and shall lay his hand upon the bullock’s head, and kill the bullock before the Lord.

Leviticus 4:5 And the priest that is anointed shall take of the bullock’s blood, and bring it to the tabernacle of the congregation:

Leviticus 4:6 And the priest shall dip his finger in the blood, and sprinkle of the blood seven times before the Lord, before the veil of the sanctuary.

Leviticus 4:7 And the priest shall put some of the blood upon the horns of the altar of sweet incense before the Lord, which is in the tabernacle of the congregation; and shall pour all the blood of the bullock at the bottom of the altar of the burnt offering, which is at the door of the tabernacle of the congregation.

Leviticus 4:8 And he shall take off from it all the fat of the bullock for the sin offering; the fat that covereth the inwards, and all the fat that is upon the inwards,

Leviticus 4:9 And the two kidneys, and the fat that is upon them, which is by the flanks, and the caul above the liver, with the kidneys, it shall he take away,

Leviticus 4:10 As it was taken off from the bullock of the sacrifice of peace offerings: and the priest shall burn them upon the altar of the burnt offering.

Leviticus 4:11 And the skin of the bullock, and all his flesh, with his head, and with his legs, and his inwards, and his dung,

Leviticus 4:12 Even the whole bullock shall he carry forth without the camp unto a clean place, where the ashes are poured out, and burn him on the wood with fire: where the ashes are poured out shall he be burnt.

Leviticus 4:13 And if the whole congregation of Israel sin through ignorance, and the thing be hid from the eyes of the assembly, and they have done somewhat against any of the commandments of the Lord concerning things which should not be done, and are guilty;

Leviticus 4:14 When the sin, which they have sinned against it, is known, then the congregation shall offer a young bullock for the sin, and bring him before the tabernacle of the congregation.

Leviticus 4:15 And the elders of the congregation shall lay their hands upon the head of the bullock before the Lord: and the bullock shall be killed before the Lord.

Leviticus 4:16 And the priest that is anointed shall bring of the bullock’s blood to the tabernacle of the congregation:

Leviticus 4:17 And the priest shall dip his finger in some of the blood, and sprinkle it seven times before the Lord, even before the veil.

Leviticus 4:18 And he shall put some of the blood upon the horns of the altar which is before the Lord, that is in the tabernacle of the congregation, and shall pour out all the blood at the bottom of the altar of the burnt offering, which is at the door of the tabernacle of the congregation.

Leviticus 4:19 And he shall take all his fat from him, and burn it upon the altar.

Leviticus 4:20 And he shall do with the bullock as he did with the bullock for a sin offering, so shall he do with this: and the priest shall make an atonement for them, and it shall be forgiven them.

Leviticus 4:21 And he shall carry forth the bullock without the camp, and burn him as he burned the first bullock: it is a sin offering for the congregation.

Leviticus 4:22 When a ruler hath sinned, and done somewhat through ignorance against any of the commandments of the Lord his God concerning things which should not be done, and is guilty;

Leviticus 4:23 Or if his sin, wherein he hath sinned, come to his knowledge; he shall bring his offering, a kid of the goats, a male without blemish:

Leviticus 4:24 And he shall lay his hand upon the head of the goat, and kill it in the place where they kill the burnt offering before the Lord: it is a sin offering.

Leviticus 4:25 And the priest shall take of the blood of the sin offering with his finger, and put it upon the horns of the altar of burnt offering, and shall pour out his blood at the bottom of the altar of burnt offering.

Leviticus 4:26 And he shall burn all his fat upon the altar, as the fat of the sacrifice of peace offerings: and the priest shall make an atonement for him as concerning his sin, and it shall be forgiven him.

Leviticus 4:27 And if any one of the common people sin through ignorance, while he doeth somewhat against any of the commandments of the Lord concerning things which ought not to be done, and be guilty;

Leviticus 4:28 Or if his sin, which he hath sinned, come to his knowledge: then he shall bring his offering, a kid of the goats, a female without blemish, for his sin which he hath sinned.

Leviticus 4:29 And he shall lay his hand upon the head of the sin offering, and slay the sin offering in the place of the burnt offering.

Leviticus 4:30 And the priest shall take of the blood thereof with his finger, and put it upon the horns of the altar of burnt offering, and shall pour out all the blood thereof at the bottom of the altar.

Leviticus 4:31 And he shall take away all the fat thereof, as the fat is taken away from off the sacrifice of peace offerings; and the priest shall burn it upon the altar for a sweet savour unto the Lord; and the priest shall make an atonement for him, and it shall be forgiven him.

Leviticus 4:32 And if he bring a lamb for a sin offering, he shall bring it a female without blemish.

Leviticus 4:33 And he shall lay his hand upon the head of the sin offering, and slay it for a sin offering in the place where they kill the burnt offering.

Leviticus 4:34 And the priest shall take of the blood of the sin offering with his finger, and put it upon the horns of the altar of burnt offering, and shall pour out all the blood thereof at the bottom of the altar:

Leviticus 4:35 And he shall take away all the fat thereof, as the fat of the lamb is taken away from the sacrifice of the peace offerings; and the priest shall burn them upon the altar, according to the offerings made by fire unto the Lord: and the priest shall make an atonement for his sin that he hath committed, and it shall be forgiven him.
