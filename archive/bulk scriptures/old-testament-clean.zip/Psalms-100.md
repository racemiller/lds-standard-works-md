# Psalms 100

Psalms 100 (summary): Serve the Lord with gladness, all who are His people—Be thankful unto Him and bless His name.

Psalms 100:1 Make a joyful noise unto the Lord, all ye lands.

Psalms 100:2 Serve the Lord with gladness: come before his presence with singing.

Psalms 100:3 Know ye that the Lord he is God: it is he that hath made us, and not we ourselves; we are his people, and the sheep of his pasture.

Psalms 100:4 Enter into his gates with thanksgiving, and into his courts with praise: be thankful unto him, and bless his name.

Psalms 100:5 For the Lord is good; his mercy is everlasting; and his truth endureth to all generations.
