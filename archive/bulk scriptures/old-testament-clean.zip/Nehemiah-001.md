# Nehemiah 1

Nehemiah 1 (summary): Nehemiah mourns, fasts, and prays for the Jews in Jerusalem.

Nehemiah 1:1 The words of Nehemiah the son of Hachaliah. And it came to pass in the month Chisleu, in the twentieth year, as I was in Shushan the palace,

Nehemiah 1:2 That Hanani, one of my brethren, came, he and certain men of Judah; and I asked them concerning the Jews that had escaped, which were left of the captivity, and concerning Jerusalem.

Nehemiah 1:3 And they said unto me, The remnant that are left of the captivity there in the province are in great affliction and reproach: the wall of Jerusalem also is broken down, and the gates thereof are burned with fire.

Nehemiah 1:4 And it came to pass, when I heard these words, that I sat down and wept, and mourned certain days, and fasted, and prayed before the God of heaven,

Nehemiah 1:5 And said, I beseech thee, O Lord God of heaven, the great and terrible God, that keepeth covenant and mercy for them that love him and observe his commandments:

Nehemiah 1:6 Let thine ear now be attentive, and thine eyes open, that thou mayest hear the prayer of thy servant, which I pray before thee now, day and night, for the children of Israel thy servants, and confess the sins of the children of Israel, which we have sinned against thee: both I and my father’s house have sinned.

Nehemiah 1:7 We have dealt very corruptly against thee, and have not kept the commandments, nor the statutes, nor the judgments, which thou commandedst thy servant Moses.

Nehemiah 1:8 Remember, I beseech thee, the word that thou commandedst thy servant Moses, saying, If ye transgress, I will scatter you abroad among the nations:

Nehemiah 1:9 But if ye turn unto me, and keep my commandments, and do them; though there were of you cast out unto the uttermost part of the heaven, yet will I gather them from thence, and will bring them unto the place that I have chosen to set my name there.

Nehemiah 1:10 Now these are thy servants and thy people, whom thou hast redeemed by thy great power, and by thy strong hand.

Nehemiah 1:11 O Lord, I beseech thee, let now thine ear be attentive to the prayer of thy servant, and to the prayer of thy servants, who desire to fear thy name: and prosper, I pray thee, thy servant this day, and grant him mercy in the sight of this man. For I was the king’s cupbearer.
