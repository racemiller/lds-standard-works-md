# 2 Chronicles 29

2 Chronicles 29 (summary): Hezekiah reigns in righteousness and restores the worship of Jehovah—The Levites cleanse and sanctify the house of the Lord—The priests offer sacrifices and make reconciliation and atonement for the people—Hezekiah and all the people worship the Lord and praise His name.

2 Chronicles 29:1 Hezekiah began to reign when he was five and twenty years old, and he reigned nine and twenty years in Jerusalem. And his mother’s name was Abijah, the daughter of Zechariah.

2 Chronicles 29:2 And he did that which was right in the sight of the Lord, according to all that David his father had done.

2 Chronicles 29:3 He in the first year of his reign, in the first month, opened the doors of the house of the Lord, and repaired them.

2 Chronicles 29:4 And he brought in the priests and the Levites, and gathered them together into the east street,

2 Chronicles 29:5 And said unto them, Hear me, ye Levites, sanctify now yourselves, and sanctify the house of the Lord God of your fathers, and carry forth the filthiness out of the holy place.

2 Chronicles 29:6 For our fathers have trespassed, and done that which was evil in the eyes of the Lord our God, and have forsaken him, and have turned away their faces from the habitation of the Lord, and turned their backs.

2 Chronicles 29:7 Also they have shut up the doors of the porch, and put out the lamps, and have not burned incense nor offered burnt offerings in the holy place unto the God of Israel.

2 Chronicles 29:8 Wherefore the wrath of the Lord was upon Judah and Jerusalem, and he hath delivered them to trouble, to astonishment, and to hissing, as ye see with your eyes.

2 Chronicles 29:9 For, lo, our fathers have fallen by the sword, and our sons and our daughters and our wives are in captivity for this.

2 Chronicles 29:10 Now it is in mine heart to make a covenant with the Lord God of Israel, that his fierce wrath may turn away from us.

2 Chronicles 29:11 My sons, be not now negligent: for the Lord hath chosen you to stand before him, to serve him, and that ye should minister unto him, and burn incense.

2 Chronicles 29:12 Then the Levites arose, Mahath the son of Amasai, and Joel the son of Azariah, of the sons of the Kohathites: and of the sons of Merari, Kish the son of Abdi, and Azariah the son of Jehalelel: and of the Gershonites; Joah the son of Zimmah, and Eden the son of Joah:

2 Chronicles 29:13 And of the sons of Elizaphan; Shimri, and Jeiel: and of the sons of Asaph; Zechariah, and Mattaniah:

2 Chronicles 29:14 And of the sons of Heman; Jehiel, and Shimei: and of the sons of Jeduthun; Shemaiah, and Uzziel.

2 Chronicles 29:15 And they gathered their brethren, and sanctified themselves, and came, according to the commandment of the king, by the words of the Lord, to cleanse the house of the Lord.

2 Chronicles 29:16 And the priests went into the inner part of the house of the Lord, to cleanse it, and brought out all the uncleanness that they found in the temple of the Lord into the court of the house of the Lord. And the Levites took it, to carry it out abroad into the brook Kidron.

2 Chronicles 29:17 Now they began on the first day of the first month to sanctify, and on the eighth day of the month came they to the porch of the Lord: so they sanctified the house of the Lord in eight days; and in the sixteenth day of the first month they made an end.

2 Chronicles 29:18 Then they went in to Hezekiah the king, and said, We have cleansed all the house of the Lord, and the altar of burnt offering, with all the vessels thereof, and the shewbread table, with all the vessels thereof.

2 Chronicles 29:19 Moreover all the vessels, which king Ahaz in his reign did cast away in his transgression, have we prepared and sanctified, and, behold, they are before the altar of the Lord.

2 Chronicles 29:20 Then Hezekiah the king rose early, and gathered the rulers of the city, and went up to the house of the Lord.

2 Chronicles 29:21 And they brought seven bullocks, and seven rams, and seven lambs, and seven he goats, for a sin offering for the kingdom, and for the sanctuary, and for Judah. And he commanded the priests the sons of Aaron to offer them on the altar of the Lord.

2 Chronicles 29:22 So they killed the bullocks, and the priests received the blood, and sprinkled it on the altar: likewise, when they had killed the rams, they sprinkled the blood upon the altar: they killed also the lambs, and they sprinkled the blood upon the altar.

2 Chronicles 29:23 And they brought forth the he goats for the sin offering before the king and the congregation; and they laid their hands upon them:

2 Chronicles 29:24 And the priests killed them, and they made reconciliation with their blood upon the altar, to make an atonement for all Israel: for the king commanded that the burnt offering and the sin offering should be made for all Israel.

2 Chronicles 29:25 And he set the Levites in the house of the Lord with cymbals, with psalteries, and with harps, according to the commandment of David, and of Gad the king’s seer, and Nathan the prophet: for so was the commandment of the Lord by his prophets.

2 Chronicles 29:26 And the Levites stood with the instruments of David, and the priests with the trumpets.

2 Chronicles 29:27 And Hezekiah commanded to offer the burnt offering upon the altar. And when the burnt offering began, the song of the Lord began also with the trumpets, and with the instruments ordained by David king of Israel.

2 Chronicles 29:28 And all the congregation worshipped, and the singers sang, and the trumpeters sounded: and all this continued until the burnt offering was finished.

2 Chronicles 29:29 And when they had made an end of offering, the king and all that were present with him bowed themselves, and worshipped.

2 Chronicles 29:30 Moreover Hezekiah the king and the princes commanded the Levites to sing praise unto the Lord with the words of David, and of Asaph the seer. And they sang praises with gladness, and they bowed their heads and worshipped.

2 Chronicles 29:31 Then Hezekiah answered and said, Now ye have consecrated yourselves unto the Lord, come near and bring sacrifices and thank offerings into the house of the Lord. And the congregation brought in sacrifices and thank offerings; and as many as were of a free heart burnt offerings.

2 Chronicles 29:32 And the number of the burnt offerings, which the congregation brought, was threescore and ten bullocks, an hundred rams, and two hundred lambs: all these were for a burnt offering to the Lord.

2 Chronicles 29:33 And the consecrated things were six hundred oxen and three thousand sheep.

2 Chronicles 29:34 But the priests were too few, so that they could not flay all the burnt offerings: wherefore their brethren the Levites did help them, till the work was ended, and until the other priests had sanctified themselves: for the Levites were more upright in heart to sanctify themselves than the priests.

2 Chronicles 29:35 And also the burnt offerings were in abundance, with the fat of the peace offerings, and the drink offerings for every burnt offering. So the service of the house of the Lord was set in order.

2 Chronicles 29:36 And Hezekiah rejoiced, and all the people, that God had prepared the people: for the thing was done suddenly.
