# Joshua 18

Joshua 18 (summary): The tabernacle of the congregation is set up at Shiloh—Benjamin receives an inheritance by lot.

Joshua 18:1 And the whole congregation of the children of Israel assembled together at Shiloh, and set up the tabernacle of the congregation there. And the land was subdued before them.

Joshua 18:2 And there remained among the children of Israel seven tribes, which had not yet received their inheritance.

Joshua 18:3 And Joshua said unto the children of Israel, How long are ye slack to go to possess the land, which the Lord God of your fathers hath given you?

Joshua 18:4 Give out from among you three men for each tribe: and I will send them, and they shall rise, and go through the land, and describe it according to the inheritance of them; and they shall come again to me.

Joshua 18:5 And they shall divide it into seven parts: Judah shall abide in their coast on the south, and the house of Joseph shall abide in their coasts on the north.

Joshua 18:6 Ye shall therefore describe the land into seven parts, and bring the description hither to me, that I may cast lots for you here before the Lord our God.

Joshua 18:7 But the Levites have no part among you; for the priesthood of the Lord is their inheritance: and Gad, and Reuben, and half the tribe of Manasseh, have received their inheritance beyond Jordan on the east, which Moses the servant of the Lord gave them.

Joshua 18:8 And the men arose, and went away: and Joshua charged them that went to describe the land, saying, Go and walk through the land, and describe it, and come again to me, that I may here cast lots for you before the Lord in Shiloh.

Joshua 18:9 And the men went and passed through the land, and described it by cities into seven parts in a book, and came again to Joshua to the host at Shiloh.

Joshua 18:10 And Joshua cast lots for them in Shiloh before the Lord: and there Joshua divided the land unto the children of Israel according to their divisions.

Joshua 18:11 And the lot of the tribe of the children of Benjamin came up according to their families: and the coast of their lot came forth between the children of Judah and the children of Joseph.

Joshua 18:12 And their border on the north side was from Jordan; and the border went up to the side of Jericho on the north side, and went up through the mountains westward; and the goings out thereof were at the wilderness of Beth-aven.

Joshua 18:13 And the border went over from thence toward Luz, to the side of Luz, which is Beth-el, southward; and the border descended to Ataroth-adar, near the hill that lieth on the south side of the nether Beth-horon.

Joshua 18:14 And the border was drawn thence, and compassed the corner of the sea southward, from the hill that lieth before Beth-horon southward; and the goings out thereof were at Kirjath-baal, which is Kirjath-jearim, a city of the children of Judah: this was the west quarter.

Joshua 18:15 And the south quarter was from the end of Kirjath-jearim, and the border went out on the west, and went out to the well of waters of Nephtoah:

Joshua 18:16 And the border came down to the end of the mountain that lieth before the valley of the son of Hinnom, and which is in the valley of the giants on the north, and descended to the valley of Hinnom, to the side of Jebusi on the south, and descended to En-rogel,

Joshua 18:17 And was drawn from the north, and went forth to En-shemesh, and went forth toward Geliloth, which is over against the going up of Adummim, and descended to the stone of Bohan the son of Reuben,

Joshua 18:18 And passed along toward the side over against Arabah northward, and went down unto Arabah:

Joshua 18:19 And the border passed along to the side of Beth-hoglah northward: and the outgoings of the border were at the north bay of the salt sea at the south end of Jordan: this was the south coast.

Joshua 18:20 And Jordan was the border of it on the east side. This was the inheritance of the children of Benjamin, by the coasts thereof round about, according to their families.

Joshua 18:21 Now the cities of the tribe of the children of Benjamin according to their families were Jericho, and Beth-hoglah, and the valley of Keziz,

Joshua 18:22 And Beth-arabah, and Zemaraim, and Beth-el,

Joshua 18:23 And Avim, and Parah, and Ophrah,

Joshua 18:24 And Chephar-haammonai, and Ophni, and Gaba; twelve cities with their villages:

Joshua 18:25 Gibeon, and Ramah, and Beeroth,

Joshua 18:26 And Mizpeh, and Chephirah, and Mozah,

Joshua 18:27 And Rekem, and Irpeel, and Taralah,

Joshua 18:28 And Zelah, Eleph, and Jebusi, which is Jerusalem, Gibeath, and Kirjath; fourteen cities with their villages. This is the inheritance of the children of Benjamin according to their families.
