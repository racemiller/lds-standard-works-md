# Ezra 4

Ezra 4 (summary): The Samaritans offer help, then hinder the work—The building of the temple and of the walls of Jerusalem ceases.

Ezra 4:1 Now when the adversaries of Judah and Benjamin heard that the children of the captivity builded the temple unto the Lord God of Israel;

Ezra 4:2 Then they came to Zerubbabel, and to the chief of the fathers, and said unto them, Let us build with you: for we seek your God, as ye do; and we do sacrifice unto him since the days of Esar-haddon king of Assur, which brought us up hither.

Ezra 4:3 But Zerubbabel, and Jeshua, and the rest of the chief of the fathers of Israel, said unto them, Ye have nothing to do with us to build an house unto our God; but we ourselves together will build unto the Lord God of Israel, as king Cyrus the king of Persia hath commanded us.

Ezra 4:4 Then the people of the land weakened the hands of the people of Judah, and troubled them in building,

Ezra 4:5 And hired counsellors against them, to frustrate their purpose, all the days of Cyrus king of Persia, even until the reign of Darius king of Persia.

Ezra 4:6 And in the reign of Ahasuerus, in the beginning of his reign, wrote they unto him an accusation against the inhabitants of Judah and Jerusalem.

Ezra 4:7 And in the days of Artaxerxes wrote Bishlam, Mithredath, Tabeel, and the rest of their companions, unto Artaxerxes king of Persia; and the writing of the letter was written in the Syrian tongue, and interpreted in the Syrian tongue.

Ezra 4:8 Rehum the chancellor and Shimshai the scribe wrote a letter against Jerusalem to Artaxerxes the king in this sort:

Ezra 4:9 Then wrote Rehum the chancellor, and Shimshai the scribe, and the rest of their companions; the Dinaites, the Apharsathchites, the Tarpelites, the Apharsites, the Archevites, the Babylonians, the Susanchites, the Dehavites, and the Elamites,

Ezra 4:10 And the rest of the nations whom the great and noble Asnappar brought over, and set in the cities of Samaria, and the rest that are on this side the river, and at such a time.

Ezra 4:11 This is the copy of the letter that they sent unto him, even unto Artaxerxes the king; Thy servants the men on this side the river, and at such a time.

Ezra 4:12 Be it known unto the king, that the Jews which came up from thee to us are come unto Jerusalem, building the rebellious and the bad city, and have set up the walls thereof, and joined the foundations.

Ezra 4:13 Be it known now unto the king, that, if this city be builded, and the walls set up again, then will they not pay toll, tribute, and custom, and so thou shalt endamage the revenue of the kings.

Ezra 4:14 Now because we have maintenance from the king’s palace, and it was not meet for us to see the king’s dishonour, therefore have we sent and certified the king;

Ezra 4:15 That search may be made in the book of the records of thy fathers: so shalt thou find in the book of the records, and know that this city is a rebellious city, and hurtful unto kings and provinces, and that they have moved sedition within the same of old time: for which cause was this city destroyed.

Ezra 4:16 We certify the king that, if this city be builded again, and the walls thereof set up, by this means thou shalt have no portion on this side the river.

Ezra 4:17 Then sent the king an answer unto Rehum the chancellor, and to Shimshai the scribe, and to the rest of their companions that dwell in Samaria, and unto the rest beyond the river, Peace, and at such a time.

Ezra 4:18 The letter which ye sent unto us hath been plainly read before me.

Ezra 4:19 And I commanded, and search hath been made, and it is found that this city of old time hath made insurrection against kings, and that rebellion and sedition have been made therein.

Ezra 4:20 There have been mighty kings also over Jerusalem, which have ruled over all countries beyond the river; and toll, tribute, and custom, was paid unto them.

Ezra 4:21 Give ye now commandment to cause these men to cease, and that this city be not builded, until another commandment shall be given from me.

Ezra 4:22 Take heed now that ye fail not to do this: why should damage grow to the hurt of the kings?

Ezra 4:23 Now when the copy of king Artaxerxes’ letter was read before Rehum, and Shimshai the scribe, and their companions, they went up in haste to Jerusalem unto the Jews, and made them to cease by force and power.

Ezra 4:24 Then ceased the work of the house of God which is at Jerusalem. So it ceased unto the second year of the reign of Darius king of Persia.
