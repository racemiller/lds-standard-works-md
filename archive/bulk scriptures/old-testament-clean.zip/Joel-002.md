# Joel 2

Joel 2 (summary): War and desolation will precede the Second Coming—The sun and the moon will be darkened—The Lord will pour out His Spirit upon all flesh—There will be dreams and visions.

Joel 2:1 Blow ye the trumpet in Zion, and sound an alarm in my holy mountain: let all the inhabitants of the land tremble: for the day of the Lord cometh, for it is nigh at hand;

Joel 2:2 A day of darkness and of gloominess, a day of clouds and of thick darkness, as the morning spread upon the mountains: a great people and a strong; there hath not been ever the like, neither shall be any more after it, even to the years of many generations.

Joel 2:3 A fire devoureth before them; and behind them a flame burneth: the land is as the garden of Eden before them, and behind them a desolate wilderness; yea, and nothing shall escape them.

Joel 2:4 The appearance of them is as the appearance of horses; and as horsemen, so shall they run.

Joel 2:5 Like the noise of chariots on the tops of mountains shall they leap, like the noise of a flame of fire that devoureth the stubble, as a strong people set in battle array.

Joel 2:6 Before their face the people shall be much pained: all faces shall gather blackness.

Joel 2:7 They shall run like mighty men; they shall climb the wall like men of war; and they shall march every one on his ways, and they shall not break their ranks:

Joel 2:8 Neither shall one thrust another; they shall walk every one in his path: and when they fall upon the sword, they shall not be wounded.

Joel 2:9 They shall run to and fro in the city; they shall run upon the wall, they shall climb up upon the houses; they shall enter in at the windows like a thief.

Joel 2:10 The earth shall quake before them; the heavens shall tremble: the sun and the moon shall be dark, and the stars shall withdraw their shining:

Joel 2:11 And the Lord shall utter his voice before his army: for his camp is very great: for he is strong that executeth his word: for the day of the Lord is great and very terrible; and who can abide it?

Joel 2:12 Therefore also now, saith the Lord, turn ye even to me with all your heart, and with fasting, and with weeping, and with mourning:

Joel 2:13 And rend your heart, and not your garments, and turn unto the Lord your God: for he is gracious and merciful, slow to anger, and of great kindness, and repenteth him of the evil.

Joel 2:14 Who knoweth if he will return and repent, and leave a blessing behind him; even a meat offering and a drink offering unto the Lord your God?

Joel 2:15 Blow the trumpet in Zion, sanctify a fast, call a solemn assembly:

Joel 2:16 Gather the people, sanctify the congregation, assemble the elders, gather the children, and those that suck the breasts: let the bridegroom go forth of his chamber, and the bride out of her closet.

Joel 2:17 Let the priests, the ministers of the Lord, weep between the porch and the altar, and let them say, Spare thy people, O Lord, and give not thine heritage to reproach, that the heathen should rule over them: wherefore should they say among the people, Where is their God?

Joel 2:18 Then will the Lord be jealous for his land, and pity his people.

Joel 2:19 Yea, the Lord will answer and say unto his people, Behold, I will send you corn, and wine, and oil, and ye shall be satisfied therewith: and I will no more make you a reproach among the heathen:

Joel 2:20 But I will remove far off from you the northern army, and will drive him into a land barren and desolate, with his face toward the east sea, and his hinder part toward the utmost sea, and his stink shall come up, and his ill savour shall come up, because he hath done great things.

Joel 2:21 Fear not, O land; be glad and rejoice: for the Lord will do great things.

Joel 2:22 Be not afraid, ye beasts of the field: for the pastures of the wilderness do spring, for the tree beareth her fruit, the fig tree and the vine do yield their strength.

Joel 2:23 Be glad then, ye children of Zion, and rejoice in the Lord your God: for he hath given you the former rain moderately, and he will cause to come down for you the rain, the former rain, and the latter rain in the first month.

Joel 2:24 And the floors shall be full of wheat, and the fats shall overflow with wine and oil.

Joel 2:25 And I will restore to you the years that the locust hath eaten, the cankerworm, and the caterpiller, and the palmerworm, my great army which I sent among you.

Joel 2:26 And ye shall eat in plenty, and be satisfied, and praise the name of the Lord your God, that hath dealt wondrously with you: and my people shall never be ashamed.

Joel 2:27 And ye shall know that I am in the midst of Israel, and that I am the Lord your God, and none else: and my people shall never be ashamed.

Joel 2:28 And it shall come to pass afterward, that I will pour out my spirit upon all flesh; and your sons and your daughters shall prophesy, your old men shall dream dreams, your young men shall see visions:

Joel 2:29 And also upon the servants and upon the handmaids in those days will I pour out my spirit.

Joel 2:30 And I will shew wonders in the heavens and in the earth, blood, and fire, and pillars of smoke.

Joel 2:31 The sun shall be turned into darkness, and the moon into blood, before the great and the terrible day of the Lord come.

Joel 2:32 And it shall come to pass, that whosoever shall call on the name of the Lord shall be delivered: for in mount Zion and in Jerusalem shall be deliverance, as the Lord hath said, and in the remnant whom the Lord shall call.
