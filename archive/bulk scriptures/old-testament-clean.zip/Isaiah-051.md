# Isaiah 51

Isaiah 51 (summary): In the last days, the Lord will comfort Zion and gather Israel—The redeemed will come to Zion amid great joy—Compare 2 Nephi 8.

Isaiah 51:1 Hearken to me, ye that follow after righteousness, ye that seek the Lord: look unto the rock whence ye are hewn, and to the hole of the pit whence ye are digged.

Isaiah 51:2 Look unto Abraham your father, and unto Sarah that bare you: for I called him alone, and blessed him, and increased him.

Isaiah 51:3 For the Lord shall comfort Zion: he will comfort all her waste places; and he will make her wilderness like Eden, and her desert like the garden of the Lord; joy and gladness shall be found therein, thanksgiving, and the voice of melody.

Isaiah 51:4 Hearken unto me, my people; and give ear unto me, O my nation: for a law shall proceed from me, and I will make my judgment to rest for a light of the people.

Isaiah 51:5 My righteousness is near; my salvation is gone forth, and mine arms shall judge the people; the isles shall wait upon me, and on mine arm shall they trust.

Isaiah 51:6 Lift up your eyes to the heavens, and look upon the earth beneath: for the heavens shall vanish away like smoke, and the earth shall wax old like a garment, and they that dwell therein shall die in like manner: but my salvation shall be for ever, and my righteousness shall not be abolished.

Isaiah 51:7 Hearken unto me, ye that know righteousness, the people in whose heart is my law; fear ye not the reproach of men, neither be ye afraid of their revilings.

Isaiah 51:8 For the moth shall eat them up like a garment, and the worm shall eat them like wool: but my righteousness shall be for ever, and my salvation from generation to generation.

Isaiah 51:9 Awake, awake, put on strength, O arm of the Lord; awake, as in the ancient days, in the generations of old. Art thou not it that hath cut Rahab, and wounded the dragon?

Isaiah 51:10 Art thou not it which hath dried the sea, the waters of the great deep; that hath made the depths of the sea a way for the ransomed to pass over?

Isaiah 51:11 Therefore the redeemed of the Lord shall return, and come with singing unto Zion; and everlasting joy shall be upon their head: they shall obtain gladness and joy; and sorrow and mourning shall flee away.

Isaiah 51:12 I, even I, am he that comforteth you: who art thou, that thou shouldest be afraid of a man that shall die, and of the son of man which shall be made as grass;

Isaiah 51:13 And forgettest the Lord thy maker, that hath stretched forth the heavens, and laid the foundations of the earth; and hast feared continually every day because of the fury of the oppressor, as if he were ready to destroy? and where is the fury of the oppressor?

Isaiah 51:14 The captive exile hasteneth that he may be loosed, and that he should not die in the pit, nor that his bread should fail.

Isaiah 51:15 But I am the Lord thy God, that divided the sea, whose waves roared: The Lord of hosts is his name.

Isaiah 51:16 And I have put my words in thy mouth, and I have covered thee in the shadow of mine hand, that I may plant the heavens, and lay the foundations of the earth, and say unto Zion, Thou art my people.

Isaiah 51:17 Awake, awake, stand up, O Jerusalem, which hast drunk at the hand of the Lord the cup of his fury; thou hast drunken the dregs of the cup of trembling, and wrung them out.

Isaiah 51:18 There is none to guide her among all the sons whom she hath brought forth; neither is there any that taketh her by the hand of all the sons that she hath brought up.

Isaiah 51:19 These two things are come unto thee; who shall be sorry for thee? desolation, and destruction, and the famine, and the sword: by whom shall I comfort thee?

Isaiah 51:20 Thy sons have fainted, they lie at the head of all the streets, as a wild bull in a net: they are full of the fury of the Lord, the rebuke of thy God.

Isaiah 51:21 Therefore hear now this, thou afflicted, and drunken, but not with wine:

Isaiah 51:22 Thus saith thy Lord the Lord, and thy God that pleadeth the cause of his people, Behold, I have taken out of thine hand the cup of trembling, even the dregs of the cup of my fury; thou shalt no more drink it again:

Isaiah 51:23 But I will put it into the hand of them that afflict thee; which have said to thy soul, Bow down, that we may go over: and thou hast laid thy body as the ground, and as the street, to them that went over.
