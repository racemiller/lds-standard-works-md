# Psalms 53

Psalms 53 (summary): David says, The fool says there is no God—There is none who does good—Gathered Israel will rejoice.

Psalms 53:1 The fool hath said in his heart, There is no God. Corrupt are they, and have done abominable iniquity: there is none that doeth good.

Psalms 53:2 God looked down from heaven upon the children of men, to see if there were any that did understand, that did seek God.

Psalms 53:3 Every one of them is gone back: they are altogether become filthy; there is none that doeth good, no, not one.

Psalms 53:4 Have the workers of iniquity no knowledge? who eat up my people as they eat bread: they have not called upon God.

Psalms 53:5 There were they in great fear, where no fear was: for God hath scattered the bones of him that encampeth against thee: thou hast put them to shame, because God hath despised them.

Psalms 53:6 Oh that the salvation of Israel were come out of Zion! When God bringeth back the captivity of his people, Jacob shall rejoice, and Israel shall be glad.
