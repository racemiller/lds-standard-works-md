# 1 Kings 13

1 Kings 13 (summary): Jeroboam is smitten and then healed by a prophet from Judah—The prophet delivers his message, is led astray by a prophet from Bethel, and is slain by a lion for his disobedience—Jeroboam continues false worship in Israel.

1 Kings 13:1 And, behold, there came a man of God out of Judah by the word of the Lord unto Beth-el: and Jeroboam stood by the altar to burn incense.

1 Kings 13:2 And he cried against the altar in the word of the Lord, and said, O altar, altar, thus saith the Lord; Behold, a child shall be born unto the house of David, Josiah by name; and upon thee shall he offer the priests of the high places that burn incense upon thee, and men’s bones shall be burnt upon thee.

1 Kings 13:3 And he gave a sign the same day, saying, This is the sign which the Lord hath spoken; Behold, the altar shall be rent, and the ashes that are upon it shall be poured out.

1 Kings 13:4 And it came to pass, when king Jeroboam heard the saying of the man of God, which had cried against the altar in Beth-el, that he put forth his hand from the altar, saying, Lay hold on him. And his hand, which he put forth against him, dried up, so that he could not pull it in again to him.

1 Kings 13:5 The altar also was rent, and the ashes poured out from the altar, according to the sign which the man of God had given by the word of the Lord.

1 Kings 13:6 And the king answered and said unto the man of God, Entreat now the face of the Lord thy God, and pray for me, that my hand may be restored me again. And the man of God besought the Lord, and the king’s hand was restored him again, and became as it was before.

1 Kings 13:7 And the king said unto the man of God, Come home with me, and refresh thyself, and I will give thee a reward.

1 Kings 13:8 And the man of God said unto the king, If thou wilt give me half thine house, I will not go in with thee, neither will I eat bread nor drink water in this place:

1 Kings 13:9 For so was it charged me by the word of the Lord, saying, Eat no bread, nor drink water, nor turn again by the same way that thou camest.

1 Kings 13:10 So he went another way, and returned not by the way that he came to Beth-el.

1 Kings 13:11 Now there dwelt an old prophet in Beth-el; and his sons came and told him all the works that the man of God had done that day in Beth-el: the words which he had spoken unto the king, them they told also to their father.

1 Kings 13:12 And their father said unto them, What way went he? For his sons had seen what way the man of God went, which came from Judah.

1 Kings 13:13 And he said unto his sons, Saddle me the ass. So they saddled him the ass: and he rode thereon,

1 Kings 13:14 And went after the man of God, and found him sitting under an oak: and he said unto him, Art thou the man of God that camest from Judah? And he said, I am.

1 Kings 13:15 Then he said unto him, Come home with me, and eat bread.

1 Kings 13:16 And he said, I may not return with thee, nor go in with thee: neither will I eat bread nor drink water with thee in this place:

1 Kings 13:17 For it was said to me by the word of the Lord, Thou shalt eat no bread nor drink water there, nor turn again to go by the way that thou camest.

1 Kings 13:18 He said unto him, I am a prophet also as thou art; and an angel spake unto me by the word of the Lord, saying, Bring him back with thee into thine house, that he may eat bread and drink water. But he lied unto him.

1 Kings 13:19 So he went back with him, and did eat bread in his house, and drank water.

1 Kings 13:20 And it came to pass, as they sat at the table, that the word of the Lord came unto the prophet that brought him back:

1 Kings 13:21 And he cried unto the man of God that came from Judah, saying, Thus saith the Lord, Forasmuch as thou hast disobeyed the mouth of the Lord, and hast not kept the commandment which the Lord thy God commanded thee,

1 Kings 13:22 But camest back, and hast eaten bread and drunk water in the place, of the which the Lord did say to thee, Eat no bread, and drink no water; thy carcase shall not come unto the sepulchre of thy fathers.

1 Kings 13:23 And it came to pass, after he had eaten bread, and after he had drunk, that he saddled for him the ass, to wit, for the prophet whom he had brought back.

1 Kings 13:24 And when he was gone, a lion met him by the way, and slew him: and his carcase was cast in the way, and the ass stood by it, the lion also stood by the carcase.

1 Kings 13:25 And, behold, men passed by, and saw the carcase cast in the way, and the lion standing by the carcase: and they came and told it in the city where the old prophet dwelt.

1 Kings 13:26 And when the prophet that brought him back from the way heard thereof, he said, It is the man of God, who was disobedient unto the word of the Lord: therefore the Lord hath delivered him unto the lion, which hath torn him, and slain him, according to the word of the Lord, which he spake unto him.

1 Kings 13:27 And he spake to his sons, saying, Saddle me the ass. And they saddled him.

1 Kings 13:28 And he went and found his carcase cast in the way, and the ass and the lion standing by the carcase: the lion had not eaten the carcase, nor torn the ass.

1 Kings 13:29 And the prophet took up the carcase of the man of God, and laid it upon the ass, and brought it back: and the old prophet came to the city, to mourn and to bury him.

1 Kings 13:30 And he laid his carcase in his own grave; and they mourned over him, saying, Alas, my brother!

1 Kings 13:31 And it came to pass, after he had buried him, that he spake to his sons, saying, When I am dead, then bury me in the sepulchre wherein the man of God is buried; lay my bones beside his bones:

1 Kings 13:32 For the saying which he cried by the word of the Lord against the altar in Beth-el, and against all the houses of the high places which are in the cities of Samaria, shall surely come to pass.

1 Kings 13:33 After this thing Jeroboam returned not from his evil way, but made again of the lowest of the people priests of the high places: whosoever would, he consecrated him, and he became one of the priests of the high places.

1 Kings 13:34 And this thing became sin unto the house of Jeroboam, even to cut it off, and to destroy it from off the face of the earth.
