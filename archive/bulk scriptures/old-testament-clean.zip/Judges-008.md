# Judges 8

Judges 8 (summary): Gideon pursues and destroys the Midianites—He frees the children of Israel but refuses their invitation to reign as king over them—Gideon dies, and Israel returns to idolatry.

Judges 8:1 And the men of Ephraim said unto him, Why hast thou served us thus, that thou calledst us not, when thou wentest to fight with the Midianites? And they did chide with him sharply.

Judges 8:2 And he said unto them, What have I done now in comparison of you? Is not the gleaning of the grapes of Ephraim better than the vintage of Abi-ezer?

Judges 8:3 God hath delivered into your hands the princes of Midian, Oreb and Zeeb: and what was I able to do in comparison of you? Then their anger was abated toward him, when he had said that.

Judges 8:4 And Gideon came to Jordan, and passed over, he, and the three hundred men that were with him, faint, yet pursuing them.

Judges 8:5 And he said unto the men of Succoth, Give, I pray you, loaves of bread unto the people that follow me; for they be faint, and I am pursuing after Zebah and Zalmunna, kings of Midian.

Judges 8:6 And the princes of Succoth said, Are the hands of Zebah and Zalmunna now in thine hand, that we should give bread unto thine army?

Judges 8:7 And Gideon said, Therefore when the Lord hath delivered Zebah and Zalmunna into mine hand, then I will tear your flesh with the thorns of the wilderness and with briers.

Judges 8:8 And he went up thence to Penuel, and spake unto them likewise: and the men of Penuel answered him as the men of Succoth had answered him.

Judges 8:9 And he spake also unto the men of Penuel, saying, When I come again in peace, I will break down this tower.

Judges 8:10 Now Zebah and Zalmunna were in Karkor, and their hosts with them, about fifteen thousand men, all that were left of all the hosts of the children of the east: for there fell an hundred and twenty thousand men that drew sword.

Judges 8:11 And Gideon went up by the way of them that dwelt in tents on the east of Nobah and Jogbehah, and smote the host: for the host was secure.

Judges 8:12 And when Zebah and Zalmunna fled, he pursued after them, and took the two kings of Midian, Zebah and Zalmunna, and discomfited all the host.

Judges 8:13 And Gideon the son of Joash returned from battle before the sun was up,

Judges 8:14 And caught a young man of the men of Succoth, and inquired of him: and he described unto him the princes of Succoth, and the elders thereof, even threescore and seventeen men.

Judges 8:15 And he came unto the men of Succoth, and said, Behold Zebah and Zalmunna, with whom ye did upbraid me, saying, Are the hands of Zebah and Zalmunna now in thine hand, that we should give bread unto thy men that are weary?

Judges 8:16 And he took the elders of the city, and thorns of the wilderness and briers, and with them he taught the men of Succoth.

Judges 8:17 And he beat down the tower of Penuel, and slew the men of the city.

Judges 8:18 Then said he unto Zebah and Zalmunna, What manner of men were they whom ye slew at Tabor? And they answered, As thou art, so were they; each one resembled the children of a king.

Judges 8:19 And he said, They were my brethren, even the sons of my mother: as the Lord liveth, if ye had saved them alive, I would not slay you.

Judges 8:20 And he said unto Jether his firstborn, Up, and slay them. But the youth drew not his sword: for he feared, because he was yet a youth.

Judges 8:21 Then Zebah and Zalmunna said, Rise thou, and fall upon us: for as the man is, so is his strength. And Gideon arose, and slew Zebah and Zalmunna, and took away the ornaments that were on their camels’ necks.

Judges 8:22 Then the men of Israel said unto Gideon, Rule thou over us, both thou, and thy son, and thy son’s son also: for thou hast delivered us from the hand of Midian.

Judges 8:23 And Gideon said unto them, I will not rule over you, neither shall my son rule over you: the Lord shall rule over you.

Judges 8:24 And Gideon said unto them, I would desire a request of you, that ye would give me every man the earrings of his prey. (For they had golden earrings, because they were Ishmaelites.)

Judges 8:25 And they answered, We will willingly give them. And they spread a garment, and did cast therein every man the earrings of his prey.

Judges 8:26 And the weight of the golden earrings that he requested was a thousand and seven hundred shekels of gold; beside ornaments, and collars, and purple raiment that was on the kings of Midian, and beside the chains that were about their camels’ necks.

Judges 8:27 And Gideon made an ephod thereof, and put it in his city, even in Ophrah: and all Israel went thither a whoring after it: which thing became a snare unto Gideon, and to his house.

Judges 8:28 Thus was Midian subdued before the children of Israel, so that they lifted up their heads no more. And the country was in quietness forty years in the days of Gideon.

Judges 8:29 And Jerubbaal the son of Joash went and dwelt in his own house.

Judges 8:30 And Gideon had threescore and ten sons of his body begotten: for he had many wives.

Judges 8:31 And his concubine that was in Shechem, she also bare him a son, whose name he called Abimelech.

Judges 8:32 And Gideon the son of Joash died in a good old age, and was buried in the sepulchre of Joash his father, in Ophrah of the Abi-ezrites.

Judges 8:33 And it came to pass, as soon as Gideon was dead, that the children of Israel turned again, and went a whoring after Baalim, and made Baal-berith their god.

Judges 8:34 And the children of Israel remembered not the Lord their God, who had delivered them out of the hands of all their enemies on every side:

Judges 8:35 Neither shewed they kindness to the house of Jerubbaal, namely, Gideon, according to all the goodness which he had shewed unto Israel.
