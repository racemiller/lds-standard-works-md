# Leviticus 19

Leviticus 19 (summary): Israel is commanded: Be holy, live righteously, love your neighbor, and keep the commandments—The Lord reveals and reaffirms sundry laws and commandments—Enchantments, wizardry, prostitution, and all evil practices are forbidden.

Leviticus 19:1 And the Lord spake unto Moses, saying,

Leviticus 19:2 Speak unto all the congregation of the children of Israel, and say unto them, Ye shall be holy: for I the Lord your God am holy.

Leviticus 19:3 Ye shall fear every man his mother, and his father, and keep my sabbaths: I am the Lord your God.

Leviticus 19:4 Turn ye not unto idols, nor make to yourselves molten gods: I am the Lord your God.

Leviticus 19:5 And if ye offer a sacrifice of peace offerings unto the Lord, ye shall offer it at your own will.

Leviticus 19:6 It shall be eaten the same day ye offer it, and on the morrow: and if ought remain until the third day, it shall be burnt in the fire.

Leviticus 19:7 And if it be eaten at all on the third day, it is abominable; it shall not be accepted.

Leviticus 19:8 Therefore every one that eateth it shall bear his iniquity, because he hath profaned the hallowed thing of the Lord: and that soul shall be cut off from among his people.

Leviticus 19:9 And when ye reap the harvest of your land, thou shalt not wholly reap the corners of thy field, neither shalt thou gather the gleanings of thy harvest.

Leviticus 19:10 And thou shalt not glean thy vineyard, neither shalt thou gather every grape of thy vineyard; thou shalt leave them for the poor and stranger: I am the Lord your God.

Leviticus 19:11 Ye shall not steal, neither deal falsely, neither lie one to another.

Leviticus 19:12 And ye shall not swear by my name falsely, neither shalt thou profane the name of thy God: I am the Lord.

Leviticus 19:13 Thou shalt not defraud thy neighbour, neither rob him: the wages of him that is hired shall not abide with thee all night until the morning.

Leviticus 19:14 Thou shalt not curse the deaf, nor put a stumblingblock before the blind, but shalt fear thy God: I am the Lord.

Leviticus 19:15 Ye shall do no unrighteousness in judgment: thou shalt not respect the person of the poor, nor honour the person of the mighty: but in righteousness shalt thou judge thy neighbour.

Leviticus 19:16 Thou shalt not go up and down as a talebearer among thy people: neither shalt thou stand against the blood of thy neighbour: I am the Lord.

Leviticus 19:17 Thou shalt not hate thy brother in thine heart: thou shalt in any wise rebuke thy neighbour, and not suffer sin upon him.

Leviticus 19:18 Thou shalt not avenge, nor bear any grudge against the children of thy people, but thou shalt love thy neighbour as thyself: I am the Lord.

Leviticus 19:19 Ye shall keep my statutes. Thou shalt not let thy cattle gender with a diverse kind: thou shalt not sow thy field with mingled seed: neither shall a garment mingled of linen and woollen come upon thee.

Leviticus 19:20 And whosoever lieth carnally with a woman, that is a bondmaid, betrothed to an husband, and not at all redeemed, nor freedom given her; she shall be scourged; they shall not be put to death, because she was not free.

Leviticus 19:21 And he shall bring his trespass offering unto the Lord, unto the door of the tabernacle of the congregation, even a ram for a trespass offering.

Leviticus 19:22 And the priest shall make an atonement for him with the ram of the trespass offering before the Lord for his sin which he hath done: and the sin which he hath done shall be forgiven him.

Leviticus 19:23 And when ye shall come into the land, and shall have planted all manner of trees for food, then ye shall count the fruit thereof as uncircumcised: three years shall it be as uncircumcised unto you: it shall not be eaten of.

Leviticus 19:24 But in the fourth year all the fruit thereof shall be holy to praise the Lord withal.

Leviticus 19:25 And in the fifth year shall ye eat of the fruit thereof, that it may yield unto you the increase thereof: I am the Lord your God.

Leviticus 19:26 Ye shall not eat any thing with the blood: neither shall ye use enchantment, nor observe times.

Leviticus 19:27 Ye shall not round the corners of your heads, neither shalt thou mar the corners of thy beard.

Leviticus 19:28 Ye shall not make any cuttings in your flesh for the dead, nor print any marks upon you: I am the Lord.

Leviticus 19:29 Do not prostitute thy daughter, to cause her to be a whore; lest the land fall to whoredom, and the land become full of wickedness.

Leviticus 19:30 Ye shall keep my sabbaths, and reverence my sanctuary: I am the Lord.

Leviticus 19:31 Regard not them that have familiar spirits, neither seek after wizards, to be defiled by them: I am the Lord your God.

Leviticus 19:32 Thou shalt rise up before the hoary head, and honour the face of the old man, and fear thy God: I am the Lord.

Leviticus 19:33 And if a stranger sojourn with thee in your land, ye shall not vex him.

Leviticus 19:34 But the stranger that dwelleth with you shall be unto you as one born among you, and thou shalt love him as thyself; for ye were strangers in the land of Egypt: I am the Lord your God.

Leviticus 19:35 Ye shall do no unrighteousness in judgment, in meteyard, in weight, or in measure.

Leviticus 19:36 Just balances, just weights, a just ephah, and a just hin, shall ye have: I am the Lord your God, which brought you out of the land of Egypt.

Leviticus 19:37 Therefore shall ye observe all my statutes, and all my judgments, and do them: I am the Lord.
