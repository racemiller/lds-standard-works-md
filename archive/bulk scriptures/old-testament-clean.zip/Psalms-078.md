# Psalms 78

Psalms 78 (summary): The Israelites are to teach the Lord’s law to their children—Disobedient Israel provoked the Lord in the wilderness—The Egyptian plagues are recounted—The Lord chooses and blesses Judah and David.

Psalms 78:1 Give ear, O my people, to my law: incline your ears to the words of my mouth.

Psalms 78:2 I will open my mouth in a parable: I will utter dark sayings of old:

Psalms 78:3 Which we have heard and known, and our fathers have told us.

Psalms 78:4 We will not hide them from their children, shewing to the generation to come the praises of the Lord, and his strength, and his wonderful works that he hath done.

Psalms 78:5 For he established a testimony in Jacob, and appointed a law in Israel, which he commanded our fathers, that they should make them known to their children:

Psalms 78:6 That the generation to come might know them, even the children which should be born; who should arise and declare them to their children:

Psalms 78:7 That they might set their hope in God, and not forget the works of God, but keep his commandments:

Psalms 78:8 And might not be as their fathers, a stubborn and rebellious generation; a generation that set not their heart aright, and whose spirit was not steadfast with God.

Psalms 78:9 The children of Ephraim, being armed, and carrying bows, turned back in the day of battle.

Psalms 78:10 They kept not the covenant of God, and refused to walk in his law;

Psalms 78:11 And forgat his works, and his wonders that he had shewed them.

Psalms 78:12 Marvellous things did he in the sight of their fathers, in the land of Egypt, in the field of Zoan.

Psalms 78:13 He divided the sea, and caused them to pass through; and he made the waters to stand as an heap.

Psalms 78:14 In the daytime also he led them with a cloud, and all the night with a light of fire.

Psalms 78:15 He clave the rocks in the wilderness, and gave them drink as out of the great depths.

Psalms 78:16 He brought streams also out of the rock, and caused waters to run down like rivers.

Psalms 78:17 And they sinned yet more against him by provoking the most High in the wilderness.

Psalms 78:18 And they tempted God in their heart by asking meat for their lust.

Psalms 78:19 Yea, they spake against God; they said, Can God furnish a table in the wilderness?

Psalms 78:20 Behold, he smote the rock, that the waters gushed out, and the streams overflowed; can he give bread also? can he provide flesh for his people?

Psalms 78:21 Therefore the Lord heard this, and was wroth: so a fire was kindled against Jacob, and anger also came up against Israel;

Psalms 78:22 Because they believed not in God, and trusted not in his salvation:

Psalms 78:23 Though he had commanded the clouds from above, and opened the doors of heaven,

Psalms 78:24 And had rained down manna upon them to eat, and had given them of the corn of heaven.

Psalms 78:25 Man did eat angels’ food: he sent them meat to the full.

Psalms 78:26 He caused an east wind to blow in the heaven: and by his power he brought in the south wind.

Psalms 78:27 He rained flesh also upon them as dust, and feathered fowls like as the sand of the sea:

Psalms 78:28 And he let it fall in the midst of their camp, round about their habitations.

Psalms 78:29 So they did eat, and were well filled: for he gave them their own desire;

Psalms 78:30 They were not estranged from their lust. But while their meat was yet in their mouths,

Psalms 78:31 The wrath of God came upon them, and slew the fattest of them, and smote down the chosen men of Israel.

Psalms 78:32 For all this they sinned still, and believed not for his wondrous works.

Psalms 78:33 Therefore their days did he consume in vanity, and their years in trouble.

Psalms 78:34 When he slew them, then they sought him: and they returned and inquired early after God.

Psalms 78:35 And they remembered that God was their rock, and the high God their redeemer.

Psalms 78:36 Nevertheless they did flatter him with their mouth, and they lied unto him with their tongues.

Psalms 78:37 For their heart was not right with him, neither were they steadfast in his covenant.

Psalms 78:38 But he, being full of compassion, forgave their iniquity, and destroyed them not: yea, many a time turned he his anger away, and did not stir up all his wrath.

Psalms 78:39 For he remembered that they were but flesh; a wind that passeth away, and cometh not again.

Psalms 78:40 How oft did they provoke him in the wilderness, and grieve him in the desert!

Psalms 78:41 Yea, they turned back and tempted God, and limited the Holy One of Israel.

Psalms 78:42 They remembered not his hand, nor the day when he delivered them from the enemy.

Psalms 78:43 How he had wrought his signs in Egypt, and his wonders in the field of Zoan:

Psalms 78:44 And had turned their rivers into blood; and their floods, that they could not drink.

Psalms 78:45 He sent divers sorts of flies among them, which devoured them; and frogs, which destroyed them.

Psalms 78:46 He gave also their increase unto the caterpiller, and their labour unto the locust.

Psalms 78:47 He destroyed their vines with hail, and their sycomore trees with frost.

Psalms 78:48 He gave up their cattle also to the hail, and their flocks to hot thunderbolts.

Psalms 78:49 He cast upon them the fierceness of his anger, wrath, and indignation, and trouble, by sending evil angels among them.

Psalms 78:50 He made a way to his anger; he spared not their soul from death, but gave their life over to the pestilence;

Psalms 78:51 And smote all the firstborn in Egypt; the chief of their strength in the tabernacles of Ham:

Psalms 78:52 But made his own people to go forth like sheep, and guided them in the wilderness like a flock.

Psalms 78:53 And he led them on safely, so that they feared not: but the sea overwhelmed their enemies.

Psalms 78:54 And he brought them to the border of his sanctuary, even to this mountain, which his right hand had purchased.

Psalms 78:55 He cast out the heathen also before them, and divided them an inheritance by line, and made the tribes of Israel to dwell in their tents.

Psalms 78:56 Yet they tempted and provoked the most high God, and kept not his testimonies:

Psalms 78:57 But turned back, and dealt unfaithfully like their fathers: they were turned aside like a deceitful bow.

Psalms 78:58 For they provoked him to anger with their high places, and moved him to jealousy with their graven images.

Psalms 78:59 When God heard this, he was wroth, and greatly abhorred Israel:

Psalms 78:60 So that he forsook the tabernacle of Shiloh, the tent which he placed among men;

Psalms 78:61 And delivered his strength into captivity, and his glory into the enemy’s hand.

Psalms 78:62 He gave his people over also unto the sword; and was wroth with his inheritance.

Psalms 78:63 The fire consumed their young men; and their maidens were not given to marriage.

Psalms 78:64 Their priests fell by the sword; and their widows made no lamentation.

Psalms 78:65 Then the Lord awaked as one out of sleep, and like a mighty man that shouteth by reason of wine.

Psalms 78:66 And he smote his enemies in the hinder parts: he put them to a perpetual reproach.

Psalms 78:67 Moreover he refused the tabernacle of Joseph, and chose not the tribe of Ephraim:

Psalms 78:68 But chose the tribe of Judah, the mount Zion which he loved.

Psalms 78:69 And he built his sanctuary like high palaces, like the earth which he hath established for ever.

Psalms 78:70 He chose David also his servant, and took him from the sheepfolds:

Psalms 78:71 From following the ewes great with young he brought him to feed Jacob his people, and Israel his inheritance.

Psalms 78:72 So he fed them according to the integrity of his heart; and guided them by the skilfulness of his hands.
