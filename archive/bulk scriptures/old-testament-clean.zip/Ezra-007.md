# Ezra 7

Ezra 7 (summary): Ezra goes up to Jerusalem—Artaxerxes provides for beautifying the temple and sustains the Jews in their worship.

Ezra 7:1 Now after these things, in the reign of Artaxerxes king of Persia, Ezra the son of Seraiah, the son of Azariah, the son of Hilkiah,

Ezra 7:2 The son of Shallum, the son of Zadok, the son of Ahitub,

Ezra 7:3 The son of Amariah, the son of Azariah, the son of Meraioth,

Ezra 7:4 The son of Zerahiah, the son of Uzzi, the son of Bukki,

Ezra 7:5 The son of Abishua, the son of Phinehas, the son of Eleazar, the son of Aaron the chief priest:

Ezra 7:6 This Ezra went up from Babylon; and he was a ready scribe in the law of Moses, which the Lord God of Israel had given: and the king granted him all his request, according to the hand of the Lord his God upon him.

Ezra 7:7 And there went up some of the children of Israel, and of the priests, and the Levites, and the singers, and the porters, and the Nethinims, unto Jerusalem, in the seventh year of Artaxerxes the king.

Ezra 7:8 And he came to Jerusalem in the fifth month, which was in the seventh year of the king.

Ezra 7:9 For upon the first day of the first month began he to go up from Babylon, and on the first day of the fifth month came he to Jerusalem, according to the good hand of his God upon him.

Ezra 7:10 For Ezra had prepared his heart to seek the law of the Lord, and to do it, and to teach in Israel statutes and judgments.

Ezra 7:11 Now this is the copy of the letter that the king Artaxerxes gave unto Ezra the priest, the scribe, even a scribe of the words of the commandments of the Lord, and of his statutes to Israel.

Ezra 7:12 Artaxerxes, king of kings, unto Ezra the priest, a scribe of the law of the God of heaven, perfect peace, and at such a time.

Ezra 7:13 I make a decree, that all they of the people of Israel, and of his priests and Levites, in my realm, which are minded of their own freewill to go up to Jerusalem, go with thee.

Ezra 7:14 Forasmuch as thou art sent of the king, and of his seven counsellors, to inquire concerning Judah and Jerusalem, according to the law of thy God which is in thine hand;

Ezra 7:15 And to carry the silver and gold, which the king and his counsellors have freely offered unto the God of Israel, whose habitation is in Jerusalem,

Ezra 7:16 And all the silver and gold that thou canst find in all the province of Babylon, with the freewill offering of the people, and of the priests, offering willingly for the house of their God which is in Jerusalem:

Ezra 7:17 That thou mayest buy speedily with this money bullocks, rams, lambs, with their meat offerings and their drink offerings, and offer them upon the altar of the house of your God which is in Jerusalem.

Ezra 7:18 And whatsoever shall seem good to thee, and to thy brethren, to do with the rest of the silver and the gold, that do after the will of your God.

Ezra 7:19 The vessels also that are given thee for the service of the house of thy God, those deliver thou before the God of Jerusalem.

Ezra 7:20 And whatsoever more shall be needful for the house of thy God, which thou shalt have occasion to bestow, bestow it out of the king’s treasure house.

Ezra 7:21 And I, even I Artaxerxes the king, do make a decree to all the treasurers which are beyond the river, that whatsoever Ezra the priest, the scribe of the law of the God of heaven, shall require of you, it be done speedily,

Ezra 7:22 Unto an hundred talents of silver, and to an hundred measures of wheat, and to an hundred baths of wine, and to an hundred baths of oil, and salt without prescribing how much.

Ezra 7:23 Whatsoever is commanded by the God of heaven, let it be diligently done for the house of the God of heaven: for why should there be wrath against the realm of the king and his sons?

Ezra 7:24 Also we certify you, that touching any of the priests and Levites, singers, porters, Nethinims, or ministers of this house of God, it shall not be lawful to impose toll, tribute, or custom, upon them.

Ezra 7:25 And thou, Ezra, after the wisdom of thy God, that is in thine hand, set magistrates and judges, which may judge all the people that are beyond the river, all such as know the laws of thy God; and teach ye them that know them not.

Ezra 7:26 And whosoever will not do the law of thy God, and the law of the king, let judgment be executed speedily upon him, whether it be unto death, or to banishment, or to confiscation of goods, or to imprisonment.

Ezra 7:27 Blessed be the Lord God of our fathers, which hath put such a thing as this in the king’s heart, to beautify the house of the Lord which is in Jerusalem:

Ezra 7:28 And hath extended mercy unto me before the king, and his counsellors, and before all the king’s mighty princes. And I was strengthened as the hand of the Lord my God was upon me, and I gathered together out of Israel chief men to go up with me.
