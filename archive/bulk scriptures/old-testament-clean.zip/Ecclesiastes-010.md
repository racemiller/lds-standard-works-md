# Ecclesiastes 10

Ecclesiastes 10 (summary): A little folly destroys the reputation of the wise and honorable—The words of a wise man’s mouth are gracious—A fool is full of words.

Ecclesiastes 10:1 Dead flies cause the ointment of the apothecary to send forth a stinking savour: so doth a little folly him that is in reputation for wisdom and honour.

Ecclesiastes 10:2 A wise man’s heart is at his right hand; but a fool’s heart at his left.

Ecclesiastes 10:3 Yea also, when he that is a fool walketh by the way, his wisdom faileth him, and he saith to every one that he is a fool.

Ecclesiastes 10:4 If the spirit of the ruler rise up against thee, leave not thy place; for yielding pacifieth great offences.

Ecclesiastes 10:5 There is an evil which I have seen under the sun, as an error which proceedeth from the ruler:

Ecclesiastes 10:6 Folly is set in great dignity, and the rich sit in low place.

Ecclesiastes 10:7 I have seen servants upon horses, and princes walking as servants upon the earth.

Ecclesiastes 10:8 He that diggeth a pit shall fall into it; and whoso breaketh an hedge, a serpent shall bite him.

Ecclesiastes 10:9 Whoso removeth stones shall be hurt therewith; and he that cleaveth wood shall be endangered thereby.

Ecclesiastes 10:10 If the iron be blunt, and he do not whet the edge, then must he put to more strength: but wisdom is profitable to direct.

Ecclesiastes 10:11 Surely the serpent will bite without enchantment; and a babbler is no better.

Ecclesiastes 10:12 The words of a wise man’s mouth are gracious; but the lips of a fool will swallow up himself.

Ecclesiastes 10:13 The beginning of the words of his mouth is foolishness: and the end of his talk is mischievous madness.

Ecclesiastes 10:14 A fool also is full of words: a man cannot tell what shall be; and what shall be after him, who can tell him?

Ecclesiastes 10:15 The labour of the foolish wearieth every one of them, because he knoweth not how to go to the city.

Ecclesiastes 10:16 Woe to thee, O land, when thy king is a child, and thy princes eat in the morning!

Ecclesiastes 10:17 Blessed art thou, O land, when thy king is the son of nobles, and thy princes eat in due season, for strength, and not for drunkenness!

Ecclesiastes 10:18 By much slothfulness the building decayeth; and through idleness of the hands the house droppeth through.

Ecclesiastes 10:19 A feast is made for laughter, and wine maketh merry: but money answereth all things.

Ecclesiastes 10:20 Curse not the king, no not in thy thought; and curse not the rich in thy bedchamber: for a bird of the air shall carry the voice, and that which hath wings shall tell the matter.
