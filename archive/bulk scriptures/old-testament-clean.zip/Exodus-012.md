# Exodus 12

Exodus 12 (summary): The Lord institutes the Passover and the Feast of Unleavened Bread—Lambs without blemish are slain—Israel is saved by their blood—The firstborn of all Egyptians are slain—Israel is thrust out of Egypt after 430 years—No bones of the paschal lambs are to be broken.

Exodus 12:1 And the Lord spake unto Moses and Aaron in the land of Egypt, saying,

Exodus 12:2 This month shall be unto you the beginning of months: it shall be the first month of the year to you.

Exodus 12:3 Speak ye unto all the congregation of Israel, saying, In the tenth day of this month they shall take to them every man a lamb, according to the house of their fathers, a lamb for an house:

Exodus 12:4 And if the household be too little for the lamb, let him and his neighbour next unto his house take it according to the number of the souls; every man according to his eating shall make your count for the lamb.

Exodus 12:5 Your lamb shall be without blemish, a male of the first year: ye shall take it out from the sheep, or from the goats:

Exodus 12:6 And ye shall keep it up until the fourteenth day of the same month: and the whole assembly of the congregation of Israel shall kill it in the evening.

Exodus 12:7 And they shall take of the blood, and strike it on the two side posts and on the upper door post of the houses, wherein they shall eat it.

Exodus 12:8 And they shall eat the flesh in that night, roast with fire, and unleavened bread; and with bitter herbs they shall eat it.

Exodus 12:9 Eat not of it raw, nor sodden at all with water, but roast with fire; his head with his legs, and with the purtenance thereof.

Exodus 12:10 And ye shall let nothing of it remain until the morning; and that which remaineth of it until the morning ye shall burn with fire.

Exodus 12:11 And thus shall ye eat it; with your loins girded, your shoes on your feet, and your staff in your hand; and ye shall eat it in haste: it is the Lord’s passover.

Exodus 12:12 For I will pass through the land of Egypt this night, and will smite all the firstborn in the land of Egypt, both man and beast; and against all the gods of Egypt I will execute judgment: I am the Lord.

Exodus 12:13 And the blood shall be to you for a token upon the houses where ye are: and when I see the blood, I will pass over you, and the plague shall not be upon you to destroy you, when I smite the land of Egypt.

Exodus 12:14 And this day shall be unto you for a memorial; and ye shall keep it a feast to the Lord throughout your generations; ye shall keep it a feast by an ordinance for ever.

Exodus 12:15 Seven days shall ye eat unleavened bread; even the first day ye shall put away leaven out of your houses: for whosoever eateth leavened bread from the first day until the seventh day, that soul shall be cut off from Israel.

Exodus 12:16 And in the first day there shall be an holy convocation, and in the seventh day there shall be an holy convocation to you; no manner of work shall be done in them, save that which every man must eat, that only may be done of you.

Exodus 12:17 And ye shall observe the feast of unleavened bread; for in this selfsame day have I brought your armies out of the land of Egypt: therefore shall ye observe this day in your generations by an ordinance for ever.

Exodus 12:18 In the first month, on the fourteenth day of the month at even, ye shall eat unleavened bread, until the one and twentieth day of the month at even.

Exodus 12:19 Seven days shall there be no leaven found in your houses: for whosoever eateth that which is leavened, even that soul shall be cut off from the congregation of Israel, whether he be a stranger, or born in the land.

Exodus 12:20 Ye shall eat nothing leavened; in all your habitations shall ye eat unleavened bread.

Exodus 12:21 Then Moses called for all the elders of Israel, and said unto them, Draw out and take you a lamb according to your families, and kill the passover.

Exodus 12:22 And ye shall take a bunch of hyssop, and dip it in the blood that is in the basin, and strike the lintel and the two side posts with the blood that is in the basin; and none of you shall go out at the door of his house until the morning.

Exodus 12:23 For the Lord will pass through to smite the Egyptians; and when he seeth the blood upon the lintel, and on the two side posts, the Lord will pass over the door, and will not suffer the destroyer to come in unto your houses to smite you.

Exodus 12:24 And ye shall observe this thing for an ordinance to thee and to thy sons for ever.

Exodus 12:25 And it shall come to pass, when ye be come to the land which the Lord will give you, according as he hath promised, that ye shall keep this service.

Exodus 12:26 And it shall come to pass, when your children shall say unto you, What mean ye by this service?

Exodus 12:27 That ye shall say, It is the sacrifice of the Lord’s passover, who passed over the houses of the children of Israel in Egypt, when he smote the Egyptians, and delivered our houses. And the people bowed the head and worshipped.

Exodus 12:28 And the children of Israel went away, and did as the Lord had commanded Moses and Aaron, so did they.

Exodus 12:29 And it came to pass, that at midnight the Lord smote all the firstborn in the land of Egypt, from the firstborn of Pharaoh that sat on his throne unto the firstborn of the captive that was in the dungeon; and all the firstborn of cattle.

Exodus 12:30 And Pharaoh rose up in the night, he, and all his servants, and all the Egyptians; and there was a great cry in Egypt; for there was not a house where there was not one dead.

Exodus 12:31 And he called for Moses and Aaron by night, and said, Rise up, and get you forth from among my people, both ye and the children of Israel; and go, serve the Lord, as ye have said.

Exodus 12:32 Also take your flocks and your herds, as ye have said, and be gone; and bless me also.

Exodus 12:33 And the Egyptians were urgent upon the people, that they might send them out of the land in haste; for they said, We be all dead men.

Exodus 12:34 And the people took their dough before it was leavened, their kneadingtroughs being bound up in their clothes upon their shoulders.

Exodus 12:35 And the children of Israel did according to the word of Moses; and they borrowed of the Egyptians jewels of silver, and jewels of gold, and raiment:

Exodus 12:36 And the Lord gave the people favour in the sight of the Egyptians, so that they lent unto them such things as they required. And they spoiled the Egyptians.

Exodus 12:37 And the children of Israel journeyed from Rameses to Succoth, about six hundred thousand on foot that were men, beside children.

Exodus 12:38 And a mixed multitude went up also with them; and flocks, and herds, even very much cattle.

Exodus 12:39 And they baked unleavened cakes of the dough which they brought forth out of Egypt, for it was not leavened; because they were thrust out of Egypt, and could not tarry, neither had they prepared for themselves any victual.

Exodus 12:40 Now the sojourning of the children of Israel, who dwelt in Egypt, was four hundred and thirty years.

Exodus 12:41 And it came to pass at the end of the four hundred and thirty years, even the selfsame day it came to pass, that all the hosts of the Lord went out from the land of Egypt.

Exodus 12:42 It is a night to be much observed unto the Lord for bringing them out from the land of Egypt: this is that night of the Lord to be observed of all the children of Israel in their generations.

Exodus 12:43 And the Lord said unto Moses and Aaron, This is the ordinance of the passover: There shall no stranger eat thereof:

Exodus 12:44 But every man’s servant that is bought for money, when thou hast circumcised him, then shall he eat thereof.

Exodus 12:45 A foreigner and an hired servant shall not eat thereof.

Exodus 12:46 In one house shall it be eaten; thou shalt not carry forth ought of the flesh abroad out of the house; neither shall ye break a bone thereof.

Exodus 12:47 All the congregation of Israel shall keep it.

Exodus 12:48 And when a stranger shall sojourn with thee, and will keep the passover to the Lord, let all his males be circumcised, and then let him come near and keep it; and he shall be as one that is born in the land: for no uncircumcised person shall eat thereof.

Exodus 12:49 One law shall be to him that is homeborn, and unto the stranger that sojourneth among you.

Exodus 12:50 Thus did all the children of Israel; as the Lord commanded Moses and Aaron, so did they.

Exodus 12:51 And it came to pass the selfsame day, that the Lord did bring the children of Israel out of the land of Egypt by their armies.
