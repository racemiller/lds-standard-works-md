# Ezekiel 18

Ezekiel 18 (summary): Men will be punished for their own sins—Sinners will die, and the righteous will surely live—A righteous man who sins will be damned, and a sinner who repents will be saved.

Ezekiel 18:1 The word of the Lord came unto me again, saying,

Ezekiel 18:2 What mean ye, that ye use this proverb concerning the land of Israel, saying, The fathers have eaten sour grapes, and the children’s teeth are set on edge?

Ezekiel 18:3 As I live, saith the Lord God, ye shall not have occasion any more to use this proverb in Israel.

Ezekiel 18:4 Behold, all souls are mine; as the soul of the father, so also the soul of the son is mine: the soul that sinneth, it shall die.

Ezekiel 18:5 But if a man be just, and do that which is lawful and right,

Ezekiel 18:6 And hath not eaten upon the mountains, neither hath lifted up his eyes to the idols of the house of Israel, neither hath defiled his neighbour’s wife, neither hath come near to a menstruous woman,

Ezekiel 18:7 And hath not oppressed any, but hath restored to the debtor his pledge, hath spoiled none by violence, hath given his bread to the hungry, and hath covered the naked with a garment;

Ezekiel 18:8 He that hath not given forth upon usury, neither hath taken any increase, that hath withdrawn his hand from iniquity, hath executed true judgment between man and man,

Ezekiel 18:9 Hath walked in my statutes, and hath kept my judgments, to deal truly; he is just, he shall surely live, saith the Lord God.

Ezekiel 18:10 If he beget a son that is a robber, a shedder of blood, and that doeth the like to any one of these things,

Ezekiel 18:11 And that doeth not any of those duties, but even hath eaten upon the mountains, and defiled his neighbour’s wife,

Ezekiel 18:12 Hath oppressed the poor and needy, hath spoiled by violence, hath not restored the pledge, and hath lifted up his eyes to the idols, hath committed abomination,

Ezekiel 18:13 Hath given forth upon usury, and hath taken increase: shall he then live? he shall not live: he hath done all these abominations; he shall surely die; his blood shall be upon him.

Ezekiel 18:14 Now, lo, if he beget a son, that seeth all his father’s sins which he hath done, and considereth, and doeth not such like,

Ezekiel 18:15 That hath not eaten upon the mountains, neither hath lifted up his eyes to the idols of the house of Israel, hath not defiled his neighbour’s wife,

Ezekiel 18:16 Neither hath oppressed any, hath not withholden the pledge, neither hath spoiled by violence, but hath given his bread to the hungry, and hath covered the naked with a garment,

Ezekiel 18:17 That hath taken off his hand from the poor, that hath not received usury nor increase, hath executed my judgments, hath walked in my statutes; he shall not die for the iniquity of his father, he shall surely live.

Ezekiel 18:18 As for his father, because he cruelly oppressed, spoiled his brother by violence, and did that which is not good among his people, lo, even he shall die in his iniquity.

Ezekiel 18:19 Yet say ye, Why? doth not the son bear the iniquity of the father? When the son hath done that which is lawful and right, and hath kept all my statutes, and hath done them, he shall surely live.

Ezekiel 18:20 The soul that sinneth, it shall die. The son shall not bear the iniquity of the father, neither shall the father bear the iniquity of the son: the righteousness of the righteous shall be upon him, and the wickedness of the wicked shall be upon him.

Ezekiel 18:21 But if the wicked will turn from all his sins that he hath committed, and keep all my statutes, and do that which is lawful and right, he shall surely live, he shall not die.

Ezekiel 18:22 All his transgressions that he hath committed, they shall not be mentioned unto him: in his righteousness that he hath done he shall live.

Ezekiel 18:23 Have I any pleasure at all that the wicked should die? saith the Lord God: and not that he should return from his ways, and live?

Ezekiel 18:24 But when the righteous turneth away from his righteousness, and committeth iniquity, and doeth according to all the abominations that the wicked man doeth, shall he live? All his righteousness that he hath done shall not be mentioned: in his trespass that he hath trespassed, and in his sin that he hath sinned, in them shall he die.

Ezekiel 18:25 Yet ye say, The way of the Lord is not equal. Hear now, O house of Israel; Is not my way equal? are not your ways unequal?

Ezekiel 18:26 When a righteous man turneth away from his righteousness, and committeth iniquity, and dieth in them; for his iniquity that he hath done shall he die.

Ezekiel 18:27 Again, when the wicked man turneth away from his wickedness that he hath committed, and doeth that which is lawful and right, he shall save his soul alive.

Ezekiel 18:28 Because he considereth, and turneth away from all his transgressions that he hath committed, he shall surely live, he shall not die.

Ezekiel 18:29 Yet saith the house of Israel, The way of the Lord is not equal. O house of Israel, are not my ways equal? are not your ways unequal?

Ezekiel 18:30 Therefore I will judge you, O house of Israel, every one according to his ways, saith the Lord God. Repent, and turn yourselves from all your transgressions; so iniquity shall not be your ruin.

Ezekiel 18:31 Cast away from you all your transgressions, whereby ye have transgressed; and make you a new heart and a new spirit: for why will ye die, O house of Israel?

Ezekiel 18:32 For I have no pleasure in the death of him that dieth, saith the Lord God: wherefore turn yourselves, and live ye.
