# Numbers 2

Numbers 2 (summary): The order and leaders of the tribes and armies of Israel in their tents are given.

Numbers 2:1 And the Lord spake unto Moses and unto Aaron, saying,

Numbers 2:2 Every man of the children of Israel shall pitch by his own standard, with the ensign of their father’s house: far off about the tabernacle of the congregation shall they pitch.

Numbers 2:3 And on the east side toward the rising of the sun shall they of the standard of the camp of Judah pitch throughout their armies: and Nahshon the son of Amminadab shall be captain of the children of Judah.

Numbers 2:4 And his host, and those that were numbered of them, were threescore and fourteen thousand and six hundred.

Numbers 2:5 And those that do pitch next unto him shall be the tribe of Issachar: and Nethaneel the son of Zuar shall be captain of the children of Issachar.

Numbers 2:6 And his host, and those that were numbered thereof, were fifty and four thousand and four hundred.

Numbers 2:7 Then the tribe of Zebulun: and Eliab the son of Helon shall be captain of the children of Zebulun.

Numbers 2:8 And his host, and those that were numbered thereof, were fifty and seven thousand and four hundred.

Numbers 2:9 All that were numbered in the camp of Judah were an hundred thousand and fourscore thousand and six thousand and four hundred, throughout their armies. These shall first set forth.

Numbers 2:10 On the south side shall be the standard of the camp of Reuben according to their armies: and the captain of the children of Reuben shall be Elizur the son of Shedeur.

Numbers 2:11 And his host, and those that were numbered thereof, were forty and six thousand and five hundred.

Numbers 2:12 And those which pitch by him shall be the tribe of Simeon: and the captain of the children of Simeon shall be Shelumiel the son of Zurishaddai.

Numbers 2:13 And his host, and those that were numbered of them, were fifty and nine thousand and three hundred.

Numbers 2:14 Then the tribe of Gad: and the captain of the sons of Gad shall be Eliasaph the son of Reuel.

Numbers 2:15 And his host, and those that were numbered of them, were forty and five thousand and six hundred and fifty.

Numbers 2:16 All that were numbered in the camp of Reuben were an hundred thousand and fifty and one thousand and four hundred and fifty, throughout their armies. And they shall set forth in the second rank.

Numbers 2:17 Then the tabernacle of the congregation shall set forward with the camp of the Levites in the midst of the camp: as they encamp, so shall they set forward, every man in his place by their standards.

Numbers 2:18 On the west side shall be the standard of the camp of Ephraim according to their armies: and the captain of the sons of Ephraim shall be Elishama the son of Ammihud.

Numbers 2:19 And his host, and those that were numbered of them, were forty thousand and five hundred.

Numbers 2:20 And by him shall be the tribe of Manasseh: and the captain of the children of Manasseh shall be Gamaliel the son of Pedahzur.

Numbers 2:21 And his host, and those that were numbered of them, were thirty and two thousand and two hundred.

Numbers 2:22 Then the tribe of Benjamin: and the captain of the sons of Benjamin shall be Abidan the son of Gideoni.

Numbers 2:23 And his host, and those that were numbered of them, were thirty and five thousand and four hundred.

Numbers 2:24 All that were numbered of the camp of Ephraim were an hundred thousand and eight thousand and an hundred, throughout their armies. And they shall go forward in the third rank.

Numbers 2:25 The standard of the camp of Dan shall be on the north side by their armies: and the captain of the children of Dan shall be Ahiezer the son of Ammishaddai.

Numbers 2:26 And his host, and those that were numbered of them, were threescore and two thousand and seven hundred.

Numbers 2:27 And those that encamp by him shall be the tribe of Asher: and the captain of the children of Asher shall be Pagiel the son of Ocran.

Numbers 2:28 And his host, and those that were numbered of them, were forty and one thousand and five hundred.

Numbers 2:29 Then the tribe of Naphtali: and the captain of the children of Naphtali shall be Ahira the son of Enan.

Numbers 2:30 And his host, and those that were numbered of them, were fifty and three thousand and four hundred.

Numbers 2:31 All they that were numbered in the camp of Dan were an hundred thousand and fifty and seven thousand and six hundred. They shall go hindmost with their standards.

Numbers 2:32 These are those which were numbered of the children of Israel by the house of their fathers: all those that were numbered of the camps throughout their hosts were six hundred thousand and three thousand and five hundred and fifty.

Numbers 2:33 But the Levites were not numbered among the children of Israel; as the Lord commanded Moses.

Numbers 2:34 And the children of Israel did according to all that the Lord commanded Moses: so they pitched by their standards, and so they set forward, every one after their families, according to the house of their fathers.
