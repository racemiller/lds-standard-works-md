# Ezekiel 5

Ezekiel 5 (summary): The judgment of Jerusalem will include famine, pestilence, war, and the scattering of her inhabitants.

Ezekiel 5:1 And thou, son of man, take thee a sharp knife, take thee a barber’s razor, and cause it to pass upon thine head and upon thy beard: then take thee balances to weigh, and divide the hair.

Ezekiel 5:2 Thou shalt burn with fire a third part in the midst of the city, when the days of the siege are fulfilled: and thou shalt take a third part, and smite about it with a knife: and a third part thou shalt scatter in the wind; and I will draw out a sword after them.

Ezekiel 5:3 Thou shalt also take thereof a few in number, and bind them in thy skirts.

Ezekiel 5:4 Then take of them again, and cast them into the midst of the fire, and burn them in the fire; for thereof shall a fire come forth into all the house of Israel.

Ezekiel 5:5 Thus saith the Lord God; This is Jerusalem: I have set it in the midst of the nations and countries that are round about her.

Ezekiel 5:6 And she hath changed my judgments into wickedness more than the nations, and my statutes more than the countries that are round about her: for they have refused my judgments and my statutes, they have not walked in them.

Ezekiel 5:7 Therefore thus saith the Lord God; Because ye multiplied more than the nations that are round about you, and have not walked in my statutes, neither have kept my judgments, neither have done according to the judgments of the nations that are round about you;

Ezekiel 5:8 Therefore thus saith the Lord God; Behold, I, even I, am against thee, and will execute judgments in the midst of thee in the sight of the nations.

Ezekiel 5:9 And I will do in thee that which I have not done, and whereunto I will not do any more the like, because of all thine abominations.

Ezekiel 5:10 Therefore the fathers shall eat the sons in the midst of thee, and the sons shall eat their fathers; and I will execute judgments in thee, and the whole remnant of thee will I scatter into all the winds.

Ezekiel 5:11 Wherefore, as I live, saith the Lord God; Surely, because thou hast defiled my sanctuary with all thy detestable things, and with all thine abominations, therefore will I also diminish thee; neither shall mine eye spare, neither will I have any pity.

Ezekiel 5:12 A third part of thee shall die with the pestilence, and with famine shall they be consumed in the midst of thee: and a third part shall fall by the sword round about thee; and I will scatter a third part into all the winds, and I will draw out a sword after them.

Ezekiel 5:13 Thus shall mine anger be accomplished, and I will cause my fury to rest upon them, and I will be comforted: and they shall know that I the Lord have spoken it in my zeal, when I have accomplished my fury in them.

Ezekiel 5:14 Moreover I will make thee waste, and a reproach among the nations that are round about thee, in the sight of all that pass by.

Ezekiel 5:15 So it shall be a reproach and a taunt, an instruction and an astonishment unto the nations that are round about thee, when I shall execute judgments in thee in anger and in fury and in furious rebukes. I the Lord have spoken it.

Ezekiel 5:16 When I shall send upon them the evil arrows of famine, which shall be for their destruction, and which I will send to destroy you: and I will increase the famine upon you, and will break your staff of bread:

Ezekiel 5:17 So will I send upon you famine and evil beasts, and they shall bereave thee; and pestilence and blood shall pass through thee; and I will bring the sword upon thee. I the Lord have spoken it.
