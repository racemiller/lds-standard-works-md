# Deuteronomy 28

Deuteronomy 28 (summary): If the children of Israel are obedient, they will be blessed temporally and spiritually—If they are disobedient, they will be cursed, smitten, and destroyed; diseases, plagues, and oppression will come upon them; they will serve false gods and become a byword among all nations; fierce nations will enslave them; and they will eat their own children and be scattered among all nations.

Deuteronomy 28:1 And it shall come to pass, if thou shalt hearken diligently unto the voice of the Lord thy God, to observe and to do all his commandments which I command thee this day, that the Lord thy God will set thee on high above all nations of the earth:

Deuteronomy 28:2 And all these blessings shall come on thee, and overtake thee, if thou shalt hearken unto the voice of the Lord thy God.

Deuteronomy 28:3 Blessed shalt thou be in the city, and blessed shalt thou be in the field.

Deuteronomy 28:4 Blessed shall be the fruit of thy body, and the fruit of thy ground, and the fruit of thy cattle, the increase of thy kine, and the flocks of thy sheep.

Deuteronomy 28:5 Blessed shall be thy basket and thy store.

Deuteronomy 28:6 Blessed shalt thou be when thou comest in, and blessed shalt thou be when thou goest out.

Deuteronomy 28:7 The Lord shall cause thine enemies that rise up against thee to be smitten before thy face: they shall come out against thee one way, and flee before thee seven ways.

Deuteronomy 28:8 The Lord shall command the blessing upon thee in thy storehouses, and in all that thou settest thine hand unto; and he shall bless thee in the land which the Lord thy God giveth thee.

Deuteronomy 28:9 The Lord shall establish thee an holy people unto himself, as he hath sworn unto thee, if thou shalt keep the commandments of the Lord thy God, and walk in his ways.

Deuteronomy 28:10 And all people of the earth shall see that thou art called by the name of the Lord; and they shall be afraid of thee.

Deuteronomy 28:11 And the Lord shall make thee plenteous in goods, in the fruit of thy body, and in the fruit of thy cattle, and in the fruit of thy ground, in the land which the Lord sware unto thy fathers to give thee.

Deuteronomy 28:12 The Lord shall open unto thee his good treasure, the heaven to give the rain unto thy land in his season, and to bless all the work of thine hand: and thou shalt lend unto many nations, and thou shalt not borrow.

Deuteronomy 28:13 And the Lord shall make thee the head, and not the tail; and thou shalt be above only, and thou shalt not be beneath; if that thou hearken unto the commandments of the Lord thy God, which I command thee this day, to observe and to do them:

Deuteronomy 28:14 And thou shalt not go aside from any of the words which I command thee this day, to the right hand, or to the left, to go after other gods to serve them.

Deuteronomy 28:15 But it shall come to pass, if thou wilt not hearken unto the voice of the Lord thy God, to observe to do all his commandments and his statutes which I command thee this day; that all these curses shall come upon thee, and overtake thee:

Deuteronomy 28:16 Cursed shalt thou be in the city, and cursed shalt thou be in the field.

Deuteronomy 28:17 Cursed shall be thy basket and thy store.

Deuteronomy 28:18 Cursed shall be the fruit of thy body, and the fruit of thy land, the increase of thy kine, and the flocks of thy sheep.

Deuteronomy 28:19 Cursed shalt thou be when thou comest in, and cursed shalt thou be when thou goest out.

Deuteronomy 28:20 The Lord shall send upon thee cursing, vexation, and rebuke, in all that thou settest thine hand unto for to do, until thou be destroyed, and until thou perish quickly; because of the wickedness of thy doings, whereby thou hast forsaken me.

Deuteronomy 28:21 The Lord shall make the pestilence cleave unto thee, until he have consumed thee from off the land, whither thou goest to possess it.

Deuteronomy 28:22 The Lord shall smite thee with a consumption, and with a fever, and with an inflammation, and with an extreme burning, and with the sword, and with blasting, and with mildew; and they shall pursue thee until thou perish.

Deuteronomy 28:23 And thy heaven that is over thy head shall be brass, and the earth that is under thee shall be iron.

Deuteronomy 28:24 The Lord shall make the rain of thy land powder and dust: from heaven shall it come down upon thee, until thou be destroyed.

Deuteronomy 28:25 The Lord shall cause thee to be smitten before thine enemies: thou shalt go out one way against them, and flee seven ways before them: and shalt be removed into all the kingdoms of the earth.

Deuteronomy 28:26 And thy carcase shall be meat unto all fowls of the air, and unto the beasts of the earth, and no man shall fray them away.

Deuteronomy 28:27 The Lord will smite thee with the botch of Egypt, and with the emerods, and with the scab, and with the itch, whereof thou canst not be healed.

Deuteronomy 28:28 The Lord shall smite thee with madness, and blindness, and astonishment of heart:

Deuteronomy 28:29 And thou shalt grope at noonday, as the blind gropeth in darkness, and thou shalt not prosper in thy ways: and thou shalt be only oppressed and spoiled evermore, and no man shall save thee.

Deuteronomy 28:30 Thou shalt betroth a wife, and another man shall lie with her: thou shalt build an house, and thou shalt not dwell therein: thou shalt plant a vineyard, and shalt not gather the grapes thereof.

Deuteronomy 28:31 Thine ox shall be slain before thine eyes, and thou shalt not eat thereof: thine ass shall be violently taken away from before thy face, and shall not be restored to thee: thy sheep shall be given unto thine enemies, and thou shalt have none to rescue them.

Deuteronomy 28:32 Thy sons and thy daughters shall be given unto another people, and thine eyes shall look, and fail with longing for them all the day long: and there shall be no might in thine hand.

Deuteronomy 28:33 The fruit of thy land, and all thy labours, shall a nation which thou knowest not eat up; and thou shalt be only oppressed and crushed alway:

Deuteronomy 28:34 So that thou shalt be mad for the sight of thine eyes which thou shalt see.

Deuteronomy 28:35 The Lord shall smite thee in the knees, and in the legs, with a sore botch that cannot be healed, from the sole of thy foot unto the top of thy head.

Deuteronomy 28:36 The Lord shall bring thee, and thy king which thou shalt set over thee, unto a nation which neither thou nor thy fathers have known; and there shalt thou serve other gods, wood and stone.

Deuteronomy 28:37 And thou shalt become an astonishment, a proverb, and a byword, among all nations whither the Lord shall lead thee.

Deuteronomy 28:38 Thou shalt carry much seed out into the field, and shalt gather but little in; for the locust shall consume it.

Deuteronomy 28:39 Thou shalt plant vineyards, and dress them, but shalt neither drink of the wine, nor gather the grapes; for the worms shall eat them.

Deuteronomy 28:40 Thou shalt have olive trees throughout all thy coasts, but thou shalt not anoint thyself with the oil; for thine olive shall cast his fruit.

Deuteronomy 28:41 Thou shalt beget sons and daughters, but thou shalt not enjoy them; for they shall go into captivity.

Deuteronomy 28:42 All thy trees and fruit of thy land shall the locust consume.

Deuteronomy 28:43 The stranger that is within thee shall get up above thee very high; and thou shalt come down very low.

Deuteronomy 28:44 He shall lend to thee, and thou shalt not lend to him: he shall be the head, and thou shalt be the tail.

Deuteronomy 28:45 Moreover all these curses shall come upon thee, and shall pursue thee, and overtake thee, till thou be destroyed; because thou hearkenedst not unto the voice of the Lord thy God, to keep his commandments and his statutes which he commanded thee:

Deuteronomy 28:46 And they shall be upon thee for a sign and for a wonder, and upon thy seed for ever.

Deuteronomy 28:47 Because thou servedst not the Lord thy God with joyfulness, and with gladness of heart, for the abundance of all things;

Deuteronomy 28:48 Therefore shalt thou serve thine enemies which the Lord shall send against thee, in hunger, and in thirst, and in nakedness, and in want of all things: and he shall put a yoke of iron upon thy neck, until he have destroyed thee.

Deuteronomy 28:49 The Lord shall bring a nation against thee from far, from the end of the earth, as swift as the eagle flieth; a nation whose tongue thou shalt not understand;

Deuteronomy 28:50 A nation of fierce countenance, which shall not regard the person of the old, nor shew favour to the young:

Deuteronomy 28:51 And he shall eat the fruit of thy cattle, and the fruit of thy land, until thou be destroyed: which also shall not leave thee either corn, wine, or oil, or the increase of thy kine, or flocks of thy sheep, until he have destroyed thee.

Deuteronomy 28:52 And he shall besiege thee in all thy gates, until thy high and fenced walls come down, wherein thou trustedst, throughout all thy land: and he shall besiege thee in all thy gates throughout all thy land, which the Lord thy God hath given thee.

Deuteronomy 28:53 And thou shalt eat the fruit of thine own body, the flesh of thy sons and of thy daughters, which the Lord thy God hath given thee, in the siege, and in the straitness, wherewith thine enemies shall distress thee:

Deuteronomy 28:54 So that the man that is tender among you, and very delicate, his eye shall be evil toward his brother, and toward the wife of his bosom, and toward the remnant of his children which he shall leave:

Deuteronomy 28:55 So that he will not give to any of them of the flesh of his children whom he shall eat: because he hath nothing left him in the siege, and in the straitness, wherewith thine enemies shall distress thee in all thy gates.

Deuteronomy 28:56 The tender and delicate woman among you, which would not adventure to set the sole of her foot upon the ground for delicateness and tenderness, her eye shall be evil toward the husband of her bosom, and toward her son, and toward her daughter,

Deuteronomy 28:57 And toward her young one that cometh out from between her feet, and toward her children which she shall bear: for she shall eat them for want of all things secretly in the siege and straitness, wherewith thine enemy shall distress thee in thy gates.

Deuteronomy 28:58 If thou wilt not observe to do all the words of this law that are written in this book, that thou mayest fear this glorious and fearful name, The Lord Thy God;

Deuteronomy 28:59 Then the Lord will make thy plagues wonderful, and the plagues of thy seed, even great plagues, and of long continuance, and sore sicknesses, and of long continuance.

Deuteronomy 28:60 Moreover he will bring upon thee all the diseases of Egypt, which thou wast afraid of; and they shall cleave unto thee.

Deuteronomy 28:61 Also every sickness, and every plague, which is not written in the book of this law, them will the Lord bring upon thee, until thou be destroyed.

Deuteronomy 28:62 And ye shall be left few in number, whereas ye were as the stars of heaven for multitude; because thou wouldest not obey the voice of the Lord thy God.

Deuteronomy 28:63 And it shall come to pass, that as the Lord rejoiced over you to do you good, and to multiply you; so the Lord will rejoice over you to destroy you, and to bring you to nought; and ye shall be plucked from off the land whither thou goest to possess it.

Deuteronomy 28:64 And the Lord shall scatter thee among all people, from the one end of the earth even unto the other; and there thou shalt serve other gods, which neither thou nor thy fathers have known, even wood and stone.

Deuteronomy 28:65 And among these nations shalt thou find no ease, neither shall the sole of thy foot have rest: but the Lord shall give thee there a trembling heart, and failing of eyes, and sorrow of mind:

Deuteronomy 28:66 And thy life shall hang in doubt before thee; and thou shalt fear day and night, and shalt have none assurance of thy life:

Deuteronomy 28:67 In the morning thou shalt say, Would God it were even! and at even thou shalt say, Would God it were morning! for the fear of thine heart wherewith thou shalt fear, and for the sight of thine eyes which thou shalt see.

Deuteronomy 28:68 And the Lord shall bring thee into Egypt again with ships, by the way whereof I spake unto thee, Thou shalt see it no more again: and there ye shall be sold unto your enemies for bondmen and bondwomen, and no man shall buy you.
