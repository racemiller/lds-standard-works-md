# Ezekiel 8

Ezekiel 8 (summary): Ezekiel sees in vision the wickedness and abominations of the people of Judah in Jerusalem—He sees idolatry practiced in the temple itself.

Ezekiel 8:1 And it came to pass in the sixth year, in the sixth month, in the fifth day of the month, as I sat in mine house, and the elders of Judah sat before me, that the hand of the Lord God fell there upon me.

Ezekiel 8:2 Then I beheld, and lo a likeness as the appearance of fire: from the appearance of his loins even downward, fire; and from his loins even upward, as the appearance of brightness, as the colour of amber.

Ezekiel 8:3 And he put forth the form of an hand, and took me by a lock of mine head; and the spirit lifted me up between the earth and the heaven, and brought me in the visions of God to Jerusalem, to the door of the inner gate that looketh toward the north; where was the seat of the image of jealousy, which provoketh to jealousy.

Ezekiel 8:4 And, behold, the glory of the God of Israel was there, according to the vision that I saw in the plain.

Ezekiel 8:5 Then said he unto me, Son of man, lift up thine eyes now the way toward the north. So I lifted up mine eyes the way toward the north, and behold northward at the gate of the altar this image of jealousy in the entry.

Ezekiel 8:6 He said furthermore unto me, Son of man, seest thou what they do? even the great abominations that the house of Israel committeth here, that I should go far off from my sanctuary? but turn thee yet again, and thou shalt see greater abominations.

Ezekiel 8:7 And he brought me to the door of the court; and when I looked, behold a hole in the wall.

Ezekiel 8:8 Then said he unto me, Son of man, dig now in the wall: and when I had digged in the wall, behold a door.

Ezekiel 8:9 And he said unto me, Go in, and behold the wicked abominations that they do here.

Ezekiel 8:10 So I went in and saw; and behold every form of creeping things, and abominable beasts, and all the idols of the house of Israel, portrayed upon the wall round about.

Ezekiel 8:11 And there stood before them seventy men of the ancients of the house of Israel, and in the midst of them stood Jaazaniah the son of Shaphan, with every man his censer in his hand; and a thick cloud of incense went up.

Ezekiel 8:12 Then said he unto me, Son of man, hast thou seen what the ancients of the house of Israel do in the dark, every man in the chambers of his imagery? for they say, The Lord seeth us not; the Lord hath forsaken the earth.

Ezekiel 8:13 He said also unto me, Turn thee yet again, and thou shalt see greater abominations that they do.

Ezekiel 8:14 Then he brought me to the door of the gate of the Lord’s house which was toward the north; and, behold, there sat women weeping for Tammuz.

Ezekiel 8:15 Then said he unto me, Hast thou seen this, O son of man? turn thee yet again, and thou shalt see greater abominations than these.

Ezekiel 8:16 And he brought me into the inner court of the Lord’s house, and, behold, at the door of the temple of the Lord, between the porch and the altar, were about five and twenty men, with their backs toward the temple of the Lord, and their faces toward the east; and they worshipped the sun toward the east.

Ezekiel 8:17 Then he said unto me, Hast thou seen this, O son of man? Is it a light thing to the house of Judah that they commit the abominations which they commit here? for they have filled the land with violence, and have returned to provoke me to anger: and, lo, they put the branch to their nose.

Ezekiel 8:18 Therefore will I also deal in fury: mine eye shall not spare, neither will I have pity: and though they cry in mine ears with a loud voice, yet will I not hear them.
