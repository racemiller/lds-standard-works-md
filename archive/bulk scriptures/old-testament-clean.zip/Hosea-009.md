# Hosea 9

Hosea 9 (summary): The people of Israel are taken into captivity for their sins—Ephraim will be a wanderer among the nations.

Hosea 9:1 Rejoice not, O Israel, for joy, as other people: for thou hast gone a whoring from thy God, thou hast loved a reward upon every cornfloor.

Hosea 9:2 The floor and the winepress shall not feed them, and the new wine shall fail in her.

Hosea 9:3 They shall not dwell in the Lord’s land; but Ephraim shall return to Egypt, and they shall eat unclean things in Assyria.

Hosea 9:4 They shall not offer wine offerings to the Lord, neither shall they be pleasing unto him: their sacrifices shall be unto them as the bread of mourners; all that eat thereof shall be polluted: for their bread for their soul shall not come into the house of the Lord.

Hosea 9:5 What will ye do in the solemn day, and in the day of the feast of the Lord?

Hosea 9:6 For, lo, they are gone because of destruction: Egypt shall gather them up, Memphis shall bury them: the pleasant places for their silver, nettles shall possess them: thorns shall be in their tabernacles.

Hosea 9:7 The days of visitation are come, the days of recompence are come; Israel shall know it: the prophet is a fool, the spiritual man is mad, for the multitude of thine iniquity, and the great hatred.

Hosea 9:8 The watchman of Ephraim was with my God: but the prophet is a snare of a fowler in all his ways, and hatred in the house of his God.

Hosea 9:9 They have deeply corrupted themselves, as in the days of Gibeah: therefore he will remember their iniquity, he will visit their sins.

Hosea 9:10 I found Israel like grapes in the wilderness; I saw your fathers as the firstripe in the fig tree at her first time: but they went to Baal-peor, and separated themselves unto that shame; and their abominations were according as they loved.

Hosea 9:11 As for Ephraim, their glory shall fly away like a bird, from the birth, and from the womb, and from the conception.

Hosea 9:12 Though they bring up their children, yet will I bereave them, that there shall not be a man left: yea, woe also to them when I depart from them!

Hosea 9:13 Ephraim, as I saw Tyrus, is planted in a pleasant place: but Ephraim shall bring forth his children to the murderer.

Hosea 9:14 Give them, O Lord: what wilt thou give? give them a miscarrying womb and dry breasts.

Hosea 9:15 All their wickedness is in Gilgal: for there I hated them: for the wickedness of their doings I will drive them out of mine house, I will love them no more: all their princes are revolters.

Hosea 9:16 Ephraim is smitten, their root is dried up, they shall bear no fruit: yea, though they bring forth, yet will I slay even the beloved fruit of their womb.

Hosea 9:17 My God will cast them away, because they did not hearken unto him: and they shall be wanderers among the nations.
