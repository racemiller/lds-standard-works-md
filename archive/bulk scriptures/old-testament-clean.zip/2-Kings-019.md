# 2 Kings 19

2 Kings 19 (summary): Hezekiah seeks counsel from Isaiah to save Jerusalem—Isaiah prophesies the defeat of the Assyrians and the death of Sennacherib—Hezekiah prays for deliverance—Sennacherib sends a blasphemous letter—Isaiah prophesies that the Assyrians will be destroyed and that a remnant of Judah will flourish—An angel slays 185,000 Assyrians—Sennacherib is slain by his sons.

2 Kings 19:1 And it came to pass, when king Hezekiah heard it, that he rent his clothes, and covered himself with sackcloth, and went into the house of the Lord.

2 Kings 19:2 And he sent Eliakim, which was over the household, and Shebna the scribe, and the elders of the priests, covered with sackcloth, to Isaiah the prophet the son of Amoz.

2 Kings 19:3 And they said unto him, Thus saith Hezekiah, This day is a day of trouble, and of rebuke, and blasphemy: for the children are come to the birth, and there is not strength to bring forth.

2 Kings 19:4 It may be the Lord thy God will hear all the words of Rab-shakeh, whom the king of Assyria his master hath sent to reproach the living God; and will reprove the words which the Lord thy God hath heard: wherefore lift up thy prayer for the remnant that are left.

2 Kings 19:5 So the servants of king Hezekiah came to Isaiah.

2 Kings 19:6 And Isaiah said unto them, Thus shall ye say to your master, Thus saith the Lord, Be not afraid of the words which thou hast heard, with which the servants of the king of Assyria have blasphemed me.

2 Kings 19:7 Behold, I will send a blast upon him, and he shall hear a rumour, and shall return to his own land; and I will cause him to fall by the sword in his own land.

2 Kings 19:8 So Rab-shakeh returned, and found the king of Assyria warring against Libnah: for he had heard that he was departed from Lachish.

2 Kings 19:9 And when he heard say of Tirhakah king of Ethiopia, Behold, he is come out to fight against thee: he sent messengers again unto Hezekiah, saying,

2 Kings 19:10 Thus shall ye speak to Hezekiah king of Judah, saying, Let not thy God in whom thou trustest deceive thee, saying, Jerusalem shall not be delivered into the hand of the king of Assyria.

2 Kings 19:11 Behold, thou hast heard what the kings of Assyria have done to all lands, by destroying them utterly: and shalt thou be delivered?

2 Kings 19:12 Have the gods of the nations delivered them which my fathers have destroyed; as Gozan, and Haran, and Rezeph, and the children of Eden which were in Thelasar?

2 Kings 19:13 Where is the king of Hamath, and the king of Arpad, and the king of the city of Sepharvaim, of Hena, and Ivah?

2 Kings 19:14 And Hezekiah received the letter of the hand of the messengers, and read it: and Hezekiah went up into the house of the Lord, and spread it before the Lord.

2 Kings 19:15 And Hezekiah prayed before the Lord, and said, O Lord God of Israel, which dwellest between the cherubims, thou art the God, even thou alone, of all the kingdoms of the earth; thou hast made heaven and earth.

2 Kings 19:16 Lord, bow down thine ear, and hear: open, Lord, thine eyes, and see: and hear the words of Sennacherib, which hath sent him to reproach the living God.

2 Kings 19:17 Of a truth, Lord, the kings of Assyria have destroyed the nations and their lands,

2 Kings 19:18 And have cast their gods into the fire: for they were no gods, but the work of men’s hands, wood and stone: therefore they have destroyed them.

2 Kings 19:19 Now therefore, O Lord our God, I beseech thee, save thou us out of his hand, that all the kingdoms of the earth may know that thou art the Lord God, even thou only.

2 Kings 19:20 Then Isaiah the son of Amoz sent to Hezekiah, saying, Thus saith the Lord God of Israel, That which thou hast prayed to me against Sennacherib king of Assyria I have heard.

2 Kings 19:21 This is the word that the Lord hath spoken concerning him; The virgin the daughter of Zion hath despised thee, and laughed thee to scorn; the daughter of Jerusalem hath shaken her head at thee.

2 Kings 19:22 Whom hast thou reproached and blasphemed? and against whom hast thou exalted thy voice, and lifted up thine eyes on high? even against the Holy One of Israel.

2 Kings 19:23 By thy messengers thou hast reproached the Lord, and hast said, With the multitude of my chariots I am come up to the height of the mountains, to the sides of Lebanon, and will cut down the tall cedar trees thereof, and the choice fir trees thereof: and I will enter into the lodgings of his borders, and into the forest of his Carmel.

2 Kings 19:24 I have digged and drunk strange waters, and with the sole of my feet have I dried up all the rivers of besieged places.

2 Kings 19:25 Hast thou not heard long ago how I have done it, and of ancient times that I have formed it? now have I brought it to pass, that thou shouldest be to lay waste fenced cities into ruinous heaps.

2 Kings 19:26 Therefore their inhabitants were of small power, they were dismayed and confounded; they were as the grass of the field, and as the green herb, as the grass on the housetops, and as corn blasted before it be grown up.

2 Kings 19:27 But I know thy abode, and thy going out, and thy coming in, and thy rage against me.

2 Kings 19:28 Because thy rage against me and thy tumult is come up into mine ears, therefore I will put my hook in thy nose, and my bridle in thy lips, and I will turn thee back by the way by which thou camest.

2 Kings 19:29 And this shall be a sign unto thee, Ye shall eat this year such things as grow of themselves, and in the second year that which springeth of the same; and in the third year sow ye, and reap, and plant vineyards, and eat the fruits thereof.

2 Kings 19:30 And the remnant that is escaped of the house of Judah shall yet again take root downward, and bear fruit upward.

2 Kings 19:31 For out of Jerusalem shall go forth a remnant, and they that escape out of mount Zion: the zeal of the Lord of hosts shall do this.

2 Kings 19:32 Therefore thus saith the Lord concerning the king of Assyria, He shall not come into this city, nor shoot an arrow there, nor come before it with shield, nor cast a bank against it.

2 Kings 19:33 By the way that he came, by the same shall he return, and shall not come into this city, saith the Lord.

2 Kings 19:34 For I will defend this city, to save it, for mine own sake, and for my servant David’s sake.

2 Kings 19:35 And it came to pass that night, that the angel of the Lord went out, and smote in the camp of the Assyrians an hundred fourscore and five thousand: and when they arose early in the morning, behold, they were all dead corpses.

2 Kings 19:36 So Sennacherib king of Assyria departed, and went and returned, and dwelt at Nineveh.

2 Kings 19:37 And it came to pass, as he was worshipping in the house of Nisroch his god, that Adrammelech and Sharezer his sons smote him with the sword: and they escaped into the land of Armenia. And Esarhaddon his son reigned in his stead.
