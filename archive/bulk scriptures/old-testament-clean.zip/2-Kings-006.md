# 2 Kings 6

2 Kings 6 (summary): Elisha causes an ax to float—He reveals to the king how to conduct a war with Syria—Horses and chariots of fire protect Elisha—The Syrians are smitten with blindness—Benhadad besieges Samaria, and foodstuff sells for a great price.

2 Kings 6:1 And the sons of the prophets said unto Elisha, Behold now, the place where we dwell with thee is too strait for us.

2 Kings 6:2 Let us go, we pray thee, unto Jordan, and take thence every man a beam, and let us make us a place there, where we may dwell. And he answered, Go ye.

2 Kings 6:3 And one said, Be content, I pray thee, and go with thy servants. And he answered, I will go.

2 Kings 6:4 So he went with them. And when they came to Jordan, they cut down wood.

2 Kings 6:5 But as one was felling a beam, the axe head fell into the water: and he cried, and said, Alas, master! for it was borrowed.

2 Kings 6:6 And the man of God said, Where fell it? And he shewed him the place. And he cut down a stick, and cast it in thither; and the iron did swim.

2 Kings 6:7 Therefore said he, Take it up to thee. And he put out his hand, and took it.

2 Kings 6:8 Then the king of Syria warred against Israel, and took counsel with his servants, saying, In such and such a place shall be my camp.

2 Kings 6:9 And the man of God sent unto the king of Israel, saying, Beware that thou pass not such a place; for thither the Syrians are come down.

2 Kings 6:10 And the king of Israel sent to the place which the man of God told him and warned him of, and saved himself there, not once nor twice.

2 Kings 6:11 Therefore the heart of the king of Syria was sore troubled for this thing; and he called his servants, and said unto them, Will ye not shew me which of us is for the king of Israel?

2 Kings 6:12 And one of his servants said, None, my lord, O king: but Elisha, the prophet that is in Israel, telleth the king of Israel the words that thou speakest in thy bedchamber.

2 Kings 6:13 And he said, Go and spy where he is, that I may send and fetch him. And it was told him, saying, Behold, he is in Dothan.

2 Kings 6:14 Therefore sent he thither horses, and chariots, and a great host: and they came by night, and compassed the city about.

2 Kings 6:15 And when the servant of the man of God was risen early, and gone forth, behold, an host compassed the city both with horses and chariots. And his servant said unto him, Alas, my master! how shall we do?

2 Kings 6:16 And he answered, Fear not: for they that be with us are more than they that be with them.

2 Kings 6:17 And Elisha prayed, and said, Lord, I pray thee, open his eyes, that he may see. And the Lord opened the eyes of the young man; and he saw: and, behold, the mountain was full of horses and chariots of fire round about Elisha.

2 Kings 6:18 And when they came down to him, Elisha prayed unto the Lord, and said, Smite this people, I pray thee, with blindness. And he smote them with blindness according to the word of Elisha.

2 Kings 6:19 And Elisha said unto them, This is not the way, neither is this the city: follow me, and I will bring you to the man whom ye seek. But he led them to Samaria.

2 Kings 6:20 And it came to pass, when they were come into Samaria, that Elisha said, Lord, open the eyes of these men, that they may see. And the Lord opened their eyes, and they saw; and, behold, they were in the midst of Samaria.

2 Kings 6:21 And the king of Israel said unto Elisha, when he saw them, My father, shall I smite them? shall I smite them?

2 Kings 6:22 And he answered, Thou shalt not smite them: wouldest thou smite those whom thou hast taken captive with thy sword and with thy bow? set bread and water before them, that they may eat and drink, and go to their master.

2 Kings 6:23 And he prepared great provision for them: and when they had eaten and drunk, he sent them away, and they went to their master. So the bands of Syria came no more into the land of Israel.

2 Kings 6:24 And it came to pass after this, that Ben-hadad king of Syria gathered all his host, and went up, and besieged Samaria.

2 Kings 6:25 And there was a great famine in Samaria: and, behold, they besieged it, until an ass’s head was sold for fourscore pieces of silver, and the fourth part of a cab of dove’s dung for five pieces of silver.

2 Kings 6:26 And as the king of Israel was passing by upon the wall, there cried a woman unto him, saying, Help, my lord, O king.

2 Kings 6:27 And he said, If the Lord do not help thee, whence shall I help thee? out of the barnfloor, or out of the winepress?

2 Kings 6:28 And the king said unto her, What aileth thee? And she answered, This woman said unto me, Give thy son, that we may eat him to day, and we will eat my son to morrow.

2 Kings 6:29 So we boiled my son, and did eat him: and I said unto her on the next day, Give thy son, that we may eat him: and she hath hid her son.

2 Kings 6:30 And it came to pass, when the king heard the words of the woman, that he rent his clothes; and he passed by upon the wall, and the people looked, and, behold, he had sackcloth within upon his flesh.

2 Kings 6:31 Then he said, God do so and more also to me, if the head of Elisha the son of Shaphat shall stand on him this day.

2 Kings 6:32 But Elisha sat in his house, and the elders sat with him; and the king sent a man from before him: but ere the messenger came to him, he said to the elders, See ye how this son of a murderer hath sent to take away mine head? look, when the messenger cometh, shut the door, and hold him fast at the door: is not the sound of his master’s feet behind him?

2 Kings 6:33 And while he yet talked with them, behold, the messenger came down unto him: and he said, Behold, this evil is of the Lord; what should I wait for the Lord any longer?
