# Psalms 30

Psalms 30 (summary): David sings praises and gives thanks to the Lord—David pleads for mercy.

Psalms 30:1 I will extol thee, O Lord; for thou hast lifted me up, and hast not made my foes to rejoice over me.

Psalms 30:2 O Lord my God, I cried unto thee, and thou hast healed me.

Psalms 30:3 O Lord, thou hast brought up my soul from the grave: thou hast kept me alive, that I should not go down to the pit.

Psalms 30:4 Sing unto the Lord, O ye saints of his, and give thanks at the remembrance of his holiness.

Psalms 30:5 For his anger endureth but a moment; in his favour is life: weeping may endure for a night, but joy cometh in the morning.

Psalms 30:6 And in my prosperity I said, I shall never be moved.

Psalms 30:7 Lord, by thy favour thou hast made my mountain to stand strong: thou didst hide thy face, and I was troubled.

Psalms 30:8 I cried to thee, O Lord; and unto the Lord I made supplication.

Psalms 30:9 What profit is there in my blood, when I go down to the pit? Shall the dust praise thee? shall it declare thy truth?

Psalms 30:10 Hear, O Lord, and have mercy upon me: Lord, be thou my helper.

Psalms 30:11 Thou hast turned for me my mourning into dancing: thou hast put off my sackcloth, and girded me with gladness;

Psalms 30:12 To the end that my glory may sing praise to thee, and not be silent. O Lord my God, I will give thanks unto thee for ever.
