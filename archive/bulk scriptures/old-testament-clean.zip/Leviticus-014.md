# Leviticus 14

Leviticus 14 (summary): Laws, rites, and sacrifices are revealed for cleansing lepers, their garments, and leprous houses.

Leviticus 14:1 And the Lord spake unto Moses, saying,

Leviticus 14:2 This shall be the law of the leper in the day of his cleansing: He shall be brought unto the priest:

Leviticus 14:3 And the priest shall go forth out of the camp; and the priest shall look, and, behold, if the plague of leprosy be healed in the leper;

Leviticus 14:4 Then shall the priest command to take for him that is to be cleansed two birds alive and clean, and cedar wood, and scarlet, and hyssop:

Leviticus 14:5 And the priest shall command that one of the birds be killed in an earthen vessel over running water:

Leviticus 14:6 As for the living bird, he shall take it, and the cedar wood, and the scarlet, and the hyssop, and shall dip them and the living bird in the blood of the bird that was killed over the running water:

Leviticus 14:7 And he shall sprinkle upon him that is to be cleansed from the leprosy seven times, and shall pronounce him clean, and shall let the living bird loose into the open field.

Leviticus 14:8 And he that is to be cleansed shall wash his clothes, and shave off all his hair, and wash himself in water, that he may be clean: and after that he shall come into the camp, and shall tarry abroad out of his tent seven days.

Leviticus 14:9 But it shall be on the seventh day, that he shall shave all his hair off his head and his beard and his eyebrows, even all his hair he shall shave off: and he shall wash his clothes, also he shall wash his flesh in water, and he shall be clean.

Leviticus 14:10 And on the eighth day he shall take two he lambs without blemish, and one ewe lamb of the first year without blemish, and three tenth deals of fine flour for a meat offering, mingled with oil, and one log of oil.

Leviticus 14:11 And the priest that maketh him clean shall present the man that is to be made clean, and those things, before the Lord, at the door of the tabernacle of the congregation:

Leviticus 14:12 And the priest shall take one he lamb, and offer him for a trespass offering, and the log of oil, and wave them for a wave offering before the Lord:

Leviticus 14:13 And he shall slay the lamb in the place where he shall kill the sin offering and the burnt offering, in the holy place: for as the sin offering is the priest’s, so is the trespass offering: it is most holy:

Leviticus 14:14 And the priest shall take some of the blood of the trespass offering, and the priest shall put it upon the tip of the right ear of him that is to be cleansed, and upon the thumb of his right hand, and upon the great toe of his right foot:

Leviticus 14:15 And the priest shall take some of the log of oil, and pour it into the palm of his own left hand:

Leviticus 14:16 And the priest shall dip his right finger in the oil that is in his left hand, and shall sprinkle of the oil with his finger seven times before the Lord:

Leviticus 14:17 And of the rest of the oil that is in his hand shall the priest put upon the tip of the right ear of him that is to be cleansed, and upon the thumb of his right hand, and upon the great toe of his right foot, upon the blood of the trespass offering:

Leviticus 14:18 And the remnant of the oil that is in the priest’s hand he shall pour upon the head of him that is to be cleansed: and the priest shall make an atonement for him before the Lord.

Leviticus 14:19 And the priest shall offer the sin offering, and make an atonement for him that is to be cleansed from his uncleanness; and afterward he shall kill the burnt offering:

Leviticus 14:20 And the priest shall offer the burnt offering and the meat offering upon the altar: and the priest shall make an atonement for him, and he shall be clean.

Leviticus 14:21 And if he be poor, and cannot get so much; then he shall take one lamb for a trespass offering to be waved, to make an atonement for him, and one tenth deal of fine flour mingled with oil for a meat offering, and a log of oil;

Leviticus 14:22 And two turtledoves, or two young pigeons, such as he is able to get; and the one shall be a sin offering, and the other a burnt offering.

Leviticus 14:23 And he shall bring them on the eighth day for his cleansing unto the priest, unto the door of the tabernacle of the congregation, before the Lord.

Leviticus 14:24 And the priest shall take the lamb of the trespass offering, and the log of oil, and the priest shall wave them for a wave offering before the Lord:

Leviticus 14:25 And he shall kill the lamb of the trespass offering, and the priest shall take some of the blood of the trespass offering, and put it upon the tip of the right ear of him that is to be cleansed, and upon the thumb of his right hand, and upon the great toe of his right foot:

Leviticus 14:26 And the priest shall pour of the oil into the palm of his own left hand:

Leviticus 14:27 And the priest shall sprinkle with his right finger some of the oil that is in his left hand seven times before the Lord:

Leviticus 14:28 And the priest shall put of the oil that is in his hand upon the tip of the right ear of him that is to be cleansed, and upon the thumb of his right hand, and upon the great toe of his right foot, upon the place of the blood of the trespass offering:

Leviticus 14:29 And the rest of the oil that is in the priest’s hand he shall put upon the head of him that is to be cleansed, to make an atonement for him before the Lord.

Leviticus 14:30 And he shall offer the one of the turtledoves, or of the young pigeons, such as he can get;

Leviticus 14:31 Even such as he is able to get, the one for a sin offering, and the other for a burnt offering, with the meat offering: and the priest shall make an atonement for him that is to be cleansed before the Lord.

Leviticus 14:32 This is the law of him in whom is the plague of leprosy, whose hand is not able to get that which pertaineth to his cleansing.

Leviticus 14:33 And the Lord spake unto Moses and unto Aaron, saying,

Leviticus 14:34 When ye be come into the land of Canaan, which I give to you for a possession, and I put the plague of leprosy in a house of the land of your possession;

Leviticus 14:35 And he that owneth the house shall come and tell the priest, saying, It seemeth to me there is as it were a plague in the house:

Leviticus 14:36 Then the priest shall command that they empty the house, before the priest go into it to see the plague, that all that is in the house be not made unclean: and afterward the priest shall go in to see the house:

Leviticus 14:37 And he shall look on the plague, and, behold, if the plague be in the walls of the house with hollow strakes, greenish or reddish, which in sight are lower than the wall;

Leviticus 14:38 Then the priest shall go out of the house to the door of the house, and shut up the house seven days:

Leviticus 14:39 And the priest shall come again the seventh day, and shall look: and, behold, if the plague be spread in the walls of the house;

Leviticus 14:40 Then the priest shall command that they take away the stones in which the plague is, and they shall cast them into an unclean place without the city:

Leviticus 14:41 And he shall cause the house to be scraped within round about, and they shall pour out the dust that they scrape off without the city into an unclean place:

Leviticus 14:42 And they shall take other stones, and put them in the place of those stones; and he shall take other mortar, and shall plaster the house.

Leviticus 14:43 And if the plague come again, and break out in the house, after that he hath taken away the stones, and after he hath scraped the house, and after it is plastered;

Leviticus 14:44 Then the priest shall come and look, and, behold, if the plague be spread in the house, it is a fretting leprosy in the house: it is unclean.

Leviticus 14:45 And he shall break down the house, the stones of it, and the timber thereof, and all the mortar of the house; and he shall carry them forth out of the city into an unclean place.

Leviticus 14:46 Moreover he that goeth into the house all the while that it is shut up shall be unclean until the even.

Leviticus 14:47 And he that lieth in the house shall wash his clothes; and he that eateth in the house shall wash his clothes.

Leviticus 14:48 And if the priest shall come in, and look upon it, and, behold, the plague hath not spread in the house, after the house was plastered: then the priest shall pronounce the house clean, because the plague is healed.

Leviticus 14:49 And he shall take to cleanse the house two birds, and cedar wood, and scarlet, and hyssop:

Leviticus 14:50 And he shall kill the one of the birds in an earthen vessel over running water:

Leviticus 14:51 And he shall take the cedar wood, and the hyssop, and the scarlet, and the living bird, and dip them in the blood of the slain bird, and in the running water, and sprinkle the house seven times:

Leviticus 14:52 And he shall cleanse the house with the blood of the bird, and with the running water, and with the living bird, and with the cedar wood, and with the hyssop, and with the scarlet:

Leviticus 14:53 But he shall let go the living bird out of the city into the open fields, and make an atonement for the house: and it shall be clean.

Leviticus 14:54 This is the law for all manner of plague of leprosy, and scall,

Leviticus 14:55 And for the leprosy of a garment, and of a house,

Leviticus 14:56 And for a rising, and for a scab, and for a bright spot:

Leviticus 14:57 To teach when it is unclean, and when it is clean: this is the law of leprosy.
