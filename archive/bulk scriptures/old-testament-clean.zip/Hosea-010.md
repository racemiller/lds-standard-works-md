# Hosea 10

Hosea 10 (summary): Israel has plowed wickedness and reaped iniquity—Hosea calls upon Israel to seek the Lord.

Hosea 10:1 Israel is an empty vine, he bringeth forth fruit unto himself: according to the multitude of his fruit he hath increased the altars; according to the goodness of his land they have made goodly images.

Hosea 10:2 Their heart is divided; now shall they be found faulty: he shall break down their altars, he shall spoil their images.

Hosea 10:3 For now they shall say, We have no king, because we feared not the Lord; what then should a king do to us?

Hosea 10:4 They have spoken words, swearing falsely in making a covenant: thus judgment springeth up as hemlock in the furrows of the field.

Hosea 10:5 The inhabitants of Samaria shall fear because of the calves of Beth-aven: for the people thereof shall mourn over it, and the priests thereof that rejoiced on it, for the glory thereof, because it is departed from it.

Hosea 10:6 It shall be also carried unto Assyria for a present to king Jareb: Ephraim shall receive shame, and Israel shall be ashamed of his own counsel.

Hosea 10:7 As for Samaria, her king is cut off as the foam upon the water.

Hosea 10:8 The high places also of Aven, the sin of Israel, shall be destroyed: the thorn and the thistle shall come up on their altars; and they shall say to the mountains, Cover us; and to the hills, Fall on us.

Hosea 10:9 O Israel, thou hast sinned from the days of Gibeah: there they stood: the battle in Gibeah against the children of iniquity did not overtake them.

Hosea 10:10 It is in my desire that I should chastise them; and the people shall be gathered against them, when they shall bind themselves in their two furrows.

Hosea 10:11 And Ephraim is as an heifer that is taught, and loveth to tread out the corn; but I passed over upon her fair neck: I will make Ephraim to ride; Judah shall plow, and Jacob shall break his clods.

Hosea 10:12 Sow to yourselves in righteousness, reap in mercy; break up your fallow ground: for it is time to seek the Lord, till he come and rain righteousness upon you.

Hosea 10:13 Ye have plowed wickedness, ye have reaped iniquity; ye have eaten the fruit of lies: because thou didst trust in thy way, in the multitude of thy mighty men.

Hosea 10:14 Therefore shall a tumult arise among thy people, and all thy fortresses shall be spoiled, as Shalman spoiled Beth-arbel in the day of battle: the mother was dashed in pieces upon her children.

Hosea 10:15 So shall Beth-el do unto you because of your great wickedness: in a morning shall the king of Israel utterly be cut off.
