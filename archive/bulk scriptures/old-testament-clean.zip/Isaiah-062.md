# Isaiah 62

Isaiah 62 (summary): In the last days, Israel will be gathered—Zion will be established—Her watchmen will teach about the Lord—The gospel standard will be lifted up—The people will be called holy, the redeemed of the Lord.

Isaiah 62:1 For Zion’s sake will I not hold my peace, and for Jerusalem’s sake I will not rest, until the righteousness thereof go forth as brightness, and the salvation thereof as a lamp that burneth.

Isaiah 62:2 And the Gentiles shall see thy righteousness, and all kings thy glory: and thou shalt be called by a new name, which the mouth of the Lord shall name.

Isaiah 62:3 Thou shalt also be a crown of glory in the hand of the Lord, and a royal diadem in the hand of thy God.

Isaiah 62:4 Thou shalt no more be termed Forsaken; neither shall thy land any more be termed Desolate: but thou shalt be called Hephzi-bah, and thy land Beulah: for the Lord delighteth in thee, and thy land shall be married.

Isaiah 62:5 For as a young man marrieth a virgin, so shall thy sons marry thee: and as the bridegroom rejoiceth over the bride, so shall thy God rejoice over thee.

Isaiah 62:6 I have set watchmen upon thy walls, O Jerusalem, which shall never hold their peace day nor night: ye that make mention of the Lord, keep not silence,

Isaiah 62:7 And give him no rest, till he establish, and till he make Jerusalem a praise in the earth.

Isaiah 62:8 The Lord hath sworn by his right hand, and by the arm of his strength, Surely I will no more give thy corn to be meat for thine enemies; and the sons of the stranger shall not drink thy wine, for the which thou hast laboured:

Isaiah 62:9 But they that have gathered it shall eat it, and praise the Lord; and they that have brought it together shall drink it in the courts of my holiness.

Isaiah 62:10 Go through, go through the gates; prepare ye the way of the people; cast up, cast up the highway; gather out the stones; lift up a standard for the people.

Isaiah 62:11 Behold, the Lord hath proclaimed unto the end of the world, Say ye to the daughter of Zion, Behold, thy salvation cometh; behold, his reward is with him, and his work before him.

Isaiah 62:12 And they shall call them, The holy people, The redeemed of the Lord: and thou shalt be called, Sought out, A city not forsaken.
