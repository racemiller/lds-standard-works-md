# Psalms 51

Psalms 51 (summary): David pleads for forgiveness after he went in to Bathsheba—He pleads, Create in me a clean heart, and renew a right spirit within me.

Psalms 51:1 Have mercy upon me, O God, according to thy lovingkindness: according unto the multitude of thy tender mercies blot out my transgressions.

Psalms 51:2 Wash me throughly from mine iniquity, and cleanse me from my sin.

Psalms 51:3 For I acknowledge my transgressions: and my sin is ever before me.

Psalms 51:4 Against thee, thee only, have I sinned, and done this evil in thy sight: that thou mightest be justified when thou speakest, and be clear when thou judgest.

Psalms 51:5 Behold, I was shapen in iniquity; and in sin did my mother conceive me.

Psalms 51:6 Behold, thou desirest truth in the inward parts: and in the hidden part thou shalt make me to know wisdom.

Psalms 51:7 Purge me with hyssop, and I shall be clean: wash me, and I shall be whiter than snow.

Psalms 51:8 Make me to hear joy and gladness; that the bones which thou hast broken may rejoice.

Psalms 51:9 Hide thy face from my sins, and blot out all mine iniquities.

Psalms 51:10 Create in me a clean heart, O God; and renew a right spirit within me.

Psalms 51:11 Cast me not away from thy presence; and take not thy holy spirit from me.

Psalms 51:12 Restore unto me the joy of thy salvation; and uphold me with thy free spirit.

Psalms 51:13 Then will I teach transgressors thy ways; and sinners shall be converted unto thee.

Psalms 51:14 Deliver me from bloodguiltiness, O God, thou God of my salvation: and my tongue shall sing aloud of thy righteousness.

Psalms 51:15 O Lord, open thou my lips; and my mouth shall shew forth thy praise.

Psalms 51:16 For thou desirest not sacrifice; else would I give it: thou delightest not in burnt offering.

Psalms 51:17 The sacrifices of God are a broken spirit: a broken and a contrite heart, O God, thou wilt not despise.

Psalms 51:18 Do good in thy good pleasure unto Zion: build thou the walls of Jerusalem.

Psalms 51:19 Then shalt thou be pleased with the sacrifices of righteousness, with burnt offering and whole burnt offering: then shall they offer bullocks upon thine altar.
