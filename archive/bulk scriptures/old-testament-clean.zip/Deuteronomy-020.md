# Deuteronomy 20

Deuteronomy 20 (summary): Laws are revealed for selecting soldiers and making war—Hittites, Amorites, Canaanites, Perizzites, Hivites, and Jebusites will be utterly destroyed.

Deuteronomy 20:1 When thou goest out to battle against thine enemies, and seest horses, and chariots, and a people more than thou, be not afraid of them: for the Lord thy God is with thee, which brought thee up out of the land of Egypt.

Deuteronomy 20:2 And it shall be, when ye are come nigh unto the battle, that the priest shall approach and speak unto the people,

Deuteronomy 20:3 And shall say unto them, Hear, O Israel, ye approach this day unto battle against your enemies: let not your hearts faint, fear not, and do not tremble, neither be ye terrified because of them;

Deuteronomy 20:4 For the Lord your God is he that goeth with you, to fight for you against your enemies, to save you.

Deuteronomy 20:5 And the officers shall speak unto the people, saying, What man is there that hath built a new house, and hath not dedicated it? let him go and return to his house, lest he die in the battle, and another man dedicate it.

Deuteronomy 20:6 And what man is he that hath planted a vineyard, and hath not yet eaten of it? let him also go and return unto his house, lest he die in the battle, and another man eat of it.

Deuteronomy 20:7 And what man is there that hath betrothed a wife, and hath not taken her? let him go and return unto his house, lest he die in the battle, and another man take her.

Deuteronomy 20:8 And the officers shall speak further unto the people, and they shall say, What man is there that is fearful and fainthearted? let him go and return unto his house, lest his brethren’s heart faint as well as his heart.

Deuteronomy 20:9 And it shall be, when the officers have made an end of speaking unto the people, that they shall make captains of the armies to lead the people.

Deuteronomy 20:10 When thou comest nigh unto a city to fight against it, then proclaim peace unto it.

Deuteronomy 20:11 And it shall be, if it make thee answer of peace, and open unto thee, then it shall be, that all the people that is found therein shall be tributaries unto thee, and they shall serve thee.

Deuteronomy 20:12 And if it will make no peace with thee, but will make war against thee, then thou shalt besiege it:

Deuteronomy 20:13 And when the Lord thy God hath delivered it into thine hands, thou shalt smite every male thereof with the edge of the sword:

Deuteronomy 20:14 But the women, and the little ones, and the cattle, and all that is in the city, even all the spoil thereof, shalt thou take unto thyself; and thou shalt eat the spoil of thine enemies, which the Lord thy God hath given thee.

Deuteronomy 20:15 Thus shalt thou do unto all the cities which are very far off from thee, which are not of the cities of these nations.

Deuteronomy 20:16 But of the cities of these people, which the Lord thy God doth give thee for an inheritance, thou shalt save alive nothing that breatheth:

Deuteronomy 20:17 But thou shalt utterly destroy them; namely, the Hittites, and the Amorites, the Canaanites, and the Perizzites, the Hivites, and the Jebusites; as the Lord thy God hath commanded thee:

Deuteronomy 20:18 That they teach you not to do after all their abominations, which they have done unto their gods; so should ye sin against the Lord your God.

Deuteronomy 20:19 When thou shalt besiege a city a long time, in making war against it to take it, thou shalt not destroy the trees thereof by forcing an axe against them: for thou mayest eat of them, and thou shalt not cut them down (for the tree of the field is man’s life) to employ them in the siege:

Deuteronomy 20:20 Only the trees which thou knowest that they be not trees for meat, thou shalt destroy and cut them down; and thou shalt build bulwarks against the city that maketh war with thee, until it be subdued.
