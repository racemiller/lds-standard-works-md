# Psalms 42

Psalms 42 (summary): The souls of the righteous thirst for God—The wicked say, Where is your God?

Psalms 42:1 As the hart panteth after the water brooks, so panteth my soul after thee, O God.

Psalms 42:2 My soul thirsteth for God, for the living God: when shall I come and appear before God?

Psalms 42:3 My tears have been my meat day and night, while they continually say unto me, Where is thy God?

Psalms 42:4 When I remember these things, I pour out my soul in me: for I had gone with the multitude, I went with them to the house of God, with the voice of joy and praise, with a multitude that kept holyday.

Psalms 42:5 Why art thou cast down, O my soul? and why art thou disquieted in me? hope thou in God: for I shall yet praise him for the help of his countenance.

Psalms 42:6 O my God, my soul is cast down within me: therefore will I remember thee from the land of Jordan, and of the Hermonites, from the hill Mizar.

Psalms 42:7 Deep calleth unto deep at the noise of thy waterspouts: all thy waves and thy billows are gone over me.

Psalms 42:8 Yet the Lord will command his lovingkindness in the daytime, and in the night his song shall be with me, and my prayer unto the God of my life.

Psalms 42:9 I will say unto God my rock, Why hast thou forgotten me? why go I mourning because of the oppression of the enemy?

Psalms 42:10 As with a sword in my bones, mine enemies reproach me; while they say daily unto me, Where is thy God?

Psalms 42:11 Why art thou cast down, O my soul? and why art thou disquieted within me? hope thou in God: for I shall yet praise him, who is the health of my countenance, and my God.
