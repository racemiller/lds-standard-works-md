# 2 Samuel 13

2 Samuel 13 (summary): Amnon desires Tamar, his sister, and forces her—He is slain by Absalom’s command—Absalom flees to Geshur.

2 Samuel 13:1 And it came to pass after this, that Absalom the son of David had a fair sister, whose name was Tamar; and Amnon the son of David loved her.

2 Samuel 13:2 And Amnon was so vexed, that he fell sick for his sister Tamar; for she was a virgin; and Amnon thought it hard for him to do any thing to her.

2 Samuel 13:3 But Amnon had a friend, whose name was Jonadab, the son of Shimeah David’s brother: and Jonadab was a very subtil man.

2 Samuel 13:4 And he said unto him, Why art thou, being the king’s son, lean from day to day? wilt thou not tell me? And Amnon said unto him, I love Tamar, my brother Absalom’s sister.

2 Samuel 13:5 And Jonadab said unto him, Lay thee down on thy bed, and make thyself sick: and when thy father cometh to see thee, say unto him, I pray thee, let my sister Tamar come, and give me meat, and dress the meat in my sight, that I may see it, and eat it at her hand.

2 Samuel 13:6 So Amnon lay down, and made himself sick: and when the king was come to see him, Amnon said unto the king, I pray thee, let Tamar my sister come, and make me a couple of cakes in my sight, that I may eat at her hand.

2 Samuel 13:7 Then David sent home to Tamar, saying, Go now to thy brother Amnon’s house, and dress him meat.

2 Samuel 13:8 So Tamar went to her brother Amnon’s house; and he was laid down. And she took flour, and kneaded it, and made cakes in his sight, and did bake the cakes.

2 Samuel 13:9 And she took a pan, and poured them out before him; but he refused to eat. And Amnon said, Have out all men from me. And they went out every man from him.

2 Samuel 13:10 And Amnon said unto Tamar, Bring the meat into the chamber, that I may eat of thine hand. And Tamar took the cakes which she had made, and brought them into the chamber to Amnon her brother.

2 Samuel 13:11 And when she had brought them unto him to eat, he took hold of her, and said unto her, Come lie with me, my sister.

2 Samuel 13:12 And she answered him, Nay, my brother, do not force me; for no such thing ought to be done in Israel: do not thou this folly.

2 Samuel 13:13 And I, whither shall I cause my shame to go? and as for thee, thou shalt be as one of the fools in Israel. Now therefore, I pray thee, speak unto the king; for he will not withhold me from thee.

2 Samuel 13:14 Howbeit he would not hearken unto her voice: but, being stronger than she, forced her, and lay with her.

2 Samuel 13:15 Then Amnon hated her exceedingly; so that the hatred wherewith he hated her was greater than the love wherewith he had loved her. And Amnon said unto her, Arise, be gone.

2 Samuel 13:16 And she said unto him, There is no cause: this evil in sending me away is greater than the other that thou didst unto me. But he would not hearken unto her.

2 Samuel 13:17 Then he called his servant that ministered unto him, and said, Put now this woman out from me, and bolt the door after her.

2 Samuel 13:18 And she had a garment of divers colours upon her: for with such robes were the king’s daughters that were virgins apparelled. Then his servant brought her out, and bolted the door after her.

2 Samuel 13:19 And Tamar put ashes on her head, and rent her garment of divers colours that was on her, and laid her hand on her head, and went on crying.

2 Samuel 13:20 And Absalom her brother said unto her, Hath Amnon thy brother been with thee? but hold now thy peace, my sister: he is thy brother; regard not this thing. So Tamar remained desolate in her brother Absalom’s house.

2 Samuel 13:21 But when king David heard of all these things, he was very wroth.

2 Samuel 13:22 And Absalom spake unto his brother Amnon neither good nor bad: for Absalom hated Amnon, because he had forced his sister Tamar.

2 Samuel 13:23 And it came to pass after two full years, that Absalom had sheepshearers in Baal-hazor, which is beside Ephraim: and Absalom invited all the king’s sons.

2 Samuel 13:24 And Absalom came to the king, and said, Behold now, thy servant hath sheepshearers; let the king, I beseech thee, and his servants go with thy servant.

2 Samuel 13:25 And the king said to Absalom, Nay, my son, let us not all now go, lest we be chargeable unto thee. And he pressed him: howbeit he would not go, but blessed him.

2 Samuel 13:26 Then said Absalom, If not, I pray thee, let my brother Amnon go with us. And the king said unto him, Why should he go with thee?

2 Samuel 13:27 But Absalom pressed him, that he let Amnon and all the king’s sons go with him.

2 Samuel 13:28 Now Absalom had commanded his servants, saying, Mark ye now when Amnon’s heart is merry with wine, and when I say unto you, Smite Amnon; then kill him, fear not: have not I commanded you? be courageous, and be valiant.

2 Samuel 13:29 And the servants of Absalom did unto Amnon as Absalom had commanded. Then all the king’s sons arose, and every man gat him up upon his mule, and fled.

2 Samuel 13:30 And it came to pass, while they were in the way, that tidings came to David, saying, Absalom hath slain all the king’s sons, and there is not one of them left.

2 Samuel 13:31 Then the king arose, and tare his garments, and lay on the earth; and all his servants stood by with their clothes rent.

2 Samuel 13:32 And Jonadab, the son of Shimeah David’s brother, answered and said, Let not my lord suppose that they have slain all the young men the king’s sons; for Amnon only is dead: for by the appointment of Absalom this hath been determined from the day that he forced his sister Tamar.

2 Samuel 13:33 Now therefore let not my lord the king take the thing to his heart, to think that all the king’s sons are dead: for Amnon only is dead.

2 Samuel 13:34 But Absalom fled. And the young man that kept the watch lifted up his eyes, and looked, and, behold, there came much people by the way of the hill side behind him.

2 Samuel 13:35 And Jonadab said unto the king, Behold, the king’s sons come: as thy servant said, so it is.

2 Samuel 13:36 And it came to pass, as soon as he had made an end of speaking, that, behold, the king’s sons came, and lifted up their voice and wept: and the king also and all his servants wept very sore.

2 Samuel 13:37 But Absalom fled, and went to Talmai, the son of Ammihud, king of Geshur. And David mourned for his son every day.

2 Samuel 13:38 So Absalom fled, and went to Geshur, and was there three years.

2 Samuel 13:39 And the soul of king David longed to go forth unto Absalom: for he was comforted concerning Amnon, seeing he was dead.
