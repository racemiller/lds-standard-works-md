# Isaiah 57

Isaiah 57 (summary): When the righteous die, they enter into peace—Mercy is promised to the penitent—There is no peace for the wicked.

Isaiah 57:1 The righteous perisheth, and no man layeth it to heart: and merciful men are taken away, none considering that the righteous is taken away from the evil to come.

Isaiah 57:2 He shall enter into peace: they shall rest in their beds, each one walking in his uprightness.

Isaiah 57:3 But draw near hither, ye sons of the sorceress, the seed of the adulterer and the whore.

Isaiah 57:4 Against whom do ye sport yourselves? against whom make ye a wide mouth, and draw out the tongue? are ye not children of transgression, a seed of falsehood,

Isaiah 57:5 Enflaming yourselves with idols under every green tree, slaying the children in the valleys under the clifts of the rocks?

Isaiah 57:6 Among the smooth stones of the stream is thy portion; they, they are thy lot: even to them hast thou poured a drink offering, thou hast offered a meat offering. Should I receive comfort in these?

Isaiah 57:7 Upon a lofty and high mountain hast thou set thy bed: even thither wentest thou up to offer sacrifice.

Isaiah 57:8 Behind the doors also and the posts hast thou set up thy remembrance: for thou hast discovered thyself to another than me, and art gone up; thou hast enlarged thy bed, and made thee a covenant with them; thou lovedst their bed where thou sawest it.

Isaiah 57:9 And thou wentest to the king with ointment, and didst increase thy perfumes, and didst send thy messengers far off, and didst debase thyself even unto hell.

Isaiah 57:10 Thou art wearied in the greatness of thy way; yet saidst thou not, There is no hope: thou hast found the life of thine hand; therefore thou wast not grieved.

Isaiah 57:11 And of whom hast thou been afraid or feared, that thou hast lied, and hast not remembered me, nor laid it to thy heart? have not I held my peace even of old, and thou fearest me not?

Isaiah 57:12 I will declare thy righteousness, and thy works; for they shall not profit thee.

Isaiah 57:13 When thou criest, let thy companies deliver thee; but the wind shall carry them all away; vanity shall take them: but he that putteth his trust in me shall possess the land, and shall inherit my holy mountain;

Isaiah 57:14 And shall say, Cast ye up, cast ye up, prepare the way, take up the stumblingblock out of the way of my people.

Isaiah 57:15 For thus saith the high and lofty One that inhabiteth eternity, whose name is Holy; I dwell in the high and holy place, with him also that is of a contrite and humble spirit, to revive the spirit of the humble, and to revive the heart of the contrite ones.

Isaiah 57:16 For I will not contend for ever, neither will I be always wroth: for the spirit should fail before me, and the souls which I have made.

Isaiah 57:17 For the iniquity of his covetousness was I wroth, and smote him: I hid me, and was wroth, and he went on frowardly in the way of his heart.

Isaiah 57:18 I have seen his ways, and will heal him: I will lead him also, and restore comforts unto him and to his mourners.

Isaiah 57:19 I create the fruit of the lips; Peace, peace to him that is far off, and to him that is near, saith the Lord; and I will heal him.

Isaiah 57:20 But the wicked are like the troubled sea, when it cannot rest, whose waters cast up mire and dirt.

Isaiah 57:21 There is no peace, saith my God, to the wicked.
