# Proverbs 23

Proverbs 23 (summary): Labor not to be rich—As a man thinks in his heart, so is he—Withhold not correction from a child—Be not among drunkards.

Proverbs 23:1 When thou sittest to eat with a ruler, consider diligently what is before thee:

Proverbs 23:2 And put a knife to thy throat, if thou be a man given to appetite.

Proverbs 23:3 Be not desirous of his dainties: for they are deceitful meat.

Proverbs 23:4 Labour not to be rich: cease from thine own wisdom.

Proverbs 23:5 Wilt thou set thine eyes upon that which is not? for riches certainly make themselves wings; they fly away as an eagle toward heaven.

Proverbs 23:6 Eat thou not the bread of him that hath an evil eye, neither desire thou his dainty meats:

Proverbs 23:7 For as he thinketh in his heart, so is he: Eat and drink, saith he to thee; but his heart is not with thee.

Proverbs 23:8 The morsel which thou hast eaten shalt thou vomit up, and lose thy sweet words.

Proverbs 23:9 Speak not in the ears of a fool: for he will despise the wisdom of thy words.

Proverbs 23:10 Remove not the old landmark; and enter not into the fields of the fatherless:

Proverbs 23:11 For their redeemer is mighty; he shall plead their cause with thee.

Proverbs 23:12 Apply thine heart unto instruction, and thine ears to the words of knowledge.

Proverbs 23:13 Withhold not correction from the child: for if thou beatest him with the rod, he shall not die.

Proverbs 23:14 Thou shalt beat him with the rod, and shalt deliver his soul from hell.

Proverbs 23:15 My son, if thine heart be wise, my heart shall rejoice, even mine.

Proverbs 23:16 Yea, my reins shall rejoice, when thy lips speak right things.

Proverbs 23:17 Let not thine heart envy sinners: but be thou in the fear of the Lord all the day long.

Proverbs 23:18 For surely there is an end; and thine expectation shall not be cut off.

Proverbs 23:19 Hear thou, my son, and be wise, and guide thine heart in the way.

Proverbs 23:20 Be not among winebibbers; among riotous eaters of flesh:

Proverbs 23:21 For the drunkard and the glutton shall come to poverty: and drowsiness shall clothe a man with rags.

Proverbs 23:22 Hearken unto thy father that begat thee, and despise not thy mother when she is old.

Proverbs 23:23 Buy the truth, and sell it not; also wisdom, and instruction, and understanding.

Proverbs 23:24 The father of the righteous shall greatly rejoice: and he that begetteth a wise child shall have joy of him.

Proverbs 23:25 Thy father and thy mother shall be glad, and she that bare thee shall rejoice.

Proverbs 23:26 My son, give me thine heart, and let thine eyes observe my ways.

Proverbs 23:27 For a whore is a deep ditch; and a strange woman is a narrow pit.

Proverbs 23:28 She also lieth in wait as for a prey, and increaseth the transgressors among men.

Proverbs 23:29 Who hath woe? who hath sorrow? who hath contentions? who hath babbling? who hath wounds without cause? who hath redness of eyes?

Proverbs 23:30 They that tarry long at the wine; they that go to seek mixed wine.

Proverbs 23:31 Look not thou upon the wine when it is red, when it giveth his colour in the cup, when it moveth itself aright.

Proverbs 23:32 At the last it biteth like a serpent, and stingeth like an adder.

Proverbs 23:33 Thine eyes shall behold strange women, and thine heart shall utter perverse things.

Proverbs 23:34 Yea, thou shalt be as he that lieth down in the midst of the sea, or as he that lieth upon the top of a mast.

Proverbs 23:35 They have stricken me, shalt thou say, and I was not sick; they have beaten me, and I felt it not: when shall I awake? I will seek it yet again.
