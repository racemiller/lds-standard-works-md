# Ezekiel 26

Ezekiel 26 (summary): Because she rejoiced in the sorrows and fall of Jerusalem, Tyre will be destroyed.

Ezekiel 26:1 And it came to pass in the eleventh year, in the first day of the month, that the word of the Lord came unto me, saying,

Ezekiel 26:2 Son of man, because that Tyrus hath said against Jerusalem, Aha, she is broken that was the gates of the people: she is turned unto me: I shall be replenished, now she is laid waste:

Ezekiel 26:3 Therefore thus saith the Lord God; Behold, I am against thee, O Tyrus, and will cause many nations to come up against thee, as the sea causeth his waves to come up.

Ezekiel 26:4 And they shall destroy the walls of Tyrus, and break down her towers: I will also scrape her dust from her, and make her like the top of a rock.

Ezekiel 26:5 It shall be a place for the spreading of nets in the midst of the sea: for I have spoken it, saith the Lord God: and it shall become a spoil to the nations.

Ezekiel 26:6 And her daughters which are in the field shall be slain by the sword; and they shall know that I am the Lord.

Ezekiel 26:7 For thus saith the Lord God; Behold, I will bring upon Tyrus Nebuchadrezzar king of Babylon, a king of kings, from the north, with horses, and with chariots, and with horsemen, and companies, and much people.

Ezekiel 26:8 He shall slay with the sword thy daughters in the field: and he shall make a fort against thee, and cast a mount against thee, and lift up the buckler against thee.

Ezekiel 26:9 And he shall set engines of war against thy walls, and with his axes he shall break down thy towers.

Ezekiel 26:10 By reason of the abundance of his horses their dust shall cover thee: thy walls shall shake at the noise of the horsemen, and of the wheels, and of the chariots, when he shall enter into thy gates, as men enter into a city wherein is made a breach.

Ezekiel 26:11 With the hoofs of his horses shall he tread down all thy streets: he shall slay thy people by the sword, and thy strong garrisons shall go down to the ground.

Ezekiel 26:12 And they shall make a spoil of thy riches, and make a prey of thy merchandise: and they shall break down thy walls, and destroy thy pleasant houses: and they shall lay thy stones and thy timber and thy dust in the midst of the water.

Ezekiel 26:13 And I will cause the noise of thy songs to cease; and the sound of thy harps shall be no more heard.

Ezekiel 26:14 And I will make thee like the top of a rock: thou shalt be a place to spread nets upon; thou shalt be built no more: for I the Lord have spoken it, saith the Lord God.

Ezekiel 26:15 Thus saith the Lord God to Tyrus; Shall not the isles shake at the sound of thy fall, when the wounded cry, when the slaughter is made in the midst of thee?

Ezekiel 26:16 Then all the princes of the sea shall come down from their thrones, and lay away their robes, and put off their broidered garments: they shall clothe themselves with trembling; they shall sit upon the ground, and shall tremble at every moment, and be astonished at thee.

Ezekiel 26:17 And they shall take up a lamentation for thee, and say to thee, How art thou destroyed, that wast inhabited of seafaring men, the renowned city, which wast strong in the sea, she and her inhabitants, which cause their terror to be on all that haunt it!

Ezekiel 26:18 Now shall the isles tremble in the day of thy fall; yea, the isles that are in the sea shall be troubled at thy departure.

Ezekiel 26:19 For thus saith the Lord God; When I shall make thee a desolate city, like the cities that are not inhabited; when I shall bring up the deep upon thee, and great waters shall cover thee;

Ezekiel 26:20 When I shall bring thee down with them that descend into the pit, with the people of old time, and shall set thee in the low parts of the earth, in places desolate of old, with them that go down to the pit, that thou be not inhabited; and I shall set glory in the land of the living;

Ezekiel 26:21 I will make thee a terror, and thou shalt be no more: though thou be sought for, yet shalt thou never be found again, saith the Lord God.
