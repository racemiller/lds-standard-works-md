# Nehemiah 7

Nehemiah 7 (summary): Provision is made to protect Jerusalem—The genealogy is given of the Jews who returned from Babylon—Priests without genealogical records are denied the priesthood.

Nehemiah 7:1 Now it came to pass, when the wall was built, and I had set up the doors, and the porters and the singers and the Levites were appointed,

Nehemiah 7:2 That I gave my brother Hanani, and Hananiah the ruler of the palace, charge over Jerusalem: for he was a faithful man, and feared God above many.

Nehemiah 7:3 And I said unto them, Let not the gates of Jerusalem be opened until the sun be hot; and while they stand by, let them shut the doors, and bar them: and appoint watches of the inhabitants of Jerusalem, every one in his watch, and every one to be over against his house.

Nehemiah 7:4 Now the city was large and great: but the people were few therein, and the houses were not builded.

Nehemiah 7:5 And my God put into mine heart to gather together the nobles, and the rulers, and the people, that they might be reckoned by genealogy. And I found a register of the genealogy of them which came up at the first, and found written therein,

Nehemiah 7:6 These are the children of the province, that went up out of the captivity, of those that had been carried away, whom Nebuchadnezzar the king of Babylon had carried away, and came again to Jerusalem and to Judah, every one unto his city;

Nehemiah 7:7 Who came with Zerubbabel, Jeshua, Nehemiah, Azariah, Raamiah, Nahamani, Mordecai, Bilshan, Mispereth, Bigvai, Nehum, Baanah. The number, I say, of the men of the people of Israel was this;

Nehemiah 7:8 The children of Parosh, two thousand an hundred seventy and two.

Nehemiah 7:9 The children of Shephatiah, three hundred seventy and two.

Nehemiah 7:10 The children of Arah, six hundred fifty and two.

Nehemiah 7:11 The children of Pahath-moab, of the children of Jeshua and Joab, two thousand and eight hundred and eighteen.

Nehemiah 7:12 The children of Elam, a thousand two hundred fifty and four.

Nehemiah 7:13 The children of Zattu, eight hundred forty and five.

Nehemiah 7:14 The children of Zaccai, seven hundred and threescore.

Nehemiah 7:15 The children of Binnui, six hundred forty and eight.

Nehemiah 7:16 The children of Bebai, six hundred twenty and eight.

Nehemiah 7:17 The children of Azgad, two thousand three hundred twenty and two.

Nehemiah 7:18 The children of Adonikam, six hundred threescore and seven.

Nehemiah 7:19 The children of Bigvai, two thousand threescore and seven.

Nehemiah 7:20 The children of Adin, six hundred fifty and five.

Nehemiah 7:21 The children of Ater of Hezekiah, ninety and eight.

Nehemiah 7:22 The children of Hashum, three hundred twenty and eight.

Nehemiah 7:23 The children of Bezai, three hundred twenty and four.

Nehemiah 7:24 The children of Hariph, an hundred and twelve.

Nehemiah 7:25 The children of Gibeon, ninety and five.

Nehemiah 7:26 The men of Beth-lehem and Netophah, an hundred fourscore and eight.

Nehemiah 7:27 The men of Anathoth, an hundred twenty and eight.

Nehemiah 7:28 The men of Beth-azmaveth, forty and two.

Nehemiah 7:29 The men of Kirjath-jearim, Chephirah, and Beeroth, seven hundred forty and three.

Nehemiah 7:30 The men of Ramah and Geba, six hundred twenty and one.

Nehemiah 7:31 The men of Michmas, an hundred and twenty and two.

Nehemiah 7:32 The men of Beth-el and Ai, an hundred twenty and three.

Nehemiah 7:33 The men of the other Nebo, fifty and two.

Nehemiah 7:34 The children of the other Elam, a thousand two hundred fifty and four.

Nehemiah 7:35 The children of Harim, three hundred and twenty.

Nehemiah 7:36 The children of Jericho, three hundred forty and five.

Nehemiah 7:37 The children of Lod, Hadid, and Ono, seven hundred twenty and one.

Nehemiah 7:38 The children of Senaah, three thousand nine hundred and thirty.

Nehemiah 7:39 The priests: the children of Jedaiah, of the house of Jeshua, nine hundred seventy and three.

Nehemiah 7:40 The children of Immer, a thousand fifty and two.

Nehemiah 7:41 The children of Pashur, a thousand two hundred forty and seven.

Nehemiah 7:42 The children of Harim, a thousand and seventeen.

Nehemiah 7:43 The Levites: the children of Jeshua, of Kadmiel, and of the children of Hodevah, seventy and four.

Nehemiah 7:44 The singers: the children of Asaph, an hundred forty and eight.

Nehemiah 7:45 The porters: the children of Shallum, the children of Ater, the children of Talmon, the children of Akkub, the children of Hatita, the children of Shobai, an hundred thirty and eight.

Nehemiah 7:46 The Nethinims: the children of Ziha, the children of Hashupha, the children of Tabbaoth,

Nehemiah 7:47 The children of Keros, the children of Sia, the children of Padon,

Nehemiah 7:48 The children of Lebana, the children of Hagaba, the children of Shalmai,

Nehemiah 7:49 The children of Hanan, the children of Giddel, the children of Gahar,

Nehemiah 7:50 The children of Reaiah, the children of Rezin, the children of Nekoda,

Nehemiah 7:51 The children of Gazzam, the children of Uzza, the children of Phaseah,

Nehemiah 7:52 The children of Besai, the children of Meunim, the children of Nephishesim,

Nehemiah 7:53 The children of Bakbuk, the children of Hakupha, the children of Harhur,

Nehemiah 7:54 The children of Bazlith, the children of Mehida, the children of Harsha,

Nehemiah 7:55 The children of Barkos, the children of Sisera, the children of Tamah,

Nehemiah 7:56 The children of Neziah, the children of Hatipha.

Nehemiah 7:57 The children of Solomon’s servants: the children of Sotai, the children of Sophereth, the children of Perida,

Nehemiah 7:58 The children of Jaala, the children of Darkon, the children of Giddel,

Nehemiah 7:59 The children of Shephatiah, the children of Hattil, the children of Pochereth of Zebaim, the children of Amon.

Nehemiah 7:60 All the Nethinims, and the children of Solomon’s servants, were three hundred ninety and two.

Nehemiah 7:61 And these were they which went up also from Tel-melah, Tel-haresha, Cherub, Addon, and Immer: but they could not shew their father’s house, nor their seed, whether they were of Israel.

Nehemiah 7:62 The children of Delaiah, the children of Tobiah, the children of Nekoda, six hundred forty and two.

Nehemiah 7:63 And of the priests: the children of Habaiah, the children of Koz, the children of Barzillai, which took one of the daughters of Barzillai the Gileadite to wife, and was called after their name.

Nehemiah 7:64 These sought their register among those that were reckoned by genealogy, but it was not found: therefore were they, as polluted, put from the priesthood.

Nehemiah 7:65 And the Tirshatha said unto them, that they should not eat of the most holy things, till there stood up a priest with Urim and Thummim.

Nehemiah 7:66 The whole congregation together was forty and two thousand three hundred and threescore,

Nehemiah 7:67 Beside their manservants and their maidservants, of whom there were seven thousand three hundred thirty and seven: and they had two hundred forty and five singing men and singing women.

Nehemiah 7:68 Their horses, seven hundred thirty and six: their mules, two hundred forty and five:

Nehemiah 7:69 Their camels, four hundred thirty and five: six thousand seven hundred and twenty asses.

Nehemiah 7:70 And some of the chief of the fathers gave unto the work. The Tirshatha gave to the treasure a thousand drams of gold, fifty basins, five hundred and thirty priests’ garments.

Nehemiah 7:71 And some of the chief of the fathers gave to the treasure of the work twenty thousand drams of gold, and two thousand and two hundred pound of silver.

Nehemiah 7:72 And that which the rest of the people gave was twenty thousand drams of gold, and two thousand pound of silver, and threescore and seven priests’ garments.

Nehemiah 7:73 So the priests, and the Levites, and the porters, and the singers, and some of the people, and the Nethinims, and all Israel, dwelt in their cities; and when the seventh month came, the children of Israel were in their cities.
