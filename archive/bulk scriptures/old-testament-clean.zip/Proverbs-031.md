# Proverbs 31

Proverbs 31 (summary): Wine and strong drink are condemned—Plead the cause of the poor and needy—A virtuous woman is more precious than rubies.

Proverbs 31:1 The words of king Lemuel, the prophecy that his mother taught him.

Proverbs 31:2 What, my son? and what, the son of my womb? and what, the son of my vows?

Proverbs 31:3 Give not thy strength unto women, nor thy ways to that which destroyeth kings.

Proverbs 31:4 It is not for kings, O Lemuel, it is not for kings to drink wine; nor for princes strong drink:

Proverbs 31:5 Lest they drink, and forget the law, and pervert the judgment of any of the afflicted.

Proverbs 31:6 Give strong drink unto him that is ready to perish, and wine unto those that be of heavy hearts.

Proverbs 31:7 Let him drink, and forget his poverty, and remember his misery no more.

Proverbs 31:8 Open thy mouth for the dumb in the cause of all such as are appointed to destruction.

Proverbs 31:9 Open thy mouth, judge righteously, and plead the cause of the poor and needy.

Proverbs 31:10 Who can find a virtuous woman? for her price is far above rubies.

Proverbs 31:11 The heart of her husband doth safely trust in her, so that he shall have no need of spoil.

Proverbs 31:12 She will do him good and not evil all the days of her life.

Proverbs 31:13 She seeketh wool, and flax, and worketh willingly with her hands.

Proverbs 31:14 She is like the merchants’ ships; she bringeth her food from afar.

Proverbs 31:15 She riseth also while it is yet night, and giveth meat to her household, and a portion to her maidens.

Proverbs 31:16 She considereth a field, and buyeth it: with the fruit of her hands she planteth a vineyard.

Proverbs 31:17 She girdeth her loins with strength, and strengtheneth her arms.

Proverbs 31:18 She perceiveth that her merchandise is good: her candle goeth not out by night.

Proverbs 31:19 She layeth her hands to the spindle, and her hands hold the distaff.

Proverbs 31:20 She stretcheth out her hand to the poor; yea, she reacheth forth her hands to the needy.

Proverbs 31:21 She is not afraid of the snow for her household: for all her household are clothed with scarlet.

Proverbs 31:22 She maketh herself coverings of tapestry; her clothing is silk and purple.

Proverbs 31:23 Her husband is known in the gates, when he sitteth among the elders of the land.

Proverbs 31:24 She maketh fine linen, and selleth it; and delivereth girdles unto the merchant.

Proverbs 31:25 Strength and honour are her clothing; and she shall rejoice in time to come.

Proverbs 31:26 She openeth her mouth with wisdom; and in her tongue is the law of kindness.

Proverbs 31:27 She looketh well to the ways of her household, and eateth not the bread of idleness.

Proverbs 31:28 Her children arise up, and call her blessed; her husband also, and he praiseth her.

Proverbs 31:29 Many daughters have done virtuously, but thou excellest them all.

Proverbs 31:30 Favour is deceitful, and beauty is vain: but a woman that feareth the Lord, she shall be praised.

Proverbs 31:31 Give her of the fruit of her hands; and let her own works praise her in the gates.
