# Psalms 93

Psalms 93 (summary): The Lord reigns—He is from everlasting—Holiness adorns the house of the Lord forever.

Psalms 93:1 The Lord reigneth, he is clothed with majesty; the Lord is clothed with strength, wherewith he hath girded himself: the world also is stablished, that it cannot be moved.

Psalms 93:2 Thy throne is established of old: thou art from everlasting.

Psalms 93:3 The floods have lifted up, O Lord, the floods have lifted up their voice; the floods lift up their waves.

Psalms 93:4 The Lord on high is mightier than the noise of many waters, yea, than the mighty waves of the sea.

Psalms 93:5 Thy testimonies are very sure: holiness becometh thine house, O Lord, for ever.
