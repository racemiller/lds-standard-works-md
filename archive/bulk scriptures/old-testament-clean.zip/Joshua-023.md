# Joshua 23

Joshua 23 (summary): Joshua exhorts Israel to be courageous, keep the commandments, love the Lord, and neither marry among nor cleave unto the remnants of the Canaanites who remain in the land—When the children of Israel serve other gods, they will be cursed and dispossessed.

Joshua 23:1 And it came to pass a long time after that the Lord had given rest unto Israel from all their enemies round about, that Joshua waxed old and stricken in age.

Joshua 23:2 And Joshua called for all Israel, and for their elders, and for their heads, and for their judges, and for their officers, and said unto them, I am old and stricken in age:

Joshua 23:3 And ye have seen all that the Lord your God hath done unto all these nations because of you; for the Lord your God is he that hath fought for you.

Joshua 23:4 Behold, I have divided unto you by lot these nations that remain, to be an inheritance for your tribes, from Jordan, with all the nations that I have cut off, even unto the great sea westward.

Joshua 23:5 And the Lord your God, he shall expel them from before you, and drive them from out of your sight; and ye shall possess their land, as the Lord your God hath promised unto you.

Joshua 23:6 Be ye therefore very courageous to keep and to do all that is written in the book of the law of Moses, that ye turn not aside therefrom to the right hand or to the left;

Joshua 23:7 That ye come not among these nations, these that remain among you; neither make mention of the name of their gods, nor cause to swear by them, neither serve them, nor bow yourselves unto them:

Joshua 23:8 But cleave unto the Lord your God, as ye have done unto this day.

Joshua 23:9 For the Lord hath driven out from before you great nations and strong: but as for you, no man hath been able to stand before you unto this day.

Joshua 23:10 One man of you shall chase a thousand: for the Lord your God, he it is that fighteth for you, as he hath promised you.

Joshua 23:11 Take good heed therefore unto yourselves, that ye love the Lord your God.

Joshua 23:12 Else if ye do in any wise go back, and cleave unto the remnant of these nations, even these that remain among you, and shall make marriages with them, and go in unto them, and they to you:

Joshua 23:13 Know for a certainty that the Lord your God will no more drive out any of these nations from before you; but they shall be snares and traps unto you, and scourges in your sides, and thorns in your eyes, until ye perish from off this good land which the Lord your God hath given you.

Joshua 23:14 And, behold, this day I am going the way of all the earth: and ye know in all your hearts and in all your souls, that not one thing hath failed of all the good things which the Lord your God spake concerning you; all are come to pass unto you, and not one thing hath failed thereof.

Joshua 23:15 Therefore it shall come to pass, that as all good things are come upon you, which the Lord your God promised you; so shall the Lord bring upon you all evil things, until he have destroyed you from off this good land which the Lord your God hath given you.

Joshua 23:16 When ye have transgressed the covenant of the Lord your God, which he commanded you, and have gone and served other gods, and bowed yourselves to them; then shall the anger of the Lord be kindled against you, and ye shall perish quickly from off the good land which he hath given unto you.
