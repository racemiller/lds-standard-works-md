# Numbers 26

Numbers 26 (summary): Moses and Eleazar count the Israelites on the plains of Moab near Jericho—The males twenty years and older, excluding Levites, total 601,730—Only Caleb and Joshua remain from those numbered at Sinai.

Numbers 26:1 And it came to pass after the plague, that the Lord spake unto Moses and unto Eleazar the son of Aaron the priest, saying,

Numbers 26:2 Take the sum of all the congregation of the children of Israel, from twenty years old and upward, throughout their fathers’ house, all that are able to go to war in Israel.

Numbers 26:3 And Moses and Eleazar the priest spake with them in the plains of Moab by Jordan near Jericho, saying,

Numbers 26:4 Take the sum of the people, from twenty years old and upward; as the Lord commanded Moses and the children of Israel, which went forth out of the land of Egypt.

Numbers 26:5 Reuben, the eldest son of Israel: the children of Reuben; Hanoch, of whom cometh the family of the Hanochites: of Pallu, the family of the Palluites:

Numbers 26:6 Of Hezron, the family of the Hezronites: of Carmi, the family of the Carmites.

Numbers 26:7 These are the families of the Reubenites: and they that were numbered of them were forty and three thousand and seven hundred and thirty.

Numbers 26:8 And the sons of Pallu; Eliab.

Numbers 26:9 And the sons of Eliab; Nemuel, and Dathan, and Abiram. This is that Dathan and Abiram, which were famous in the congregation, who strove against Moses and against Aaron in the company of Korah, when they strove against the Lord:

Numbers 26:10 And the earth opened her mouth, and swallowed them up together with Korah, when that company died, what time the fire devoured two hundred and fifty men: and they became a sign.

Numbers 26:11 Notwithstanding the children of Korah died not.

Numbers 26:12 The sons of Simeon after their families: of Nemuel, the family of the Nemuelites: of Jamin, the family of the Jaminites: of Jachin, the family of the Jachinites:

Numbers 26:13 Of Zerah, the family of the Zarhites: of Shaul, the family of the Shaulites.

Numbers 26:14 These are the families of the Simeonites, twenty and two thousand and two hundred.

Numbers 26:15 The children of Gad after their families: of Zephon, the family of the Zephonites: of Haggi, the family of the Haggites: of Shuni, the family of the Shunites:

Numbers 26:16 Of Ozni, the family of the Oznites: of Eri, the family of the Erites:

Numbers 26:17 Of Arod, the family of the Arodites: of Areli, the family of the Arelites.

Numbers 26:18 These are the families of the children of Gad according to those that were numbered of them, forty thousand and five hundred.

Numbers 26:19 The sons of Judah were Er and Onan: and Er and Onan died in the land of Canaan.

Numbers 26:20 And the sons of Judah after their families were; of Shelah, the family of the Shelanites: of Pharez, the family of the Pharzites: of Zerah, the family of the Zarhites.

Numbers 26:21 And the sons of Pharez were; of Hezron, the family of the Hezronites: of Hamul, the family of the Hamulites.

Numbers 26:22 These are the families of Judah according to those that were numbered of them, threescore and sixteen thousand and five hundred.

Numbers 26:23 Of the sons of Issachar after their families: of Tola, the family of the Tolaites: of Pua, the family of the Punites:

Numbers 26:24 Of Jashub, the family of the Jashubites: of Shimron, the family of the Shimronites.

Numbers 26:25 These are the families of Issachar according to those that were numbered of them, threescore and four thousand and three hundred.

Numbers 26:26 Of the sons of Zebulun after their families: of Sered, the family of the Sardites: of Elon, the family of the Elonites: of Jahleel, the family of the Jahleelites.

Numbers 26:27 These are the families of the Zebulunites according to those that were numbered of them, threescore thousand and five hundred.

Numbers 26:28 The sons of Joseph after their families were Manasseh and Ephraim.

Numbers 26:29 Of the sons of Manasseh: of Machir, the family of the Machirites: and Machir begat Gilead: of Gilead come the family of the Gileadites.

Numbers 26:30 These are the sons of Gilead: of Jeezer, the family of the Jeezerites: of Helek, the family of the Helekites:

Numbers 26:31 And of Asriel, the family of the Asrielites: and of Shechem, the family of the Shechemites:

Numbers 26:32 And of Shemida, the family of the Shemidaites: and of Hepher, the family of the Hepherites.

Numbers 26:33 And Zelophehad the son of Hepher had no sons, but daughters: and the names of the daughters of Zelophehad were Mahlah, and Noah, Hoglah, Milcah, and Tirzah.

Numbers 26:34 These are the families of Manasseh, and those that were numbered of them, fifty and two thousand and seven hundred.

Numbers 26:35 These are the sons of Ephraim after their families: of Shuthelah, the family of the Shuthalhites: of Becher, the family of the Bachrites: of Tahan, the family of the Tahanites.

Numbers 26:36 And these are the sons of Shuthelah: of Eran, the family of the Eranites.

Numbers 26:37 These are the families of the sons of Ephraim according to those that were numbered of them, thirty and two thousand and five hundred. These are the sons of Joseph after their families.

Numbers 26:38 The sons of Benjamin after their families: of Bela, the family of the Belaites: of Ashbel, the family of the Ashbelites: of Ahiram, the family of the Ahiramites:

Numbers 26:39 Of Shupham, the family of the Shuphamites: of Hupham, the family of the Huphamites.

Numbers 26:40 And the sons of Bela were Ard and Naaman: of Ard, the family of the Ardites: and of Naaman, the family of the Naamites.

Numbers 26:41 These are the sons of Benjamin after their families: and they that were numbered of them were forty and five thousand and six hundred.

Numbers 26:42 These are the sons of Dan after their families: of Shuham, the family of the Shuhamites. These are the families of Dan after their families.

Numbers 26:43 All the families of the Shuhamites, according to those that were numbered of them, were threescore and four thousand and four hundred.

Numbers 26:44 Of the children of Asher after their families: of Jimna, the family of the Jimnites: of Jesui, the family of the Jesuites: of Beriah, the family of the Beriites.

Numbers 26:45 Of the sons of Beriah: of Heber, the family of the Heberites: of Malchiel, the family of the Malchielites.

Numbers 26:46 And the name of the daughter of Asher was Sarah.

Numbers 26:47 These are the families of the sons of Asher according to those that were numbered of them; who were fifty and three thousand and four hundred.

Numbers 26:48 Of the sons of Naphtali after their families: of Jahzeel, the family of the Jahzeelites: of Guni, the family of the Gunites:

Numbers 26:49 Of Jezer, the family of the Jezerites: of Shillem, the family of the Shillemites.

Numbers 26:50 These are the families of Naphtali according to their families: and they that were numbered of them were forty and five thousand and four hundred.

Numbers 26:51 These were the numbered of the children of Israel, six hundred thousand and a thousand seven hundred and thirty.

Numbers 26:52 And the Lord spake unto Moses, saying,

Numbers 26:53 Unto these the land shall be divided for an inheritance according to the number of names.

Numbers 26:54 To many thou shalt give the more inheritance, and to few thou shalt give the less inheritance: to every one shall his inheritance be given according to those that were numbered of him.

Numbers 26:55 Notwithstanding the land shall be divided by lot: according to the names of the tribes of their fathers they shall inherit.

Numbers 26:56 According to the lot shall the possession thereof be divided between many and few.

Numbers 26:57 And these are they that were numbered of the Levites after their families: of Gershon, the family of the Gershonites: of Kohath, the family of the Kohathites: of Merari, the family of the Merarites.

Numbers 26:58 These are the families of the Levites: the family of the Libnites, the family of the Hebronites, the family of the Mahlites, the family of the Mushites, the family of the Korathites. And Kohath begat Amram.

Numbers 26:59 And the name of Amram’s wife was Jochebed, the daughter of Levi, whom her mother bare to Levi in Egypt: and she bare unto Amram Aaron and Moses, and Miriam their sister.

Numbers 26:60 And unto Aaron was born Nadab, and Abihu, Eleazar, and Ithamar.

Numbers 26:61 And Nadab and Abihu died, when they offered strange fire before the Lord.

Numbers 26:62 And those that were numbered of them were twenty and three thousand, all males from a month old and upward: for they were not numbered among the children of Israel, because there was no inheritance given them among the children of Israel.

Numbers 26:63 These are they that were numbered by Moses and Eleazar the priest, who numbered the children of Israel in the plains of Moab by Jordan near Jericho.

Numbers 26:64 But among these there was not a man of them whom Moses and Aaron the priest numbered, when they numbered the children of Israel in the wilderness of Sinai.

Numbers 26:65 For the Lord had said of them, They shall surely die in the wilderness. And there was not left a man of them, save Caleb the son of Jephunneh, and Joshua the son of Nun.
