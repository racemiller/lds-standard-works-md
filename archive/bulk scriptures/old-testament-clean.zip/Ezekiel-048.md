# Ezekiel 48

Ezekiel 48 (summary): The portions of land for the tribes are named—The gates of the city bear the names of the tribes—The name of the city will be The Lord Is There.

Ezekiel 48:1 Now these are the names of the tribes. From the north end to the coast of the way of Hethlon, as one goeth to Hamath, Hazar-enan, the border of Damascus northward, to the coast of Hamath; for these are his sides east and west; a portion for Dan.

Ezekiel 48:2 And by the border of Dan, from the east side unto the west side, a portion for Asher.

Ezekiel 48:3 And by the border of Asher, from the east side even unto the west side, a portion for Naphtali.

Ezekiel 48:4 And by the border of Naphtali, from the east side unto the west side, a portion for Manasseh.

Ezekiel 48:5 And by the border of Manasseh, from the east side unto the west side, a portion for Ephraim.

Ezekiel 48:6 And by the border of Ephraim, from the east side even unto the west side, a portion for Reuben.

Ezekiel 48:7 And by the border of Reuben, from the east side unto the west side, a portion for Judah.

Ezekiel 48:8 And by the border of Judah, from the east side unto the west side, shall be the offering which ye shall offer of five and twenty thousand reeds in breadth, and in length as one of the other parts, from the east side unto the west side: and the sanctuary shall be in the midst of it.

Ezekiel 48:9 The oblation that ye shall offer unto the Lord shall be of five and twenty thousand in length, and of ten thousand in breadth.

Ezekiel 48:10 And for them, even for the priests, shall be this holy oblation; toward the north five and twenty thousand in length, and toward the west ten thousand in breadth, and toward the east ten thousand in breadth, and toward the south five and twenty thousand in length: and the sanctuary of the Lord shall be in the midst thereof.

Ezekiel 48:11 It shall be for the priests that are sanctified of the sons of Zadok; which have kept my charge, which went not astray when the children of Israel went astray, as the Levites went astray.

Ezekiel 48:12 And this oblation of the land that is offered shall be unto them a thing most holy by the border of the Levites.

Ezekiel 48:13 And over against the border of the priests the Levites shall have five and twenty thousand in length, and ten thousand in breadth: all the length shall be five and twenty thousand, and the breadth ten thousand.

Ezekiel 48:14 And they shall not sell of it, neither exchange, nor alienate the firstfruits of the land: for it is holy unto the Lord.

Ezekiel 48:15 And the five thousand, that are left in the breadth over against the five and twenty thousand, shall be a profane place for the city, for dwelling, and for suburbs: and the city shall be in the midst thereof.

Ezekiel 48:16 And these shall be the measures thereof; the north side four thousand and five hundred, and the south side four thousand and five hundred, and on the east side four thousand and five hundred, and the west side four thousand and five hundred.

Ezekiel 48:17 And the suburbs of the city shall be toward the north two hundred and fifty, and toward the south two hundred and fifty, and toward the east two hundred and fifty, and toward the west two hundred and fifty.

Ezekiel 48:18 And the residue in length over against the oblation of the holy portion shall be ten thousand eastward, and ten thousand westward: and it shall be over against the oblation of the holy portion; and the increase thereof shall be for food unto them that serve the city.

Ezekiel 48:19 And they that serve the city shall serve it out of all the tribes of Israel.

Ezekiel 48:20 All the oblation shall be five and twenty thousand by five and twenty thousand: ye shall offer the holy oblation foursquare, with the possession of the city.

Ezekiel 48:21 And the residue shall be for the prince, on the one side and on the other of the holy oblation, and of the possession of the city, over against the five and twenty thousand of the oblation toward the east border, and westward over against the five and twenty thousand toward the west border, over against the portions for the prince: and it shall be the holy oblation; and the sanctuary of the house shall be in the midst thereof.

Ezekiel 48:22 Moreover from the possession of the Levites, and from the possession of the city, being in the midst of that which is the prince’s, between the border of Judah and the border of Benjamin, shall be for the prince.

Ezekiel 48:23 As for the rest of the tribes, from the east side unto the west side, Benjamin shall have a portion.

Ezekiel 48:24 And by the border of Benjamin, from the east side unto the west side, Simeon shall have a portion.

Ezekiel 48:25 And by the border of Simeon, from the east side unto the west side, Issachar a portion.

Ezekiel 48:26 And by the border of Issachar, from the east side unto the west side, Zebulun a portion.

Ezekiel 48:27 And by the border of Zebulun, from the east side unto the west side, Gad a portion.

Ezekiel 48:28 And by the border of Gad, at the south side southward, the border shall be even from Tamar unto the waters of strife in Kadesh, and to the river toward the great sea.

Ezekiel 48:29 This is the land which ye shall divide by lot unto the tribes of Israel for inheritance, and these are their portions, saith the Lord God.

Ezekiel 48:30 And these are the goings out of the city on the north side, four thousand and five hundred measures.

Ezekiel 48:31 And the gates of the city shall be after the names of the tribes of Israel: three gates northward; one gate of Reuben, one gate of Judah, one gate of Levi.

Ezekiel 48:32 And at the east side four thousand and five hundred: and three gates; and one gate of Joseph, one gate of Benjamin, one gate of Dan.

Ezekiel 48:33 And at the south side four thousand and five hundred measures: and three gates; one gate of Simeon, one gate of Issachar, one gate of Zebulun.

Ezekiel 48:34 At the west side four thousand and five hundred, with their three gates; one gate of Gad, one gate of Asher, one gate of Naphtali.

Ezekiel 48:35 It was round about eighteen thousand measures: and the name of the city from that day shall be, The Lord is there.
