# Amos 9

Amos 9 (summary): Israel will be sifted among all nations—In the last days, the people of Israel will be gathered again into their own land, and it will become productive.

Amos 9:1 I saw the Lord standing upon the altar: and he said, Smite the lintel of the door, that the posts may shake: and cut them in the head, all of them; and I will slay the last of them with the sword: he that fleeth of them shall not flee away, and he that escapeth of them shall not be delivered.

Amos 9:2 Though they dig into hell, thence shall mine hand take them; though they climb up to heaven, thence will I bring them down:

Amos 9:3 And though they hide themselves in the top of Carmel, I will search and take them out thence; and though they be hid from my sight in the bottom of the sea, thence will I command the serpent, and he shall bite them:

Amos 9:4 And though they go into captivity before their enemies, thence will I command the sword, and it shall slay them: and I will set mine eyes upon them for evil, and not for good.

Amos 9:5 And the Lord God of hosts is he that toucheth the land, and it shall melt, and all that dwell therein shall mourn: and it shall rise up wholly like a flood; and shall be drowned, as by the flood of Egypt.

Amos 9:6 It is he that buildeth his stories in the heaven, and hath founded his troop in the earth; he that calleth for the waters of the sea, and poureth them out upon the face of the earth: The Lord is his name.

Amos 9:7 Are ye not as children of the Ethiopians unto me, O children of Israel? saith the Lord. Have not I brought up Israel out of the land of Egypt? and the Philistines from Caphtor, and the Syrians from Kir?

Amos 9:8 Behold, the eyes of the Lord God are upon the sinful kingdom, and I will destroy it from off the face of the earth; saving that I will not utterly destroy the house of Jacob, saith the Lord.

Amos 9:9 For, lo, I will command, and I will sift the house of Israel among all nations, like as corn is sifted in a sieve, yet shall not the least grain fall upon the earth.

Amos 9:10 All the sinners of my people shall die by the sword, which say, The evil shall not overtake nor prevent us.

Amos 9:11 In that day will I raise up the tabernacle of David that is fallen, and close up the breaches thereof; and I will raise up his ruins, and I will build it as in the days of old:

Amos 9:12 That they may possess the remnant of Edom, and of all the heathen, which are called by my name, saith the Lord that doeth this.

Amos 9:13 Behold, the days come, saith the Lord, that the plowman shall overtake the reaper, and the treader of grapes him that soweth seed; and the mountains shall drop sweet wine, and all the hills shall melt.

Amos 9:14 And I will bring again the captivity of my people of Israel, and they shall build the waste cities, and inhabit them; and they shall plant vineyards, and drink the wine thereof; they shall also make gardens, and eat the fruit of them.

Amos 9:15 And I will plant them upon their land, and they shall no more be pulled up out of their land which I have given them, saith the Lord thy God.
