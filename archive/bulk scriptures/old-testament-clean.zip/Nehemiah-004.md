# Nehemiah 4

Nehemiah 4 (summary): The Jews’ enemies seek to prevent them from rebuilding the walls of Jerusalem—Nehemiah arms the laborers and keeps the work progressing.

Nehemiah 4:1 But it came to pass, that when Sanballat heard that we builded the wall, he was wroth, and took great indignation, and mocked the Jews.

Nehemiah 4:2 And he spake before his brethren and the army of Samaria, and said, What do these feeble Jews? will they fortify themselves? will they sacrifice? will they make an end in a day? will they revive the stones out of the heaps of the rubbish which are burned?

Nehemiah 4:3 Now Tobiah the Ammonite was by him, and he said, Even that which they build, if a fox go up, he shall even break down their stone wall.

Nehemiah 4:4 Hear, O our God; for we are despised: and turn their reproach upon their own head, and give them for a prey in the land of captivity:

Nehemiah 4:5 And cover not their iniquity, and let not their sin be blotted out from before thee: for they have provoked thee to anger before the builders.

Nehemiah 4:6 So built we the wall; and all the wall was joined together unto the half thereof: for the people had a mind to work.

Nehemiah 4:7 But it came to pass, that when Sanballat, and Tobiah, and the Arabians, and the Ammonites, and the Ashdodites, heard that the walls of Jerusalem were made up, and that the breaches began to be stopped, then they were very wroth,

Nehemiah 4:8 And conspired all of them together to come and to fight against Jerusalem, and to hinder it.

Nehemiah 4:9 Nevertheless we made our prayer unto our God, and set a watch against them day and night, because of them.

Nehemiah 4:10 And Judah said, The strength of the bearers of burdens is decayed, and there is much rubbish; so that we are not able to build the wall.

Nehemiah 4:11 And our adversaries said, They shall not know, neither see, till we come in the midst among them, and slay them, and cause the work to cease.

Nehemiah 4:12 And it came to pass, that when the Jews which dwelt by them came, they said unto us ten times, From all places whence ye shall return unto us they will be upon you.

Nehemiah 4:13 Therefore set I in the lower places behind the wall, and on the higher places, I even set the people after their families with their swords, their spears, and their bows.

Nehemiah 4:14 And I looked, and rose up, and said unto the nobles, and to the rulers, and to the rest of the people, Be not ye afraid of them: remember the Lord, which is great and terrible, and fight for your brethren, your sons, and your daughters, your wives, and your houses.

Nehemiah 4:15 And it came to pass, when our enemies heard that it was known unto us, and God had brought their counsel to nought, that we returned all of us to the wall, every one unto his work.

Nehemiah 4:16 And it came to pass from that time forth, that the half of my servants wrought in the work, and the other half of them held both the spears, the shields, and the bows, and the habergeons; and the rulers were behind all the house of Judah.

Nehemiah 4:17 They which builded on the wall, and they that bare burdens, with those that laded, every one with one of his hands wrought in the work, and with the other hand held a weapon.

Nehemiah 4:18 For the builders, every one had his sword girded by his side, and so builded. And he that sounded the trumpet was by me.

Nehemiah 4:19 And I said unto the nobles, and to the rulers, and to the rest of the people, The work is great and large, and we are separated upon the wall, one far from another.

Nehemiah 4:20 In what place therefore ye hear the sound of the trumpet, resort ye thither unto us: our God shall fight for us.

Nehemiah 4:21 So we laboured in the work: and half of them held the spears from the rising of the morning till the stars appeared.

Nehemiah 4:22 Likewise at the same time said I unto the people, Let every one with his servant lodge within Jerusalem, that in the night they may be a guard to us, and labour on the day.

Nehemiah 4:23 So neither I, nor my brethren, nor my servants, nor the men of the guard which followed me, none of us put off our clothes, saving that every one put them off for washing.
