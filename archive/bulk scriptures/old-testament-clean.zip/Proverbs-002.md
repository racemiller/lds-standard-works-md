# Proverbs 2

Proverbs 2 (summary): The Lord gives wisdom, knowledge, and understanding—Walk in the way of good men.

Proverbs 2:1 My son, if thou wilt receive my words, and hide my commandments with thee;

Proverbs 2:2 So that thou incline thine ear unto wisdom, and apply thine heart to understanding;

Proverbs 2:3 Yea, if thou criest after knowledge, and liftest up thy voice for understanding;

Proverbs 2:4 If thou seekest her as silver, and searchest for her as for hid treasures;

Proverbs 2:5 Then shalt thou understand the fear of the Lord, and find the knowledge of God.

Proverbs 2:6 For the Lord giveth wisdom: out of his mouth cometh knowledge and understanding.

Proverbs 2:7 He layeth up sound wisdom for the righteous: he is a buckler to them that walk uprightly.

Proverbs 2:8 He keepeth the paths of judgment, and preserveth the way of his saints.

Proverbs 2:9 Then shalt thou understand righteousness, and judgment, and equity; yea, every good path.

Proverbs 2:10 When wisdom entereth into thine heart, and knowledge is pleasant unto thy soul;

Proverbs 2:11 Discretion shall preserve thee, understanding shall keep thee:

Proverbs 2:12 To deliver thee from the way of the evil man, from the man that speaketh froward things;

Proverbs 2:13 Who leave the paths of uprightness, to walk in the ways of darkness;

Proverbs 2:14 Who rejoice to do evil, and delight in the frowardness of the wicked;

Proverbs 2:15 Whose ways are crooked, and they froward in their paths:

Proverbs 2:16 To deliver thee from the strange woman, even from the stranger which flattereth with her words;

Proverbs 2:17 Which forsaketh the guide of her youth, and forgetteth the covenant of her God.

Proverbs 2:18 For her house inclineth unto death, and her paths unto the dead.

Proverbs 2:19 None that go unto her return again, neither take they hold of the paths of life.

Proverbs 2:20 That thou mayest walk in the way of good men, and keep the paths of the righteous.

Proverbs 2:21 For the upright shall dwell in the land, and the perfect shall remain in it.

Proverbs 2:22 But the wicked shall be cut off from the earth, and the transgressors shall be rooted out of it.
