# Isaiah 32

Isaiah 32 (summary): A king (the Messiah) will reign in righteousness—The land of Israel will be a wilderness until the day of restoration and gathering.

Isaiah 32:1 Behold, a king shall reign in righteousness, and princes shall rule in judgment.

Isaiah 32:2 And a man shall be as an hiding place from the wind, and a covert from the tempest; as rivers of water in a dry place, as the shadow of a great rock in a weary land.

Isaiah 32:3 And the eyes of them that see shall not be dim, and the ears of them that hear shall hearken.

Isaiah 32:4 The heart also of the rash shall understand knowledge, and the tongue of the stammerers shall be ready to speak plainly.

Isaiah 32:5 The vile person shall be no more called liberal, nor the churl said to be bountiful.

Isaiah 32:6 For the vile person will speak villany, and his heart will work iniquity, to practise hypocrisy, and to utter error against the Lord, to make empty the soul of the hungry, and he will cause the drink of the thirsty to fail.

Isaiah 32:7 The instruments also of the churl are evil: he deviseth wicked devices to destroy the poor with lying words, even when the needy speaketh right.

Isaiah 32:8 But the liberal deviseth liberal things; and by liberal things shall he stand.

Isaiah 32:9 Rise up, ye women that are at ease; hear my voice, ye careless daughters; give ear unto my speech.

Isaiah 32:10 Many days and years shall ye be troubled, ye careless women: for the vintage shall fail, the gathering shall not come.

Isaiah 32:11 Tremble, ye women that are at ease; be troubled, ye careless ones: strip you, and make you bare, and gird sackcloth upon your loins.

Isaiah 32:12 They shall lament for the teats, for the pleasant fields, for the fruitful vine.

Isaiah 32:13 Upon the land of my people shall come up thorns and briers; yea, upon all the houses of joy in the joyous city:

Isaiah 32:14 Because the palaces shall be forsaken; the multitude of the city shall be left; the forts and towers shall be for dens for ever, a joy of wild asses, a pasture of flocks;

Isaiah 32:15 Until the spirit be poured upon us from on high, and the wilderness be a fruitful field, and the fruitful field be counted for a forest.

Isaiah 32:16 Then judgment shall dwell in the wilderness, and righteousness remain in the fruitful field.

Isaiah 32:17 And the work of righteousness shall be peace; and the effect of righteousness quietness and assurance for ever.

Isaiah 32:18 And my people shall dwell in a peaceable habitation, and in sure dwellings, and in quiet resting places;

Isaiah 32:19 When it shall hail, coming down on the forest; and the city shall be low in a low place.

Isaiah 32:20 Blessed are ye that sow beside all waters, that send forth thither the feet of the ox and the ass.
