# Proverbs 27

Proverbs 27 (summary): Let another man praise you—A prudent man foresees evil—Hell and destruction are never full.

Proverbs 27:1 Boast not thyself of to morrow; for thou knowest not what a day may bring forth.

Proverbs 27:2 Let another man praise thee, and not thine own mouth; a stranger, and not thine own lips.

Proverbs 27:3 A stone is heavy, and the sand weighty; but a fool’s wrath is heavier than them both.

Proverbs 27:4 Wrath is cruel, and anger is outrageous; but who is able to stand before envy?

Proverbs 27:5 Open rebuke is better than secret love.

Proverbs 27:6 Faithful are the wounds of a friend; but the kisses of an enemy are deceitful.

Proverbs 27:7 The full soul loatheth an honeycomb; but to the hungry soul every bitter thing is sweet.

Proverbs 27:8 As a bird that wandereth from her nest, so is a man that wandereth from his place.

Proverbs 27:9 Ointment and perfume rejoice the heart: so doth the sweetness of a man’s friend by hearty counsel.

Proverbs 27:10 Thine own friend, and thy father’s friend, forsake not; neither go into thy brother’s house in the day of thy calamity: for better is a neighbour that is near than a brother far off.

Proverbs 27:11 My son, be wise, and make my heart glad, that I may answer him that reproacheth me.

Proverbs 27:12 A prudent man foreseeth the evil, and hideth himself; but the simple pass on, and are punished.

Proverbs 27:13 Take his garment that is surety for a stranger, and take a pledge of him for a strange woman.

Proverbs 27:14 He that blesseth his friend with a loud voice, rising early in the morning, it shall be counted a curse to him.

Proverbs 27:15 A continual dropping in a very rainy day and a contentious woman are alike.

Proverbs 27:16 Whosoever hideth her hideth the wind, and the ointment of his right hand, which bewrayeth itself.

Proverbs 27:17 Iron sharpeneth iron; so a man sharpeneth the countenance of his friend.

Proverbs 27:18 Whoso keepeth the fig tree shall eat the fruit thereof: so he that waiteth on his master shall be honoured.

Proverbs 27:19 As in water face answereth to face, so the heart of man to man.

Proverbs 27:20 Hell and destruction are never full; so the eyes of man are never satisfied.

Proverbs 27:21 As the fining pot for silver, and the furnace for gold; so is a man to his praise.

Proverbs 27:22 Though thou shouldest bray a fool in a mortar among wheat with a pestle, yet will not his foolishness depart from him.

Proverbs 27:23 Be thou diligent to know the state of thy flocks, and look well to thy herds.

Proverbs 27:24 For riches are not for ever: and doth the crown endure to every generation?

Proverbs 27:25 The hay appeareth, and the tender grass sheweth itself, and herbs of the mountains are gathered.

Proverbs 27:26 The lambs are for thy clothing, and the goats are the price of the field.

Proverbs 27:27 And thou shalt have goats’ milk enough for thy food, for the food of thy household, and for the maintenance for thy maidens.
