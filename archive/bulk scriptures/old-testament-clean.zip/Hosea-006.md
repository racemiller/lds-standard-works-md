# Hosea 6

Hosea 6 (summary): Hosea calls Israel to return and serve the Lord—The mercy and knowledge of God are more important than ritualistic sacrifices.

Hosea 6:1 Come, and let us return unto the Lord: for he hath torn, and he will heal us; he hath smitten, and he will bind us up.

Hosea 6:2 After two days will he revive us: in the third day he will raise us up, and we shall live in his sight.

Hosea 6:3 Then shall we know, if we follow on to know the Lord: his going forth is prepared as the morning; and he shall come unto us as the rain, as the latter and former rain unto the earth.

Hosea 6:4 O Ephraim, what shall I do unto thee? O Judah, what shall I do unto thee? for your goodness is as a morning cloud, and as the early dew it goeth away.

Hosea 6:5 Therefore have I hewed them by the prophets; I have slain them by the words of my mouth: and thy judgments are as the light that goeth forth.

Hosea 6:6 For I desired mercy, and not sacrifice; and the knowledge of God more than burnt offerings.

Hosea 6:7 But they like men have transgressed the covenant: there have they dealt treacherously against me.

Hosea 6:8 Gilead is a city of them that work iniquity, and is polluted with blood.

Hosea 6:9 And as troops of robbers wait for a man, so the company of priests murder in the way by consent: for they commit lewdness.

Hosea 6:10 I have seen an horrible thing in the house of Israel: there is the whoredom of Ephraim, Israel is defiled.

Hosea 6:11 Also, O Judah, he hath set an harvest for thee, when I returned the captivity of my people.
