# Psalms 82

Psalms 82 (summary): Thus says the Lord, Ye are gods and children of the Most High.

Psalms 82:1 God standeth in the congregation of the mighty; he judgeth among the gods.

Psalms 82:2 How long will ye judge unjustly, and accept the persons of the wicked? Selah.

Psalms 82:3 Defend the poor and fatherless: do justice to the afflicted and needy.

Psalms 82:4 Deliver the poor and needy: rid them out of the hand of the wicked.

Psalms 82:5 They know not, neither will they understand; they walk on in darkness: all the foundations of the earth are out of course.

Psalms 82:6 I have said, Ye are gods; and all of you are children of the most High.

Psalms 82:7 But ye shall die like men, and fall like one of the princes.

Psalms 82:8 Arise, O God, judge the earth: for thou shalt inherit all nations.
