# Joshua 16

Joshua 16 (summary): The children of Joseph (Ephraim and Manasseh) receive their inheritances—Some Canaanites continue to dwell among the Ephraimites.

Joshua 16:1 And the lot of the children of Joseph fell from Jordan by Jericho, unto the water of Jericho on the east, to the wilderness that goeth up from Jericho throughout mount Beth-el,

Joshua 16:2 And goeth out from Beth-el to Luz, and passeth along unto the borders of Archi to Ataroth,

Joshua 16:3 And goeth down westward to the coast of Japhleti, unto the coast of Beth-horon the nether, and to Gezer: and the goings out thereof are at the sea.

Joshua 16:4 So the children of Joseph, Manasseh and Ephraim, took their inheritance.

Joshua 16:5 And the border of the children of Ephraim according to their families was thus: even the border of their inheritance on the east side was Ataroth-addar, unto Beth-horon the upper;

Joshua 16:6 And the border went out toward the sea to Michmethah on the north side; and the border went about eastward unto Taanath-shiloh, and passed by it on the east to Janohah;

Joshua 16:7 And it went down from Janohah to Ataroth, and to Naarath, and came to Jericho, and went out at Jordan.

Joshua 16:8 The border went out from Tappuah westward unto the river Kanah; and the goings out thereof were at the sea. This is the inheritance of the tribe of the children of Ephraim by their families.

Joshua 16:9 And the separate cities for the children of Ephraim were among the inheritance of the children of Manasseh, all the cities with their villages.

Joshua 16:10 And they drave not out the Canaanites that dwelt in Gezer: but the Canaanites dwell among the Ephraimites unto this day, and serve under tribute.
