# Jeremiah 29

Jeremiah 29 (summary): Jeremiah tells the Jews in Babylon to prepare for seventy years of captivity—Those remaining in Jerusalem will yet be scattered—Shemaiah prophesies falsely and is cursed.

Jeremiah 29:1 Now these are the words of the letter that Jeremiah the prophet sent from Jerusalem unto the residue of the elders which were carried away captives, and to the priests, and to the prophets, and to all the people whom Nebuchadnezzar had carried away captive from Jerusalem to Babylon;

Jeremiah 29:2 (After that Jeconiah the king, and the queen, and the eunuchs, the princes of Judah and Jerusalem, and the carpenters, and the smiths, were departed from Jerusalem;)

Jeremiah 29:3 By the hand of Elasah the son of Shaphan, and Gemariah the son of Hilkiah, (whom Zedekiah king of Judah sent unto Babylon to Nebuchadnezzar king of Babylon) saying,

Jeremiah 29:4 Thus saith the Lord of hosts, the God of Israel, unto all that are carried away captives, whom I have caused to be carried away from Jerusalem unto Babylon;

Jeremiah 29:5 Build ye houses, and dwell in them; and plant gardens, and eat the fruit of them;

Jeremiah 29:6 Take ye wives, and beget sons and daughters; and take wives for your sons, and give your daughters to husbands, that they may bear sons and daughters; that ye may be increased there, and not diminished.

Jeremiah 29:7 And seek the peace of the city whither I have caused you to be carried away captives, and pray unto the Lord for it: for in the peace thereof shall ye have peace.

Jeremiah 29:8 For thus saith the Lord of hosts, the God of Israel; Let not your prophets and your diviners, that be in the midst of you, deceive you, neither hearken to your dreams which ye cause to be dreamed.

Jeremiah 29:9 For they prophesy falsely unto you in my name: I have not sent them, saith the Lord.

Jeremiah 29:10 For thus saith the Lord, That after seventy years be accomplished at Babylon I will visit you, and perform my good word toward you, in causing you to return to this place.

Jeremiah 29:11 For I know the thoughts that I think toward you, saith the Lord, thoughts of peace, and not of evil, to give you an expected end.

Jeremiah 29:12 Then shall ye call upon me, and ye shall go and pray unto me, and I will hearken unto you.

Jeremiah 29:13 And ye shall seek me, and find me, when ye shall search for me with all your heart.

Jeremiah 29:14 And I will be found of you, saith the Lord: and I will turn away your captivity, and I will gather you from all the nations, and from all the places whither I have driven you, saith the Lord; and I will bring you again into the place whence I caused you to be carried away captive.

Jeremiah 29:15 Because ye have said, The Lord hath raised us up prophets in Babylon;

Jeremiah 29:16 Know that thus saith the Lord of the king that sitteth upon the throne of David, and of all the people that dwelleth in this city, and of your brethren that are not gone forth with you into captivity;

Jeremiah 29:17 Thus saith the Lord of hosts; Behold, I will send upon them the sword, the famine, and the pestilence, and will make them like vile figs, that cannot be eaten, they are so evil.

Jeremiah 29:18 And I will persecute them with the sword, with the famine, and with the pestilence, and will deliver them to be removed to all the kingdoms of the earth, to be a curse, and an astonishment, and an hissing, and a reproach, among all the nations whither I have driven them:

Jeremiah 29:19 Because they have not hearkened to my words, saith the Lord, which I sent unto them by my servants the prophets, rising up early and sending them; but ye would not hear, saith the Lord.

Jeremiah 29:20 Hear ye therefore the word of the Lord, all ye of the captivity, whom I have sent from Jerusalem to Babylon:

Jeremiah 29:21 Thus saith the Lord of hosts, the God of Israel, of Ahab the son of Kolaiah, and of Zedekiah the son of Maaseiah, which prophesy a lie unto you in my name; Behold, I will deliver them into the hand of Nebuchadrezzar king of Babylon; and he shall slay them before your eyes;

Jeremiah 29:22 And of them shall be taken up a curse by all the captivity of Judah which are in Babylon, saying, The Lord make thee like Zedekiah and like Ahab, whom the king of Babylon roasted in the fire;

Jeremiah 29:23 Because they have committed villany in Israel, and have committed adultery with their neighbours’ wives, and have spoken lying words in my name, which I have not commanded them; even I know, and am a witness, saith the Lord.

Jeremiah 29:24 Thus shalt thou also speak to Shemaiah the Nehelamite, saying,

Jeremiah 29:25 Thus speaketh the Lord of hosts, the God of Israel, saying, Because thou hast sent letters in thy name unto all the people that are at Jerusalem, and to Zephaniah the son of Maaseiah the priest, and to all the priests, saying,

Jeremiah 29:26 The Lord hath made thee priest in the stead of Jehoiada the priest, that ye should be officers in the house of the Lord, for every man that is mad, and maketh himself a prophet, that thou shouldest put him in prison, and in the stocks.

Jeremiah 29:27 Now therefore why hast thou not reproved Jeremiah of Anathoth, which maketh himself a prophet to you?

Jeremiah 29:28 For therefore he sent unto us in Babylon, saying, This captivity is long: build ye houses, and dwell in them; and plant gardens, and eat the fruit of them.

Jeremiah 29:29 And Zephaniah the priest read this letter in the ears of Jeremiah the prophet.

Jeremiah 29:30 Then came the word of the Lord unto Jeremiah, saying,

Jeremiah 29:31 Send to all them of the captivity, saying, Thus saith the Lord concerning Shemaiah the Nehelamite; Because that Shemaiah hath prophesied unto you, and I sent him not, and he caused you to trust in a lie:

Jeremiah 29:32 Therefore thus saith the Lord; Behold, I will punish Shemaiah the Nehelamite, and his seed: he shall not have a man to dwell among this people; neither shall he behold the good that I will do for my people, saith the Lord; because he hath taught rebellion against the Lord.
