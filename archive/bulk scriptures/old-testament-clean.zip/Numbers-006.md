# Numbers 6

Numbers 6 (summary): The law of the Nazarite is explained, whereby the children of Israel may consecrate themselves to the Lord by a vow—They drink no wine nor strong drink and if defiled must shave their heads—The Lord reveals the blessing to be used by Aaron and his sons in blessing Israel.

Numbers 6:1 And the Lord spake unto Moses, saying,

Numbers 6:2 Speak unto the children of Israel, and say unto them, When either man or woman shall separate themselves to vow a vow of a Nazarite, to separate themselves unto the Lord:

Numbers 6:3 He shall separate himself from wine and strong drink, and shall drink no vinegar of wine, or vinegar of strong drink, neither shall he drink any liquor of grapes, nor eat moist grapes, or dried.

Numbers 6:4 All the days of his separation shall he eat nothing that is made of the vine tree, from the kernels even to the husk.

Numbers 6:5 All the days of the vow of his separation there shall no razor come upon his head: until the days be fulfilled, in the which he separateth himself unto the Lord, he shall be holy, and shall let the locks of the hair of his head grow.

Numbers 6:6 All the days that he separateth himself unto the Lord he shall come at no dead body.

Numbers 6:7 He shall not make himself unclean for his father, or for his mother, for his brother, or for his sister, when they die: because the consecration of his God is upon his head.

Numbers 6:8 All the days of his separation he is holy unto the Lord.

Numbers 6:9 And if any man die very suddenly by him, and he hath defiled the head of his consecration; then he shall shave his head in the day of his cleansing, on the seventh day shall he shave it.

Numbers 6:10 And on the eighth day he shall bring two turtles, or two young pigeons, to the priest, to the door of the tabernacle of the congregation:

Numbers 6:11 And the priest shall offer the one for a sin offering, and the other for a burnt offering, and make an atonement for him, for that he sinned by the dead, and shall hallow his head that same day.

Numbers 6:12 And he shall consecrate unto the Lord the days of his separation, and shall bring a lamb of the first year for a trespass offering: but the days that were before shall be lost, because his separation was defiled.

Numbers 6:13 And this is the law of the Nazarite, when the days of his separation are fulfilled: he shall be brought unto the door of the tabernacle of the congregation:

Numbers 6:14 And he shall offer his offering unto the Lord, one he lamb of the first year without blemish for a burnt offering, and one ewe lamb of the first year without blemish for a sin offering, and one ram without blemish for peace offerings,

Numbers 6:15 And a basket of unleavened bread, cakes of fine flour mingled with oil, and wafers of unleavened bread anointed with oil, and their meat offering, and their drink offerings.

Numbers 6:16 And the priest shall bring them before the Lord, and shall offer his sin offering, and his burnt offering:

Numbers 6:17 And he shall offer the ram for a sacrifice of peace offerings unto the Lord, with the basket of unleavened bread: the priest shall offer also his meat offering, and his drink offering.

Numbers 6:18 And the Nazarite shall shave the head of his separation at the door of the tabernacle of the congregation, and shall take the hair of the head of his separation, and put it in the fire which is under the sacrifice of the peace offerings.

Numbers 6:19 And the priest shall take the sodden shoulder of the ram, and one unleavened cake out of the basket, and one unleavened wafer, and shall put them upon the hands of the Nazarite, after the hair of his separation is shaven:

Numbers 6:20 And the priest shall wave them for a wave offering before the Lord: this is holy for the priest, with the wave breast and heave shoulder: and after that the Nazarite may drink wine.

Numbers 6:21 This is the law of the Nazarite who hath vowed, and of his offering unto the Lord for his separation, beside that that his hand shall get: according to the vow which he vowed, so he must do after the law of his separation.

Numbers 6:22 And the Lord spake unto Moses, saying,

Numbers 6:23 Speak unto Aaron and unto his sons, saying, On this wise ye shall bless the children of Israel, saying unto them,

Numbers 6:24 The Lord bless thee, and keep thee:

Numbers 6:25 The Lord make his face shine upon thee, and be gracious unto thee:

Numbers 6:26 The Lord lift up his countenance upon thee, and give thee peace.

Numbers 6:27 And they shall put my name upon the children of Israel; and I will bless them.
