# Isaiah 6

Isaiah 6 (summary): Isaiah sees the Lord—His sins are forgiven—He is called to prophesy—He prophesies of the Jews’ rejection of Christ’s teachings—A remnant will return—Compare 2 Nephi 16.

Isaiah 6:1 In the year that king Uzziah died I saw also the Lord sitting upon a throne, high and lifted up, and his train filled the temple.

Isaiah 6:2 Above it stood the seraphims: each one had six wings; with twain he covered his face, and with twain he covered his feet, and with twain he did fly.

Isaiah 6:3 And one cried unto another, and said, Holy, holy, holy, is the Lord of hosts: the whole earth is full of his glory.

Isaiah 6:4 And the posts of the door moved at the voice of him that cried, and the house was filled with smoke.

Isaiah 6:5 Then said I, Woe is me! for I am undone; because I am a man of unclean lips, and I dwell in the midst of a people of unclean lips: for mine eyes have seen the King, the Lord of hosts.

Isaiah 6:6 Then flew one of the seraphims unto me, having a live coal in his hand, which he had taken with the tongs from off the altar:

Isaiah 6:7 And he laid it upon my mouth, and said, Lo, this hath touched thy lips; and thine iniquity is taken away, and thy sin purged.

Isaiah 6:8 Also I heard the voice of the Lord, saying, Whom shall I send, and who will go for us? Then said I, Here am I; send me.

Isaiah 6:9 And he said, Go, and tell this people, Hear ye indeed, but understand not; and see ye indeed, but perceive not.

Isaiah 6:10 Make the heart of this people fat, and make their ears heavy, and shut their eyes; lest they see with their eyes, and hear with their ears, and understand with their heart, and convert, and be healed.

Isaiah 6:11 Then said I, Lord, how long? And he answered, Until the cities be wasted without inhabitant, and the houses without man, and the land be utterly desolate,

Isaiah 6:12 And the Lord have removed men far away, and there be a great forsaking in the midst of the land.

Isaiah 6:13 But yet in it shall be a tenth, and it shall return, and shall be eaten: as a teil tree, and as an oak, whose substance is in them, when they cast their leaves: so the holy seed shall be the substance thereof.
