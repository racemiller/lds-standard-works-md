# Psalms 15

Psalms 15 (summary): David asks, Who will dwell in the Lord’s holy hill?—He answers, The righteous, the upright, and those with integrity.

Psalms 15:1 Lord, who shall abide in thy tabernacle? who shall dwell in thy holy hill?

Psalms 15:2 He that walketh uprightly, and worketh righteousness, and speaketh the truth in his heart.

Psalms 15:3 He that backbiteth not with his tongue, nor doeth evil to his neighbour, nor taketh up a reproach against his neighbour.

Psalms 15:4 In whose eyes a vile person is contemned; but he honoureth them that fear the Lord. He that sweareth to his own hurt, and changeth not.

Psalms 15:5 He that putteth not out his money to usury, nor taketh reward against the innocent. He that doeth these things shall never be moved.
