# Exodus 40

Exodus 40 (summary): The tabernacle is reared—Aaron and his sons are washed and anointed and given an everlasting priesthood—The glory of the Lord fills the tabernacle—A cloud covers the tabernacle by day, and fire rests on it by night.

Exodus 40:1 And the Lord spake unto Moses, saying,

Exodus 40:2 On the first day of the first month shalt thou set up the tabernacle of the tent of the congregation.

Exodus 40:3 And thou shalt put therein the ark of the testimony, and cover the ark with the veil.

Exodus 40:4 And thou shalt bring in the table, and set in order the things that are to be set in order upon it; and thou shalt bring in the candlestick, and light the lamps thereof.

Exodus 40:5 And thou shalt set the altar of gold for the incense before the ark of the testimony, and put the hanging of the door to the tabernacle.

Exodus 40:6 And thou shalt set the altar of the burnt offering before the door of the tabernacle of the tent of the congregation.

Exodus 40:7 And thou shalt set the laver between the tent of the congregation and the altar, and shalt put water therein.

Exodus 40:8 And thou shalt set up the court round about, and hang up the hanging at the court gate.

Exodus 40:9 And thou shalt take the anointing oil, and anoint the tabernacle, and all that is therein, and shalt hallow it, and all the vessels thereof: and it shall be holy.

Exodus 40:10 And thou shalt anoint the altar of the burnt offering, and all his vessels, and sanctify the altar: and it shall be an altar most holy.

Exodus 40:11 And thou shalt anoint the laver and his foot, and sanctify it.

Exodus 40:12 And thou shalt bring Aaron and his sons unto the door of the tabernacle of the congregation, and wash them with water.

Exodus 40:13 And thou shalt put upon Aaron the holy garments, and anoint him, and sanctify him; that he may minister unto me in the priest’s office.

Exodus 40:14 And thou shalt bring his sons, and clothe them with coats:

Exodus 40:15 And thou shalt anoint them, as thou didst anoint their father, that they may minister unto me in the priest’s office: for their anointing shall surely be an everlasting priesthood throughout their generations.

Exodus 40:16 Thus did Moses: according to all that the Lord commanded him, so did he.

Exodus 40:17 And it came to pass in the first month in the second year, on the first day of the month, that the tabernacle was reared up.

Exodus 40:18 And Moses reared up the tabernacle, and fastened his sockets, and set up the boards thereof, and put in the bars thereof, and reared up his pillars.

Exodus 40:19 And he spread abroad the tent over the tabernacle, and put the covering of the tent above upon it; as the Lord commanded Moses.

Exodus 40:20 And he took and put the testimony into the ark, and set the staves on the ark, and put the mercy seat above upon the ark:

Exodus 40:21 And he brought the ark into the tabernacle, and set up the veil of the covering, and covered the ark of the testimony; as the Lord commanded Moses.

Exodus 40:22 And he put the table in the tent of the congregation, upon the side of the tabernacle northward, without the veil.

Exodus 40:23 And he set the bread in order upon it before the Lord; as the Lord had commanded Moses.

Exodus 40:24 And he put the candlestick in the tent of the congregation, over against the table, on the side of the tabernacle southward.

Exodus 40:25 And he lighted the lamps before the Lord; as the Lord commanded Moses.

Exodus 40:26 And he put the golden altar in the tent of the congregation before the veil:

Exodus 40:27 And he burnt sweet incense thereon; as the Lord commanded Moses.

Exodus 40:28 And he set up the hanging at the door of the tabernacle.

Exodus 40:29 And he put the altar of burnt offering by the door of the tabernacle of the tent of the congregation, and offered upon it the burnt offering and the meat offering; as the Lord commanded Moses.

Exodus 40:30 And he set the laver between the tent of the congregation and the altar, and put water there, to wash withal.

Exodus 40:31 And Moses and Aaron and his sons washed their hands and their feet thereat:

Exodus 40:32 When they went into the tent of the congregation, and when they came near unto the altar, they washed; as the Lord commanded Moses.

Exodus 40:33 And he reared up the court round about the tabernacle and the altar, and set up the hanging of the court gate. So Moses finished the work.

Exodus 40:34 Then a cloud covered the tent of the congregation, and the glory of the Lord filled the tabernacle.

Exodus 40:35 And Moses was not able to enter into the tent of the congregation, because the cloud abode thereon, and the glory of the Lord filled the tabernacle.

Exodus 40:36 And when the cloud was taken up from over the tabernacle, the children of Israel went onward in all their journeys:

Exodus 40:37 But if the cloud were not taken up, then they journeyed not till the day that it was taken up.

Exodus 40:38 For the cloud of the Lord was upon the tabernacle by day, and fire was on it by night, in the sight of all the house of Israel, throughout all their journeys.
