# Genesis 18

Genesis 18 (summary): Abraham entertains three holy men—They promise that Sarah will have a son—Abraham will command his children to be just—The Lord appears to him—They discuss the destruction of Sodom and Gomorrah.

Genesis 18:1 And the Lord appeared unto him in the plains of Mamre: and he sat in the tent door in the heat of the day;

Genesis 18:2 And he lift up his eyes and looked, and, lo, three men stood by him: and when he saw them, he ran to meet them from the tent door, and bowed himself toward the ground,

Genesis 18:3 And said, My Lord, if now I have found favour in thy sight, pass not away, I pray thee, from thy servant:

Genesis 18:4 Let a little water, I pray you, be fetched, and wash your feet, and rest yourselves under the tree:

Genesis 18:5 And I will fetch a morsel of bread, and comfort ye your hearts; after that ye shall pass on: for therefore are ye come to your servant. And they said, So do, as thou hast said.

Genesis 18:6 And Abraham hastened into the tent unto Sarah, and said, Make ready quickly three measures of fine meal, knead it, and make cakes upon the hearth.

Genesis 18:7 And Abraham ran unto the herd, and fetcht a calf tender and good, and gave it unto a young man; and he hasted to dress it.

Genesis 18:8 And he took butter, and milk, and the calf which he had dressed, and set it before them; and he stood by them under the tree, and they did eat.

Genesis 18:9 And they said unto him, Where is Sarah thy wife? And he said, Behold, in the tent.

Genesis 18:10 And he said, I will certainly return unto thee according to the time of life; and, lo, Sarah thy wife shall have a son. And Sarah heard it in the tent door, which was behind him.

Genesis 18:11 Now Abraham and Sarah were old and well stricken in age; and it ceased to be with Sarah after the manner of women.

Genesis 18:12 Therefore Sarah laughed within herself, saying, After I am waxed old shall I have pleasure, my lord being old also?

Genesis 18:13 And the Lord said unto Abraham, Wherefore did Sarah laugh, saying, Shall I of a surety bear a child, which am old?

Genesis 18:14 Is any thing too hard for the Lord? At the time appointed I will return unto thee, according to the time of life, and Sarah shall have a son.

Genesis 18:15 Then Sarah denied, saying, I laughed not; for she was afraid. And he said, Nay; but thou didst laugh.

Genesis 18:16 And the men rose up from thence, and looked toward Sodom: and Abraham went with them to bring them on the way.

Genesis 18:17 And the Lord said, Shall I hide from Abraham that thing which I do;

Genesis 18:18 Seeing that Abraham shall surely become a great and mighty nation, and all the nations of the earth shall be blessed in him?

Genesis 18:19 For I know him, that he will command his children and his household after him, and they shall keep the way of the Lord, to do justice and judgment; that the Lord may bring upon Abraham that which he hath spoken of him.

Genesis 18:20 And the Lord said, Because the cry of Sodom and Gomorrah is great, and because their sin is very grievous;

Genesis 18:21 I will go down now, and see whether they have done altogether according to the cry of it, which is come unto me; and if not, I will know.

Genesis 18:22 And the men turned their faces from thence, and went toward Sodom: but Abraham stood yet before the Lord.

Genesis 18:23 And Abraham drew near, and said, Wilt thou also destroy the righteous with the wicked?

Genesis 18:24 Peradventure there be fifty righteous within the city: wilt thou also destroy and not spare the place for the fifty righteous that are therein?

Genesis 18:25 That be far from thee to do after this manner, to slay the righteous with the wicked: and that the righteous should be as the wicked, that be far from thee: Shall not the Judge of all the earth do right?

Genesis 18:26 And the Lord said, If I find in Sodom fifty righteous within the city, then I will spare all the place for their sakes.

Genesis 18:27 And Abraham answered and said, Behold now, I have taken upon me to speak unto the Lord, which am but dust and ashes:

Genesis 18:28 Peradventure there shall lack five of the fifty righteous: wilt thou destroy all the city for lack of five? And he said, If I find there forty and five, I will not destroy it.

Genesis 18:29 And he spake unto him yet again, and said, Peradventure there shall be forty found there. And he said, I will not do it for forty’s sake.

Genesis 18:30 And he said unto him, Oh let not the Lord be angry, and I will speak: Peradventure there shall thirty be found there. And he said, I will not do it, if I find thirty there.

Genesis 18:31 And he said, Behold now, I have taken upon me to speak unto the Lord: Peradventure there shall be twenty found there. And he said, I will not destroy it for twenty’s sake.

Genesis 18:32 And he said, Oh let not the Lord be angry, and I will speak yet but this once: Peradventure ten shall be found there. And he said, I will not destroy it for ten’s sake.

Genesis 18:33 And the Lord went his way, as soon as he had left communing with Abraham: and Abraham returned unto his place.
