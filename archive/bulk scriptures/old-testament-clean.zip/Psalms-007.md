# Psalms 7

Psalms 7 (summary): David trusts in the Lord, who will judge the people—God is angry with the wicked.

Psalms 7:1 O Lord my God, in thee do I put my trust: save me from all them that persecute me, and deliver me:

Psalms 7:2 Lest he tear my soul like a lion, rending it in pieces, while there is none to deliver.

Psalms 7:3 O Lord my God, if I have done this; if there be iniquity in my hands;

Psalms 7:4 If I have rewarded evil unto him that was at peace with me; (yea, I have delivered him that without cause is mine enemy:)

Psalms 7:5 Let the enemy persecute my soul, and take it; yea, let him tread down my life upon the earth, and lay mine honour in the dust. Selah.

Psalms 7:6 Arise, O Lord, in thine anger, lift up thyself because of the rage of mine enemies: and awake for me to the judgment that thou hast commanded.

Psalms 7:7 So shall the congregation of the people compass thee about: for their sakes therefore return thou on high.

Psalms 7:8 The Lord shall judge the people: judge me, O Lord, according to my righteousness, and according to mine integrity that is in me.

Psalms 7:9 Oh let the wickedness of the wicked come to an end; but establish the just: for the righteous God trieth the hearts and reins.

Psalms 7:10 My defence is of God, which saveth the upright in heart.

Psalms 7:11 God judgeth the righteous, and God is angry with the wicked every day.

Psalms 7:12 If he turn not, he will whet his sword; he hath bent his bow, and made it ready.

Psalms 7:13 He hath also prepared for him the instruments of death; he ordaineth his arrows against the persecutors.

Psalms 7:14 Behold, he travaileth with iniquity, and hath conceived mischief, and brought forth falsehood.

Psalms 7:15 He made a pit, and digged it, and is fallen into the ditch which he made.

Psalms 7:16 His mischief shall return upon his own head, and his violent dealing shall come down upon his own pate.

Psalms 7:17 I will praise the Lord according to his righteousness: and will sing praise to the name of the Lord most high.
