# Psalms 98

Psalms 98 (summary): Sing unto the Lord—All the ends of the earth will see His salvation—He comes to judge all men with equity and righteousness.

Psalms 98:1 O sing unto the Lord a new song; for he hath done marvellous things: his right hand, and his holy arm, hath gotten him the victory.

Psalms 98:2 The Lord hath made known his salvation: his righteousness hath he openly shewed in the sight of the heathen.

Psalms 98:3 He hath remembered his mercy and his truth toward the house of Israel: all the ends of the earth have seen the salvation of our God.

Psalms 98:4 Make a joyful noise unto the Lord, all the earth: make a loud noise, and rejoice, and sing praise.

Psalms 98:5 Sing unto the Lord with the harp; with the harp, and the voice of a psalm.

Psalms 98:6 With trumpets and sound of cornet make a joyful noise before the Lord, the King.

Psalms 98:7 Let the sea roar, and the fulness thereof; the world, and they that dwell therein.

Psalms 98:8 Let the floods clap their hands: let the hills be joyful together

Psalms 98:9 Before the Lord; for he cometh to judge the earth: with righteousness shall he judge the world, and the people with equity.
