# Exodus 37

Exodus 37 (summary): Bezaleel makes the ark, the mercy seat, and the cherubims—He makes the table, the vessels, the candlestick, the incense altar, the holy anointing oil, and the sweet incense.

Exodus 37:1 And Bezaleel made the ark of shittim wood: two cubits and a half was the length of it, and a cubit and a half the breadth of it, and a cubit and a half the height of it:

Exodus 37:2 And he overlaid it with pure gold within and without, and made a crown of gold to it round about.

Exodus 37:3 And he cast for it four rings of gold, to be set by the four corners of it; even two rings upon the one side of it, and two rings upon the other side of it.

Exodus 37:4 And he made staves of shittim wood, and overlaid them with gold.

Exodus 37:5 And he put the staves into the rings by the sides of the ark, to bear the ark.

Exodus 37:6 And he made the mercy seat of pure gold: two cubits and a half was the length thereof, and one cubit and a half the breadth thereof.

Exodus 37:7 And he made two cherubims of gold, beaten out of one piece made he them, on the two ends of the mercy seat;

Exodus 37:8 One cherub on the end on this side, and another cherub on the other end on that side: out of the mercy seat made he the cherubims on the two ends thereof.

Exodus 37:9 And the cherubims spread out their wings on high, and covered with their wings over the mercy seat, with their faces one to another; even to the mercy seatward were the faces of the cherubims.

Exodus 37:10 And he made the table of shittim wood: two cubits was the length thereof, and a cubit the breadth thereof, and a cubit and a half the height thereof:

Exodus 37:11 And he overlaid it with pure gold, and made thereunto a crown of gold round about.

Exodus 37:12 Also he made thereunto a border of an handbreadth round about; and made a crown of gold for the border thereof round about.

Exodus 37:13 And he cast for it four rings of gold, and put the rings upon the four corners that were in the four feet thereof.

Exodus 37:14 Over against the border were the rings, the places for the staves to bear the table.

Exodus 37:15 And he made the staves of shittim wood, and overlaid them with gold, to bear the table.

Exodus 37:16 And he made the vessels which were upon the table, his dishes, and his spoons, and his bowls, and his covers to cover withal, of pure gold.

Exodus 37:17 And he made the candlestick of pure gold: of beaten work made he the candlestick; his shaft, and his branch, his bowls, his knops, and his flowers, were of the same:

Exodus 37:18 And six branches going out of the sides thereof; three branches of the candlestick out of the one side thereof, and three branches of the candlestick out of the other side thereof:

Exodus 37:19 Three bowls made after the fashion of almonds in one branch, a knop and a flower; and three bowls made like almonds in another branch, a knop and a flower: so throughout the six branches going out of the candlestick.

Exodus 37:20 And in the candlestick were four bowls made like almonds, his knops, and his flowers:

Exodus 37:21 And a knop under two branches of the same, and a knop under two branches of the same, and a knop under two branches of the same, according to the six branches going out of it.

Exodus 37:22 Their knops and their branches were of the same: all of it was one beaten work of pure gold.

Exodus 37:23 And he made his seven lamps, and his snuffers, and his snuffdishes, of pure gold.

Exodus 37:24 Of a talent of pure gold made he it, and all the vessels thereof.

Exodus 37:25 And he made the incense altar of shittim wood: the length of it was a cubit, and the breadth of it a cubit; it was foursquare; and two cubits was the height of it; the horns thereof were of the same.

Exodus 37:26 And he overlaid it with pure gold, both the top of it, and the sides thereof round about, and the horns of it: also he made unto it a crown of gold round about.

Exodus 37:27 And he made two rings of gold for it under the crown thereof, by the two corners of it, upon the two sides thereof, to be places for the staves to bear it withal.

Exodus 37:28 And he made the staves of shittim wood, and overlaid them with gold.

Exodus 37:29 And he made the holy anointing oil, and the pure incense of sweet spices, according to the work of the apothecary.
