# Ezra 3

Ezra 3 (summary): The altar is rebuilt—Regular sacrifices are reinstituted—The foundations of the temple are laid amid great rejoicing.

Ezra 3:1 And when the seventh month was come, and the children of Israel were in the cities, the people gathered themselves together as one man to Jerusalem.

Ezra 3:2 Then stood up Jeshua the son of Jozadak, and his brethren the priests, and Zerubbabel the son of Shealtiel, and his brethren, and builded the altar of the God of Israel, to offer burnt offerings thereon, as it is written in the law of Moses the man of God.

Ezra 3:3 And they set the altar upon his bases; for fear was upon them because of the people of those countries: and they offered burnt offerings thereon unto the Lord, even burnt offerings morning and evening.

Ezra 3:4 They kept also the feast of tabernacles, as it is written, and offered the daily burnt offerings by number, according to the custom, as the duty of every day required;

Ezra 3:5 And afterward offered the continual burnt offering, both of the new moons, and of all the set feasts of the Lord that were consecrated, and of every one that willingly offered a freewill offering unto the Lord.

Ezra 3:6 From the first day of the seventh month began they to offer burnt offerings unto the Lord. But the foundation of the temple of the Lord was not yet laid.

Ezra 3:7 They gave money also unto the masons, and to the carpenters; and meat, and drink, and oil, unto them of Zidon, and to them of Tyre, to bring cedar trees from Lebanon to the sea of Joppa, according to the grant that they had of Cyrus king of Persia.

Ezra 3:8 Now in the second year of their coming unto the house of God at Jerusalem, in the second month, began Zerubbabel the son of Shealtiel, and Jeshua the son of Jozadak, and the remnant of their brethren the priests and the Levites, and all they that were come out of the captivity unto Jerusalem; and appointed the Levites, from twenty years old and upward, to set forward the work of the house of the Lord.

Ezra 3:9 Then stood Jeshua with his sons and his brethren, Kadmiel and his sons, the sons of Judah, together, to set forward the workmen in the house of God: the sons of Henadad, with their sons and their brethren the Levites.

Ezra 3:10 And when the builders laid the foundation of the temple of the Lord, they set the priests in their apparel with trumpets, and the Levites the sons of Asaph with cymbals, to praise the Lord, after the ordinance of David king of Israel.

Ezra 3:11 And they sang together by course in praising and giving thanks unto the Lord; because he is good, for his mercy endureth for ever toward Israel. And all the people shouted with a great shout, when they praised the Lord, because the foundation of the house of the Lord was laid.

Ezra 3:12 But many of the priests and Levites and chief of the fathers, who were ancient men, that had seen the first house, when the foundation of this house was laid before their eyes, wept with a loud voice; and many shouted aloud for joy:

Ezra 3:13 So that the people could not discern the noise of the shout of joy from the noise of the weeping of the people: for the people shouted with a loud shout, and the noise was heard afar off.
