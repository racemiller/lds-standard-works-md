# Psalms 106

Psalms 106 (summary): Praise the Lord for His mercy and mighty works—Israel rebelled and did wickedly—Moses mediated between Israel and the Lord—Israel was scattered and slain for worshipping false gods.

Psalms 106:1 Praise ye the Lord. O give thanks unto the Lord; for he is good: for his mercy endureth for ever.

Psalms 106:2 Who can utter the mighty acts of the Lord? who can shew forth all his praise?

Psalms 106:3 Blessed are they that keep judgment, and he that doeth righteousness at all times.

Psalms 106:4 Remember me, O Lord, with the favour that thou bearest unto thy people: O visit me with thy salvation;

Psalms 106:5 That I may see the good of thy chosen, that I may rejoice in the gladness of thy nation, that I may glory with thine inheritance.

Psalms 106:6 We have sinned with our fathers, we have committed iniquity, we have done wickedly.

Psalms 106:7 Our fathers understood not thy wonders in Egypt; they remembered not the multitude of thy mercies; but provoked him at the sea, even at the Red sea.

Psalms 106:8 Nevertheless he saved them for his name’s sake, that he might make his mighty power to be known.

Psalms 106:9 He rebuked the Red sea also, and it was dried up: so he led them through the depths, as through the wilderness.

Psalms 106:10 And he saved them from the hand of him that hated them, and redeemed them from the hand of the enemy.

Psalms 106:11 And the waters covered their enemies: there was not one of them left.

Psalms 106:12 Then believed they his words; they sang his praise.

Psalms 106:13 They soon forgat his works; they waited not for his counsel:

Psalms 106:14 But lusted exceedingly in the wilderness, and tempted God in the desert.

Psalms 106:15 And he gave them their request; but sent leanness into their soul.

Psalms 106:16 They envied Moses also in the camp, and Aaron the saint of the Lord.

Psalms 106:17 The earth opened and swallowed up Dathan, and covered the company of Abiram.

Psalms 106:18 And a fire was kindled in their company; the flame burned up the wicked.

Psalms 106:19 They made a calf in Horeb, and worshipped the molten image.

Psalms 106:20 Thus they changed their glory into the similitude of an ox that eateth grass.

Psalms 106:21 They forgat God their saviour, which had done great things in Egypt;

Psalms 106:22 Wondrous works in the land of Ham, and terrible things by the Red sea.

Psalms 106:23 Therefore he said that he would destroy them, had not Moses his chosen stood before him in the breach, to turn away his wrath, lest he should destroy them.

Psalms 106:24 Yea, they despised the pleasant land, they believed not his word:

Psalms 106:25 But murmured in their tents, and hearkened not unto the voice of the Lord.

Psalms 106:26 Therefore he lifted up his hand against them, to overthrow them in the wilderness:

Psalms 106:27 To overthrow their seed also among the nations, and to scatter them in the lands.

Psalms 106:28 They joined themselves also unto Baal-peor, and ate the sacrifices of the dead.

Psalms 106:29 Thus they provoked him to anger with their inventions: and the plague brake in upon them.

Psalms 106:30 Then stood up Phinehas, and executed judgment: and so the plague was stayed.

Psalms 106:31 And that was counted unto him for righteousness unto all generations for evermore.

Psalms 106:32 They angered him also at the waters of strife, so that it went ill with Moses for their sakes:

Psalms 106:33 Because they provoked his spirit, so that he spake unadvisedly with his lips.

Psalms 106:34 They did not destroy the nations, concerning whom the Lord commanded them:

Psalms 106:35 But were mingled among the heathen, and learned their works.

Psalms 106:36 And they served their idols: which were a snare unto them.

Psalms 106:37 Yea, they sacrificed their sons and their daughters unto devils,

Psalms 106:38 And shed innocent blood, even the blood of their sons and of their daughters, whom they sacrificed unto the idols of Canaan: and the land was polluted with blood.

Psalms 106:39 Thus were they defiled with their own works, and went a whoring with their own inventions.

Psalms 106:40 Therefore was the wrath of the Lord kindled against his people, insomuch that he abhorred his own inheritance.

Psalms 106:41 And he gave them into the hand of the heathen; and they that hated them ruled over them.

Psalms 106:42 Their enemies also oppressed them, and they were brought into subjection under their hand.

Psalms 106:43 Many times did he deliver them; but they provoked him with their counsel, and were brought low for their iniquity.

Psalms 106:44 Nevertheless he regarded their affliction, when he heard their cry:

Psalms 106:45 And he remembered for them his covenant, and repented according to the multitude of his mercies.

Psalms 106:46 He made them also to be pitied of all those that carried them captives.

Psalms 106:47 Save us, O Lord our God, and gather us from among the heathen, to give thanks unto thy holy name, and to triumph in thy praise.

Psalms 106:48 Blessed be the Lord God of Israel from everlasting to everlasting: and let all the people say, Amen. Praise ye the Lord.
