# Deuteronomy 5

Deuteronomy 5 (summary): Moses tells of the covenant God made with Israel in Horeb—He reviews the Ten Commandments—Sabbath observance also commemorates the deliverance from Egypt—God talks with man—Blessings flow from obedience.

Deuteronomy 5:1 And Moses called all Israel, and said unto them, Hear, O Israel, the statutes and judgments which I speak in your ears this day, that ye may learn them, and keep, and do them.

Deuteronomy 5:2 The Lord our God made a covenant with us in Horeb.

Deuteronomy 5:3 The Lord made not this covenant with our fathers, but with us, even us, who are all of us here alive this day.

Deuteronomy 5:4 The Lord talked with you face to face in the mount out of the midst of the fire,

Deuteronomy 5:5 (I stood between the Lord and you at that time, to shew you the word of the Lord: for ye were afraid by reason of the fire, and went not up into the mount;) saying,

Deuteronomy 5:6 I am the Lord thy God, which brought thee out of the land of Egypt, from the house of bondage.

Deuteronomy 5:7 Thou shalt have none other gods before me.

Deuteronomy 5:8 Thou shalt not make thee any graven image, or any likeness of any thing that is in heaven above, or that is in the earth beneath, or that is in the waters beneath the earth:

Deuteronomy 5:9 Thou shalt not bow down thyself unto them, nor serve them: for I the Lord thy God am a jealous God, visiting the iniquity of the fathers upon the children unto the third and fourth generation of them that hate me,

Deuteronomy 5:10 And shewing mercy unto thousands of them that love me and keep my commandments.

Deuteronomy 5:11 Thou shalt not take the name of the Lord thy God in vain: for the Lord will not hold him guiltless that taketh his name in vain.

Deuteronomy 5:12 Keep the sabbath day to sanctify it, as the Lord thy God hath commanded thee.

Deuteronomy 5:13 Six days thou shalt labour, and do all thy work:

Deuteronomy 5:14 But the seventh day is the sabbath of the Lord thy God: in it thou shalt not do any work, thou, nor thy son, nor thy daughter, nor thy manservant, nor thy maidservant, nor thine ox, nor thine ass, nor any of thy cattle, nor thy stranger that is within thy gates; that thy manservant and thy maidservant may rest as well as thou.

Deuteronomy 5:15 And remember that thou wast a servant in the land of Egypt, and that the Lord thy God brought thee out thence through a mighty hand and by a stretched out arm: therefore the Lord thy God commanded thee to keep the sabbath day.

Deuteronomy 5:16 Honour thy father and thy mother, as the Lord thy God hath commanded thee; that thy days may be prolonged, and that it may go well with thee, in the land which the Lord thy God giveth thee.

Deuteronomy 5:17 Thou shalt not kill.

Deuteronomy 5:18 Neither shalt thou commit adultery.

Deuteronomy 5:19 Neither shalt thou steal.

Deuteronomy 5:20 Neither shalt thou bear false witness against thy neighbour.

Deuteronomy 5:21 Neither shalt thou desire thy neighbour’s wife, neither shalt thou covet thy neighbour’s house, his field, or his manservant, or his maidservant, his ox, or his ass, or any thing that is thy neighbour’s.

Deuteronomy 5:22 These words the Lord spake unto all your assembly in the mount out of the midst of the fire, of the cloud, and of the thick darkness, with a great voice: and he added no more. And he wrote them in two tables of stone, and delivered them unto me.

Deuteronomy 5:23 And it came to pass, when ye heard the voice out of the midst of the darkness, (for the mountain did burn with fire,) that ye came near unto me, even all the heads of your tribes, and your elders;

Deuteronomy 5:24 And ye said, Behold, the Lord our God hath shewed us his glory and his greatness, and we have heard his voice out of the midst of the fire: we have seen this day that God doth talk with man, and he liveth.

Deuteronomy 5:25 Now therefore why should we die? for this great fire will consume us: if we hear the voice of the Lord our God any more, then we shall die.

Deuteronomy 5:26 For who is there of all flesh, that hath heard the voice of the living God speaking out of the midst of the fire, as we have, and lived?

Deuteronomy 5:27 Go thou near, and hear all that the Lord our God shall say: and speak thou unto us all that the Lord our God shall speak unto thee; and we will hear it, and do it.

Deuteronomy 5:28 And the Lord heard the voice of your words, when ye spake unto me; and the Lord said unto me, I have heard the voice of the words of this people, which they have spoken unto thee: they have well said all that they have spoken.

Deuteronomy 5:29 O that there were such an heart in them, that they would fear me, and keep all my commandments always, that it might be well with them, and with their children for ever!

Deuteronomy 5:30 Go say to them, Get you into your tents again.

Deuteronomy 5:31 But as for thee, stand thou here by me, and I will speak unto thee all the commandments, and the statutes, and the judgments, which thou shalt teach them, that they may do them in the land which I give them to possess it.

Deuteronomy 5:32 Ye shall observe to do therefore as the Lord your God hath commanded you: ye shall not turn aside to the right hand or to the left.

Deuteronomy 5:33 Ye shall walk in all the ways which the Lord your God hath commanded you, that ye may live, and that it may be well with you, and that ye may prolong your days in the land which ye shall possess.
