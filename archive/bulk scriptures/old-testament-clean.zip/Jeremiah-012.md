# Jeremiah 12

Jeremiah 12 (summary): Jeremiah complains of the prosperity of the wicked—If other nations learn the ways of Israel, they will be numbered with Israel.

Jeremiah 12:1 Righteous art thou, O Lord, when I plead with thee: yet let me talk with thee of thy judgments: Wherefore doth the way of the wicked prosper? wherefore are all they happy that deal very treacherously?

Jeremiah 12:2 Thou hast planted them, yea, they have taken root: they grow, yea, they bring forth fruit: thou art near in their mouth, and far from their reins.

Jeremiah 12:3 But thou, O Lord, knowest me: thou hast seen me, and tried mine heart toward thee: pull them out like sheep for the slaughter, and prepare them for the day of slaughter.

Jeremiah 12:4 How long shall the land mourn, and the herbs of every field wither, for the wickedness of them that dwell therein? the beasts are consumed, and the birds; because they said, He shall not see our last end.

Jeremiah 12:5 If thou hast run with the footmen, and they have wearied thee, then how canst thou contend with horses? and if in the land of peace, wherein thou trustedst, they wearied thee, then how wilt thou do in the swelling of Jordan?

Jeremiah 12:6 For even thy brethren, and the house of thy father, even they have dealt treacherously with thee; yea, they have called a multitude after thee: believe them not, though they speak fair words unto thee.

Jeremiah 12:7 I have forsaken mine house, I have left mine heritage; I have given the dearly beloved of my soul into the hand of her enemies.

Jeremiah 12:8 Mine heritage is unto me as a lion in the forest; it crieth out against me: therefore have I hated it.

Jeremiah 12:9 Mine heritage is unto me as a speckled bird, the birds round about are against her; come ye, assemble all the beasts of the field, come to devour.

Jeremiah 12:10 Many pastors have destroyed my vineyard, they have trodden my portion under foot, they have made my pleasant portion a desolate wilderness.

Jeremiah 12:11 They have made it desolate, and being desolate it mourneth unto me; the whole land is made desolate, because no man layeth it to heart.

Jeremiah 12:12 The spoilers are come upon all high places through the wilderness: for the sword of the Lord shall devour from the one end of the land even to the other end of the land: no flesh shall have peace.

Jeremiah 12:13 They have sown wheat, but shall reap thorns: they have put themselves to pain, but shall not profit: and they shall be ashamed of your revenues because of the fierce anger of the Lord.

Jeremiah 12:14 Thus saith the Lord against all mine evil neighbours, that touch the inheritance which I have caused my people Israel to inherit; Behold, I will pluck them out of their land, and pluck out the house of Judah from among them.

Jeremiah 12:15 And it shall come to pass, after that I have plucked them out I will return, and have compassion on them, and will bring them again, every man to his heritage, and every man to his land.

Jeremiah 12:16 And it shall come to pass, if they will diligently learn the ways of my people, to swear by my name, The Lord liveth; as they taught my people to swear by Baal; then shall they be built in the midst of my people.

Jeremiah 12:17 But if they will not obey, I will utterly pluck up and destroy that nation, saith the Lord.
