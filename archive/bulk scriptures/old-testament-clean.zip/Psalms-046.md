# Psalms 46

Psalms 46 (summary): God is our refuge and strength—He dwells in His city, does marvelous things, and says, Be still and know that I am God.

Psalms 46:1 God is our refuge and strength, a very present help in trouble.

Psalms 46:2 Therefore will not we fear, though the earth be removed, and though the mountains be carried into the midst of the sea;

Psalms 46:3 Though the waters thereof roar and be troubled, though the mountains shake with the swelling thereof. Selah.

Psalms 46:4 There is a river, the streams whereof shall make glad the city of God, the holy place of the tabernacles of the most High.

Psalms 46:5 God is in the midst of her; she shall not be moved: God shall help her, and that right early.

Psalms 46:6 The heathen raged, the kingdoms were moved: he uttered his voice, the earth melted.

Psalms 46:7 The Lord of hosts is with us; the God of Jacob is our refuge. Selah.

Psalms 46:8 Come, behold the works of the Lord, what desolations he hath made in the earth.

Psalms 46:9 He maketh wars to cease unto the end of the earth; he breaketh the bow, and cutteth the spear in sunder; he burneth the chariot in the fire.

Psalms 46:10 Be still, and know that I am God: I will be exalted among the heathen, I will be exalted in the earth.

Psalms 46:11 The Lord of hosts is with us; the God of Jacob is our refuge. Selah.
