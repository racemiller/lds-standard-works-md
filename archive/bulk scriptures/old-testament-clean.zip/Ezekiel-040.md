# Ezekiel 40

Ezekiel 40 (summary): A heavenly messenger shows Ezekiel in vision a city where the temple is located—Ezekiel is shown the form and size of the temple and its courts.

Ezekiel 40:1 In the five and twentieth year of our captivity, in the beginning of the year, in the tenth day of the month, in the fourteenth year after that the city was smitten, in the selfsame day the hand of the Lord was upon me, and brought me thither.

Ezekiel 40:2 In the visions of God brought he me into the land of Israel, and set me upon a very high mountain, by which was as the frame of a city on the south.

Ezekiel 40:3 And he brought me thither, and, behold, there was a man, whose appearance was like the appearance of brass, with a line of flax in his hand, and a measuring reed; and he stood in the gate.

Ezekiel 40:4 And the man said unto me, Son of man, behold with thine eyes, and hear with thine ears, and set thine heart upon all that I shall shew thee; for to the intent that I might shew them unto thee art thou brought hither: declare all that thou seest to the house of Israel.

Ezekiel 40:5 And behold a wall on the outside of the house round about, and in the man’s hand a measuring reed of six cubits long by the cubit and an hand breadth: so he measured the breadth of the building, one reed; and the height, one reed.

Ezekiel 40:6 Then came he unto the gate which looketh toward the east, and went up the stairs thereof, and measured the threshold of the gate, which was one reed broad; and the other threshold of the gate, which was one reed broad.

Ezekiel 40:7 And every little chamber was one reed long, and one reed broad; and between the little chambers were five cubits; and the threshold of the gate by the porch of the gate within was one reed.

Ezekiel 40:8 He measured also the porch of the gate within, one reed.

Ezekiel 40:9 Then measured he the porch of the gate, eight cubits; and the posts thereof, two cubits; and the porch of the gate was inward.

Ezekiel 40:10 And the little chambers of the gate eastward were three on this side, and three on that side; they three were of one measure: and the posts had one measure on this side and on that side.

Ezekiel 40:11 And he measured the breadth of the entry of the gate, ten cubits; and the length of the gate, thirteen cubits.

Ezekiel 40:12 The space also before the little chambers was one cubit on this side, and the space was one cubit on that side: and the little chambers were six cubits on this side, and six cubits on that side.

Ezekiel 40:13 He measured then the gate from the roof of one little chamber to the roof of another: the breadth was five and twenty cubits, door against door.

Ezekiel 40:14 He made also posts of threescore cubits, even unto the post of the court round about the gate.

Ezekiel 40:15 And from the face of the gate of the entrance unto the face of the porch of the inner gate were fifty cubits.

Ezekiel 40:16 And there were narrow windows to the little chambers, and to their posts within the gate round about, and likewise to the arches: and windows were round about inward: and upon each post were palm trees.

Ezekiel 40:17 Then brought he me into the outward court, and, lo, there were chambers, and a pavement made for the court round about: thirty chambers were upon the pavement.

Ezekiel 40:18 And the pavement by the side of the gates over against the length of the gates was the lower pavement.

Ezekiel 40:19 Then he measured the breadth from the forefront of the lower gate unto the forefront of the inner court without, an hundred cubits eastward and northward.

Ezekiel 40:20 And the gate of the outward court that looked toward the north, he measured the length thereof, and the breadth thereof.

Ezekiel 40:21 And the little chambers thereof were three on this side and three on that side; and the posts thereof and the arches thereof were after the measure of the first gate: the length thereof was fifty cubits, and the breadth five and twenty cubits.

Ezekiel 40:22 And their windows, and their arches, and their palm trees, were after the measure of the gate that looketh toward the east; and they went up unto it by seven steps; and the arches thereof were before them.

Ezekiel 40:23 And the gate of the inner court was over against the gate toward the north, and toward the east; and he measured from gate to gate an hundred cubits.

Ezekiel 40:24 After that he brought me toward the south, and behold a gate toward the south: and he measured the posts thereof and the arches thereof according to these measures.

Ezekiel 40:25 And there were windows in it and in the arches thereof round about, like those windows: the length was fifty cubits, and the breadth five and twenty cubits.

Ezekiel 40:26 And there were seven steps to go up to it, and the arches thereof were before them: and it had palm trees, one on this side, and another on that side, upon the posts thereof.

Ezekiel 40:27 And there was a gate in the inner court toward the south: and he measured from gate to gate toward the south an hundred cubits.

Ezekiel 40:28 And he brought me to the inner court by the south gate: and he measured the south gate according to these measures;

Ezekiel 40:29 And the little chambers thereof, and the posts thereof, and the arches thereof, according to these measures: and there were windows in it and in the arches thereof round about: it was fifty cubits long, and five and twenty cubits broad.

Ezekiel 40:30 And the arches round about were five and twenty cubits long, and five cubits broad.

Ezekiel 40:31 And the arches thereof were toward the utter court; and palm trees were upon the posts thereof: and the going up to it had eight steps.

Ezekiel 40:32 And he brought me into the inner court toward the east: and he measured the gate according to these measures.

Ezekiel 40:33 And the little chambers thereof, and the posts thereof, and the arches thereof, were according to these measures: and there were windows therein and in the arches thereof round about: it was fifty cubits long, and five and twenty cubits broad.

Ezekiel 40:34 And the arches thereof were toward the outward court; and palm trees were upon the posts thereof, on this side, and on that side: and the going up to it had eight steps.

Ezekiel 40:35 And he brought me to the north gate, and measured it according to these measures;

Ezekiel 40:36 The little chambers thereof, the posts thereof, and the arches thereof, and the windows to it round about: the length was fifty cubits, and the breadth five and twenty cubits.

Ezekiel 40:37 And the posts thereof were toward the utter court; and palm trees were upon the posts thereof, on this side, and on that side: and the going up to it had eight steps.

Ezekiel 40:38 And the chambers and the entries thereof were by the posts of the gates, where they washed the burnt offering.

Ezekiel 40:39 And in the porch of the gate were two tables on this side, and two tables on that side, to slay thereon the burnt offering and the sin offering and the trespass offering.

Ezekiel 40:40 And at the side without, as one goeth up to the entry of the north gate, were two tables; and on the other side, which was at the porch of the gate, were two tables.

Ezekiel 40:41 Four tables were on this side, and four tables on that side, by the side of the gate; eight tables, whereupon they slew their sacrifices.

Ezekiel 40:42 And the four tables were of hewn stone for the burnt offering, of a cubit and an half long, and a cubit and an half broad, and one cubit high: whereupon also they laid the instruments wherewith they slew the burnt offering and the sacrifice.

Ezekiel 40:43 And within were hooks, an hand broad, fastened round about: and upon the tables was the flesh of the offering.

Ezekiel 40:44 And without the inner gate were the chambers of the singers in the inner court, which was at the side of the north gate; and their prospect was toward the south: one at the side of the east gate having the prospect toward the north.

Ezekiel 40:45 And he said unto me, This chamber, whose prospect is toward the south, is for the priests, the keepers of the charge of the house.

Ezekiel 40:46 And the chamber whose prospect is toward the north is for the priests, the keepers of the charge of the altar: these are the sons of Zadok among the sons of Levi, which come near to the Lord to minister unto him.

Ezekiel 40:47 So he measured the court, an hundred cubits long, and an hundred cubits broad, foursquare; and the altar that was before the house.

Ezekiel 40:48 And he brought me to the porch of the house, and measured each post of the porch, five cubits on this side, and five cubits on that side: and the breadth of the gate was three cubits on this side, and three cubits on that side.

Ezekiel 40:49 The length of the porch was twenty cubits, and the breadth eleven cubits; and he brought me by the steps whereby they went up to it: and there were pillars by the posts, one on this side, and another on that side.
