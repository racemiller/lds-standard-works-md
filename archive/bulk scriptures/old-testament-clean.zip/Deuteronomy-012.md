# Deuteronomy 12

Deuteronomy 12 (summary): Israel is to destroy the Canaanite gods and places of worship—The Lord will designate where His people will worship—The eating of blood is forbidden—Israel’s worship must conform to the divine standard.

Deuteronomy 12:1 These are the statutes and judgments, which ye shall observe to do in the land, which the Lord God of thy fathers giveth thee to possess it, all the days that ye live upon the earth.

Deuteronomy 12:2 Ye shall utterly destroy all the places, wherein the nations which ye shall possess served their gods, upon the high mountains, and upon the hills, and under every green tree:

Deuteronomy 12:3 And ye shall overthrow their altars, and break their pillars, and burn their groves with fire; and ye shall hew down the graven images of their gods, and destroy the names of them out of that place.

Deuteronomy 12:4 Ye shall not do so unto the Lord your God.

Deuteronomy 12:5 But unto the place which the Lord your God shall choose out of all your tribes to put his name there, even unto his habitation shall ye seek, and thither thou shalt come:

Deuteronomy 12:6 And thither ye shall bring your burnt offerings, and your sacrifices, and your tithes, and heave offerings of your hand, and your vows, and your freewill offerings, and the firstlings of your herds and of your flocks:

Deuteronomy 12:7 And there ye shall eat before the Lord your God, and ye shall rejoice in all that ye put your hand unto, ye and your households, wherein the Lord thy God hath blessed thee.

Deuteronomy 12:8 Ye shall not do after all the things that we do here this day, every man whatsoever is right in his own eyes.

Deuteronomy 12:9 For ye are not as yet come to the rest and to the inheritance, which the Lord your God giveth you.

Deuteronomy 12:10 But when ye go over Jordan, and dwell in the land which the Lord your God giveth you to inherit, and when he giveth you rest from all your enemies round about, so that ye dwell in safety;

Deuteronomy 12:11 Then there shall be a place which the Lord your God shall choose to cause his name to dwell there; thither shall ye bring all that I command you; your burnt offerings, and your sacrifices, your tithes, and the heave offering of your hand, and all your choice vows which ye vow unto the Lord:

Deuteronomy 12:12 And ye shall rejoice before the Lord your God, ye, and your sons, and your daughters, and your menservants, and your maidservants, and the Levite that is within your gates; forasmuch as he hath no part nor inheritance with you.

Deuteronomy 12:13 Take heed to thyself that thou offer not thy burnt offerings in every place that thou seest:

Deuteronomy 12:14 But in the place which the Lord shall choose in one of thy tribes, there thou shalt offer thy burnt offerings, and there thou shalt do all that I command thee.

Deuteronomy 12:15 Notwithstanding thou mayest kill and eat flesh in all thy gates, whatsoever thy soul lusteth after, according to the blessing of the Lord thy God which he hath given thee: the unclean and the clean may eat thereof, as of the roebuck, and as of the hart.

Deuteronomy 12:16 Only ye shall not eat the blood; ye shall pour it upon the earth as water.

Deuteronomy 12:17 Thou mayest not eat within thy gates the tithe of thy corn, or of thy wine, or of thy oil, or the firstlings of thy herds or of thy flock, nor any of thy vows which thou vowest, nor thy freewill offerings, or heave offering of thine hand:

Deuteronomy 12:18 But thou must eat them before the Lord thy God in the place which the Lord thy God shall choose, thou, and thy son, and thy daughter, and thy manservant, and thy maidservant, and the Levite that is within thy gates: and thou shalt rejoice before the Lord thy God in all that thou puttest thine hands unto.

Deuteronomy 12:19 Take heed to thyself that thou forsake not the Levite as long as thou livest upon the earth.

Deuteronomy 12:20 When the Lord thy God shall enlarge thy border, as he hath promised thee, and thou shalt say, I will eat flesh, because thy soul longeth to eat flesh; thou mayest eat flesh, whatsoever thy soul lusteth after.

Deuteronomy 12:21 If the place which the Lord thy God hath chosen to put his name there be too far from thee, then thou shalt kill of thy herd and of thy flock, which the Lord hath given thee, as I have commanded thee, and thou shalt eat in thy gates whatsoever thy soul lusteth after.

Deuteronomy 12:22 Even as the roebuck and the hart is eaten, so thou shalt eat them: the unclean and the clean shall eat of them alike.

Deuteronomy 12:23 Only be sure that thou eat not the blood: for the blood is the life; and thou mayest not eat the life with the flesh.

Deuteronomy 12:24 Thou shalt not eat it; thou shalt pour it upon the earth as water.

Deuteronomy 12:25 Thou shalt not eat it; that it may go well with thee, and with thy children after thee, when thou shalt do that which is right in the sight of the Lord.

Deuteronomy 12:26 Only thy holy things which thou hast, and thy vows, thou shalt take, and go unto the place which the Lord shall choose:

Deuteronomy 12:27 And thou shalt offer thy burnt offerings, the flesh and the blood, upon the altar of the Lord thy God: and the blood of thy sacrifices shall be poured out upon the altar of the Lord thy God, and thou shalt eat the flesh.

Deuteronomy 12:28 Observe and hear all these words which I command thee, that it may go well with thee, and with thy children after thee for ever, when thou doest that which is good and right in the sight of the Lord thy God.

Deuteronomy 12:29 When the Lord thy God shall cut off the nations from before thee, whither thou goest to possess them, and thou succeedest them, and dwellest in their land;

Deuteronomy 12:30 Take heed to thyself that thou be not snared by following them, after that they be destroyed from before thee; and that thou inquire not after their gods, saying, How did these nations serve their gods? even so will I do likewise.

Deuteronomy 12:31 Thou shalt not do so unto the Lord thy God: for every abomination to the Lord, which he hateth, have they done unto their gods; for even their sons and their daughters they have burnt in the fire to their gods.

Deuteronomy 12:32 What thing soever I command you, observe to do it: thou shalt not add thereto, nor diminish from it.
