# Ezekiel 22

Ezekiel 22 (summary): Ezekiel catalogs the sins of the people of Judah in Jerusalem—They will be scattered and destroyed for their iniquities.

Ezekiel 22:1 Moreover the word of the Lord came unto me, saying,

Ezekiel 22:2 Now, thou son of man, wilt thou judge, wilt thou judge the bloody city? yea, thou shalt shew her all her abominations.

Ezekiel 22:3 Then say thou, Thus saith the Lord God, The city sheddeth blood in the midst of it, that her time may come, and maketh idols against herself to defile herself.

Ezekiel 22:4 Thou art become guilty in thy blood that thou hast shed; and hast defiled thyself in thine idols which thou hast made; and thou hast caused thy days to draw near, and art come even unto thy years: therefore have I made thee a reproach unto the heathen, and a mocking to all countries.

Ezekiel 22:5 Those that be near, and those that be far from thee, shall mock thee, which art infamous and much vexed.

Ezekiel 22:6 Behold, the princes of Israel, every one were in thee to their power to shed blood.

Ezekiel 22:7 In thee have they set light by father and mother: in the midst of thee have they dealt by oppression with the stranger: in thee have they vexed the fatherless and the widow.

Ezekiel 22:8 Thou hast despised mine holy things, and hast profaned my sabbaths.

Ezekiel 22:9 In thee are men that carry tales to shed blood: and in thee they eat upon the mountains: in the midst of thee they commit lewdness.

Ezekiel 22:10 In thee have they discovered their fathers’ nakedness: in thee have they humbled her that was set apart for pollution.

Ezekiel 22:11 And one hath committed abomination with his neighbour’s wife; and another hath lewdly defiled his daughter in law; and another in thee hath humbled his sister, his father’s daughter.

Ezekiel 22:12 In thee have they taken gifts to shed blood; thou hast taken usury and increase, and thou hast greedily gained of thy neighbours by extortion, and hast forgotten me, saith the Lord God.

Ezekiel 22:13 Behold, therefore I have smitten mine hand at thy dishonest gain which thou hast made, and at thy blood which hath been in the midst of thee.

Ezekiel 22:14 Can thine heart endure, or can thine hands be strong, in the days that I shall deal with thee? I the Lord have spoken it, and will do it.

Ezekiel 22:15 And I will scatter thee among the heathen, and disperse thee in the countries, and will consume thy filthiness out of thee.

Ezekiel 22:16 And thou shalt take thine inheritance in thyself in the sight of the heathen, and thou shalt know that I am the Lord.

Ezekiel 22:17 And the word of the Lord came unto me, saying,

Ezekiel 22:18 Son of man, the house of Israel is to me become dross: all they are brass, and tin, and iron, and lead, in the midst of the furnace; they are even the dross of silver.

Ezekiel 22:19 Therefore thus saith the Lord God; Because ye are all become dross, behold, therefore I will gather you into the midst of Jerusalem.

Ezekiel 22:20 As they gather silver, and brass, and iron, and lead, and tin, into the midst of the furnace, to blow the fire upon it, to melt it; so will I gather you in mine anger and in my fury, and I will leave you there, and melt you.

Ezekiel 22:21 Yea, I will gather you, and blow upon you in the fire of my wrath, and ye shall be melted in the midst thereof.

Ezekiel 22:22 As silver is melted in the midst of the furnace, so shall ye be melted in the midst thereof; and ye shall know that I the Lord have poured out my fury upon you.

Ezekiel 22:23 And the word of the Lord came unto me, saying,

Ezekiel 22:24 Son of man, say unto her, Thou art the land that is not cleansed, nor rained upon in the day of indignation.

Ezekiel 22:25 There is a conspiracy of her prophets in the midst thereof, like a roaring lion ravening the prey; they have devoured souls; they have taken the treasure and precious things; they have made her many widows in the midst thereof.

Ezekiel 22:26 Her priests have violated my law, and have profaned mine holy things: they have put no difference between the holy and profane, neither have they shewed difference between the unclean and the clean, and have hid their eyes from my sabbaths, and I am profaned among them.

Ezekiel 22:27 Her princes in the midst thereof are like wolves ravening the prey, to shed blood, and to destroy souls, to get dishonest gain.

Ezekiel 22:28 And her prophets have daubed them with untempered mortar, seeing vanity, and divining lies unto them, saying, Thus saith the Lord God, when the Lord hath not spoken.

Ezekiel 22:29 The people of the land have used oppression, and exercised robbery, and have vexed the poor and needy: yea, they have oppressed the stranger wrongfully.

Ezekiel 22:30 And I sought for a man among them, that should make up the hedge, and stand in the gap before me for the land, that I should not destroy it: but I found none.

Ezekiel 22:31 Therefore have I poured out mine indignation upon them; I have consumed them with the fire of my wrath: their own way have I recompensed upon their heads, saith the Lord God.
