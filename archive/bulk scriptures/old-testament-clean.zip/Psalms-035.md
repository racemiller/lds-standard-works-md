# Psalms 35

Psalms 35 (summary): David complains of his enemies and their wrong dealings—He asks the Lord to judge him according to his righteousness.

Psalms 35:1 Plead my cause, O Lord, with them that strive with me: fight against them that fight against me.

Psalms 35:2 Take hold of shield and buckler, and stand up for mine help.

Psalms 35:3 Draw out also the spear, and stop the way against them that persecute me: say unto my soul, I am thy salvation.

Psalms 35:4 Let them be confounded and put to shame that seek after my soul: let them be turned back and brought to confusion that devise my hurt.

Psalms 35:5 Let them be as chaff before the wind: and let the angel of the Lord chase them.

Psalms 35:6 Let their way be dark and slippery: and let the angel of the Lord persecute them.

Psalms 35:7 For without cause have they hid for me their net in a pit, which without cause they have digged for my soul.

Psalms 35:8 Let destruction come upon him at unawares; and let his net that he hath hid catch himself: into that very destruction let him fall.

Psalms 35:9 And my soul shall be joyful in the Lord: it shall rejoice in his salvation.

Psalms 35:10 All my bones shall say, Lord, who is like unto thee, which deliverest the poor from him that is too strong for him, yea, the poor and the needy from him that spoileth him?

Psalms 35:11 False witnesses did rise up; they laid to my charge things that I knew not.

Psalms 35:12 They rewarded me evil for good to the spoiling of my soul.

Psalms 35:13 But as for me, when they were sick, my clothing was sackcloth: I humbled my soul with fasting; and my prayer returned into mine own bosom.

Psalms 35:14 I behaved myself as though he had been my friend or brother: I bowed down heavily, as one that mourneth for his mother.

Psalms 35:15 But in mine adversity they rejoiced, and gathered themselves together: yea, the abjects gathered themselves together against me, and I knew it not; they did tear me, and ceased not:

Psalms 35:16 With hypocritical mockers in feasts, they gnashed upon me with their teeth.

Psalms 35:17 Lord, how long wilt thou look on? rescue my soul from their destructions, my darling from the lions.

Psalms 35:18 I will give thee thanks in the great congregation: I will praise thee among much people.

Psalms 35:19 Let not them that are mine enemies wrongfully rejoice over me: neither let them wink with the eye that hate me without a cause.

Psalms 35:20 For they speak not peace: but they devise deceitful matters against them that are quiet in the land.

Psalms 35:21 Yea, they opened their mouth wide against me, and said, Aha, aha, our eye hath seen it.

Psalms 35:22 This thou hast seen, O Lord: keep not silence: O Lord, be not far from me.

Psalms 35:23 Stir up thyself, and awake to my judgment, even unto my cause, my God and my Lord.

Psalms 35:24 Judge me, O Lord my God, according to thy righteousness; and let them not rejoice over me.

Psalms 35:25 Let them not say in their hearts, Ah, so would we have it: let them not say, We have swallowed him up.

Psalms 35:26 Let them be ashamed and brought to confusion together that rejoice at mine hurt: let them be clothed with shame and dishonour that magnify themselves against me.

Psalms 35:27 Let them shout for joy, and be glad, that favour my righteous cause: yea, let them say continually, Let the Lord be magnified, which hath pleasure in the prosperity of his servant.

Psalms 35:28 And my tongue shall speak of thy righteousness and of thy praise all the day long.
