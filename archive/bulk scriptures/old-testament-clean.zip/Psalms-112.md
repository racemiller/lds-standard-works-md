# Psalms 112

Psalms 112 (summary): Blessed is the man who fears the Lord—The righteous will be remembered always.

Psalms 112:1 Praise ye the Lord. Blessed is the man that feareth the Lord, that delighteth greatly in his commandments.

Psalms 112:2 His seed shall be mighty upon earth: the generation of the upright shall be blessed.

Psalms 112:3 Wealth and riches shall be in his house: and his righteousness endureth for ever.

Psalms 112:4 Unto the upright there ariseth light in the darkness: he is gracious, and full of compassion, and righteous.

Psalms 112:5 A good man sheweth favour, and lendeth: he will guide his affairs with discretion.

Psalms 112:6 Surely he shall not be moved for ever: the righteous shall be in everlasting remembrance.

Psalms 112:7 He shall not be afraid of evil tidings: his heart is fixed, trusting in the Lord.

Psalms 112:8 His heart is established, he shall not be afraid, until he see his desire upon his enemies.

Psalms 112:9 He hath dispersed, he hath given to the poor; his righteousness endureth for ever; his horn shall be exalted with honour.

Psalms 112:10 The wicked shall see it, and be grieved; he shall gnash with his teeth, and melt away: the desire of the wicked shall perish.
