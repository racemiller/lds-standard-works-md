# Proverbs 28

Proverbs 28 (summary): The wicked flee when no man pursues—Whoever walks uprightly will be saved—A faithful man will abound with blessings.

Proverbs 28:1 The wicked flee when no man pursueth: but the righteous are bold as a lion.

Proverbs 28:2 For the transgression of a land many are the princes thereof: but by a man of understanding and knowledge the state thereof shall be prolonged.

Proverbs 28:3 A poor man that oppresseth the poor is like a sweeping rain which leaveth no food.

Proverbs 28:4 They that forsake the law praise the wicked: but such as keep the law contend with them.

Proverbs 28:5 Evil men understand not judgment: but they that seek the Lord understand all things.

Proverbs 28:6 Better is the poor that walketh in his uprightness, than he that is perverse in his ways, though he be rich.

Proverbs 28:7 Whoso keepeth the law is a wise son: but he that is a companion of riotous men shameth his father.

Proverbs 28:8 He that by usury and unjust gain increaseth his substance, he shall gather it for him that will pity the poor.

Proverbs 28:9 He that turneth away his ear from hearing the law, even his prayer shall be abomination.

Proverbs 28:10 Whoso causeth the righteous to go astray in an evil way, he shall fall himself into his own pit: but the upright shall have good things in possession.

Proverbs 28:11 The rich man is wise in his own conceit; but the poor that hath understanding searcheth him out.

Proverbs 28:12 When righteous men do rejoice, there is great glory: but when the wicked rise, a man is hidden.

Proverbs 28:13 He that covereth his sins shall not prosper: but whoso confesseth and forsaketh them shall have mercy.

Proverbs 28:14 Happy is the man that feareth alway: but he that hardeneth his heart shall fall into mischief.

Proverbs 28:15 As a roaring lion, and a ranging bear; so is a wicked ruler over the poor people.

Proverbs 28:16 The prince that wanteth understanding is also a great oppressor: but he that hateth covetousness shall prolong his days.

Proverbs 28:17 A man that doeth violence to the blood of any person shall flee to the pit; let no man stay him.

Proverbs 28:18 Whoso walketh uprightly shall be saved: but he that is perverse in his ways shall fall at once.

Proverbs 28:19 He that tilleth his land shall have plenty of bread: but he that followeth after vain persons shall have poverty enough.

Proverbs 28:20 A faithful man shall abound with blessings: but he that maketh haste to be rich shall not be innocent.

Proverbs 28:21 To have respect of persons is not good: for for a piece of bread that man will transgress.

Proverbs 28:22 He that hasteth to be rich hath an evil eye, and considereth not that poverty shall come upon him.

Proverbs 28:23 He that rebuketh a man afterwards shall find more favour than he that flattereth with the tongue.

Proverbs 28:24 Whoso robbeth his father or his mother, and saith, It is no transgression; the same is the companion of a destroyer.

Proverbs 28:25 He that is of a proud heart stirreth up strife: but he that putteth his trust in the Lord shall be made fat.

Proverbs 28:26 He that trusteth in his own heart is a fool: but whoso walketh wisely, he shall be delivered.

Proverbs 28:27 He that giveth unto the poor shall not lack: but he that hideth his eyes shall have many a curse.

Proverbs 28:28 When the wicked rise, men hide themselves: but when they perish, the righteous increase.
