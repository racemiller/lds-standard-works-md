# Psalms 48

Psalms 48 (summary): Zion, the city of God, the joy of the whole earth, will be established forever.

Psalms 48:1 Great is the Lord, and greatly to be praised in the city of our God, in the mountain of his holiness.

Psalms 48:2 Beautiful for situation, the joy of the whole earth, is mount Zion, on the sides of the north, the city of the great King.

Psalms 48:3 God is known in her palaces for a refuge.

Psalms 48:4 For, lo, the kings were assembled, they passed by together.

Psalms 48:5 They saw it, and so they marvelled; they were troubled, and hasted away.

Psalms 48:6 Fear took hold upon them there, and pain, as of a woman in travail.

Psalms 48:7 Thou breakest the ships of Tarshish with an east wind.

Psalms 48:8 As we have heard, so have we seen in the city of the Lord of hosts, in the city of our God: God will establish it for ever. Selah.

Psalms 48:9 We have thought of thy lovingkindness, O God, in the midst of thy temple.

Psalms 48:10 According to thy name, O God, so is thy praise unto the ends of the earth: thy right hand is full of righteousness.

Psalms 48:11 Let mount Zion rejoice, let the daughters of Judah be glad, because of thy judgments.

Psalms 48:12 Walk about Zion, and go round about her: tell the towers thereof.

Psalms 48:13 Mark ye well her bulwarks, consider her palaces; that ye may tell it to the generation following.

Psalms 48:14 For this God is our God for ever and ever: he will be our guide even unto death.
