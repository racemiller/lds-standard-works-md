# Joshua 11

Joshua 11 (summary): Joshua and Israel conquer the whole land, destroying many cities and nations.

Joshua 11:1 And it came to pass, when Jabin king of Hazor had heard those things, that he sent to Jobab king of Madon, and to the king of Shimron, and to the king of Achshaph,

Joshua 11:2 And to the kings that were on the north of the mountains, and of the plains south of Chinneroth, and in the valley, and in the borders of Dor on the west,

Joshua 11:3 And to the Canaanite on the east and on the west, and to the Amorite, and the Hittite, and the Perizzite, and the Jebusite in the mountains, and to the Hivite under Hermon in the land of Mizpeh.

Joshua 11:4 And they went out, they and all their hosts with them, much people, even as the sand that is upon the sea shore in multitude, with horses and chariots very many.

Joshua 11:5 And when all these kings were met together, they came and pitched together at the waters of Merom, to fight against Israel.

Joshua 11:6 And the Lord said unto Joshua, Be not afraid because of them: for to morrow about this time will I deliver them up all slain before Israel: thou shalt hough their horses, and burn their chariots with fire.

Joshua 11:7 So Joshua came, and all the people of war with him, against them by the waters of Merom suddenly; and they fell upon them.

Joshua 11:8 And the Lord delivered them into the hand of Israel, who smote them, and chased them unto great Zidon, and unto Misrephoth-maim, and unto the valley of Mizpeh eastward; and they smote them, until they left them none remaining.

Joshua 11:9 And Joshua did unto them as the Lord bade him: he houghed their horses, and burnt their chariots with fire.

Joshua 11:10 And Joshua at that time turned back, and took Hazor, and smote the king thereof with the sword: for Hazor beforetime was the head of all those kingdoms.

Joshua 11:11 And they smote all the souls that were therein with the edge of the sword, utterly destroying them: there was not any left to breathe: and he burnt Hazor with fire.

Joshua 11:12 And all the cities of those kings, and all the kings of them, did Joshua take, and smote them with the edge of the sword, and he utterly destroyed them, as Moses the servant of the Lord commanded.

Joshua 11:13 But as for the cities that stood still in their strength, Israel burned none of them, save Hazor only; that did Joshua burn.

Joshua 11:14 And all the spoil of these cities, and the cattle, the children of Israel took for a prey unto themselves; but every man they smote with the edge of the sword, until they had destroyed them, neither left they any to breathe.

Joshua 11:15 As the Lord commanded Moses his servant, so did Moses command Joshua, and so did Joshua; he left nothing undone of all that the Lord commanded Moses.

Joshua 11:16 So Joshua took all that land, the hills, and all the south country, and all the land of Goshen, and the valley, and the plain, and the mountain of Israel, and the valley of the same;

Joshua 11:17 Even from the mount Halak, that goeth up to Seir, even unto Baal-gad in the valley of Lebanon under mount Hermon: and all their kings he took, and smote them, and slew them.

Joshua 11:18 Joshua made war a long time with all those kings.

Joshua 11:19 There was not a city that made peace with the children of Israel, save the Hivites the inhabitants of Gibeon: all other they took in battle.

Joshua 11:20 For it was of the Lord to harden their hearts, that they should come against Israel in battle, that he might destroy them utterly, and that they might have no favour, but that he might destroy them, as the Lord commanded Moses.

Joshua 11:21 And at that time came Joshua, and cut off the Anakims from the mountains, from Hebron, from Debir, from Anab, and from all the mountains of Judah, and from all the mountains of Israel: Joshua destroyed them utterly with their cities.

Joshua 11:22 There was none of the Anakims left in the land of the children of Israel: only in Gaza, in Gath, and in Ashdod, there remained.

Joshua 11:23 So Joshua took the whole land, according to all that the Lord said unto Moses; and Joshua gave it for an inheritance unto Israel according to their divisions by their tribes. And the land rested from war.
