# Genesis 15

Genesis 15 (summary): Abram desires offspring—The Lord promises him seed in number as the stars—Abram believes the promise—His seed will be strangers in Egypt—Then, after four generations, they will inherit Canaan.

Genesis 15:1 After these things the word of the Lord came unto Abram in a vision, saying, Fear not, Abram: I am thy shield, and thy exceeding great reward.

Genesis 15:2 And Abram said, Lord God, what wilt thou give me, seeing I go childless, and the steward of my house is this Eliezer of Damascus?

Genesis 15:3 And Abram said, Behold, to me thou hast given no seed: and, lo, one born in my house is mine heir.

Genesis 15:4 And, behold, the word of the Lord came unto him, saying, This shall not be thine heir; but he that shall come forth out of thine own bowels shall be thine heir.

Genesis 15:5 And he brought him forth abroad, and said, Look now toward heaven, and tell the stars, if thou be able to number them: and he said unto him, So shall thy seed be.

Genesis 15:6 And he believed in the Lord; and he counted it to him for righteousness.

Genesis 15:7 And he said unto him, I am the Lord that brought thee out of Ur of the Chaldees, to give thee this land to inherit it.

Genesis 15:8 And he said, Lord God, whereby shall I know that I shall inherit it?

Genesis 15:9 And he said unto him, Take me an heifer of three years old, and a she goat of three years old, and a ram of three years old, and a turtledove, and a young pigeon.

Genesis 15:10 And he took unto him all these, and divided them in the midst, and laid each piece one against another: but the birds divided he not.

Genesis 15:11 And when the fowls came down upon the carcases, Abram drove them away.

Genesis 15:12 And when the sun was going down, a deep sleep fell upon Abram; and, lo, an horror of great darkness fell upon him.

Genesis 15:13 And he said unto Abram, Know of a surety that thy seed shall be a stranger in a land that is not theirs, and shall serve them; and they shall afflict them four hundred years;

Genesis 15:14 And also that nation, whom they shall serve, will I judge: and afterward shall they come out with great substance.

Genesis 15:15 And thou shalt go to thy fathers in peace; thou shalt be buried in a good old age.

Genesis 15:16 But in the fourth generation they shall come hither again: for the iniquity of the Amorites is not yet full.

Genesis 15:17 And it came to pass, that, when the sun went down, and it was dark, behold a smoking furnace, and a burning lamp that passed between those pieces.

Genesis 15:18 In the same day the Lord made a covenant with Abram, saying, Unto thy seed have I given this land, from the river of Egypt unto the great river, the river Euphrates:

Genesis 15:19 The Kenites, and the Kenizzites, and the Kadmonites,

Genesis 15:20 And the Hittites, and the Perizzites, and the Rephaims,

Genesis 15:21 And the Amorites, and the Canaanites, and the Girgashites, and the Jebusites.
