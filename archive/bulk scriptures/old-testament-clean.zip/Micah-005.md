# Micah 5

Micah 5 (summary): The Messiah will be born in Bethlehem—In the last days, the remnant of Jacob will triumph gloriously over the Gentiles.

Micah 5:1 Now gather thyself in troops, O daughter of troops: he hath laid siege against us: they shall smite the judge of Israel with a rod upon the cheek.

Micah 5:2 But thou, Beth-lehem Ephratah, though thou be little among the thousands of Judah, yet out of thee shall he come forth unto me that is to be ruler in Israel; whose goings forth have been from of old, from everlasting.

Micah 5:3 Therefore will he give them up, until the time that she which travaileth hath brought forth: then the remnant of his brethren shall return unto the children of Israel.

Micah 5:4 And he shall stand and feed in the strength of the Lord, in the majesty of the name of the Lord his God; and they shall abide: for now shall he be great unto the ends of the earth.

Micah 5:5 And this man shall be the peace, when the Assyrian shall come into our land: and when he shall tread in our palaces, then shall we raise against him seven shepherds, and eight principal men.

Micah 5:6 And they shall waste the land of Assyria with the sword, and the land of Nimrod in the entrances thereof: thus shall he deliver us from the Assyrian, when he cometh into our land, and when he treadeth within our borders.

Micah 5:7 And the remnant of Jacob shall be in the midst of many people as a dew from the Lord, as the showers upon the grass, that tarrieth not for man, nor waiteth for the sons of men.

Micah 5:8 And the remnant of Jacob shall be among the Gentiles in the midst of many people as a lion among the beasts of the forest, as a young lion among the flocks of sheep: who, if he go through, both treadeth down, and teareth in pieces, and none can deliver.

Micah 5:9 Thine hand shall be lifted up upon thine adversaries, and all thine enemies shall be cut off.

Micah 5:10 And it shall come to pass in that day, saith the Lord, that I will cut off thy horses out of the midst of thee, and I will destroy thy chariots:

Micah 5:11 And I will cut off the cities of thy land, and throw down all thy strong holds:

Micah 5:12 And I will cut off witchcrafts out of thine hand; and thou shalt have no more soothsayers:

Micah 5:13 Thy graven images also will I cut off, and thy standing images out of the midst of thee; and thou shalt no more worship the work of thine hands.

Micah 5:14 And I will pluck up thy groves out of the midst of thee: so will I destroy thy cities.

Micah 5:15 And I will execute vengeance in anger and fury upon the heathen, such as they have not heard.
