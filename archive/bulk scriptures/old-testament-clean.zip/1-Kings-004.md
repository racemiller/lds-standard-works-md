# 1 Kings 4

1 Kings 4 (summary): The officers in Solomon’s court are listed—Solomon reigns in peace and prosperity over a large kingdom—His wisdom and understanding exceed that of all men.

1 Kings 4:1 So king Solomon was king over all Israel.

1 Kings 4:2 And these were the princes which he had; Azariah the son of Zadok the priest,

1 Kings 4:3 Elihoreph and Ahiah, the sons of Shisha, scribes; Jehoshaphat the son of Ahilud, the recorder.

1 Kings 4:4 And Benaiah the son of Jehoiada was over the host: and Zadok and Abiathar were the priests:

1 Kings 4:5 And Azariah the son of Nathan was over the officers: and Zabud the son of Nathan was principal officer, and the king’s friend:

1 Kings 4:6 And Ahishar was over the household: and Adoniram the son of Abda was over the tribute.

1 Kings 4:7 And Solomon had twelve officers over all Israel, which provided victuals for the king and his household: each man his month in a year made provision.

1 Kings 4:8 And these are their names: The son of Hur, in mount Ephraim:

1 Kings 4:9 The son of Dekar, in Makaz, and in Shaalbim, and Beth-shemesh, and Elon-beth-hanan:

1 Kings 4:10 The son of Hesed, in Aruboth; to him pertained Sochoh, and all the land of Hepher:

1 Kings 4:11 The son of Abinadab, in all the region of Dor; which had Taphath the daughter of Solomon to wife:

1 Kings 4:12 Baana the son of Ahilud; to him pertained Taanach and Megiddo, and all Beth-shean, which is by Zartanah beneath Jezreel, from Beth-shean to Abel-meholah, even unto the place that is beyond Jokneam:

1 Kings 4:13 The son of Geber, in Ramoth-gilead; to him pertained the towns of Jair the son of Manasseh, which are in Gilead; to him also pertained the region of Argob, which is in Bashan, threescore great cities with walls and brasen bars:

1 Kings 4:14 Ahinadab the son of Iddo had Mahanaim:

1 Kings 4:15 Ahimaaz was in Naphtali; he also took Basmath the daughter of Solomon to wife:

1 Kings 4:16 Baanah the son of Hushai was in Asher and in Aloth:

1 Kings 4:17 Jehoshaphat the son of Paruah, in Issachar:

1 Kings 4:18 Shimei the son of Elah, in Benjamin:

1 Kings 4:19 Geber the son of Uri was in the country of Gilead, in the country of Sihon king of the Amorites, and of Og king of Bashan; and he was the only officer which was in the land.

1 Kings 4:20 Judah and Israel were many, as the sand which is by the sea in multitude, eating and drinking, and making merry.

1 Kings 4:21 And Solomon reigned over all kingdoms from the river unto the land of the Philistines, and unto the border of Egypt: they brought presents, and served Solomon all the days of his life.

1 Kings 4:22 And Solomon’s provision for one day was thirty measures of fine flour, and threescore measures of meal,

1 Kings 4:23 Ten fat oxen, and twenty oxen out of the pastures, and an hundred sheep, beside harts, and roebucks, and fallowdeer, and fatted fowl.

1 Kings 4:24 For he had dominion over all the region on this side the river, from Tiphsah even to Azzah, over all the kings on this side the river: and he had peace on all sides round about him.

1 Kings 4:25 And Judah and Israel dwelt safely, every man under his vine and under his fig tree, from Dan even to Beer-sheba, all the days of Solomon.

1 Kings 4:26 And Solomon had forty thousand stalls of horses for his chariots, and twelve thousand horsemen.

1 Kings 4:27 And those officers provided victual for king Solomon, and for all that came unto king Solomon’s table, every man in his month: they lacked nothing.

1 Kings 4:28 Barley also and straw for the horses and dromedaries brought they unto the place where the officers were, every man according to his charge.

1 Kings 4:29 And God gave Solomon wisdom and understanding exceeding much, and largeness of heart, even as the sand that is on the sea shore.

1 Kings 4:30 And Solomon’s wisdom excelled the wisdom of all the children of the east country, and all the wisdom of Egypt.

1 Kings 4:31 For he was wiser than all men; than Ethan the Ezrahite, and Heman, and Chalcol, and Darda, the sons of Mahol: and his fame was in all nations round about.

1 Kings 4:32 And he spake three thousand proverbs: and his songs were a thousand and five.

1 Kings 4:33 And he spake of trees, from the cedar tree that is in Lebanon even unto the hyssop that springeth out of the wall: he spake also of beasts, and of fowl, and of creeping things, and of fishes.

1 Kings 4:34 And there came of all people to hear the wisdom of Solomon, from all kings of the earth, which had heard of his wisdom.
