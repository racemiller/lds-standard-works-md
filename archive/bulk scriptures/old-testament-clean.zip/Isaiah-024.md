# Isaiah 24

Isaiah 24 (summary): Men will transgress the law and break the everlasting covenant—At the Second Coming, they will be burned, the earth will reel, and the sun will be ashamed—Then the Lord will reign in Zion and in Jerusalem.

Isaiah 24:1 Behold, the Lord maketh the earth empty, and maketh it waste, and turneth it upside down, and scattereth abroad the inhabitants thereof.

Isaiah 24:2 And it shall be, as with the people, so with the priest; as with the servant, so with his master; as with the maid, so with her mistress; as with the buyer, so with the seller; as with the lender, so with the borrower; as with the taker of usury, so with the giver of usury to him.

Isaiah 24:3 The land shall be utterly emptied, and utterly spoiled: for the Lord hath spoken this word.

Isaiah 24:4 The earth mourneth and fadeth away, the world languisheth and fadeth away, the haughty people of the earth do languish.

Isaiah 24:5 The earth also is defiled under the inhabitants thereof; because they have transgressed the laws, changed the ordinance, broken the everlasting covenant.

Isaiah 24:6 Therefore hath the curse devoured the earth, and they that dwell therein are desolate: therefore the inhabitants of the earth are burned, and few men left.

Isaiah 24:7 The new wine mourneth, the vine languisheth, all the merryhearted do sigh.

Isaiah 24:8 The mirth of tabrets ceaseth, the noise of them that rejoice endeth, the joy of the harp ceaseth.

Isaiah 24:9 They shall not drink wine with a song; strong drink shall be bitter to them that drink it.

Isaiah 24:10 The city of confusion is broken down: every house is shut up, that no man may come in.

Isaiah 24:11 There is a crying for wine in the streets; all joy is darkened, the mirth of the land is gone.

Isaiah 24:12 In the city is left desolation, and the gate is smitten with destruction.

Isaiah 24:13 When thus it shall be in the midst of the land among the people, there shall be as the shaking of an olive tree, and as the gleaning grapes when the vintage is done.

Isaiah 24:14 They shall lift up their voice, they shall sing for the majesty of the Lord, they shall cry aloud from the sea.

Isaiah 24:15 Wherefore glorify ye the Lord in the fires, even the name of the Lord God of Israel in the isles of the sea.

Isaiah 24:16 From the uttermost part of the earth have we heard songs, even glory to the righteous. But I said, My leanness, my leanness, woe unto me! the treacherous dealers have dealt treacherously; yea, the treacherous dealers have dealt very treacherously.

Isaiah 24:17 Fear, and the pit, and the snare, are upon thee, O inhabitant of the earth.

Isaiah 24:18 And it shall come to pass, that he who fleeth from the noise of the fear shall fall into the pit; and he that cometh up out of the midst of the pit shall be taken in the snare: for the windows from on high are open, and the foundations of the earth do shake.

Isaiah 24:19 The earth is utterly broken down, the earth is clean dissolved, the earth is moved exceedingly.

Isaiah 24:20 The earth shall reel to and fro like a drunkard, and shall be removed like a cottage; and the transgression thereof shall be heavy upon it; and it shall fall, and not rise again.

Isaiah 24:21 And it shall come to pass in that day, that the Lord shall punish the host of the high ones that are on high, and the kings of the earth upon the earth.

Isaiah 24:22 And they shall be gathered together, as prisoners are gathered in the pit, and shall be shut up in the prison, and after many days shall they be visited.

Isaiah 24:23 Then the moon shall be confounded, and the sun ashamed, when the Lord of hosts shall reign in mount Zion, and in Jerusalem, and before his ancients gloriously.
