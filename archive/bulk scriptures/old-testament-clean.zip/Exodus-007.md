# Exodus 7

Exodus 7 (summary): Moses is appointed to give the word of the Lord to Pharaoh—The Lord will multiply signs and wonders in Egypt—Aaron’s rod becomes a serpent—The river is turned into blood—The magicians imitate the miracles of Moses and Aaron.

Exodus 7:1 And the Lord said unto Moses, See, I have made thee a god to Pharaoh: and Aaron thy brother shall be thy prophet.

Exodus 7:2 Thou shalt speak all that I command thee: and Aaron thy brother shall speak unto Pharaoh, that he send the children of Israel out of his land.

Exodus 7:3 And I will harden Pharaoh’s heart, and multiply my signs and my wonders in the land of Egypt.

Exodus 7:4 But Pharaoh shall not hearken unto you, that I may lay my hand upon Egypt, and bring forth mine armies, and my people the children of Israel, out of the land of Egypt by great judgments.

Exodus 7:5 And the Egyptians shall know that I am the Lord, when I stretch forth mine hand upon Egypt, and bring out the children of Israel from among them.

Exodus 7:6 And Moses and Aaron did as the Lord commanded them, so did they.

Exodus 7:7 And Moses was fourscore years old, and Aaron fourscore and three years old, when they spake unto Pharaoh.

Exodus 7:8 And the Lord spake unto Moses and unto Aaron, saying,

Exodus 7:9 When Pharaoh shall speak unto you, saying, Shew a miracle for you: then thou shalt say unto Aaron, Take thy rod, and cast it before Pharaoh, and it shall become a serpent.

Exodus 7:10 And Moses and Aaron went in unto Pharaoh, and they did so as the Lord had commanded: and Aaron cast down his rod before Pharaoh, and before his servants, and it became a serpent.

Exodus 7:11 Then Pharaoh also called the wise men and the sorcerers: now the magicians of Egypt, they also did in like manner with their enchantments.

Exodus 7:12 For they cast down every man his rod, and they became serpents: but Aaron’s rod swallowed up their rods.

Exodus 7:13 And he hardened Pharaoh’s heart, that he hearkened not unto them; as the Lord had said.

Exodus 7:14 And the Lord said unto Moses, Pharaoh’s heart is hardened, he refuseth to let the people go.

Exodus 7:15 Get thee unto Pharaoh in the morning; lo, he goeth out unto the water; and thou shalt stand by the river’s brink against he come; and the rod which was turned to a serpent shalt thou take in thine hand.

Exodus 7:16 And thou shalt say unto him, The Lord God of the Hebrews hath sent me unto thee, saying, Let my people go, that they may serve me in the wilderness: and, behold, hitherto thou wouldest not hear.

Exodus 7:17 Thus saith the Lord, In this thou shalt know that I am the Lord: behold, I will smite with the rod that is in mine hand upon the waters which are in the river, and they shall be turned to blood.

Exodus 7:18 And the fish that is in the river shall die, and the river shall stink; and the Egyptians shall lothe to drink of the water of the river.

Exodus 7:19 And the Lord spake unto Moses, Say unto Aaron, Take thy rod, and stretch out thine hand upon the waters of Egypt, upon their streams, upon their rivers, and upon their ponds, and upon all their pools of water, that they may become blood; and that there may be blood throughout all the land of Egypt, both in vessels of wood, and in vessels of stone.

Exodus 7:20 And Moses and Aaron did so, as the Lord commanded; and he lifted up the rod, and smote the waters that were in the river, in the sight of Pharaoh, and in the sight of his servants; and all the waters that were in the river were turned to blood.

Exodus 7:21 And the fish that was in the river died; and the river stank, and the Egyptians could not drink of the water of the river; and there was blood throughout all the land of Egypt.

Exodus 7:22 And the magicians of Egypt did so with their enchantments: and Pharaoh’s heart was hardened, neither did he hearken unto them; as the Lord had said.

Exodus 7:23 And Pharaoh turned and went into his house, neither did he set his heart to this also.

Exodus 7:24 And all the Egyptians digged round about the river for water to drink; for they could not drink of the water of the river.

Exodus 7:25 And seven days were fulfilled, after that the Lord had smitten the river.
