# Psalms 20

Psalms 20 (summary): David prays that the Lord will hear in time of trouble—The Lord saves His anointed.

Psalms 20:1 The Lord hear thee in the day of trouble; the name of the God of Jacob defend thee;

Psalms 20:2 Send thee help from the sanctuary, and strengthen thee out of Zion;

Psalms 20:3 Remember all thy offerings, and accept thy burnt sacrifice; Selah.

Psalms 20:4 Grant thee according to thine own heart, and fulfil all thy counsel.

Psalms 20:5 We will rejoice in thy salvation, and in the name of our God we will set up our banners: the Lord fulfil all thy petitions.

Psalms 20:6 Now know I that the Lord saveth his anointed; he will hear him from his holy heaven with the saving strength of his right hand.

Psalms 20:7 Some trust in chariots, and some in horses: but we will remember the name of the Lord our God.

Psalms 20:8 They are brought down and fallen: but we are risen, and stand upright.

Psalms 20:9 Save, Lord: let the king hear us when we call.
