# Psalms 110

Psalms 110 (summary): A messianic psalm of David—Christ will sit on the Lord’s right hand—He will be a priest forever after the order of Melchizedek.

Psalms 110:1 The Lord said unto my Lord, Sit thou at my right hand, until I make thine enemies thy footstool.

Psalms 110:2 The Lord shall send the rod of thy strength out of Zion: rule thou in the midst of thine enemies.

Psalms 110:3 Thy people shall be willing in the day of thy power, in the beauties of holiness from the womb of the morning: thou hast the dew of thy youth.

Psalms 110:4 The Lord hath sworn, and will not repent, Thou art a priest for ever after the order of Melchizedek.

Psalms 110:5 The Lord at thy right hand shall strike through kings in the day of his wrath.

Psalms 110:6 He shall judge among the heathen, he shall fill the places with the dead bodies; he shall wound the heads over many countries.

Psalms 110:7 He shall drink of the brook in the way: therefore shall he lift up the head.
