# Numbers 34

Numbers 34 (summary): Moses specifies the borders of Israel’s inheritance in Canaan and names the princes of the tribes who will divide the land.

Numbers 34:1 And the Lord spake unto Moses, saying,

Numbers 34:2 Command the children of Israel, and say unto them, When ye come into the land of Canaan; (this is the land that shall fall unto you for an inheritance, even the land of Canaan with the coasts thereof:)

Numbers 34:3 Then your south quarter shall be from the wilderness of Zin along by the coast of Edom, and your south border shall be the outmost coast of the salt sea eastward:

Numbers 34:4 And your border shall turn from the south to the ascent of Akrabbim, and pass on to Zin: and the going forth thereof shall be from the south to Kadesh-barnea, and shall go on to Hazar-addar, and pass on to Azmon:

Numbers 34:5 And the border shall fetch a compass from Azmon unto the river of Egypt, and the goings out of it shall be at the sea.

Numbers 34:6 And as for the western border, ye shall even have the great sea for a border: this shall be your west border.

Numbers 34:7 And this shall be your north border: from the great sea ye shall point out for you mount Hor:

Numbers 34:8 From mount Hor ye shall point out your border unto the entrance of Hamath; and the goings forth of the border shall be to Zedad:

Numbers 34:9 And the border shall go on to Ziphron, and the goings out of it shall be at Hazar-enan: this shall be your north border.

Numbers 34:10 And ye shall point out your east border from Hazar-enan to Shepham:

Numbers 34:11 And the coast shall go down from Shepham to Riblah, on the east side of Ain; and the border shall descend, and shall reach unto the side of the sea of Chinnereth eastward:

Numbers 34:12 And the border shall go down to Jordan, and the goings out of it shall be at the salt sea: this shall be your land with the coasts thereof round about.

Numbers 34:13 And Moses commanded the children of Israel, saying, This is the land which ye shall inherit by lot, which the Lord commanded to give unto the nine tribes, and to the half tribe:

Numbers 34:14 For the tribe of the children of Reuben according to the house of their fathers, and the tribe of the children of Gad according to the house of their fathers, have received their inheritance; and half the tribe of Manasseh have received their inheritance:

Numbers 34:15 The two tribes and the half tribe have received their inheritance on this side Jordan near Jericho eastward, toward the sunrising.

Numbers 34:16 And the Lord spake unto Moses, saying,

Numbers 34:17 These are the names of the men which shall divide the land unto you: Eleazar the priest, and Joshua the son of Nun.

Numbers 34:18 And ye shall take one prince of every tribe, to divide the land by inheritance.

Numbers 34:19 And the names of the men are these: Of the tribe of Judah, Caleb the son of Jephunneh.

Numbers 34:20 And of the tribe of the children of Simeon, Shemuel the son of Ammihud.

Numbers 34:21 Of the tribe of Benjamin, Elidad the son of Chislon.

Numbers 34:22 And the prince of the tribe of the children of Dan, Bukki the son of Jogli.

Numbers 34:23 The prince of the children of Joseph, for the tribe of the children of Manasseh, Hanniel the son of Ephod.

Numbers 34:24 And the prince of the tribe of the children of Ephraim, Kemuel the son of Shiphtan.

Numbers 34:25 And the prince of the tribe of the children of Zebulun, Elizaphan the son of Parnach.

Numbers 34:26 And the prince of the tribe of the children of Issachar, Paltiel the son of Azzan.

Numbers 34:27 And the prince of the tribe of the children of Asher, Ahihud the son of Shelomi.

Numbers 34:28 And the prince of the tribe of the children of Naphtali, Pedahel the son of Ammihud.

Numbers 34:29 These are they whom the Lord commanded to divide the inheritance unto the children of Israel in the land of Canaan.
