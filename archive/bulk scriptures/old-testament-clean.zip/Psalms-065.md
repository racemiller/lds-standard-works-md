# Psalms 65

Psalms 65 (summary): David speaks of the blessedness of God’s chosen—The Lord sends rain and good things upon the earth.

Psalms 65:1 Praise waiteth for thee, O God, in Sion: and unto thee shall the vow be performed.

Psalms 65:2 O thou that hearest prayer, unto thee shall all flesh come.

Psalms 65:3 Iniquities prevail against me: as for our transgressions, thou shalt purge them away.

Psalms 65:4 Blessed is the man whom thou choosest, and causest to approach unto thee, that he may dwell in thy courts: we shall be satisfied with the goodness of thy house, even of thy holy temple.

Psalms 65:5 By terrible things in righteousness wilt thou answer us, O God of our salvation; who art the confidence of all the ends of the earth, and of them that are afar off upon the sea:

Psalms 65:6 Which by his strength setteth fast the mountains; being girded with power:

Psalms 65:7 Which stilleth the noise of the seas, the noise of their waves, and the tumult of the people.

Psalms 65:8 They also that dwell in the uttermost parts are afraid at thy tokens: thou makest the outgoings of the morning and evening to rejoice.

Psalms 65:9 Thou visitest the earth, and waterest it: thou greatly enrichest it with the river of God, which is full of water: thou preparest them corn, when thou hast so provided for it.

Psalms 65:10 Thou waterest the ridges thereof abundantly: thou settlest the furrows thereof: thou makest it soft with showers: thou blessest the springing thereof.

Psalms 65:11 Thou crownest the year with thy goodness; and thy paths drop fatness.

Psalms 65:12 They drop upon the pastures of the wilderness: and the little hills rejoice on every side.

Psalms 65:13 The pastures are clothed with flocks; the valleys also are covered over with corn; they shout for joy, they also sing.
