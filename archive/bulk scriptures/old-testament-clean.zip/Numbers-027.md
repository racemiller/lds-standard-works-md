# Numbers 27

Numbers 27 (summary): The law of inheritances to sons, daughters, and kinsmen is explained—Moses will see but not enter the promised land—Joshua is called and set apart to lead Israel.

Numbers 27:1 Then came the daughters of Zelophehad, the son of Hepher, the son of Gilead, the son of Machir, the son of Manasseh, of the families of Manasseh the son of Joseph: and these are the names of his daughters; Mahlah, Noah, and Hoglah, and Milcah, and Tirzah.

Numbers 27:2 And they stood before Moses, and before Eleazar the priest, and before the princes and all the congregation, by the door of the tabernacle of the congregation, saying,

Numbers 27:3 Our father died in the wilderness, and he was not in the company of them that gathered themselves together against the Lord in the company of Korah; but died in his own sin, and had no sons.

Numbers 27:4 Why should the name of our father be done away from among his family, because he hath no son? Give unto us therefore a possession among the brethren of our father.

Numbers 27:5 And Moses brought their cause before the Lord.

Numbers 27:6 And the Lord spake unto Moses, saying,

Numbers 27:7 The daughters of Zelophehad speak right: thou shalt surely give them a possession of an inheritance among their father’s brethren; and thou shalt cause the inheritance of their father to pass unto them.

Numbers 27:8 And thou shalt speak unto the children of Israel, saying, If a man die, and have no son, then ye shall cause his inheritance to pass unto his daughter.

Numbers 27:9 And if he have no daughter, then ye shall give his inheritance unto his brethren.

Numbers 27:10 And if he have no brethren, then ye shall give his inheritance unto his father’s brethren.

Numbers 27:11 And if his father have no brethren, then ye shall give his inheritance unto his kinsman that is next to him of his family, and he shall possess it: and it shall be unto the children of Israel a statute of judgment, as the Lord commanded Moses.

Numbers 27:12 And the Lord said unto Moses, Get thee up into this mount Abarim, and see the land which I have given unto the children of Israel.

Numbers 27:13 And when thou hast seen it, thou also shalt be gathered unto thy people, as Aaron thy brother was gathered.

Numbers 27:14 For ye rebelled against my commandment in the desert of Zin, in the strife of the congregation, to sanctify me at the water before their eyes: that is the water of Meribah in Kadesh in the wilderness of Zin.

Numbers 27:15 And Moses spake unto the Lord, saying,

Numbers 27:16 Let the Lord, the God of the spirits of all flesh, set a man over the congregation,

Numbers 27:17 Which may go out before them, and which may go in before them, and which may lead them out, and which may bring them in; that the congregation of the Lord be not as sheep which have no shepherd.

Numbers 27:18 And the Lord said unto Moses, Take thee Joshua the son of Nun, a man in whom is the spirit, and lay thine hand upon him;

Numbers 27:19 And set him before Eleazar the priest, and before all the congregation; and give him a charge in their sight.

Numbers 27:20 And thou shalt put some of thine honour upon him, that all the congregation of the children of Israel may be obedient.

Numbers 27:21 And he shall stand before Eleazar the priest, who shall ask counsel for him after the judgment of Urim before the Lord: at his word shall they go out, and at his word they shall come in, both he, and all the children of Israel with him, even all the congregation.

Numbers 27:22 And Moses did as the Lord commanded him: and he took Joshua, and set him before Eleazar the priest, and before all the congregation:

Numbers 27:23 And he laid his hands upon him, and gave him a charge, as the Lord commanded by the hand of Moses.
