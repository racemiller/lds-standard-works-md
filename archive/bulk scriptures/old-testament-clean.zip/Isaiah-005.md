# Isaiah 5

Isaiah 5 (summary): The Lord’s vineyard (Israel) will become desolate, and His people will be scattered—Woes will come upon them in their apostate and scattered state—The Lord will lift an ensign and gather Israel—Compare 2 Nephi 15.

Isaiah 5:1 Now will I sing to my wellbeloved a song of my beloved touching his vineyard. My wellbeloved hath a vineyard in a very fruitful hill:

Isaiah 5:2 And he fenced it, and gathered out the stones thereof, and planted it with the choicest vine, and built a tower in the midst of it, and also made a winepress therein: and he looked that it should bring forth grapes, and it brought forth wild grapes.

Isaiah 5:3 And now, O inhabitants of Jerusalem, and men of Judah, judge, I pray you, betwixt me and my vineyard.

Isaiah 5:4 What could have been done more to my vineyard, that I have not done in it? wherefore, when I looked that it should bring forth grapes, brought it forth wild grapes?

Isaiah 5:5 And now go to; I will tell you what I will do to my vineyard: I will take away the hedge thereof, and it shall be eaten up; and break down the wall thereof, and it shall be trodden down:

Isaiah 5:6 And I will lay it waste: it shall not be pruned, nor digged; but there shall come up briers and thorns: I will also command the clouds that they rain no rain upon it.

Isaiah 5:7 For the vineyard of the Lord of hosts is the house of Israel, and the men of Judah his pleasant plant: and he looked for judgment, but behold oppression; for righteousness, but behold a cry.

Isaiah 5:8 Woe unto them that join house to house, that lay field to field, till there be no place, that they may be placed alone in the midst of the earth!

Isaiah 5:9 In mine ears said the Lord of hosts, Of a truth many houses shall be desolate, even great and fair, without inhabitant.

Isaiah 5:10 Yea, ten acres of vineyard shall yield one bath, and the seed of an homer shall yield an ephah.

Isaiah 5:11 Woe unto them that rise up early in the morning, that they may follow strong drink; that continue until night, till wine inflame them!

Isaiah 5:12 And the harp, and the viol, the tabret, and pipe, and wine, are in their feasts: but they regard not the work of the Lord, neither consider the operation of his hands.

Isaiah 5:13 Therefore my people are gone into captivity, because they have no knowledge: and their honourable men are famished, and their multitude dried up with thirst.

Isaiah 5:14 Therefore hell hath enlarged herself, and opened her mouth without measure: and their glory, and their multitude, and their pomp, and he that rejoiceth, shall descend into it.

Isaiah 5:15 And the mean man shall be brought down, and the mighty man shall be humbled, and the eyes of the lofty shall be humbled:

Isaiah 5:16 But the Lord of hosts shall be exalted in judgment, and God that is holy shall be sanctified in righteousness.

Isaiah 5:17 Then shall the lambs feed after their manner, and the waste places of the fat ones shall strangers eat.

Isaiah 5:18 Woe unto them that draw iniquity with cords of vanity, and sin as it were with a cart rope:

Isaiah 5:19 That say, Let him make speed, and hasten his work, that we may see it: and let the counsel of the Holy One of Israel draw nigh and come, that we may know it!

Isaiah 5:20 Woe unto them that call evil good, and good evil; that put darkness for light, and light for darkness; that put bitter for sweet, and sweet for bitter!

Isaiah 5:21 Woe unto them that are wise in their own eyes, and prudent in their own sight!

Isaiah 5:22 Woe unto them that are mighty to drink wine, and men of strength to mingle strong drink:

Isaiah 5:23 Which justify the wicked for reward, and take away the righteousness of the righteous from him!

Isaiah 5:24 Therefore as the fire devoureth the stubble, and the flame consumeth the chaff, so their root shall be as rottenness, and their blossom shall go up as dust: because they have cast away the law of the Lord of hosts, and despised the word of the Holy One of Israel.

Isaiah 5:25 Therefore is the anger of the Lord kindled against his people, and he hath stretched forth his hand against them, and hath smitten them: and the hills did tremble, and their carcases were torn in the midst of the streets. For all this his anger is not turned away, but his hand is stretched out still.

Isaiah 5:26 And he will lift up an ensign to the nations from far, and will hiss unto them from the end of the earth: and, behold, they shall come with speed swiftly:

Isaiah 5:27 None shall be weary nor stumble among them; none shall slumber nor sleep; neither shall the girdle of their loins be loosed, nor the latchet of their shoes be broken:

Isaiah 5:28 Whose arrows are sharp, and all their bows bent, their horses’ hoofs shall be counted like flint, and their wheels like a whirlwind:

Isaiah 5:29 Their roaring shall be like a lion, they shall roar like young lions: yea, they shall roar, and lay hold of the prey, and shall carry it away safe, and none shall deliver it.

Isaiah 5:30 And in that day they shall roar against them like the roaring of the sea: and if one look unto the land, behold darkness and sorrow, and the light is darkened in the heavens thereof.
