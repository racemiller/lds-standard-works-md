# Proverbs 30

Proverbs 30 (summary): Every word of God is pure—Give me neither poverty nor riches.

Proverbs 30:1 The words of Agur the son of Jakeh, even the prophecy: the man spake unto Ithiel, even unto Ithiel and Ucal,

Proverbs 30:2 Surely I am more brutish than any man, and have not the understanding of a man.

Proverbs 30:3 I neither learned wisdom, nor have the knowledge of the holy.

Proverbs 30:4 Who hath ascended up into heaven, or descended? who hath gathered the wind in his fists? who hath bound the waters in a garment? who hath established all the ends of the earth? what is his name, and what is his son’s name, if thou canst tell?

Proverbs 30:5 Every word of God is pure: he is a shield unto them that put their trust in him.

Proverbs 30:6 Add thou not unto his words, lest he reprove thee, and thou be found a liar.

Proverbs 30:7 Two things have I required of thee; deny me them not before I die:

Proverbs 30:8 Remove far from me vanity and lies: give me neither poverty nor riches; feed me with food convenient for me:

Proverbs 30:9 Lest I be full, and deny thee, and say, Who is the Lord? or lest I be poor, and steal, and take the name of my God in vain.

Proverbs 30:10 Accuse not a servant unto his master, lest he curse thee, and thou be found guilty.

Proverbs 30:11 There is a generation that curseth their father, and doth not bless their mother.

Proverbs 30:12 There is a generation that are pure in their own eyes, and yet is not washed from their filthiness.

Proverbs 30:13 There is a generation, O how lofty are their eyes! and their eyelids are lifted up.

Proverbs 30:14 There is a generation, whose teeth are as swords, and their jaw teeth as knives, to devour the poor from off the earth, and the needy from among men.

Proverbs 30:15 The horseleach hath two daughters, crying, Give, give. There are three things that are never satisfied, yea, four things say not, It is enough:

Proverbs 30:16 The grave; and the barren womb; the earth that is not filled with water; and the fire that saith not, It is enough.

Proverbs 30:17 The eye that mocketh at his father, and despiseth to obey his mother, the ravens of the valley shall pick it out, and the young eagles shall eat it.

Proverbs 30:18 There be three things which are too wonderful for me, yea, four which I know not:

Proverbs 30:19 The way of an eagle in the air; the way of a serpent upon a rock; the way of a ship in the midst of the sea; and the way of a man with a maid.

Proverbs 30:20 Such is the way of an adulterous woman; she eateth, and wipeth her mouth, and saith, I have done no wickedness.

Proverbs 30:21 For three things the earth is disquieted, and for four which it cannot bear:

Proverbs 30:22 For a servant when he reigneth; and a fool when he is filled with meat;

Proverbs 30:23 For an odious woman when she is married; and an handmaid that is heir to her mistress.

Proverbs 30:24 There be four things which are little upon the earth, but they are exceeding wise:

Proverbs 30:25 The ants are a people not strong, yet they prepare their meat in the summer;

Proverbs 30:26 The conies are but a feeble folk, yet make they their houses in the rocks;

Proverbs 30:27 The locusts have no king, yet go they forth all of them by bands;

Proverbs 30:28 The spider taketh hold with her hands, and is in kings’ palaces.

Proverbs 30:29 There be three things which go well, yea, four are comely in going:

Proverbs 30:30 A lion which is strongest among beasts, and turneth not away for any;

Proverbs 30:31 A greyhound; an he goat also; and a king, against whom there is no rising up.

Proverbs 30:32 If thou hast done foolishly in lifting up thyself, or if thou hast thought evil, lay thine hand upon thy mouth.

Proverbs 30:33 Surely the churning of milk bringeth forth butter, and the wringing of the nose bringeth forth blood: so the forcing of wrath bringeth forth strife.
