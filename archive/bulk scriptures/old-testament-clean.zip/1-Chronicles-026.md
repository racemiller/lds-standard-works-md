# 1 Chronicles 26

1 Chronicles 26 (summary): The Levites are assigned as porters—They have charge of the treasures, serve as officers and judges, and conduct the outward business pertaining to the Israelites.

1 Chronicles 26:1 Concerning the divisions of the porters: Of the Korhites was Meshelemiah the son of Kore, of the sons of Asaph.

1 Chronicles 26:2 And the sons of Meshelemiah were, Zechariah the firstborn, Jediael the second, Zebadiah the third, Jathniel the fourth,

1 Chronicles 26:3 Elam the fifth, Jehohanan the sixth, Elioenai the seventh.

1 Chronicles 26:4 Moreover the sons of Obed-edom were, Shemaiah the firstborn, Jehozabad the second, Joah the third, and Sacar the fourth, and Nethaneel the fifth,

1 Chronicles 26:5 Ammiel the sixth, Issachar the seventh, Peulthai the eighth: for God blessed him.

1 Chronicles 26:6 Also unto Shemaiah his son were sons born, that ruled throughout the house of their father: for they were mighty men of valour.

1 Chronicles 26:7 The sons of Shemaiah; Othni, and Rephael, and Obed, Elzabad, whose brethren were strong men, Elihu, and Semachiah.

1 Chronicles 26:8 All these of the sons of Obed-edom: they and their sons and their brethren, able men for strength for the service, were threescore and two of Obed-edom.

1 Chronicles 26:9 And Meshelemiah had sons and brethren, strong men, eighteen.

1 Chronicles 26:10 Also Hosah, of the children of Merari, had sons; Simri the chief, (for though he was not the firstborn, yet his father made him the chief;)

1 Chronicles 26:11 Hilkiah the second, Tebaliah the third, Zechariah the fourth: all the sons and brethren of Hosah were thirteen.

1 Chronicles 26:12 Among these were the divisions of the porters, even among the chief men, having wards one against another, to minister in the house of the Lord.

1 Chronicles 26:13 And they cast lots, as well the small as the great, according to the house of their fathers, for every gate.

1 Chronicles 26:14 And the lot eastward fell to Shelemiah. Then for Zechariah his son, a wise counsellor, they cast lots; and his lot came out northward.

1 Chronicles 26:15 To Obed-edom southward; and to his sons the house of Asuppim.

1 Chronicles 26:16 To Shuppim and Hosah the lot came forth westward, with the gate Shallecheth, by the causeway of the going up, ward against ward.

1 Chronicles 26:17 Eastward were six Levites, northward four a day, southward four a day, and toward Asuppim two and two.

1 Chronicles 26:18 At Parbar westward, four at the causeway, and two at Parbar.

1 Chronicles 26:19 These are the divisions of the porters among the sons of Kore, and among the sons of Merari.

1 Chronicles 26:20 And of the Levites, Ahijah was over the treasures of the house of God, and over the treasures of the dedicated things.

1 Chronicles 26:21 As concerning the sons of Laadan; the sons of the Gershonite Laadan, chief fathers, even of Laadan the Gershonite, were Jehieli.

1 Chronicles 26:22 The sons of Jehieli; Zetham, and Joel his brother, which were over the treasures of the house of the Lord.

1 Chronicles 26:23 Of the Amramites, and the Izharites, the Hebronites, and the Uzzielites:

1 Chronicles 26:24 And Shebuel the son of Gershom, the son of Moses, was ruler of the treasures.

1 Chronicles 26:25 And his brethren by Eliezer; Rehabiah his son, and Jeshaiah his son, and Joram his son, and Zichri his son, and Shelomith his son.

1 Chronicles 26:26 Which Shelomith and his brethren were over all the treasures of the dedicated things, which David the king, and the chief fathers, the captains over thousands and hundreds, and the captains of the host, had dedicated.

1 Chronicles 26:27 Out of the spoils won in battles did they dedicate to maintain the house of the Lord.

1 Chronicles 26:28 And all that Samuel the seer, and Saul the son of Kish, and Abner the son of Ner, and Joab the son of Zeruiah, had dedicated; and whosoever had dedicated any thing, it was under the hand of Shelomith, and of his brethren.

1 Chronicles 26:29 Of the Izharites, Chenaniah and his sons were for the outward business over Israel, for officers and judges.

1 Chronicles 26:30 And of the Hebronites, Hashabiah and his brethren, men of valour, a thousand and seven hundred, were officers among them of Israel on this side Jordan westward in all the business of the Lord, and in the service of the king.

1 Chronicles 26:31 Among the Hebronites was Jerijah the chief, even among the Hebronites, according to the generations of his fathers. In the fortieth year of the reign of David they were sought for, and there were found among them mighty men of valour at Jazer of Gilead.

1 Chronicles 26:32 And his brethren, men of valour, were two thousand and seven hundred chief fathers, whom king David made rulers over the Reubenites, the Gadites, and the half tribe of Manasseh, for every matter pertaining to God, and affairs of the king.
