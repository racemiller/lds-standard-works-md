# 1 Chronicles 23

1 Chronicles 23 (summary): Solomon is made king—The Levites are numbered and assigned their various religious duties.

1 Chronicles 23:1 So when David was old and full of days, he made Solomon his son king over Israel.

1 Chronicles 23:2 And he gathered together all the princes of Israel, with the priests and the Levites.

1 Chronicles 23:3 Now the Levites were numbered from the age of thirty years and upward: and their number by their polls, man by man, was thirty and eight thousand.

1 Chronicles 23:4 Of which, twenty and four thousand were to set forward the work of the house of the Lord; and six thousand were officers and judges:

1 Chronicles 23:5 Moreover four thousand were porters; and four thousand praised the Lord with the instruments which I made, said David, to praise therewith.

1 Chronicles 23:6 And David divided them into courses among the sons of Levi, namely, Gershon, Kohath, and Merari.

1 Chronicles 23:7 Of the Gershonites were, Laadan, and Shimei.

1 Chronicles 23:8 The sons of Laadan; the chief was Jehiel, and Zetham, and Joel, three.

1 Chronicles 23:9 The sons of Shimei; Shelomith, and Haziel, and Haran, three. These were the chief of the fathers of Laadan.

1 Chronicles 23:10 And the sons of Shimei were, Jahath, Zina, and Jeush, and Beriah. These four were the sons of Shimei.

1 Chronicles 23:11 And Jahath was the chief, and Zizah the second: but Jeush and Beriah had not many sons; therefore they were in one reckoning, according to their father’s house.

1 Chronicles 23:12 The sons of Kohath; Amram, Izhar, Hebron, and Uzziel, four.

1 Chronicles 23:13 The sons of Amram; Aaron and Moses: and Aaron was separated, that he should sanctify the most holy things, he and his sons for ever, to burn incense before the Lord, to minister unto him, and to bless in his name for ever.

1 Chronicles 23:14 Now concerning Moses the man of God, his sons were named of the tribe of Levi.

1 Chronicles 23:15 The sons of Moses were, Gershom, and Eliezer.

1 Chronicles 23:16 Of the sons of Gershom, Shebuel was the chief.

1 Chronicles 23:17 And the sons of Eliezer were, Rehabiah the chief. And Eliezer had none other sons; but the sons of Rehabiah were very many.

1 Chronicles 23:18 Of the sons of Izhar; Shelomith the chief.

1 Chronicles 23:19 Of the sons of Hebron; Jeriah the first, Amariah the second, Jahaziel the third, and Jekameam the fourth.

1 Chronicles 23:20 Of the sons of Uzziel; Michah the first, and Jesiah the second.

1 Chronicles 23:21 The sons of Merari; Mahli, and Mushi. The sons of Mahli; Eleazar, and Kish.

1 Chronicles 23:22 And Eleazar died, and had no sons, but daughters: and their brethren the sons of Kish took them.

1 Chronicles 23:23 The sons of Mushi; Mahli, and Eder, and Jeremoth, three.

1 Chronicles 23:24 These were the sons of Levi after the house of their fathers; even the chief of the fathers, as they were counted by number of names by their polls, that did the work for the service of the house of the Lord, from the age of twenty years and upward.

1 Chronicles 23:25 For David said, The Lord God of Israel hath given rest unto his people, that they may dwell in Jerusalem for ever:

1 Chronicles 23:26 And also unto the Levites; they shall no more carry the tabernacle, nor any vessels of it for the service thereof.

1 Chronicles 23:27 For by the last words of David the Levites were numbered from twenty years old and above:

1 Chronicles 23:28 Because their office was to wait on the sons of Aaron for the service of the house of the Lord, in the courts, and in the chambers, and in the purifying of all holy things, and the work of the service of the house of God;

1 Chronicles 23:29 Both for the shewbread, and for the fine flour for meat offering, and for the unleavened cakes, and for that which is baked in the pan, and for that which is fried, and for all manner of measure and size;

1 Chronicles 23:30 And to stand every morning to thank and praise the Lord, and likewise at even;

1 Chronicles 23:31 And to offer all burnt sacrifices unto the Lord in the sabbaths, in the new moons, and on the set feasts, by number, according to the order commanded unto them, continually before the Lord:

1 Chronicles 23:32 And that they should keep the charge of the tabernacle of the congregation, and the charge of the holy place, and the charge of the sons of Aaron their brethren, in the service of the house of the Lord.
