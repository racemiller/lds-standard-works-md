# Psalms 32

Psalms 32 (summary): David says, Blessed is the man unto whom the Lord imputes not iniquity—David acknowledges his sin—He recommends that the righteous be glad in the Lord and rejoice.

Psalms 32:1 Blessed is he whose transgression is forgiven, whose sin is covered.

Psalms 32:2 Blessed is the man unto whom the Lord imputeth not iniquity, and in whose spirit there is no guile.

Psalms 32:3 When I kept silence, my bones waxed old through my roaring all the day long.

Psalms 32:4 For day and night thy hand was heavy upon me: my moisture is turned into the drought of summer. Selah.

Psalms 32:5 I acknowledged my sin unto thee, and mine iniquity have I not hid. I said, I will confess my transgressions unto the Lord; and thou forgavest the iniquity of my sin. Selah.

Psalms 32:6 For this shall every one that is godly pray unto thee in a time when thou mayest be found: surely in the floods of great waters they shall not come nigh unto him.

Psalms 32:7 Thou art my hiding place; thou shalt preserve me from trouble; thou shalt compass me about with songs of deliverance. Selah.

Psalms 32:8 I will instruct thee and teach thee in the way which thou shalt go: I will guide thee with mine eye.

Psalms 32:9 Be ye not as the horse, or as the mule, which have no understanding: whose mouth must be held in with bit and bridle, lest they come near unto thee.

Psalms 32:10 Many sorrows shall be to the wicked: but he that trusteth in the Lord, mercy shall compass him about.

Psalms 32:11 Be glad in the Lord, and rejoice, ye righteous: and shout for joy, all ye that are upright in heart.
