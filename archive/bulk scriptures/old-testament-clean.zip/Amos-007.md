# Amos 7

Amos 7 (summary): Amos relates how he was called of God to be a prophet—He prophesies the captivity of Israel.

Amos 7:1 Thus hath the Lord God shewed unto me; and, behold, he formed grasshoppers in the beginning of the shooting up of the latter growth; and, lo, it was the latter growth after the king’s mowings.

Amos 7:2 And it came to pass, that when they had made an end of eating the grass of the land, then I said, O Lord God, forgive, I beseech thee: by whom shall Jacob arise? for he is small.

Amos 7:3 The Lord repented for this: It shall not be, saith the Lord.

Amos 7:4 Thus hath the Lord God shewed unto me: and, behold, the Lord God called to contend by fire, and it devoured the great deep, and did eat up a part.

Amos 7:5 Then said I, O Lord God, cease, I beseech thee: by whom shall Jacob arise? for he is small.

Amos 7:6 The Lord repented for this: This also shall not be, saith the Lord God.

Amos 7:7 Thus he shewed me: and, behold, the Lord stood upon a wall made by a plumbline, with a plumbline in his hand.

Amos 7:8 And the Lord said unto me, Amos, what seest thou? And I said, A plumbline. Then said the Lord, Behold, I will set a plumbline in the midst of my people Israel: I will not again pass by them any more:

Amos 7:9 And the high places of Isaac shall be desolate, and the sanctuaries of Israel shall be laid waste; and I will rise against the house of Jeroboam with the sword.

Amos 7:10 Then Amaziah the priest of Beth-el sent to Jeroboam king of Israel, saying, Amos hath conspired against thee in the midst of the house of Israel: the land is not able to bear all his words.

Amos 7:11 For thus Amos saith, Jeroboam shall die by the sword, and Israel shall surely be led away captive out of their own land.

Amos 7:12 Also Amaziah said unto Amos, O thou seer, go, flee thee away into the land of Judah, and there eat bread, and prophesy there:

Amos 7:13 But prophesy not again any more at Beth-el: for it is the king’s chapel, and it is the king’s court.

Amos 7:14 Then answered Amos, and said to Amaziah, I was no prophet, neither was I a prophet’s son; but I was an herdman, and a gatherer of sycomore fruit:

Amos 7:15 And the Lord took me as I followed the flock, and the Lord said unto me, Go, prophesy unto my people Israel.

Amos 7:16 Now therefore hear thou the word of the Lord: Thou sayest, Prophesy not against Israel, and drop not thy word against the house of Isaac.

Amos 7:17 Therefore thus saith the Lord; Thy wife shall be an harlot in the city, and thy sons and thy daughters shall fall by the sword, and thy land shall be divided by line; and thou shalt die in a polluted land: and Israel shall surely go into captivity forth of his land.
