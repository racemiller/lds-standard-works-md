# Ezekiel 16

Ezekiel 16 (summary): Jerusalem has become as a harlot, reveling in her idols and worshipping false gods—She has partaken of all the sins of Egypt and the nations round about, and she is rejected—Yet in the last days, the Lord will again establish His covenant with her.

Ezekiel 16:1 Again the word of the Lord came unto me, saying,

Ezekiel 16:2 Son of man, cause Jerusalem to know her abominations,

Ezekiel 16:3 And say, Thus saith the Lord God unto Jerusalem; Thy birth and thy nativity is of the land of Canaan; thy father was an Amorite, and thy mother an Hittite.

Ezekiel 16:4 And as for thy nativity, in the day thou wast born thy navel was not cut, neither wast thou washed in water to supple thee; thou wast not salted at all, nor swaddled at all.

Ezekiel 16:5 None eye pitied thee, to do any of these unto thee, to have compassion upon thee; but thou wast cast out in the open field, to the lothing of thy person, in the day that thou wast born.

Ezekiel 16:6 And when I passed by thee, and saw thee polluted in thine own blood, I said unto thee when thou wast in thy blood, Live; yea, I said unto thee when thou wast in thy blood, Live.

Ezekiel 16:7 I have caused thee to multiply as the bud of the field, and thou hast increased and waxen great, and thou art come to excellent ornaments: thy breasts are fashioned, and thine hair is grown, whereas thou wast naked and bare.

Ezekiel 16:8 Now when I passed by thee, and looked upon thee, behold, thy time was the time of love; and I spread my skirt over thee, and covered thy nakedness: yea, I sware unto thee, and entered into a covenant with thee, saith the Lord God, and thou becamest mine.

Ezekiel 16:9 Then washed I thee with water; yea, I throughly washed away thy blood from thee, and I anointed thee with oil.

Ezekiel 16:10 I clothed thee also with broidered work, and shod thee with badgers’ skin, and I girded thee about with fine linen, and I covered thee with silk.

Ezekiel 16:11 I decked thee also with ornaments, and I put bracelets upon thy hands, and a chain on thy neck.

Ezekiel 16:12 And I put a jewel on thy forehead, and earrings in thine ears, and a beautiful crown upon thine head.

Ezekiel 16:13 Thus wast thou decked with gold and silver; and thy raiment was of fine linen, and silk, and broidered work; thou didst eat fine flour, and honey, and oil: and thou wast exceeding beautiful, and thou didst prosper into a kingdom.

Ezekiel 16:14 And thy renown went forth among the heathen for thy beauty: for it was perfect through my comeliness, which I had put upon thee, saith the Lord God.

Ezekiel 16:15 But thou didst trust in thine own beauty, and playedst the harlot because of thy renown, and pouredst out thy fornications on every one that passed by; his it was.

Ezekiel 16:16 And of thy garments thou didst take, and deckedst thy high places with divers colours, and playedst the harlot thereupon: the like things shall not come, neither shall it be so.

Ezekiel 16:17 Thou hast also taken thy fair jewels of my gold and of my silver, which I had given thee, and madest to thyself images of men, and didst commit whoredom with them,

Ezekiel 16:18 And tookest thy broidered garments, and coveredst them: and thou hast set mine oil and mine incense before them.

Ezekiel 16:19 My meat also which I gave thee, fine flour, and oil, and honey, wherewith I fed thee, thou hast even set it before them for a sweet savour: and thus it was, saith the Lord God.

Ezekiel 16:20 Moreover thou hast taken thy sons and thy daughters, whom thou hast borne unto me, and these hast thou sacrificed unto them to be devoured. Is this of thy whoredoms a small matter,

Ezekiel 16:21 That thou hast slain my children, and delivered them to cause them to pass through the fire for them?

Ezekiel 16:22 And in all thine abominations and thy whoredoms thou hast not remembered the days of thy youth, when thou wast naked and bare, and wast polluted in thy blood.

Ezekiel 16:23 And it came to pass after all thy wickedness, (woe, woe unto thee! saith the Lord God;)

Ezekiel 16:24 That thou hast also built unto thee an eminent place, and hast made thee an high place in every street.

Ezekiel 16:25 Thou hast built thy high place at every head of the way, and hast made thy beauty to be abhorred, and hast opened thy feet to every one that passed by, and multiplied thy whoredoms.

Ezekiel 16:26 Thou hast also committed fornication with the Egyptians thy neighbours, great of flesh; and hast increased thy whoredoms, to provoke me to anger.

Ezekiel 16:27 Behold, therefore I have stretched out my hand over thee, and have diminished thine ordinary food, and delivered thee unto the will of them that hate thee, the daughters of the Philistines, which are ashamed of thy lewd way.

Ezekiel 16:28 Thou hast played the whore also with the Assyrians, because thou wast unsatiable; yea, thou hast played the harlot with them, and yet couldest not be satisfied.

Ezekiel 16:29 Thou hast moreover multiplied thy fornication in the land of Canaan unto Chaldea; and yet thou wast not satisfied herewith.

Ezekiel 16:30 How weak is thine heart, saith the Lord God, seeing thou doest all these things, the work of an imperious whorish woman;

Ezekiel 16:31 In that thou buildest thine eminent place in the head of every way, and makest thine high place in every street; and hast not been as an harlot, in that thou scornest hire;

Ezekiel 16:32 But as a wife that committeth adultery, which taketh strangers instead of her husband!

Ezekiel 16:33 They give gifts to all whores: but thou givest thy gifts to all thy lovers, and hirest them, that they may come unto thee on every side for thy whoredom.

Ezekiel 16:34 And the contrary is in thee from other women in thy whoredoms, whereas none followeth thee to commit whoredoms: and in that thou givest a reward, and no reward is given unto thee, therefore thou art contrary.

Ezekiel 16:35 Wherefore, O harlot, hear the word of the Lord:

Ezekiel 16:36 Thus saith the Lord God; Because thy filthiness was poured out, and thy nakedness discovered through thy whoredoms with thy lovers, and with all the idols of thy abominations, and by the blood of thy children, which thou didst give unto them;

Ezekiel 16:37 Behold, therefore I will gather all thy lovers, with whom thou hast taken pleasure, and all them that thou hast loved, with all them that thou hast hated; I will even gather them round about against thee, and will discover thy nakedness unto them, that they may see all thy nakedness.

Ezekiel 16:38 And I will judge thee, as women that break wedlock and shed blood are judged; and I will give thee blood in fury and jealousy.

Ezekiel 16:39 And I will also give thee into their hand, and they shall throw down thine eminent place, and shall break down thy high places: they shall strip thee also of thy clothes, and shall take thy fair jewels, and leave thee naked and bare.

Ezekiel 16:40 They shall also bring up a company against thee, and they shall stone thee with stones, and thrust thee through with their swords.

Ezekiel 16:41 And they shall burn thine houses with fire, and execute judgments upon thee in the sight of many women: and I will cause thee to cease from playing the harlot, and thou also shalt give no hire any more.

Ezekiel 16:42 So will I make my fury toward thee to rest, and my jealousy shall depart from thee, and I will be quiet, and will be no more angry.

Ezekiel 16:43 Because thou hast not remembered the days of thy youth, but hast fretted me in all these things; behold, therefore I also will recompense thy way upon thine head, saith the Lord God: and thou shalt not commit this lewdness above all thine abominations.

Ezekiel 16:44 Behold, every one that useth proverbs shall use this proverb against thee, saying, As is the mother, so is her daughter.

Ezekiel 16:45 Thou art thy mother’s daughter, that lotheth her husband and her children; and thou art the sister of thy sisters, which lothed their husbands and their children: your mother was an Hittite, and your father an Amorite.

Ezekiel 16:46 And thine elder sister is Samaria, she and her daughters that dwell at thy left hand: and thy younger sister, that dwelleth at thy right hand, is Sodom and her daughters.

Ezekiel 16:47 Yet hast thou not walked after their ways, nor done after their abominations: but, as if that were a very little thing, thou wast corrupted more than they in all thy ways.

Ezekiel 16:48 As I live, saith the Lord God, Sodom thy sister hath not done, she nor her daughters, as thou hast done, thou and thy daughters.

Ezekiel 16:49 Behold, this was the iniquity of thy sister Sodom, pride, fulness of bread, and abundance of idleness was in her and in her daughters, neither did she strengthen the hand of the poor and needy.

Ezekiel 16:50 And they were haughty, and committed abomination before me: therefore I took them away as I saw good.

Ezekiel 16:51 Neither hath Samaria committed half of thy sins; but thou hast multiplied thine abominations more than they, and hast justified thy sisters in all thine abominations which thou hast done.

Ezekiel 16:52 Thou also, which hast judged thy sisters, bear thine own shame for thy sins that thou hast committed more abominable than they: they are more righteous than thou: yea, be thou confounded also, and bear thy shame, in that thou hast justified thy sisters.

Ezekiel 16:53 When I shall bring again their captivity, the captivity of Sodom and her daughters, and the captivity of Samaria and her daughters, then will I bring again the captivity of thy captives in the midst of them:

Ezekiel 16:54 That thou mayest bear thine own shame, and mayest be confounded in all that thou hast done, in that thou art a comfort unto them.

Ezekiel 16:55 When thy sisters, Sodom and her daughters, shall return to their former estate, and Samaria and her daughters shall return to their former estate, then thou and thy daughters shall return to your former estate.

Ezekiel 16:56 For thy sister Sodom was not mentioned by thy mouth in the day of thy pride,

Ezekiel 16:57 Before thy wickedness was discovered, as at the time of thy reproach of the daughters of Syria, and all that are round about her, the daughters of the Philistines, which despise thee round about.

Ezekiel 16:58 Thou hast borne thy lewdness and thine abominations, saith the Lord.

Ezekiel 16:59 For thus saith the Lord God; I will even deal with thee as thou hast done, which hast despised the oath in breaking the covenant.

Ezekiel 16:60 Nevertheless I will remember my covenant with thee in the days of thy youth, and I will establish unto thee an everlasting covenant.

Ezekiel 16:61 Then thou shalt remember thy ways, and be ashamed, when thou shalt receive thy sisters, thine elder and thy younger: and I will give them unto thee for daughters, but not by thy covenant.

Ezekiel 16:62 And I will establish my covenant with thee; and thou shalt know that I am the Lord:

Ezekiel 16:63 That thou mayest remember, and be confounded, and never open thy mouth any more because of thy shame, when I am pacified toward thee for all that thou hast done, saith the Lord God.
