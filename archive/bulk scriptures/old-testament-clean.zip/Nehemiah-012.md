# Nehemiah 12

Nehemiah 12 (summary): The priests and Levites who came up from Babylon are named—The walls of Jerusalem are dedicated—The offices of priests and Levites are appointed in the temple.

Nehemiah 12:1 Now these are the priests and the Levites that went up with Zerubbabel the son of Shealtiel, and Jeshua: Seraiah, Jeremiah, Ezra,

Nehemiah 12:2 Amariah, Malluch, Hattush,

Nehemiah 12:3 Shechaniah, Rehum, Meremoth,

Nehemiah 12:4 Iddo, Ginnetho, Abijah,

Nehemiah 12:5 Miamin, Maadiah, Bilgah,

Nehemiah 12:6 Shemaiah, and Joiarib, Jedaiah,

Nehemiah 12:7 Sallu, Amok, Hilkiah, Jedaiah. These were the chief of the priests and of their brethren in the days of Jeshua.

Nehemiah 12:8 Moreover the Levites: Jeshua, Binnui, Kadmiel, Sherebiah, Judah, and Mattaniah, which was over the thanksgiving, he and his brethren.

Nehemiah 12:9 Also Bakbukiah and Unni, their brethren, were over against them in the watches.

Nehemiah 12:10 And Jeshua begat Joiakim, Joiakim also begat Eliashib, and Eliashib begat Joiada,

Nehemiah 12:11 And Joiada begat Jonathan, and Jonathan begat Jaddua.

Nehemiah 12:12 And in the days of Joiakim were priests, the chief of the fathers: of Seraiah, Meraiah; of Jeremiah, Hananiah;

Nehemiah 12:13 Of Ezra, Meshullam; of Amariah, Jehohanan;

Nehemiah 12:14 Of Melicu, Jonathan; of Shebaniah, Joseph;

Nehemiah 12:15 Of Harim, Adna; of Meraioth, Helkai;

Nehemiah 12:16 Of Iddo, Zechariah; of Ginnethon, Meshullam;

Nehemiah 12:17 Of Abijah, Zichri; of Miniamin, of Moadiah, Piltai;

Nehemiah 12:18 Of Bilgah, Shammua; of Shemaiah, Jehonathan;

Nehemiah 12:19 And of Joiarib, Mattenai; of Jedaiah, Uzzi;

Nehemiah 12:20 Of Sallai, Kallai; of Amok, Eber;

Nehemiah 12:21 Of Hilkiah, Hashabiah; of Jedaiah, Nethaneel.

Nehemiah 12:22 The Levites in the days of Eliashib, Joiada, and Johanan, and Jaddua, were recorded chief of the fathers: also the priests, to the reign of Darius the Persian.

Nehemiah 12:23 The sons of Levi, the chief of the fathers, were written in the book of the chronicles, even until the days of Johanan the son of Eliashib.

Nehemiah 12:24 And the chief of the Levites: Hashabiah, Sherebiah, and Jeshua the son of Kadmiel, with their brethren over against them, to praise and to give thanks, according to the commandment of David the man of God, ward over against ward.

Nehemiah 12:25 Mattaniah, and Bakbukiah, Obadiah, Meshullam, Talmon, Akkub, were porters keeping the ward at the thresholds of the gates.

Nehemiah 12:26 These were in the days of Joiakim the son of Jeshua, the son of Jozadak, and in the days of Nehemiah the governor, and of Ezra the priest, the scribe.

Nehemiah 12:27 And at the dedication of the wall of Jerusalem they sought the Levites out of all their places, to bring them to Jerusalem, to keep the dedication with gladness, both with thanksgivings, and with singing, with cymbals, psalteries, and with harps.

Nehemiah 12:28 And the sons of the singers gathered themselves together, both out of the plain country round about Jerusalem, and from the villages of Netophathi;

Nehemiah 12:29 Also from the house of Gilgal, and out of the fields of Geba and Azmaveth: for the singers had builded them villages round about Jerusalem.

Nehemiah 12:30 And the priests and the Levites purified themselves, and purified the people, and the gates, and the wall.

Nehemiah 12:31 Then I brought up the princes of Judah upon the wall, and appointed two great companies of them that gave thanks, whereof one went on the right hand upon the wall toward the dung gate:

Nehemiah 12:32 And after them went Hoshaiah, and half of the princes of Judah,

Nehemiah 12:33 And Azariah, Ezra, and Meshullam,

Nehemiah 12:34 Judah, and Benjamin, and Shemaiah, and Jeremiah,

Nehemiah 12:35 And certain of the priests’ sons with trumpets; namely, Zechariah the son of Jonathan, the son of Shemaiah, the son of Mattaniah, the son of Michaiah, the son of Zaccur, the son of Asaph:

Nehemiah 12:36 And his brethren, Shemaiah, and Azarael, Milalai, Gilalai, Maai, Nethaneel, and Judah, Hanani, with the musical instruments of David the man of God, and Ezra the scribe before them.

Nehemiah 12:37 And at the fountain gate, which was over against them, they went up by the stairs of the city of David, at the going up of the wall, above the house of David, even unto the water gate eastward.

Nehemiah 12:38 And the other company of them that gave thanks went over against them, and I after them, and the half of the people upon the wall, from beyond the tower of the furnaces even unto the broad wall;

Nehemiah 12:39 And from above the gate of Ephraim, and above the old gate, and above the fish gate, and the tower of Hananeel, and the tower of Meah, even unto the sheep gate: and they stood still in the prison gate.

Nehemiah 12:40 So stood the two companies of them that gave thanks in the house of God, and I, and the half of the rulers with me:

Nehemiah 12:41 And the priests; Eliakim, Maaseiah, Miniamin, Michaiah, Elioenai, Zechariah, and Hananiah, with trumpets;

Nehemiah 12:42 And Maaseiah, and Shemaiah, and Eleazar, and Uzzi, and Jehohanan, and Malchijah, and Elam, and Ezer. And the singers sang loud, with Jezrahiah their overseer.

Nehemiah 12:43 Also that day they offered great sacrifices, and rejoiced: for God had made them rejoice with great joy: the wives also and the children rejoiced: so that the joy of Jerusalem was heard even afar off.

Nehemiah 12:44 And at that time were some appointed over the chambers for the treasures, for the offerings, for the firstfruits, and for the tithes, to gather into them out of the fields of the cities the portions of the law for the priests and Levites: for Judah rejoiced for the priests and for the Levites that waited.

Nehemiah 12:45 And both the singers and the porters kept the ward of their God, and the ward of the purification, according to the commandment of David, and of Solomon his son.

Nehemiah 12:46 For in the days of David and Asaph of old there were chief of the singers, and songs of praise and thanksgiving unto God.

Nehemiah 12:47 And all Israel in the days of Zerubbabel, and in the days of Nehemiah, gave the portions of the singers and the porters, every day his portion: and they sanctified holy things unto the Levites; and the Levites sanctified them unto the children of Aaron.
