# Ecclesiastes 2

Ecclesiastes 2 (summary): All the riches and wealth of the king are vanity and vexation of spirit—Wisdom is better than folly—God gives wisdom, knowledge, and joy to man.

Ecclesiastes 2:1 I said in mine heart, Go to now, I will prove thee with mirth, therefore enjoy pleasure: and, behold, this also is vanity.

Ecclesiastes 2:2 I said of laughter, It is mad: and of mirth, What doeth it?

Ecclesiastes 2:3 I sought in mine heart to give myself unto wine, yet acquainting mine heart with wisdom; and to lay hold on folly, till I might see what was that good for the sons of men, which they should do under the heaven all the days of their life.

Ecclesiastes 2:4 I made me great works; I builded me houses; I planted me vineyards:

Ecclesiastes 2:5 I made me gardens and orchards, and I planted trees in them of all kind of fruits:

Ecclesiastes 2:6 I made me pools of water, to water therewith the wood that bringeth forth trees:

Ecclesiastes 2:7 I got me servants and maidens, and had servants born in my house; also I had great possessions of great and small cattle above all that were in Jerusalem before me:

Ecclesiastes 2:8 I gathered me also silver and gold, and the peculiar treasure of kings and of the provinces: I gat me men singers and women singers, and the delights of the sons of men, as musical instruments, and that of all sorts.

Ecclesiastes 2:9 So I was great, and increased more than all that were before me in Jerusalem: also my wisdom remained with me.

Ecclesiastes 2:10 And whatsoever mine eyes desired I kept not from them, I withheld not my heart from any joy; for my heart rejoiced in all my labour: and this was my portion of all my labour.

Ecclesiastes 2:11 Then I looked on all the works that my hands had wrought, and on the labour that I had laboured to do: and, behold, all was vanity and vexation of spirit, and there was no profit under the sun.

Ecclesiastes 2:12 And I turned myself to behold wisdom, and madness, and folly: for what can the man do that cometh after the king? even that which hath been already done.

Ecclesiastes 2:13 Then I saw that wisdom excelleth folly, as far as light excelleth darkness.

Ecclesiastes 2:14 The wise man’s eyes are in his head; but the fool walketh in darkness: and I myself perceived also that one event happeneth to them all.

Ecclesiastes 2:15 Then said I in my heart, As it happeneth to the fool, so it happeneth even to me; and why was I then more wise? Then I said in my heart, that this also is vanity.

Ecclesiastes 2:16 For there is no remembrance of the wise more than of the fool for ever; seeing that which now is in the days to come shall all be forgotten. And how dieth the wise man? as the fool.

Ecclesiastes 2:17 Therefore I hated life; because the work that is wrought under the sun is grievous unto me: for all is vanity and vexation of spirit.

Ecclesiastes 2:18 Yea, I hated all my labour which I had taken under the sun: because I should leave it unto the man that shall be after me.

Ecclesiastes 2:19 And who knoweth whether he shall be a wise man or a fool? yet shall he have rule over all my labour wherein I have laboured, and wherein I have shewed myself wise under the sun. This is also vanity.

Ecclesiastes 2:20 Therefore I went about to cause my heart to despair of all the labour which I took under the sun.

Ecclesiastes 2:21 For there is a man whose labour is in wisdom, and in knowledge, and in equity; yet to a man that hath not laboured therein shall he leave it for his portion. This also is vanity and a great evil.

Ecclesiastes 2:22 For what hath man of all his labour, and of the vexation of his heart, wherein he hath laboured under the sun?

Ecclesiastes 2:23 For all his days are sorrows, and his travail grief; yea, his heart taketh not rest in the night. This is also vanity.

Ecclesiastes 2:24 There is nothing better for a man, than that he should eat and drink, and that he should make his soul enjoy good in his labour. This also I saw, that it was from the hand of God.

Ecclesiastes 2:25 For who can eat, or who else can hasten hereunto, more than I?

Ecclesiastes 2:26 For God giveth to a man that is good in his sight wisdom, and knowledge, and joy: but to the sinner he giveth travail, to gather and to heap up, that he may give to him that is good before God. This also is vanity and vexation of spirit.
