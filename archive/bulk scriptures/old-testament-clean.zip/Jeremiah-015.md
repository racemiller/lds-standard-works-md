# Jeremiah 15

Jeremiah 15 (summary): The people of Judah will suffer death, the sword, famine, and captivity—They will be scattered into all the kingdoms of the earth—Jerusalem will be destroyed.

Jeremiah 15:1 Then said the Lord unto me, Though Moses and Samuel stood before me, yet my mind could not be toward this people: cast them out of my sight, and let them go forth.

Jeremiah 15:2 And it shall come to pass, if they say unto thee, Whither shall we go forth? then thou shalt tell them, Thus saith the Lord; Such as are for death, to death; and such as are for the sword, to the sword; and such as are for the famine, to the famine; and such as are for the captivity, to the captivity.

Jeremiah 15:3 And I will appoint over them four kinds, saith the Lord: the sword to slay, and the dogs to tear, and the fowls of the heaven, and the beasts of the earth, to devour and destroy.

Jeremiah 15:4 And I will cause them to be removed into all kingdoms of the earth, because of Manasseh the son of Hezekiah king of Judah, for that which he did in Jerusalem.

Jeremiah 15:5 For who shall have pity upon thee, O Jerusalem? or who shall bemoan thee? or who shall go aside to ask how thou doest?

Jeremiah 15:6 Thou hast forsaken me, saith the Lord, thou art gone backward: therefore will I stretch out my hand against thee, and destroy thee; I am weary with repenting.

Jeremiah 15:7 And I will fan them with a fan in the gates of the land; I will bereave them of children, I will destroy my people, since they return not from their ways.

Jeremiah 15:8 Their widows are increased to me above the sand of the seas: I have brought upon them against the mother of the young men a spoiler at noonday: I have caused him to fall upon it suddenly, and terrors upon the city.

Jeremiah 15:9 She that hath borne seven languisheth: she hath given up the ghost; her sun is gone down while it was yet day: she hath been ashamed and confounded: and the residue of them will I deliver to the sword before their enemies, saith the Lord.

Jeremiah 15:10 Woe is me, my mother, that thou hast borne me a man of strife and a man of contention to the whole earth! I have neither lent on usury, nor men have lent to me on usury; yet every one of them doth curse me.

Jeremiah 15:11 The Lord said, Verily it shall be well with thy remnant; verily I will cause the enemy to entreat thee well in the time of evil and in the time of affliction.

Jeremiah 15:12 Shall iron break the northern iron and the steel?

Jeremiah 15:13 Thy substance and thy treasures will I give to the spoil without price, and that for all thy sins, even in all thy borders.

Jeremiah 15:14 And I will make thee to pass with thine enemies into a land which thou knowest not: for a fire is kindled in mine anger, which shall burn upon you.

Jeremiah 15:15 O Lord, thou knowest: remember me, and visit me, and revenge me of my persecutors; take me not away in thy longsuffering: know that for thy sake I have suffered rebuke.

Jeremiah 15:16 Thy words were found, and I did eat them; and thy word was unto me the joy and rejoicing of mine heart: for I am called by thy name, O Lord God of hosts.

Jeremiah 15:17 I sat not in the assembly of the mockers, nor rejoiced; I sat alone because of thy hand: for thou hast filled me with indignation.

Jeremiah 15:18 Why is my pain perpetual, and my wound incurable, which refuseth to be healed? wilt thou be altogether unto me as a liar, and as waters that fail?

Jeremiah 15:19 Therefore thus saith the Lord, If thou return, then will I bring thee again, and thou shalt stand before me: and if thou take forth the precious from the vile, thou shalt be as my mouth: let them return unto thee; but return not thou unto them.

Jeremiah 15:20 And I will make thee unto this people a fenced brasen wall: and they shall fight against thee, but they shall not prevail against thee: for I am with thee to save thee and to deliver thee, saith the Lord.

Jeremiah 15:21 And I will deliver thee out of the hand of the wicked, and I will redeem thee out of the hand of the terrible.
