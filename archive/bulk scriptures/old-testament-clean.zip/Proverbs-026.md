# Proverbs 26

Proverbs 26 (summary): Honor is not fitting for a fool—Answer not a fool according to his folly—Where there is no talebearer, the strife ceases.

Proverbs 26:1 As snow in summer, and as rain in harvest, so honour is not seemly for a fool.

Proverbs 26:2 As the bird by wandering, as the swallow by flying, so the curse causeless shall not come.

Proverbs 26:3 A whip for the horse, a bridle for the ass, and a rod for the fool’s back.

Proverbs 26:4 Answer not a fool according to his folly, lest thou also be like unto him.

Proverbs 26:5 Answer a fool according to his folly, lest he be wise in his own conceit.

Proverbs 26:6 He that sendeth a message by the hand of a fool cutteth off the feet, and drinketh damage.

Proverbs 26:7 The legs of the lame are not equal: so is a parable in the mouth of fools.

Proverbs 26:8 As he that bindeth a stone in a sling, so is he that giveth honour to a fool.

Proverbs 26:9 As a thorn goeth up into the hand of a drunkard, so is a parable in the mouth of fools.

Proverbs 26:10 The great God that formed all things both rewardeth the fool, and rewardeth transgressors.

Proverbs 26:11 As a dog returneth to his vomit, so a fool returneth to his folly.

Proverbs 26:12 Seest thou a man wise in his own conceit? there is more hope of a fool than of him.

Proverbs 26:13 The slothful man saith, There is a lion in the way; a lion is in the streets.

Proverbs 26:14 As the door turneth upon his hinges, so doth the slothful upon his bed.

Proverbs 26:15 The slothful hideth his hand in his bosom; it grieveth him to bring it again to his mouth.

Proverbs 26:16 The sluggard is wiser in his own conceit than seven men that can render a reason.

Proverbs 26:17 He that passeth by, and meddleth with strife belonging not to him, is like one that taketh a dog by the ears.

Proverbs 26:18 As a mad man who casteth firebrands, arrows, and death,

Proverbs 26:19 So is the man that deceiveth his neighbour, and saith, Am not I in sport?

Proverbs 26:20 Where no wood is, there the fire goeth out: so where there is no talebearer, the strife ceaseth.

Proverbs 26:21 As coals are to burning coals, and wood to fire; so is a contentious man to kindle strife.

Proverbs 26:22 The words of a talebearer are as wounds, and they go down into the innermost parts of the belly.

Proverbs 26:23 Burning lips and a wicked heart are like a potsherd covered with silver dross.

Proverbs 26:24 He that hateth dissembleth with his lips, and layeth up deceit within him;

Proverbs 26:25 When he speaketh fair, believe him not: for there are seven abominations in his heart.

Proverbs 26:26 Whose hatred is covered by deceit, his wickedness shall be shewed before the whole congregation.

Proverbs 26:27 Whoso diggeth a pit shall fall therein: and he that rolleth a stone, it will return upon him.

Proverbs 26:28 A lying tongue hateth those that are afflicted by it; and a flattering mouth worketh ruin.
