# Abraham 4

Abraham 4 (summary): The Gods plan the creation of the earth and all life thereon—Their plans for the six days of creation are set forth.

Abraham 4:1 And then the Lord said: Let us go down. And they went down at the beginning, and they, that is the Gods, organized and formed the heavens and the earth.

Abraham 4:2 And the earth, after it was formed, was empty and desolate, because they had not formed anything but the earth; and darkness reigned upon the face of the deep, and the Spirit of the Gods was brooding upon the face of the waters.

Abraham 4:3 And they (the Gods) said: Let there be light; and there was light.

Abraham 4:4 And they (the Gods) comprehended the light, for it was bright; and they divided the light, or caused it to be divided, from the darkness.

Abraham 4:5 And the Gods called the light Day, and the darkness they called Night. And it came to pass that from the evening until morning they called night; and from the morning until the evening they called day; and this was the first, or the beginning, of that which they called day and night.

Abraham 4:6 And the Gods also said: Let there be an expanse in the midst of the waters, and it shall divide the waters from the waters.

Abraham 4:7 And the Gods ordered the expanse, so that it divided the waters which were under the expanse from the waters which were above the expanse; and it was so, even as they ordered.

Abraham 4:8 And the Gods called the expanse, Heaven. And it came to pass that it was from evening until morning that they called night; and it came to pass that it was from morning until evening that they called day; and this was the second time that they called night and day.

Abraham 4:9 And the Gods ordered, saying: Let the waters under the heaven be gathered together unto one place, and let the earth come up dry; and it was so as they ordered;

Abraham 4:10 And the Gods pronounced the dry land, Earth; and the gathering together of the waters, pronounced they, Great Waters; and the Gods saw that they were obeyed.

Abraham 4:11 And the Gods said: Let us prepare the earth to bring forth grass; the herb yielding seed; the fruit tree yielding fruit, after his kind, whose seed in itself yieldeth its own likeness upon the earth; and it was so, even as they ordered.

Abraham 4:12 And the Gods organized the earth to bring forth grass from its own seed, and the herb to bring forth herb from its own seed, yielding seed after his kind; and the earth to bring forth the tree from its own seed, yielding fruit, whose seed could only bring forth the same in itself, after his kind; and the Gods saw that they were obeyed.

Abraham 4:13 And it came to pass that they numbered the days; from the evening until the morning they called night; and it came to pass, from the morning until the evening they called day; and it was the third time.

Abraham 4:14 And the Gods organized the lights in the expanse of the heaven, and caused them to divide the day from the night; and organized them to be for signs and for seasons, and for days and for years;

Abraham 4:15 And organized them to be for lights in the expanse of the heaven to give light upon the earth; and it was so.

Abraham 4:16 And the Gods organized the two great lights, the greater light to rule the day, and the lesser light to rule the night; with the lesser light they set the stars also;

Abraham 4:17 And the Gods set them in the expanse of the heavens, to give light upon the earth, and to rule over the day and over the night, and to cause to divide the light from the darkness.

Abraham 4:18 And the Gods watched those things which they had ordered until they obeyed.

Abraham 4:19 And it came to pass that it was from evening until morning that it was night; and it came to pass that it was from morning until evening that it was day; and it was the fourth time.

Abraham 4:20 And the Gods said: Let us prepare the waters to bring forth abundantly the moving creatures that have life; and the fowl, that they may fly above the earth in the open expanse of heaven.

Abraham 4:21 And the Gods prepared the waters that they might bring forth great whales, and every living creature that moveth, which the waters were to bring forth abundantly after their kind; and every winged fowl after their kind. And the Gods saw that they would be obeyed, and that their plan was good.

Abraham 4:22 And the Gods said: We will bless them, and cause them to be fruitful and multiply, and fill the waters in the seas or great waters; and cause the fowl to multiply in the earth.

Abraham 4:23 And it came to pass that it was from evening until morning that they called night; and it came to pass that it was from morning until evening that they called day; and it was the fifth time.

Abraham 4:24 And the Gods prepared the earth to bring forth the living creature after his kind, cattle and creeping things, and beasts of the earth after their kind; and it was so, as they had said.

Abraham 4:25 And the Gods organized the earth to bring forth the beasts after their kind, and cattle after their kind, and every thing that creepeth upon the earth after its kind; and the Gods saw they would obey.

Abraham 4:26 And the Gods took counsel among themselves and said: Let us go down and form man in our image, after our likeness; and we will give them dominion over the fish of the sea, and over the fowl of the air, and over the cattle, and over all the earth, and over every creeping thing that creepeth upon the earth.

Abraham 4:27 So the Gods went down to organize man in their own image, in the image of the Gods to form they him, male and female to form they them.

Abraham 4:28 And the Gods said: We will bless them. And the Gods said: We will cause them to be fruitful and multiply, and replenish the earth, and subdue it, and to have dominion over the fish of the sea, and over the fowl of the air, and over every living thing that moveth upon the earth.

Abraham 4:29 And the Gods said: Behold, we will give them every herb bearing seed that shall come upon the face of all the earth, and every tree which shall have fruit upon it; yea, the fruit of the tree yielding seed to them we will give it; it shall be for their meat.

Abraham 4:30 And to every beast of the earth, and to every fowl of the air, and to every thing that creepeth upon the earth, behold, we will give them life, and also we will give to them every green herb for meat, and all these things shall be thus organized.

Abraham 4:31 And the Gods said: We will do everything that we have said, and organize them; and behold, they shall be very obedient. And it came to pass that it was from evening until morning they called night; and it came to pass that it was from morning until evening that they called day; and they numbered the sixth time.
