# Official Declaration 1

Official Declaration 1 — The Bible and the Book of Mormon teach that monogamy is God’s standard for marriage unless He declares otherwise (see 2 Samuel 12:7–8 and Jacob 2:27, 30). Following a revelation to Joseph Smith, the practice of plural marriage was instituted among Church members in the early 1840s (see section 132). From the 1860s to the 1880s, the United States government passed laws to make this religious practice illegal. These laws were eventually upheld by the U.S. Supreme Court. After receiving revelation, President Wilford Woodruff issued the following Manifesto, which was accepted by the Church as authoritative and binding on October 6, 1890. This led to the end of the practice of plural marriage in the Church.

Official Declaration 1 — To Whom It May Concern:

Official Declaration 1 — Press dispatches having been sent for political purposes, from Salt Lake City, which have been widely published, to the effect that the Utah Commission, in their recent report to the Secretary of the Interior, allege that plural marriages are still being solemnized and that forty or more such marriages have been contracted in Utah since last June or during the past year, also that in public discourses the leaders of the Church have taught, encouraged and urged the continuance of the practice of polygamy—

Official Declaration 1 — I, therefore, as President of The Church of Jesus Christ of Latter-day Saints, do hereby, in the most solemn manner, declare that these charges are false. We are not teaching polygamy or plural marriage, nor permitting any person to enter into its practice, and I deny that either forty or any other number of plural marriages have during that period been solemnized in our Temples or in any other place in the Territory.

Official Declaration 1 — One case has been reported, in which the parties allege that the marriage was performed in the Endowment House, in Salt Lake City, in the Spring of 1889, but I have not been able to learn who performed the ceremony; whatever was done in this matter was without my knowledge. In consequence of this alleged occurrence the Endowment House was, by my instructions, taken down without delay.

Official Declaration 1 — Inasmuch as laws have been enacted by Congress forbidding plural marriages, which laws have been pronounced constitutional by the court of last resort, I hereby declare my intention to submit to those laws, and to use my influence with the members of the Church over which I preside to have them do likewise.

Official Declaration 1 — There is nothing in my teachings to the Church or in those of my associates, during the time specified, which can be reasonably construed to inculcate or encourage polygamy; and when any Elder of the Church has used language which appeared to convey any such teaching, he has been promptly reproved. And I now publicly declare that my advice to the Latter-day Saints is to refrain from contracting any marriage forbidden by the law of the land.

Official Declaration 1 — Wilford Woodruff

Official Declaration 1 — President of The Church of Jesus Christ
of Latter-day Saints.

Official Declaration 1 — President Lorenzo Snow offered the following:

Official Declaration 1 — “I move that, recognizing Wilford Woodruff as the President of The Church of Jesus Christ of Latter-day Saints, and the only man on the earth at the present time who holds the keys of the sealing ordinances, we consider him fully authorized by virtue of his position to issue the Manifesto which has been read in our hearing, and which is dated September 24th, 1890, and that as a Church in General Conference assembled, we accept his declaration concerning plural marriages as authoritative and binding.”

Official Declaration 1 — Salt Lake City, Utah, October 6, 1890.

Official Declaration 1 — ## Excerpts from Three Addresses by President Wilford Woodruff Regarding the Manifesto

Official Declaration 1 — The Lord will never permit me or any other man who stands as President of this Church to lead you astray. It is not in the programme. It is not in the mind of God. If I were to attempt that, the Lord would remove me out of my place, and so He will any other man who attempts to lead the children of men astray from the oracles of God and from their duty. (Sixty-first Semiannual General Conference of the Church, Monday, October 6, 1890, Salt Lake City, Utah. Reported in *Deseret Evening News,* October 11, 1890, p. 2.)

Official Declaration 1 — It matters not who lives or who dies, or who is called to lead this Church, they have got to lead it by the inspiration of Almighty God. If they do not do it that way, they cannot do it at all. …

Official Declaration 1 — I have had some revelations of late, and very important ones to me, and I will tell you what the Lord has said to me. Let me bring your minds to what is termed the manifesto. …

Official Declaration 1 — The Lord has told me to ask the Latter-day Saints a question, and He also told me that if they would listen to what I said to them and answer the question put to them, by the Spirit and power of God, they would all answer alike, and they would all believe alike with regard to this matter.

Official Declaration 1 — The question is this: Which is the wisest course for the Latter-day Saints to pursue—to continue to attempt to practice plural marriage, with the laws of the nation against it and the opposition of sixty millions of people, and at the cost of the confiscation and loss of all the Temples, and the stopping of all the ordinances therein, both for the living and the dead, and the imprisonment of the First Presidency and Twelve and the heads of families in the Church, and the confiscation of personal property of the people (all of which of themselves would stop the practice); or, after doing and suffering what we have through our adherence to this principle to cease the practice and submit to the law, and through doing so leave the Prophets, Apostles and fathers at home, so that they can instruct the people and attend to the duties of the Church, and also leave the Temples in the hands of the Saints, so that they can attend to the ordinances of the Gospel, both for the living and the dead?

Official Declaration 1 — The Lord showed me by vision and revelation exactly what would take place if we did not stop this practice. If we had not stopped it, you would have had no use for … any of the men in this temple at Logan; for all ordinances would be stopped throughout the land of Zion. Confusion would reign throughout Israel, and many men would be made prisoners. This trouble would have come upon the whole Church, and we should have been compelled to stop the practice. Now, the question is, whether it should be stopped in this manner, or in the way the Lord has manifested to us, and leave our Prophets and Apostles and fathers free men, and the temples in the hands of the people, so that the dead may be redeemed. A large number has already been delivered from the prison house in the spirit world by this people, and shall the work go on or stop? This is the question I lay before the Latter-day Saints. You have to judge for yourselves. I want you to answer it for yourselves. I shall not answer it; but I say to you that that is exactly the condition we as a people would have been in had we not taken the course we have.

Official Declaration 1 — … I saw exactly what would come to pass if there was not something done. I have had this spirit upon me for a long time. But I want to say this: I should have let all the temples go out of our hands; I should have gone to prison myself, and let every other man go there, had not the God of heaven commanded me to do what I did do; and when the hour came that I was commanded to do that, it was all clear to me. I went before the Lord, and I wrote what the Lord told me to write. …

Official Declaration 1 — I leave this with you, for you to contemplate and consider. The Lord is at work with us. (Cache Stake Conference, Logan, Utah, Sunday, November 1, 1891. Reported in *Deseret Weekly,* November 14, 1891.)

Official Declaration 1 — Now I will tell you what was manifested to me and what the Son of God performed in this thing. … All these things would have come to pass, as God Almighty lives, had not that Manifesto been given. Therefore, the Son of God felt disposed to have that thing presented to the Church and to the world for purposes in his own mind. The Lord had decreed the establishment of Zion. He had decreed the finishing of this temple. He had decreed that the salvation of the living and the dead should be given in these valleys of the mountains. And Almighty God decreed that the Devil should not thwart it. If you can understand that, that is a key to it. (From a discourse at the sixth session of the dedication of the Salt Lake Temple, April 1893. Typescript of Dedicatory Services, Archives, Church Historical Department, Salt Lake City, Utah.)
