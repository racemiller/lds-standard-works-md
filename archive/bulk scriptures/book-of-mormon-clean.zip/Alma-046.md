# Alma 46

Alma 46 (summary): Amalickiah conspires to be king—Moroni raises the title of liberty—He rallies the people to defend their religion—True believers are called Christians—A remnant of Joseph will be preserved—Amalickiah and the dissenters flee to the land of Nephi—Those who will not support the cause of freedom are put to death. About 73–72 B.C.

Alma 46:1 And it came to pass that as many as would not hearken to the words of Helaman and his brethren were gathered together against their brethren.

Alma 46:2 And now behold, they were exceedingly wroth, insomuch that they were determined to slay them.

Alma 46:3 Now the leader of those who were wroth against their brethren was a large and a strong man; and his name was Amalickiah.

Alma 46:4 And Amalickiah was desirous to be a king; and those people who were wroth were also desirous that he should be their king; and they were the greater part of them the lower judges of the land, and they were seeking for power.

Alma 46:5 And they had been led by the flatteries of Amalickiah, that if they would support him and establish him to be their king that he would make them rulers over the people.

Alma 46:6 Thus they were led away by Amalickiah to dissensions, notwithstanding the preaching of Helaman and his brethren, yea, notwithstanding their exceedingly great care over the church, for they were high priests over the church.

Alma 46:7 And there were many in the church who believed in the flattering words of Amalickiah, therefore they dissented even from the church; and thus were the affairs of the people of Nephi exceedingly precarious and dangerous, notwithstanding their great victory which they had had over the Lamanites, and their great rejoicings which they had had because of their deliverance by the hand of the Lord.

Alma 46:8 Thus we see how quick the children of men do forget the Lord their God, yea, how quick to do iniquity, and to be led away by the evil one.

Alma 46:9 Yea, and we also see the great wickedness one very wicked man can cause to take place among the children of men.

Alma 46:10 Yea, we see that Amalickiah, because he was a man of cunning device and a man of many flattering words, that he led away the hearts of many people to do wickedly; yea, and to seek to destroy the church of God, and to destroy the foundation of liberty which God had granted unto them, or which blessing God had sent upon the face of the land for the righteous’ sake.

Alma 46:11 And now it came to pass that when Moroni, who was the chief commander of the armies of the Nephites, had heard of these dissensions, he was angry with Amalickiah.

Alma 46:12 And it came to pass that he rent his coat; and he took a piece thereof, and wrote upon it—In memory of our God, our religion, and freedom, and our peace, our wives, and our children—and he fastened it upon the end of a pole.

Alma 46:13 And he fastened on his head-plate, and his breastplate, and his shields, and girded on his armor about his loins; and he took the pole, which had on the end thereof his rent coat, (and he called it the title of liberty) and he bowed himself to the earth, and he prayed mightily unto his God for the blessings of liberty to rest upon his brethren, so long as there should a band of Christians remain to possess the land—

Alma 46:14 For thus were all the true believers of Christ, who belonged to the church of God, called by those who did not belong to the church.

Alma 46:15 And those who did belong to the church were faithful; yea, all those who were true believers in Christ took upon them, gladly, the name of Christ, or Christians as they were called, because of their belief in Christ who should come.

Alma 46:16 And therefore, at this time, Moroni prayed that the cause of the Christians, and the freedom of the land might be favored.

Alma 46:17 And it came to pass that when he had poured out his soul to God, he named all the land which was south of the land Desolation, yea, and in fine, all the land, both on the north and on the south—A chosen land, and the land of liberty.

Alma 46:18 And he said: Surely God shall not suffer that we, who are despised because we take upon us the name of Christ, shall be trodden down and destroyed, until we bring it upon us by our own transgressions.

Alma 46:19 And when Moroni had said these words, he went forth among the people, waving the rent part of his garment in the air, that all might see the writing which he had written upon the rent part, and crying with a loud voice, saying:

Alma 46:20 Behold, whosoever will maintain this title upon the land, let them come forth in the strength of the Lord, and enter into a covenant that they will maintain their rights, and their religion, that the Lord God may bless them.

Alma 46:21 And it came to pass that when Moroni had proclaimed these words, behold, the people came running together with their armor girded about their loins, rending their garments in token, or as a covenant, that they would not forsake the Lord their God; or, in other words, if they should transgress the commandments of God, or fall into transgression, and be ashamed to take upon them the name of Christ, the Lord should rend them even as they had rent their garments.

Alma 46:22 Now this was the covenant which they made, and they cast their garments at the feet of Moroni, saying: We covenant with our God, that we shall be destroyed, even as our brethren in the land northward, if we shall fall into transgression; yea, he may cast us at the feet of our enemies, even as we have cast our garments at thy feet to be trodden under foot, if we shall fall into transgression.

Alma 46:23 Moroni said unto them: Behold, we are a remnant of the seed of Jacob; yea, we are a remnant of the seed of Joseph, whose coat was rent by his brethren into many pieces; yea, and now behold, let us remember to keep the commandments of God, or our garments shall be rent by our brethren, and we be cast into prison, or be sold, or be slain.

Alma 46:24 Yea, let us preserve our liberty as a remnant of Joseph; yea, let us remember the words of Jacob, before his death, for behold, he saw that a part of the remnant of the coat of Joseph was preserved and had not decayed. And he said—Even as this remnant of garment of my son hath been preserved, so shall a remnant of the seed of my son be preserved by the hand of God, and be taken unto himself, while the remainder of the seed of Joseph shall perish, even as the remnant of his garment.

Alma 46:25 Now behold, this giveth my soul sorrow; nevertheless, my soul hath joy in my son, because of that part of his seed which shall be taken unto God.

Alma 46:26 Now behold, this was the language of Jacob.

Alma 46:27 And now who knoweth but what the remnant of the seed of Joseph, which shall perish as his garment, are those who have dissented from us? Yea, and even it shall be ourselves if we do not stand fast in the faith of Christ.

Alma 46:28 And now it came to pass that when Moroni had said these words he went forth, and also sent forth in all the parts of the land where there were dissensions, and gathered together all the people who were desirous to maintain their liberty, to stand against Amalickiah and those who had dissented, who were called Amalickiahites.

Alma 46:29 And it came to pass that when Amalickiah saw that the people of Moroni were more numerous than the Amalickiahites—and he also saw that his people were doubtful concerning the justice of the cause in which they had undertaken—therefore, fearing that he should not gain the point, he took those of his people who would and departed into the land of Nephi.

Alma 46:30 Now Moroni thought it was not expedient that the Lamanites should have any more strength; therefore he thought to cut off the people of Amalickiah, or to take them and bring them back, and put Amalickiah to death; yea, for he knew that he would stir up the Lamanites to anger against them, and cause them to come to battle against them; and this he knew that Amalickiah would do that he might obtain his purposes.

Alma 46:31 Therefore Moroni thought it was expedient that he should take his armies, who had gathered themselves together, and armed themselves, and entered into a covenant to keep the peace—and it came to pass that he took his army and marched out with his tents into the wilderness, to cut off the course of Amalickiah in the wilderness.

Alma 46:32 And it came to pass that he did according to his desires, and marched forth into the wilderness, and headed the armies of Amalickiah.

Alma 46:33 And it came to pass that Amalickiah fled with a small number of his men, and the remainder were delivered up into the hands of Moroni and were taken back into the land of Zarahemla.

Alma 46:34 Now, Moroni being a man who was appointed by the chief judges and the voice of the people, therefore he had power according to his will with the armies of the Nephites, to establish and to exercise authority over them.

Alma 46:35 And it came to pass that whomsoever of the Amalickiahites that would not enter into a covenant to support the cause of freedom, that they might maintain a free government, he caused to be put to death; and there were but few who denied the covenant of freedom.

Alma 46:36 And it came to pass also, that he caused the title of liberty to be hoisted upon every tower which was in all the land, which was possessed by the Nephites; and thus Moroni planted the standard of liberty among the Nephites.

Alma 46:37 And they began to have peace again in the land; and thus they did maintain peace in the land until nearly the end of the nineteenth year of the reign of the judges.

Alma 46:38 And Helaman and the high priests did also maintain order in the church; yea, even for the space of four years did they have much peace and rejoicing in the church.

Alma 46:39 And it came to pass that there were many who died, firmly believing that their souls were redeemed by the Lord Jesus Christ; thus they went out of the world rejoicing.

Alma 46:40 And there were some who died with fevers, which at some seasons of the year were very frequent in the land—but not so much so with fevers, because of the excellent qualities of the many plants and roots which God had prepared to remove the cause of diseases, to which men were subject by the nature of the climate—

Alma 46:41 But there were many who died with old age; and those who died in the faith of Christ are happy in him, as we must needs suppose.
