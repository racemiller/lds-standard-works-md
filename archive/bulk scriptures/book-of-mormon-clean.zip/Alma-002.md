# Alma 2

Alma 2 (summary): Amlici seeks to be king and is rejected by the voice of the people—His followers make him king—The Amlicites make war on the Nephites and are defeated—The Lamanites and Amlicites join forces and are defeated—Alma slays Amlici. About 87 B.C.

Alma 2:1 And it came to pass in the commencement of the fifth year of their reign there began to be a contention among the people; for a certain man, being called Amlici, he being a very cunning man, yea, a wise man as to the wisdom of the world, he being after the order of the man that slew Gideon by the sword, who was executed according to the law—

Alma 2:2 Now this Amlici had, by his cunning, drawn away much people after him; even so much that they began to be very powerful; and they began to endeavor to establish Amlici to be a king over the people.

Alma 2:3 Now this was alarming to the people of the church, and also to all those who had not been drawn away after the persuasions of Amlici; for they knew that according to their law that such things must be established by the voice of the people.

Alma 2:4 Therefore, if it were possible that Amlici should gain the voice of the people, he, being a wicked man, would deprive them of their rights and privileges of the church; for it was his intent to destroy the church of God.

Alma 2:5 And it came to pass that the people assembled themselves together throughout all the land, every man according to his mind, whether it were for or against Amlici, in separate bodies, having much dispute and wonderful contentions one with another.

Alma 2:6 And thus they did assemble themselves together to cast in their voices concerning the matter; and they were laid before the judges.

Alma 2:7 And it came to pass that the voice of the people came against Amlici, that he was not made king over the people.

Alma 2:8 Now this did cause much joy in the hearts of those who were against him; but Amlici did stir up those who were in his favor to anger against those who were not in his favor.

Alma 2:9 And it came to pass that they gathered themselves together, and did consecrate Amlici to be their king.

Alma 2:10 Now when Amlici was made king over them he commanded them that they should take up arms against their brethren; and this he did that he might subject them to him.

Alma 2:11 Now the people of Amlici were distinguished by the name of Amlici, being called Amlicites; and the remainder were called Nephites, or the people of God.

Alma 2:12 Therefore the people of the Nephites were aware of the intent of the Amlicites, and therefore they did prepare to meet them; yea, they did arm themselves with swords, and with cimeters, and with bows, and with arrows, and with stones, and with slings, and with all manner of weapons of war, of every kind.

Alma 2:13 And thus they were prepared to meet the Amlicites at the time of their coming. And there were appointed captains, and higher captains, and chief captains, according to their numbers.

Alma 2:14 And it came to pass that Amlici did arm his men with all manner of weapons of war of every kind; and he also appointed rulers and leaders over his people, to lead them to war against their brethren.

Alma 2:15 And it came to pass that the Amlicites came upon the hill Amnihu, which was east of the river Sidon, which ran by the land of Zarahemla, and there they began to make war with the Nephites.

Alma 2:16 Now Alma, being the chief judge and the governor of the people of Nephi, therefore he went up with his people, yea, with his captains, and chief captains, yea, at the head of his armies, against the Amlicites to battle.

Alma 2:17 And they began to slay the Amlicites upon the hill east of Sidon. And the Amlicites did contend with the Nephites with great strength, insomuch that many of the Nephites did fall before the Amlicites.

Alma 2:18 Nevertheless the Lord did strengthen the hand of the Nephites, that they slew the Amlicites with great slaughter, that they began to flee before them.

Alma 2:19 And it came to pass that the Nephites did pursue the Amlicites all that day, and did slay them with much slaughter, insomuch that there were slain of the Amlicites twelve thousand five hundred thirty and two souls; and there were slain of the Nephites six thousand five hundred sixty and two souls.

Alma 2:20 And it came to pass that when Alma could pursue the Amlicites no longer he caused that his people should pitch their tents in the valley of Gideon, the valley being called after that Gideon who was slain by the hand of Nehor with the sword; and in this valley the Nephites did pitch their tents for the night.

Alma 2:21 And Alma sent spies to follow the remnant of the Amlicites, that he might know of their plans and their plots, whereby he might guard himself against them, that he might preserve his people from being destroyed.

Alma 2:22 Now those whom he had sent out to watch the camp of the Amlicites were called Zeram, and Amnor, and Manti, and Limher; these were they who went out with their men to watch the camp of the Amlicites.

Alma 2:23 And it came to pass that on the morrow they returned into the camp of the Nephites in great haste, being greatly astonished, and struck with much fear, saying:

Alma 2:24 Behold, we followed the camp of the Amlicites, and to our great astonishment, in the land of Minon, above the land of Zarahemla, in the course of the land of Nephi, we saw a numerous host of the Lamanites; and behold, the Amlicites have joined them;

Alma 2:25 And they are upon our brethren in that land; and they are fleeing before them with their flocks, and their wives, and their children, towards our city; and except we make haste they obtain possession of our city, and our fathers, and our wives, and our children be slain.

Alma 2:26 And it came to pass that the people of Nephi took their tents, and departed out of the valley of Gideon towards their city, which was the city of Zarahemla.

Alma 2:27 And behold, as they were crossing the river Sidon, the Lamanites and the Amlicites, being as numerous almost, as it were, as the sands of the sea, came upon them to destroy them.

Alma 2:28 Nevertheless, the Nephites being strengthened by the hand of the Lord, having prayed mightily to him that he would deliver them out of the hands of their enemies, therefore the Lord did hear their cries, and did strengthen them, and the Lamanites and the Amlicites did fall before them.

Alma 2:29 And it came to pass that Alma fought with Amlici with the sword, face to face; and they did contend mightily, one with another.

Alma 2:30 And it came to pass that Alma, being a man of God, being exercised with much faith, cried, saying: O Lord, have mercy and spare my life, that I may be an instrument in thy hands to save and preserve this people.

Alma 2:31 Now when Alma had said these words he contended again with Amlici; and he was strengthened, insomuch that he slew Amlici with the sword.

Alma 2:32 And he also contended with the king of the Lamanites; but the king of the Lamanites fled back from before Alma and sent his guards to contend with Alma.

Alma 2:33 But Alma, with his guards, contended with the guards of the king of the Lamanites until he slew and drove them back.

Alma 2:34 And thus he cleared the ground, or rather the bank, which was on the west of the river Sidon, throwing the bodies of the Lamanites who had been slain into the waters of Sidon, that thereby his people might have room to cross and contend with the Lamanites and the Amlicites on the west side of the river Sidon.

Alma 2:35 And it came to pass that when they had all crossed the river Sidon that the Lamanites and the Amlicites began to flee before them, notwithstanding they were so numerous that they could not be numbered.

Alma 2:36 And they fled before the Nephites towards the wilderness which was west and north, away beyond the borders of the land; and the Nephites did pursue them with their might, and did slay them.

Alma 2:37 Yea, they were met on every hand, and slain and driven, until they were scattered on the west, and on the north, until they had reached the wilderness, which was called Hermounts; and it was that part of the wilderness which was infested by wild and ravenous beasts.

Alma 2:38 And it came to pass that many died in the wilderness of their wounds, and were devoured by those beasts and also the vultures of the air; and their bones have been found, and have been heaped up on the earth.
