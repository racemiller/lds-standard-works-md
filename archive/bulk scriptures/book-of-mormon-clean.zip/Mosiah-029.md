# Mosiah 29

Mosiah 29 (summary): Mosiah proposes that judges be chosen in place of a king—Unrighteous kings lead their people into sin—Alma the younger is chosen chief judge by the voice of the people—He is also the high priest over the Church—Alma the elder and Mosiah die. About 92–91 B.C.

Mosiah 29:1 Now when Mosiah had done this he sent out throughout all the land, among all the people, desiring to know their will concerning who should be their king.

Mosiah 29:2 And it came to pass that the voice of the people came, saying: We are desirous that Aaron thy son should be our king and our ruler.

Mosiah 29:3 Now Aaron had gone up to the land of Nephi, therefore the king could not confer the kingdom upon him; neither would Aaron take upon him the kingdom; neither were any of the sons of Mosiah willing to take upon them the kingdom.

Mosiah 29:4 Therefore king Mosiah sent again among the people; yea, even a written word sent he among the people. And these were the words that were written, saying:

Mosiah 29:5 Behold, O ye my people, or my brethren, for I esteem you as such, I desire that ye should consider the cause which ye are called to consider—for ye are desirous to have a king.

Mosiah 29:6 Now I declare unto you that he to whom the kingdom doth rightly belong has declined, and will not take upon him the kingdom.

Mosiah 29:7 And now if there should be another appointed in his stead, behold I fear there would rise contentions among you. And who knoweth but what my son, to whom the kingdom doth belong, should turn to be angry and draw away a part of this people after him, which would cause wars and contentions among you, which would be the cause of shedding much blood and perverting the way of the Lord, yea, and destroy the souls of many people.

Mosiah 29:8 Now I say unto you let us be wise and consider these things, for we have no right to destroy my son, neither should we have any right to destroy another if he should be appointed in his stead.

Mosiah 29:9 And if my son should turn again to his pride and vain things he would recall the things which he had said, and claim his right to the kingdom, which would cause him and also this people to commit much sin.

Mosiah 29:10 And now let us be wise and look forward to these things, and do that which will make for the peace of this people.

Mosiah 29:11 Therefore I will be your king the remainder of my days; nevertheless, let us appoint judges, to judge this people according to our law; and we will newly arrange the affairs of this people, for we will appoint wise men to be judges, that will judge this people according to the commandments of God.

Mosiah 29:12 Now it is better that a man should be judged of God than of man, for the judgments of God are always just, but the judgments of man are not always just.

Mosiah 29:13 Therefore, if it were possible that you could have just men to be your kings, who would establish the laws of God, and judge this people according to his commandments, yea, if ye could have men for your kings who would do even as my father Benjamin did for this people—I say unto you, if this could always be the case then it would be expedient that ye should always have kings to rule over you.

Mosiah 29:14 And even I myself have labored with all the power and faculties which I have possessed, to teach you the commandments of God, and to establish peace throughout the land, that there should be no wars nor contentions, no stealing, nor plundering, nor murdering, nor any manner of iniquity;

Mosiah 29:15 And whosoever has committed iniquity, him have I punished according to the crime which he has committed, according to the law which has been given to us by our fathers.

Mosiah 29:16 Now I say unto you, that because all men are not just it is not expedient that ye should have a king or kings to rule over you.

Mosiah 29:17 For behold, how much iniquity doth one wicked king cause to be committed, yea, and what great destruction!

Mosiah 29:18 Yea, remember king Noah, his wickedness and his abominations, and also the wickedness and abominations of his people. Behold what great destruction did come upon them; and also because of their iniquities they were brought into bondage.

Mosiah 29:19 And were it not for the interposition of their all-wise Creator, and this because of their sincere repentance, they must unavoidably remain in bondage until now.

Mosiah 29:20 But behold, he did deliver them because they did humble themselves before him; and because they cried mightily unto him he did deliver them out of bondage; and thus doth the Lord work with his power in all cases among the children of men, extending the arm of mercy towards them that put their trust in him.

Mosiah 29:21 And behold, now I say unto you, ye cannot dethrone an iniquitous king save it be through much contention, and the shedding of much blood.

Mosiah 29:22 For behold, he has his friends in iniquity, and he keepeth his guards about him; and he teareth up the laws of those who have reigned in righteousness before him; and he trampleth under his feet the commandments of God;

Mosiah 29:23 And he enacteth laws, and sendeth them forth among his people, yea, laws after the manner of his own wickedness; and whosoever doth not obey his laws he causeth to be destroyed; and whosoever doth rebel against him he will send his armies against them to war, and if he can he will destroy them; and thus an unrighteous king doth pervert the ways of all righteousness.

Mosiah 29:24 And now behold I say unto you, it is not expedient that such abominations should come upon you.

Mosiah 29:25 Therefore, choose you by the voice of this people, judges, that ye may be judged according to the laws which have been given you by our fathers, which are correct, and which were given them by the hand of the Lord.

Mosiah 29:26 Now it is not common that the voice of the people desireth anything contrary to that which is right; but it is common for the lesser part of the people to desire that which is not right; therefore this shall ye observe and make it your law—to do your business by the voice of the people.

Mosiah 29:27 And if the time comes that the voice of the people doth choose iniquity, then is the time that the judgments of God will come upon you; yea, then is the time he will visit you with great destruction even as he has hitherto visited this land.

Mosiah 29:28 And now if ye have judges, and they do not judge you according to the law which has been given, ye can cause that they may be judged of a higher judge.

Mosiah 29:29 If your higher judges do not judge righteous judgments, ye shall cause that a small number of your lower judges should be gathered together, and they shall judge your higher judges, according to the voice of the people.

Mosiah 29:30 And I command you to do these things in the fear of the Lord; and I command you to do these things, and that ye have no king; that if these people commit sins and iniquities they shall be answered upon their own heads.

Mosiah 29:31 For behold I say unto you, the sins of many people have been caused by the iniquities of their kings; therefore their iniquities are answered upon the heads of their kings.

Mosiah 29:32 And now I desire that this inequality should be no more in this land, especially among this my people; but I desire that this land be a land of liberty, and every man may enjoy his rights and privileges alike, so long as the Lord sees fit that we may live and inherit the land, yea, even as long as any of our posterity remains upon the face of the land.

Mosiah 29:33 And many more things did king Mosiah write unto them, unfolding unto them all the trials and troubles of a righteous king, yea, all the travails of soul for their people, and also all the murmurings of the people to their king; and he explained it all unto them.

Mosiah 29:34 And he told them that these things ought not to be; but that the burden should come upon all the people, that every man might bear his part.

Mosiah 29:35 And he also unfolded unto them all the disadvantages they labored under, by having an unrighteous king to rule over them;

Mosiah 29:36 Yea, all his iniquities and abominations, and all the wars, and contentions, and bloodshed, and the stealing, and the plundering, and the committing of whoredoms, and all manner of iniquities which cannot be enumerated—telling them that these things ought not to be, that they were expressly repugnant to the commandments of God.

Mosiah 29:37 And now it came to pass, after king Mosiah had sent these things forth among the people they were convinced of the truth of his words.

Mosiah 29:38 Therefore they relinquished their desires for a king, and became exceedingly anxious that every man should have an equal chance throughout all the land; yea, and every man expressed a willingness to answer for his own sins.

Mosiah 29:39 Therefore, it came to pass that they assembled themselves together in bodies throughout the land, to cast in their voices concerning who should be their judges, to judge them according to the law which had been given them; and they were exceedingly rejoiced because of the liberty which had been granted unto them.

Mosiah 29:40 And they did wax strong in love towards Mosiah; yea, they did esteem him more than any other man; for they did not look upon him as a tyrant who was seeking for gain, yea, for that lucre which doth corrupt the soul; for he had not exacted riches of them, neither had he delighted in the shedding of blood; but he had established peace in the land, and he had granted unto his people that they should be delivered from all manner of bondage; therefore they did esteem him, yea, exceedingly, beyond measure.

Mosiah 29:41 And it came to pass that they did appoint judges to rule over them, or to judge them according to the law; and this they did throughout all the land.

Mosiah 29:42 And it came to pass that Alma was appointed to be the first chief judge, he being also the high priest, his father having conferred the office upon him, and having given him the charge concerning all the affairs of the church.

Mosiah 29:43 And now it came to pass that Alma did walk in the ways of the Lord, and he did keep his commandments, and he did judge righteous judgments; and there was continual peace through the land.

Mosiah 29:44 And thus commenced the reign of the judges throughout all the land of Zarahemla, among all the people who were called the Nephites; and Alma was the first and chief judge.

Mosiah 29:45 And now it came to pass that his father died, being eighty and two years old, having lived to fulfil the commandments of God.

Mosiah 29:46 And it came to pass that Mosiah died also, in the thirty and third year of his reign, being sixty and three years old; making in the whole, five hundred and nine years from the time Lehi left Jerusalem.

Mosiah 29:47 And thus ended the reign of the kings over the people of Nephi; and thus ended the days of Alma, who was the founder of their church.
