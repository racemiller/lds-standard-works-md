# Alma 5

Alma 5 (summary): To gain salvation, men must repent and keep the commandments, be born again, cleanse their garments through the blood of Christ, be humble and strip themselves of pride and envy, and do the works of righteousness—The Good Shepherd calls His people—Those who do evil works are children of the devil—Alma testifies of the truth of his doctrine and commands men to repent—The names of the righteous will be written in the book of life. About 83 B.C.

Alma 5:1 Now it came to pass that Alma began to deliver the word of God unto the people, first in the land of Zarahemla, and from thence throughout all the land.

Alma 5:2 And these are the words which he spake to the people in the church which was established in the city of Zarahemla, according to his own record, saying:

Alma 5:3 I, Alma, having been consecrated by my father, Alma, to be a high priest over the church of God, he having power and authority from God to do these things, behold, I say unto you that he began to establish a church in the land which was in the borders of Nephi; yea, the land which was called the land of Mormon; yea, and he did baptize his brethren in the waters of Mormon.

Alma 5:4 And behold, I say unto you, they were delivered out of the hands of the people of king Noah, by the mercy and power of God.

Alma 5:5 And behold, after that, they were brought into bondage by the hands of the Lamanites in the wilderness; yea, I say unto you, they were in captivity, and again the Lord did deliver them out of bondage by the power of his word; and we were brought into this land, and here we began to establish the church of God throughout this land also.

Alma 5:6 And now behold, I say unto you, my brethren, you that belong to this church, have you sufficiently retained in remembrance the captivity of your fathers? Yea, and have you sufficiently retained in remembrance his mercy and long-suffering towards them? And moreover, have ye sufficiently retained in remembrance that he has delivered their souls from hell?

Alma 5:7 Behold, he changed their hearts; yea, he awakened them out of a deep sleep, and they awoke unto God. Behold, they were in the midst of darkness; nevertheless, their souls were illuminated by the light of the everlasting word; yea, they were encircled about by the bands of death, and the chains of hell, and an everlasting destruction did await them.

Alma 5:8 And now I ask of you, my brethren, were they destroyed? Behold, I say unto you, Nay, they were not.

Alma 5:9 And again I ask, were the bands of death broken, and the chains of hell which encircled them about, were they loosed? I say unto you, Yea, they were loosed, and their souls did expand, and they did sing redeeming love. And I say unto you that they are saved.

Alma 5:10 And now I ask of you on what conditions are they saved? Yea, what grounds had they to hope for salvation? What is the cause of their being loosed from the bands of death, yea, and also the chains of hell?

Alma 5:11 Behold, I can tell you—did not my father Alma believe in the words which were delivered by the mouth of Abinadi? And was he not a holy prophet? Did he not speak the words of God, and my father Alma believe them?

Alma 5:12 And according to his faith there was a mighty change wrought in his heart. Behold I say unto you that this is all true.

Alma 5:13 And behold, he preached the word unto your fathers, and a mighty change was also wrought in their hearts, and they humbled themselves and put their trust in the true and living God. And behold, they were faithful until the end; therefore they were saved.

Alma 5:14 And now behold, I ask of you, my brethren of the church, have ye spiritually been born of God? Have ye received his image in your countenances? Have ye experienced this mighty change in your hearts?

Alma 5:15 Do ye exercise faith in the redemption of him who created you? Do you look forward with an eye of faith, and view this mortal body raised in immortality, and this corruption raised in incorruption, to stand before God to be judged according to the deeds which have been done in the mortal body?

Alma 5:16 I say unto you, can you imagine to yourselves that ye hear the voice of the Lord, saying unto you, in that day: Come unto me ye blessed, for behold, your works have been the works of righteousness upon the face of the earth?

Alma 5:17 Or do ye imagine to yourselves that ye can lie unto the Lord in that day, and say—Lord, our works have been righteous works upon the face of the earth—and that he will save you?

Alma 5:18 Or otherwise, can ye imagine yourselves brought before the tribunal of God with your souls filled with guilt and remorse, having a remembrance of all your guilt, yea, a perfect remembrance of all your wickedness, yea, a remembrance that ye have set at defiance the commandments of God?

Alma 5:19 I say unto you, can ye look up to God at that day with a pure heart and clean hands? I say unto you, can you look up, having the image of God engraven upon your countenances?

Alma 5:20 I say unto you, can ye think of being saved when you have yielded yourselves to become subjects to the devil?

Alma 5:21 I say unto you, ye will know at that day that ye cannot be saved; for there can no man be saved except his garments are washed white; yea, his garments must be purified until they are cleansed from all stain, through the blood of him of whom it has been spoken by our fathers, who should come to redeem his people from their sins.

Alma 5:22 And now I ask of you, my brethren, how will any of you feel, if ye shall stand before the bar of God, having your garments stained with blood and all manner of filthiness? Behold, what will these things testify against you?

Alma 5:23 Behold will they not testify that ye are murderers, yea, and also that ye are guilty of all manner of wickedness?

Alma 5:24 Behold, my brethren, do ye suppose that such an one can have a place to sit down in the kingdom of God, with Abraham, with Isaac, and with Jacob, and also all the holy prophets, whose garments are cleansed and are spotless, pure and white?

Alma 5:25 I say unto you, Nay; except ye make our Creator a liar from the beginning, or suppose that he is a liar from the beginning, ye cannot suppose that such can have place in the kingdom of heaven; but they shall be cast out for they are the children of the kingdom of the devil.

Alma 5:26 And now behold, I say unto you, my brethren, if ye have experienced a change of heart, and if ye have felt to sing the song of redeeming love, I would ask, can ye feel so now?

Alma 5:27 Have ye walked, keeping yourselves blameless before God? Could ye say, if ye were called to die at this time, within yourselves, that ye have been sufficiently humble? That your garments have been cleansed and made white through the blood of Christ, who will come to redeem his people from their sins?

Alma 5:28 Behold, are ye stripped of pride? I say unto you, if ye are not ye are not prepared to meet God. Behold ye must prepare quickly; for the kingdom of heaven is soon at hand, and such an one hath not eternal life.

Alma 5:29 Behold, I say, is there one among you who is not stripped of envy? I say unto you that such an one is not prepared; and I would that he should prepare quickly, for the hour is close at hand, and he knoweth not when the time shall come; for such an one is not found guiltless.

Alma 5:30 And again I say unto you, is there one among you that doth make a mock of his brother, or that heapeth upon him persecutions?

Alma 5:31 Wo unto such an one, for he is not prepared, and the time is at hand that he must repent or he cannot be saved!

Alma 5:32 Yea, even wo unto all ye workers of iniquity; repent, repent, for the Lord God hath spoken it!

Alma 5:33 Behold, he sendeth an invitation unto all men, for the arms of mercy are extended towards them, and he saith: Repent, and I will receive you.

Alma 5:34 Yea, he saith: Come unto me and ye shall partake of the fruit of the tree of life; yea, ye shall eat and drink of the bread and the waters of life freely;

Alma 5:35 Yea, come unto me and bring forth works of righteousness, and ye shall not be hewn down and cast into the fire—

Alma 5:36 For behold, the time is at hand that whosoever bringeth forth not good fruit, or whosoever doeth not the works of righteousness, the same have cause to wail and mourn.

Alma 5:37 O ye workers of iniquity; ye that are puffed up in the vain things of the world, ye that have professed to have known the ways of righteousness nevertheless have gone astray, as sheep having no shepherd, notwithstanding a shepherd hath called after you and is still calling after you, but ye will not hearken unto his voice!

Alma 5:38 Behold, I say unto you, that the good shepherd doth call you; yea, and in his own name he doth call you, which is the name of Christ; and if ye will not hearken unto the voice of the good shepherd, to the name by which ye are called, behold, ye are not the sheep of the good shepherd.

Alma 5:39 And now if ye are not the sheep of the good shepherd, of what fold are ye? Behold, I say unto you, that the devil is your shepherd, and ye are of his fold; and now, who can deny this? Behold, I say unto you, whosoever denieth this is a liar and a child of the devil.

Alma 5:40 For I say unto you that whatsoever is good cometh from God, and whatsoever is evil cometh from the devil.

Alma 5:41 Therefore, if a man bringeth forth good works he hearkeneth unto the voice of the good shepherd, and he doth follow him; but whosoever bringeth forth evil works, the same becometh a child of the devil, for he hearkeneth unto his voice, and doth follow him.

Alma 5:42 And whosoever doeth this must receive his wages of him; therefore, for his wages he receiveth death, as to things pertaining unto righteousness, being dead unto all good works.

Alma 5:43 And now, my brethren, I would that ye should hear me, for I speak in the energy of my soul; for behold, I have spoken unto you plainly that ye cannot err, or have spoken according to the commandments of God.

Alma 5:44 For I am called to speak after this manner, according to the holy order of God, which is in Christ Jesus; yea, I am commanded to stand and testify unto this people the things which have been spoken by our fathers concerning the things which are to come.

Alma 5:45 And this is not all. Do ye not suppose that I know of these things myself? Behold, I testify unto you that I do know that these things whereof I have spoken are true. And how do ye suppose that I know of their surety?

Alma 5:46 Behold, I say unto you they are made known unto me by the Holy Spirit of God. Behold, I have fasted and prayed many days that I might know these things of myself. And now I do know of myself that they are true; for the Lord God hath made them manifest unto me by his Holy Spirit; and this is the spirit of revelation which is in me.

Alma 5:47 And moreover, I say unto you that it has thus been revealed unto me, that the words which have been spoken by our fathers are true, even so according to the spirit of prophecy which is in me, which is also by the manifestation of the Spirit of God.

Alma 5:48 I say unto you, that I know of myself that whatsoever I shall say unto you, concerning that which is to come, is true; and I say unto you, that I know that Jesus Christ shall come, yea, the Son, the Only Begotten of the Father, full of grace, and mercy, and truth. And behold, it is he that cometh to take away the sins of the world, yea, the sins of every man who steadfastly believeth on his name.

Alma 5:49 And now I say unto you that this is the order after which I am called, yea, to preach unto my beloved brethren, yea, and every one that dwelleth in the land; yea, to preach unto all, both old and young, both bond and free; yea, I say unto you the aged, and also the middle aged, and the rising generation; yea, to cry unto them that they must repent and be born again.

Alma 5:50 Yea, thus saith the Spirit: Repent, all ye ends of the earth, for the kingdom of heaven is soon at hand; yea, the Son of God cometh in his glory, in his might, majesty, power, and dominion. Yea, my beloved brethren, I say unto you, that the Spirit saith: Behold the glory of the King of all the earth; and also the King of heaven shall very soon shine forth among all the children of men.

Alma 5:51 And also the Spirit saith unto me, yea, crieth unto me with a mighty voice, saying: Go forth and say unto this people—Repent, for except ye repent ye can in nowise inherit the kingdom of heaven.

Alma 5:52 And again I say unto you, the Spirit saith: Behold, the ax is laid at the root of the tree; therefore every tree that bringeth not forth good fruit shall be hewn down and cast into the fire, yea, a fire which cannot be consumed, even an unquenchable fire. Behold, and remember, the Holy One hath spoken it.

Alma 5:53 And now my beloved brethren, I say unto you, can ye withstand these sayings; yea, can ye lay aside these things, and trample the Holy One under your feet; yea, can ye be puffed up in the pride of your hearts; yea, will ye still persist in the wearing of costly apparel and setting your hearts upon the vain things of the world, upon your riches?

Alma 5:54 Yea, will ye persist in supposing that ye are better one than another; yea, will ye persist in the persecution of your brethren, who humble themselves and do walk after the holy order of God, wherewith they have been brought into this church, having been sanctified by the Holy Spirit, and they do bring forth works which are meet for repentance—

Alma 5:55 Yea, and will you persist in turning your backs upon the poor, and the needy, and in withholding your substance from them?

Alma 5:56 And finally, all ye that will persist in your wickedness, I say unto you that these are they who shall be hewn down and cast into the fire except they speedily repent.

Alma 5:57 And now I say unto you, all you that are desirous to follow the voice of the good shepherd, come ye out from the wicked, and be ye separate, and touch not their unclean things; and behold, their names shall be blotted out, that the names of the wicked shall not be numbered among the names of the righteous, that the word of God may be fulfilled, which saith: The names of the wicked shall not be mingled with the names of my people;

Alma 5:58 For the names of the righteous shall be written in the book of life, and unto them will I grant an inheritance at my right hand. And now, my brethren, what have ye to say against this? I say unto you, if ye speak against it, it matters not, for the word of God must be fulfilled.

Alma 5:59 For what shepherd is there among you having many sheep doth not watch over them, that the wolves enter not and devour his flock? And behold, if a wolf enter his flock doth he not drive him out? Yea, and at the last, if he can, he will destroy him.

Alma 5:60 And now I say unto you that the good shepherd doth call after you; and if you will hearken unto his voice he will bring you into his fold, and ye are his sheep; and he commandeth you that ye suffer no ravenous wolf to enter among you, that ye may not be destroyed.

Alma 5:61 And now I, Alma, do command you in the language of him who hath commanded me, that ye observe to do the words which I have spoken unto you.

Alma 5:62 I speak by way of command unto you that belong to the church; and unto those who do not belong to the church I speak by way of invitation, saying: Come and be baptized unto repentance, that ye also may be partakers of the fruit of the tree of life.
