# 2 Nephi 22

2 Nephi 22 (summary): In the millennial day all men will praise the Lord—He will dwell among them—Compare Isaiah 12. About 559–545 B.C.

2 Nephi 22:1 And in that day thou shalt say: O Lord, I will praise thee; though thou wast angry with me thine anger is turned away, and thou comfortedst me.

2 Nephi 22:2 Behold, God is my salvation; I will trust, and not be afraid; for the Lord Jehovah is my strength and my song; he also has become my salvation.

2 Nephi 22:3 Therefore, with joy shall ye draw water out of the wells of salvation.

2 Nephi 22:4 And in that day shall ye say: Praise the Lord, call upon his name, declare his doings among the people, make mention that his name is exalted.

2 Nephi 22:5 Sing unto the Lord; for he hath done excellent things; this is known in all the earth.

2 Nephi 22:6 Cry out and shout, thou inhabitant of Zion; for great is the Holy One of Israel in the midst of thee.
