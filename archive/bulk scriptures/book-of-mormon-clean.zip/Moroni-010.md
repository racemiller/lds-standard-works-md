# Moroni 10

Moroni 10 (summary): A testimony of the Book of Mormon comes by the power of the Holy Ghost—The gifts of the Spirit are dispensed to the faithful—Spiritual gifts always accompany faith—Moroni’s words speak from the dust—Come unto Christ, be perfected in Him, and sanctify your souls. About A.D. 421.

Moroni 10:1 Now I, Moroni, write somewhat as seemeth me good; and I write unto my brethren, the Lamanites; and I would that they should know that more than four hundred and twenty years have passed away since the sign was given of the coming of Christ.

Moroni 10:2 And I seal up these records, after I have spoken a few words by way of exhortation unto you.

Moroni 10:3 Behold, I would exhort you that when ye shall read these things, if it be wisdom in God that ye should read them, that ye would remember how merciful the Lord hath been unto the children of men, from the creation of Adam even down until the time that ye shall receive these things, and ponder it in your hearts.

Moroni 10:4 And when ye shall receive these things, I would exhort you that ye would ask God, the Eternal Father, in the name of Christ, if these things are not true; and if ye shall ask with a sincere heart, with real intent, having faith in Christ, he will manifest the truth of it unto you, by the power of the Holy Ghost.

Moroni 10:5 And by the power of the Holy Ghost ye may know the truth of all things.

Moroni 10:6 And whatsoever thing is good is just and true; wherefore, nothing that is good denieth the Christ, but acknowledgeth that he is.

Moroni 10:7 And ye may know that he is, by the power of the Holy Ghost; wherefore I would exhort you that ye deny not the power of God; for he worketh by power, according to the faith of the children of men, the same today and tomorrow, and forever.

Moroni 10:8 And again, I exhort you, my brethren, that ye deny not the gifts of God, for they are many; and they come from the same God. And there are different ways that these gifts are administered; but it is the same God who worketh all in all; and they are given by the manifestations of the Spirit of God unto men, to profit them.

Moroni 10:9 For behold, to one is given by the Spirit of God, that he may teach the word of wisdom;

Moroni 10:10 And to another, that he may teach the word of knowledge by the same Spirit;

Moroni 10:11 And to another, exceedingly great faith; and to another, the gifts of healing by the same Spirit;

Moroni 10:12 And again, to another, that he may work mighty miracles;

Moroni 10:13 And again, to another, that he may prophesy concerning all things;

Moroni 10:14 And again, to another, the beholding of angels and ministering spirits;

Moroni 10:15 And again, to another, all kinds of tongues;

Moroni 10:16 And again, to another, the interpretation of languages and of divers kinds of tongues.

Moroni 10:17 And all these gifts come by the Spirit of Christ; and they come unto every man severally, according as he will.

Moroni 10:18 And I would exhort you, my beloved brethren, that ye remember that every good gift cometh of Christ.

Moroni 10:19 And I would exhort you, my beloved brethren, that ye remember that he is the same yesterday, today, and forever, and that all these gifts of which I have spoken, which are spiritual, never will be done away, even as long as the world shall stand, only according to the unbelief of the children of men.

Moroni 10:20 Wherefore, there must be faith; and if there must be faith there must also be hope; and if there must be hope there must also be charity.

Moroni 10:21 And except ye have charity ye can in nowise be saved in the kingdom of God; neither can ye be saved in the kingdom of God if ye have not faith; neither can ye if ye have no hope.

Moroni 10:22 And if ye have no hope ye must needs be in despair; and despair cometh because of iniquity.

Moroni 10:23 And Christ truly said unto our fathers: If ye have faith ye can do all things which are expedient unto me.

Moroni 10:24 And now I speak unto all the ends of the earth—that if the day cometh that the power and gifts of God shall be done away among you, it shall be because of unbelief.

Moroni 10:25 And wo be unto the children of men if this be the case; for there shall be none that doeth good among you, no not one. For if there be one among you that doeth good, he shall work by the power and gifts of God.

Moroni 10:26 And wo unto them who shall do these things away and die, for they die in their sins, and they cannot be saved in the kingdom of God; and I speak it according to the words of Christ; and I lie not.

Moroni 10:27 And I exhort you to remember these things; for the time speedily cometh that ye shall know that I lie not, for ye shall see me at the bar of God; and the Lord God will say unto you: Did I not declare my words unto you, which were written by this man, like as one crying from the dead, yea, even as one speaking out of the dust?

Moroni 10:28 I declare these things unto the fulfilling of the prophecies. And behold, they shall proceed forth out of the mouth of the everlasting God; and his word shall hiss forth from generation to generation.

Moroni 10:29 And God shall show unto you, that that which I have written is true.

Moroni 10:30 And again I would exhort you that ye would come unto Christ, and lay hold upon every good gift, and touch not the evil gift, nor the unclean thing.

Moroni 10:31 And awake, and arise from the dust, O Jerusalem; yea, and put on thy beautiful garments, O daughter of Zion; and strengthen thy stakes and enlarge thy borders forever, that thou mayest no more be confounded, that the covenants of the Eternal Father which he hath made unto thee, O house of Israel, may be fulfilled.

Moroni 10:32 Yea, come unto Christ, and be perfected in him, and deny yourselves of all ungodliness; and if ye shall deny yourselves of all ungodliness, and love God with all your might, mind and strength, then is his grace sufficient for you, that by his grace ye may be perfect in Christ; and if by the grace of God ye are perfect in Christ, ye can in nowise deny the power of God.

Moroni 10:33 And again, if ye by the grace of God are perfect in Christ, and deny not his power, then are ye sanctified in Christ by the grace of God, through the shedding of the blood of Christ, which is in the covenant of the Father unto the remission of your sins, that ye become holy, without spot.

Moroni 10:34 And now I bid unto all, farewell. I soon go to rest in the paradise of God, until my spirit and body shall again reunite, and I am brought forth triumphant through the air, to meet you before the pleasing bar of the great Jehovah, the Eternal Judge of both quick and dead. Amen.
