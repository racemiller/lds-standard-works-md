# Helaman 4

Helaman 4 (summary): Nephite dissenters and the Lamanites join forces and take the land of Zarahemla—The Nephites’ defeats come because of their wickedness—The Church dwindles, and the people become weak like the Lamanites. About 38–30 B.C.

Helaman 4:1 And it came to pass in the fifty and fourth year there were many dissensions in the church, and there was also a contention among the people, insomuch that there was much bloodshed.

Helaman 4:2 And the rebellious part were slain and driven out of the land, and they did go unto the king of the Lamanites.

Helaman 4:3 And it came to pass that they did endeavor to stir up the Lamanites to war against the Nephites; but behold, the Lamanites were exceedingly afraid, insomuch that they would not hearken to the words of those dissenters.

Helaman 4:4 But it came to pass in the fifty and sixth year of the reign of the judges, there were dissenters who went up from the Nephites unto the Lamanites; and they succeeded with those others in stirring them up to anger against the Nephites; and they were all that year preparing for war.

Helaman 4:5 And in the fifty and seventh year they did come down against the Nephites to battle, and they did commence the work of death; yea, insomuch that in the fifty and eighth year of the reign of the judges they succeeded in obtaining possession of the land of Zarahemla; yea, and also all the lands, even unto the land which was near the land Bountiful.

Helaman 4:6 And the Nephites and the armies of Moronihah were driven even into the land of Bountiful;

Helaman 4:7 And there they did fortify against the Lamanites, from the west sea, even unto the east; it being a day’s journey for a Nephite, on the line which they had fortified and stationed their armies to defend their north country.

Helaman 4:8 And thus those dissenters of the Nephites, with the help of a numerous army of the Lamanites, had obtained all the possession of the Nephites which was in the land southward. And all this was done in the fifty and eighth and ninth years of the reign of the judges.

Helaman 4:9 And it came to pass in the sixtieth year of the reign of the judges, Moronihah did succeed with his armies in obtaining many parts of the land; yea, they regained many cities which had fallen into the hands of the Lamanites.

Helaman 4:10 And it came to pass in the sixty and first year of the reign of the judges they succeeded in regaining even the half of all their possessions.

Helaman 4:11 Now this great loss of the Nephites, and the great slaughter which was among them, would not have happened had it not been for their wickedness and their abomination which was among them; yea, and it was among those also who professed to belong to the church of God.

Helaman 4:12 And it was because of the pride of their hearts, because of their exceeding riches, yea, it was because of their oppression to the poor, withholding their food from the hungry, withholding their clothing from the naked, and smiting their humble brethren upon the cheek, making a mock of that which was sacred, denying the spirit of prophecy and of revelation, murdering, plundering, lying, stealing, committing adultery, rising up in great contentions, and deserting away into the land of Nephi, among the Lamanites—

Helaman 4:13 And because of this their great wickedness, and their boastings in their own strength, they were left in their own strength; therefore they did not prosper, but were afflicted and smitten, and driven before the Lamanites, until they had lost possession of almost all their lands.

Helaman 4:14 But behold, Moronihah did preach many things unto the people because of their iniquity, and also Nephi and Lehi, who were the sons of Helaman, did preach many things unto the people, yea, and did prophesy many things unto them concerning their iniquities, and what should come unto them if they did not repent of their sins.

Helaman 4:15 And it came to pass that they did repent, and inasmuch as they did repent they did begin to prosper.

Helaman 4:16 For when Moronihah saw that they did repent he did venture to lead them forth from place to place, and from city to city, even until they had regained the one-half of their property and the one-half of all their lands.

Helaman 4:17 And thus ended the sixty and first year of the reign of the judges.

Helaman 4:18 And it came to pass in the sixty and second year of the reign of the judges, that Moronihah could obtain no more possessions over the Lamanites.

Helaman 4:19 Therefore they did abandon their design to obtain the remainder of their lands, for so numerous were the Lamanites that it became impossible for the Nephites to obtain more power over them; therefore Moronihah did employ all his armies in maintaining those parts which he had taken.

Helaman 4:20 And it came to pass, because of the greatness of the number of the Lamanites the Nephites were in great fear, lest they should be overpowered, and trodden down, and slain, and destroyed.

Helaman 4:21 Yea, they began to remember the prophecies of Alma, and also the words of Mosiah; and they saw that they had been a stiffnecked people, and that they had set at naught the commandments of God;

Helaman 4:22 And that they had altered and trampled under their feet the laws of Mosiah, or that which the Lord commanded him to give unto the people; and they saw that their laws had become corrupted, and that they had become a wicked people, insomuch that they were wicked even like unto the Lamanites.

Helaman 4:23 And because of their iniquity the church had begun to dwindle; and they began to disbelieve in the spirit of prophecy and in the spirit of revelation; and the judgments of God did stare them in the face.

Helaman 4:24 And they saw that they had become weak, like unto their brethren, the Lamanites, and that the Spirit of the Lord did no more preserve them; yea, it had withdrawn from them because the Spirit of the Lord doth not dwell in unholy temples—

Helaman 4:25 Therefore the Lord did cease to preserve them by his miraculous and matchless power, for they had fallen into a state of unbelief and awful wickedness; and they saw that the Lamanites were exceedingly more numerous than they, and except they should cleave unto the Lord their God they must unavoidably perish.

Helaman 4:26 For behold, they saw that the strength of the Lamanites was as great as their strength, even man for man. And thus had they fallen into this great transgression; yea, thus had they become weak, because of their transgression, in the space of not many years.
