# 2 Nephi 16

2 Nephi 16 (summary): Isaiah sees the Lord—Isaiah’s sins are forgiven—He is called to prophesy—He prophesies of the rejection by the Jews of Christ’s teachings—A remnant will return—Compare Isaiah 6. About 559–545 B.C.

2 Nephi 16:1 In the year that king Uzziah died, I saw also the Lord sitting upon a throne, high and lifted up, and his train filled the temple.

2 Nephi 16:2 Above it stood the seraphim; each one had six wings; with twain he covered his face, and with twain he covered his feet, and with twain he did fly.

2 Nephi 16:3 And one cried unto another, and said: Holy, holy, holy, is the Lord of Hosts; the whole earth is full of his glory.

2 Nephi 16:4 And the posts of the door moved at the voice of him that cried, and the house was filled with smoke.

2 Nephi 16:5 Then said I: Wo is unto me! for I am undone; because I am a man of unclean lips; and I dwell in the midst of a people of unclean lips; for mine eyes have seen the King, the Lord of Hosts.

2 Nephi 16:6 Then flew one of the seraphim unto me, having a live coal in his hand, which he had taken with the tongs from off the altar;

2 Nephi 16:7 And he laid it upon my mouth, and said: Lo, this has touched thy lips; and thine iniquity is taken away, and thy sin purged.

2 Nephi 16:8 Also I heard the voice of the Lord, saying: Whom shall I send, and who will go for us? Then I said: Here am I; send me.

2 Nephi 16:9 And he said: Go and tell this people—Hear ye indeed, but they understood not; and see ye indeed, but they perceived not.

2 Nephi 16:10 Make the heart of this people fat, and make their ears heavy, and shut their eyes—lest they see with their eyes, and hear with their ears, and understand with their heart, and be converted and be healed.

2 Nephi 16:11 Then said I: Lord, how long? And he said: Until the cities be wasted without inhabitant, and the houses without man, and the land be utterly desolate;

2 Nephi 16:12 And the Lord have removed men far away, for there shall be a great forsaking in the midst of the land.

2 Nephi 16:13 But yet there shall be a tenth, and they shall return, and shall be eaten, as a teil tree, and as an oak whose substance is in them when they cast their leaves; so the holy seed shall be the substance thereof.
