# Mosiah 3

Mosiah 3 (summary): King Benjamin continues his address—The Lord Omnipotent will minister among men in a tabernacle of clay—Blood will come from every pore as He atones for the sins of the world—His is the only name whereby salvation comes—Men can put off the natural man and become Saints through the Atonement—The torment of the wicked will be as a lake of fire and brimstone. About 124 B.C.

Mosiah 3:1 And again my brethren, I would call your attention, for I have somewhat more to speak unto you; for behold, I have things to tell you concerning that which is to come.

Mosiah 3:2 And the things which I shall tell you are made known unto me by an angel from God. And he said unto me: Awake; and I awoke, and behold he stood before me.

Mosiah 3:3 And he said unto me: Awake, and hear the words which I shall tell thee; for behold, I am come to declare unto you the glad tidings of great joy.

Mosiah 3:4 For the Lord hath heard thy prayers, and hath judged of thy righteousness, and hath sent me to declare unto thee that thou mayest rejoice; and that thou mayest declare unto thy people, that they may also be filled with joy.

Mosiah 3:5 For behold, the time cometh, and is not far distant, that with power, the Lord Omnipotent who reigneth, who was, and is from all eternity to all eternity, shall come down from heaven among the children of men, and shall dwell in a tabernacle of clay, and shall go forth amongst men, working mighty miracles, such as healing the sick, raising the dead, causing the lame to walk, the blind to receive their sight, and the deaf to hear, and curing all manner of diseases.

Mosiah 3:6 And he shall cast out devils, or the evil spirits which dwell in the hearts of the children of men.

Mosiah 3:7 And lo, he shall suffer temptations, and pain of body, hunger, thirst, and fatigue, even more than man can suffer, except it be unto death; for behold, blood cometh from every pore, so great shall be his anguish for the wickedness and the abominations of his people.

Mosiah 3:8 And he shall be called Jesus Christ, the Son of God, the Father of heaven and earth, the Creator of all things from the beginning; and his mother shall be called Mary.

Mosiah 3:9 And lo, he cometh unto his own, that salvation might come unto the children of men even through faith on his name; and even after all this they shall consider him a man, and say that he hath a devil, and shall scourge him, and shall crucify him.

Mosiah 3:10 And he shall rise the third day from the dead; and behold, he standeth to judge the world; and behold, all these things are done that a righteous judgment might come upon the children of men.

Mosiah 3:11 For behold, and also his blood atoneth for the sins of those who have fallen by the transgression of Adam, who have died not knowing the will of God concerning them, or who have ignorantly sinned.

Mosiah 3:12 But wo, wo unto him who knoweth that he rebelleth against God! For salvation cometh to none such except it be through repentance and faith on the Lord Jesus Christ.

Mosiah 3:13 And the Lord God hath sent his holy prophets among all the children of men, to declare these things to every kindred, nation, and tongue, that thereby whosoever should believe that Christ should come, the same might receive remission of their sins, and rejoice with exceedingly great joy, even as though he had already come among them.

Mosiah 3:14 Yet the Lord God saw that his people were a stiffnecked people, and he appointed unto them a law, even the law of Moses.

Mosiah 3:15 And many signs, and wonders, and types, and shadows showed he unto them, concerning his coming; and also holy prophets spake unto them concerning his coming; and yet they hardened their hearts, and understood not that the law of Moses availeth nothing except it were through the atonement of his blood.

Mosiah 3:16 And even if it were possible that little children could sin they could not be saved; but I say unto you they are blessed; for behold, as in Adam, or by nature, they fall, even so the blood of Christ atoneth for their sins.

Mosiah 3:17 And moreover, I say unto you, that there shall be no other name given nor any other way nor means whereby salvation can come unto the children of men, only in and through the name of Christ, the Lord Omnipotent.

Mosiah 3:18 For behold he judgeth, and his judgment is just; and the infant perisheth not that dieth in his infancy; but men drink damnation to their own souls except they humble themselves and become as little children, and believe that salvation was, and is, and is to come, in and through the atoning blood of Christ, the Lord Omnipotent.

Mosiah 3:19 For the natural man is an enemy to God, and has been from the fall of Adam, and will be, forever and ever, unless he yields to the enticings of the Holy Spirit, and putteth off the natural man and becometh a saint through the atonement of Christ the Lord, and becometh as a child, submissive, meek, humble, patient, full of love, willing to submit to all things which the Lord seeth fit to inflict upon him, even as a child doth submit to his father.

Mosiah 3:20 And moreover, I say unto you, that the time shall come when the knowledge of a Savior shall spread throughout every nation, kindred, tongue, and people.

Mosiah 3:21 And behold, when that time cometh, none shall be found blameless before God, except it be little children, only through repentance and faith on the name of the Lord God Omnipotent.

Mosiah 3:22 And even at this time, when thou shalt have taught thy people the things which the Lord thy God hath commanded thee, even then are they found no more blameless in the sight of God, only according to the words which I have spoken unto thee.

Mosiah 3:23 And now I have spoken the words which the Lord God hath commanded me.

Mosiah 3:24 And thus saith the Lord: They shall stand as a bright testimony against this people, at the judgment day; whereof they shall be judged, every man according to his works, whether they be good, or whether they be evil.

Mosiah 3:25 And if they be evil they are consigned to an awful view of their own guilt and abominations, which doth cause them to shrink from the presence of the Lord into a state of misery and endless torment, from whence they can no more return; therefore they have drunk damnation to their own souls.

Mosiah 3:26 Therefore, they have drunk out of the cup of the wrath of God, which justice could no more deny unto them than it could deny that Adam should fall because of his partaking of the forbidden fruit; therefore, mercy could have claim on them no more forever.

Mosiah 3:27 And their torment is as a lake of fire and brimstone, whose flames are unquenchable, and whose smoke ascendeth up forever and ever. Thus hath the Lord commanded me. Amen.
