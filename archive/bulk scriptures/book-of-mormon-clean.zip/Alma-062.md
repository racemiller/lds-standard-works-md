# Alma 62

Alma 62 (summary): Moroni marches to the aid of Pahoran in the land of Gideon—The king-men who refuse to defend their country are put to death—Pahoran and Moroni retake Nephihah—Many Lamanites join the people of Ammon—Teancum slays Ammoron and is in turn slain—The Lamanites are driven from the land, and peace is established—Helaman returns to the ministry and builds up the Church. About 62–57 B.C.

Alma 62:1 And now it came to pass that when Moroni had received this epistle his heart did take courage, and was filled with exceedingly great joy because of the faithfulness of Pahoran, that he was not also a traitor to the freedom and cause of his country.

Alma 62:2 But he did also mourn exceedingly because of the iniquity of those who had driven Pahoran from the judgment-seat, yea, in fine because of those who had rebelled against their country and also their God.

Alma 62:3 And it came to pass that Moroni took a small number of men, according to the desire of Pahoran, and gave Lehi and Teancum command over the remainder of his army, and took his march towards the land of Gideon.

Alma 62:4 And he did raise the standard of liberty in whatsoever place he did enter, and gained whatsoever force he could in all his march towards the land of Gideon.

Alma 62:5 And it came to pass that thousands did flock unto his standard, and did take up their swords in the defence of their freedom, that they might not come into bondage.

Alma 62:6 And thus, when Moroni had gathered together whatsoever men he could in all his march, he came to the land of Gideon; and uniting his forces with those of Pahoran they became exceedingly strong, even stronger than the men of Pachus, who was the king of those dissenters who had driven the freemen out of the land of Zarahemla and had taken possession of the land.

Alma 62:7 And it came to pass that Moroni and Pahoran went down with their armies into the land of Zarahemla, and went forth against the city, and did meet the men of Pachus, insomuch that they did come to battle.

Alma 62:8 And behold, Pachus was slain and his men were taken prisoners, and Pahoran was restored to his judgment-seat.

Alma 62:9 And the men of Pachus received their trial, according to the law, and also those king-men who had been taken and cast into prison; and they were executed according to the law; yea, those men of Pachus and those king-men, whosoever would not take up arms in the defence of their country, but would fight against it, were put to death.

Alma 62:10 And thus it became expedient that this law should be strictly observed for the safety of their country; yea, and whosoever was found denying their freedom was speedily executed according to the law.

Alma 62:11 And thus ended the thirtieth year of the reign of the judges over the people of Nephi; Moroni and Pahoran having restored peace to the land of Zarahemla, among their own people, having inflicted death upon all those who were not true to the cause of freedom.

Alma 62:12 And it came to pass in the commencement of the thirty and first year of the reign of the judges over the people of Nephi, Moroni immediately caused that provisions should be sent, and also an army of six thousand men should be sent unto Helaman, to assist him in preserving that part of the land.

Alma 62:13 And he also caused that an army of six thousand men, with a sufficient quantity of food, should be sent to the armies of Lehi and Teancum. And it came to pass that this was done to fortify the land against the Lamanites.

Alma 62:14 And it came to pass that Moroni and Pahoran, leaving a large body of men in the land of Zarahemla, took their march with a large body of men towards the land of Nephihah, being determined to overthrow the Lamanites in that city.

Alma 62:15 And it came to pass that as they were marching towards the land, they took a large body of men of the Lamanites, and slew many of them, and took their provisions and their weapons of war.

Alma 62:16 And it came to pass after they had taken them, they caused them to enter into a covenant that they would no more take up their weapons of war against the Nephites.

Alma 62:17 And when they had entered into this covenant they sent them to dwell with the people of Ammon, and they were in number about four thousand who had not been slain.

Alma 62:18 And it came to pass that when they had sent them away they pursued their march towards the land of Nephihah. And it came to pass that when they had come to the city of Nephihah, they did pitch their tents in the plains of Nephihah, which is near the city of Nephihah.

Alma 62:19 Now Moroni was desirous that the Lamanites should come out to battle against them, upon the plains; but the Lamanites, knowing of their exceedingly great courage, and beholding the greatness of their numbers, therefore they durst not come out against them; therefore they did not come to battle in that day.

Alma 62:20 And when the night came, Moroni went forth in the darkness of the night, and came upon the top of the wall to spy out in what part of the city the Lamanites did camp with their army.

Alma 62:21 And it came to pass that they were on the east, by the entrance; and they were all asleep. And now Moroni returned to his army, and caused that they should prepare in haste strong cords and ladders, to be let down from the top of the wall into the inner part of the wall.

Alma 62:22 And it came to pass that Moroni caused that his men should march forth and come upon the top of the wall, and let themselves down into that part of the city, yea, even on the west, where the Lamanites did not camp with their armies.

Alma 62:23 And it came to pass that they were all let down into the city by night, by the means of their strong cords and their ladders; thus when the morning came they were all within the walls of the city.

Alma 62:24 And now, when the Lamanites awoke and saw that the armies of Moroni were within the walls, they were affrighted exceedingly, insomuch that they did flee out by the pass.

Alma 62:25 And now when Moroni saw that they were fleeing before him, he did cause that his men should march forth against them, and slew many, and surrounded many others, and took them prisoners; and the remainder of them fled into the land of Moroni, which was in the borders by the seashore.

Alma 62:26 Thus had Moroni and Pahoran obtained the possession of the city of Nephihah without the loss of one soul; and there were many of the Lamanites who were slain.

Alma 62:27 Now it came to pass that many of the Lamanites that were prisoners were desirous to join the people of Ammon and become a free people.

Alma 62:28 And it came to pass that as many as were desirous, unto them it was granted according to their desires.

Alma 62:29 Therefore, all the prisoners of the Lamanites did join the people of Ammon, and did begin to labor exceedingly, tilling the ground, raising all manner of grain, and flocks and herds of every kind; and thus were the Nephites relieved from a great burden; yea, insomuch that they were relieved from all the prisoners of the Lamanites.

Alma 62:30 Now it came to pass that Moroni, after he had obtained possession of the city of Nephihah, having taken many prisoners, which did reduce the armies of the Lamanites exceedingly, and having regained many of the Nephites who had been taken prisoners, which did strengthen the army of Moroni exceedingly; therefore Moroni went forth from the land of Nephihah to the land of Lehi.

Alma 62:31 And it came to pass that when the Lamanites saw that Moroni was coming against them, they were again frightened and fled before the army of Moroni.

Alma 62:32 And it came to pass that Moroni and his army did pursue them from city to city, until they were met by Lehi and Teancum; and the Lamanites fled from Lehi and Teancum, even down upon the borders by the seashore, until they came to the land of Moroni.

Alma 62:33 And the armies of the Lamanites were all gathered together, insomuch that they were all in one body in the land of Moroni. Now Ammoron, the king of the Lamanites, was also with them.

Alma 62:34 And it came to pass that Moroni and Lehi and Teancum did encamp with their armies round about in the borders of the land of Moroni, insomuch that the Lamanites were encircled about in the borders by the wilderness on the south, and in the borders by the wilderness on the east.

Alma 62:35 And thus they did encamp for the night. For behold, the Nephites and the Lamanites also were weary because of the greatness of the march; therefore they did not resolve upon any stratagem in the night-time, save it were Teancum; for he was exceedingly angry with Ammoron, insomuch that he considered that Ammoron, and Amalickiah his brother, had been the cause of this great and lasting war between them and the Lamanites, which had been the cause of so much war and bloodshed, yea, and so much famine.

Alma 62:36 And it came to pass that Teancum in his anger did go forth into the camp of the Lamanites, and did let himself down over the walls of the city. And he went forth with a cord, from place to place, insomuch that he did find the king; and he did cast a javelin at him, which did pierce him near the heart. But behold, the king did awaken his servants before he died, insomuch that they did pursue Teancum, and slew him.

Alma 62:37 Now it came to pass that when Lehi and Moroni knew that Teancum was dead they were exceedingly sorrowful; for behold, he had been a man who had fought valiantly for his country, yea, a true friend to liberty; and he had suffered very many exceedingly sore afflictions. But behold, he was dead, and had gone the way of all the earth.

Alma 62:38 Now it came to pass that Moroni marched forth on the morrow, and came upon the Lamanites, insomuch that they did slay them with a great slaughter; and they did drive them out of the land; and they did flee, even that they did not return at that time against the Nephites.

Alma 62:39 And thus ended the thirty and first year of the reign of the judges over the people of Nephi; and thus they had had wars, and bloodsheds, and famine, and affliction, for the space of many years.

Alma 62:40 And there had been murders, and contentions, and dissensions, and all manner of iniquity among the people of Nephi; nevertheless for the righteous’ sake, yea, because of the prayers of the righteous, they were spared.

Alma 62:41 But behold, because of the exceedingly great length of the war between the Nephites and the Lamanites many had become hardened, because of the exceedingly great length of the war; and many were softened because of their afflictions, insomuch that they did humble themselves before God, even in the depth of humility.

Alma 62:42 And it came to pass that after Moroni had fortified those parts of the land which were most exposed to the Lamanites, until they were sufficiently strong, he returned to the city of Zarahemla; and also Helaman returned to the place of his inheritance; and there was once more peace established among the people of Nephi.

Alma 62:43 And Moroni yielded up the command of his armies into the hands of his son, whose name was Moronihah; and he retired to his own house that he might spend the remainder of his days in peace.

Alma 62:44 And Pahoran did return to his judgment-seat; and Helaman did take upon him again to preach unto the people the word of God; for because of so many wars and contentions it had become expedient that a regulation should be made again in the church.

Alma 62:45 Therefore, Helaman and his brethren went forth, and did declare the word of God with much power unto the convincing of many people of their wickedness, which did cause them to repent of their sins and to be baptized unto the Lord their God.

Alma 62:46 And it came to pass that they did establish again the church of God, throughout all the land.

Alma 62:47 Yea, and regulations were made concerning the law. And their judges, and their chief judges were chosen.

Alma 62:48 And the people of Nephi began to prosper again in the land, and began to multiply and to wax exceedingly strong again in the land. And they began to grow exceedingly rich.

Alma 62:49 But notwithstanding their riches, or their strength, or their prosperity, they were not lifted up in the pride of their eyes; neither were they slow to remember the Lord their God; but they did humble themselves exceedingly before him.

Alma 62:50 Yea, they did remember how great things the Lord had done for them, that he had delivered them from death, and from bonds, and from prisons, and from all manner of afflictions, and he had delivered them out of the hands of their enemies.

Alma 62:51 And they did pray unto the Lord their God continually, insomuch that the Lord did bless them, according to his word, so that they did wax strong and prosper in the land.

Alma 62:52 And it came to pass that all these things were done. And Helaman died, in the thirty and fifth year of the reign of the judges over the people of Nephi.
