# 3 Nephi 23

3 Nephi 23 (summary): Jesus approves the words of Isaiah—He commands the people to search the prophets—The words of Samuel the Lamanite concerning the Resurrection are added to their records. About A.D. 34.

3 Nephi 23:1 And now, behold, I say unto you, that ye ought to search these things. Yea, a commandment I give unto you that ye search these things diligently; for great are the words of Isaiah.

3 Nephi 23:2 For surely he spake as touching all things concerning my people which are of the house of Israel; therefore it must needs be that he must speak also to the Gentiles.

3 Nephi 23:3 And all things that he spake have been and shall be, even according to the words which he spake.

3 Nephi 23:4 Therefore give heed to my words; write the things which I have told you; and according to the time and the will of the Father they shall go forth unto the Gentiles.

3 Nephi 23:5 And whosoever will hearken unto my words and repenteth and is baptized, the same shall be saved. Search the prophets, for many there be that testify of these things.

3 Nephi 23:6 And now it came to pass that when Jesus had said these words he said unto them again, after he had expounded all the scriptures unto them which they had received, he said unto them: Behold, other scriptures I would that ye should write, that ye have not.

3 Nephi 23:7 And it came to pass that he said unto Nephi: Bring forth the record which ye have kept.

3 Nephi 23:8 And when Nephi had brought forth the records, and laid them before him, he cast his eyes upon them and said:

3 Nephi 23:9 Verily I say unto you, I commanded my servant Samuel, the Lamanite, that he should testify unto this people, that at the day that the Father should glorify his name in me that there were many saints who should arise from the dead, and should appear unto many, and should minister unto them. And he said unto them: Was it not so?

3 Nephi 23:10 And his disciples answered him and said: Yea, Lord, Samuel did prophesy according to thy words, and they were all fulfilled.

3 Nephi 23:11 And Jesus said unto them: How be it that ye have not written this thing, that many saints did arise and appear unto many and did minister unto them?

3 Nephi 23:12 And it came to pass that Nephi remembered that this thing had not been written.

3 Nephi 23:13 And it came to pass that Jesus commanded that it should be written; therefore it was written according as he commanded.

3 Nephi 23:14 And now it came to pass that when Jesus had expounded all the scriptures in one, which they had written, he commanded them that they should teach the things which he had expounded unto them.
