# Helaman 1

Helaman 1 (summary): Pahoran the second becomes chief judge and is murdered by Kishkumen—Pacumeni fills the judgment seat—Coriantumr leads the Lamanite armies, takes Zarahemla, and slays Pacumeni—Moronihah defeats the Lamanites and retakes Zarahemla, and Coriantumr is slain. About 52–50 B.C.

Helaman 1:1 And now behold, it came to pass in the commencement of the fortieth year of the reign of the judges over the people of Nephi, there began to be a serious difficulty among the people of the Nephites.

Helaman 1:2 For behold, Pahoran had died, and gone the way of all the earth; therefore there began to be a serious contention concerning who should have the judgment-seat among the brethren, who were the sons of Pahoran.

Helaman 1:3 Now these are their names who did contend for the judgment-seat, who did also cause the people to contend: Pahoran, Paanchi, and Pacumeni.

Helaman 1:4 Now these are not all the sons of Pahoran (for he had many), but these are they who did contend for the judgment-seat; therefore, they did cause three divisions among the people.

Helaman 1:5 Nevertheless, it came to pass that Pahoran was appointed by the voice of the people to be chief judge and a governor over the people of Nephi.

Helaman 1:6 And it came to pass that Pacumeni, when he saw that he could not obtain the judgment-seat, he did unite with the voice of the people.

Helaman 1:7 But behold, Paanchi, and that part of the people that were desirous that he should be their governor, was exceedingly wroth; therefore, he was about to flatter away those people to rise up in rebellion against their brethren.

Helaman 1:8 And it came to pass as he was about to do this, behold, he was taken, and was tried according to the voice of the people, and condemned unto death; for he had raised up in rebellion and sought to destroy the liberty of the people.

Helaman 1:9 Now when those people who were desirous that he should be their governor saw that he was condemned unto death, therefore they were angry, and behold, they sent forth one Kishkumen, even to the judgment-seat of Pahoran, and murdered Pahoran as he sat upon the judgment-seat.

Helaman 1:10 And he was pursued by the servants of Pahoran; but behold, so speedy was the flight of Kishkumen that no man could overtake him.

Helaman 1:11 And he went unto those that sent him, and they all entered into a covenant, yea, swearing by their everlasting Maker, that they would tell no man that Kishkumen had murdered Pahoran.

Helaman 1:12 Therefore, Kishkumen was not known among the people of Nephi, for he was in disguise at the time that he murdered Pahoran. And Kishkumen and his band, who had covenanted with him, did mingle themselves among the people, in a manner that they all could not be found; but as many as were found were condemned unto death.

Helaman 1:13 And now behold, Pacumeni was appointed, according to the voice of the people, to be a chief judge and a governor over the people, to reign in the stead of his brother Pahoran; and it was according to his right. And all this was done in the fortieth year of the reign of the judges; and it had an end.

Helaman 1:14 And it came to pass in the forty and first year of the reign of the judges, that the Lamanites had gathered together an innumerable army of men, and armed them with swords, and with cimeters and with bows, and with arrows, and with head-plates, and with breastplates, and with all manner of shields of every kind.

Helaman 1:15 And they came down again that they might pitch battle against the Nephites. And they were led by a man whose name was Coriantumr; and he was a descendant of Zarahemla; and he was a dissenter from among the Nephites; and he was a large and a mighty man.

Helaman 1:16 Therefore, the king of the Lamanites, whose name was Tubaloth, who was the son of Ammoron, supposing that Coriantumr, being a mighty man, could stand against the Nephites, with his strength and also with his great wisdom, insomuch that by sending him forth he should gain power over the Nephites—

Helaman 1:17 Therefore he did stir them up to anger, and he did gather together his armies, and he did appoint Coriantumr to be their leader, and did cause that they should march down to the land of Zarahemla to battle against the Nephites.

Helaman 1:18 And it came to pass that because of so much contention and so much difficulty in the government, that they had not kept sufficient guards in the land of Zarahemla; for they had supposed that the Lamanites durst not come into the heart of their lands to attack that great city Zarahemla.

Helaman 1:19 But it came to pass that Coriantumr did march forth at the head of his numerous host, and came upon the inhabitants of the city, and their march was with such exceedingly great speed that there was no time for the Nephites to gather together their armies.

Helaman 1:20 Therefore Coriantumr did cut down the watch by the entrance of the city, and did march forth with his whole army into the city, and they did slay every one who did oppose them, insomuch that they did take possession of the whole city.

Helaman 1:21 And it came to pass that Pacumeni, who was the chief judge, did flee before Coriantumr, even to the walls of the city. And it came to pass that Coriantumr did smite him against the wall, insomuch that he died. And thus ended the days of Pacumeni.

Helaman 1:22 And now when Coriantumr saw that he was in possession of the city of Zarahemla, and saw that the Nephites had fled before them, and were slain, and were taken, and were cast into prison, and that he had obtained the possession of the strongest hold in all the land, his heart took courage insomuch that he was about to go forth against all the land.

Helaman 1:23 And now he did not tarry in the land of Zarahemla, but he did march forth with a large army, even towards the city of Bountiful; for it was his determination to go forth and cut his way through with the sword, that he might obtain the north parts of the land.

Helaman 1:24 And, supposing that their greatest strength was in the center of the land, therefore he did march forth, giving them no time to assemble themselves together save it were in small bodies; and in this manner they did fall upon them and cut them down to the earth.

Helaman 1:25 But behold, this march of Coriantumr through the center of the land gave Moronihah great advantage over them, notwithstanding the greatness of the number of the Nephites who were slain.

Helaman 1:26 For behold, Moronihah had supposed that the Lamanites durst not come into the center of the land, but that they would attack the cities round about in the borders as they had hitherto done; therefore Moronihah had caused that their strong armies should maintain those parts round about by the borders.

Helaman 1:27 But behold, the Lamanites were not frightened according to his desire, but they had come into the center of the land, and had taken the capital city which was the city of Zarahemla, and were marching through the most capital parts of the land, slaying the people with a great slaughter, both men, women, and children, taking possession of many cities and of many strongholds.

Helaman 1:28 But when Moronihah had discovered this, he immediately sent forth Lehi with an army round about to head them before they should come to the land Bountiful.

Helaman 1:29 And thus he did; and he did head them before they came to the land Bountiful, and gave unto them battle, insomuch that they began to retreat back towards the land of Zarahemla.

Helaman 1:30 And it came to pass that Moronihah did head them in their retreat, and did give unto them battle, insomuch that it became an exceedingly bloody battle; yea, many were slain, and among the number who were slain Coriantumr was also found.

Helaman 1:31 And now, behold, the Lamanites could not retreat either way, neither on the north, nor on the south, nor on the east, nor on the west, for they were surrounded on every hand by the Nephites.

Helaman 1:32 And thus had Coriantumr plunged the Lamanites into the midst of the Nephites, insomuch that they were in the power of the Nephites, and he himself was slain, and the Lamanites did yield themselves into the hands of the Nephites.

Helaman 1:33 And it came to pass that Moronihah took possession of the city of Zarahemla again, and caused that the Lamanites who had been taken prisoners should depart out of the land in peace.

Helaman 1:34 And thus ended the forty and first year of the reign of the judges.
