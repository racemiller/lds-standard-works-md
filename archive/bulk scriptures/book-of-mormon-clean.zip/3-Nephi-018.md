# 3 Nephi 18

3 Nephi 18 (summary): Jesus institutes the sacrament among the Nephites—They are commanded to pray always in His name—Those who eat His flesh and drink His blood unworthily are damned—The disciples are given power to confer the Holy Ghost. About A.D. 34.

3 Nephi 18:1 And it came to pass that Jesus commanded his disciples that they should bring forth some bread and wine unto him.

3 Nephi 18:2 And while they were gone for bread and wine, he commanded the multitude that they should sit themselves down upon the earth.

3 Nephi 18:3 And when the disciples had come with bread and wine, he took of the bread and brake and blessed it; and he gave unto the disciples and commanded that they should eat.

3 Nephi 18:4 And when they had eaten and were filled, he commanded that they should give unto the multitude.

3 Nephi 18:5 And when the multitude had eaten and were filled, he said unto the disciples: Behold there shall one be ordained among you, and to him will I give power that he shall break bread and bless it and give it unto the people of my church, unto all those who shall believe and be baptized in my name.

3 Nephi 18:6 And this shall ye always observe to do, even as I have done, even as I have broken bread and blessed it and given it unto you.

3 Nephi 18:7 And this shall ye do in remembrance of my body, which I have shown unto you. And it shall be a testimony unto the Father that ye do always remember me. And if ye do always remember me ye shall have my Spirit to be with you.

3 Nephi 18:8 And it came to pass that when he said these words, he commanded his disciples that they should take of the wine of the cup and drink of it, and that they should also give unto the multitude that they might drink of it.

3 Nephi 18:9 And it came to pass that they did so, and did drink of it and were filled; and they gave unto the multitude, and they did drink, and they were filled.

3 Nephi 18:10 And when the disciples had done this, Jesus said unto them: Blessed are ye for this thing which ye have done, for this is fulfilling my commandments, and this doth witness unto the Father that ye are willing to do that which I have commanded you.

3 Nephi 18:11 And this shall ye always do to those who repent and are baptized in my name; and ye shall do it in remembrance of my blood, which I have shed for you, that ye may witness unto the Father that ye do always remember me. And if ye do always remember me ye shall have my Spirit to be with you.

3 Nephi 18:12 And I give unto you a commandment that ye shall do these things. And if ye shall always do these things blessed are ye, for ye are built upon my rock.

3 Nephi 18:13 But whoso among you shall do more or less than these are not built upon my rock, but are built upon a sandy foundation; and when the rain descends, and the floods come, and the winds blow, and beat upon them, they shall fall, and the gates of hell are ready open to receive them.

3 Nephi 18:14 Therefore blessed are ye if ye shall keep my commandments, which the Father hath commanded me that I should give unto you.

3 Nephi 18:15 Verily, verily, I say unto you, ye must watch and pray always, lest ye be tempted by the devil, and ye be led away captive by him.

3 Nephi 18:16 And as I have prayed among you even so shall ye pray in my church, among my people who do repent and are baptized in my name. Behold I am the light; I have set an example for you.

3 Nephi 18:17 And it came to pass that when Jesus had spoken these words unto his disciples, he turned again unto the multitude and said unto them:

3 Nephi 18:18 Behold, verily, verily, I say unto you, ye must watch and pray always lest ye enter into temptation; for Satan desireth to have you, that he may sift you as wheat.

3 Nephi 18:19 Therefore ye must always pray unto the Father in my name;

3 Nephi 18:20 And whatsoever ye shall ask the Father in my name, which is right, believing that ye shall receive, behold it shall be given unto you.

3 Nephi 18:21 Pray in your families unto the Father, always in my name, that your wives and your children may be blessed.

3 Nephi 18:22 And behold, ye shall meet together oft; and ye shall not forbid any man from coming unto you when ye shall meet together, but suffer them that they may come unto you and forbid them not;

3 Nephi 18:23 But ye shall pray for them, and shall not cast them out; and if it so be that they come unto you oft ye shall pray for them unto the Father, in my name.

3 Nephi 18:24 Therefore, hold up your light that it may shine unto the world. Behold I am the light which ye shall hold up—that which ye have seen me do. Behold ye see that I have prayed unto the Father, and ye all have witnessed.

3 Nephi 18:25 And ye see that I have commanded that none of you should go away, but rather have commanded that ye should come unto me, that ye might feel and see; even so shall ye do unto the world; and whosoever breaketh this commandment suffereth himself to be led into temptation.

3 Nephi 18:26 And now it came to pass that when Jesus had spoken these words, he turned his eyes again upon the disciples whom he had chosen, and said unto them:

3 Nephi 18:27 Behold verily, verily, I say unto you, I give unto you another commandment, and then I must go unto my Father that I may fulfil other commandments which he hath given me.

3 Nephi 18:28 And now behold, this is the commandment which I give unto you, that ye shall not suffer any one knowingly to partake of my flesh and blood unworthily, when ye shall minister it;

3 Nephi 18:29 For whoso eateth and drinketh my flesh and blood unworthily eateth and drinketh damnation to his soul; therefore if ye know that a man is unworthy to eat and drink of my flesh and blood ye shall forbid him.

3 Nephi 18:30 Nevertheless, ye shall not cast him out from among you, but ye shall minister unto him and shall pray for him unto the Father, in my name; and if it so be that he repenteth and is baptized in my name, then shall ye receive him, and shall minister unto him of my flesh and blood.

3 Nephi 18:31 But if he repent not he shall not be numbered among my people, that he may not destroy my people, for behold I know my sheep, and they are numbered.

3 Nephi 18:32 Nevertheless, ye shall not cast him out of your synagogues, or your places of worship, for unto such shall ye continue to minister; for ye know not but what they will return and repent, and come unto me with full purpose of heart, and I shall heal them; and ye shall be the means of bringing salvation unto them.

3 Nephi 18:33 Therefore, keep these sayings which I have commanded you that ye come not under condemnation; for wo unto him whom the Father condemneth.

3 Nephi 18:34 And I give you these commandments because of the disputations which have been among you. And blessed are ye if ye have no disputations among you.

3 Nephi 18:35 And now I go unto the Father, because it is expedient that I should go unto the Father for your sakes.

3 Nephi 18:36 And it came to pass that when Jesus had made an end of these sayings, he touched with his hand the disciples whom he had chosen, one by one, even until he had touched them all, and spake unto them as he touched them.

3 Nephi 18:37 And the multitude heard not the words which he spake, therefore they did not bear record; but the disciples bare record that he gave them power to give the Holy Ghost. And I will show unto you hereafter that this record is true.

3 Nephi 18:38 And it came to pass that when Jesus had touched them all, there came a cloud and overshadowed the multitude that they could not see Jesus.

3 Nephi 18:39 And while they were overshadowed he departed from them, and ascended into heaven. And the disciples saw and did bear record that he ascended again into heaven.
