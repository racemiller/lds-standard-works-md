# Alma 7

Alma 7 (summary): Christ will be born of Mary—He will loose the bands of death and bear the sins of His people—Those who repent, are baptized, and keep the commandments will have eternal life—Filthiness cannot inherit the kingdom of God—Humility, faith, hope, and charity are required. About 83 B.C.

Alma 7:1 Behold my beloved brethren, seeing that I have been permitted to come unto you, therefore I attempt to address you in my language; yea, by my own mouth, seeing that it is the first time that I have spoken unto you by the words of my mouth, I having been wholly confined to the judgment-seat, having had much business that I could not come unto you.

Alma 7:2 And even I could not have come now at this time were it not that the judgment-seat hath been given to another, to reign in my stead; and the Lord in much mercy hath granted that I should come unto you.

Alma 7:3 And behold, I have come having great hopes and much desire that I should find that ye had humbled yourselves before God, and that ye had continued in the supplicating of his grace, that I should find that ye were blameless before him, that I should find that ye were not in the awful dilemma that our brethren were in at Zarahemla.

Alma 7:4 But blessed be the name of God, that he hath given me to know, yea, hath given unto me the exceedingly great joy of knowing that they are established again in the way of his righteousness.

Alma 7:5 And I trust, according to the Spirit of God which is in me, that I shall also have joy over you; nevertheless I do not desire that my joy over you should come by the cause of so much afflictions and sorrow which I have had for the brethren at Zarahemla, for behold, my joy cometh over them after wading through much affliction and sorrow.

Alma 7:6 But behold, I trust that ye are not in a state of so much unbelief as were your brethren; I trust that ye are not lifted up in the pride of your hearts; yea, I trust that ye have not set your hearts upon riches and the vain things of the world; yea, I trust that you do not worship idols, but that ye do worship the true and the living God, and that ye look forward for the remission of your sins, with an everlasting faith, which is to come.

Alma 7:7 For behold, I say unto you there be many things to come; and behold, there is one thing which is of more importance than they all—for behold, the time is not far distant that the Redeemer liveth and cometh among his people.

Alma 7:8 Behold, I do not say that he will come among us at the time of his dwelling in his mortal tabernacle; for behold, the Spirit hath not said unto me that this should be the case. Now as to this thing I do not know; but this much I do know, that the Lord God hath power to do all things which are according to his word.

Alma 7:9 But behold, the Spirit hath said this much unto me, saying: Cry unto this people, saying—Repent ye, and prepare the way of the Lord, and walk in his paths, which are straight; for behold, the kingdom of heaven is at hand, and the Son of God cometh upon the face of the earth.

Alma 7:10 And behold, he shall be born of Mary, at Jerusalem which is the land of our forefathers, she being a virgin, a precious and chosen vessel, who shall be overshadowed and conceive by the power of the Holy Ghost, and bring forth a son, yea, even the Son of God.

Alma 7:11 And he shall go forth, suffering pains and afflictions and temptations of every kind; and this that the word might be fulfilled which saith he will take upon him the pains and the sicknesses of his people.

Alma 7:12 And he will take upon him death, that he may loose the bands of death which bind his people; and he will take upon him their infirmities, that his bowels may be filled with mercy, according to the flesh, that he may know according to the flesh how to succor his people according to their infirmities.

Alma 7:13 Now the Spirit knoweth all things; nevertheless the Son of God suffereth according to the flesh that he might take upon him the sins of his people, that he might blot out their transgressions according to the power of his deliverance; and now behold, this is the testimony which is in me.

Alma 7:14 Now I say unto you that ye must repent, and be born again; for the Spirit saith if ye are not born again ye cannot inherit the kingdom of heaven; therefore come and be baptized unto repentance, that ye may be washed from your sins, that ye may have faith on the Lamb of God, who taketh away the sins of the world, who is mighty to save and to cleanse from all unrighteousness.

Alma 7:15 Yea, I say unto you come and fear not, and lay aside every sin, which easily doth beset you, which doth bind you down to destruction, yea, come and go forth, and show unto your God that ye are willing to repent of your sins and enter into a covenant with him to keep his commandments, and witness it unto him this day by going into the waters of baptism.

Alma 7:16 And whosoever doeth this, and keepeth the commandments of God from thenceforth, the same will remember that I say unto him, yea, he will remember that I have said unto him, he shall have eternal life, according to the testimony of the Holy Spirit, which testifieth in me.

Alma 7:17 And now my beloved brethren, do you believe these things? Behold, I say unto you, yea, I know that ye believe them; and the way that I know that ye believe them is by the manifestation of the Spirit which is in me. And now because your faith is strong concerning that, yea, concerning the things which I have spoken, great is my joy.

Alma 7:18 For as I said unto you from the beginning, that I had much desire that ye were not in the state of dilemma like your brethren, even so I have found that my desires have been gratified.

Alma 7:19 For I perceive that ye are in the paths of righteousness; I perceive that ye are in the path which leads to the kingdom of God; yea, I perceive that ye are making his paths straight.

Alma 7:20 I perceive that it has been made known unto you, by the testimony of his word, that he cannot walk in crooked paths; neither doth he vary from that which he hath said; neither hath he a shadow of turning from the right to the left, or from that which is right to that which is wrong; therefore, his course is one eternal round.

Alma 7:21 And he doth not dwell in unholy temples; neither can filthiness or anything which is unclean be received into the kingdom of God; therefore I say unto you the time shall come, yea, and it shall be at the last day, that he who is filthy shall remain in his filthiness.

Alma 7:22 And now my beloved brethren, I have said these things unto you that I might awaken you to a sense of your duty to God, that ye may walk blameless before him, that ye may walk after the holy order of God, after which ye have been received.

Alma 7:23 And now I would that ye should be humble, and be submissive and gentle; easy to be entreated; full of patience and long-suffering; being temperate in all things; being diligent in keeping the commandments of God at all times; asking for whatsoever things ye stand in need, both spiritual and temporal; always returning thanks unto God for whatsoever things ye do receive.

Alma 7:24 And see that ye have faith, hope, and charity, and then ye will always abound in good works.

Alma 7:25 And may the Lord bless you, and keep your garments spotless, that ye may at last be brought to sit down with Abraham, Isaac, and Jacob, and the holy prophets who have been ever since the world began, having your garments spotless even as their garments are spotless, in the kingdom of heaven to go no more out.

Alma 7:26 And now my beloved brethren, I have spoken these words unto you according to the Spirit which testifieth in me; and my soul doth exceedingly rejoice, because of the exceeding diligence and heed which ye have given unto my word.

Alma 7:27 And now, may the peace of God rest upon you, and upon your houses and lands, and upon your flocks and herds, and all that you possess, your women and your children, according to your faith and good works, from this time forth and forever. And thus I have spoken. Amen.
