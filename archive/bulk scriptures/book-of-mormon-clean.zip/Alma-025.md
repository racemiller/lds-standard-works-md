# Alma 25

Alma 25 (summary): Lamanite aggressions spread—The seed of the priests of Noah perish as Abinadi prophesied—Many Lamanites are converted and join the people of Anti-Nephi-Lehi—They believe in Christ and keep the law of Moses. About 90–77 B.C.

Alma 25:1 And behold, now it came to pass that those Lamanites were more angry because they had slain their brethren; therefore they swore vengeance upon the Nephites; and they did no more attempt to slay the people of Anti-Nephi-Lehi at that time.

Alma 25:2 But they took their armies and went over into the borders of the land of Zarahemla, and fell upon the people who were in the land of Ammonihah and destroyed them.

Alma 25:3 And after that, they had many battles with the Nephites, in the which they were driven and slain.

Alma 25:4 And among the Lamanites who were slain were almost all the seed of Amulon and his brethren, who were the priests of Noah, and they were slain by the hands of the Nephites;

Alma 25:5 And the remainder, having fled into the east wilderness, and having usurped the power and authority over the Lamanites, caused that many of the Lamanites should perish by fire because of their belief—

Alma 25:6 For many of them, after having suffered much loss and so many afflictions, began to be stirred up in remembrance of the words which Aaron and his brethren had preached to them in their land; therefore they began to disbelieve the traditions of their fathers, and to believe in the Lord, and that he gave great power unto the Nephites; and thus there were many of them converted in the wilderness.

Alma 25:7 And it came to pass that those rulers who were the remnant of the children of Amulon caused that they should be put to death, yea, all those that believed in these things.

Alma 25:8 Now this martyrdom caused that many of their brethren should be stirred up to anger; and there began to be contention in the wilderness; and the Lamanites began to hunt the seed of Amulon and his brethren and began to slay them; and they fled into the east wilderness.

Alma 25:9 And behold they are hunted at this day by the Lamanites. Thus the words of Abinadi were brought to pass, which he said concerning the seed of the priests who caused that he should suffer death by fire.

Alma 25:10 For he said unto them: What ye shall do unto me shall be a type of things to come.

Alma 25:11 And now Abinadi was the first that suffered death by fire because of his belief in God; now this is what he meant, that many should suffer death by fire, according as he had suffered.

Alma 25:12 And he said unto the priests of Noah that their seed should cause many to be put to death, in the like manner as he was, and that they should be scattered abroad and slain, even as a sheep having no shepherd is driven and slain by wild beasts; and now behold, these words were verified, for they were driven by the Lamanites, and they were hunted, and they were smitten.

Alma 25:13 And it came to pass that when the Lamanites saw that they could not overpower the Nephites they returned again to their own land; and many of them came over to dwell in the land of Ishmael and the land of Nephi, and did join themselves to the people of God, who were the people of Anti-Nephi-Lehi.

Alma 25:14 And they did also bury their weapons of war, according as their brethren had, and they began to be a righteous people; and they did walk in the ways of the Lord, and did observe to keep his commandments and his statutes.

Alma 25:15 Yea, and they did keep the law of Moses; for it was expedient that they should keep the law of Moses as yet, for it was not all fulfilled. But notwithstanding the law of Moses, they did look forward to the coming of Christ, considering that the law of Moses was a type of his coming, and believing that they must keep those outward performances until the time that he should be revealed unto them.

Alma 25:16 Now they did not suppose that salvation came by the law of Moses; but the law of Moses did serve to strengthen their faith in Christ; and thus they did retain a hope through faith, unto eternal salvation, relying upon the spirit of prophecy, which spake of those things to come.

Alma 25:17 And now behold, Ammon, and Aaron, and Omner, and Himni, and their brethren did rejoice exceedingly, for the success which they had had among the Lamanites, seeing that the Lord had granted unto them according to their prayers, and that he had also verified his word unto them in every particular.
