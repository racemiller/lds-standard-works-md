# 3 Nephi 4

3 Nephi 4 (summary): The Nephite armies defeat the Gadianton robbers—Giddianhi is slain, and his successor, Zemnarihah, is hanged—The Nephites praise the Lord for their victories. About A.D. 19–22.

3 Nephi 4:1 And it came to pass that in the latter end of the eighteenth year those armies of robbers had prepared for battle, and began to come down and to sally forth from the hills, and out of the mountains, and the wilderness, and their strongholds, and their secret places, and began to take possession of the lands, both which were in the land south and which were in the land north, and began to take possession of all the lands which had been deserted by the Nephites, and the cities which had been left desolate.

3 Nephi 4:2 But behold, there were no wild beasts nor game in those lands which had been deserted by the Nephites, and there was no game for the robbers save it were in the wilderness.

3 Nephi 4:3 And the robbers could not exist save it were in the wilderness, for the want of food; for the Nephites had left their lands desolate, and had gathered their flocks and their herds and all their substance, and they were in one body.

3 Nephi 4:4 Therefore, there was no chance for the robbers to plunder and to obtain food, save it were to come up in open battle against the Nephites; and the Nephites being in one body, and having so great a number, and having reserved for themselves provisions, and horses and cattle, and flocks of every kind, that they might subsist for the space of seven years, in the which time they did hope to destroy the robbers from off the face of the land; and thus the eighteenth year did pass away.

3 Nephi 4:5 And it came to pass that in the nineteenth year Giddianhi found that it was expedient that he should go up to battle against the Nephites, for there was no way that they could subsist save it were to plunder and rob and murder.

3 Nephi 4:6 And they durst not spread themselves upon the face of the land insomuch that they could raise grain, lest the Nephites should come upon them and slay them; therefore Giddianhi gave commandment unto his armies that in this year they should go up to battle against the Nephites.

3 Nephi 4:7 And it came to pass that they did come up to battle; and it was in the sixth month; and behold, great and terrible was the day that they did come up to battle; and they were girded about after the manner of robbers; and they had a lamb-skin about their loins, and they were dyed in blood, and their heads were shorn, and they had head-plates upon them; and great and terrible was the appearance of the armies of Giddianhi, because of their armor, and because of their being dyed in blood.

3 Nephi 4:8 And it came to pass that the armies of the Nephites, when they saw the appearance of the army of Giddianhi, had all fallen to the earth, and did lift their cries to the Lord their God, that he would spare them and deliver them out of the hands of their enemies.

3 Nephi 4:9 And it came to pass that when the armies of Giddianhi saw this they began to shout with a loud voice, because of their joy, for they had supposed that the Nephites had fallen with fear because of the terror of their armies.

3 Nephi 4:10 But in this thing they were disappointed, for the Nephites did not fear them; but they did fear their God and did supplicate him for protection; therefore, when the armies of Giddianhi did rush upon them they were prepared to meet them; yea, in the strength of the Lord they did receive them.

3 Nephi 4:11 And the battle commenced in this the sixth month; and great and terrible was the battle thereof, yea, great and terrible was the slaughter thereof, insomuch that there never was known so great a slaughter among all the people of Lehi since he left Jerusalem.

3 Nephi 4:12 And notwithstanding the threatenings and the oaths which Giddianhi had made, behold, the Nephites did beat them, insomuch that they did fall back from before them.

3 Nephi 4:13 And it came to pass that Gidgiddoni commanded that his armies should pursue them as far as the borders of the wilderness, and that they should not spare any that should fall into their hands by the way; and thus they did pursue them and did slay them, to the borders of the wilderness, even until they had fulfilled the commandment of Gidgiddoni.

3 Nephi 4:14 And it came to pass that Giddianhi, who had stood and fought with boldness, was pursued as he fled; and being weary because of his much fighting he was overtaken and slain. And thus was the end of Giddianhi the robber.

3 Nephi 4:15 And it came to pass that the armies of the Nephites did return again to their place of security. And it came to pass that this nineteenth year did pass away, and the robbers did not come again to battle; neither did they come again in the twentieth year.

3 Nephi 4:16 And in the twenty and first year they did not come up to battle, but they came up on all sides to lay siege round about the people of Nephi; for they did suppose that if they should cut off the people of Nephi from their lands, and should hem them in on every side, and if they should cut them off from all their outward privileges, that they could cause them to yield themselves up according to their wishes.

3 Nephi 4:17 Now they had appointed unto themselves another leader, whose name was Zemnarihah; therefore it was Zemnarihah that did cause that this siege should take place.

3 Nephi 4:18 But behold, this was an advantage to the Nephites; for it was impossible for the robbers to lay siege sufficiently long to have any effect upon the Nephites, because of their much provision which they had laid up in store,

3 Nephi 4:19 And because of the scantiness of provisions among the robbers; for behold, they had nothing save it were meat for their subsistence, which meat they did obtain in the wilderness;

3 Nephi 4:20 And it came to pass that the wild game became scarce in the wilderness insomuch that the robbers were about to perish with hunger.

3 Nephi 4:21 And the Nephites were continually marching out by day and by night, and falling upon their armies, and cutting them off by thousands and by tens of thousands.

3 Nephi 4:22 And thus it became the desire of the people of Zemnarihah to withdraw from their design, because of the great destruction which came upon them by night and by day.

3 Nephi 4:23 And it came to pass that Zemnarihah did give command unto his people that they should withdraw themselves from the siege, and march into the furthermost parts of the land northward.

3 Nephi 4:24 And now, Gidgiddoni being aware of their design, and knowing of their weakness because of the want of food, and the great slaughter which had been made among them, therefore he did send out his armies in the night-time, and did cut off the way of their retreat, and did place his armies in the way of their retreat.

3 Nephi 4:25 And this did they do in the night-time, and got on their march beyond the robbers, so that on the morrow, when the robbers began their march, they were met by the armies of the Nephites both in their front and in their rear.

3 Nephi 4:26 And the robbers who were on the south were also cut off in their places of retreat. And all these things were done by command of Gidgiddoni.

3 Nephi 4:27 And there were many thousands who did yield themselves up prisoners unto the Nephites, and the remainder of them were slain.

3 Nephi 4:28 And their leader, Zemnarihah, was taken and hanged upon a tree, yea, even upon the top thereof until he was dead. And when they had hanged him until he was dead they did fell the tree to the earth, and did cry with a loud voice, saying:

3 Nephi 4:29 May the Lord preserve his people in righteousness and in holiness of heart, that they may cause to be felled to the earth all who shall seek to slay them because of power and secret combinations, even as this man hath been felled to the earth.

3 Nephi 4:30 And they did rejoice and cry again with one voice, saying: May the God of Abraham, and the God of Isaac, and the God of Jacob, protect this people in righteousness, so long as they shall call on the name of their God for protection.

3 Nephi 4:31 And it came to pass that they did break forth, all as one, in singing, and praising their God for the great thing which he had done for them, in preserving them from falling into the hands of their enemies.

3 Nephi 4:32 Yea, they did cry: Hosanna to the Most High God. And they did cry: Blessed be the name of the Lord God Almighty, the Most High God.

3 Nephi 4:33 And their hearts were swollen with joy, unto the gushing out of many tears, because of the great goodness of God in delivering them out of the hands of their enemies; and they knew it was because of their repentance and their humility that they had been delivered from an everlasting destruction.
