# Alma 8

Alma 8 (summary): Alma preaches and baptizes in Melek—He is rejected in Ammonihah and leaves—An angel commands him to return and cry repentance unto the people—He is received by Amulek, and the two of them preach in Ammonihah. About 82 B.C.

Alma 8:1 And now it came to pass that Alma returned from the land of Gideon, after having taught the people of Gideon many things which cannot be written, having established the order of the church, according as he had before done in the land of Zarahemla, yea, he returned to his own house at Zarahemla to rest himself from the labors which he had performed.

Alma 8:2 And thus ended the ninth year of the reign of the judges over the people of Nephi.

Alma 8:3 And it came to pass in the commencement of the tenth year of the reign of the judges over the people of Nephi, that Alma departed from thence and took his journey over into the land of Melek, on the west of the river Sidon, on the west by the borders of the wilderness.

Alma 8:4 And he began to teach the people in the land of Melek according to the holy order of God, by which he had been called; and he began to teach the people throughout all the land of Melek.

Alma 8:5 And it came to pass that the people came to him throughout all the borders of the land which was by the wilderness side. And they were baptized throughout all the land;

Alma 8:6 So that when he had finished his work at Melek he departed thence, and traveled three days’ journey on the north of the land of Melek; and he came to a city which was called Ammonihah.

Alma 8:7 Now it was the custom of the people of Nephi to call their lands, and their cities, and their villages, yea, even all their small villages, after the name of him who first possessed them; and thus it was with the land of Ammonihah.

Alma 8:8 And it came to pass that when Alma had come to the city of Ammonihah he began to preach the word of God unto them.

Alma 8:9 Now Satan had gotten great hold upon the hearts of the people of the city of Ammonihah; therefore they would not hearken unto the words of Alma.

Alma 8:10 Nevertheless Alma labored much in the spirit, wrestling with God in mighty prayer, that he would pour out his Spirit upon the people who were in the city; that he would also grant that he might baptize them unto repentance.

Alma 8:11 Nevertheless, they hardened their hearts, saying unto him: Behold, we know that thou art Alma; and we know that thou art high priest over the church which thou hast established in many parts of the land, according to your tradition; and we are not of thy church, and we do not believe in such foolish traditions.

Alma 8:12 And now we know that because we are not of thy church we know that thou hast no power over us; and thou hast delivered up the judgment-seat unto Nephihah; therefore thou art not the chief judge over us.

Alma 8:13 Now when the people had said this, and withstood all his words, and reviled him, and spit upon him, and caused that he should be cast out of their city, he departed thence and took his journey towards the city which was called Aaron.

Alma 8:14 And it came to pass that while he was journeying thither, being weighed down with sorrow, wading through much tribulation and anguish of soul, because of the wickedness of the people who were in the city of Ammonihah, it came to pass while Alma was thus weighed down with sorrow, behold an angel of the Lord appeared unto him, saying:

Alma 8:15 Blessed art thou, Alma; therefore, lift up thy head and rejoice, for thou hast great cause to rejoice; for thou hast been faithful in keeping the commandments of God from the time which thou receivedst thy first message from him. Behold, I am he that delivered it unto you.

Alma 8:16 And behold, I am sent to command thee that thou return to the city of Ammonihah, and preach again unto the people of the city; yea, preach unto them. Yea, say unto them, except they repent the Lord God will destroy them.

Alma 8:17 For behold, they do study at this time that they may destroy the liberty of thy people, (for thus saith the Lord) which is contrary to the statutes, and judgments, and commandments which he has given unto his people.

Alma 8:18 Now it came to pass that after Alma had received his message from the angel of the Lord he returned speedily to the land of Ammonihah. And he entered the city by another way, yea, by the way which is on the south of the city of Ammonihah.

Alma 8:19 And as he entered the city he was an hungered, and he said to a man: Will ye give to an humble servant of God something to eat?

Alma 8:20 And the man said unto him: I am a Nephite, and I know that thou art a holy prophet of God, for thou art the man whom an angel said in a vision: Thou shalt receive. Therefore, go with me into my house and I will impart unto thee of my food; and I know that thou wilt be a blessing unto me and my house.

Alma 8:21 And it came to pass that the man received him into his house; and the man was called Amulek; and he brought forth bread and meat and set before Alma.

Alma 8:22 And it came to pass that Alma ate bread and was filled; and he blessed Amulek and his house, and he gave thanks unto God.

Alma 8:23 And after he had eaten and was filled he said unto Amulek: I am Alma, and am the high priest over the church of God throughout the land.

Alma 8:24 And behold, I have been called to preach the word of God among all this people, according to the spirit of revelation and prophecy; and I was in this land and they would not receive me, but they cast me out and I was about to set my back towards this land forever.

Alma 8:25 But behold, I have been commanded that I should turn again and prophesy unto this people, yea, and to testify against them concerning their iniquities.

Alma 8:26 And now, Amulek, because thou hast fed me and taken me in, thou art blessed; for I was an hungered, for I had fasted many days.

Alma 8:27 And Alma tarried many days with Amulek before he began to preach unto the people.

Alma 8:28 And it came to pass that the people did wax more gross in their iniquities.

Alma 8:29 And the word came to Alma, saying: Go; and also say unto my servant Amulek, go forth and prophesy unto this people, saying—Repent ye, for thus saith the Lord, except ye repent I will visit this people in mine anger; yea, and I will not turn my fierce anger away.

Alma 8:30 And Alma went forth, and also Amulek, among the people, to declare the words of God unto them; and they were filled with the Holy Ghost.

Alma 8:31 And they had power given unto them, insomuch that they could not be confined in dungeons; neither was it possible that any man could slay them; nevertheless they did not exercise their power until they were bound in bands and cast into prison. Now, this was done that the Lord might show forth his power in them.

Alma 8:32 And it came to pass that they went forth and began to preach and to prophesy unto the people, according to the spirit and power which the Lord had given them.
