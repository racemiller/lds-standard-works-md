# Jacob 6

Jacob 6 (summary): The Lord will recover Israel in the last days—The world will be burned with fire—Men must follow Christ to avoid the lake of fire and brimstone. About 544–421 B.C.

Jacob 6:1 And now, behold, my brethren, as I said unto you that I would prophesy, behold, this is my prophecy—that the things which this prophet Zenos spake, concerning the house of Israel, in the which he likened them unto a tame olive tree, must surely come to pass.

Jacob 6:2 And the day that he shall set his hand again the second time to recover his people, is the day, yea, even the last time, that the servants of the Lord shall go forth in his power, to nourish and prune his vineyard; and after that the end soon cometh.

Jacob 6:3 And how blessed are they who have labored diligently in his vineyard; and how cursed are they who shall be cast out into their own place! And the world shall be burned with fire.

Jacob 6:4 And how merciful is our God unto us, for he remembereth the house of Israel, both roots and branches; and he stretches forth his hands unto them all the day long; and they are a stiffnecked and a gainsaying people; but as many as will not harden their hearts shall be saved in the kingdom of God.

Jacob 6:5 Wherefore, my beloved brethren, I beseech of you in words of soberness that ye would repent, and come with full purpose of heart, and cleave unto God as he cleaveth unto you. And while his arm of mercy is extended towards you in the light of the day, harden not your hearts.

Jacob 6:6 Yea, today, if ye will hear his voice, harden not your hearts; for why will ye die?

Jacob 6:7 For behold, after ye have been nourished by the good word of God all the day long, will ye bring forth evil fruit, that ye must be hewn down and cast into the fire?

Jacob 6:8 Behold, will ye reject these words? Will ye reject the words of the prophets; and will ye reject all the words which have been spoken concerning Christ, after so many have spoken concerning him; and deny the good word of Christ, and the power of God, and the gift of the Holy Ghost, and quench the Holy Spirit, and make a mock of the great plan of redemption, which hath been laid for you?

Jacob 6:9 Know ye not that if ye will do these things, that the power of the redemption and the resurrection, which is in Christ, will bring you to stand with shame and awful guilt before the bar of God?

Jacob 6:10 And according to the power of justice, for justice cannot be denied, ye must go away into that lake of fire and brimstone, whose flames are unquenchable, and whose smoke ascendeth up forever and ever, which lake of fire and brimstone is endless torment.

Jacob 6:11 O then, my beloved brethren, repent ye, and enter in at the strait gate, and continue in the way which is narrow, until ye shall obtain eternal life.

Jacob 6:12 O be wise; what can I say more?

Jacob 6:13 Finally, I bid you farewell, until I shall meet you before the pleasing bar of God, which bar striketh the wicked with awful dread and fear. Amen.
