# Alma 36

Alma 36 (summary): Alma testifies to Helaman of his conversion after seeing an angel—He suffered the pains of a damned soul; he called upon the name of Jesus, and was then born of God—Sweet joy filled his soul—He saw concourses of angels praising God—Many converts have tasted and seen as he has tasted and seen. About 74 B.C.

Alma 36:1 My son, give ear to my words; for I swear unto you, that inasmuch as ye shall keep the commandments of God ye shall prosper in the land.

Alma 36:2 I would that ye should do as I have done, in remembering the captivity of our fathers; for they were in bondage, and none could deliver them except it was the God of Abraham, and the God of Isaac, and the God of Jacob; and he surely did deliver them in their afflictions.

Alma 36:3 And now, O my son Helaman, behold, thou art in thy youth, and therefore, I beseech of thee that thou wilt hear my words and learn of me; for I do know that whosoever shall put their trust in God shall be supported in their trials, and their troubles, and their afflictions, and shall be lifted up at the last day.

Alma 36:4 And I would not that ye think that I know of myself—not of the temporal but of the spiritual, not of the carnal mind but of God.

Alma 36:5 Now, behold, I say unto you, if I had not been born of God I should not have known these things; but God has, by the mouth of his holy angel, made these things known unto me, not of any worthiness of myself;

Alma 36:6 For I went about with the sons of Mosiah, seeking to destroy the church of God; but behold, God sent his holy angel to stop us by the way.

Alma 36:7 And behold, he spake unto us, as it were the voice of thunder, and the whole earth did tremble beneath our feet; and we all fell to the earth, for the fear of the Lord came upon us.

Alma 36:8 But behold, the voice said unto me: Arise. And I arose and stood up, and beheld the angel.

Alma 36:9 And he said unto me: If thou wilt of thyself be destroyed, seek no more to destroy the church of God.

Alma 36:10 And it came to pass that I fell to the earth; and it was for the space of three days and three nights that I could not open my mouth, neither had I the use of my limbs.

Alma 36:11 And the angel spake more things unto me, which were heard by my brethren, but I did not hear them; for when I heard the words—If thou wilt be destroyed of thyself, seek no more to destroy the church of God—I was struck with such great fear and amazement lest perhaps I should be destroyed, that I fell to the earth and I did hear no more.

Alma 36:12 But I was racked with eternal torment, for my soul was harrowed up to the greatest degree and racked with all my sins.

Alma 36:13 Yea, I did remember all my sins and iniquities, for which I was tormented with the pains of hell; yea, I saw that I had rebelled against my God, and that I had not kept his holy commandments.

Alma 36:14 Yea, and I had murdered many of his children, or rather led them away unto destruction; yea, and in fine so great had been my iniquities, that the very thought of coming into the presence of my God did rack my soul with inexpressible horror.

Alma 36:15 Oh, thought I, that I could be banished and become extinct both soul and body, that I might not be brought to stand in the presence of my God, to be judged of my deeds.

Alma 36:16 And now, for three days and for three nights was I racked, even with the pains of a damned soul.

Alma 36:17 And it came to pass that as I was thus racked with torment, while I was harrowed up by the memory of my many sins, behold, I remembered also to have heard my father prophesy unto the people concerning the coming of one Jesus Christ, a Son of God, to atone for the sins of the world.

Alma 36:18 Now, as my mind caught hold upon this thought, I cried within my heart: O Jesus, thou Son of God, have mercy on me, who am in the gall of bitterness, and am encircled about by the everlasting chains of death.

Alma 36:19 And now, behold, when I thought this, I could remember my pains no more; yea, I was harrowed up by the memory of my sins no more.

Alma 36:20 And oh, what joy, and what marvelous light I did behold; yea, my soul was filled with joy as exceeding as was my pain!

Alma 36:21 Yea, I say unto you, my son, that there could be nothing so exquisite and so bitter as were my pains. Yea, and again I say unto you, my son, that on the other hand, there can be nothing so exquisite and sweet as was my joy.

Alma 36:22 Yea, methought I saw, even as our father Lehi saw, God sitting upon his throne, surrounded with numberless concourses of angels, in the attitude of singing and praising their God; yea, and my soul did long to be there.

Alma 36:23 But behold, my limbs did receive their strength again, and I stood upon my feet, and did manifest unto the people that I had been born of God.

Alma 36:24 Yea, and from that time even until now, I have labored without ceasing, that I might bring souls unto repentance; that I might bring them to taste of the exceeding joy of which I did taste; that they might also be born of God, and be filled with the Holy Ghost.

Alma 36:25 Yea, and now behold, O my son, the Lord doth give me exceedingly great joy in the fruit of my labors;

Alma 36:26 For because of the word which he has imparted unto me, behold, many have been born of God, and have tasted as I have tasted, and have seen eye to eye as I have seen; therefore they do know of these things of which I have spoken, as I do know; and the knowledge which I have is of God.

Alma 36:27 And I have been supported under trials and troubles of every kind, yea, and in all manner of afflictions; yea, God has delivered me from prison, and from bonds, and from death; yea, and I do put my trust in him, and he will still deliver me.

Alma 36:28 And I know that he will raise me up at the last day, to dwell with him in glory; yea, and I will praise him forever, for he has brought our fathers out of Egypt, and he has swallowed up the Egyptians in the Red Sea; and he led them by his power into the promised land; yea, and he has delivered them out of bondage and captivity from time to time.

Alma 36:29 Yea, and he has also brought our fathers out of the land of Jerusalem; and he has also, by his everlasting power, delivered them out of bondage and captivity, from time to time even down to the present day; and I have always retained in remembrance their captivity; yea, and ye also ought to retain in remembrance, as I have done, their captivity.

Alma 36:30 But behold, my son, this is not all; for ye ought to know as I do know, that inasmuch as ye shall keep the commandments of God ye shall prosper in the land; and ye ought to know also, that inasmuch as ye will not keep the commandments of God ye shall be cut off from his presence. Now this is according to his word.
