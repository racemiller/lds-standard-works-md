# Mosiah 14

Mosiah 14 (summary): Isaiah speaks messianically—The Messiah’s humiliation and sufferings are set forth—He makes His soul an offering for sin and makes intercession for transgressors—Compare Isaiah 53. About 148 B.C.

Mosiah 14:1 Yea, even doth not Isaiah say: Who hath believed our report, and to whom is the arm of the Lord revealed?

Mosiah 14:2 For he shall grow up before him as a tender plant, and as a root out of dry ground; he hath no form nor comeliness; and when we shall see him there is no beauty that we should desire him.

Mosiah 14:3 He is despised and rejected of men; a man of sorrows, and acquainted with grief; and we hid as it were our faces from him; he was despised, and we esteemed him not.

Mosiah 14:4 Surely he has borne our griefs, and carried our sorrows; yet we did esteem him stricken, smitten of God, and afflicted.

Mosiah 14:5 But he was wounded for our transgressions, he was bruised for our iniquities; the chastisement of our peace was upon him; and with his stripes we are healed.

Mosiah 14:6 All we, like sheep, have gone astray; we have turned every one to his own way; and the Lord hath laid on him the iniquities of us all.

Mosiah 14:7 He was oppressed, and he was afflicted, yet he opened not his mouth; he is brought as a lamb to the slaughter, and as a sheep before her shearers is dumb so he opened not his mouth.

Mosiah 14:8 He was taken from prison and from judgment; and who shall declare his generation? For he was cut off out of the land of the living; for the transgressions of my people was he stricken.

Mosiah 14:9 And he made his grave with the wicked, and with the rich in his death; because he had done no evil, neither was any deceit in his mouth.

Mosiah 14:10 Yet it pleased the Lord to bruise him; he hath put him to grief; when thou shalt make his soul an offering for sin he shall see his seed, he shall prolong his days, and the pleasure of the Lord shall prosper in his hand.

Mosiah 14:11 He shall see the travail of his soul, and shall be satisfied; by his knowledge shall my righteous servant justify many; for he shall bear their iniquities.

Mosiah 14:12 Therefore will I divide him a portion with the great, and he shall divide the spoil with the strong; because he hath poured out his soul unto death; and he was numbered with the transgressors; and he bore the sins of many, and made intercession for the transgressors.
