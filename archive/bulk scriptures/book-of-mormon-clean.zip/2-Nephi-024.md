# 2 Nephi 24

2 Nephi 24 (summary): Israel will be gathered and will enjoy millennial rest—Lucifer was cast out of heaven for rebellion—Israel will triumph over Babylon (the world)—Compare Isaiah 14. About 559–545 B.C.

2 Nephi 24:1 For the Lord will have mercy on Jacob, and will yet choose Israel, and set them in their own land; and the strangers shall be joined with them, and they shall cleave to the house of Jacob.

2 Nephi 24:2 And the people shall take them and bring them to their place; yea, from far unto the ends of the earth; and they shall return to their lands of promise. And the house of Israel shall possess them, and the land of the Lord shall be for servants and handmaids; and they shall take them captives unto whom they were captives; and they shall rule over their oppressors.

2 Nephi 24:3 And it shall come to pass in that day that the Lord shall give thee rest, from thy sorrow, and from thy fear, and from the hard bondage wherein thou wast made to serve.

2 Nephi 24:4 And it shall come to pass in that day, that thou shalt take up this proverb against the king of Babylon, and say: How hath the oppressor ceased, the golden city ceased!

2 Nephi 24:5 The Lord hath broken the staff of the wicked, the scepters of the rulers.

2 Nephi 24:6 He who smote the people in wrath with a continual stroke, he that ruled the nations in anger, is persecuted, and none hindereth.

2 Nephi 24:7 The whole earth is at rest, and is quiet; they break forth into singing.

2 Nephi 24:8 Yea, the fir trees rejoice at thee, and also the cedars of Lebanon, saying: Since thou art laid down no feller is come up against us.

2 Nephi 24:9 Hell from beneath is moved for thee to meet thee at thy coming; it stirreth up the dead for thee, even all the chief ones of the earth; it hath raised up from their thrones all the kings of the nations.

2 Nephi 24:10 All they shall speak and say unto thee: Art thou also become weak as we? Art thou become like unto us?

2 Nephi 24:11 Thy pomp is brought down to the grave; the noise of thy viols is not heard; the worm is spread under thee, and the worms cover thee.

2 Nephi 24:12 How art thou fallen from heaven, O Lucifer, son of the morning! Art thou cut down to the ground, which did weaken the nations!

2 Nephi 24:13 For thou hast said in thy heart: I will ascend into heaven, I will exalt my throne above the stars of God; I will sit also upon the mount of the congregation, in the sides of the north;

2 Nephi 24:14 I will ascend above the heights of the clouds; I will be like the Most High.

2 Nephi 24:15 Yet thou shalt be brought down to hell, to the sides of the pit.

2 Nephi 24:16 They that see thee shall narrowly look upon thee, and shall consider thee, and shall say: Is this the man that made the earth to tremble, that did shake kingdoms?

2 Nephi 24:17 And made the world as a wilderness, and destroyed the cities thereof, and opened not the house of his prisoners?

2 Nephi 24:18 All the kings of the nations, yea, all of them, lie in glory, every one of them in his own house.

2 Nephi 24:19 But thou art cast out of thy grave like an abominable branch, and the remnant of those that are slain, thrust through with a sword, that go down to the stones of the pit; as a carcass trodden under feet.

2 Nephi 24:20 Thou shalt not be joined with them in burial, because thou hast destroyed thy land and slain thy people; the seed of evil-doers shall never be renowned.

2 Nephi 24:21 Prepare slaughter for his children for the iniquities of their fathers, that they do not rise, nor possess the land, nor fill the face of the world with cities.

2 Nephi 24:22 For I will rise up against them, saith the Lord of Hosts, and cut off from Babylon the name, and remnant, and son, and nephew, saith the Lord.

2 Nephi 24:23 I will also make it a possession for the bittern, and pools of water; and I will sweep it with the besom of destruction, saith the Lord of Hosts.

2 Nephi 24:24 The Lord of Hosts hath sworn, saying: Surely as I have thought, so shall it come to pass; and as I have purposed, so shall it stand—

2 Nephi 24:25 That I will bring the Assyrian in my land, and upon my mountains tread him under foot; then shall his yoke depart from off them, and his burden depart from off their shoulders.

2 Nephi 24:26 This is the purpose that is purposed upon the whole earth; and this is the hand that is stretched out upon all nations.

2 Nephi 24:27 For the Lord of Hosts hath purposed, and who shall disannul? And his hand is stretched out, and who shall turn it back?

2 Nephi 24:28 In the year that king Ahaz died was this burden.

2 Nephi 24:29 Rejoice not thou, whole Palestina, because the rod of him that smote thee is broken; for out of the serpent’s root shall come forth a cockatrice, and his fruit shall be a fiery flying serpent.

2 Nephi 24:30 And the firstborn of the poor shall feed, and the needy shall lie down in safety; and I will kill thy root with famine, and he shall slay thy remnant.

2 Nephi 24:31 Howl, O gate; cry, O city; thou, whole Palestina, art dissolved; for there shall come from the north a smoke, and none shall be alone in his appointed times.

2 Nephi 24:32 What shall then answer the messengers of the nations? That the Lord hath founded Zion, and the poor of his people shall trust in it.
