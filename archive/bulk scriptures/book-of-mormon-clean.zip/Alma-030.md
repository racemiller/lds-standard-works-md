# Alma 30

Alma 30 (summary): Korihor, the anti-Christ, ridicules Christ, the Atonement, and the spirit of prophecy—He teaches that there is no God, no fall of man, no penalty for sin, and no Christ—Alma testifies that Christ will come and that all things denote there is a God—Korihor demands a sign and is struck dumb—The devil had appeared to Korihor as an angel and taught him what to say—Korihor is trodden down and dies. About 76–74 B.C.

Alma 30:1 Behold, now it came to pass that after the people of Ammon were established in the land of Jershon, yea, and also after the Lamanites were driven out of the land, and their dead were buried by the people of the land—

Alma 30:2 Now their dead were not numbered because of the greatness of their numbers; neither were the dead of the Nephites numbered—but it came to pass after they had buried their dead, and also after the days of fasting, and mourning, and prayer, (and it was in the sixteenth year of the reign of the judges over the people of Nephi) there began to be continual peace throughout all the land.

Alma 30:3 Yea, and the people did observe to keep the commandments of the Lord; and they were strict in observing the ordinances of God, according to the law of Moses; for they were taught to keep the law of Moses until it should be fulfilled.

Alma 30:4 And thus the people did have no disturbance in all the sixteenth year of the reign of the judges over the people of Nephi.

Alma 30:5 And it came to pass that in the commencement of the seventeenth year of the reign of the judges, there was continual peace.

Alma 30:6 But it came to pass in the latter end of the seventeenth year, there came a man into the land of Zarahemla, and he was Anti-Christ, for he began to preach unto the people against the prophecies which had been spoken by the prophets, concerning the coming of Christ.

Alma 30:7 Now there was no law against a man’s belief; for it was strictly contrary to the commands of God that there should be a law which should bring men on to unequal grounds.

Alma 30:8 For thus saith the scripture: Choose ye this day, whom ye will serve.

Alma 30:9 Now if a man desired to serve God, it was his privilege; or rather, if he believed in God it was his privilege to serve him; but if he did not believe in him there was no law to punish him.

Alma 30:10 But if he murdered he was punished unto death; and if he robbed he was also punished; and if he stole he was also punished; and if he committed adultery he was also punished; yea, for all this wickedness they were punished.

Alma 30:11 For there was a law that men should be judged according to their crimes. Nevertheless, there was no law against a man’s belief; therefore, a man was punished only for the crimes which he had done; therefore all men were on equal grounds.

Alma 30:12 And this Anti-Christ, whose name was Korihor, (and the law could have no hold upon him) began to preach unto the people that there should be no Christ. And after this manner did he preach, saying:

Alma 30:13 O ye that are bound down under a foolish and a vain hope, why do ye yoke yourselves with such foolish things? Why do ye look for a Christ? For no man can know of anything which is to come.

Alma 30:14 Behold, these things which ye call prophecies, which ye say are handed down by holy prophets, behold, they are foolish traditions of your fathers.

Alma 30:15 How do ye know of their surety? Behold, ye cannot know of things which ye do not see; therefore ye cannot know that there shall be a Christ.

Alma 30:16 Ye look forward and say that ye see a remission of your sins. But behold, it is the effect of a frenzied mind; and this derangement of your minds comes because of the traditions of your fathers, which lead you away into a belief of things which are not so.

Alma 30:17 And many more such things did he say unto them, telling them that there could be no atonement made for the sins of men, but every man fared in this life according to the management of the creature; therefore every man prospered according to his genius, and that every man conquered according to his strength; and whatsoever a man did was no crime.

Alma 30:18 And thus he did preach unto them, leading away the hearts of many, causing them to lift up their heads in their wickedness, yea, leading away many women, and also men, to commit whoredoms—telling them that when a man was dead, that was the end thereof.

Alma 30:19 Now this man went over to the land of Jershon also, to preach these things among the people of Ammon, who were once the people of the Lamanites.

Alma 30:20 But behold they were more wise than many of the Nephites; for they took him, and bound him, and carried him before Ammon, who was a high priest over that people.

Alma 30:21 And it came to pass that he caused that he should be carried out of the land. And he came over into the land of Gideon, and began to preach unto them also; and here he did not have much success, for he was taken and bound and carried before the high priest, and also the chief judge over the land.

Alma 30:22 And it came to pass that the high priest said unto him: Why do ye go about perverting the ways of the Lord? Why do ye teach this people that there shall be no Christ, to interrupt their rejoicings? Why do ye speak against all the prophecies of the holy prophets?

Alma 30:23 Now the high priest’s name was Giddonah. And Korihor said unto him: Because I do not teach the foolish traditions of your fathers, and because I do not teach this people to bind themselves down under the foolish ordinances and performances which are laid down by ancient priests, to usurp power and authority over them, to keep them in ignorance, that they may not lift up their heads, but be brought down according to thy words.

Alma 30:24 Ye say that this people is a free people. Behold, I say they are in bondage. Ye say that those ancient prophecies are true. Behold, I say that ye do not know that they are true.

Alma 30:25 Ye say that this people is a guilty and a fallen people, because of the transgression of a parent. Behold, I say that a child is not guilty because of its parents.

Alma 30:26 And ye also say that Christ shall come. But behold, I say that ye do not know that there shall be a Christ. And ye say also that he shall be slain for the sins of the world—

Alma 30:27 And thus ye lead away this people after the foolish traditions of your fathers, and according to your own desires; and ye keep them down, even as it were in bondage, that ye may glut yourselves with the labors of their hands, that they durst not look up with boldness, and that they durst not enjoy their rights and privileges.

Alma 30:28 Yea, they durst not make use of that which is their own lest they should offend their priests, who do yoke them according to their desires, and have brought them to believe, by their traditions and their dreams and their whims and their visions and their pretended mysteries, that they should, if they did not do according to their words, offend some unknown being, who they say is God—a being who never has been seen or known, who never was nor ever will be.

Alma 30:29 Now when the high priest and the chief judge saw the hardness of his heart, yea, when they saw that he would revile even against God, they would not make any reply to his words; but they caused that he should be bound; and they delivered him up into the hands of the officers, and sent him to the land of Zarahemla, that he might be brought before Alma, and the chief judge who was governor over all the land.

Alma 30:30 And it came to pass that when he was brought before Alma and the chief judge, he did go on in the same manner as he did in the land of Gideon; yea, he went on to blaspheme.

Alma 30:31 And he did rise up in great swelling words before Alma, and did revile against the priests and teachers, accusing them of leading away the people after the silly traditions of their fathers, for the sake of glutting on the labors of the people.

Alma 30:32 Now Alma said unto him: Thou knowest that we do not glut ourselves upon the labors of this people; for behold I have labored even from the commencement of the reign of the judges until now, with mine own hands for my support, notwithstanding my many travels round about the land to declare the word of God unto my people.

Alma 30:33 And notwithstanding the many labors which I have performed in the church, I have never received so much as even one senine for my labor; neither has any of my brethren, save it were in the judgment-seat; and then we have received only according to law for our time.

Alma 30:34 And now, if we do not receive anything for our labors in the church, what doth it profit us to labor in the church save it were to declare the truth, that we may have rejoicings in the joy of our brethren?

Alma 30:35 Then why sayest thou that we preach unto this people to get gain, when thou, of thyself, knowest that we receive no gain? And now, believest thou that we deceive this people, that causes such joy in their hearts?

Alma 30:36 And Korihor answered him, Yea.

Alma 30:37 And then Alma said unto him: Believest thou that there is a God?

Alma 30:38 And he answered, Nay.

Alma 30:39 Now Alma said unto him: Will ye deny again that there is a God, and also deny the Christ? For behold, I say unto you, I know there is a God, and also that Christ shall come.

Alma 30:40 And now what evidence have ye that there is no God, or that Christ cometh not? I say unto you that ye have none, save it be your word only.

Alma 30:41 But, behold, I have all things as a testimony that these things are true; and ye also have all things as a testimony unto you that they are true; and will ye deny them? Believest thou that these things are true?

Alma 30:42 Behold, I know that thou believest, but thou art possessed with a lying spirit, and ye have put off the Spirit of God that it may have no place in you; but the devil has power over you, and he doth carry you about, working devices that he may destroy the children of God.

Alma 30:43 And now Korihor said unto Alma: If thou wilt show me a sign, that I may be convinced that there is a God, yea, show unto me that he hath power, and then will I be convinced of the truth of thy words.

Alma 30:44 But Alma said unto him: Thou hast had signs enough; will ye tempt your God? Will ye say, Show unto me a sign, when ye have the testimony of all these thy brethren, and also all the holy prophets? The scriptures are laid before thee, yea, and all things denote there is a God; yea, even the earth, and all things that are upon the face of it, yea, and its motion, yea, and also all the planets which move in their regular form do witness that there is a Supreme Creator.

Alma 30:45 And yet do ye go about, leading away the hearts of this people, testifying unto them there is no God? And yet will ye deny against all these witnesses? And he said: Yea, I will deny, except ye shall show me a sign.

Alma 30:46 And now it came to pass that Alma said unto him: Behold, I am grieved because of the hardness of your heart, yea, that ye will still resist the spirit of the truth, that thy soul may be destroyed.

Alma 30:47 But behold, it is better that thy soul should be lost than that thou shouldst be the means of bringing many souls down to destruction, by thy lying and by thy flattering words; therefore if thou shalt deny again, behold God shall smite thee, that thou shalt become dumb, that thou shalt never open thy mouth any more, that thou shalt not deceive this people any more.

Alma 30:48 Now Korihor said unto him: I do not deny the existence of a God, but I do not believe that there is a God; and I say also, that ye do not know that there is a God; and except ye show me a sign, I will not believe.

Alma 30:49 Now Alma said unto him: This will I give unto thee for a sign, that thou shalt be struck dumb, according to my words; and I say, that in the name of God, ye shall be struck dumb, that ye shall no more have utterance.

Alma 30:50 Now when Alma had said these words, Korihor was struck dumb, that he could not have utterance, according to the words of Alma.

Alma 30:51 And now when the chief judge saw this, he put forth his hand and wrote unto Korihor, saying: Art thou convinced of the power of God? In whom did ye desire that Alma should show forth his sign? Would ye that he should afflict others, to show unto thee a sign? Behold, he has showed unto you a sign; and now will ye dispute more?

Alma 30:52 And Korihor put forth his hand and wrote, saying: I know that I am dumb, for I cannot speak; and I know that nothing save it were the power of God could bring this upon me; yea, and I always knew that there was a God.

Alma 30:53 But behold, the devil hath deceived me; for he appeared unto me in the form of an angel, and said unto me: Go and reclaim this people, for they have all gone astray after an unknown God. And he said unto me: There is no God; yea, and he taught me that which I should say. And I have taught his words; and I taught them because they were pleasing unto the carnal mind; and I taught them, even until I had much success, insomuch that I verily believed that they were true; and for this cause I withstood the truth, even until I have brought this great curse upon me.

Alma 30:54 Now when he had said this, he besought that Alma should pray unto God, that the curse might be taken from him.

Alma 30:55 But Alma said unto him: If this curse should be taken from thee thou wouldst again lead away the hearts of this people; therefore, it shall be unto thee even as the Lord will.

Alma 30:56 And it came to pass that the curse was not taken off of Korihor; but he was cast out, and went about from house to house begging for his food.

Alma 30:57 Now the knowledge of what had happened unto Korihor was immediately published throughout all the land; yea, the proclamation was sent forth by the chief judge to all the people in the land, declaring unto those who had believed in the words of Korihor that they must speedily repent, lest the same judgments would come unto them.

Alma 30:58 And it came to pass that they were all convinced of the wickedness of Korihor; therefore they were all converted again unto the Lord; and this put an end to the iniquity after the manner of Korihor. And Korihor did go about from house to house, begging food for his support.

Alma 30:59 And it came to pass that as he went forth among the people, yea, among a people who had separated themselves from the Nephites and called themselves Zoramites, being led by a man whose name was Zoram—and as he went forth amongst them, behold, he was run upon and trodden down, even until he was dead.

Alma 30:60 And thus we see the end of him who perverteth the ways of the Lord; and thus we see that the devil will not support his children at the last day, but doth speedily drag them down to hell.
