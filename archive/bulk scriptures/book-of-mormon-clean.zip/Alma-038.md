# Alma 38

Alma 38 (summary): Shiblon was persecuted for righteousness’ sake—Salvation is in Christ, who is the life and the light of the world—Bridle all your passions. About 74 B.C.

Alma 38:1 My son, give ear to my words, for I say unto you, even as I said unto Helaman, that inasmuch as ye shall keep the commandments of God ye shall prosper in the land; and inasmuch as ye will not keep the commandments of God ye shall be cut off from his presence.

Alma 38:2 And now, my son, I trust that I shall have great joy in you, because of your steadiness and your faithfulness unto God; for as you have commenced in your youth to look to the Lord your God, even so I hope that you will continue in keeping his commandments; for blessed is he that endureth to the end.

Alma 38:3 I say unto you, my son, that I have had great joy in thee already, because of thy faithfulness and thy diligence, and thy patience and thy long-suffering among the people of the Zoramites.

Alma 38:4 For I know that thou wast in bonds; yea, and I also know that thou wast stoned for the word’s sake; and thou didst bear all these things with patience because the Lord was with thee; and now thou knowest that the Lord did deliver thee.

Alma 38:5 And now my son, Shiblon, I would that ye should remember, that as much as ye shall put your trust in God even so much ye shall be delivered out of your trials, and your troubles, and your afflictions, and ye shall be lifted up at the last day.

Alma 38:6 Now, my son, I would not that ye should think that I know these things of myself, but it is the Spirit of God which is in me which maketh these things known unto me; for if I had not been born of God I should not have known these things.

Alma 38:7 But behold, the Lord in his great mercy sent his angel to declare unto me that I must stop the work of destruction among his people; yea, and I have seen an angel face to face, and he spake with me, and his voice was as thunder, and it shook the whole earth.

Alma 38:8 And it came to pass that I was three days and three nights in the most bitter pain and anguish of soul; and never, until I did cry out unto the Lord Jesus Christ for mercy, did I receive a remission of my sins. But behold, I did cry unto him and I did find peace to my soul.

Alma 38:9 And now, my son, I have told you this that ye may learn wisdom, that ye may learn of me that there is no other way or means whereby man can be saved, only in and through Christ. Behold, he is the life and the light of the world. Behold, he is the word of truth and righteousness.

Alma 38:10 And now, as ye have begun to teach the word even so I would that ye should continue to teach; and I would that ye would be diligent and temperate in all things.

Alma 38:11 See that ye are not lifted up unto pride; yea, see that ye do not boast in your own wisdom, nor of your much strength.

Alma 38:12 Use boldness, but not overbearance; and also see that ye bridle all your passions, that ye may be filled with love; see that ye refrain from idleness.

Alma 38:13 Do not pray as the Zoramites do, for ye have seen that they pray to be heard of men, and to be praised for their wisdom.

Alma 38:14 Do not say: O God, I thank thee that we are better than our brethren; but rather say: O Lord, forgive my unworthiness, and remember my brethren in mercy—yea, acknowledge your unworthiness before God at all times.

Alma 38:15 And may the Lord bless your soul, and receive you at the last day into his kingdom, to sit down in peace. Now go, my son, and teach the word unto this people. Be sober. My son, farewell.
