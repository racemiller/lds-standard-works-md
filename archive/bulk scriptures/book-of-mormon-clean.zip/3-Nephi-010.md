# 3 Nephi 10

3 Nephi 10 (summary): There is silence in the land for many hours—The voice of Christ promises to gather His people as a hen gathers her chickens—The more righteous part of the people have been preserved. About A.D. 34–35.

3 Nephi 10:1 And now behold, it came to pass that all the people of the land did hear these sayings, and did witness of it. And after these sayings there was silence in the land for the space of many hours;

3 Nephi 10:2 For so great was the astonishment of the people that they did cease lamenting and howling for the loss of their kindred which had been slain; therefore there was silence in all the land for the space of many hours.

3 Nephi 10:3 And it came to pass that there came a voice again unto the people, and all the people did hear, and did witness of it, saying:

3 Nephi 10:4 O ye people of these great cities which have fallen, who are descendants of Jacob, yea, who are of the house of Israel, how oft have I gathered you as a hen gathereth her chickens under her wings, and have nourished you.

3 Nephi 10:5 And again, how oft would I have gathered you as a hen gathereth her chickens under her wings, yea, O ye people of the house of Israel, who have fallen; yea, O ye people of the house of Israel, ye that dwell at Jerusalem, as ye that have fallen; yea, how oft would I have gathered you as a hen gathereth her chickens, and ye would not.

3 Nephi 10:6 O ye house of Israel whom I have spared, how oft will I gather you as a hen gathereth her chickens under her wings, if ye will repent and return unto me with full purpose of heart.

3 Nephi 10:7 But if not, O house of Israel, the places of your dwellings shall become desolate until the time of the fulfilling of the covenant to your fathers.

3 Nephi 10:8 And now it came to pass that after the people had heard these words, behold, they began to weep and howl again because of the loss of their kindred and friends.

3 Nephi 10:9 And it came to pass that thus did the three days pass away. And it was in the morning, and the darkness dispersed from off the face of the land, and the earth did cease to tremble, and the rocks did cease to rend, and the dreadful groanings did cease, and all the tumultuous noises did pass away.

3 Nephi 10:10 And the earth did cleave together again, that it stood; and the mourning, and the weeping, and the wailing of the people who were spared alive did cease; and their mourning was turned into joy, and their lamentations into the praise and thanksgiving unto the Lord Jesus Christ, their Redeemer.

3 Nephi 10:11 And thus far were the scriptures fulfilled which had been spoken by the prophets.

3 Nephi 10:12 And it was the more righteous part of the people who were saved, and it was they who received the prophets and stoned them not; and it was they who had not shed the blood of the saints, who were spared—

3 Nephi 10:13 And they were spared and were not sunk and buried up in the earth; and they were not drowned in the depths of the sea; and they were not burned by fire, neither were they fallen upon and crushed to death; and they were not carried away in the whirlwind; neither were they overpowered by the vapor of smoke and of darkness.

3 Nephi 10:14 And now, whoso readeth, let him understand; he that hath the scriptures, let him search them, and see and behold if all these deaths and destructions by fire, and by smoke, and by tempests, and by whirlwinds, and by the opening of the earth to receive them, and all these things are not unto the fulfilling of the prophecies of many of the holy prophets.

3 Nephi 10:15 Behold, I say unto you, Yea, many have testified of these things at the coming of Christ, and were slain because they testified of these things.

3 Nephi 10:16 Yea, the prophet Zenos did testify of these things, and also Zenock spake concerning these things, because they testified particularly concerning us, who are the remnant of their seed.

3 Nephi 10:17 Behold, our father Jacob also testified concerning a remnant of the seed of Joseph. And behold, are not we a remnant of the seed of Joseph? And these things which testify of us, are they not written upon the plates of brass which our father Lehi brought out of Jerusalem?

3 Nephi 10:18 And it came to pass that in the ending of the thirty and fourth year, behold, I will show unto you that the people of Nephi who were spared, and also those who had been called Lamanites, who had been spared, did have great favors shown unto them, and great blessings poured out upon their heads, insomuch that soon after the ascension of Christ into heaven he did truly manifest himself unto them—

3 Nephi 10:19 Showing his body unto them, and ministering unto them; and an account of his ministry shall be given hereafter. Therefore for this time I make an end of my sayings.
