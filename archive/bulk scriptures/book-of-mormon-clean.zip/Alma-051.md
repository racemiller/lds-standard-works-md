# Alma 51

Alma 51 (summary): The king-men seek to change the law and set up a king—Pahoran and the freemen are supported by the voice of the people—Moroni compels the king-men to defend their country or be put to death—Amalickiah and the Lamanites capture many fortified cities—Teancum repels the Lamanite invasion and slays Amalickiah in his tent. About 67–66 B.C.

Alma 51:1 And now it came to pass in the commencement of the twenty and fifth year of the reign of the judges over the people of Nephi, they having established peace between the people of Lehi and the people of Morianton concerning their lands, and having commenced the twenty and fifth year in peace;

Alma 51:2 Nevertheless, they did not long maintain an entire peace in the land, for there began to be a contention among the people concerning the chief judge Pahoran; for behold, there were a part of the people who desired that a few particular points of the law should be altered.

Alma 51:3 But behold, Pahoran would not alter nor suffer the law to be altered; therefore, he did not hearken to those who had sent in their voices with their petitions concerning the altering of the law.

Alma 51:4 Therefore, those who were desirous that the law should be altered were angry with him, and desired that he should no longer be chief judge over the land; therefore there arose a warm dispute concerning the matter, but not unto bloodshed.

Alma 51:5 And it came to pass that those who were desirous that Pahoran should be dethroned from the judgment-seat were called king-men, for they were desirous that the law should be altered in a manner to overthrow the free government and to establish a king over the land.

Alma 51:6 And those who were desirous that Pahoran should remain chief judge over the land took upon them the name of freemen; and thus was the division among them, for the freemen had sworn or covenanted to maintain their rights and the privileges of their religion by a free government.

Alma 51:7 And it came to pass that this matter of their contention was settled by the voice of the people. And it came to pass that the voice of the people came in favor of the freemen, and Pahoran retained the judgment-seat, which caused much rejoicing among the brethren of Pahoran and also many of the people of liberty, who also put the king-men to silence, that they durst not oppose but were obliged to maintain the cause of freedom.

Alma 51:8 Now those who were in favor of kings were those of high birth, and they sought to be kings; and they were supported by those who sought power and authority over the people.

Alma 51:9 But behold, this was a critical time for such contentions to be among the people of Nephi; for behold, Amalickiah had again stirred up the hearts of the people of the Lamanites against the people of the Nephites, and he was gathering together soldiers from all parts of his land, and arming them, and preparing for war with all diligence; for he had sworn to drink the blood of Moroni.

Alma 51:10 But behold, we shall see that his promise which he made was rash; nevertheless, he did prepare himself and his armies to come to battle against the Nephites.

Alma 51:11 Now his armies were not so great as they had hitherto been, because of the many thousands who had been slain by the hand of the Nephites; but notwithstanding their great loss, Amalickiah had gathered together a wonderfully great army, insomuch that he feared not to come down to the land of Zarahemla.

Alma 51:12 Yea, even Amalickiah did himself come down, at the head of the Lamanites. And it was in the twenty and fifth year of the reign of the judges; and it was at the same time that they had begun to settle the affairs of their contentions concerning the chief judge, Pahoran.

Alma 51:13 And it came to pass that when the men who were called king-men had heard that the Lamanites were coming down to battle against them, they were glad in their hearts; and they refused to take up arms, for they were so wroth with the chief judge, and also with the people of liberty, that they would not take up arms to defend their country.

Alma 51:14 And it came to pass that when Moroni saw this, and also saw that the Lamanites were coming into the borders of the land, he was exceedingly wroth because of the stubbornness of those people whom he had labored with so much diligence to preserve; yea, he was exceedingly wroth; his soul was filled with anger against them.

Alma 51:15 And it came to pass that he sent a petition, with the voice of the people, unto the governor of the land, desiring that he should read it, and give him (Moroni) power to compel those dissenters to defend their country or to put them to death.

Alma 51:16 For it was his first care to put an end to such contentions and dissensions among the people; for behold, this had been hitherto a cause of all their destruction. And it came to pass that it was granted according to the voice of the people.

Alma 51:17 And it came to pass that Moroni commanded that his army should go against those king-men, to pull down their pride and their nobility and level them with the earth, or they should take up arms and support the cause of liberty.

Alma 51:18 And it came to pass that the armies did march forth against them; and they did pull down their pride and their nobility, insomuch that as they did lift their weapons of war to fight against the men of Moroni they were hewn down and leveled to the earth.

Alma 51:19 And it came to pass that there were four thousand of those dissenters who were hewn down by the sword; and those of their leaders who were not slain in battle were taken and cast into prison, for there was no time for their trials at this period.

Alma 51:20 And the remainder of those dissenters, rather than be smitten down to the earth by the sword, yielded to the standard of liberty, and were compelled to hoist the title of liberty upon their towers, and in their cities, and to take up arms in defence of their country.

Alma 51:21 And thus Moroni put an end to those king-men, that there were not any known by the appellation of king-men; and thus he put an end to the stubbornness and the pride of those people who professed the blood of nobility; but they were brought down to humble themselves like unto their brethren, and to fight valiantly for their freedom from bondage.

Alma 51:22 Behold, it came to pass that while Moroni was thus breaking down the wars and contentions among his own people, and subjecting them to peace and civilization, and making regulations to prepare for war against the Lamanites, behold, the Lamanites had come into the land of Moroni, which was in the borders by the seashore.

Alma 51:23 And it came to pass that the Nephites were not sufficiently strong in the city of Moroni; therefore Amalickiah did drive them, slaying many. And it came to pass that Amalickiah took possession of the city, yea, possession of all their fortifications.

Alma 51:24 And those who fled out of the city of Moroni came to the city of Nephihah; and also the people of the city of Lehi gathered themselves together, and made preparations and were ready to receive the Lamanites to battle.

Alma 51:25 But it came to pass that Amalickiah would not suffer the Lamanites to go against the city of Nephihah to battle, but kept them down by the seashore, leaving men in every city to maintain and defend it.

Alma 51:26 And thus he went on, taking possession of many cities, the city of Nephihah, and the city of Lehi, and the city of Morianton, and the city of Omner, and the city of Gid, and the city of Mulek, all of which were on the east borders by the seashore.

Alma 51:27 And thus had the Lamanites obtained, by the cunning of Amalickiah, so many cities, by their numberless hosts, all of which were strongly fortified after the manner of the fortifications of Moroni; all of which afforded strongholds for the Lamanites.

Alma 51:28 And it came to pass that they marched to the borders of the land Bountiful, driving the Nephites before them and slaying many.

Alma 51:29 But it came to pass that they were met by Teancum, who had slain Morianton and had headed his people in his flight.

Alma 51:30 And it came to pass that he headed Amalickiah also, as he was marching forth with his numerous army that he might take possession of the land Bountiful, and also the land northward.

Alma 51:31 But behold he met with a disappointment by being repulsed by Teancum and his men, for they were great warriors; for every man of Teancum did exceed the Lamanites in their strength and in their skill of war, insomuch that they did gain advantage over the Lamanites.

Alma 51:32 And it came to pass that they did harass them, insomuch that they did slay them even until it was dark. And it came to pass that Teancum and his men did pitch their tents in the borders of the land Bountiful; and Amalickiah did pitch his tents in the borders on the beach by the seashore, and after this manner were they driven.

Alma 51:33 And it came to pass that when the night had come, Teancum and his servant stole forth and went out by night, and went into the camp of Amalickiah; and behold, sleep had overpowered them because of their much fatigue, which was caused by the labors and heat of the day.

Alma 51:34 And it came to pass that Teancum stole privily into the tent of the king, and put a javelin to his heart; and he did cause the death of the king immediately that he did not awake his servants.

Alma 51:35 And he returned again privily to his own camp, and behold, his men were asleep, and he awoke them and told them all the things that he had done.

Alma 51:36 And he caused that his armies should stand in readiness, lest the Lamanites had awakened and should come upon them.

Alma 51:37 And thus endeth the twenty and fifth year of the reign of the judges over the people of Nephi; and thus endeth the days of Amalickiah.
