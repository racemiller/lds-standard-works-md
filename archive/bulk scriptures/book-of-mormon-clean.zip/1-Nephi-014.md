# 1 Nephi 14

1 Nephi 14 (summary): An angel tells Nephi of the blessings and cursings to fall upon the Gentiles—There are only two churches: the Church of the Lamb of God and the church of the devil—The Saints of God in all nations are persecuted by the great and abominable church—The Apostle John will write concerning the end of the world. About 600–592 B.C.

1 Nephi 14:1 And it shall come to pass, that if the Gentiles shall hearken unto the Lamb of God in that day that he shall manifest himself unto them in word, and also in power, in very deed, unto the taking away of their stumbling blocks—

1 Nephi 14:2 And harden not their hearts against the Lamb of God, they shall be numbered among the seed of thy father; yea, they shall be numbered among the house of Israel; and they shall be a blessed people upon the promised land forever; they shall be no more brought down into captivity; and the house of Israel shall no more be confounded.

1 Nephi 14:3 And that great pit, which hath been digged for them by that great and abominable church, which was founded by the devil and his children, that he might lead away the souls of men down to hell—yea, that great pit which hath been digged for the destruction of men shall be filled by those who digged it, unto their utter destruction, saith the Lamb of God; not the destruction of the soul, save it be the casting of it into that hell which hath no end.

1 Nephi 14:4 For behold, this is according to the captivity of the devil, and also according to the justice of God, upon all those who will work wickedness and abomination before him.

1 Nephi 14:5 And it came to pass that the angel spake unto me, Nephi, saying: Thou hast beheld that if the Gentiles repent it shall be well with them; and thou also knowest concerning the covenants of the Lord unto the house of Israel; and thou also hast heard that whoso repenteth not must perish.

1 Nephi 14:6 Therefore, wo be unto the Gentiles if it so be that they harden their hearts against the Lamb of God.

1 Nephi 14:7 For the time cometh, saith the Lamb of God, that I will work a great and a marvelous work among the children of men; a work which shall be everlasting, either on the one hand or on the other—either to the convincing of them unto peace and life eternal, or unto the deliverance of them to the hardness of their hearts and the blindness of their minds unto their being brought down into captivity, and also into destruction, both temporally and spiritually, according to the captivity of the devil, of which I have spoken.

1 Nephi 14:8 And it came to pass that when the angel had spoken these words, he said unto me: Rememberest thou the covenants of the Father unto the house of Israel? I said unto him, Yea.

1 Nephi 14:9 And it came to pass that he said unto me: Look, and behold that great and abominable church, which is the mother of abominations, whose founder is the devil.

1 Nephi 14:10 And he said unto me: Behold there are save two churches only; the one is the church of the Lamb of God, and the other is the church of the devil; wherefore, whoso belongeth not to the church of the Lamb of God belongeth to that great church, which is the mother of abominations; and she is the whore of all the earth.

1 Nephi 14:11 And it came to pass that I looked and beheld the whore of all the earth, and she sat upon many waters; and she had dominion over all the earth, among all nations, kindreds, tongues, and people.

1 Nephi 14:12 And it came to pass that I beheld the church of the Lamb of God, and its numbers were few, because of the wickedness and abominations of the whore who sat upon many waters; nevertheless, I beheld that the church of the Lamb, who were the saints of God, were also upon all the face of the earth; and their dominions upon the face of the earth were small, because of the wickedness of the great whore whom I saw.

1 Nephi 14:13 And it came to pass that I beheld that the great mother of abominations did gather together multitudes upon the face of all the earth, among all the nations of the Gentiles, to fight against the Lamb of God.

1 Nephi 14:14 And it came to pass that I, Nephi, beheld the power of the Lamb of God, that it descended upon the saints of the church of the Lamb, and upon the covenant people of the Lord, who were scattered upon all the face of the earth; and they were armed with righteousness and with the power of God in great glory.

1 Nephi 14:15 And it came to pass that I beheld that the wrath of God was poured out upon that great and abominable church, insomuch that there were wars and rumors of wars among all the nations and kindreds of the earth.

1 Nephi 14:16 And as there began to be wars and rumors of wars among all the nations which belonged to the mother of abominations, the angel spake unto me, saying: Behold, the wrath of God is upon the mother of harlots; and behold, thou seest all these things—

1 Nephi 14:17 And when the day cometh that the wrath of God is poured out upon the mother of harlots, which is the great and abominable church of all the earth, whose founder is the devil, then, at that day, the work of the Father shall commence, in preparing the way for the fulfilling of his covenants, which he hath made to his people who are of the house of Israel.

1 Nephi 14:18 And it came to pass that the angel spake unto me, saying: Look!

1 Nephi 14:19 And I looked and beheld a man, and he was dressed in a white robe.

1 Nephi 14:20 And the angel said unto me: Behold one of the twelve apostles of the Lamb.

1 Nephi 14:21 Behold, he shall see and write the remainder of these things; yea, and also many things which have been.

1 Nephi 14:22 And he shall also write concerning the end of the world.

1 Nephi 14:23 Wherefore, the things which he shall write are just and true; and behold they are written in the book which thou beheld proceeding out of the mouth of the Jew; and at the time they proceeded out of the mouth of the Jew, or, at the time the book proceeded out of the mouth of the Jew, the things which were written were plain and pure, and most precious and easy to the understanding of all men.

1 Nephi 14:24 And behold, the things which this apostle of the Lamb shall write are many things which thou hast seen; and behold, the remainder shalt thou see.

1 Nephi 14:25 But the things which thou shalt see hereafter thou shalt not write; for the Lord God hath ordained the apostle of the Lamb of God that he should write them.

1 Nephi 14:26 And also others who have been, to them hath he shown all things, and they have written them; and they are sealed up to come forth in their purity, according to the truth which is in the Lamb, in the own due time of the Lord, unto the house of Israel.

1 Nephi 14:27 And I, Nephi, heard and bear record, that the name of the apostle of the Lamb was John, according to the word of the angel.

1 Nephi 14:28 And behold, I, Nephi, am forbidden that I should write the remainder of the things which I saw and heard; wherefore the things which I have written sufficeth me; and I have written but a small part of the things which I saw.

1 Nephi 14:29 And I bear record that I saw the things which my father saw, and the angel of the Lord did make them known unto me.

1 Nephi 14:30 And now I make an end of speaking concerning the things which I saw while I was carried away in the Spirit; and if all the things which I saw are not written, the things which I have written are true. And thus it is. Amen.
