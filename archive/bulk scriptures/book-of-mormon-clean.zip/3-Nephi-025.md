# 3 Nephi 25

3 Nephi 25 (summary): At the Second Coming, the proud and wicked will be burned as stubble—Elijah will return before that great and dreadful day—Compare Malachi 4. About A.D. 34.

3 Nephi 25:1 For behold, the day cometh that shall burn as an oven; and all the proud, yea, and all that do wickedly, shall be stubble; and the day that cometh shall burn them up, saith the Lord of Hosts, that it shall leave them neither root nor branch.

3 Nephi 25:2 But unto you that fear my name, shall the Son of Righteousness arise with healing in his wings; and ye shall go forth and grow up as calves in the stall.

3 Nephi 25:3 And ye shall tread down the wicked; for they shall be ashes under the soles of your feet in the day that I shall do this, saith the Lord of Hosts.

3 Nephi 25:4 Remember ye the law of Moses, my servant, which I commanded unto him in Horeb for all Israel, with the statutes and judgments.

3 Nephi 25:5 Behold, I will send you Elijah the prophet before the coming of the great and dreadful day of the Lord;

3 Nephi 25:6 And he shall turn the heart of the fathers to the children, and the heart of the children to their fathers, lest I come and smite the earth with a curse.
