# Alma 27

Alma 27 (summary): The Lord commands Ammon to lead the people of Anti-Nephi-Lehi to safety—Upon meeting Alma, Ammon’s joy exhausts his strength—The Nephites give the Anti-Nephi-Lehies the land of Jershon—They are called the people of Ammon. About 90–77 B.C.

Alma 27:1 Now it came to pass that when those Lamanites who had gone to war against the Nephites had found, after their many struggles to destroy them, that it was in vain to seek their destruction, they returned again to the land of Nephi.

Alma 27:2 And it came to pass that the Amalekites, because of their loss, were exceedingly angry. And when they saw that they could not seek revenge from the Nephites, they began to stir up the people in anger against their brethren, the people of Anti-Nephi-Lehi; therefore they began again to destroy them.

Alma 27:3 Now this people again refused to take their arms, and they suffered themselves to be slain according to the desires of their enemies.

Alma 27:4 Now when Ammon and his brethren saw this work of destruction among those whom they so dearly beloved, and among those who had so dearly beloved them—for they were treated as though they were angels sent from God to save them from everlasting destruction—therefore, when Ammon and his brethren saw this great work of destruction, they were moved with compassion, and they said unto the king:

Alma 27:5 Let us gather together this people of the Lord, and let us go down to the land of Zarahemla to our brethren the Nephites, and flee out of the hands of our enemies, that we be not destroyed.

Alma 27:6 But the king said unto them: Behold, the Nephites will destroy us, because of the many murders and sins we have committed against them.

Alma 27:7 And Ammon said: I will go and inquire of the Lord, and if he say unto us, go down unto our brethren, will ye go?

Alma 27:8 And the king said unto him: Yea, if the Lord saith unto us go, we will go down unto our brethren, and we will be their slaves until we repair unto them the many murders and sins which we have committed against them.

Alma 27:9 But Ammon said unto him: It is against the law of our brethren, which was established by my father, that there should be any slaves among them; therefore let us go down and rely upon the mercies of our brethren.

Alma 27:10 But the king said unto him: Inquire of the Lord, and if he saith unto us go, we will go; otherwise we will perish in the land.

Alma 27:11 And it came to pass that Ammon went and inquired of the Lord, and the Lord said unto him:

Alma 27:12 Get this people out of this land, that they perish not; for Satan has great hold on the hearts of the Amalekites, who do stir up the Lamanites to anger against their brethren to slay them; therefore get thee out of this land; and blessed are this people in this generation, for I will preserve them.

Alma 27:13 And now it came to pass that Ammon went and told the king all the words which the Lord had said unto him.

Alma 27:14 And they gathered together all their people, yea, all the people of the Lord, and did gather together all their flocks and herds, and departed out of the land, and came into the wilderness which divided the land of Nephi from the land of Zarahemla, and came over near the borders of the land.

Alma 27:15 And it came to pass that Ammon said unto them: Behold, I and my brethren will go forth into the land of Zarahemla, and ye shall remain here until we return; and we will try the hearts of our brethren, whether they will that ye shall come into their land.

Alma 27:16 And it came to pass that as Ammon was going forth into the land, that he and his brethren met Alma, over in the place of which has been spoken; and behold, this was a joyful meeting.

Alma 27:17 Now the joy of Ammon was so great even that he was full; yea, he was swallowed up in the joy of his God, even to the exhausting of his strength; and he fell again to the earth.

Alma 27:18 Now was not this exceeding joy? Behold, this is joy which none receiveth save it be the truly penitent and humble seeker of happiness.

Alma 27:19 Now the joy of Alma in meeting his brethren was truly great, and also the joy of Aaron, of Omner, and Himni; but behold their joy was not that to exceed their strength.

Alma 27:20 And now it came to pass that Alma conducted his brethren back to the land of Zarahemla; even to his own house. And they went and told the chief judge all the things that had happened unto them in the land of Nephi, among their brethren, the Lamanites.

Alma 27:21 And it came to pass that the chief judge sent a proclamation throughout all the land, desiring the voice of the people concerning the admitting their brethren, who were the people of Anti-Nephi-Lehi.

Alma 27:22 And it came to pass that the voice of the people came, saying: Behold, we will give up the land of Jershon, which is on the east by the sea, which joins the land Bountiful, which is on the south of the land Bountiful; and this land Jershon is the land which we will give unto our brethren for an inheritance.

Alma 27:23 And behold, we will set our armies between the land Jershon and the land Nephi, that we may protect our brethren in the land Jershon; and this we do for our brethren, on account of their fear to take up arms against their brethren lest they should commit sin; and this their great fear came because of their sore repentance which they had, on account of their many murders and their awful wickedness.

Alma 27:24 And now behold, this will we do unto our brethren, that they may inherit the land Jershon; and we will guard them from their enemies with our armies, on condition that they will give us a portion of their substance to assist us that we may maintain our armies.

Alma 27:25 Now, it came to pass that when Ammon had heard this, he returned to the people of Anti-Nephi-Lehi, and also Alma with him, into the wilderness, where they had pitched their tents, and made known unto them all these things. And Alma also related unto them his conversion, with Ammon and Aaron, and his brethren.

Alma 27:26 And it came to pass that it did cause great joy among them. And they went down into the land of Jershon, and took possession of the land of Jershon; and they were called by the Nephites the people of Ammon; therefore they were distinguished by that name ever after.

Alma 27:27 And they were among the people of Nephi, and also numbered among the people who were of the church of God. And they were also distinguished for their zeal towards God, and also towards men; for they were perfectly honest and upright in all things; and they were firm in the faith of Christ, even unto the end.

Alma 27:28 And they did look upon shedding the blood of their brethren with the greatest abhorrence; and they never could be prevailed upon to take up arms against their brethren; and they never did look upon death with any degree of terror, for their hope and views of Christ and the resurrection; therefore, death was swallowed up to them by the victory of Christ over it.

Alma 27:29 Therefore, they would suffer death in the most aggravating and distressing manner which could be inflicted by their brethren, before they would take the sword or cimeter to smite them.

Alma 27:30 And thus they were a zealous and beloved people, a highly favored people of the Lord.
