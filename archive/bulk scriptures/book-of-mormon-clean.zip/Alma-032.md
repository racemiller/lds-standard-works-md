# Alma 32

Alma 32 (summary): Alma teaches the poor whose afflictions had humbled them—Faith is a hope in that which is not seen which is true—Alma testifies that angels minister to men, women, and children—Alma compares the word unto a seed—It must be planted and nourished—Then it grows into a tree from which the fruit of eternal life is picked. About 74 B.C.

Alma 32:1 And it came to pass that they did go forth, and began to preach the word of God unto the people, entering into their synagogues, and into their houses; yea, and even they did preach the word in their streets.

Alma 32:2 And it came to pass that after much labor among them, they began to have success among the poor class of people; for behold, they were cast out of the synagogues because of the coarseness of their apparel—

Alma 32:3 Therefore they were not permitted to enter into their synagogues to worship God, being esteemed as filthiness; therefore they were poor; yea, they were esteemed by their brethren as dross; therefore they were poor as to things of the world; and also they were poor in heart.

Alma 32:4 Now, as Alma was teaching and speaking unto the people upon the hill Onidah, there came a great multitude unto him, who were those of whom we have been speaking, of whom were poor in heart, because of their poverty as to the things of the world.

Alma 32:5 And they came unto Alma; and the one who was the foremost among them said unto him: Behold, what shall these my brethren do, for they are despised of all men because of their poverty, yea, and more especially by our priests; for they have cast us out of our synagogues which we have labored abundantly to build with our own hands; and they have cast us out because of our exceeding poverty; and we have no place to worship our God; and behold, what shall we do?

Alma 32:6 And now when Alma heard this, he turned him about, his face immediately towards him, and he beheld with great joy; for he beheld that their afflictions had truly humbled them, and that they were in a preparation to hear the word.

Alma 32:7 Therefore he did say no more to the other multitude; but he stretched forth his hand, and cried unto those whom he beheld, who were truly penitent, and said unto them:

Alma 32:8 I behold that ye are lowly in heart; and if so, blessed are ye.

Alma 32:9 Behold thy brother hath said, What shall we do?—for we are cast out of our synagogues, that we cannot worship our God.

Alma 32:10 Behold I say unto you, do ye suppose that ye cannot worship God save it be in your synagogues only?

Alma 32:11 And moreover, I would ask, do ye suppose that ye must not worship God only once in a week?

Alma 32:12 I say unto you, it is well that ye are cast out of your synagogues, that ye may be humble, and that ye may learn wisdom; for it is necessary that ye should learn wisdom; for it is because that ye are cast out, that ye are despised of your brethren because of your exceeding poverty, that ye are brought to a lowliness of heart; for ye are necessarily brought to be humble.

Alma 32:13 And now, because ye are compelled to be humble blessed are ye; for a man sometimes, if he is compelled to be humble, seeketh repentance; and now surely, whosoever repenteth shall find mercy; and he that findeth mercy and endureth to the end the same shall be saved.

Alma 32:14 And now, as I said unto you, that because ye were compelled to be humble ye were blessed, do ye not suppose that they are more blessed who truly humble themselves because of the word?

Alma 32:15 Yea, he that truly humbleth himself, and repenteth of his sins, and endureth to the end, the same shall be blessed—yea, much more blessed than they who are compelled to be humble because of their exceeding poverty.

Alma 32:16 Therefore, blessed are they who humble themselves without being compelled to be humble; or rather, in other words, blessed is he that believeth in the word of God, and is baptized without stubbornness of heart, yea, without being brought to know the word, or even compelled to know, before they will believe.

Alma 32:17 Yea, there are many who do say: If thou wilt show unto us a sign from heaven, then we shall know of a surety; then we shall believe.

Alma 32:18 Now I ask, is this faith? Behold, I say unto you, Nay; for if a man knoweth a thing he hath no cause to believe, for he knoweth it.

Alma 32:19 And now, how much more cursed is he that knoweth the will of God and doeth it not, than he that only believeth, or only hath cause to believe, and falleth into transgression?

Alma 32:20 Now of this thing ye must judge. Behold, I say unto you, that it is on the one hand even as it is on the other; and it shall be unto every man according to his work.

Alma 32:21 And now as I said concerning faith—faith is not to have a perfect knowledge of things; therefore if ye have faith ye hope for things which are not seen, which are true.

Alma 32:22 And now, behold, I say unto you, and I would that ye should remember, that God is merciful unto all who believe on his name; therefore he desireth, in the first place, that ye should believe, yea, even on his word.

Alma 32:23 And now, he imparteth his word by angels unto men, yea, not only men but women also. Now this is not all; little children do have words given unto them many times, which confound the wise and the learned.

Alma 32:24 And now, my beloved brethren, as ye have desired to know of me what ye shall do because ye are afflicted and cast out—now I do not desire that ye should suppose that I mean to judge you only according to that which is true—

Alma 32:25 For I do not mean that ye all of you have been compelled to humble yourselves; for I verily believe that there are some among you who would humble themselves, let them be in whatsoever circumstances they might.

Alma 32:26 Now, as I said concerning faith—that it was not a perfect knowledge—even so it is with my words. Ye cannot know of their surety at first, unto perfection, any more than faith is a perfect knowledge.

Alma 32:27 But behold, if ye will awake and arouse your faculties, even to an experiment upon my words, and exercise a particle of faith, yea, even if ye can no more than desire to believe, let this desire work in you, even until ye believe in a manner that ye can give place for a portion of my words.

Alma 32:28 Now, we will compare the word unto a seed. Now, if ye give place, that a seed may be planted in your heart, behold, if it be a true seed, or a good seed, if ye do not cast it out by your unbelief, that ye will resist the Spirit of the Lord, behold, it will begin to swell within your breasts; and when you feel these swelling motions, ye will begin to say within yourselves—It must needs be that this is a good seed, or that the word is good, for it beginneth to enlarge my soul; yea, it beginneth to enlighten my understanding, yea, it beginneth to be delicious to me.

Alma 32:29 Now behold, would not this increase your faith? I say unto you, Yea; nevertheless it hath not grown up to a perfect knowledge.

Alma 32:30 But behold, as the seed swelleth, and sprouteth, and beginneth to grow, then you must needs say that the seed is good; for behold it swelleth, and sprouteth, and beginneth to grow. And now, behold, will not this strengthen your faith? Yea, it will strengthen your faith: for ye will say I know that this is a good seed; for behold it sprouteth and beginneth to grow.

Alma 32:31 And now, behold, are ye sure that this is a good seed? I say unto you, Yea; for every seed bringeth forth unto its own likeness.

Alma 32:32 Therefore, if a seed groweth it is good, but if it groweth not, behold it is not good, therefore it is cast away.

Alma 32:33 And now, behold, because ye have tried the experiment, and planted the seed, and it swelleth and sprouteth, and beginneth to grow, ye must needs know that the seed is good.

Alma 32:34 And now, behold, is your knowledge perfect? Yea, your knowledge is perfect in that thing, and your faith is dormant; and this because you know, for ye know that the word hath swelled your souls, and ye also know that it hath sprouted up, that your understanding doth begin to be enlightened, and your mind doth begin to expand.

Alma 32:35 O then, is not this real? I say unto you, Yea, because it is light; and whatsoever is light, is good, because it is discernible, therefore ye must know that it is good; and now behold, after ye have tasted this light is your knowledge perfect?

Alma 32:36 Behold I say unto you, Nay; neither must ye lay aside your faith, for ye have only exercised your faith to plant the seed that ye might try the experiment to know if the seed was good.

Alma 32:37 And behold, as the tree beginneth to grow, ye will say: Let us nourish it with great care, that it may get root, that it may grow up, and bring forth fruit unto us. And now behold, if ye nourish it with much care it will get root, and grow up, and bring forth fruit.

Alma 32:38 But if ye neglect the tree, and take no thought for its nourishment, behold it will not get any root; and when the heat of the sun cometh and scorcheth it, because it hath no root it withers away, and ye pluck it up and cast it out.

Alma 32:39 Now, this is not because the seed was not good, neither is it because the fruit thereof would not be desirable; but it is because your ground is barren, and ye will not nourish the tree, therefore ye cannot have the fruit thereof.

Alma 32:40 And thus, if ye will not nourish the word, looking forward with an eye of faith to the fruit thereof, ye can never pluck of the fruit of the tree of life.

Alma 32:41 But if ye will nourish the word, yea, nourish the tree as it beginneth to grow, by your faith with great diligence, and with patience, looking forward to the fruit thereof, it shall take root; and behold it shall be a tree springing up unto everlasting life.

Alma 32:42 And because of your diligence and your faith and your patience with the word in nourishing it, that it may take root in you, behold, by and by ye shall pluck the fruit thereof, which is most precious, which is sweet above all that is sweet, and which is white above all that is white, yea, and pure above all that is pure; and ye shall feast upon this fruit even until ye are filled, that ye hunger not, neither shall ye thirst.

Alma 32:43 Then, my brethren, ye shall reap the rewards of your faith, and your diligence, and patience, and long-suffering, waiting for the tree to bring forth fruit unto you.
