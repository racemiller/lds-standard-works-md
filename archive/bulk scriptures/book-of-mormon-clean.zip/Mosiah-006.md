# Mosiah 6

Mosiah 6 (summary): King Benjamin records the names of the people and appoints priests to teach them—Mosiah reigns as a righteous king. About 124–121 B.C.

Mosiah 6:1 And now, king Benjamin thought it was expedient, after having finished speaking to the people, that he should take the names of all those who had entered into a covenant with God to keep his commandments.

Mosiah 6:2 And it came to pass that there was not one soul, except it were little children, but who had entered into the covenant and had taken upon them the name of Christ.

Mosiah 6:3 And again, it came to pass that when king Benjamin had made an end of all these things, and had consecrated his son Mosiah to be a ruler and a king over his people, and had given him all the charges concerning the kingdom, and also had appointed priests to teach the people, that thereby they might hear and know the commandments of God, and to stir them up in remembrance of the oath which they had made, he dismissed the multitude, and they returned, every one, according to their families, to their own houses.

Mosiah 6:4 And Mosiah began to reign in his father’s stead. And he began to reign in the thirtieth year of his age, making in the whole, about four hundred and seventy-six years from the time that Lehi left Jerusalem.

Mosiah 6:5 And king Benjamin lived three years and he died.

Mosiah 6:6 And it came to pass that king Mosiah did walk in the ways of the Lord, and did observe his judgments and his statutes, and did keep his commandments in all things whatsoever he commanded him.

Mosiah 6:7 And king Mosiah did cause his people that they should till the earth. And he also, himself, did till the earth, that thereby he might not become burdensome to his people, that he might do according to that which his father had done in all things. And there was no contention among all his people for the space of three years.
