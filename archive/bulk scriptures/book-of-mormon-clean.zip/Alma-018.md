# Alma 18

Alma 18 (summary): King Lamoni supposes that Ammon is the Great Spirit—Ammon teaches the king about the Creation, God’s dealings with men, and the redemption that comes through Christ—Lamoni believes and falls to the earth as if dead. About 90 B.C.

Alma 18:1 And it came to pass that king Lamoni caused that his servants should stand forth and testify to all the things which they had seen concerning the matter.

Alma 18:2 And when they had all testified to the things which they had seen, and he had learned of the faithfulness of Ammon in preserving his flocks, and also of his great power in contending against those who sought to slay him, he was astonished exceedingly, and said: Surely, this is more than a man. Behold, is not this the Great Spirit who doth send such great punishments upon this people, because of their murders?

Alma 18:3 And they answered the king, and said: Whether he be the Great Spirit or a man, we know not; but this much we do know, that he cannot be slain by the enemies of the king; neither can they scatter the king’s flocks when he is with us, because of his expertness and great strength; therefore, we know that he is a friend to the king. And now, O king, we do not believe that a man has such great power, for we know he cannot be slain.

Alma 18:4 And now, when the king heard these words, he said unto them: Now I know that it is the Great Spirit; and he has come down at this time to preserve your lives, that I might not slay you as I did your brethren. Now this is the Great Spirit of whom our fathers have spoken.

Alma 18:5 Now this was the tradition of Lamoni, which he had received from his father, that there was a Great Spirit. Notwithstanding they believed in a Great Spirit, they supposed that whatsoever they did was right; nevertheless, Lamoni began to fear exceedingly, with fear lest he had done wrong in slaying his servants;

Alma 18:6 For he had slain many of them because their brethren had scattered their flocks at the place of water; and thus, because they had had their flocks scattered they were slain.

Alma 18:7 Now it was the practice of these Lamanites to stand by the waters of Sebus to scatter the flocks of the people, that thereby they might drive away many that were scattered unto their own land, it being a practice of plunder among them.

Alma 18:8 And it came to pass that king Lamoni inquired of his servants, saying: Where is this man that has such great power?

Alma 18:9 And they said unto him: Behold, he is feeding thy horses. Now the king had commanded his servants, previous to the time of the watering of their flocks, that they should prepare his horses and chariots, and conduct him forth to the land of Nephi; for there had been a great feast appointed at the land of Nephi, by the father of Lamoni, who was king over all the land.

Alma 18:10 Now when king Lamoni heard that Ammon was preparing his horses and his chariots he was more astonished, because of the faithfulness of Ammon, saying: Surely there has not been any servant among all my servants that has been so faithful as this man; for even he doth remember all my commandments to execute them.

Alma 18:11 Now I surely know that this is the Great Spirit, and I would desire him that he come in unto me, but I durst not.

Alma 18:12 And it came to pass that when Ammon had made ready the horses and the chariots for the king and his servants, he went in unto the king, and he saw that the countenance of the king was changed; therefore he was about to return out of his presence.

Alma 18:13 And one of the king’s servants said unto him, Rabbanah, which is, being interpreted, powerful or great king, considering their kings to be powerful; and thus he said unto him: Rabbanah, the king desireth thee to stay.

Alma 18:14 Therefore Ammon turned himself unto the king, and said unto him: What wilt thou that I should do for thee, O king? And the king answered him not for the space of an hour, according to their time, for he knew not what he should say unto him.

Alma 18:15 And it came to pass that Ammon said unto him again: What desirest thou of me? But the king answered him not.

Alma 18:16 And it came to pass that Ammon, being filled with the Spirit of God, therefore he perceived the thoughts of the king. And he said unto him: Is it because thou hast heard that I defended thy servants and thy flocks, and slew seven of their brethren with the sling and with the sword, and smote off the arms of others, in order to defend thy flocks and thy servants; behold, is it this that causeth thy marvelings?

Alma 18:17 I say unto you, what is it, that thy marvelings are so great? Behold, I am a man, and am thy servant; therefore, whatsoever thou desirest which is right, that will I do.

Alma 18:18 Now when the king had heard these words, he marveled again, for he beheld that Ammon could discern his thoughts; but notwithstanding this, king Lamoni did open his mouth, and said unto him: Who art thou? Art thou that Great Spirit, who knows all things?

Alma 18:19 Ammon answered and said unto him: I am not.

Alma 18:20 And the king said: How knowest thou the thoughts of my heart? Thou mayest speak boldly, and tell me concerning these things; and also tell me by what power ye slew and smote off the arms of my brethren that scattered my flocks—

Alma 18:21 And now, if thou wilt tell me concerning these things, whatsoever thou desirest I will give unto thee; and if it were needed, I would guard thee with my armies; but I know that thou art more powerful than all they; nevertheless, whatsoever thou desirest of me I will grant it unto thee.

Alma 18:22 Now Ammon being wise, yet harmless, he said unto Lamoni: Wilt thou hearken unto my words, if I tell thee by what power I do these things? And this is the thing that I desire of thee.

Alma 18:23 And the king answered him, and said: Yea, I will believe all thy words. And thus he was caught with guile.

Alma 18:24 And Ammon began to speak unto him with boldness, and said unto him: Believest thou that there is a God?

Alma 18:25 And he answered, and said unto him: I do not know what that meaneth.

Alma 18:26 And then Ammon said: Believest thou that there is a Great Spirit?

Alma 18:27 And he said, Yea.

Alma 18:28 And Ammon said: This is God. And Ammon said unto him again: Believest thou that this Great Spirit, who is God, created all things which are in heaven and in the earth?

Alma 18:29 And he said: Yea, I believe that he created all things which are in the earth; but I do not know the heavens.

Alma 18:30 And Ammon said unto him: The heavens is a place where God dwells and all his holy angels.

Alma 18:31 And king Lamoni said: Is it above the earth?

Alma 18:32 And Ammon said: Yea, and he looketh down upon all the children of men; and he knows all the thoughts and intents of the heart; for by his hand were they all created from the beginning.

Alma 18:33 And king Lamoni said: I believe all these things which thou hast spoken. Art thou sent from God?

Alma 18:34 Ammon said unto him: I am a man; and man in the beginning was created after the image of God, and I am called by his Holy Spirit to teach these things unto this people, that they may be brought to a knowledge of that which is just and true;

Alma 18:35 And a portion of that Spirit dwelleth in me, which giveth me knowledge, and also power according to my faith and desires which are in God.

Alma 18:36 Now when Ammon had said these words, he began at the creation of the world, and also the creation of Adam, and told him all the things concerning the fall of man, and rehearsed and laid before him the records and the holy scriptures of the people, which had been spoken by the prophets, even down to the time that their father, Lehi, left Jerusalem.

Alma 18:37 And he also rehearsed unto them (for it was unto the king and to his servants) all the journeyings of their fathers in the wilderness, and all their sufferings with hunger and thirst, and their travail, and so forth.

Alma 18:38 And he also rehearsed unto them concerning the rebellions of Laman and Lemuel, and the sons of Ishmael, yea, all their rebellions did he relate unto them; and he expounded unto them all the records and scriptures from the time that Lehi left Jerusalem down to the present time.

Alma 18:39 But this is not all; for he expounded unto them the plan of redemption, which was prepared from the foundation of the world; and he also made known unto them concerning the coming of Christ, and all the works of the Lord did he make known unto them.

Alma 18:40 And it came to pass that after he had said all these things, and expounded them to the king, that the king believed all his words.

Alma 18:41 And he began to cry unto the Lord, saying: O Lord, have mercy; according to thy abundant mercy which thou hast had upon the people of Nephi, have upon me, and my people.

Alma 18:42 And now, when he had said this, he fell unto the earth, as if he were dead.

Alma 18:43 And it came to pass that his servants took him and carried him in unto his wife, and laid him upon a bed; and he lay as if he were dead for the space of two days and two nights; and his wife, and his sons, and his daughters mourned over him, after the manner of the Lamanites, greatly lamenting his loss.
