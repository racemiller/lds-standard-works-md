# Mosiah 10

Mosiah 10 (summary): King Laman dies—His people are wild and ferocious and believe in false traditions—Zeniff and his people prevail against them. About 187–160 B.C.

Mosiah 10:1 And it came to pass that we again began to establish the kingdom and we again began to possess the land in peace. And I caused that there should be weapons of war made of every kind, that thereby I might have weapons for my people against the time the Lamanites should come up again to war against my people.

Mosiah 10:2 And I set guards round about the land, that the Lamanites might not come upon us again unawares and destroy us; and thus I did guard my people and my flocks, and keep them from falling into the hands of our enemies.

Mosiah 10:3 And it came to pass that we did inherit the land of our fathers for many years, yea, for the space of twenty and two years.

Mosiah 10:4 And I did cause that the men should till the ground, and raise all manner of grain and all manner of fruit of every kind.

Mosiah 10:5 And I did cause that the women should spin, and toil, and work, and work all manner of fine linen, yea, and cloth of every kind, that we might clothe our nakedness; and thus we did prosper in the land—thus we did have continual peace in the land for the space of twenty and two years.

Mosiah 10:6 And it came to pass that king Laman died, and his son began to reign in his stead. And he began to stir his people up in rebellion against my people; therefore they began to prepare for war, and to come up to battle against my people.

Mosiah 10:7 But I had sent my spies out round about the land of Shemlon, that I might discover their preparations, that I might guard against them, that they might not come upon my people and destroy them.

Mosiah 10:8 And it came to pass that they came up upon the north of the land of Shilom, with their numerous hosts, men armed with bows, and with arrows, and with swords, and with cimeters, and with stones, and with slings; and they had their heads shaved that they were naked; and they were girded with a leathern girdle about their loins.

Mosiah 10:9 And it came to pass that I caused that the women and children of my people should be hid in the wilderness; and I also caused that all my old men that could bear arms, and also all my young men that were able to bear arms, should gather themselves together to go to battle against the Lamanites; and I did place them in their ranks, every man according to his age.

Mosiah 10:10 And it came to pass that we did go up to battle against the Lamanites; and I, even I, in my old age, did go up to battle against the Lamanites. And it came to pass that we did go up in the strength of the Lord to battle.

Mosiah 10:11 Now, the Lamanites knew nothing concerning the Lord, nor the strength of the Lord, therefore they depended upon their own strength. Yet they were a strong people, as to the strength of men.

Mosiah 10:12 They were a wild, and ferocious, and a blood-thirsty people, believing in the tradition of their fathers, which is this—Believing that they were driven out of the land of Jerusalem because of the iniquities of their fathers, and that they were wronged in the wilderness by their brethren, and they were also wronged while crossing the sea;

Mosiah 10:13 And again, that they were wronged while in the land of their first inheritance, after they had crossed the sea, and all this because that Nephi was more faithful in keeping the commandments of the Lord—therefore he was favored of the Lord, for the Lord heard his prayers and answered them, and he took the lead of their journey in the wilderness.

Mosiah 10:14 And his brethren were wroth with him because they understood not the dealings of the Lord; they were also wroth with him upon the waters because they hardened their hearts against the Lord.

Mosiah 10:15 And again, they were wroth with him when they had arrived in the promised land, because they said that he had taken the ruling of the people out of their hands; and they sought to kill him.

Mosiah 10:16 And again, they were wroth with him because he departed into the wilderness as the Lord had commanded him, and took the records which were engraven on the plates of brass, for they said that he robbed them.

Mosiah 10:17 And thus they have taught their children that they should hate them, and that they should murder them, and that they should rob and plunder them, and do all they could to destroy them; therefore they have an eternal hatred towards the children of Nephi.

Mosiah 10:18 For this very cause has king Laman, by his cunning, and lying craftiness, and his fair promises, deceived me, that I have brought this my people up into this land, that they may destroy them; yea, and we have suffered these many years in the land.

Mosiah 10:19 And now I, Zeniff, after having told all these things unto my people concerning the Lamanites, I did stimulate them to go to battle with their might, putting their trust in the Lord; therefore, we did contend with them, face to face.

Mosiah 10:20 And it came to pass that we did drive them again out of our land; and we slew them with a great slaughter, even so many that we did not number them.

Mosiah 10:21 And it came to pass that we returned again to our own land, and my people again began to tend their flocks, and to till their ground.

Mosiah 10:22 And now I, being old, did confer the kingdom upon one of my sons; therefore, I say no more. And may the Lord bless my people. Amen.
