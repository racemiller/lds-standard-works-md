# 3 Nephi 1

3 Nephi 1 (summary): Nephi, the son of Helaman, departs out of the land, and his son Nephi keeps the records—Though signs and wonders abound, the wicked plan to slay the righteous—The night of Christ’s birth arrives—The sign is given, and a new star arises—Lyings and deceivings increase, and the Gadianton robbers slaughter many. About A.D. 1–4.

3 Nephi 1:1 Now it came to pass that the ninety and first year had passed away and it was six hundred years from the time that Lehi left Jerusalem; and it was in the year that Lachoneus was the chief judge and the governor over the land.

3 Nephi 1:2 And Nephi, the son of Helaman, had departed out of the land of Zarahemla, giving charge unto his son Nephi, who was his eldest son, concerning the plates of brass, and all the records which had been kept, and all those things which had been kept sacred from the departure of Lehi out of Jerusalem.

3 Nephi 1:3 Then he departed out of the land, and whither he went, no man knoweth; and his son Nephi did keep the records in his stead, yea, the record of this people.

3 Nephi 1:4 And it came to pass that in the commencement of the ninety and second year, behold, the prophecies of the prophets began to be fulfilled more fully; for there began to be greater signs and greater miracles wrought among the people.

3 Nephi 1:5 But there were some who began to say that the time was past for the words to be fulfilled, which were spoken by Samuel, the Lamanite.

3 Nephi 1:6 And they began to rejoice over their brethren, saying: Behold the time is past, and the words of Samuel are not fulfilled; therefore, your joy and your faith concerning this thing hath been vain.

3 Nephi 1:7 And it came to pass that they did make a great uproar throughout the land; and the people who believed began to be very sorrowful, lest by any means those things which had been spoken might not come to pass.

3 Nephi 1:8 But behold, they did watch steadfastly for that day and that night and that day which should be as one day as if there were no night, that they might know that their faith had not been vain.

3 Nephi 1:9 Now it came to pass that there was a day set apart by the unbelievers, that all those who believed in those traditions should be put to death except the sign should come to pass, which had been given by Samuel the prophet.

3 Nephi 1:10 Now it came to pass that when Nephi, the son of Nephi, saw this wickedness of his people, his heart was exceedingly sorrowful.

3 Nephi 1:11 And it came to pass that he went out and bowed himself down upon the earth, and cried mightily to his God in behalf of his people, yea, those who were about to be destroyed because of their faith in the tradition of their fathers.

3 Nephi 1:12 And it came to pass that he cried mightily unto the Lord all that day; and behold, the voice of the Lord came unto him, saying:

3 Nephi 1:13 Lift up your head and be of good cheer; for behold, the time is at hand, and on this night shall the sign be given, and on the morrow come I into the world, to show unto the world that I will fulfil all that which I have caused to be spoken by the mouth of my holy prophets.

3 Nephi 1:14 Behold, I come unto my own, to fulfil all things which I have made known unto the children of men from the foundation of the world, and to do the will, both of the Father and of the Son—of the Father because of me, and of the Son because of my flesh. And behold, the time is at hand, and this night shall the sign be given.

3 Nephi 1:15 And it came to pass that the words which came unto Nephi were fulfilled, according as they had been spoken; for behold, at the going down of the sun there was no darkness; and the people began to be astonished because there was no darkness when the night came.

3 Nephi 1:16 And there were many, who had not believed the words of the prophets, who fell to the earth and became as if they were dead, for they knew that the great plan of destruction which they had laid for those who believed in the words of the prophets had been frustrated; for the sign which had been given was already at hand.

3 Nephi 1:17 And they began to know that the Son of God must shortly appear; yea, in fine, all the people upon the face of the whole earth from the west to the east, both in the land north and in the land south, were so exceedingly astonished that they fell to the earth.

3 Nephi 1:18 For they knew that the prophets had testified of these things for many years, and that the sign which had been given was already at hand; and they began to fear because of their iniquity and their unbelief.

3 Nephi 1:19 And it came to pass that there was no darkness in all that night, but it was as light as though it was mid-day. And it came to pass that the sun did rise in the morning again, according to its proper order; and they knew that it was the day that the Lord should be born, because of the sign which had been given.

3 Nephi 1:20 And it had come to pass, yea, all things, every whit, according to the words of the prophets.

3 Nephi 1:21 And it came to pass also that a new star did appear, according to the word.

3 Nephi 1:22 And it came to pass that from this time forth there began to be lyings sent forth among the people, by Satan, to harden their hearts, to the intent that they might not believe in those signs and wonders which they had seen; but notwithstanding these lyings and deceivings the more part of the people did believe, and were converted unto the Lord.

3 Nephi 1:23 And it came to pass that Nephi went forth among the people, and also many others, baptizing unto repentance, in the which there was a great remission of sins. And thus the people began again to have peace in the land.

3 Nephi 1:24 And there were no contentions, save it were a few that began to preach, endeavoring to prove by the scriptures that it was no more expedient to observe the law of Moses. Now in this thing they did err, having not understood the scriptures.

3 Nephi 1:25 But it came to pass that they soon became converted, and were convinced of the error which they were in, for it was made known unto them that the law was not yet fulfilled, and that it must be fulfilled in every whit; yea, the word came unto them that it must be fulfilled; yea, that one jot or tittle should not pass away till it should all be fulfilled; therefore in this same year were they brought to a knowledge of their error and did confess their faults.

3 Nephi 1:26 And thus the ninety and second year did pass away, bringing glad tidings unto the people because of the signs which did come to pass, according to the words of the prophecy of all the holy prophets.

3 Nephi 1:27 And it came to pass that the ninety and third year did also pass away in peace, save it were for the Gadianton robbers, who dwelt upon the mountains, who did infest the land; for so strong were their holds and their secret places that the people could not overpower them; therefore they did commit many murders, and did do much slaughter among the people.

3 Nephi 1:28 And it came to pass that in the ninety and fourth year they began to increase in a great degree, because there were many dissenters of the Nephites who did flee unto them, which did cause much sorrow unto those Nephites who did remain in the land.

3 Nephi 1:29 And there was also a cause of much sorrow among the Lamanites; for behold, they had many children who did grow up and began to wax strong in years, that they became for themselves, and were led away by some who were Zoramites, by their lyings and their flattering words, to join those Gadianton robbers.

3 Nephi 1:30 And thus were the Lamanites afflicted also, and began to decrease as to their faith and righteousness, because of the wickedness of the rising generation.
