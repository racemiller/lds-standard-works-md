# Helaman 7

Helaman 7 (summary): Nephi is rejected in the north and returns to Zarahemla—He prays upon his garden tower and then calls upon the people to repent or perish. About 23–21 B.C.

Helaman 7:1 Behold, now it came to pass in the sixty and ninth year of the reign of the judges over the people of the Nephites, that Nephi, the son of Helaman, returned to the land of Zarahemla from the land northward.

Helaman 7:2 For he had been forth among the people who were in the land northward, and did preach the word of God unto them, and did prophesy many things unto them;

Helaman 7:3 And they did reject all his words, insomuch that he could not stay among them, but returned again unto the land of his nativity.

Helaman 7:4 And seeing the people in a state of such awful wickedness, and those Gadianton robbers filling the judgment-seats—having usurped the power and authority of the land; laying aside the commandments of God, and not in the least aright before him; doing no justice unto the children of men;

Helaman 7:5 Condemning the righteous because of their righteousness; letting the guilty and the wicked go unpunished because of their money; and moreover to be held in office at the head of government, to rule and do according to their wills, that they might get gain and glory of the world, and, moreover, that they might the more easily commit adultery, and steal, and kill, and do according to their own wills—

Helaman 7:6 Now this great iniquity had come upon the Nephites, in the space of not many years; and when Nephi saw it, his heart was swollen with sorrow within his breast; and he did exclaim in the agony of his soul:

Helaman 7:7 Oh, that I could have had my days in the days when my father Nephi first came out of the land of Jerusalem, that I could have joyed with him in the promised land; then were his people easy to be entreated, firm to keep the commandments of God, and slow to be led to do iniquity; and they were quick to hearken unto the words of the Lord—

Helaman 7:8 Yea, if my days could have been in those days, then would my soul have had joy in the righteousness of my brethren.

Helaman 7:9 But behold, I am consigned that these are my days, and that my soul shall be filled with sorrow because of this the wickedness of my brethren.

Helaman 7:10 And behold, now it came to pass that it was upon a tower, which was in the garden of Nephi, which was by the highway which led to the chief market, which was in the city of Zarahemla; therefore, Nephi had bowed himself upon the tower which was in his garden, which tower was also near unto the garden gate by which led the highway.

Helaman 7:11 And it came to pass that there were certain men passing by and saw Nephi as he was pouring out his soul unto God upon the tower; and they ran and told the people what they had seen, and the people came together in multitudes that they might know the cause of so great mourning for the wickedness of the people.

Helaman 7:12 And now, when Nephi arose he beheld the multitudes of people who had gathered together.

Helaman 7:13 And it came to pass that he opened his mouth and said unto them: Behold, why have ye gathered yourselves together? That I may tell you of your iniquities?

Helaman 7:14 Yea, because I have got upon my tower that I might pour out my soul unto my God, because of the exceeding sorrow of my heart, which is because of your iniquities!

Helaman 7:15 And because of my mourning and lamentation ye have gathered yourselves together, and do marvel; yea, and ye have great need to marvel; yea, ye ought to marvel because ye are given away that the devil has got so great hold upon your hearts.

Helaman 7:16 Yea, how could you have given way to the enticing of him who is seeking to hurl away your souls down to everlasting misery and endless wo?

Helaman 7:17 O repent ye, repent ye! Why will ye die? Turn ye, turn ye unto the Lord your God. Why has he forsaken you?

Helaman 7:18 It is because you have hardened your hearts; yea, ye will not hearken unto the voice of the good shepherd; yea, ye have provoked him to anger against you.

Helaman 7:19 And behold, instead of gathering you, except ye will repent, behold, he shall scatter you forth that ye shall become meat for dogs and wild beasts.

Helaman 7:20 O, how could you have forgotten your God in the very day that he has delivered you?

Helaman 7:21 But behold, it is to get gain, to be praised of men, yea, and that ye might get gold and silver. And ye have set your hearts upon the riches and the vain things of this world, for the which ye do murder, and plunder, and steal, and bear false witness against your neighbor, and do all manner of iniquity.

Helaman 7:22 And for this cause wo shall come unto you except ye shall repent. For if ye will not repent, behold, this great city, and also all those great cities which are round about, which are in the land of our possession, shall be taken away that ye shall have no place in them; for behold, the Lord will not grant unto you strength, as he has hitherto done, to withstand against your enemies.

Helaman 7:23 For behold, thus saith the Lord: I will not show unto the wicked of my strength, to one more than the other, save it be unto those who repent of their sins, and hearken unto my words. Now therefore, I would that ye should behold, my brethren, that it shall be better for the Lamanites than for you except ye shall repent.

Helaman 7:24 For behold, they are more righteous than you, for they have not sinned against that great knowledge which ye have received; therefore the Lord will be merciful unto them; yea, he will lengthen out their days and increase their seed, even when thou shalt be utterly destroyed except thou shalt repent.

Helaman 7:25 Yea, wo be unto you because of that great abomination which has come among you; and ye have united yourselves unto it, yea, to that secret band which was established by Gadianton!

Helaman 7:26 Yea, wo shall come unto you because of that pride which ye have suffered to enter your hearts, which has lifted you up beyond that which is good because of your exceedingly great riches!

Helaman 7:27 Yea, wo be unto you because of your wickedness and abominations!

Helaman 7:28 And except ye repent ye shall perish; yea, even your lands shall be taken from you, and ye shall be destroyed from off the face of the earth.

Helaman 7:29 Behold now, I do not say that these things shall be, of myself, because it is not of myself that I know these things; but behold, I know that these things are true because the Lord God has made them known unto me, therefore I testify that they shall be.
