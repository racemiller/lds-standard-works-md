# Alma 15

Alma 15 (summary): Alma and Amulek go to Sidom and establish a church—Alma heals Zeezrom, who joins the Church—Many are baptized, and the Church prospers—Alma and Amulek go to Zarahemla. About 81 B.C.

Alma 15:1 And it came to pass that Alma and Amulek were commanded to depart out of that city; and they departed, and came out even into the land of Sidom; and behold, there they found all the people who had departed out of the land of Ammonihah, who had been cast out and stoned, because they believed in the words of Alma.

Alma 15:2 And they related unto them all that had happened unto their wives and children, and also concerning themselves, and of their power of deliverance.

Alma 15:3 And also Zeezrom lay sick at Sidom, with a burning fever, which was caused by the great tribulations of his mind on account of his wickedness, for he supposed that Alma and Amulek were no more; and he supposed that they had been slain because of his iniquity. And this great sin, and his many other sins, did harrow up his mind until it did become exceedingly sore, having no deliverance; therefore he began to be scorched with a burning heat.

Alma 15:4 Now, when he heard that Alma and Amulek were in the land of Sidom, his heart began to take courage; and he sent a message immediately unto them, desiring them to come unto him.

Alma 15:5 And it came to pass that they went immediately, obeying the message which he had sent unto them; and they went in unto the house unto Zeezrom; and they found him upon his bed, sick, being very low with a burning fever; and his mind also was exceedingly sore because of his iniquities; and when he saw them he stretched forth his hand, and besought them that they would heal him.

Alma 15:6 And it came to pass that Alma said unto him, taking him by the hand: Believest thou in the power of Christ unto salvation?

Alma 15:7 And he answered and said: Yea, I believe all the words that thou hast taught.

Alma 15:8 And Alma said: If thou believest in the redemption of Christ thou canst be healed.

Alma 15:9 And he said: Yea, I believe according to thy words.

Alma 15:10 And then Alma cried unto the Lord, saying: O Lord our God, have mercy on this man, and heal him according to his faith which is in Christ.

Alma 15:11 And when Alma had said these words, Zeezrom leaped upon his feet, and began to walk; and this was done to the great astonishment of all the people; and the knowledge of this went forth throughout all the land of Sidom.

Alma 15:12 And Alma baptized Zeezrom unto the Lord; and he began from that time forth to preach unto the people.

Alma 15:13 And Alma established a church in the land of Sidom, and consecrated priests and teachers in the land, to baptize unto the Lord whosoever were desirous to be baptized.

Alma 15:14 And it came to pass that they were many; for they did flock in from all the region round about Sidom, and were baptized.

Alma 15:15 But as to the people that were in the land of Ammonihah, they yet remained a hard-hearted and a stiffnecked people; and they repented not of their sins, ascribing all the power of Alma and Amulek to the devil; for they were of the profession of Nehor, and did not believe in the repentance of their sins.

Alma 15:16 And it came to pass that Alma and Amulek, Amulek having forsaken all his gold, and silver, and his precious things, which were in the land of Ammonihah, for the word of God, he being rejected by those who were once his friends and also by his father and his kindred;

Alma 15:17 Therefore, after Alma having established the church at Sidom, seeing a great check, yea, seeing that the people were checked as to the pride of their hearts, and began to humble themselves before God, and began to assemble themselves together at their sanctuaries to worship God before the altar, watching and praying continually, that they might be delivered from Satan, and from death, and from destruction—

Alma 15:18 Now as I said, Alma having seen all these things, therefore he took Amulek and came over to the land of Zarahemla, and took him to his own house, and did administer unto him in his tribulations, and strengthened him in the Lord.

Alma 15:19 And thus ended the tenth year of the reign of the judges over the people of Nephi.
