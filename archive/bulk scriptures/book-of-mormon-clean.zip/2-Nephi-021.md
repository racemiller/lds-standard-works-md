# 2 Nephi 21

2 Nephi 21 (summary): The stem of Jesse (Christ) will judge in righteousness—The knowledge of God will cover the earth in the Millennium—The Lord will raise an ensign and gather Israel—Compare Isaiah 11. About 559–545 B.C.

2 Nephi 21:1 And there shall come forth a rod out of the stem of Jesse, and a branch shall grow out of his roots.

2 Nephi 21:2 And the Spirit of the Lord shall rest upon him, the spirit of wisdom and understanding, the spirit of counsel and might, the spirit of knowledge and of the fear of the Lord;

2 Nephi 21:3 And shall make him of quick understanding in the fear of the Lord; and he shall not judge after the sight of his eyes, neither reprove after the hearing of his ears.

2 Nephi 21:4 But with righteousness shall he judge the poor, and reprove with equity for the meek of the earth; and he shall smite the earth with the rod of his mouth, and with the breath of his lips shall he slay the wicked.

2 Nephi 21:5 And righteousness shall be the girdle of his loins, and faithfulness the girdle of his reins.

2 Nephi 21:6 The wolf also shall dwell with the lamb, and the leopard shall lie down with the kid, and the calf and the young lion and fatling together; and a little child shall lead them.

2 Nephi 21:7 And the cow and the bear shall feed; their young ones shall lie down together; and the lion shall eat straw like the ox.

2 Nephi 21:8 And the sucking child shall play on the hole of the asp, and the weaned child shall put his hand on the cockatrice’s den.

2 Nephi 21:9 They shall not hurt nor destroy in all my holy mountain, for the earth shall be full of the knowledge of the Lord, as the waters cover the sea.

2 Nephi 21:10 And in that day there shall be a root of Jesse, which shall stand for an ensign of the people; to it shall the Gentiles seek; and his rest shall be glorious.

2 Nephi 21:11 And it shall come to pass in that day that the Lord shall set his hand again the second time to recover the remnant of his people which shall be left, from Assyria, and from Egypt, and from Pathros, and from Cush, and from Elam, and from Shinar, and from Hamath, and from the islands of the sea.

2 Nephi 21:12 And he shall set up an ensign for the nations, and shall assemble the outcasts of Israel, and gather together the dispersed of Judah from the four corners of the earth.

2 Nephi 21:13 The envy of Ephraim also shall depart, and the adversaries of Judah shall be cut off; Ephraim shall not envy Judah, and Judah shall not vex Ephraim.

2 Nephi 21:14 But they shall fly upon the shoulders of the Philistines towards the west; they shall spoil them of the east together; they shall lay their hand upon Edom and Moab; and the children of Ammon shall obey them.

2 Nephi 21:15 And the Lord shall utterly destroy the tongue of the Egyptian sea; and with his mighty wind he shall shake his hand over the river, and shall smite it in the seven streams, and make men go over dry shod.

2 Nephi 21:16 And there shall be a highway for the remnant of his people which shall be left, from Assyria, like as it was to Israel in the day that he came up out of the land of Egypt.
