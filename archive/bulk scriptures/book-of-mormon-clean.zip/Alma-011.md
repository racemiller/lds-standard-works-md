# Alma 11

Alma 11 (summary): The Nephite monetary system is set forth—Amulek contends with Zeezrom—Christ will not save people in their sins—Only those who inherit the kingdom of heaven are saved—All men will rise in immortality—There is no death after the Resurrection. About 82 B.C.

Alma 11:1 Now it was in the law of Mosiah that every man who was a judge of the law, or those who were appointed to be judges, should receive wages according to the time which they labored to judge those who were brought before them to be judged.

Alma 11:2 Now if a man owed another, and he would not pay that which he did owe, he was complained of to the judge; and the judge executed authority, and sent forth officers that the man should be brought before him; and he judged the man according to the law and the evidences which were brought against him, and thus the man was compelled to pay that which he owed, or be stripped, or be cast out from among the people as a thief and a robber.

Alma 11:3 And the judge received for his wages according to his time—a senine of gold for a day, or a senum of silver, which is equal to a senine of gold; and this is according to the law which was given.

Alma 11:4 Now these are the names of the different pieces of their gold, and of their silver, according to their value. And the names are given by the Nephites, for they did not reckon after the manner of the Jews who were at Jerusalem; neither did they measure after the manner of the Jews; but they altered their reckoning and their measure, according to the minds and the circumstances of the people, in every generation, until the reign of the judges, they having been established by king Mosiah.

Alma 11:5 Now the reckoning is thus—a senine of gold, a seon of gold, a shum of gold, and a limnah of gold.

Alma 11:6 A senum of silver, an amnor of silver, an ezrom of silver, and an onti of silver.

Alma 11:7 A senum of silver was equal to a senine of gold, and either for a measure of barley, and also for a measure of every kind of grain.

Alma 11:8 Now the amount of a seon of gold was twice the value of a senine.

Alma 11:9 And a shum of gold was twice the value of a seon.

Alma 11:10 And a limnah of gold was the value of them all.

Alma 11:11 And an amnor of silver was as great as two senums.

Alma 11:12 And an ezrom of silver was as great as four senums.

Alma 11:13 And an onti was as great as them all.

Alma 11:14 Now this is the value of the lesser numbers of their reckoning—

Alma 11:15 A shiblon is half of a senum; therefore, a shiblon for half a measure of barley.

Alma 11:16 And a shiblum is a half of a shiblon.

Alma 11:17 And a leah is the half of a shiblum.

Alma 11:18 Now this is their number, according to their reckoning.

Alma 11:19 Now an antion of gold is equal to three shiblons.

Alma 11:20 Now, it was for the sole purpose to get gain, because they received their wages according to their employ, therefore, they did stir up the people to riotings, and all manner of disturbances and wickedness, that they might have more employ, that they might get money according to the suits which were brought before them; therefore they did stir up the people against Alma and Amulek.

Alma 11:21 And this Zeezrom began to question Amulek, saying: Will ye answer me a few questions which I shall ask you? Now Zeezrom was a man who was expert in the devices of the devil, that he might destroy that which was good; therefore, he said unto Amulek: Will ye answer the questions which I shall put unto you?

Alma 11:22 And Amulek said unto him: Yea, if it be according to the Spirit of the Lord, which is in me; for I shall say nothing which is contrary to the Spirit of the Lord. And Zeezrom said unto him: Behold, here are six onties of silver, and all these will I give thee if thou wilt deny the existence of a Supreme Being.

Alma 11:23 Now Amulek said: O thou child of hell, why tempt ye me? Knowest thou that the righteous yieldeth to no such temptations?

Alma 11:24 Believest thou that there is no God? I say unto you, Nay, thou knowest that there is a God, but thou lovest that lucre more than him.

Alma 11:25 And now thou hast lied before God unto me. Thou saidst unto me—Behold these six onties, which are of great worth, I will give unto thee—when thou hadst it in thy heart to retain them from me; and it was only thy desire that I should deny the true and living God, that thou mightest have cause to destroy me. And now behold, for this great evil thou shalt have thy reward.

Alma 11:26 And Zeezrom said unto him: Thou sayest there is a true and living God?

Alma 11:27 And Amulek said: Yea, there is a true and living God.

Alma 11:28 Now Zeezrom said: Is there more than one God?

Alma 11:29 And he answered, No.

Alma 11:30 Now Zeezrom said unto him again: How knowest thou these things?

Alma 11:31 And he said: An angel hath made them known unto me.

Alma 11:32 And Zeezrom said again: Who is he that shall come? Is it the Son of God?

Alma 11:33 And he said unto him, Yea.

Alma 11:34 And Zeezrom said again: Shall he save his people in their sins? And Amulek answered and said unto him: I say unto you he shall not, for it is impossible for him to deny his word.

Alma 11:35 Now Zeezrom said unto the people: See that ye remember these things; for he said there is but one God; yet he saith that the Son of God shall come, but he shall not save his people—as though he had authority to command God.

Alma 11:36 Now Amulek saith again unto him: Behold thou hast lied, for thou sayest that I spake as though I had authority to command God because I said he shall not save his people in their sins.

Alma 11:37 And I say unto you again that he cannot save them in their sins; for I cannot deny his word, and he hath said that no unclean thing can inherit the kingdom of heaven; therefore, how can ye be saved, except ye inherit the kingdom of heaven? Therefore, ye cannot be saved in your sins.

Alma 11:38 Now Zeezrom saith again unto him: Is the Son of God the very Eternal Father?

Alma 11:39 And Amulek said unto him: Yea, he is the very Eternal Father of heaven and of earth, and all things which in them are; he is the beginning and the end, the first and the last;

Alma 11:40 And he shall come into the world to redeem his people; and he shall take upon him the transgressions of those who believe on his name; and these are they that shall have eternal life, and salvation cometh to none else.

Alma 11:41 Therefore the wicked remain as though there had been no redemption made, except it be the loosing of the bands of death; for behold, the day cometh that all shall rise from the dead and stand before God, and be judged according to their works.

Alma 11:42 Now, there is a death which is called a temporal death; and the death of Christ shall loose the bands of this temporal death, that all shall be raised from this temporal death.

Alma 11:43 The spirit and the body shall be reunited again in its perfect form; both limb and joint shall be restored to its proper frame, even as we now are at this time; and we shall be brought to stand before God, knowing even as we know now, and have a bright recollection of all our guilt.

Alma 11:44 Now, this restoration shall come to all, both old and young, both bond and free, both male and female, both the wicked and the righteous; and even there shall not so much as a hair of their heads be lost; but every thing shall be restored to its perfect frame, as it is now, or in the body, and shall be brought and be arraigned before the bar of Christ the Son, and God the Father, and the Holy Spirit, which is one Eternal God, to be judged according to their works, whether they be good or whether they be evil.

Alma 11:45 Now, behold, I have spoken unto you concerning the death of the mortal body, and also concerning the resurrection of the mortal body. I say unto you that this mortal body is raised to an immortal body, that is from death, even from the first death unto life, that they can die no more; their spirits uniting with their bodies, never to be divided; thus the whole becoming spiritual and immortal, that they can no more see corruption.

Alma 11:46 Now, when Amulek had finished these words the people began again to be astonished, and also Zeezrom began to tremble. And thus ended the words of Amulek, or this is all that I have written.
