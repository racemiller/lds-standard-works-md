# Mosiah 18

Mosiah 18 (summary): Alma preaches in private—He sets forth the covenant of baptism and baptizes at the waters of Mormon—He organizes the Church of Christ and ordains priests—They support themselves and teach the people—Alma and his people flee from King Noah into the wilderness. About 147–145 B.C.

Mosiah 18:1 And now, it came to pass that Alma, who had fled from the servants of king Noah, repented of his sins and iniquities, and went about privately among the people, and began to teach the words of Abinadi—

Mosiah 18:2 Yea, concerning that which was to come, and also concerning the resurrection of the dead, and the redemption of the people, which was to be brought to pass through the power, and sufferings, and death of Christ, and his resurrection and ascension into heaven.

Mosiah 18:3 And as many as would hear his word he did teach. And he taught them privately, that it might not come to the knowledge of the king. And many did believe his words.

Mosiah 18:4 And it came to pass that as many as did believe him did go forth to a place which was called Mormon, having received its name from the king, being in the borders of the land having been infested, by times or at seasons, by wild beasts.

Mosiah 18:5 Now, there was in Mormon a fountain of pure water, and Alma resorted thither, there being near the water a thicket of small trees, where he did hide himself in the daytime from the searches of the king.

Mosiah 18:6 And it came to pass that as many as believed him went thither to hear his words.

Mosiah 18:7 And it came to pass after many days there were a goodly number gathered together at the place of Mormon, to hear the words of Alma. Yea, all were gathered together that believed on his word, to hear him. And he did teach them, and did preach unto them repentance, and redemption, and faith on the Lord.

Mosiah 18:8 And it came to pass that he said unto them: Behold, here are the waters of Mormon (for thus were they called) and now, as ye are desirous to come into the fold of God, and to be called his people, and are willing to bear one another’s burdens, that they may be light;

Mosiah 18:9 Yea, and are willing to mourn with those that mourn; yea, and comfort those that stand in need of comfort, and to stand as witnesses of God at all times and in all things, and in all places that ye may be in, even until death, that ye may be redeemed of God, and be numbered with those of the first resurrection, that ye may have eternal life—

Mosiah 18:10 Now I say unto you, if this be the desire of your hearts, what have you against being baptized in the name of the Lord, as a witness before him that ye have entered into a covenant with him, that ye will serve him and keep his commandments, that he may pour out his Spirit more abundantly upon you?

Mosiah 18:11 And now when the people had heard these words, they clapped their hands for joy, and exclaimed: This is the desire of our hearts.

Mosiah 18:12 And now it came to pass that Alma took Helam, he being one of the first, and went and stood forth in the water, and cried, saying: O Lord, pour out thy Spirit upon thy servant, that he may do this work with holiness of heart.

Mosiah 18:13 And when he had said these words, the Spirit of the Lord was upon him, and he said: Helam, I baptize thee, having authority from the Almighty God, as a testimony that ye have entered into a covenant to serve him until you are dead as to the mortal body; and may the Spirit of the Lord be poured out upon you; and may he grant unto you eternal life, through the redemption of Christ, whom he has prepared from the foundation of the world.

Mosiah 18:14 And after Alma had said these words, both Alma and Helam were buried in the water; and they arose and came forth out of the water rejoicing, being filled with the Spirit.

Mosiah 18:15 And again, Alma took another, and went forth a second time into the water, and baptized him according to the first, only he did not bury himself again in the water.

Mosiah 18:16 And after this manner he did baptize every one that went forth to the place of Mormon; and they were in number about two hundred and four souls; yea, and they were baptized in the waters of Mormon, and were filled with the grace of God.

Mosiah 18:17 And they were called the church of God, or the church of Christ, from that time forward. And it came to pass that whosoever was baptized by the power and authority of God was added to his church.

Mosiah 18:18 And it came to pass that Alma, having authority from God, ordained priests; even one priest to every fifty of their number did he ordain to preach unto them, and to teach them concerning the things pertaining to the kingdom of God.

Mosiah 18:19 And he commanded them that they should teach nothing save it were the things which he had taught, and which had been spoken by the mouth of the holy prophets.

Mosiah 18:20 Yea, even he commanded them that they should preach nothing save it were repentance and faith on the Lord, who had redeemed his people.

Mosiah 18:21 And he commanded them that there should be no contention one with another, but that they should look forward with one eye, having one faith and one baptism, having their hearts knit together in unity and in love one towards another.

Mosiah 18:22 And thus he commanded them to preach. And thus they became the children of God.

Mosiah 18:23 And he commanded them that they should observe the sabbath day, and keep it holy, and also every day they should give thanks to the Lord their God.

Mosiah 18:24 And he also commanded them that the priests whom he had ordained should labor with their own hands for their support.

Mosiah 18:25 And there was one day in every week that was set apart that they should gather themselves together to teach the people, and to worship the Lord their God, and also, as often as it was in their power, to assemble themselves together.

Mosiah 18:26 And the priests were not to depend upon the people for their support; but for their labor they were to receive the grace of God, that they might wax strong in the Spirit, having the knowledge of God, that they might teach with power and authority from God.

Mosiah 18:27 And again Alma commanded that the people of the church should impart of their substance, every one according to that which he had; if he have more abundantly he should impart more abundantly; and of him that had but little, but little should be required; and to him that had not should be given.

Mosiah 18:28 And thus they should impart of their substance of their own free will and good desires towards God, and to those priests that stood in need, yea, and to every needy, naked soul.

Mosiah 18:29 And this he said unto them, having been commanded of God; and they did walk uprightly before God, imparting to one another both temporally and spiritually according to their needs and their wants.

Mosiah 18:30 And now it came to pass that all this was done in Mormon, yea, by the waters of Mormon, in the forest that was near the waters of Mormon; yea, the place of Mormon, the waters of Mormon, the forest of Mormon, how beautiful are they to the eyes of them who there came to the knowledge of their Redeemer; yea, and how blessed are they, for they shall sing to his praise forever.

Mosiah 18:31 And these things were done in the borders of the land, that they might not come to the knowledge of the king.

Mosiah 18:32 But behold, it came to pass that the king, having discovered a movement among the people, sent his servants to watch them. Therefore on the day that they were assembling themselves together to hear the word of the Lord they were discovered unto the king.

Mosiah 18:33 And now the king said that Alma was stirring up the people to rebellion against him; therefore he sent his army to destroy them.

Mosiah 18:34 And it came to pass that Alma and the people of the Lord were apprised of the coming of the king’s army; therefore they took their tents and their families and departed into the wilderness.

Mosiah 18:35 And they were in number about four hundred and fifty souls.
