# 2 Nephi 9

2 Nephi 9 (summary): Jacob explains that the Jews will be gathered in all their lands of promise—The Atonement ransoms man from the Fall—The bodies of the dead will come forth from the grave, and their spirits from hell and from paradise—They will be judged—The Atonement saves from death, hell, the devil, and endless torment—The righteous are to be saved in the kingdom of God—Penalties for sins are set forth—The Holy One of Israel is the keeper of the gate. About 559–545 B.C.

2 Nephi 9:1 And now, my beloved brethren, I have read these things that ye might know concerning the covenants of the Lord that he has covenanted with all the house of Israel—

2 Nephi 9:2 That he has spoken unto the Jews, by the mouth of his holy prophets, even from the beginning down, from generation to generation, until the time comes that they shall be restored to the true church and fold of God; when they shall be gathered home to the lands of their inheritance, and shall be established in all their lands of promise.

2 Nephi 9:3 Behold, my beloved brethren, I speak unto you these things that ye may rejoice, and lift up your heads forever, because of the blessings which the Lord God shall bestow upon your children.

2 Nephi 9:4 For I know that ye have searched much, many of you, to know of things to come; wherefore I know that ye know that our flesh must waste away and die; nevertheless, in our bodies we shall see God.

2 Nephi 9:5 Yea, I know that ye know that in the body he shall show himself unto those at Jerusalem, from whence we came; for it is expedient that it should be among them; for it behooveth the great Creator that he suffereth himself to become subject unto man in the flesh, and die for all men, that all men might become subject unto him.

2 Nephi 9:6 For as death hath passed upon all men, to fulfil the merciful plan of the great Creator, there must needs be a power of resurrection, and the resurrection must needs come unto man by reason of the fall; and the fall came by reason of transgression; and because man became fallen they were cut off from the presence of the Lord.

2 Nephi 9:7 Wherefore, it must needs be an infinite atonement—save it should be an infinite atonement this corruption could not put on incorruption. Wherefore, the first judgment which came upon man must needs have remained to an endless duration. And if so, this flesh must have laid down to rot and to crumble to its mother earth, to rise no more.

2 Nephi 9:8 O the wisdom of God, his mercy and grace! For behold, if the flesh should rise no more our spirits must become subject to that angel who fell from before the presence of the Eternal God, and became the devil, to rise no more.

2 Nephi 9:9 And our spirits must have become like unto him, and we become devils, angels to a devil, to be shut out from the presence of our God, and to remain with the father of lies, in misery, like unto himself; yea, to that being who beguiled our first parents, who transformeth himself nigh unto an angel of light, and stirreth up the children of men unto secret combinations of murder and all manner of secret works of darkness.

2 Nephi 9:10 O how great the goodness of our God, who prepareth a way for our escape from the grasp of this awful monster; yea, that monster, death and hell, which I call the death of the body, and also the death of the spirit.

2 Nephi 9:11 And because of the way of deliverance of our God, the Holy One of Israel, this death, of which I have spoken, which is the temporal, shall deliver up its dead; which death is the grave.

2 Nephi 9:12 And this death of which I have spoken, which is the spiritual death, shall deliver up its dead; which spiritual death is hell; wherefore, death and hell must deliver up their dead, and hell must deliver up its captive spirits, and the grave must deliver up its captive bodies, and the bodies and the spirits of men will be restored one to the other; and it is by the power of the resurrection of the Holy One of Israel.

2 Nephi 9:13 O how great the plan of our God! For on the other hand, the paradise of God must deliver up the spirits of the righteous, and the grave deliver up the body of the righteous; and the spirit and the body is restored to itself again, and all men become incorruptible, and immortal, and they are living souls, having a perfect knowledge like unto us in the flesh, save it be that our knowledge shall be perfect.

2 Nephi 9:14 Wherefore, we shall have a perfect knowledge of all our guilt, and our uncleanness, and our nakedness; and the righteous shall have a perfect knowledge of their enjoyment, and their righteousness, being clothed with purity, yea, even with the robe of righteousness.

2 Nephi 9:15 And it shall come to pass that when all men shall have passed from this first death unto life, insomuch as they have become immortal, they must appear before the judgment-seat of the Holy One of Israel; and then cometh the judgment, and then must they be judged according to the holy judgment of God.

2 Nephi 9:16 And assuredly, as the Lord liveth, for the Lord God hath spoken it, and it is his eternal word, which cannot pass away, that they who are righteous shall be righteous still, and they who are filthy shall be filthy still; wherefore, they who are filthy are the devil and his angels; and they shall go away into everlasting fire, prepared for them; and their torment is as a lake of fire and brimstone, whose flame ascendeth up forever and ever and has no end.

2 Nephi 9:17 O the greatness and the justice of our God! For he executeth all his words, and they have gone forth out of his mouth, and his law must be fulfilled.

2 Nephi 9:18 But, behold, the righteous, the saints of the Holy One of Israel, they who have believed in the Holy One of Israel, they who have endured the crosses of the world, and despised the shame of it, they shall inherit the kingdom of God, which was prepared for them from the foundation of the world, and their joy shall be full forever.

2 Nephi 9:19 O the greatness of the mercy of our God, the Holy One of Israel! For he delivereth his saints from that awful monster the devil, and death, and hell, and that lake of fire and brimstone, which is endless torment.

2 Nephi 9:20 O how great the holiness of our God! For he knoweth all things, and there is not anything save he knows it.

2 Nephi 9:21 And he cometh into the world that he may save all men if they will hearken unto his voice; for behold, he suffereth the pains of all men, yea, the pains of every living creature, both men, women, and children, who belong to the family of Adam.

2 Nephi 9:22 And he suffereth this that the resurrection might pass upon all men, that all might stand before him at the great and judgment day.

2 Nephi 9:23 And he commandeth all men that they must repent, and be baptized in his name, having perfect faith in the Holy One of Israel, or they cannot be saved in the kingdom of God.

2 Nephi 9:24 And if they will not repent and believe in his name, and be baptized in his name, and endure to the end, they must be damned; for the Lord God, the Holy One of Israel, has spoken it.

2 Nephi 9:25 Wherefore, he has given a law; and where there is no law given there is no punishment; and where there is no punishment there is no condemnation; and where there is no condemnation the mercies of the Holy One of Israel have claim upon them, because of the atonement; for they are delivered by the power of him.

2 Nephi 9:26 For the atonement satisfieth the demands of his justice upon all those who have not the law given to them, that they are delivered from that awful monster, death and hell, and the devil, and the lake of fire and brimstone, which is endless torment; and they are restored to that God who gave them breath, which is the Holy One of Israel.

2 Nephi 9:27 But wo unto him that has the law given, yea, that has all the commandments of God, like unto us, and that transgresseth them, and that wasteth the days of his probation, for awful is his state!

2 Nephi 9:28 O that cunning plan of the evil one! O the vainness, and the frailties, and the foolishness of men! When they are learned they think they are wise, and they hearken not unto the counsel of God, for they set it aside, supposing they know of themselves, wherefore, their wisdom is foolishness and it profiteth them not. And they shall perish.

2 Nephi 9:29 But to be learned is good if they hearken unto the counsels of God.

2 Nephi 9:30 But wo unto the rich, who are rich as to the things of the world. For because they are rich they despise the poor, and they persecute the meek, and their hearts are upon their treasures; wherefore, their treasure is their god. And behold, their treasure shall perish with them also.

2 Nephi 9:31 And wo unto the deaf that will not hear; for they shall perish.

2 Nephi 9:32 Wo unto the blind that will not see; for they shall perish also.

2 Nephi 9:33 Wo unto the uncircumcised of heart, for a knowledge of their iniquities shall smite them at the last day.

2 Nephi 9:34 Wo unto the liar, for he shall be thrust down to hell.

2 Nephi 9:35 Wo unto the murderer who deliberately killeth, for he shall die.

2 Nephi 9:36 Wo unto them who commit whoredoms, for they shall be thrust down to hell.

2 Nephi 9:37 Yea, wo unto those that worship idols, for the devil of all devils delighteth in them.

2 Nephi 9:38 And, in fine, wo unto all those who die in their sins; for they shall return to God, and behold his face, and remain in their sins.

2 Nephi 9:39 O, my beloved brethren, remember the awfulness in transgressing against that Holy God, and also the awfulness of yielding to the enticings of that cunning one. Remember, to be carnally-minded is death, and to be spiritually-minded is life eternal.

2 Nephi 9:40 O, my beloved brethren, give ear to my words. Remember the greatness of the Holy One of Israel. Do not say that I have spoken hard things against you; for if ye do, ye will revile against the truth; for I have spoken the words of your Maker. I know that the words of truth are hard against all uncleanness; but the righteous fear them not, for they love the truth and are not shaken.

2 Nephi 9:41 O then, my beloved brethren, come unto the Lord, the Holy One. Remember that his paths are righteous. Behold, the way for man is narrow, but it lieth in a straight course before him, and the keeper of the gate is the Holy One of Israel; and he employeth no servant there; and there is none other way save it be by the gate; for he cannot be deceived, for the Lord God is his name.

2 Nephi 9:42 And whoso knocketh, to him will he open; and the wise, and the learned, and they that are rich, who are puffed up because of their learning, and their wisdom, and their riches—yea, they are they whom he despiseth; and save they shall cast these things away, and consider themselves fools before God, and come down in the depths of humility, he will not open unto them.

2 Nephi 9:43 But the things of the wise and the prudent shall be hid from them forever—yea, that happiness which is prepared for the saints.

2 Nephi 9:44 O, my beloved brethren, remember my words. Behold, I take off my garments, and I shake them before you; I pray the God of my salvation that he view me with his all-searching eye; wherefore, ye shall know at the last day, when all men shall be judged of their works, that the God of Israel did witness that I shook your iniquities from my soul, and that I stand with brightness before him, and am rid of your blood.

2 Nephi 9:45 O, my beloved brethren, turn away from your sins; shake off the chains of him that would bind you fast; come unto that God who is the rock of your salvation.

2 Nephi 9:46 Prepare your souls for that glorious day when justice shall be administered unto the righteous, even the day of judgment, that ye may not shrink with awful fear; that ye may not remember your awful guilt in perfectness, and be constrained to exclaim: Holy, holy are thy judgments, O Lord God Almighty—but I know my guilt; I transgressed thy law, and my transgressions are mine; and the devil hath obtained me, that I am a prey to his awful misery.

2 Nephi 9:47 But behold, my brethren, is it expedient that I should awake you to an awful reality of these things? Would I harrow up your souls if your minds were pure? Would I be plain unto you according to the plainness of the truth if ye were freed from sin?

2 Nephi 9:48 Behold, if ye were holy I would speak unto you of holiness; but as ye are not holy, and ye look upon me as a teacher, it must needs be expedient that I teach you the consequences of sin.

2 Nephi 9:49 Behold, my soul abhorreth sin, and my heart delighteth in righteousness; and I will praise the holy name of my God.

2 Nephi 9:50 Come, my brethren, every one that thirsteth, come ye to the waters; and he that hath no money, come buy and eat; yea, come buy wine and milk without money and without price.

2 Nephi 9:51 Wherefore, do not spend money for that which is of no worth, nor your labor for that which cannot satisfy. Hearken diligently unto me, and remember the words which I have spoken; and come unto the Holy One of Israel, and feast upon that which perisheth not, neither can be corrupted, and let your soul delight in fatness.

2 Nephi 9:52 Behold, my beloved brethren, remember the words of your God; pray unto him continually by day, and give thanks unto his holy name by night. Let your hearts rejoice.

2 Nephi 9:53 And behold how great the covenants of the Lord, and how great his condescensions unto the children of men; and because of his greatness, and his grace and mercy, he has promised unto us that our seed shall not utterly be destroyed, according to the flesh, but that he would preserve them; and in future generations they shall become a righteous branch unto the house of Israel.

2 Nephi 9:54 And now, my brethren, I would speak unto you more; but on the morrow I will declare unto you the remainder of my words. Amen.
