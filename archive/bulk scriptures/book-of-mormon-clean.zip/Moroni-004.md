# Moroni 4

Moroni 4 (summary): How elders and priests administer the sacramental bread is explained. About A.D. 401–21.

Moroni 4:1 The manner of their elders and priests administering the flesh and blood of Christ unto the church; and they administered it according to the commandments of Christ; wherefore we know the manner to be true; and the elder or priest did minister it—

Moroni 4:2 And they did kneel down with the church, and pray to the Father in the name of Christ, saying:

Moroni 4:3 O God, the Eternal Father, we ask thee in the name of thy Son, Jesus Christ, to bless and sanctify this bread to the souls of all those who partake of it; that they may eat in remembrance of the body of thy Son, and witness unto thee, O God, the Eternal Father, that they are willing to take upon them the name of thy Son, and always remember him, and keep his commandments which he hath given them, that they may always have his Spirit to be with them. Amen.
