# Alma 24

Alma 24 (summary): The Lamanites come against the people of God—The Anti-Nephi-Lehies rejoice in Christ and are visited by angels—They choose to suffer death rather than to defend themselves—More Lamanites are converted. About 90–77 B.C.

Alma 24:1 And it came to pass that the Amalekites and the Amulonites and the Lamanites who were in the land of Amulon, and also in the land of Helam, and who were in the land of Jerusalem, and in fine, in all the land round about, who had not been converted and had not taken upon them the name of Anti-Nephi-Lehi, were stirred up by the Amalekites and by the Amulonites to anger against their brethren.

Alma 24:2 And their hatred became exceedingly sore against them, even insomuch that they began to rebel against their king, insomuch that they would not that he should be their king; therefore, they took up arms against the people of Anti-Nephi-Lehi.

Alma 24:3 Now the king conferred the kingdom upon his son, and he called his name Anti-Nephi-Lehi.

Alma 24:4 And the king died in that selfsame year that the Lamanites began to make preparations for war against the people of God.

Alma 24:5 Now when Ammon and his brethren and all those who had come up with him saw the preparations of the Lamanites to destroy their brethren, they came forth to the land of Midian, and there Ammon met all his brethren; and from thence they came to the land of Ishmael that they might hold a council with Lamoni and also with his brother Anti-Nephi-Lehi, what they should do to defend themselves against the Lamanites.

Alma 24:6 Now there was not one soul among all the people who had been converted unto the Lord that would take up arms against their brethren; nay, they would not even make any preparations for war; yea, and also their king commanded them that they should not.

Alma 24:7 Now, these are the words which he said unto the people concerning the matter: I thank my God, my beloved people, that our great God has in goodness sent these our brethren, the Nephites, unto us to preach unto us, and to convince us of the traditions of our wicked fathers.

Alma 24:8 And behold, I thank my great God that he has given us a portion of his Spirit to soften our hearts, that we have opened a correspondence with these brethren, the Nephites.

Alma 24:9 And behold, I also thank my God, that by opening this correspondence we have been convinced of our sins, and of the many murders which we have committed.

Alma 24:10 And I also thank my God, yea, my great God, that he hath granted unto us that we might repent of these things, and also that he hath forgiven us of those our many sins and murders which we have committed, and taken away the guilt from our hearts, through the merits of his Son.

Alma 24:11 And now behold, my brethren, since it has been all that we could do (as we were the most lost of all mankind) to repent of all our sins and the many murders which we have committed, and to get God to take them away from our hearts, for it was all we could do to repent sufficiently before God that he would take away our stain—

Alma 24:12 Now, my best beloved brethren, since God hath taken away our stains, and our swords have become bright, then let us stain our swords no more with the blood of our brethren.

Alma 24:13 Behold, I say unto you, Nay, let us retain our swords that they be not stained with the blood of our brethren; for perhaps, if we should stain our swords again they can no more be washed bright through the blood of the Son of our great God, which shall be shed for the atonement of our sins.

Alma 24:14 And the great God has had mercy on us, and made these things known unto us that we might not perish; yea, and he has made these things known unto us beforehand, because he loveth our souls as well as he loveth our children; therefore, in his mercy he doth visit us by his angels, that the plan of salvation might be made known unto us as well as unto future generations.

Alma 24:15 Oh, how merciful is our God! And now behold, since it has been as much as we could do to get our stains taken away from us, and our swords are made bright, let us hide them away that they may be kept bright, as a testimony to our God at the last day, or at the day that we shall be brought to stand before him to be judged, that we have not stained our swords in the blood of our brethren since he imparted his word unto us and has made us clean thereby.

Alma 24:16 And now, my brethren, if our brethren seek to destroy us, behold, we will hide away our swords, yea, even we will bury them deep in the earth, that they may be kept bright, as a testimony that we have never used them, at the last day; and if our brethren destroy us, behold, we shall go to our God and shall be saved.

Alma 24:17 And now it came to pass that when the king had made an end of these sayings, and all the people were assembled together, they took their swords, and all the weapons which were used for the shedding of man’s blood, and they did bury them up deep in the earth.

Alma 24:18 And this they did, it being in their view a testimony to God, and also to men, that they never would use weapons again for the shedding of man’s blood; and this they did, vouching and covenanting with God, that rather than shed the blood of their brethren they would give up their own lives; and rather than take away from a brother they would give unto him; and rather than spend their days in idleness they would labor abundantly with their hands.

Alma 24:19 And thus we see that, when these Lamanites were brought to believe and to know the truth, they were firm, and would suffer even unto death rather than commit sin; and thus we see that they buried their weapons of peace, or they buried the weapons of war, for peace.

Alma 24:20 And it came to pass that their brethren, the Lamanites, made preparations for war, and came up to the land of Nephi for the purpose of destroying the king, and to place another in his stead, and also of destroying the people of Anti-Nephi-Lehi out of the land.

Alma 24:21 Now when the people saw that they were coming against them they went out to meet them, and prostrated themselves before them to the earth, and began to call on the name of the Lord; and thus they were in this attitude when the Lamanites began to fall upon them, and began to slay them with the sword.

Alma 24:22 And thus without meeting any resistance, they did slay a thousand and five of them; and we know that they are blessed, for they have gone to dwell with their God.

Alma 24:23 Now when the Lamanites saw that their brethren would not flee from the sword, neither would they turn aside to the right hand or to the left, but that they would lie down and perish, and praised God even in the very act of perishing under the sword—

Alma 24:24 Now when the Lamanites saw this they did forbear from slaying them; and there were many whose hearts had swollen in them for those of their brethren who had fallen under the sword, for they repented of the things which they had done.

Alma 24:25 And it came to pass that they threw down their weapons of war, and they would not take them again, for they were stung for the murders which they had committed; and they came down even as their brethren, relying upon the mercies of those whose arms were lifted to slay them.

Alma 24:26 And it came to pass that the people of God were joined that day by more than the number who had been slain; and those who had been slain were righteous people, therefore we have no reason to doubt but what they were saved.

Alma 24:27 And there was not a wicked man slain among them; but there were more than a thousand brought to the knowledge of the truth; thus we see that the Lord worketh in many ways to the salvation of his people.

Alma 24:28 Now the greatest number of those of the Lamanites who slew so many of their brethren were Amalekites and Amulonites, the greatest number of whom were after the order of the Nehors.

Alma 24:29 Now, among those who joined the people of the Lord, there were none who were Amalekites or Amulonites, or who were of the order of Nehor, but they were actual descendants of Laman and Lemuel.

Alma 24:30 And thus we can plainly discern, that after a people have been once enlightened by the Spirit of God, and have had great knowledge of things pertaining to righteousness, and then have fallen away into sin and transgression, they become more hardened, and thus their state becomes worse than though they had never known these things.
