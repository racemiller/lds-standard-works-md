# Alma 1

Alma 1 (summary): Nehor teaches false doctrines, establishes a church, introduces priestcraft, and slays Gideon—Nehor is executed for his crimes—Priestcrafts and persecutions spread among the people—The priests support themselves, the people care for the poor, and the Church prospers. About 91–88 B.C.

Alma 1:1 Now it came to pass that in the first year of the reign of the judges over the people of Nephi, from this time forward, king Mosiah having gone the way of all the earth, having warred a good warfare, walking uprightly before God, leaving none to reign in his stead; nevertheless he had established laws, and they were acknowledged by the people; therefore they were obliged to abide by the laws which he had made.

Alma 1:2 And it came to pass that in the first year of the reign of Alma in the judgment-seat, there was a man brought before him to be judged, a man who was large, and was noted for his much strength.

Alma 1:3 And he had gone about among the people, preaching to them that which he termed to be the word of God, bearing down against the church; declaring unto the people that every priest and teacher ought to become popular; and they ought not to labor with their hands, but that they ought to be supported by the people.

Alma 1:4 And he also testified unto the people that all mankind should be saved at the last day, and that they need not fear nor tremble, but that they might lift up their heads and rejoice; for the Lord had created all men, and had also redeemed all men; and, in the end, all men should have eternal life.

Alma 1:5 And it came to pass that he did teach these things so much that many did believe on his words, even so many that they began to support him and give him money.

Alma 1:6 And he began to be lifted up in the pride of his heart, and to wear very costly apparel, yea, and even began to establish a church after the manner of his preaching.

Alma 1:7 And it came to pass as he was going, to preach to those who believed on his word, he met a man who belonged to the church of God, yea, even one of their teachers; and he began to contend with him sharply, that he might lead away the people of the church; but the man withstood him, admonishing him with the words of God.

Alma 1:8 Now the name of the man was Gideon; and it was he who was an instrument in the hands of God in delivering the people of Limhi out of bondage.

Alma 1:9 Now, because Gideon withstood him with the words of God he was wroth with Gideon, and drew his sword and began to smite him. Now Gideon being stricken with many years, therefore he was not able to withstand his blows, therefore he was slain by the sword.

Alma 1:10 And the man who slew him was taken by the people of the church, and was brought before Alma, to be judged according to the crimes which he had committed.

Alma 1:11 And it came to pass that he stood before Alma and pled for himself with much boldness.

Alma 1:12 But Alma said unto him: Behold, this is the first time that priestcraft has been introduced among this people. And behold, thou art not only guilty of priestcraft, but hast endeavored to enforce it by the sword; and were priestcraft to be enforced among this people it would prove their entire destruction.

Alma 1:13 And thou hast shed the blood of a righteous man, yea, a man who has done much good among this people; and were we to spare thee his blood would come upon us for vengeance.

Alma 1:14 Therefore thou art condemned to die, according to the law which has been given us by Mosiah, our last king; and it has been acknowledged by this people; therefore this people must abide by the law.

Alma 1:15 And it came to pass that they took him; and his name was Nehor; and they carried him upon the top of the hill Manti, and there he was caused, or rather did acknowledge, between the heavens and the earth, that what he had taught to the people was contrary to the word of God; and there he suffered an ignominious death.

Alma 1:16 Nevertheless, this did not put an end to the spreading of priestcraft through the land; for there were many who loved the vain things of the world, and they went forth preaching false doctrines; and this they did for the sake of riches and honor.

Alma 1:17 Nevertheless, they durst not lie, if it were known, for fear of the law, for liars were punished; therefore they pretended to preach according to their belief; and now the law could have no power on any man for his belief.

Alma 1:18 And they durst not steal, for fear of the law, for such were punished; neither durst they rob, nor murder, for he that murdered was punished unto death.

Alma 1:19 But it came to pass that whosoever did not belong to the church of God began to persecute those that did belong to the church of God, and had taken upon them the name of Christ.

Alma 1:20 Yea, they did persecute them, and afflict them with all manner of words, and this because of their humility; because they were not proud in their own eyes, and because they did impart the word of God, one with another, without money and without price.

Alma 1:21 Now there was a strict law among the people of the church, that there should not any man, belonging to the church, arise and persecute those that did not belong to the church, and that there should be no persecution among themselves.

Alma 1:22 Nevertheless, there were many among them who began to be proud, and began to contend warmly with their adversaries, even unto blows; yea, they would smite one another with their fists.

Alma 1:23 Now this was in the second year of the reign of Alma, and it was a cause of much affliction to the church; yea, it was the cause of much trial with the church.

Alma 1:24 For the hearts of many were hardened, and their names were blotted out, that they were remembered no more among the people of God. And also many withdrew themselves from among them.

Alma 1:25 Now this was a great trial to those that did stand fast in the faith; nevertheless, they were steadfast and immovable in keeping the commandments of God, and they bore with patience the persecution which was heaped upon them.

Alma 1:26 And when the priests left their labor to impart the word of God unto the people, the people also left their labors to hear the word of God. And when the priest had imparted unto them the word of God they all returned again diligently unto their labors; and the priest, not esteeming himself above his hearers, for the preacher was no better than the hearer, neither was the teacher any better than the learner; and thus they were all equal, and they did all labor, every man according to his strength.

Alma 1:27 And they did impart of their substance, every man according to that which he had, to the poor, and the needy, and the sick, and the afflicted; and they did not wear costly apparel, yet they were neat and comely.

Alma 1:28 And thus they did establish the affairs of the church; and thus they began to have continual peace again, notwithstanding all their persecutions.

Alma 1:29 And now, because of the steadiness of the church they began to be exceedingly rich, having abundance of all things whatsoever they stood in need—an abundance of flocks and herds, and fatlings of every kind, and also abundance of grain, and of gold, and of silver, and of precious things, and abundance of silk and fine-twined linen, and all manner of good homely cloth.

Alma 1:30 And thus, in their prosperous circumstances, they did not send away any who were naked, or that were hungry, or that were athirst, or that were sick, or that had not been nourished; and they did not set their hearts upon riches; therefore they were liberal to all, both old and young, both bond and free, both male and female, whether out of the church or in the church, having no respect to persons as to those who stood in need.

Alma 1:31 And thus they did prosper and become far more wealthy than those who did not belong to their church.

Alma 1:32 For those who did not belong to their church did indulge themselves in sorceries, and in idolatry or idleness, and in babblings, and in envyings and strife; wearing costly apparel; being lifted up in the pride of their own eyes; persecuting, lying, thieving, robbing, committing whoredoms, and murdering, and all manner of wickedness; nevertheless, the law was put in force upon all those who did transgress it, inasmuch as it was possible.

Alma 1:33 And it came to pass that by thus exercising the law upon them, every man suffering according to that which he had done, they became more still, and durst not commit any wickedness if it were known; therefore, there was much peace among the people of Nephi until the fifth year of the reign of the judges.
