# Helaman 6

Helaman 6 (summary): The righteous Lamanites preach to the wicked Nephites—Both peoples prosper during an era of peace and plenty—Lucifer, the author of sin, stirs up the hearts of the wicked and the Gadianton robbers in murder and wickedness—The robbers take over the Nephite government. About 29–23 B.C.

Helaman 6:1 And it came to pass that when the sixty and second year of the reign of the judges had ended, all these things had happened and the Lamanites had become, the more part of them, a righteous people, insomuch that their righteousness did exceed that of the Nephites, because of their firmness and their steadiness in the faith.

Helaman 6:2 For behold, there were many of the Nephites who had become hardened and impenitent and grossly wicked, insomuch that they did reject the word of God and all the preaching and prophesying which did come among them.

Helaman 6:3 Nevertheless, the people of the church did have great joy because of the conversion of the Lamanites, yea, because of the church of God, which had been established among them. And they did fellowship one with another, and did rejoice one with another, and did have great joy.

Helaman 6:4 And it came to pass that many of the Lamanites did come down into the land of Zarahemla, and did declare unto the people of the Nephites the manner of their conversion, and did exhort them to faith and repentance.

Helaman 6:5 Yea, and many did preach with exceedingly great power and authority, unto the bringing down many of them into the depths of humility, to be the humble followers of God and the Lamb.

Helaman 6:6 And it came to pass that many of the Lamanites did go into the land northward; and also Nephi and Lehi went into the land northward, to preach unto the people. And thus ended the sixty and third year.

Helaman 6:7 And behold, there was peace in all the land, insomuch that the Nephites did go into whatsoever part of the land they would, whether among the Nephites or the Lamanites.

Helaman 6:8 And it came to pass that the Lamanites did also go whithersoever they would, whether it were among the Lamanites or among the Nephites; and thus they did have free intercourse one with another, to buy and to sell, and to get gain, according to their desire.

Helaman 6:9 And it came to pass that they became exceedingly rich, both the Lamanites and the Nephites; and they did have an exceeding plenty of gold, and of silver, and of all manner of precious metals, both in the land south and in the land north.

Helaman 6:10 Now the land south was called Lehi, and the land north was called Mulek, which was after the son of Zedekiah; for the Lord did bring Mulek into the land north, and Lehi into the land south.

Helaman 6:11 And behold, there was all manner of gold in both these lands, and of silver, and of precious ore of every kind; and there were also curious workmen, who did work all kinds of ore and did refine it; and thus they did become rich.

Helaman 6:12 They did raise grain in abundance, both in the north and in the south; and they did flourish exceedingly, both in the north and in the south. And they did multiply and wax exceedingly strong in the land. And they did raise many flocks and herds, yea, many fatlings.

Helaman 6:13 Behold their women did toil and spin, and did make all manner of cloth, of fine-twined linen and cloth of every kind, to clothe their nakedness. And thus the sixty and fourth year did pass away in peace.

Helaman 6:14 And in the sixty and fifth year they did also have great joy and peace, yea, much preaching and many prophecies concerning that which was to come. And thus passed away the sixty and fifth year.

Helaman 6:15 And it came to pass that in the sixty and sixth year of the reign of the judges, behold, Cezoram was murdered by an unknown hand as he sat upon the judgment-seat. And it came to pass that in the same year, that his son, who had been appointed by the people in his stead, was also murdered. And thus ended the sixty and sixth year.

Helaman 6:16 And in the commencement of the sixty and seventh year the people began to grow exceedingly wicked again.

Helaman 6:17 For behold, the Lord had blessed them so long with the riches of the world that they had not been stirred up to anger, to wars, nor to bloodshed; therefore they began to set their hearts upon their riches; yea, they began to seek to get gain that they might be lifted up one above another; therefore they began to commit secret murders, and to rob and to plunder, that they might get gain.

Helaman 6:18 And now behold, those murderers and plunderers were a band who had been formed by Kishkumen and Gadianton. And now it had come to pass that there were many, even among the Nephites, of Gadianton’s band. But behold, they were more numerous among the more wicked part of the Lamanites. And they were called Gadianton’s robbers and murderers.

Helaman 6:19 And it was they who did murder the chief judge Cezoram, and his son, while in the judgment-seat; and behold, they were not found.

Helaman 6:20 And now it came to pass that when the Lamanites found that there were robbers among them they were exceedingly sorrowful; and they did use every means in their power to destroy them off the face of the earth.

Helaman 6:21 But behold, Satan did stir up the hearts of the more part of the Nephites, insomuch that they did unite with those bands of robbers, and did enter into their covenants and their oaths, that they would protect and preserve one another in whatsoever difficult circumstances they should be placed, that they should not suffer for their murders, and their plunderings, and their stealings.

Helaman 6:22 And it came to pass that they did have their signs, yea, their secret signs, and their secret words; and this that they might distinguish a brother who had entered into the covenant, that whatsoever wickedness his brother should do he should not be injured by his brother, nor by those who did belong to his band, who had taken this covenant.

Helaman 6:23 And thus they might murder, and plunder, and steal, and commit whoredoms and all manner of wickedness, contrary to the laws of their country and also the laws of their God.

Helaman 6:24 And whosoever of those who belonged to their band should reveal unto the world of their wickedness and their abominations, should be tried, not according to the laws of their country, but according to the laws of their wickedness, which had been given by Gadianton and Kishkumen.

Helaman 6:25 Now behold, it is these secret oaths and covenants which Alma commanded his son should not go forth unto the world, lest they should be a means of bringing down the people unto destruction.

Helaman 6:26 Now behold, those secret oaths and covenants did not come forth unto Gadianton from the records which were delivered unto Helaman; but behold, they were put into the heart of Gadianton by that same being who did entice our first parents to partake of the forbidden fruit—

Helaman 6:27 Yea, that same being who did plot with Cain, that if he would murder his brother Abel it should not be known unto the world. And he did plot with Cain and his followers from that time forth.

Helaman 6:28 And also it is that same being who put it into the hearts of the people to build a tower sufficiently high that they might get to heaven. And it was that same being who led on the people who came from that tower into this land; who spread the works of darkness and abominations over all the face of the land, until he dragged the people down to an entire destruction, and to an everlasting hell.

Helaman 6:29 Yea, it is that same being who put it into the heart of Gadianton to still carry on the work of darkness, and of secret murder; and he has brought it forth from the beginning of man even down to this time.

Helaman 6:30 And behold, it is he who is the author of all sin. And behold, he doth carry on his works of darkness and secret murder, and doth hand down their plots, and their oaths, and their covenants, and their plans of awful wickedness, from generation to generation according as he can get hold upon the hearts of the children of men.

Helaman 6:31 And now behold, he had got great hold upon the hearts of the Nephites; yea, insomuch that they had become exceedingly wicked; yea, the more part of them had turned out of the way of righteousness, and did trample under their feet the commandments of God, and did turn unto their own ways, and did build up unto themselves idols of their gold and their silver.

Helaman 6:32 And it came to pass that all these iniquities did come unto them in the space of not many years, insomuch that a more part of it had come unto them in the sixty and seventh year of the reign of the judges over the people of Nephi.

Helaman 6:33 And they did grow in their iniquities in the sixty and eighth year also, to the great sorrow and lamentation of the righteous.

Helaman 6:34 And thus we see that the Nephites did begin to dwindle in unbelief, and grow in wickedness and abominations, while the Lamanites began to grow exceedingly in the knowledge of their God; yea, they did begin to keep his statutes and commandments, and to walk in truth and uprightness before him.

Helaman 6:35 And thus we see that the Spirit of the Lord began to withdraw from the Nephites, because of the wickedness and the hardness of their hearts.

Helaman 6:36 And thus we see that the Lord began to pour out his Spirit upon the Lamanites, because of their easiness and willingness to believe in his words.

Helaman 6:37 And it came to pass that the Lamanites did hunt the band of robbers of Gadianton; and they did preach the word of God among the more wicked part of them, insomuch that this band of robbers was utterly destroyed from among the Lamanites.

Helaman 6:38 And it came to pass on the other hand, that the Nephites did build them up and support them, beginning at the more wicked part of them, until they had overspread all the land of the Nephites, and had seduced the more part of the righteous until they had come down to believe in their works and partake of their spoils, and to join with them in their secret murders and combinations.

Helaman 6:39 And thus they did obtain the sole management of the government, insomuch that they did trample under their feet and smite and rend and turn their backs upon the poor and the meek, and the humble followers of God.

Helaman 6:40 And thus we see that they were in an awful state, and ripening for an everlasting destruction.

Helaman 6:41 And it came to pass that thus ended the sixty and eighth year of the reign of the judges over the people of Nephi.
