# Moroni 3

Moroni 3 (summary): Elders ordain priests and teachers by the laying on of hands. About A.D. 401–21.

Moroni 3:1 The manner which the disciples, who were called the elders of the church, ordained priests and teachers—

Moroni 3:2 After they had prayed unto the Father in the name of Christ, they laid their hands upon them, and said:

Moroni 3:3 In the name of Jesus Christ I ordain you to be a priest (or if he be a teacher, I ordain you to be a teacher) to preach repentance and remission of sins through Jesus Christ, by the endurance of faith on his name to the end. Amen.

Moroni 3:4 And after this manner did they ordain priests and teachers, according to the gifts and callings of God unto men; and they ordained them by the power of the Holy Ghost, which was in them.
