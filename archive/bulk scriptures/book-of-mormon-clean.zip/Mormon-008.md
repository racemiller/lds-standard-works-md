# Mormon 8

Mormon 8 (summary): The Lamanites seek out and destroy the Nephites—The Book of Mormon will come forth by the power of God—Woes pronounced upon those who breathe out wrath and strife against the work of the Lord—The Nephite record will come forth in a day of wickedness, degeneracy, and apostasy. About A.D. 400–421.

Mormon 8:1 Behold I, Moroni, do finish the record of my father, Mormon. Behold, I have but few things to write, which things I have been commanded by my father.

Mormon 8:2 And now it came to pass that after the great and tremendous battle at Cumorah, behold, the Nephites who had escaped into the country southward were hunted by the Lamanites, until they were all destroyed.

Mormon 8:3 And my father also was killed by them, and I even remain alone to write the sad tale of the destruction of my people. But behold, they are gone, and I fulfil the commandment of my father. And whether they will slay me, I know not.

Mormon 8:4 Therefore I will write and hide up the records in the earth; and whither I go it mattereth not.

Mormon 8:5 Behold, my father hath made this record, and he hath written the intent thereof. And behold, I would write it also if I had room upon the plates, but I have not; and ore I have none, for I am alone. My father hath been slain in battle, and all my kinsfolk, and I have not friends nor whither to go; and how long the Lord will suffer that I may live I know not.

Mormon 8:6 Behold, four hundred years have passed away since the coming of our Lord and Savior.

Mormon 8:7 And behold, the Lamanites have hunted my people, the Nephites, down from city to city and from place to place, even until they are no more; and great has been their fall; yea, great and marvelous is the destruction of my people, the Nephites.

Mormon 8:8 And behold, it is the hand of the Lord which hath done it. And behold also, the Lamanites are at war one with another; and the whole face of this land is one continual round of murder and bloodshed; and no one knoweth the end of the war.

Mormon 8:9 And now, behold, I say no more concerning them, for there are none save it be the Lamanites and robbers that do exist upon the face of the land.

Mormon 8:10 And there are none that do know the true God save it be the disciples of Jesus, who did tarry in the land until the wickedness of the people was so great that the Lord would not suffer them to remain with the people; and whether they be upon the face of the land no man knoweth.

Mormon 8:11 But behold, my father and I have seen them, and they have ministered unto us.

Mormon 8:12 And whoso receiveth this record, and shall not condemn it because of the imperfections which are in it, the same shall know of greater things than these. Behold, I am Moroni; and were it possible, I would make all things known unto you.

Mormon 8:13 Behold, I make an end of speaking concerning this people. I am the son of Mormon, and my father was a descendant of Nephi.

Mormon 8:14 And I am the same who hideth up this record unto the Lord; the plates thereof are of no worth, because of the commandment of the Lord. For he truly saith that no one shall have them to get gain; but the record thereof is of great worth; and whoso shall bring it to light, him will the Lord bless.

Mormon 8:15 For none can have power to bring it to light save it be given him of God; for God wills that it shall be done with an eye single to his glory, or the welfare of the ancient and long dispersed covenant people of the Lord.

Mormon 8:16 And blessed be he that shall bring this thing to light; for it shall be brought out of darkness unto light, according to the word of God; yea, it shall be brought out of the earth, and it shall shine forth out of darkness, and come unto the knowledge of the people; and it shall be done by the power of God.

Mormon 8:17 And if there be faults they be the faults of a man. But behold, we know no fault; nevertheless God knoweth all things; therefore, he that condemneth, let him be aware lest he shall be in danger of hell fire.

Mormon 8:18 And he that saith: Show unto me, or ye shall be smitten—let him beware lest he commandeth that which is forbidden of the Lord.

Mormon 8:19 For behold, the same that judgeth rashly shall be judged rashly again; for according to his works shall his wages be; therefore, he that smiteth shall be smitten again, of the Lord.

Mormon 8:20 Behold what the scripture says—man shall not smite, neither shall he judge; for judgment is mine, saith the Lord, and vengeance is mine also, and I will repay.

Mormon 8:21 And he that shall breathe out wrath and strifes against the work of the Lord, and against the covenant people of the Lord who are the house of Israel, and shall say: We will destroy the work of the Lord, and the Lord will not remember his covenant which he hath made unto the house of Israel—the same is in danger to be hewn down and cast into the fire;

Mormon 8:22 For the eternal purposes of the Lord shall roll on, until all his promises shall be fulfilled.

Mormon 8:23 Search the prophecies of Isaiah. Behold, I cannot write them. Yea, behold I say unto you, that those saints who have gone before me, who have possessed this land, shall cry, yea, even from the dust will they cry unto the Lord; and as the Lord liveth he will remember the covenant which he hath made with them.

Mormon 8:24 And he knoweth their prayers, that they were in behalf of their brethren. And he knoweth their faith, for in his name could they remove mountains; and in his name could they cause the earth to shake; and by the power of his word did they cause prisons to tumble to the earth; yea, even the fiery furnace could not harm them, neither wild beasts nor poisonous serpents, because of the power of his word.

Mormon 8:25 And behold, their prayers were also in behalf of him that the Lord should suffer to bring these things forth.

Mormon 8:26 And no one need say they shall not come, for they surely shall, for the Lord hath spoken it; for out of the earth shall they come, by the hand of the Lord, and none can stay it; and it shall come in a day when it shall be said that miracles are done away; and it shall come even as if one should speak from the dead.

Mormon 8:27 And it shall come in a day when the blood of saints shall cry unto the Lord, because of secret combinations and the works of darkness.

Mormon 8:28 Yea, it shall come in a day when the power of God shall be denied, and churches become defiled and be lifted up in the pride of their hearts; yea, even in a day when leaders of churches and teachers shall rise in the pride of their hearts, even to the envying of them who belong to their churches.

Mormon 8:29 Yea, it shall come in a day when there shall be heard of fires, and tempests, and vapors of smoke in foreign lands;

Mormon 8:30 And there shall also be heard of wars, rumors of wars, and earthquakes in divers places.

Mormon 8:31 Yea, it shall come in a day when there shall be great pollutions upon the face of the earth; there shall be murders, and robbing, and lying, and deceivings, and whoredoms, and all manner of abominations; when there shall be many who will say, Do this, or do that, and it mattereth not, for the Lord will uphold such at the last day. But wo unto such, for they are in the gall of bitterness and in the bonds of iniquity.

Mormon 8:32 Yea, it shall come in a day when there shall be churches built up that shall say: Come unto me, and for your money you shall be forgiven of your sins.

Mormon 8:33 O ye wicked and perverse and stiffnecked people, why have ye built up churches unto yourselves to get gain? Why have ye transfigured the holy word of God, that ye might bring damnation upon your souls? Behold, look ye unto the revelations of God; for behold, the time cometh at that day when all these things must be fulfilled.

Mormon 8:34 Behold, the Lord hath shown unto me great and marvelous things concerning that which must shortly come, at that day when these things shall come forth among you.

Mormon 8:35 Behold, I speak unto you as if ye were present, and yet ye are not. But behold, Jesus Christ hath shown you unto me, and I know your doing.

Mormon 8:36 And I know that ye do walk in the pride of your hearts; and there are none save a few only who do not lift themselves up in the pride of their hearts, unto the wearing of very fine apparel, unto envying, and strifes, and malice, and persecutions, and all manner of iniquities; and your churches, yea, even every one, have become polluted because of the pride of your hearts.

Mormon 8:37 For behold, ye do love money, and your substance, and your fine apparel, and the adorning of your churches, more than ye love the poor and the needy, the sick and the afflicted.

Mormon 8:38 O ye pollutions, ye hypocrites, ye teachers, who sell yourselves for that which will canker, why have ye polluted the holy church of God? Why are ye ashamed to take upon you the name of Christ? Why do ye not think that greater is the value of an endless happiness than that misery which never dies—because of the praise of the world?

Mormon 8:39 Why do ye adorn yourselves with that which hath no life, and yet suffer the hungry, and the needy, and the naked, and the sick and the afflicted to pass by you, and notice them not?

Mormon 8:40 Yea, why do ye build up your secret abominations to get gain, and cause that widows should mourn before the Lord, and also orphans to mourn before the Lord, and also the blood of their fathers and their husbands to cry unto the Lord from the ground, for vengeance upon your heads?

Mormon 8:41 Behold, the sword of vengeance hangeth over you; and the time soon cometh that he avengeth the blood of the saints upon you, for he will not suffer their cries any longer.
