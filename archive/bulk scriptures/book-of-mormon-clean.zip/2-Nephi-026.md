# 2 Nephi 26

2 Nephi 26 (summary): Christ will minister to the Nephites—Nephi foresees the destruction of his people—They will speak from the dust—The Gentiles will build up false churches and secret combinations—The Lord forbids men to practice priestcrafts. About 559–545 B.C.

2 Nephi 26:1 And after Christ shall have risen from the dead he shall show himself unto you, my children, and my beloved brethren; and the words which he shall speak unto you shall be the law which ye shall do.

2 Nephi 26:2 For behold, I say unto you that I have beheld that many generations shall pass away, and there shall be great wars and contentions among my people.

2 Nephi 26:3 And after the Messiah shall come there shall be signs given unto my people of his birth, and also of his death and resurrection; and great and terrible shall that day be unto the wicked, for they shall perish; and they perish because they cast out the prophets, and the saints, and stone them, and slay them; wherefore the cry of the blood of the saints shall ascend up to God from the ground against them.

2 Nephi 26:4 Wherefore, all those who are proud, and that do wickedly, the day that cometh shall burn them up, saith the Lord of Hosts, for they shall be as stubble.

2 Nephi 26:5 And they that kill the prophets, and the saints, the depths of the earth shall swallow them up, saith the Lord of Hosts; and mountains shall cover them, and whirlwinds shall carry them away, and buildings shall fall upon them and crush them to pieces and grind them to powder.

2 Nephi 26:6 And they shall be visited with thunderings, and lightnings, and earthquakes, and all manner of destructions, for the fire of the anger of the Lord shall be kindled against them, and they shall be as stubble, and the day that cometh shall consume them, saith the Lord of Hosts.

2 Nephi 26:7 O the pain, and the anguish of my soul for the loss of the slain of my people! For I, Nephi, have seen it, and it well nigh consumeth me before the presence of the Lord; but I must cry unto my God: Thy ways are just.

2 Nephi 26:8 But behold, the righteous that hearken unto the words of the prophets, and destroy them not, but look forward unto Christ with steadfastness for the signs which are given, notwithstanding all persecution—behold, they are they which shall not perish.

2 Nephi 26:9 But the Son of Righteousness shall appear unto them; and he shall heal them, and they shall have peace with him, until three generations shall have passed away, and many of the fourth generation shall have passed away in righteousness.

2 Nephi 26:10 And when these things have passed away a speedy destruction cometh unto my people; for, notwithstanding the pains of my soul, I have seen it; wherefore, I know that it shall come to pass; and they sell themselves for naught; for, for the reward of their pride and their foolishness they shall reap destruction; for because they yield unto the devil and choose works of darkness rather than light, therefore they must go down to hell.

2 Nephi 26:11 For the Spirit of the Lord will not always strive with man. And when the Spirit ceaseth to strive with man then cometh speedy destruction, and this grieveth my soul.

2 Nephi 26:12 And as I spake concerning the convincing of the Jews, that Jesus is the very Christ, it must needs be that the Gentiles be convinced also that Jesus is the Christ, the Eternal God;

2 Nephi 26:13 And that he manifesteth himself unto all those who believe in him, by the power of the Holy Ghost; yea, unto every nation, kindred, tongue, and people, working mighty miracles, signs, and wonders, among the children of men according to their faith.

2 Nephi 26:14 But behold, I prophesy unto you concerning the last days; concerning the days when the Lord God shall bring these things forth unto the children of men.

2 Nephi 26:15 After my seed and the seed of my brethren shall have dwindled in unbelief, and shall have been smitten by the Gentiles; yea, after the Lord God shall have camped against them round about, and shall have laid siege against them with a mount, and raised forts against them; and after they shall have been brought down low in the dust, even that they are not, yet the words of the righteous shall be written, and the prayers of the faithful shall be heard, and all those who have dwindled in unbelief shall not be forgotten.

2 Nephi 26:16 For those who shall be destroyed shall speak unto them out of the ground, and their speech shall be low out of the dust, and their voice shall be as one that hath a familiar spirit; for the Lord God will give unto him power, that he may whisper concerning them, even as it were out of the ground; and their speech shall whisper out of the dust.

2 Nephi 26:17 For thus saith the Lord God: They shall write the things which shall be done among them, and they shall be written and sealed up in a book, and those who have dwindled in unbelief shall not have them, for they seek to destroy the things of God.

2 Nephi 26:18 Wherefore, as those who have been destroyed have been destroyed speedily; and the multitude of their terrible ones shall be as chaff that passeth away—yea, thus saith the Lord God: It shall be at an instant, suddenly—

2 Nephi 26:19 And it shall come to pass, that those who have dwindled in unbelief shall be smitten by the hand of the Gentiles.

2 Nephi 26:20 And the Gentiles are lifted up in the pride of their eyes, and have stumbled, because of the greatness of their stumbling block, that they have built up many churches; nevertheless, they put down the power and miracles of God, and preach up unto themselves their own wisdom and their own learning, that they may get gain and grind upon the face of the poor.

2 Nephi 26:21 And there are many churches built up which cause envyings, and strifes, and malice.

2 Nephi 26:22 And there are also secret combinations, even as in times of old, according to the combinations of the devil, for he is the founder of all these things; yea, the founder of murder, and works of darkness; yea, and he leadeth them by the neck with a flaxen cord, until he bindeth them with his strong cords forever.

2 Nephi 26:23 For behold, my beloved brethren, I say unto you that the Lord God worketh not in darkness.

2 Nephi 26:24 He doeth not anything save it be for the benefit of the world; for he loveth the world, even that he layeth down his own life that he may draw all men unto him. Wherefore, he commandeth none that they shall not partake of his salvation.

2 Nephi 26:25 Behold, doth he cry unto any, saying: Depart from me? Behold, I say unto you, Nay; but he saith: Come unto me all ye ends of the earth, buy milk and honey, without money and without price.

2 Nephi 26:26 Behold, hath he commanded any that they should depart out of the synagogues, or out of the houses of worship? Behold, I say unto you, Nay.

2 Nephi 26:27 Hath he commanded any that they should not partake of his salvation? Behold I say unto you, Nay; but he hath given it free for all men; and he hath commanded his people that they should persuade all men to repentance.

2 Nephi 26:28 Behold, hath the Lord commanded any that they should not partake of his goodness? Behold I say unto you, Nay; but all men are privileged the one like unto the other, and none are forbidden.

2 Nephi 26:29 He commandeth that there shall be no priestcrafts; for, behold, priestcrafts are that men preach and set themselves up for a light unto the world, that they may get gain and praise of the world; but they seek not the welfare of Zion.

2 Nephi 26:30 Behold, the Lord hath forbidden this thing; wherefore, the Lord God hath given a commandment that all men should have charity, which charity is love. And except they should have charity they were nothing. Wherefore, if they should have charity they would not suffer the laborer in Zion to perish.

2 Nephi 26:31 But the laborer in Zion shall labor for Zion; for if they labor for money they shall perish.

2 Nephi 26:32 And again, the Lord God hath commanded that men should not murder; that they should not lie; that they should not steal; that they should not take the name of the Lord their God in vain; that they should not envy; that they should not have malice; that they should not contend one with another; that they should not commit whoredoms; and that they should do none of these things; for whoso doeth them shall perish.

2 Nephi 26:33 For none of these iniquities come of the Lord; for he doeth that which is good among the children of men; and he doeth nothing save it be plain unto the children of men; and he inviteth them all to come unto him and partake of his goodness; and he denieth none that come unto him, black and white, bond and free, male and female; and he remembereth the heathen; and all are alike unto God, both Jew and Gentile.
