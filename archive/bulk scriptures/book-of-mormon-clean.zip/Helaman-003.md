# Helaman 3

Helaman 3 (summary): Many Nephites migrate to the land northward—They build houses of cement and keep many records—Tens of thousands are converted and baptized—The word of God leads men to salvation—Nephi the son of Helaman fills the judgment seat. About 49–39 B.C.

Helaman 3:1 And now it came to pass in the forty and third year of the reign of the judges, there was no contention among the people of Nephi save it were a little pride which was in the church, which did cause some little dissensions among the people, which affairs were settled in the ending of the forty and third year.

Helaman 3:2 And there was no contention among the people in the forty and fourth year; neither was there much contention in the forty and fifth year.

Helaman 3:3 And it came to pass in the forty and sixth, yea, there was much contention and many dissensions; in the which there were an exceedingly great many who departed out of the land of Zarahemla, and went forth unto the land northward to inherit the land.

Helaman 3:4 And they did travel to an exceedingly great distance, insomuch that they came to large bodies of water and many rivers.

Helaman 3:5 Yea, and even they did spread forth into all parts of the land, into whatever parts it had not been rendered desolate and without timber, because of the many inhabitants who had before inherited the land.

Helaman 3:6 And now no part of the land was desolate, save it were for timber; but because of the greatness of the destruction of the people who had before inhabited the land it was called desolate.

Helaman 3:7 And there being but little timber upon the face of the land, nevertheless the people who went forth became exceedingly expert in the working of cement; therefore they did build houses of cement, in the which they did dwell.

Helaman 3:8 And it came to pass that they did multiply and spread, and did go forth from the land southward to the land northward, and did spread insomuch that they began to cover the face of the whole earth, from the sea south to the sea north, from the sea west to the sea east.

Helaman 3:9 And the people who were in the land northward did dwell in tents, and in houses of cement, and they did suffer whatsoever tree should spring up upon the face of the land that it should grow up, that in time they might have timber to build their houses, yea, their cities, and their temples, and their synagogues, and their sanctuaries, and all manner of their buildings.

Helaman 3:10 And it came to pass as timber was exceedingly scarce in the land northward, they did send forth much by the way of shipping.

Helaman 3:11 And thus they did enable the people in the land northward that they might build many cities, both of wood and of cement.

Helaman 3:12 And it came to pass that there were many of the people of Ammon, who were Lamanites by birth, did also go forth into this land.

Helaman 3:13 And now there are many records kept of the proceedings of this people, by many of this people, which are particular and very large, concerning them.

Helaman 3:14 But behold, a hundredth part of the proceedings of this people, yea, the account of the Lamanites and of the Nephites, and their wars, and contentions, and dissensions, and their preaching, and their prophecies, and their shipping and their building of ships, and their building of temples, and of synagogues and their sanctuaries, and their righteousness, and their wickedness, and their murders, and their robbings, and their plundering, and all manner of abominations and whoredoms, cannot be contained in this work.

Helaman 3:15 But behold, there are many books and many records of every kind, and they have been kept chiefly by the Nephites.

Helaman 3:16 And they have been handed down from one generation to another by the Nephites, even until they have fallen into transgression and have been murdered, plundered, and hunted, and driven forth, and slain, and scattered upon the face of the earth, and mixed with the Lamanites until they are no more called the Nephites, becoming wicked, and wild, and ferocious, yea, even becoming Lamanites.

Helaman 3:17 And now I return again to mine account; therefore, what I have spoken had passed after there had been great contentions, and disturbances, and wars, and dissensions, among the people of Nephi.

Helaman 3:18 The forty and sixth year of the reign of the judges ended;

Helaman 3:19 And it came to pass that there was still great contention in the land, yea, even in the forty and seventh year, and also in the forty and eighth year.

Helaman 3:20 Nevertheless Helaman did fill the judgment-seat with justice and equity; yea, he did observe to keep the statutes, and the judgments, and the commandments of God; and he did do that which was right in the sight of God continually; and he did walk after the ways of his father, insomuch that he did prosper in the land.

Helaman 3:21 And it came to pass that he had two sons. He gave unto the eldest the name of Nephi, and unto the youngest, the name of Lehi. And they began to grow up unto the Lord.

Helaman 3:22 And it came to pass that the wars and contentions began to cease, in a small degree, among the people of the Nephites, in the latter end of the forty and eighth year of the reign of the judges over the people of Nephi.

Helaman 3:23 And it came to pass in the forty and ninth year of the reign of the judges, there was continual peace established in the land, all save it were the secret combinations which Gadianton the robber had established in the more settled parts of the land, which at that time were not known unto those who were at the head of government; therefore they were not destroyed out of the land.

Helaman 3:24 And it came to pass that in this same year there was exceedingly great prosperity in the church, insomuch that there were thousands who did join themselves unto the church and were baptized unto repentance.

Helaman 3:25 And so great was the prosperity of the church, and so many the blessings which were poured out upon the people, that even the high priests and the teachers were themselves astonished beyond measure.

Helaman 3:26 And it came to pass that the work of the Lord did prosper unto the baptizing and uniting to the church of God, many souls, yea, even tens of thousands.

Helaman 3:27 Thus we may see that the Lord is merciful unto all who will, in the sincerity of their hearts, call upon his holy name.

Helaman 3:28 Yea, thus we see that the gate of heaven is open unto all, even to those who will believe on the name of Jesus Christ, who is the Son of God.

Helaman 3:29 Yea, we see that whosoever will may lay hold upon the word of God, which is quick and powerful, which shall divide asunder all the cunning and the snares and the wiles of the devil, and lead the man of Christ in a strait and narrow course across that everlasting gulf of misery which is prepared to engulf the wicked—

Helaman 3:30 And land their souls, yea, their immortal souls, at the right hand of God in the kingdom of heaven, to sit down with Abraham, and Isaac, and with Jacob, and with all our holy fathers, to go no more out.

Helaman 3:31 And in this year there was continual rejoicing in the land of Zarahemla, and in all the regions round about, even in all the land which was possessed by the Nephites.

Helaman 3:32 And it came to pass that there was peace and exceedingly great joy in the remainder of the forty and ninth year; yea, and also there was continual peace and great joy in the fiftieth year of the reign of the judges.

Helaman 3:33 And in the fifty and first year of the reign of the judges there was peace also, save it were the pride which began to enter into the church—not into the church of God, but into the hearts of the people who professed to belong to the church of God—

Helaman 3:34 And they were lifted up in pride, even to the persecution of many of their brethren. Now this was a great evil, which did cause the more humble part of the people to suffer great persecutions, and to wade through much affliction.

Helaman 3:35 Nevertheless they did fast and pray oft, and did wax stronger and stronger in their humility, and firmer and firmer in the faith of Christ, unto the filling their souls with joy and consolation, yea, even to the purifying and the sanctification of their hearts, which sanctification cometh because of their yielding their hearts unto God.

Helaman 3:36 And it came to pass that the fifty and second year ended in peace also, save it were the exceedingly great pride which had gotten into the hearts of the people; and it was because of their exceedingly great riches and their prosperity in the land; and it did grow upon them from day to day.

Helaman 3:37 And it came to pass in the fifty and third year of the reign of the judges, Helaman died, and his eldest son Nephi began to reign in his stead. And it came to pass that he did fill the judgment-seat with justice and equity; yea, he did keep the commandments of God, and did walk in the ways of his father.
