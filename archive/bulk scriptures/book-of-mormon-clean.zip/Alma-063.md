# Alma 63

Alma 63 (summary): Shiblon and later Helaman take possession of the sacred records—Many Nephites travel to the land northward—Hagoth builds ships, which sail forth in the west sea—Moronihah defeats the Lamanites in battle. About 56–52 B.C.

Alma 63:1 And it came to pass in the commencement of the thirty and sixth year of the reign of the judges over the people of Nephi, that Shiblon took possession of those sacred things which had been delivered unto Helaman by Alma.

Alma 63:2 And he was a just man, and he did walk uprightly before God; and he did observe to do good continually, to keep the commandments of the Lord his God; and also did his brother.

Alma 63:3 And it came to pass that Moroni died also. And thus ended the thirty and sixth year of the reign of the judges.

Alma 63:4 And it came to pass that in the thirty and seventh year of the reign of the judges, there was a large company of men, even to the amount of five thousand and four hundred men, with their wives and their children, departed out of the land of Zarahemla into the land which was northward.

Alma 63:5 And it came to pass that Hagoth, he being an exceedingly curious man, therefore he went forth and built him an exceedingly large ship, on the borders of the land Bountiful, by the land Desolation, and launched it forth into the west sea, by the narrow neck which led into the land northward.

Alma 63:6 And behold, there were many of the Nephites who did enter therein and did sail forth with much provisions, and also many women and children; and they took their course northward. And thus ended the thirty and seventh year.

Alma 63:7 And in the thirty and eighth year, this man built other ships. And the first ship did also return, and many more people did enter into it; and they also took much provisions, and set out again to the land northward.

Alma 63:8 And it came to pass that they were never heard of more. And we suppose that they were drowned in the depths of the sea. And it came to pass that one other ship also did sail forth; and whither she did go we know not.

Alma 63:9 And it came to pass that in this year there were many people who went forth into the land northward. And thus ended the thirty and eighth year.

Alma 63:10 And it came to pass in the thirty and ninth year of the reign of the judges, Shiblon died also, and Corianton had gone forth to the land northward in a ship, to carry forth provisions unto the people who had gone forth into that land.

Alma 63:11 Therefore it became expedient for Shiblon to confer those sacred things, before his death, upon the son of Helaman, who was called Helaman, being called after the name of his father.

Alma 63:12 Now behold, all those engravings which were in the possession of Helaman were written and sent forth among the children of men throughout all the land, save it were those parts which had been commanded by Alma should not go forth.

Alma 63:13 Nevertheless, these things were to be kept sacred, and handed down from one generation to another; therefore, in this year, they had been conferred upon Helaman, before the death of Shiblon.

Alma 63:14 And it came to pass also in this year that there were some dissenters who had gone forth unto the Lamanites; and they were stirred up again to anger against the Nephites.

Alma 63:15 And also in this same year they came down with a numerous army to war against the people of Moronihah, or against the army of Moronihah, in the which they were beaten and driven back again to their own lands, suffering great loss.

Alma 63:16 And thus ended the thirty and ninth year of the reign of the judges over the people of Nephi.

Alma 63:17 And thus ended the account of Alma, and Helaman his son, and also Shiblon, who was his son.
