# Alma 17

Alma 17 (summary): The sons of Mosiah have the spirit of prophecy and of revelation—They go their several ways to declare the word to the Lamanites—Ammon goes to the land of Ishmael and becomes the servant of King Lamoni—Ammon saves the king’s flocks and slays his enemies at the water of Sebus. [Verses 1–3](../alma/17.xhtml#p1), about 77 B.C.; [verse 4](../alma/17.xhtml#p4), about 91–77 B.C.; and [verses 5–39](../alma/17.xhtml#p5), about 91 B.C.

Alma 17:1 And now it came to pass that as Alma was journeying from the land of Gideon southward, away to the land of Manti, behold, to his astonishment, he met with the sons of Mosiah journeying towards the land of Zarahemla.

Alma 17:2 Now these sons of Mosiah were with Alma at the time the angel first appeared unto him; therefore Alma did rejoice exceedingly to see his brethren; and what added more to his joy, they were still his brethren in the Lord; yea, and they had waxed strong in the knowledge of the truth; for they were men of a sound understanding and they had searched the scriptures diligently, that they might know the word of God.

Alma 17:3 But this is not all; they had given themselves to much prayer, and fasting; therefore they had the spirit of prophecy, and the spirit of revelation, and when they taught, they taught with power and authority of God.

Alma 17:4 And they had been teaching the word of God for the space of fourteen years among the Lamanites, having had much success in bringing many to the knowledge of the truth; yea, by the power of their words many were brought before the altar of God, to call on his name and confess their sins before him.

Alma 17:5 Now these are the circumstances which attended them in their journeyings, for they had many afflictions; they did suffer much, both in body and in mind, such as hunger, thirst and fatigue, and also much labor in the spirit.

Alma 17:6 Now these were their journeyings: Having taken leave of their father, Mosiah, in the first year of the judges; having refused the kingdom which their father was desirous to confer upon them, and also this was the minds of the people;

Alma 17:7 Nevertheless they departed out of the land of Zarahemla, and took their swords, and their spears, and their bows, and their arrows, and their slings; and this they did that they might provide food for themselves while in the wilderness.

Alma 17:8 And thus they departed into the wilderness with their numbers which they had selected, to go up to the land of Nephi, to preach the word of God unto the Lamanites.

Alma 17:9 And it came to pass that they journeyed many days in the wilderness, and they fasted much and prayed much that the Lord would grant unto them a portion of his Spirit to go with them, and abide with them, that they might be an instrument in the hands of God to bring, if it were possible, their brethren, the Lamanites, to the knowledge of the truth, to the knowledge of the baseness of the traditions of their fathers, which were not correct.

Alma 17:10 And it came to pass that the Lord did visit them with his Spirit, and said unto them: Be comforted. And they were comforted.

Alma 17:11 And the Lord said unto them also: Go forth among the Lamanites, thy brethren, and establish my word; yet ye shall be patient in long-suffering and afflictions, that ye may show forth good examples unto them in me, and I will make an instrument of thee in my hands unto the salvation of many souls.

Alma 17:12 And it came to pass that the hearts of the sons of Mosiah, and also those who were with them, took courage to go forth unto the Lamanites to declare unto them the word of God.

Alma 17:13 And it came to pass when they had arrived in the borders of the land of the Lamanites, that they separated themselves and departed one from another, trusting in the Lord that they should meet again at the close of their harvest; for they supposed that great was the work which they had undertaken.

Alma 17:14 And assuredly it was great, for they had undertaken to preach the word of God to a wild and a hardened and a ferocious people; a people who delighted in murdering the Nephites, and robbing and plundering them; and their hearts were set upon riches, or upon gold and silver, and precious stones; yet they sought to obtain these things by murdering and plundering, that they might not labor for them with their own hands.

Alma 17:15 Thus they were a very indolent people, many of whom did worship idols, and the curse of God had fallen upon them because of the traditions of their fathers; notwithstanding the promises of the Lord were extended unto them on the conditions of repentance.

Alma 17:16 Therefore, this was the cause for which the sons of Mosiah had undertaken the work, that perhaps they might bring them unto repentance; that perhaps they might bring them to know of the plan of redemption.

Alma 17:17 Therefore they separated themselves one from another, and went forth among them, every man alone, according to the word and power of God which was given unto him.

Alma 17:18 Now Ammon being the chief among them, or rather he did administer unto them, and he departed from them, after having blessed them according to their several stations, having imparted the word of God unto them, or administered unto them before his departure; and thus they took their several journeys throughout the land.

Alma 17:19 And Ammon went to the land of Ishmael, the land being called after the sons of Ishmael, who also became Lamanites.

Alma 17:20 And as Ammon entered the land of Ishmael, the Lamanites took him and bound him, as was their custom to bind all the Nephites who fell into their hands, and carry them before the king; and thus it was left to the pleasure of the king to slay them, or to retain them in captivity, or to cast them into prison, or to cast them out of his land, according to his will and pleasure.

Alma 17:21 And thus Ammon was carried before the king who was over the land of Ishmael; and his name was Lamoni; and he was a descendant of Ishmael.

Alma 17:22 And the king inquired of Ammon if it were his desire to dwell in the land among the Lamanites, or among his people.

Alma 17:23 And Ammon said unto him: Yea, I desire to dwell among this people for a time; yea, and perhaps until the day I die.

Alma 17:24 And it came to pass that king Lamoni was much pleased with Ammon, and caused that his bands should be loosed; and he would that Ammon should take one of his daughters to wife.

Alma 17:25 But Ammon said unto him: Nay, but I will be thy servant. Therefore Ammon became a servant to king Lamoni. And it came to pass that he was set among other servants to watch the flocks of Lamoni, according to the custom of the Lamanites.

Alma 17:26 And after he had been in the service of the king three days, as he was with the Lamanitish servants going forth with their flocks to the place of water, which was called the water of Sebus, and all the Lamanites drive their flocks hither, that they may have water—

Alma 17:27 Therefore, as Ammon and the servants of the king were driving forth their flocks to this place of water, behold, a certain number of the Lamanites, who had been with their flocks to water, stood and scattered the flocks of Ammon and the servants of the king, and they scattered them insomuch that they fled many ways.

Alma 17:28 Now the servants of the king began to murmur, saying: Now the king will slay us, as he has our brethren because their flocks were scattered by the wickedness of these men. And they began to weep exceedingly, saying: Behold, our flocks are scattered already.

Alma 17:29 Now they wept because of the fear of being slain. Now when Ammon saw this his heart was swollen within him with joy; for, said he, I will show forth my power unto these my fellow-servants, or the power which is in me, in restoring these flocks unto the king, that I may win the hearts of these my fellow-servants, that I may lead them to believe in my words.

Alma 17:30 And now, these were the thoughts of Ammon, when he saw the afflictions of those whom he termed to be his brethren.

Alma 17:31 And it came to pass that he flattered them by his words, saying: My brethren, be of good cheer and let us go in search of the flocks, and we will gather them together and bring them back unto the place of water; and thus we will preserve the flocks unto the king and he will not slay us.

Alma 17:32 And it came to pass that they went in search of the flocks, and they did follow Ammon, and they rushed forth with much swiftness and did head the flocks of the king, and did gather them together again to the place of water.

Alma 17:33 And those men again stood to scatter their flocks; but Ammon said unto his brethren: Encircle the flocks round about that they flee not; and I go and contend with these men who do scatter our flocks.

Alma 17:34 Therefore, they did as Ammon commanded them, and he went forth and stood to contend with those who stood by the waters of Sebus; and they were in number not a few.

Alma 17:35 Therefore they did not fear Ammon, for they supposed that one of their men could slay him according to their pleasure, for they knew not that the Lord had promised Mosiah that he would deliver his sons out of their hands; neither did they know anything concerning the Lord; therefore they delighted in the destruction of their brethren; and for this cause they stood to scatter the flocks of the king.

Alma 17:36 But Ammon stood forth and began to cast stones at them with his sling; yea, with mighty power he did sling stones amongst them; and thus he slew a certain number of them insomuch that they began to be astonished at his power; nevertheless they were angry because of the slain of their brethren, and they were determined that he should fall; therefore, seeing that they could not hit him with their stones, they came forth with clubs to slay him.

Alma 17:37 But behold, every man that lifted his club to smite Ammon, he smote off their arms with his sword; for he did withstand their blows by smiting their arms with the edge of his sword, insomuch that they began to be astonished, and began to flee before him; yea, and they were not few in number; and he caused them to flee by the strength of his arm.

Alma 17:38 Now six of them had fallen by the sling, but he slew none save it were their leader with his sword; and he smote off as many of their arms as were lifted against him, and they were not a few.

Alma 17:39 And when he had driven them afar off, he returned and they watered their flocks and returned them to the pasture of the king, and then went in unto the king, bearing the arms which had been smitten off by the sword of Ammon, of those who sought to slay him; and they were carried in unto the king for a testimony of the things which they had done.
