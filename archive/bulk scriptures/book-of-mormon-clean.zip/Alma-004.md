# Alma 4

Alma 4 (summary): Alma baptizes thousands of converts—Iniquity enters the Church, and the Church’s progress is hindered—Nephihah is appointed chief judge—Alma, as high priest, devotes himself to the ministry. About 86–83 B.C.

Alma 4:1 Now it came to pass in the sixth year of the reign of the judges over the people of Nephi, there were no contentions nor wars in the land of Zarahemla;

Alma 4:2 But the people were afflicted, yea, greatly afflicted for the loss of their brethren, and also for the loss of their flocks and herds, and also for the loss of their fields of grain, which were trodden under foot and destroyed by the Lamanites.

Alma 4:3 And so great were their afflictions that every soul had cause to mourn; and they believed that it was the judgments of God sent upon them because of their wickedness and their abominations; therefore they were awakened to a remembrance of their duty.

Alma 4:4 And they began to establish the church more fully; yea, and many were baptized in the waters of Sidon and were joined to the church of God; yea, they were baptized by the hand of Alma, who had been consecrated the high priest over the people of the church, by the hand of his father Alma.

Alma 4:5 And it came to pass in the seventh year of the reign of the judges there were about three thousand five hundred souls that united themselves to the church of God and were baptized. And thus ended the seventh year of the reign of the judges over the people of Nephi; and there was continual peace in all that time.

Alma 4:6 And it came to pass in the eighth year of the reign of the judges, that the people of the church began to wax proud, because of their exceeding riches, and their fine silks, and their fine-twined linen, and because of their many flocks and herds, and their gold and their silver, and all manner of precious things, which they had obtained by their industry; and in all these things were they lifted up in the pride of their eyes, for they began to wear very costly apparel.

Alma 4:7 Now this was the cause of much affliction to Alma, yea, and to many of the people whom Alma had consecrated to be teachers, and priests, and elders over the church; yea, many of them were sorely grieved for the wickedness which they saw had begun to be among their people.

Alma 4:8 For they saw and beheld with great sorrow that the people of the church began to be lifted up in the pride of their eyes, and to set their hearts upon riches and upon the vain things of the world, that they began to be scornful, one towards another, and they began to persecute those that did not believe according to their own will and pleasure.

Alma 4:9 And thus, in this eighth year of the reign of the judges, there began to be great contentions among the people of the church; yea, there were envyings, and strife, and malice, and persecutions, and pride, even to exceed the pride of those who did not belong to the church of God.

Alma 4:10 And thus ended the eighth year of the reign of the judges; and the wickedness of the church was a great stumbling-block to those who did not belong to the church; and thus the church began to fail in its progress.

Alma 4:11 And it came to pass in the commencement of the ninth year, Alma saw the wickedness of the church, and he saw also that the example of the church began to lead those who were unbelievers on from one piece of iniquity to another, thus bringing on the destruction of the people.

Alma 4:12 Yea, he saw great inequality among the people, some lifting themselves up with their pride, despising others, turning their backs upon the needy and the naked and those who were hungry, and those who were athirst, and those who were sick and afflicted.

Alma 4:13 Now this was a great cause for lamentations among the people, while others were abasing themselves, succoring those who stood in need of their succor, such as imparting their substance to the poor and the needy, feeding the hungry, and suffering all manner of afflictions, for Christ’s sake, who should come according to the spirit of prophecy;

Alma 4:14 Looking forward to that day, thus retaining a remission of their sins; being filled with great joy because of the resurrection of the dead, according to the will and power and deliverance of Jesus Christ from the bands of death.

Alma 4:15 And now it came to pass that Alma, having seen the afflictions of the humble followers of God, and the persecutions which were heaped upon them by the remainder of his people, and seeing all their inequality, began to be very sorrowful; nevertheless the Spirit of the Lord did not fail him.

Alma 4:16 And he selected a wise man who was among the elders of the church, and gave him power according to the voice of the people, that he might have power to enact laws according to the laws which had been given, and to put them in force according to the wickedness and the crimes of the people.

Alma 4:17 Now this man’s name was Nephihah, and he was appointed chief judge; and he sat in the judgment-seat to judge and to govern the people.

Alma 4:18 Now Alma did not grant unto him the office of being high priest over the church, but he retained the office of high priest unto himself; but he delivered the judgment-seat unto Nephihah.

Alma 4:19 And this he did that he himself might go forth among his people, or among the people of Nephi, that he might preach the word of God unto them, to stir them up in remembrance of their duty, and that he might pull down, by the word of God, all the pride and craftiness and all the contentions which were among his people, seeing no way that he might reclaim them save it were in bearing down in pure testimony against them.

Alma 4:20 And thus in the commencement of the ninth year of the reign of the judges over the people of Nephi, Alma delivered up the judgment-seat to Nephihah, and confined himself wholly to the high priesthood of the holy order of God, to the testimony of the word, according to the spirit of revelation and prophecy.
