# 2 Nephi 29

2 Nephi 29 (summary): Many Gentiles will reject the Book of Mormon—They will say, We need no more Bible—The Lord speaks to many nations—He will judge the world out of the books which will be written. About 559–545 B.C.

2 Nephi 29:1 But behold, there shall be many—at that day when I shall proceed to do a marvelous work among them, that I may remember my covenants which I have made unto the children of men, that I may set my hand again the second time to recover my people, which are of the house of Israel;

2 Nephi 29:2 And also, that I may remember the promises which I have made unto thee, Nephi, and also unto thy father, that I would remember your seed; and that the words of your seed should proceed forth out of my mouth unto your seed; and my words shall hiss forth unto the ends of the earth, for a standard unto my people, which are of the house of Israel;

2 Nephi 29:3 And because my words shall hiss forth—many of the Gentiles shall say: A Bible! A Bible! We have got a Bible, and there cannot be any more Bible.

2 Nephi 29:4 But thus saith the Lord God: O fools, they shall have a Bible; and it shall proceed forth from the Jews, mine ancient covenant people. And what thank they the Jews for the Bible which they receive from them? Yea, what do the Gentiles mean? Do they remember the travails, and the labors, and the pains of the Jews, and their diligence unto me, in bringing forth salvation unto the Gentiles?

2 Nephi 29:5 O ye Gentiles, have ye remembered the Jews, mine ancient covenant people? Nay; but ye have cursed them, and have hated them, and have not sought to recover them. But behold, I will return all these things upon your own heads; for I the Lord have not forgotten my people.

2 Nephi 29:6 Thou fool, that shall say: A Bible, we have got a Bible, and we need no more Bible. Have ye obtained a Bible save it were by the Jews?

2 Nephi 29:7 Know ye not that there are more nations than one? Know ye not that I, the Lord your God, have created all men, and that I remember those who are upon the isles of the sea; and that I rule in the heavens above and in the earth beneath; and I bring forth my word unto the children of men, yea, even upon all the nations of the earth?

2 Nephi 29:8 Wherefore murmur ye, because that ye shall receive more of my word? Know ye not that the testimony of two nations is a witness unto you that I am God, that I remember one nation like unto another? Wherefore, I speak the same words unto one nation like unto another. And when the two nations shall run together the testimony of the two nations shall run together also.

2 Nephi 29:9 And I do this that I may prove unto many that I am the same yesterday, today, and forever; and that I speak forth my words according to mine own pleasure. And because that I have spoken one word ye need not suppose that I cannot speak another; for my work is not yet finished; neither shall it be until the end of man, neither from that time henceforth and forever.

2 Nephi 29:10 Wherefore, because that ye have a Bible ye need not suppose that it contains all my words; neither need ye suppose that I have not caused more to be written.

2 Nephi 29:11 For I command all men, both in the east and in the west, and in the north, and in the south, and in the islands of the sea, that they shall write the words which I speak unto them; for out of the books which shall be written I will judge the world, every man according to their works, according to that which is written.

2 Nephi 29:12 For behold, I shall speak unto the Jews and they shall write it; and I shall also speak unto the Nephites and they shall write it; and I shall also speak unto the other tribes of the house of Israel, which I have led away, and they shall write it; and I shall also speak unto all nations of the earth and they shall write it.

2 Nephi 29:13 And it shall come to pass that the Jews shall have the words of the Nephites, and the Nephites shall have the words of the Jews; and the Nephites and the Jews shall have the words of the lost tribes of Israel; and the lost tribes of Israel shall have the words of the Nephites and the Jews.

2 Nephi 29:14 And it shall come to pass that my people, which are of the house of Israel, shall be gathered home unto the lands of their possessions; and my word also shall be gathered in one. And I will show unto them that fight against my word and against my people, who are of the house of Israel, that I am God, and that I covenanted with Abraham that I would remember his seed forever.
