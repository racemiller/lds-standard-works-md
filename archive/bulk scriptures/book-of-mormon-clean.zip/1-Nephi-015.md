# 1 Nephi 15

1 Nephi 15 (summary): Lehi’s seed are to receive the gospel from the Gentiles in the latter days—The gathering of Israel is likened unto an olive tree whose natural branches will be grafted in again—Nephi interprets the vision of the tree of life and speaks of the justice of God in dividing the wicked from the righteous. About 600–592 B.C.

1 Nephi 15:1 And it came to pass that after I, Nephi, had been carried away in the Spirit, and seen all these things, I returned to the tent of my father.

1 Nephi 15:2 And it came to pass that I beheld my brethren, and they were disputing one with another concerning the things which my father had spoken unto them.

1 Nephi 15:3 For he truly spake many great things unto them, which were hard to be understood, save a man should inquire of the Lord; and they being hard in their hearts, therefore they did not look unto the Lord as they ought.

1 Nephi 15:4 And now I, Nephi, was grieved because of the hardness of their hearts, and also, because of the things which I had seen, and knew they must unavoidably come to pass because of the great wickedness of the children of men.

1 Nephi 15:5 And it came to pass that I was overcome because of my afflictions, for I considered that mine afflictions were great above all, because of the destruction of my people, for I had beheld their fall.

1 Nephi 15:6 And it came to pass that after I had received strength I spake unto my brethren, desiring to know of them the cause of their disputations.

1 Nephi 15:7 And they said: Behold, we cannot understand the words which our father hath spoken concerning the natural branches of the olive tree, and also concerning the Gentiles.

1 Nephi 15:8 And I said unto them: Have ye inquired of the Lord?

1 Nephi 15:9 And they said unto me: We have not; for the Lord maketh no such thing known unto us.

1 Nephi 15:10 Behold, I said unto them: How is it that ye do not keep the commandments of the Lord? How is it that ye will perish, because of the hardness of your hearts?

1 Nephi 15:11 Do ye not remember the things which the Lord hath said?—If ye will not harden your hearts, and ask me in faith, believing that ye shall receive, with diligence in keeping my commandments, surely these things shall be made known unto you.

1 Nephi 15:12 Behold, I say unto you, that the house of Israel was compared unto an olive tree, by the Spirit of the Lord which was in our father; and behold are we not broken off from the house of Israel, and are we not a branch of the house of Israel?

1 Nephi 15:13 And now, the thing which our father meaneth concerning the grafting in of the natural branches through the fulness of the Gentiles, is, that in the latter days, when our seed shall have dwindled in unbelief, yea, for the space of many years, and many generations after the Messiah shall be manifested in body unto the children of men, then shall the fulness of the gospel of the Messiah come unto the Gentiles, and from the Gentiles unto the remnant of our seed—

1 Nephi 15:14 And at that day shall the remnant of our seed know that they are of the house of Israel, and that they are the covenant people of the Lord; and then shall they know and come to the knowledge of their forefathers, and also to the knowledge of the gospel of their Redeemer, which was ministered unto their fathers by him; wherefore, they shall come to the knowledge of their Redeemer and the very points of his doctrine, that they may know how to come unto him and be saved.

1 Nephi 15:15 And then at that day will they not rejoice and give praise unto their everlasting God, their rock and their salvation? Yea, at that day, will they not receive the strength and nourishment from the true vine? Yea, will they not come unto the true fold of God?

1 Nephi 15:16 Behold, I say unto you, Yea; they shall be remembered again among the house of Israel; they shall be grafted in, being a natural branch of the olive tree, into the true olive tree.

1 Nephi 15:17 And this is what our father meaneth; and he meaneth that it will not come to pass until after they are scattered by the Gentiles; and he meaneth that it shall come by way of the Gentiles, that the Lord may show his power unto the Gentiles, for the very cause that he shall be rejected of the Jews, or of the house of Israel.

1 Nephi 15:18 Wherefore, our father hath not spoken of our seed alone, but also of all the house of Israel, pointing to the covenant which should be fulfilled in the latter days; which covenant the Lord made to our father Abraham, saying: In thy seed shall all the kindreds of the earth be blessed.

1 Nephi 15:19 And it came to pass that I, Nephi, spake much unto them concerning these things; yea, I spake unto them concerning the restoration of the Jews in the latter days.

1 Nephi 15:20 And I did rehearse unto them the words of Isaiah, who spake concerning the restoration of the Jews, or of the house of Israel; and after they were restored they should no more be confounded, neither should they be scattered again. And it came to pass that I did speak many words unto my brethren, that they were pacified and did humble themselves before the Lord.

1 Nephi 15:21 And it came to pass that they did speak unto me again, saying: What meaneth this thing which our father saw in a dream? What meaneth the tree which he saw?

1 Nephi 15:22 And I said unto them: It was a representation of the tree of life.

1 Nephi 15:23 And they said unto me: What meaneth the rod of iron which our father saw, that led to the tree?

1 Nephi 15:24 And I said unto them that it was the word of God; and whoso would hearken unto the word of God, and would hold fast unto it, they would never perish; neither could the temptations and the fiery darts of the adversary overpower them unto blindness, to lead them away to destruction.

1 Nephi 15:25 Wherefore, I, Nephi, did exhort them to give heed unto the word of the Lord; yea, I did exhort them with all the energies of my soul, and with all the faculty which I possessed, that they would give heed to the word of God and remember to keep his commandments always in all things.

1 Nephi 15:26 And they said unto me: What meaneth the river of water which our father saw?

1 Nephi 15:27 And I said unto them that the water which my father saw was filthiness; and so much was his mind swallowed up in other things that he beheld not the filthiness of the water.

1 Nephi 15:28 And I said unto them that it was an awful gulf, which separated the wicked from the tree of life, and also from the saints of God.

1 Nephi 15:29 And I said unto them that it was a representation of that awful hell, which the angel said unto me was prepared for the wicked.

1 Nephi 15:30 And I said unto them that our father also saw that the justice of God did also divide the wicked from the righteous; and the brightness thereof was like unto the brightness of a flaming fire, which ascendeth up unto God forever and ever, and hath no end.

1 Nephi 15:31 And they said unto me: Doth this thing mean the torment of the body in the days of probation, or doth it mean the final state of the soul after the death of the temporal body, or doth it speak of the things which are temporal?

1 Nephi 15:32 And it came to pass that I said unto them that it was a representation of things both temporal and spiritual; for the day should come that they must be judged of their works, yea, even the works which were done by the temporal body in their days of probation.

1 Nephi 15:33 Wherefore, if they should die in their wickedness they must be cast off also, as to the things which are spiritual, which are pertaining to righteousness; wherefore, they must be brought to stand before God, to be judged of their works; and if their works have been filthiness they must needs be filthy; and if they be filthy it must needs be that they cannot dwell in the kingdom of God; if so, the kingdom of God must be filthy also.

1 Nephi 15:34 But behold, I say unto you, the kingdom of God is not filthy, and there cannot any unclean thing enter into the kingdom of God; wherefore there must needs be a place of filthiness prepared for that which is filthy.

1 Nephi 15:35 And there is a place prepared, yea, even that awful hell of which I have spoken, and the devil is the preparator of it; wherefore the final state of the souls of men is to dwell in the kingdom of God, or to be cast out because of that justice of which I have spoken.

1 Nephi 15:36 Wherefore, the wicked are rejected from the righteous, and also from that tree of life, whose fruit is most precious and most desirable above all other fruits; yea, and it is the greatest of all the gifts of God. And thus I spake unto my brethren. Amen.
