# Ether 1

Ether 1 (summary): Moroni abridges the writings of Ether—Ether’s genealogy is set forth—The language of the Jaredites is not confounded at the Tower of Babel—The Lord promises to lead them to a choice land and make them a great nation.

Ether 1:1 And now I, Moroni, proceed to give an account of those ancient inhabitants who were destroyed by the hand of the Lord upon the face of this north country.

Ether 1:2 And I take mine account from the twenty and four plates which were found by the people of Limhi, which is called the Book of Ether.

Ether 1:3 And as I suppose that the first part of this record, which speaks concerning the creation of the world, and also of Adam, and an account from that time even to the great tower, and whatsoever things transpired among the children of men until that time, is had among the Jews—

Ether 1:4 Therefore I do not write those things which transpired from the days of Adam until that time; but they are had upon the plates; and whoso findeth them, the same will have power that he may get the full account.

Ether 1:5 But behold, I give not the full account, but a part of the account I give, from the tower down until they were destroyed.

Ether 1:6 And on this wise do I give the account. He that wrote this record was Ether, and he was a descendant of Coriantor.

Ether 1:7 Coriantor was the son of Moron.

Ether 1:8 And Moron was the son of Ethem.

Ether 1:9 And Ethem was the son of Ahah.

Ether 1:10 And Ahah was the son of Seth.

Ether 1:11 And Seth was the son of Shiblon.

Ether 1:12 And Shiblon was the son of Com.

Ether 1:13 And Com was the son of Coriantum.

Ether 1:14 And Coriantum was the son of Amnigaddah.

Ether 1:15 And Amnigaddah was the son of Aaron.

Ether 1:16 And Aaron was a descendant of Heth, who was the son of Hearthom.

Ether 1:17 And Hearthom was the son of Lib.

Ether 1:18 And Lib was the son of Kish.

Ether 1:19 And Kish was the son of Corom.

Ether 1:20 And Corom was the son of Levi.

Ether 1:21 And Levi was the son of Kim.

Ether 1:22 And Kim was the son of Morianton.

Ether 1:23 And Morianton was a descendant of Riplakish.

Ether 1:24 And Riplakish was the son of Shez.

Ether 1:25 And Shez was the son of Heth.

Ether 1:26 And Heth was the son of Com.

Ether 1:27 And Com was the son of Coriantum.

Ether 1:28 And Coriantum was the son of Emer.

Ether 1:29 And Emer was the son of Omer.

Ether 1:30 And Omer was the son of Shule.

Ether 1:31 And Shule was the son of Kib.

Ether 1:32 And Kib was the son of Orihah, who was the son of Jared;

Ether 1:33 Which Jared came forth with his brother and their families, with some others and their families, from the great tower, at the time the Lord confounded the language of the people, and swore in his wrath that they should be scattered upon all the face of the earth; and according to the word of the Lord the people were scattered.

Ether 1:34 And the brother of Jared being a large and mighty man, and a man highly favored of the Lord, Jared, his brother, said unto him: Cry unto the Lord, that he will not confound us that we may not understand our words.

Ether 1:35 And it came to pass that the brother of Jared did cry unto the Lord, and the Lord had compassion upon Jared; therefore he did not confound the language of Jared; and Jared and his brother were not confounded.

Ether 1:36 Then Jared said unto his brother: Cry again unto the Lord, and it may be that he will turn away his anger from them who are our friends, that he confound not their language.

Ether 1:37 And it came to pass that the brother of Jared did cry unto the Lord, and the Lord had compassion upon their friends and their families also, that they were not confounded.

Ether 1:38 And it came to pass that Jared spake again unto his brother, saying: Go and inquire of the Lord whether he will drive us out of the land, and if he will drive us out of the land, cry unto him whither we shall go. And who knoweth but the Lord will carry us forth into a land which is choice above all the earth? And if it so be, let us be faithful unto the Lord, that we may receive it for our inheritance.

Ether 1:39 And it came to pass that the brother of Jared did cry unto the Lord according to that which had been spoken by the mouth of Jared.

Ether 1:40 And it came to pass that the Lord did hear the brother of Jared, and had compassion upon him, and said unto him:

Ether 1:41 Go to and gather together thy flocks, both male and female, of every kind; and also of the seed of the earth of every kind; and thy families; and also Jared thy brother and his family; and also thy friends and their families, and the friends of Jared and their families.

Ether 1:42 And when thou hast done this thou shalt go at the head of them down into the valley which is northward. And there will I meet thee, and I will go before thee into a land which is choice above all the lands of the earth.

Ether 1:43 And there will I bless thee and thy seed, and raise up unto me of thy seed, and of the seed of thy brother, and they who shall go with thee, a great nation. And there shall be none greater than the nation which I will raise up unto me of thy seed, upon all the face of the earth. And thus I will do unto thee because this long time ye have cried unto me.
