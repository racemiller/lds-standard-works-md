# 1 Nephi 17

1 Nephi 17 (summary): Nephi is commanded to build a ship—His brethren oppose him—He exhorts them by recounting the history of God’s dealings with Israel—Nephi is filled with the power of God—His brethren are forbidden to touch him, lest they wither as a dried reed. About 592–591 B.C.

1 Nephi 17:1 And it came to pass that we did again take our journey in the wilderness; and we did travel nearly eastward from that time forth. And we did travel and wade through much affliction in the wilderness; and our women did bear children in the wilderness.

1 Nephi 17:2 And so great were the blessings of the Lord upon us, that while we did live upon raw meat in the wilderness, our women did give plenty of suck for their children, and were strong, yea, even like unto the men; and they began to bear their journeyings without murmurings.

1 Nephi 17:3 And thus we see that the commandments of God must be fulfilled. And if it so be that the children of men keep the commandments of God he doth nourish them, and strengthen them, and provide means whereby they can accomplish the thing which he has commanded them; wherefore, he did provide means for us while we did sojourn in the wilderness.

1 Nephi 17:4 And we did sojourn for the space of many years, yea, even eight years in the wilderness.

1 Nephi 17:5 And we did come to the land which we called Bountiful, because of its much fruit and also wild honey; and all these things were prepared of the Lord that we might not perish. And we beheld the sea, which we called Irreantum, which, being interpreted, is many waters.

1 Nephi 17:6 And it came to pass that we did pitch our tents by the seashore; and notwithstanding we had suffered many afflictions and much difficulty, yea, even so much that we cannot write them all, we were exceedingly rejoiced when we came to the seashore; and we called the place Bountiful, because of its much fruit.

1 Nephi 17:7 And it came to pass that after I, Nephi, had been in the land of Bountiful for the space of many days, the voice of the Lord came unto me, saying: Arise, and get thee into the mountain. And it came to pass that I arose and went up into the mountain, and cried unto the Lord.

1 Nephi 17:8 And it came to pass that the Lord spake unto me, saying: Thou shalt construct a ship, after the manner which I shall show thee, that I may carry thy people across these waters.

1 Nephi 17:9 And I said: Lord, whither shall I go that I may find ore to molten, that I may make tools to construct the ship after the manner which thou hast shown unto me?

1 Nephi 17:10 And it came to pass that the Lord told me whither I should go to find ore, that I might make tools.

1 Nephi 17:11 And it came to pass that I, Nephi, did make a bellows wherewith to blow the fire, of the skins of beasts; and after I had made a bellows, that I might have wherewith to blow the fire, I did smite two stones together that I might make fire.

1 Nephi 17:12 For the Lord had not hitherto suffered that we should make much fire, as we journeyed in the wilderness; for he said: I will make thy food become sweet, that ye cook it not;

1 Nephi 17:13 And I will also be your light in the wilderness; and I will prepare the way before you, if it so be that ye shall keep my commandments; wherefore, inasmuch as ye shall keep my commandments ye shall be led towards the promised land; and ye shall know that it is by me that ye are led.

1 Nephi 17:14 Yea, and the Lord said also that: After ye have arrived in the promised land, ye shall know that I, the Lord, am God; and that I, the Lord, did deliver you from destruction; yea, that I did bring you out of the land of Jerusalem.

1 Nephi 17:15 Wherefore, I, Nephi, did strive to keep the commandments of the Lord, and I did exhort my brethren to faithfulness and diligence.

1 Nephi 17:16 And it came to pass that I did make tools of the ore which I did molten out of the rock.

1 Nephi 17:17 And when my brethren saw that I was about to build a ship, they began to murmur against me, saying: Our brother is a fool, for he thinketh that he can build a ship; yea, and he also thinketh that he can cross these great waters.

1 Nephi 17:18 And thus my brethren did complain against me, and were desirous that they might not labor, for they did not believe that I could build a ship; neither would they believe that I was instructed of the Lord.

1 Nephi 17:19 And now it came to pass that I, Nephi, was exceedingly sorrowful because of the hardness of their hearts; and now when they saw that I began to be sorrowful they were glad in their hearts, insomuch that they did rejoice over me, saying: We knew that ye could not construct a ship, for we knew that ye were lacking in judgment; wherefore, thou canst not accomplish so great a work.

1 Nephi 17:20 And thou art like unto our father, led away by the foolish imaginations of his heart; yea, he hath led us out of the land of Jerusalem, and we have wandered in the wilderness for these many years; and our women have toiled, being big with child; and they have borne children in the wilderness and suffered all things, save it were death; and it would have been better that they had died before they came out of Jerusalem than to have suffered these afflictions.

1 Nephi 17:21 Behold, these many years we have suffered in the wilderness, which time we might have enjoyed our possessions and the land of our inheritance; yea, and we might have been happy.

1 Nephi 17:22 And we know that the people who were in the land of Jerusalem were a righteous people; for they kept the statutes and judgments of the Lord, and all his commandments, according to the law of Moses; wherefore, we know that they are a righteous people; and our father hath judged them, and hath led us away because we would hearken unto his words; yea, and our brother is like unto him. And after this manner of language did my brethren murmur and complain against us.

1 Nephi 17:23 And it came to pass that I, Nephi, spake unto them, saying: Do ye believe that our fathers, who were the children of Israel, would have been led away out of the hands of the Egyptians if they had not hearkened unto the words of the Lord?

1 Nephi 17:24 Yea, do ye suppose that they would have been led out of bondage, if the Lord had not commanded Moses that he should lead them out of bondage?

1 Nephi 17:25 Now ye know that the children of Israel were in bondage; and ye know that they were laden with tasks, which were grievous to be borne; wherefore, ye know that it must needs be a good thing for them, that they should be brought out of bondage.

1 Nephi 17:26 Now ye know that Moses was commanded of the Lord to do that great work; and ye know that by his word the waters of the Red Sea were divided hither and thither, and they passed through on dry ground.

1 Nephi 17:27 But ye know that the Egyptians were drowned in the Red Sea, who were the armies of Pharaoh.

1 Nephi 17:28 And ye also know that they were fed with manna in the wilderness.

1 Nephi 17:29 Yea, and ye also know that Moses, by his word according to the power of God which was in him, smote the rock, and there came forth water, that the children of Israel might quench their thirst.

1 Nephi 17:30 And notwithstanding they being led, the Lord their God, their Redeemer, going before them, leading them by day and giving light unto them by night, and doing all things for them which were expedient for man to receive, they hardened their hearts and blinded their minds, and reviled against Moses and against the true and living God.

1 Nephi 17:31 And it came to pass that according to his word he did destroy them; and according to his word he did lead them; and according to his word he did do all things for them; and there was not any thing done save it were by his word.

1 Nephi 17:32 And after they had crossed the river Jordan he did make them mighty unto the driving out of the children of the land, yea, unto the scattering them to destruction.

1 Nephi 17:33 And now, do ye suppose that the children of this land, who were in the land of promise, who were driven out by our fathers, do ye suppose that they were righteous? Behold, I say unto you, Nay.

1 Nephi 17:34 Do ye suppose that our fathers would have been more choice than they if they had been righteous? I say unto you, Nay.

1 Nephi 17:35 Behold, the Lord esteemeth all flesh in one; he that is righteous is favored of God. But behold, this people had rejected every word of God, and they were ripe in iniquity; and the fulness of the wrath of God was upon them; and the Lord did curse the land against them, and bless it unto our fathers; yea, he did curse it against them unto their destruction, and he did bless it unto our fathers unto their obtaining power over it.

1 Nephi 17:36 Behold, the Lord hath created the earth that it should be inhabited; and he hath created his children that they should possess it.

1 Nephi 17:37 And he raiseth up a righteous nation, and destroyeth the nations of the wicked.

1 Nephi 17:38 And he leadeth away the righteous into precious lands, and the wicked he destroyeth, and curseth the land unto them for their sakes.

1 Nephi 17:39 He ruleth high in the heavens, for it is his throne, and this earth is his footstool.

1 Nephi 17:40 And he loveth those who will have him to be their God. Behold, he loved our fathers, and he covenanted with them, yea, even Abraham, Isaac, and Jacob; and he remembered the covenants which he had made; wherefore, he did bring them out of the land of Egypt.

1 Nephi 17:41 And he did straiten them in the wilderness with his rod; for they hardened their hearts, even as ye have; and the Lord straitened them because of their iniquity. He sent fiery flying serpents among them; and after they were bitten he prepared a way that they might be healed; and the labor which they had to perform was to look; and because of the simpleness of the way, or the easiness of it, there were many who perished.

1 Nephi 17:42 And they did harden their hearts from time to time, and they did revile against Moses, and also against God; nevertheless, ye know that they were led forth by his matchless power into the land of promise.

1 Nephi 17:43 And now, after all these things, the time has come that they have become wicked, yea, nearly unto ripeness; and I know not but they are at this day about to be destroyed; for I know that the day must surely come that they must be destroyed, save a few only, who shall be led away into captivity.

1 Nephi 17:44 Wherefore, the Lord commanded my father that he should depart into the wilderness; and the Jews also sought to take away his life; yea, and ye also have sought to take away his life; wherefore, ye are murderers in your hearts and ye are like unto them.

1 Nephi 17:45 Ye are swift to do iniquity but slow to remember the Lord your God. Ye have seen an angel, and he spake unto you; yea, ye have heard his voice from time to time; and he hath spoken unto you in a still small voice, but ye were past feeling, that ye could not feel his words; wherefore, he has spoken unto you like unto the voice of thunder, which did cause the earth to shake as if it were to divide asunder.

1 Nephi 17:46 And ye also know that by the power of his almighty word he can cause the earth that it shall pass away; yea, and ye know that by his word he can cause the rough places to be made smooth, and smooth places shall be broken up. O, then, why is it, that ye can be so hard in your hearts?

1 Nephi 17:47 Behold, my soul is rent with anguish because of you, and my heart is pained; I fear lest ye shall be cast off forever. Behold, I am full of the Spirit of God, insomuch that my frame has no strength.

1 Nephi 17:48 And now it came to pass that when I had spoken these words they were angry with me, and were desirous to throw me into the depths of the sea; and as they came forth to lay their hands upon me I spake unto them, saying: In the name of the Almighty God, I command you that ye touch me not, for I am filled with the power of God, even unto the consuming of my flesh; and whoso shall lay his hands upon me shall wither even as a dried reed; and he shall be as naught before the power of God, for God shall smite him.

1 Nephi 17:49 And it came to pass that I, Nephi, said unto them that they should murmur no more against their father; neither should they withhold their labor from me, for God had commanded me that I should build a ship.

1 Nephi 17:50 And I said unto them: If God had commanded me to do all things I could do them. If he should command me that I should say unto this water, be thou earth, it should be earth; and if I should say it, it would be done.

1 Nephi 17:51 And now, if the Lord has such great power, and has wrought so many miracles among the children of men, how is it that he cannot instruct me, that I should build a ship?

1 Nephi 17:52 And it came to pass that I, Nephi, said many things unto my brethren, insomuch that they were confounded and could not contend against me; neither durst they lay their hands upon me nor touch me with their fingers, even for the space of many days. Now they durst not do this lest they should wither before me, so powerful was the Spirit of God; and thus it had wrought upon them.

1 Nephi 17:53 And it came to pass that the Lord said unto me: Stretch forth thine hand again unto thy brethren, and they shall not wither before thee, but I will shock them, saith the Lord, and this will I do, that they may know that I am the Lord their God.

1 Nephi 17:54 And it came to pass that I stretched forth my hand unto my brethren, and they did not wither before me; but the Lord did shake them, even according to the word which he had spoken.

1 Nephi 17:55 And now, they said: We know of a surety that the Lord is with thee, for we know that it is the power of the Lord that has shaken us. And they fell down before me, and were about to worship me, but I would not suffer them, saying: I am thy brother, yea, even thy younger brother; wherefore, worship the Lord thy God, and honor thy father and thy mother, that thy days may be long in the land which the Lord thy God shall give thee.
