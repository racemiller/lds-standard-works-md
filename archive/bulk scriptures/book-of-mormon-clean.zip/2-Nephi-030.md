# 2 Nephi 30

2 Nephi 30 (summary): Converted Gentiles will be numbered with the covenant people—Many Lamanites and Jews will believe the word and become delightsome—Israel will be restored and the wicked destroyed. About 559–545 B.C.

2 Nephi 30:1 And now behold, my beloved brethren, I would speak unto you; for I, Nephi, would not suffer that ye should suppose that ye are more righteous than the Gentiles shall be. For behold, except ye shall keep the commandments of God ye shall all likewise perish; and because of the words which have been spoken ye need not suppose that the Gentiles are utterly destroyed.

2 Nephi 30:2 For behold, I say unto you that as many of the Gentiles as will repent are the covenant people of the Lord; and as many of the Jews as will not repent shall be cast off; for the Lord covenanteth with none save it be with them that repent and believe in his Son, who is the Holy One of Israel.

2 Nephi 30:3 And now, I would prophesy somewhat more concerning the Jews and the Gentiles. For after the book of which I have spoken shall come forth, and be written unto the Gentiles, and sealed up again unto the Lord, there shall be many which shall believe the words which are written; and they shall carry them forth unto the remnant of our seed.

2 Nephi 30:4 And then shall the remnant of our seed know concerning us, how that we came out from Jerusalem, and that they are descendants of the Jews.

2 Nephi 30:5 And the gospel of Jesus Christ shall be declared among them; wherefore, they shall be restored unto the knowledge of their fathers, and also to the knowledge of Jesus Christ, which was had among their fathers.

2 Nephi 30:6 And then shall they rejoice; for they shall know that it is a blessing unto them from the hand of God; and their scales of darkness shall begin to fall from their eyes; and many generations shall not pass away among them, save they shall be a pure and a delightsome people.

2 Nephi 30:7 And it shall come to pass that the Jews which are scattered also shall begin to believe in Christ; and they shall begin to gather in upon the face of the land; and as many as shall believe in Christ shall also become a delightsome people.

2 Nephi 30:8 And it shall come to pass that the Lord God shall commence his work among all nations, kindreds, tongues, and people, to bring about the restoration of his people upon the earth.

2 Nephi 30:9 And with righteousness shall the Lord God judge the poor, and reprove with equity for the meek of the earth. And he shall smite the earth with the rod of his mouth; and with the breath of his lips shall he slay the wicked.

2 Nephi 30:10 For the time speedily cometh that the Lord God shall cause a great division among the people, and the wicked will he destroy; and he will spare his people, yea, even if it so be that he must destroy the wicked by fire.

2 Nephi 30:11 And righteousness shall be the girdle of his loins, and faithfulness the girdle of his reins.

2 Nephi 30:12 And then shall the wolf dwell with the lamb; and the leopard shall lie down with the kid, and the calf, and the young lion, and the fatling, together; and a little child shall lead them.

2 Nephi 30:13 And the cow and the bear shall feed; their young ones shall lie down together; and the lion shall eat straw like the ox.

2 Nephi 30:14 And the sucking child shall play on the hole of the asp, and the weaned child shall put his hand on the cockatrice’s den.

2 Nephi 30:15 They shall not hurt nor destroy in all my holy mountain; for the earth shall be full of the knowledge of the Lord as the waters cover the sea.

2 Nephi 30:16 Wherefore, the things of all nations shall be made known; yea, all things shall be made known unto the children of men.

2 Nephi 30:17 There is nothing which is secret save it shall be revealed; there is no work of darkness save it shall be made manifest in the light; and there is nothing which is sealed upon the earth save it shall be loosed.

2 Nephi 30:18 Wherefore, all things which have been revealed unto the children of men shall at that day be revealed; and Satan shall have power over the hearts of the children of men no more, for a long time. And now, my beloved brethren, I make an end of my sayings.
