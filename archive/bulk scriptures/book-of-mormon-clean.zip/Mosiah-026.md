# Mosiah 26

Mosiah 26 (summary): Many members of the Church are led into sin by unbelievers—Alma is promised eternal life—Those who repent and are baptized gain forgiveness—Church members in sin who repent and confess to Alma and to the Lord will be forgiven; otherwise, they will not be numbered among the people of the Church. About 120–100 B.C.

Mosiah 26:1 Now it came to pass that there were many of the rising generation that could not understand the words of king Benjamin, being little children at the time he spake unto his people; and they did not believe the tradition of their fathers.

Mosiah 26:2 They did not believe what had been said concerning the resurrection of the dead, neither did they believe concerning the coming of Christ.

Mosiah 26:3 And now because of their unbelief they could not understand the word of God; and their hearts were hardened.

Mosiah 26:4 And they would not be baptized; neither would they join the church. And they were a separate people as to their faith, and remained so ever after, even in their carnal and sinful state; for they would not call upon the Lord their God.

Mosiah 26:5 And now in the reign of Mosiah they were not half so numerous as the people of God; but because of the dissensions among the brethren they became more numerous.

Mosiah 26:6 For it came to pass that they did deceive many with their flattering words, who were in the church, and did cause them to commit many sins; therefore it became expedient that those who committed sin, that were in the church, should be admonished by the church.

Mosiah 26:7 And it came to pass that they were brought before the priests, and delivered up unto the priests by the teachers; and the priests brought them before Alma, who was the high priest.

Mosiah 26:8 Now king Mosiah had given Alma the authority over the church.

Mosiah 26:9 And it came to pass that Alma did not know concerning them; but there were many witnesses against them; yea, the people stood and testified of their iniquity in abundance.

Mosiah 26:10 Now there had not any such thing happened before in the church; therefore Alma was troubled in his spirit, and he caused that they should be brought before the king.

Mosiah 26:11 And he said unto the king: Behold, here are many whom we have brought before thee, who are accused of their brethren; yea, and they have been taken in divers iniquities. And they do not repent of their iniquities; therefore we have brought them before thee, that thou mayest judge them according to their crimes.

Mosiah 26:12 But king Mosiah said unto Alma: Behold, I judge them not; therefore I deliver them into thy hands to be judged.

Mosiah 26:13 And now the spirit of Alma was again troubled; and he went and inquired of the Lord what he should do concerning this matter, for he feared that he should do wrong in the sight of God.

Mosiah 26:14 And it came to pass that after he had poured out his whole soul to God, the voice of the Lord came to him, saying:

Mosiah 26:15 Blessed art thou, Alma, and blessed are they who were baptized in the waters of Mormon. Thou art blessed because of thy exceeding faith in the words alone of my servant Abinadi.

Mosiah 26:16 And blessed are they because of their exceeding faith in the words alone which thou hast spoken unto them.

Mosiah 26:17 And blessed art thou because thou hast established a church among this people; and they shall be established, and they shall be my people.

Mosiah 26:18 Yea, blessed is this people who are willing to bear my name; for in my name shall they be called; and they are mine.

Mosiah 26:19 And because thou hast inquired of me concerning the transgressor, thou art blessed.

Mosiah 26:20 Thou art my servant; and I covenant with thee that thou shalt have eternal life; and thou shalt serve me and go forth in my name, and shalt gather together my sheep.

Mosiah 26:21 And he that will hear my voice shall be my sheep; and him shall ye receive into the church, and him will I also receive.

Mosiah 26:22 For behold, this is my church; whosoever is baptized shall be baptized unto repentance. And whomsoever ye receive shall believe in my name; and him will I freely forgive.

Mosiah 26:23 For it is I that taketh upon me the sins of the world; for it is I that hath created them; and it is I that granteth unto him that believeth unto the end a place at my right hand.

Mosiah 26:24 For behold, in my name are they called; and if they know me they shall come forth, and shall have a place eternally at my right hand.

Mosiah 26:25 And it shall come to pass that when the second trump shall sound then shall they that never knew me come forth and shall stand before me.

Mosiah 26:26 And then shall they know that I am the Lord their God, that I am their Redeemer; but they would not be redeemed.

Mosiah 26:27 And then I will confess unto them that I never knew them; and they shall depart into everlasting fire prepared for the devil and his angels.

Mosiah 26:28 Therefore I say unto you, that he that will not hear my voice, the same shall ye not receive into my church, for him I will not receive at the last day.

Mosiah 26:29 Therefore I say unto you, Go; and whosoever transgresseth against me, him shall ye judge according to the sins which he has committed; and if he confess his sins before thee and me, and repenteth in the sincerity of his heart, him shall ye forgive, and I will forgive him also.

Mosiah 26:30 Yea, and as often as my people repent will I forgive them their trespasses against me.

Mosiah 26:31 And ye shall also forgive one another your trespasses; for verily I say unto you, he that forgiveth not his neighbor’s trespasses when he says that he repents, the same hath brought himself under condemnation.

Mosiah 26:32 Now I say unto you, Go; and whosoever will not repent of his sins the same shall not be numbered among my people; and this shall be observed from this time forward.

Mosiah 26:33 And it came to pass when Alma had heard these words he wrote them down that he might have them, and that he might judge the people of that church according to the commandments of God.

Mosiah 26:34 And it came to pass that Alma went and judged those that had been taken in iniquity, according to the word of the Lord.

Mosiah 26:35 And whosoever repented of their sins and did confess them, them he did number among the people of the church;

Mosiah 26:36 And those that would not confess their sins and repent of their iniquity, the same were not numbered among the people of the church, and their names were blotted out.

Mosiah 26:37 And it came to pass that Alma did regulate all the affairs of the church; and they began again to have peace and to prosper exceedingly in the affairs of the church, walking circumspectly before God, receiving many, and baptizing many.

Mosiah 26:38 And now all these things did Alma and his fellow laborers do who were over the church, walking in all diligence, teaching the word of God in all things, suffering all manner of afflictions, being persecuted by all those who did not belong to the church of God.

Mosiah 26:39 And they did admonish their brethren; and they were also admonished, every one by the word of God, according to his sins, or to the sins which he had committed, being commanded of God to pray without ceasing, and to give thanks in all things.
