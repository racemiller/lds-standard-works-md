# 1 Nephi 10

1 Nephi 10 (summary): Lehi predicts that the Jews will be taken captive by the Babylonians—He tells of the coming among the Jews of a Messiah, a Savior, a Redeemer—Lehi tells also of the coming of the one who should baptize the Lamb of God—Lehi tells of the death and resurrection of the Messiah—He compares the scattering and gathering of Israel to an olive tree—Nephi speaks of the Son of God, of the gift of the Holy Ghost, and of the need for righteousness. About 600–592 B.C.

1 Nephi 10:1 And now I, Nephi, proceed to give an account upon these plates of my proceedings, and my reign and ministry; wherefore, to proceed with mine account, I must speak somewhat of the things of my father, and also of my brethren.

1 Nephi 10:2 For behold, it came to pass after my father had made an end of speaking the words of his dream, and also of exhorting them to all diligence, he spake unto them concerning the Jews—

1 Nephi 10:3 That after they should be destroyed, even that great city Jerusalem, and many be carried away captive into Babylon, according to the own due time of the Lord, they should return again, yea, even be brought back out of captivity; and after they should be brought back out of captivity they should possess again the land of their inheritance.

1 Nephi 10:4 Yea, even six hundred years from the time that my father left Jerusalem, a prophet would the Lord God raise up among the Jews—even a Messiah, or, in other words, a Savior of the world.

1 Nephi 10:5 And he also spake concerning the prophets, how great a number had testified of these things, concerning this Messiah, of whom he had spoken, or this Redeemer of the world.

1 Nephi 10:6 Wherefore, all mankind were in a lost and in a fallen state, and ever would be save they should rely on this Redeemer.

1 Nephi 10:7 And he spake also concerning a prophet who should come before the Messiah, to prepare the way of the Lord—

1 Nephi 10:8 Yea, even he should go forth and cry in the wilderness: Prepare ye the way of the Lord, and make his paths straight; for there standeth one among you whom ye know not; and he is mightier than I, whose shoe’s latchet I am not worthy to unloose. And much spake my father concerning this thing.

1 Nephi 10:9 And my father said he should baptize in Bethabara, beyond Jordan; and he also said he should baptize with water; even that he should baptize the Messiah with water.

1 Nephi 10:10 And after he had baptized the Messiah with water, he should behold and bear record that he had baptized the Lamb of God, who should take away the sins of the world.

1 Nephi 10:11 And it came to pass after my father had spoken these words he spake unto my brethren concerning the gospel which should be preached among the Jews, and also concerning the dwindling of the Jews in unbelief. And after they had slain the Messiah, who should come, and after he had been slain he should rise from the dead, and should make himself manifest, by the Holy Ghost, unto the Gentiles.

1 Nephi 10:12 Yea, even my father spake much concerning the Gentiles, and also concerning the house of Israel, that they should be compared like unto an olive tree, whose branches should be broken off and should be scattered upon all the face of the earth.

1 Nephi 10:13 Wherefore, he said it must needs be that we should be led with one accord into the land of promise, unto the fulfilling of the word of the Lord, that we should be scattered upon all the face of the earth.

1 Nephi 10:14 And after the house of Israel should be scattered they should be gathered together again; or, in fine, after the Gentiles had received the fulness of the Gospel, the natural branches of the olive tree, or the remnants of the house of Israel, should be grafted in, or come to the knowledge of the true Messiah, their Lord and their Redeemer.

1 Nephi 10:15 And after this manner of language did my father prophesy and speak unto my brethren, and also many more things which I do not write in this book; for I have written as many of them as were expedient for me in mine other book.

1 Nephi 10:16 And all these things, of which I have spoken, were done as my father dwelt in a tent, in the valley of Lemuel.

1 Nephi 10:17 And it came to pass after I, Nephi, having heard all the words of my father, concerning the things which he saw in a vision, and also the things which he spake by the power of the Holy Ghost, which power he received by faith on the Son of God—and the Son of God was the Messiah who should come—I, Nephi, was desirous also that I might see, and hear, and know of these things, by the power of the Holy Ghost, which is the gift of God unto all those who diligently seek him, as well in times of old as in the time that he should manifest himself unto the children of men.

1 Nephi 10:18 For he is the same yesterday, today, and forever; and the way is prepared for all men from the foundation of the world, if it so be that they repent and come unto him.

1 Nephi 10:19 For he that diligently seeketh shall find; and the mysteries of God shall be unfolded unto them, by the power of the Holy Ghost, as well in these times as in times of old, and as well in times of old as in times to come; wherefore, the course of the Lord is one eternal round.

1 Nephi 10:20 Therefore remember, O man, for all thy doings thou shalt be brought into judgment.

1 Nephi 10:21 Wherefore, if ye have sought to do wickedly in the days of your probation, then ye are found unclean before the judgment-seat of God; and no unclean thing can dwell with God; wherefore, ye must be cast off forever.

1 Nephi 10:22 And the Holy Ghost giveth authority that I should speak these things, and deny them not.
