# Mosiah 13

Mosiah 13 (summary): Abinadi is protected by divine power—He teaches the Ten Commandments—Salvation does not come by the law of Moses alone—God Himself will make an atonement and redeem His people. About 148 B.C.

Mosiah 13:1 And now when the king had heard these words, he said unto his priests: Away with this fellow, and slay him; for what have we to do with him, for he is mad.

Mosiah 13:2 And they stood forth and attempted to lay their hands on him; but he withstood them, and said unto them:

Mosiah 13:3 Touch me not, for God shall smite you if ye lay your hands upon me, for I have not delivered the message which the Lord sent me to deliver; neither have I told you that which ye requested that I should tell; therefore, God will not suffer that I shall be destroyed at this time.

Mosiah 13:4 But I must fulfil the commandments wherewith God has commanded me; and because I have told you the truth ye are angry with me. And again, because I have spoken the word of God ye have judged me that I am mad.

Mosiah 13:5 Now it came to pass after Abinadi had spoken these words that the people of king Noah durst not lay their hands on him, for the Spirit of the Lord was upon him; and his face shone with exceeding luster, even as Moses’ did while in the mount of Sinai, while speaking with the Lord.

Mosiah 13:6 And he spake with power and authority from God; and he continued his words, saying:

Mosiah 13:7 Ye see that ye have not power to slay me, therefore I finish my message. Yea, and I perceive that it cuts you to your hearts because I tell you the truth concerning your iniquities.

Mosiah 13:8 Yea, and my words fill you with wonder and amazement, and with anger.

Mosiah 13:9 But I finish my message; and then it matters not whither I go, if it so be that I am saved.

Mosiah 13:10 But this much I tell you, what you do with me, after this, shall be as a type and a shadow of things which are to come.

Mosiah 13:11 And now I read unto you the remainder of the commandments of God, for I perceive that they are not written in your hearts; I perceive that ye have studied and taught iniquity the most part of your lives.

Mosiah 13:12 And now, ye remember that I said unto you: Thou shalt not make unto thee any graven image, or any likeness of things which are in heaven above, or which are in the earth beneath, or which are in the water under the earth.

Mosiah 13:13 And again: Thou shalt not bow down thyself unto them, nor serve them; for I the Lord thy God am a jealous God, visiting the iniquities of the fathers upon the children, unto the third and fourth generations of them that hate me;

Mosiah 13:14 And showing mercy unto thousands of them that love me and keep my commandments.

Mosiah 13:15 Thou shalt not take the name of the Lord thy God in vain; for the Lord will not hold him guiltless that taketh his name in vain.

Mosiah 13:16 Remember the sabbath day, to keep it holy.

Mosiah 13:17 Six days shalt thou labor, and do all thy work;

Mosiah 13:18 But the seventh day, the sabbath of the Lord thy God, thou shalt not do any work, thou, nor thy son, nor thy daughter, thy man-servant, nor thy maid-servant, nor thy cattle, nor thy stranger that is within thy gates;

Mosiah 13:19 For in six days the Lord made heaven and earth, and the sea, and all that in them is; wherefore the Lord blessed the sabbath day, and hallowed it.

Mosiah 13:20 Honor thy father and thy mother, that thy days may be long upon the land which the Lord thy God giveth thee.

Mosiah 13:21 Thou shalt not kill.

Mosiah 13:22 Thou shalt not commit adultery. Thou shalt not steal.

Mosiah 13:23 Thou shalt not bear false witness against thy neighbor.

Mosiah 13:24 Thou shalt not covet thy neighbor’s house, thou shalt not covet thy neighbor’s wife, nor his man-servant, nor his maid-servant, nor his ox, nor his ass, nor anything that is thy neighbor’s.

Mosiah 13:25 And it came to pass that after Abinadi had made an end of these sayings that he said unto them: Have ye taught this people that they should observe to do all these things for to keep these commandments?

Mosiah 13:26 I say unto you, Nay; for if ye had, the Lord would not have caused me to come forth and to prophesy evil concerning this people.

Mosiah 13:27 And now ye have said that salvation cometh by the law of Moses. I say unto you that it is expedient that ye should keep the law of Moses as yet; but I say unto you, that the time shall come when it shall no more be expedient to keep the law of Moses.

Mosiah 13:28 And moreover, I say unto you, that salvation doth not come by the law alone; and were it not for the atonement, which God himself shall make for the sins and iniquities of his people, that they must unavoidably perish, notwithstanding the law of Moses.

Mosiah 13:29 And now I say unto you that it was expedient that there should be a law given to the children of Israel, yea, even a very strict law; for they were a stiffnecked people, quick to do iniquity, and slow to remember the Lord their God;

Mosiah 13:30 Therefore there was a law given them, yea, a law of performances and of ordinances, a law which they were to observe strictly from day to day, to keep them in remembrance of God and their duty towards him.

Mosiah 13:31 But behold, I say unto you, that all these things were types of things to come.

Mosiah 13:32 And now, did they understand the law? I say unto you, Nay, they did not all understand the law; and this because of the hardness of their hearts; for they understood not that there could not any man be saved except it were through the redemption of God.

Mosiah 13:33 For behold, did not Moses prophesy unto them concerning the coming of the Messiah, and that God should redeem his people? Yea, and even all the prophets who have prophesied ever since the world began—have they not spoken more or less concerning these things?

Mosiah 13:34 Have they not said that God himself should come down among the children of men, and take upon him the form of man, and go forth in mighty power upon the face of the earth?

Mosiah 13:35 Yea, and have they not said also that he should bring to pass the resurrection of the dead, and that he, himself, should be oppressed and afflicted?
