# 1 Nephi 9

1 Nephi 9 (summary): Nephi makes two sets of records—Each is called the plates of Nephi—The larger plates contain a secular history; the smaller ones deal primarily with sacred things. About 600–592 B.C.

1 Nephi 9:1 And all these things did my father see, and hear, and speak, as he dwelt in a tent, in the valley of Lemuel, and also a great many more things, which cannot be written upon these plates.

1 Nephi 9:2 And now, as I have spoken concerning these plates, behold they are not the plates upon which I make a full account of the history of my people; for the plates upon which I make a full account of my people I have given the name of Nephi; wherefore, they are called the plates of Nephi, after mine own name; and these plates also are called the plates of Nephi.

1 Nephi 9:3 Nevertheless, I have received a commandment of the Lord that I should make these plates, for the special purpose that there should be an account engraven of the ministry of my people.

1 Nephi 9:4 Upon the other plates should be engraven an account of the reign of the kings, and the wars and contentions of my people; wherefore these plates are for the more part of the ministry; and the other plates are for the more part of the reign of the kings and the wars and contentions of my people.

1 Nephi 9:5 Wherefore, the Lord hath commanded me to make these plates for a wise purpose in him, which purpose I know not.

1 Nephi 9:6 But the Lord knoweth all things from the beginning; wherefore, he prepareth a way to accomplish all his works among the children of men; for behold, he hath all power unto the fulfilling of all his words. And thus it is. Amen.
