# Ether 5

Ether 5 (summary): Three witnesses and the work itself will stand as a testimony of the truthfulness of the Book of Mormon.

Ether 5:1 And now I, Moroni, have written the words which were commanded me, according to my memory; and I have told you the things which I have sealed up; therefore touch them not in order that ye may translate; for that thing is forbidden you, except by and by it shall be wisdom in God.

Ether 5:2 And behold, ye may be privileged that ye may show the plates unto those who shall assist to bring forth this work;

Ether 5:3 And unto three shall they be shown by the power of God; wherefore they shall know of a surety that these things are true.

Ether 5:4 And in the mouth of three witnesses shall these things be established; and the testimony of three, and this work, in the which shall be shown forth the power of God and also his word, of which the Father, and the Son, and the Holy Ghost bear record—and all this shall stand as a testimony against the world at the last day.

Ether 5:5 And if it so be that they repent and come unto the Father in the name of Jesus, they shall be received into the kingdom of God.

Ether 5:6 And now, if I have no authority for these things, judge ye; for ye shall know that I have authority when ye shall see me, and we shall stand before God at the last day. Amen.
