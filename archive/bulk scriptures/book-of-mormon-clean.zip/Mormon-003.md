# Mormon 3

Mormon 3 (summary): Mormon cries repentance unto the Nephites—They gain a great victory and glory in their own strength—Mormon refuses to lead them, and his prayers for them are without faith—The Book of Mormon invites the twelve tribes of Israel to believe the gospel. About A.D. 360–62.

Mormon 3:1 And it came to pass that the Lamanites did not come to battle again until ten years more had passed away. And behold, I had employed my people, the Nephites, in preparing their lands and their arms against the time of battle.

Mormon 3:2 And it came to pass that the Lord did say unto me: Cry unto this people—Repent ye, and come unto me, and be ye baptized, and build up again my church, and ye shall be spared.

Mormon 3:3 And I did cry unto this people, but it was in vain; and they did not realize that it was the Lord that had spared them, and granted unto them a chance for repentance. And behold they did harden their hearts against the Lord their God.

Mormon 3:4 And it came to pass that after this tenth year had passed away, making, in the whole, three hundred and sixty years from the coming of Christ, the king of the Lamanites sent an epistle unto me, which gave unto me to know that they were preparing to come again to battle against us.

Mormon 3:5 And it came to pass that I did cause my people that they should gather themselves together at the land Desolation, to a city which was in the borders, by the narrow pass which led into the land southward.

Mormon 3:6 And there we did place our armies, that we might stop the armies of the Lamanites, that they might not get possession of any of our lands; therefore we did fortify against them with all our force.

Mormon 3:7 And it came to pass that in the three hundred and sixty and first year the Lamanites did come down to the city of Desolation to battle against us; and it came to pass that in that year we did beat them, insomuch that they did return to their own lands again.

Mormon 3:8 And in the three hundred and sixty and second year they did come down again to battle. And we did beat them again, and did slay a great number of them, and their dead were cast into the sea.

Mormon 3:9 And now, because of this great thing which my people, the Nephites, had done, they began to boast in their own strength, and began to swear before the heavens that they would avenge themselves of the blood of their brethren who had been slain by their enemies.

Mormon 3:10 And they did swear by the heavens, and also by the throne of God, that they would go up to battle against their enemies, and would cut them off from the face of the land.

Mormon 3:11 And it came to pass that I, Mormon, did utterly refuse from this time forth to be a commander and a leader of this people, because of their wickedness and abomination.

Mormon 3:12 Behold, I had led them, notwithstanding their wickedness I had led them many times to battle, and had loved them, according to the love of God which was in me, with all my heart; and my soul had been poured out in prayer unto my God all the day long for them; nevertheless, it was without faith, because of the hardness of their hearts.

Mormon 3:13 And thrice have I delivered them out of the hands of their enemies, and they have repented not of their sins.

Mormon 3:14 And when they had sworn by all that had been forbidden them by our Lord and Savior Jesus Christ, that they would go up unto their enemies to battle, and avenge themselves of the blood of their brethren, behold the voice of the Lord came unto me, saying:

Mormon 3:15 Vengeance is mine, and I will repay; and because this people repented not after I had delivered them, behold, they shall be cut off from the face of the earth.

Mormon 3:16 And it came to pass that I utterly refused to go up against mine enemies; and I did even as the Lord had commanded me; and I did stand as an idle witness to manifest unto the world the things which I saw and heard, according to the manifestations of the Spirit which had testified of things to come.

Mormon 3:17 Therefore I write unto you, Gentiles, and also unto you, house of Israel, when the work shall commence, that ye shall be about to prepare to return to the land of your inheritance;

Mormon 3:18 Yea, behold, I write unto all the ends of the earth; yea, unto you, twelve tribes of Israel, who shall be judged according to your works by the twelve whom Jesus chose to be his disciples in the land of Jerusalem.

Mormon 3:19 And I write also unto the remnant of this people, who shall also be judged by the twelve whom Jesus chose in this land; and they shall be judged by the other twelve whom Jesus chose in the land of Jerusalem.

Mormon 3:20 And these things doth the Spirit manifest unto me; therefore I write unto you all. And for this cause I write unto you, that ye may know that ye must all stand before the judgment-seat of Christ, yea, every soul who belongs to the whole human family of Adam; and ye must stand to be judged of your works, whether they be good or evil;

Mormon 3:21 And also that ye may believe the gospel of Jesus Christ, which ye shall have among you; and also that the Jews, the covenant people of the Lord, shall have other witness besides him whom they saw and heard, that Jesus, whom they slew, was the very Christ and the very God.

Mormon 3:22 And I would that I could persuade all ye ends of the earth to repent and prepare to stand before the judgment-seat of Christ.
