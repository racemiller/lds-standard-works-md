# Mosiah 19

Mosiah 19 (summary): Gideon seeks to slay King Noah—The Lamanites invade the land—King Noah suffers death by fire—Limhi rules as a tributary monarch. About 145–121 B.C.

Mosiah 19:1 And it came to pass that the army of the king returned, having searched in vain for the people of the Lord.

Mosiah 19:2 And now behold, the forces of the king were small, having been reduced, and there began to be a division among the remainder of the people.

Mosiah 19:3 And the lesser part began to breathe out threatenings against the king, and there began to be a great contention among them.

Mosiah 19:4 And now there was a man among them whose name was Gideon, and he being a strong man and an enemy to the king, therefore he drew his sword, and swore in his wrath that he would slay the king.

Mosiah 19:5 And it came to pass that he fought with the king; and when the king saw that he was about to overpower him, he fled and ran and got upon the tower which was near the temple.

Mosiah 19:6 And Gideon pursued after him and was about to get upon the tower to slay the king, and the king cast his eyes round about towards the land of Shemlon, and behold, the army of the Lamanites were within the borders of the land.

Mosiah 19:7 And now the king cried out in the anguish of his soul, saying: Gideon, spare me, for the Lamanites are upon us, and they will destroy us; yea, they will destroy my people.

Mosiah 19:8 And now the king was not so much concerned about his people as he was about his own life; nevertheless, Gideon did spare his life.

Mosiah 19:9 And the king commanded the people that they should flee before the Lamanites, and he himself did go before them, and they did flee into the wilderness, with their women and their children.

Mosiah 19:10 And it came to pass that the Lamanites did pursue them, and did overtake them, and began to slay them.

Mosiah 19:11 Now it came to pass that the king commanded them that all the men should leave their wives and their children, and flee before the Lamanites.

Mosiah 19:12 Now there were many that would not leave them, but had rather stay and perish with them. And the rest left their wives and their children and fled.

Mosiah 19:13 And it came to pass that those who tarried with their wives and their children caused that their fair daughters should stand forth and plead with the Lamanites that they would not slay them.

Mosiah 19:14 And it came to pass that the Lamanites had compassion on them, for they were charmed with the beauty of their women.

Mosiah 19:15 Therefore the Lamanites did spare their lives, and took them captives and carried them back to the land of Nephi, and granted unto them that they might possess the land, under the conditions that they would deliver up king Noah into the hands of the Lamanites, and deliver up their property, even one half of all they possessed, one half of their gold, and their silver, and all their precious things, and thus they should pay tribute to the king of the Lamanites from year to year.

Mosiah 19:16 And now there was one of the sons of the king among those that were taken captive, whose name was Limhi.

Mosiah 19:17 And now Limhi was desirous that his father should not be destroyed; nevertheless, Limhi was not ignorant of the iniquities of his father, he himself being a just man.

Mosiah 19:18 And it came to pass that Gideon sent men into the wilderness secretly, to search for the king and those that were with him. And it came to pass that they met the people in the wilderness, all save the king and his priests.

Mosiah 19:19 Now they had sworn in their hearts that they would return to the land of Nephi, and if their wives and their children were slain, and also those that had tarried with them, that they would seek revenge, and also perish with them.

Mosiah 19:20 And the king commanded them that they should not return; and they were angry with the king, and caused that he should suffer, even unto death by fire.

Mosiah 19:21 And they were about to take the priests also and put them to death, and they fled before them.

Mosiah 19:22 And it came to pass that they were about to return to the land of Nephi, and they met the men of Gideon. And the men of Gideon told them of all that had happened to their wives and their children; and that the Lamanites had granted unto them that they might possess the land by paying a tribute to the Lamanites of one half of all they possessed.

Mosiah 19:23 And the people told the men of Gideon that they had slain the king, and his priests had fled from them farther into the wilderness.

Mosiah 19:24 And it came to pass that after they had ended the ceremony, that they returned to the land of Nephi, rejoicing, because their wives and their children were not slain; and they told Gideon what they had done to the king.

Mosiah 19:25 And it came to pass that the king of the Lamanites made an oath unto them, that his people should not slay them.

Mosiah 19:26 And also Limhi, being the son of the king, having the kingdom conferred upon him by the people, made oath unto the king of the Lamanites that his people should pay tribute unto him, even one half of all they possessed.

Mosiah 19:27 And it came to pass that Limhi began to establish the kingdom and to establish peace among his people.

Mosiah 19:28 And the king of the Lamanites set guards round about the land, that he might keep the people of Limhi in the land, that they might not depart into the wilderness; and he did support his guards out of the tribute which he did receive from the Nephites.

Mosiah 19:29 And now king Limhi did have continual peace in his kingdom for the space of two years, that the Lamanites did not molest them nor seek to destroy them.
