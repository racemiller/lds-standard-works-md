# Alma 22

Alma 22 (summary): Aaron teaches Lamoni’s father about the Creation, the Fall of Adam, and the plan of redemption through Christ—The king and all his household are converted—The division of the land between the Nephites and the Lamanites is explained. About 90–77 B.C.

Alma 22:1 Now, as Ammon was thus teaching the people of Lamoni continually, we will return to the account of Aaron and his brethren; for after he departed from the land of Middoni he was led by the Spirit to the land of Nephi, even to the house of the king which was over all the land save it were the land of Ishmael; and he was the father of Lamoni.

Alma 22:2 And it came to pass that he went in unto him into the king’s palace, with his brethren, and bowed himself before the king, and said unto him: Behold, O king, we are the brethren of Ammon, whom thou hast delivered out of prison.

Alma 22:3 And now, O king, if thou wilt spare our lives, we will be thy servants. And the king said unto them: Arise, for I will grant unto you your lives, and I will not suffer that ye shall be my servants; but I will insist that ye shall administer unto me; for I have been somewhat troubled in mind because of the generosity and the greatness of the words of thy brother Ammon; and I desire to know the cause why he has not come up out of Middoni with thee.

Alma 22:4 And Aaron said unto the king: Behold, the Spirit of the Lord has called him another way; he has gone to the land of Ishmael, to teach the people of Lamoni.

Alma 22:5 Now the king said unto them: What is this that ye have said concerning the Spirit of the Lord? Behold, this is the thing which doth trouble me.

Alma 22:6 And also, what is this that Ammon said—If ye will repent ye shall be saved, and if ye will not repent, ye shall be cast off at the last day?

Alma 22:7 And Aaron answered him and said unto him: Believest thou that there is a God? And the king said: I know that the Amalekites say that there is a God, and I have granted unto them that they should build sanctuaries, that they may assemble themselves together to worship him. And if now thou sayest there is a God, behold I will believe.

Alma 22:8 And now when Aaron heard this, his heart began to rejoice, and he said: Behold, assuredly as thou livest, O king, there is a God.

Alma 22:9 And the king said: Is God that Great Spirit that brought our fathers out of the land of Jerusalem?

Alma 22:10 And Aaron said unto him: Yea, he is that Great Spirit, and he created all things both in heaven and in earth. Believest thou this?

Alma 22:11 And he said: Yea, I believe that the Great Spirit created all things, and I desire that ye should tell me concerning all these things, and I will believe thy words.

Alma 22:12 And it came to pass that when Aaron saw that the king would believe his words, he began from the creation of Adam, reading the scriptures unto the king—how God created man after his own image, and that God gave him commandments, and that because of transgression, man had fallen.

Alma 22:13 And Aaron did expound unto him the scriptures from the creation of Adam, laying the fall of man before him, and their carnal state and also the plan of redemption, which was prepared from the foundation of the world, through Christ, for all whosoever would believe on his name.

Alma 22:14 And since man had fallen he could not merit anything of himself; but the sufferings and death of Christ atone for their sins, through faith and repentance, and so forth; and that he breaketh the bands of death, that the grave shall have no victory, and that the sting of death should be swallowed up in the hopes of glory; and Aaron did expound all these things unto the king.

Alma 22:15 And it came to pass that after Aaron had expounded these things unto him, the king said: What shall I do that I may have this eternal life of which thou hast spoken? Yea, what shall I do that I may be born of God, having this wicked spirit rooted out of my breast, and receive his Spirit, that I may be filled with joy, that I may not be cast off at the last day? Behold, said he, I will give up all that I possess, yea, I will forsake my kingdom, that I may receive this great joy.

Alma 22:16 But Aaron said unto him: If thou desirest this thing, if thou wilt bow down before God, yea, if thou wilt repent of all thy sins, and will bow down before God, and call on his name in faith, believing that ye shall receive, then shalt thou receive the hope which thou desirest.

Alma 22:17 And it came to pass that when Aaron had said these words, the king did bow down before the Lord, upon his knees; yea, even he did prostrate himself upon the earth, and cried mightily, saying:

Alma 22:18 O God, Aaron hath told me that there is a God; and if there is a God, and if thou art God, wilt thou make thyself known unto me, and I will give away all my sins to know thee, and that I may be raised from the dead, and be saved at the last day. And now when the king had said these words, he was struck as if he were dead.

Alma 22:19 And it came to pass that his servants ran and told the queen all that had happened unto the king. And she came in unto the king; and when she saw him lay as if he were dead, and also Aaron and his brethren standing as though they had been the cause of his fall, she was angry with them, and commanded that her servants, or the servants of the king, should take them and slay them.

Alma 22:20 Now the servants had seen the cause of the king’s fall, therefore they durst not lay their hands on Aaron and his brethren; and they pled with the queen saying: Why commandest thou that we should slay these men, when behold one of them is mightier than us all? Therefore we shall fall before them.

Alma 22:21 Now when the queen saw the fear of the servants she also began to fear exceedingly, lest there should some evil come upon her. And she commanded her servants that they should go and call the people, that they might slay Aaron and his brethren.

Alma 22:22 Now when Aaron saw the determination of the queen, he, also knowing the hardness of the hearts of the people, feared lest that a multitude should assemble themselves together, and there should be a great contention and a disturbance among them; therefore he put forth his hand and raised the king from the earth, and said unto him: Stand. And he stood upon his feet, receiving his strength.

Alma 22:23 Now this was done in the presence of the queen and many of the servants. And when they saw it they greatly marveled, and began to fear. And the king stood forth, and began to minister unto them. And he did minister unto them, insomuch that his whole household were converted unto the Lord.

Alma 22:24 Now there was a multitude gathered together because of the commandment of the queen, and there began to be great murmurings among them because of Aaron and his brethren.

Alma 22:25 But the king stood forth among them and administered unto them. And they were pacified towards Aaron and those who were with him.

Alma 22:26 And it came to pass that when the king saw that the people were pacified, he caused that Aaron and his brethren should stand forth in the midst of the multitude, and that they should preach the word unto them.

Alma 22:27 And it came to pass that the king sent a proclamation throughout all the land, amongst all his people who were in all his land, who were in all the regions round about, which was bordering even to the sea, on the east and on the west, and which was divided from the land of Zarahemla by a narrow strip of wilderness, which ran from the sea east even to the sea west, and round about on the borders of the seashore, and the borders of the wilderness which was on the north by the land of Zarahemla, through the borders of Manti, by the head of the river Sidon, running from the east towards the west—and thus were the Lamanites and the Nephites divided.

Alma 22:28 Now, the more idle part of the Lamanites lived in the wilderness, and dwelt in tents; and they were spread through the wilderness on the west, in the land of Nephi; yea, and also on the west of the land of Zarahemla, in the borders by the seashore, and on the west in the land of Nephi, in the place of their fathers’ first inheritance, and thus bordering along by the seashore.

Alma 22:29 And also there were many Lamanites on the east by the seashore, whither the Nephites had driven them. And thus the Nephites were nearly surrounded by the Lamanites; nevertheless the Nephites had taken possession of all the northern parts of the land bordering on the wilderness, at the head of the river Sidon, from the east to the west, round about on the wilderness side; on the north, even until they came to the land which they called Bountiful.

Alma 22:30 And it bordered upon the land which they called Desolation, it being so far northward that it came into the land which had been peopled and been destroyed, of whose bones we have spoken, which was discovered by the people of Zarahemla, it being the place of their first landing.

Alma 22:31 And they came from there up into the south wilderness. Thus the land on the northward was called Desolation, and the land on the southward was called Bountiful, it being the wilderness which is filled with all manner of wild animals of every kind, a part of which had come from the land northward for food.

Alma 22:32 And now, it was only the distance of a day and a half’s journey for a Nephite, on the line Bountiful and the land Desolation, from the east to the west sea; and thus the land of Nephi and the land of Zarahemla were nearly surrounded by water, there being a small neck of land between the land northward and the land southward.

Alma 22:33 And it came to pass that the Nephites had inhabited the land Bountiful, even from the east unto the west sea, and thus the Nephites in their wisdom, with their guards and their armies, had hemmed in the Lamanites on the south, that thereby they should have no more possession on the north, that they might not overrun the land northward.

Alma 22:34 Therefore the Lamanites could have no more possessions only in the land of Nephi, and the wilderness round about. Now this was wisdom in the Nephites—as the Lamanites were an enemy to them, they would not suffer their afflictions on every hand, and also that they might have a country whither they might flee, according to their desires.

Alma 22:35 And now I, after having said this, return again to the account of Ammon and Aaron, Omner and Himni, and their brethren.
