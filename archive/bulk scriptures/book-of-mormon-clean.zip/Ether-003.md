# Ether 3

Ether 3 (summary): The brother of Jared sees the finger of the Lord as He touches sixteen stones—Christ shows His spirit body to the brother of Jared—Those who have a perfect knowledge cannot be kept from within the veil—Interpreters are provided to bring the Jaredite record to light.

Ether 3:1 And it came to pass that the brother of Jared, (now the number of the vessels which had been prepared was eight) went forth unto the mount, which they called the mount Shelem, because of its exceeding height, and did molten out of a rock sixteen small stones; and they were white and clear, even as transparent glass; and he did carry them in his hands upon the top of the mount, and cried again unto the Lord, saying:

Ether 3:2 O Lord, thou hast said that we must be encompassed about by the floods. Now behold, O Lord, and do not be angry with thy servant because of his weakness before thee; for we know that thou art holy and dwellest in the heavens, and that we are unworthy before thee; because of the fall our natures have become evil continually; nevertheless, O Lord, thou hast given us a commandment that we must call upon thee, that from thee we may receive according to our desires.

Ether 3:3 Behold, O Lord, thou hast smitten us because of our iniquity, and hast driven us forth, and for these many years we have been in the wilderness; nevertheless, thou hast been merciful unto us. O Lord, look upon me in pity, and turn away thine anger from this thy people, and suffer not that they shall go forth across this raging deep in darkness; but behold these things which I have molten out of the rock.

Ether 3:4 And I know, O Lord, that thou hast all power, and can do whatsoever thou wilt for the benefit of man; therefore touch these stones, O Lord, with thy finger, and prepare them that they may shine forth in darkness; and they shall shine forth unto us in the vessels which we have prepared, that we may have light while we shall cross the sea.

Ether 3:5 Behold, O Lord, thou canst do this. We know that thou art able to show forth great power, which looks small unto the understanding of men.

Ether 3:6 And it came to pass that when the brother of Jared had said these words, behold, the Lord stretched forth his hand and touched the stones one by one with his finger. And the veil was taken from off the eyes of the brother of Jared, and he saw the finger of the Lord; and it was as the finger of a man, like unto flesh and blood; and the brother of Jared fell down before the Lord, for he was struck with fear.

Ether 3:7 And the Lord saw that the brother of Jared had fallen to the earth; and the Lord said unto him: Arise, why hast thou fallen?

Ether 3:8 And he saith unto the Lord: I saw the finger of the Lord, and I feared lest he should smite me; for I knew not that the Lord had flesh and blood.

Ether 3:9 And the Lord said unto him: Because of thy faith thou hast seen that I shall take upon me flesh and blood; and never has man come before me with such exceeding faith as thou hast; for were it not so ye could not have seen my finger. Sawest thou more than this?

Ether 3:10 And he answered: Nay; Lord, show thyself unto me.

Ether 3:11 And the Lord said unto him: Believest thou the words which I shall speak?

Ether 3:12 And he answered: Yea, Lord, I know that thou speakest the truth, for thou art a God of truth, and canst not lie.

Ether 3:13 And when he had said these words, behold, the Lord showed himself unto him, and said: Because thou knowest these things ye are redeemed from the fall; therefore ye are brought back into my presence; therefore I show myself unto you.

Ether 3:14 Behold, I am he who was prepared from the foundation of the world to redeem my people. Behold, I am Jesus Christ. I am the Father and the Son. In me shall all mankind have life, and that eternally, even they who shall believe on my name; and they shall become my sons and my daughters.

Ether 3:15 And never have I showed myself unto man whom I have created, for never has man believed in me as thou hast. Seest thou that ye are created after mine own image? Yea, even all men were created in the beginning after mine own image.

Ether 3:16 Behold, this body, which ye now behold, is the body of my spirit; and man have I created after the body of my spirit; and even as I appear unto thee to be in the spirit will I appear unto my people in the flesh.

Ether 3:17 And now, as I, Moroni, said I could not make a full account of these things which are written, therefore it sufficeth me to say that Jesus showed himself unto this man in the spirit, even after the manner and in the likeness of the same body even as he showed himself unto the Nephites.

Ether 3:18 And he ministered unto him even as he ministered unto the Nephites; and all this, that this man might know that he was God, because of the many great works which the Lord had showed unto him.

Ether 3:19 And because of the knowledge of this man he could not be kept from beholding within the veil; and he saw the finger of Jesus, which, when he saw, he fell with fear; for he knew that it was the finger of the Lord; and he had faith no longer, for he knew, nothing doubting.

Ether 3:20 Wherefore, having this perfect knowledge of God, he could not be kept from within the veil; therefore he saw Jesus; and he did minister unto him.

Ether 3:21 And it came to pass that the Lord said unto the brother of Jared: Behold, thou shalt not suffer these things which ye have seen and heard to go forth unto the world, until the time cometh that I shall glorify my name in the flesh; wherefore, ye shall treasure up the things which ye have seen and heard, and show it to no man.

Ether 3:22 And behold, when ye shall come unto me, ye shall write them and shall seal them up, that no one can interpret them; for ye shall write them in a language that they cannot be read.

Ether 3:23 And behold, these two stones will I give unto thee, and ye shall seal them up also with the things which ye shall write.

Ether 3:24 For behold, the language which ye shall write I have confounded; wherefore I will cause in my own due time that these stones shall magnify to the eyes of men these things which ye shall write.

Ether 3:25 And when the Lord had said these words, he showed unto the brother of Jared all the inhabitants of the earth which had been, and also all that would be; and he withheld them not from his sight, even unto the ends of the earth.

Ether 3:26 For he had said unto him in times before, that if he would believe in him that he could show unto him all things—it should be shown unto him; therefore the Lord could not withhold anything from him, for he knew that the Lord could show him all things.

Ether 3:27 And the Lord said unto him: Write these things and seal them up; and I will show them in mine own due time unto the children of men.

Ether 3:28 And it came to pass that the Lord commanded him that he should seal up the two stones which he had received, and show them not, until the Lord should show them unto the children of men.
