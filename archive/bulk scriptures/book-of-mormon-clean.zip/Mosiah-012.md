# Mosiah 12

Mosiah 12 (summary): Abinadi is imprisoned for prophesying the destruction of the people and the death of King Noah—The false priests quote the scriptures and pretend to keep the law of Moses—Abinadi begins to teach them the Ten Commandments. About 148 B.C.

Mosiah 12:1 And it came to pass that after the space of two years that Abinadi came among them in disguise, that they knew him not, and began to prophesy among them, saying: Thus has the Lord commanded me, saying—Abinadi, go and prophesy unto this my people, for they have hardened their hearts against my words; they have repented not of their evil doings; therefore, I will visit them in my anger, yea, in my fierce anger will I visit them in their iniquities and abominations.

Mosiah 12:2 Yea, wo be unto this generation! And the Lord said unto me: Stretch forth thy hand and prophesy, saying: Thus saith the Lord, it shall come to pass that this generation, because of their iniquities, shall be brought into bondage, and shall be smitten on the cheek; yea, and shall be driven by men, and shall be slain; and the vultures of the air, and the dogs, yea, and the wild beasts, shall devour their flesh.

Mosiah 12:3 And it shall come to pass that the life of king Noah shall be valued even as a garment in a hot furnace; for he shall know that I am the Lord.

Mosiah 12:4 And it shall come to pass that I will smite this my people with sore afflictions, yea, with famine and with pestilence; and I will cause that they shall howl all the day long.

Mosiah 12:5 Yea, and I will cause that they shall have burdens lashed upon their backs; and they shall be driven before like a dumb ass.

Mosiah 12:6 And it shall come to pass that I will send forth hail among them, and it shall smite them; and they shall also be smitten with the east wind; and insects shall pester their land also, and devour their grain.

Mosiah 12:7 And they shall be smitten with a great pestilence—and all this will I do because of their iniquities and abominations.

Mosiah 12:8 And it shall come to pass that except they repent I will utterly destroy them from off the face of the earth; yet they shall leave a record behind them, and I will preserve them for other nations which shall possess the land; yea, even this will I do that I may discover the abominations of this people to other nations. And many things did Abinadi prophesy against this people.

Mosiah 12:9 And it came to pass that they were angry with him; and they took him and carried him bound before the king, and said unto the king: Behold, we have brought a man before thee who has prophesied evil concerning thy people, and saith that God will destroy them.

Mosiah 12:10 And he also prophesieth evil concerning thy life, and saith that thy life shall be as a garment in a furnace of fire.

Mosiah 12:11 And again, he saith that thou shalt be as a stalk, even as a dry stalk of the field, which is run over by the beasts and trodden under foot.

Mosiah 12:12 And again, he saith thou shalt be as the blossoms of a thistle, which, when it is fully ripe, if the wind bloweth, it is driven forth upon the face of the land. And he pretendeth the Lord hath spoken it. And he saith all this shall come upon thee except thou repent, and this because of thine iniquities.

Mosiah 12:13 And now, O king, what great evil hast thou done, or what great sins have thy people committed, that we should be condemned of God or judged of this man?

Mosiah 12:14 And now, O king, behold, we are guiltless, and thou, O king, hast not sinned; therefore, this man has lied concerning you, and he has prophesied in vain.

Mosiah 12:15 And behold, we are strong, we shall not come into bondage, or be taken captive by our enemies; yea, and thou hast prospered in the land, and thou shalt also prosper.

Mosiah 12:16 Behold, here is the man, we deliver him into thy hands; thou mayest do with him as seemeth thee good.

Mosiah 12:17 And it came to pass that king Noah caused that Abinadi should be cast into prison; and he commanded that the priests should gather themselves together that he might hold a council with them what he should do with him.

Mosiah 12:18 And it came to pass that they said unto the king: Bring him hither that we may question him; and the king commanded that he should be brought before them.

Mosiah 12:19 And they began to question him, that they might cross him, that thereby they might have wherewith to accuse him; but he answered them boldly, and withstood all their questions, yea, to their astonishment; for he did withstand them in all their questions, and did confound them in all their words.

Mosiah 12:20 And it came to pass that one of them said unto him: What meaneth the words which are written, and which have been taught by our fathers, saying:

Mosiah 12:21 How beautiful upon the mountains are the feet of him that bringeth good tidings; that publisheth peace; that bringeth good tidings of good; that publisheth salvation; that saith unto Zion, Thy God reigneth;

Mosiah 12:22 Thy watchmen shall lift up the voice; with the voice together shall they sing; for they shall see eye to eye when the Lord shall bring again Zion;

Mosiah 12:23 Break forth into joy; sing together ye waste places of Jerusalem; for the Lord hath comforted his people, he hath redeemed Jerusalem;

Mosiah 12:24 The Lord hath made bare his holy arm in the eyes of all the nations, and all the ends of the earth shall see the salvation of our God?

Mosiah 12:25 And now Abinadi said unto them: Are you priests, and pretend to teach this people, and to understand the spirit of prophesying, and yet desire to know of me what these things mean?

Mosiah 12:26 I say unto you, wo be unto you for perverting the ways of the Lord! For if ye understand these things ye have not taught them; therefore, ye have perverted the ways of the Lord.

Mosiah 12:27 Ye have not applied your hearts to understanding; therefore, ye have not been wise. Therefore, what teach ye this people?

Mosiah 12:28 And they said: We teach the law of Moses.

Mosiah 12:29 And again he said unto them: If ye teach the law of Moses why do ye not keep it? Why do ye set your hearts upon riches? Why do ye commit whoredoms and spend your strength with harlots, yea, and cause this people to commit sin, that the Lord has cause to send me to prophesy against this people, yea, even a great evil against this people?

Mosiah 12:30 Know ye not that I speak the truth? Yea, ye know that I speak the truth; and you ought to tremble before God.

Mosiah 12:31 And it shall come to pass that ye shall be smitten for your iniquities, for ye have said that ye teach the law of Moses. And what know ye concerning the law of Moses? Doth salvation come by the law of Moses? What say ye?

Mosiah 12:32 And they answered and said that salvation did come by the law of Moses.

Mosiah 12:33 But now Abinadi said unto them: I know if ye keep the commandments of God ye shall be saved; yea, if ye keep the commandments which the Lord delivered unto Moses in the mount of Sinai, saying:

Mosiah 12:34 I am the Lord thy God, who hath brought thee out of the land of Egypt, out of the house of bondage.

Mosiah 12:35 Thou shalt have no other God before me.

Mosiah 12:36 Thou shalt not make unto thee any graven image, or any likeness of any thing in heaven above, or things which are in the earth beneath.

Mosiah 12:37 Now Abinadi said unto them, Have ye done all this? I say unto you, Nay, ye have not. And have ye taught this people that they should do all these things? I say unto you, Nay, ye have not.
