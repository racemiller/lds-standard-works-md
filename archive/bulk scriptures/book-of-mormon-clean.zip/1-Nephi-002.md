# 1 Nephi 2

1 Nephi 2 (summary): Lehi takes his family into the wilderness by the Red Sea—They leave their property—Lehi offers a sacrifice to the Lord and teaches his sons to keep the commandments—Laman and Lemuel murmur against their father—Nephi is obedient and prays in faith; the Lord speaks to him, and he is chosen to rule over his brethren. About 600 B.C.

1 Nephi 2:1 For behold, it came to pass that the Lord spake unto my father, yea, even in a dream, and said unto him: Blessed art thou Lehi, because of the things which thou hast done; and because thou hast been faithful and declared unto this people the things which I commanded thee, behold, they seek to take away thy life.

1 Nephi 2:2 And it came to pass that the Lord commanded my father, even in a dream, that he should take his family and depart into the wilderness.

1 Nephi 2:3 And it came to pass that he was obedient unto the word of the Lord, wherefore he did as the Lord commanded him.

1 Nephi 2:4 And it came to pass that he departed into the wilderness. And he left his house, and the land of his inheritance, and his gold, and his silver, and his precious things, and took nothing with him, save it were his family, and provisions, and tents, and departed into the wilderness.

1 Nephi 2:5 And he came down by the borders near the shore of the Red Sea; and he traveled in the wilderness in the borders which are nearer the Red Sea; and he did travel in the wilderness with his family, which consisted of my mother, Sariah, and my elder brothers, who were Laman, Lemuel, and Sam.

1 Nephi 2:6 And it came to pass that when he had traveled three days in the wilderness, he pitched his tent in a valley by the side of a river of water.

1 Nephi 2:7 And it came to pass that he built an altar of stones, and made an offering unto the Lord, and gave thanks unto the Lord our God.

1 Nephi 2:8 And it came to pass that he called the name of the river, Laman, and it emptied into the Red Sea; and the valley was in the borders near the mouth thereof.

1 Nephi 2:9 And when my father saw that the waters of the river emptied into the fountain of the Red Sea, he spake unto Laman, saying: O that thou mightest be like unto this river, continually running into the fountain of all righteousness!

1 Nephi 2:10 And he also spake unto Lemuel: O that thou mightest be like unto this valley, firm and steadfast, and immovable in keeping the commandments of the Lord!

1 Nephi 2:11 Now this he spake because of the stiffneckedness of Laman and Lemuel; for behold they did murmur in many things against their father, because he was a visionary man, and had led them out of the land of Jerusalem, to leave the land of their inheritance, and their gold, and their silver, and their precious things, to perish in the wilderness. And this they said he had done because of the foolish imaginations of his heart.

1 Nephi 2:12 And thus Laman and Lemuel, being the eldest, did murmur against their father. And they did murmur because they knew not the dealings of that God who had created them.

1 Nephi 2:13 Neither did they believe that Jerusalem, that great city, could be destroyed according to the words of the prophets. And they were like unto the Jews who were at Jerusalem, who sought to take away the life of my father.

1 Nephi 2:14 And it came to pass that my father did speak unto them in the valley of Lemuel, with power, being filled with the Spirit, until their frames did shake before him. And he did confound them, that they durst not utter against him; wherefore, they did as he commanded them.

1 Nephi 2:15 And my father dwelt in a tent.

1 Nephi 2:16 And it came to pass that I, Nephi, being exceedingly young, nevertheless being large in stature, and also having great desires to know of the mysteries of God, wherefore, I did cry unto the Lord; and behold he did visit me, and did soften my heart that I did believe all the words which had been spoken by my father; wherefore, I did not rebel against him like unto my brothers.

1 Nephi 2:17 And I spake unto Sam, making known unto him the things which the Lord had manifested unto me by his Holy Spirit. And it came to pass that he believed in my words.

1 Nephi 2:18 But, behold, Laman and Lemuel would not hearken unto my words; and being grieved because of the hardness of their hearts I cried unto the Lord for them.

1 Nephi 2:19 And it came to pass that the Lord spake unto me, saying: Blessed art thou, Nephi, because of thy faith, for thou hast sought me diligently, with lowliness of heart.

1 Nephi 2:20 And inasmuch as ye shall keep my commandments, ye shall prosper, and shall be led to a land of promise; yea, even a land which I have prepared for you; yea, a land which is choice above all other lands.

1 Nephi 2:21 And inasmuch as thy brethren shall rebel against thee, they shall be cut off from the presence of the Lord.

1 Nephi 2:22 And inasmuch as thou shalt keep my commandments, thou shalt be made a ruler and a teacher over thy brethren.

1 Nephi 2:23 For behold, in that day that they shall rebel against me, I will curse them even with a sore curse, and they shall have no power over thy seed except they shall rebel against me also.

1 Nephi 2:24 And if it so be that they rebel against me, they shall be a scourge unto thy seed, to stir them up in the ways of remembrance.
