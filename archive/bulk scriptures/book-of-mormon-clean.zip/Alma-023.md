# Alma 23

Alma 23 (summary): Religious freedom is proclaimed—The Lamanites in seven lands and cities are converted—They call themselves Anti-Nephi-Lehies and are freed from the curse—The Amalekites and the Amulonites reject the truth. About 90–77 B.C.

Alma 23:1 Behold, now it came to pass that the king of the Lamanites sent a proclamation among all his people, that they should not lay their hands on Ammon, or Aaron, or Omner, or Himni, nor either of their brethren who should go forth preaching the word of God, in whatsoever place they should be, in any part of their land.

Alma 23:2 Yea, he sent a decree among them, that they should not lay their hands on them to bind them, or to cast them into prison; neither should they spit upon them, nor smite them, nor cast them out of their synagogues, nor scourge them; neither should they cast stones at them, but that they should have free access to their houses, and also their temples, and their sanctuaries.

Alma 23:3 And thus they might go forth and preach the word according to their desires, for the king had been converted unto the Lord, and all his household; therefore he sent his proclamation throughout the land unto his people, that the word of God might have no obstruction, but that it might go forth throughout all the land, that his people might be convinced concerning the wicked traditions of their fathers, and that they might be convinced that they were all brethren, and that they ought not to murder, nor to plunder, nor to steal, nor to commit adultery, nor to commit any manner of wickedness.

Alma 23:4 And now it came to pass that when the king had sent forth this proclamation, that Aaron and his brethren went forth from city to city, and from one house of worship to another, establishing churches, and consecrating priests and teachers throughout the land among the Lamanites, to preach and to teach the word of God among them; and thus they began to have great success.

Alma 23:5 And thousands were brought to the knowledge of the Lord, yea, thousands were brought to believe in the traditions of the Nephites; and they were taught the records and prophecies which were handed down even to the present time.

Alma 23:6 And as sure as the Lord liveth, so sure as many as believed, or as many as were brought to the knowledge of the truth, through the preaching of Ammon and his brethren, according to the spirit of revelation and of prophecy, and the power of God working miracles in them—yea, I say unto you, as the Lord liveth, as many of the Lamanites as believed in their preaching, and were converted unto the Lord, never did fall away.

Alma 23:7 For they became a righteous people; they did lay down the weapons of their rebellion, that they did not fight against God any more, neither against any of their brethren.

Alma 23:8 Now, these are they who were converted unto the Lord:

Alma 23:9 The people of the Lamanites who were in the land of Ishmael;

Alma 23:10 And also of the people of the Lamanites who were in the land of Middoni;

Alma 23:11 And also of the people of the Lamanites who were in the city of Nephi;

Alma 23:12 And also of the people of the Lamanites who were in the land of Shilom, and who were in the land of Shemlon, and in the city of Lemuel, and in the city of Shimnilom.

Alma 23:13 And these are the names of the cities of the Lamanites which were converted unto the Lord; and these are they that laid down the weapons of their rebellion, yea, all their weapons of war; and they were all Lamanites.

Alma 23:14 And the Amalekites were not converted, save only one; neither were any of the Amulonites; but they did harden their hearts, and also the hearts of the Lamanites in that part of the land wheresoever they dwelt, yea, and all their villages and all their cities.

Alma 23:15 Therefore, we have named all the cities of the Lamanites in which they did repent and come to the knowledge of the truth, and were converted.

Alma 23:16 And now it came to pass that the king and those who were converted were desirous that they might have a name, that thereby they might be distinguished from their brethren; therefore the king consulted with Aaron and many of their priests, concerning the name that they should take upon them, that they might be distinguished.

Alma 23:17 And it came to pass that they called their names Anti-Nephi-Lehies; and they were called by this name and were no more called Lamanites.

Alma 23:18 And they began to be a very industrious people; yea, and they were friendly with the Nephites; therefore, they did open a correspondence with them, and the curse of God did no more follow them.
