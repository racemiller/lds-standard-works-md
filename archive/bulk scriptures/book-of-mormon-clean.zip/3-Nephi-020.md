# 3 Nephi 20

3 Nephi 20 (summary): Jesus provides bread and wine miraculously and again administers the sacrament unto the people—The remnant of Jacob will come to the knowledge of the Lord their God and will inherit the Americas—Jesus is the prophet like unto Moses, and the Nephites are children of the prophets—Others of the Lord’s people will be gathered to Jerusalem. About A.D. 34.

3 Nephi 20:1 And it came to pass that he commanded the multitude that they should cease to pray, and also his disciples. And he commanded them that they should not cease to pray in their hearts.

3 Nephi 20:2 And he commanded them that they should arise and stand up upon their feet. And they arose up and stood upon their feet.

3 Nephi 20:3 And it came to pass that he brake bread again and blessed it, and gave to the disciples to eat.

3 Nephi 20:4 And when they had eaten he commanded them that they should break bread, and give unto the multitude.

3 Nephi 20:5 And when they had given unto the multitude he also gave them wine to drink, and commanded them that they should give unto the multitude.

3 Nephi 20:6 Now, there had been no bread, neither wine, brought by the disciples, neither by the multitude;

3 Nephi 20:7 But he truly gave unto them bread to eat, and also wine to drink.

3 Nephi 20:8 And he said unto them: He that eateth this bread eateth of my body to his soul; and he that drinketh of this wine drinketh of my blood to his soul; and his soul shall never hunger nor thirst, but shall be filled.

3 Nephi 20:9 Now, when the multitude had all eaten and drunk, behold, they were filled with the Spirit; and they did cry out with one voice, and gave glory to Jesus, whom they both saw and heard.

3 Nephi 20:10 And it came to pass that when they had all given glory unto Jesus, he said unto them: Behold now I finish the commandment which the Father hath commanded me concerning this people, who are a remnant of the house of Israel.

3 Nephi 20:11 Ye remember that I spake unto you, and said that when the words of Isaiah should be fulfilled—behold they are written, ye have them before you, therefore search them—

3 Nephi 20:12 And verily, verily, I say unto you, that when they shall be fulfilled then is the fulfilling of the covenant which the Father hath made unto his people, O house of Israel.

3 Nephi 20:13 And then shall the remnants, which shall be scattered abroad upon the face of the earth, be gathered in from the east and from the west, and from the south and from the north; and they shall be brought to the knowledge of the Lord their God, who hath redeemed them.

3 Nephi 20:14 And the Father hath commanded me that I should give unto you this land, for your inheritance.

3 Nephi 20:15 And I say unto you, that if the Gentiles do not repent after the blessing which they shall receive, after they have scattered my people—

3 Nephi 20:16 Then shall ye, who are a remnant of the house of Jacob, go forth among them; and ye shall be in the midst of them who shall be many; and ye shall be among them as a lion among the beasts of the forest, and as a young lion among the flocks of sheep, who, if he goeth through both treadeth down and teareth in pieces, and none can deliver.

3 Nephi 20:17 Thy hand shall be lifted up upon thine adversaries, and all thine enemies shall be cut off.

3 Nephi 20:18 And I will gather my people together as a man gathereth his sheaves into the floor.

3 Nephi 20:19 For I will make my people with whom the Father hath covenanted, yea, I will make thy horn iron, and I will make thy hoofs brass. And thou shalt beat in pieces many people; and I will consecrate their gain unto the Lord, and their substance unto the Lord of the whole earth. And behold, I am he who doeth it.

3 Nephi 20:20 And it shall come to pass, saith the Father, that the sword of my justice shall hang over them at that day; and except they repent it shall fall upon them, saith the Father, yea, even upon all the nations of the Gentiles.

3 Nephi 20:21 And it shall come to pass that I will establish my people, O house of Israel.

3 Nephi 20:22 And behold, this people will I establish in this land, unto the fulfilling of the covenant which I made with your father Jacob; and it shall be a New Jerusalem. And the powers of heaven shall be in the midst of this people; yea, even I will be in the midst of you.

3 Nephi 20:23 Behold, I am he of whom Moses spake, saying: A prophet shall the Lord your God raise up unto you of your brethren, like unto me; him shall ye hear in all things whatsoever he shall say unto you. And it shall come to pass that every soul who will not hear that prophet shall be cut off from among the people.

3 Nephi 20:24 Verily I say unto you, yea, and all the prophets from Samuel and those that follow after, as many as have spoken, have testified of me.

3 Nephi 20:25 And behold, ye are the children of the prophets; and ye are of the house of Israel; and ye are of the covenant which the Father made with your fathers, saying unto Abraham: And in thy seed shall all the kindreds of the earth be blessed.

3 Nephi 20:26 The Father having raised me up unto you first, and sent me to bless you in turning away every one of you from his iniquities; and this because ye are the children of the covenant—

3 Nephi 20:27 And after that ye were blessed then fulfilleth the Father the covenant which he made with Abraham, saying: In thy seed shall all the kindreds of the earth be blessed—unto the pouring out of the Holy Ghost through me upon the Gentiles, which blessing upon the Gentiles shall make them mighty above all, unto the scattering of my people, O house of Israel.

3 Nephi 20:28 And they shall be a scourge unto the people of this land. Nevertheless, when they shall have received the fulness of my gospel, then if they shall harden their hearts against me I will return their iniquities upon their own heads, saith the Father.

3 Nephi 20:29 And I will remember the covenant which I have made with my people; and I have covenanted with them that I would gather them together in mine own due time, that I would give unto them again the land of their fathers for their inheritance, which is the land of Jerusalem, which is the promised land unto them forever, saith the Father.

3 Nephi 20:30 And it shall come to pass that the time cometh, when the fulness of my gospel shall be preached unto them;

3 Nephi 20:31 And they shall believe in me, that I am Jesus Christ, the Son of God, and shall pray unto the Father in my name.

3 Nephi 20:32 Then shall their watchmen lift up their voice, and with the voice together shall they sing; for they shall see eye to eye.

3 Nephi 20:33 Then will the Father gather them together again, and give unto them Jerusalem for the land of their inheritance.

3 Nephi 20:34 Then shall they break forth into joy—Sing together, ye waste places of Jerusalem; for the Father hath comforted his people, he hath redeemed Jerusalem.

3 Nephi 20:35 The Father hath made bare his holy arm in the eyes of all the nations; and all the ends of the earth shall see the salvation of the Father; and the Father and I are one.

3 Nephi 20:36 And then shall be brought to pass that which is written: Awake, awake again, and put on thy strength, O Zion; put on thy beautiful garments, O Jerusalem, the holy city, for henceforth there shall no more come into thee the uncircumcised and the unclean.

3 Nephi 20:37 Shake thyself from the dust; arise, sit down, O Jerusalem; loose thyself from the bands of thy neck, O captive daughter of Zion.

3 Nephi 20:38 For thus saith the Lord: Ye have sold yourselves for naught, and ye shall be redeemed without money.

3 Nephi 20:39 Verily, verily, I say unto you, that my people shall know my name; yea, in that day they shall know that I am he that doth speak.

3 Nephi 20:40 And then shall they say: How beautiful upon the mountains are the feet of him that bringeth good tidings unto them, that publisheth peace; that bringeth good tidings unto them of good, that publisheth salvation; that saith unto Zion: Thy God reigneth!

3 Nephi 20:41 And then shall a cry go forth: Depart ye, depart ye, go ye out from thence, touch not that which is unclean; go ye out of the midst of her; be ye clean that bear the vessels of the Lord.

3 Nephi 20:42 For ye shall not go out with haste nor go by flight; for the Lord will go before you, and the God of Israel shall be your rearward.

3 Nephi 20:43 Behold, my servant shall deal prudently; he shall be exalted and extolled and be very high.

3 Nephi 20:44 As many were astonished at thee—his visage was so marred, more than any man, and his form more than the sons of men—

3 Nephi 20:45 So shall he sprinkle many nations; the kings shall shut their mouths at him, for that which had not been told them shall they see; and that which they had not heard shall they consider.

3 Nephi 20:46 Verily, verily, I say unto you, all these things shall surely come, even as the Father hath commanded me. Then shall this covenant which the Father hath covenanted with his people be fulfilled; and then shall Jerusalem be inhabited again with my people, and it shall be the land of their inheritance.
