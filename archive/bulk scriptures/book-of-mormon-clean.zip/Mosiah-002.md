# Mosiah 2

Mosiah 2 (summary): King Benjamin addresses his people—He recounts the equity, fairness, and spirituality of his reign—He counsels them to serve their Heavenly King—Those who rebel against God will suffer anguish like unquenchable fire. About 124 B.C.

Mosiah 2:1 And it came to pass that after Mosiah had done as his father had commanded him, and had made a proclamation throughout all the land, that the people gathered themselves together throughout all the land, that they might go up to the temple to hear the words which king Benjamin should speak unto them.

Mosiah 2:2 And there were a great number, even so many that they did not number them; for they had multiplied exceedingly and waxed great in the land.

Mosiah 2:3 And they also took of the firstlings of their flocks, that they might offer sacrifice and burnt offerings according to the law of Moses;

Mosiah 2:4 And also that they might give thanks to the Lord their God, who had brought them out of the land of Jerusalem, and who had delivered them out of the hands of their enemies, and had appointed just men to be their teachers, and also a just man to be their king, who had established peace in the land of Zarahemla, and who had taught them to keep the commandments of God, that they might rejoice and be filled with love towards God and all men.

Mosiah 2:5 And it came to pass that when they came up to the temple, they pitched their tents round about, every man according to his family, consisting of his wife, and his sons, and his daughters, and their sons, and their daughters, from the eldest down to the youngest, every family being separate one from another.

Mosiah 2:6 And they pitched their tents round about the temple, every man having his tent with the door thereof towards the temple, that thereby they might remain in their tents and hear the words which king Benjamin should speak unto them;

Mosiah 2:7 For the multitude being so great that king Benjamin could not teach them all within the walls of the temple, therefore he caused a tower to be erected, that thereby his people might hear the words which he should speak unto them.

Mosiah 2:8 And it came to pass that he began to speak to his people from the tower; and they could not all hear his words because of the greatness of the multitude; therefore he caused that the words which he spake should be written and sent forth among those that were not under the sound of his voice, that they might also receive his words.

Mosiah 2:9 And these are the words which he spake and caused to be written, saying: My brethren, all ye that have assembled yourselves together, you that can hear my words which I shall speak unto you this day; for I have not commanded you to come up hither to trifle with the words which I shall speak, but that you should hearken unto me, and open your ears that ye may hear, and your hearts that ye may understand, and your minds that the mysteries of God may be unfolded to your view.

Mosiah 2:10 I have not commanded you to come up hither that ye should fear me, or that ye should think that I of myself am more than a mortal man.

Mosiah 2:11 But I am like as yourselves, subject to all manner of infirmities in body and mind; yet I have been chosen by this people, and consecrated by my father, and was suffered by the hand of the Lord that I should be a ruler and a king over this people; and have been kept and preserved by his matchless power, to serve you with all the might, mind and strength which the Lord hath granted unto me.

Mosiah 2:12 I say unto you that as I have been suffered to spend my days in your service, even up to this time, and have not sought gold nor silver nor any manner of riches of you;

Mosiah 2:13 Neither have I suffered that ye should be confined in dungeons, nor that ye should make slaves one of another, nor that ye should murder, or plunder, or steal, or commit adultery; nor even have I suffered that ye should commit any manner of wickedness, and have taught you that ye should keep the commandments of the Lord, in all things which he hath commanded you—

Mosiah 2:14 And even I, myself, have labored with mine own hands that I might serve you, and that ye should not be laden with taxes, and that there should nothing come upon you which was grievous to be borne—and of all these things which I have spoken, ye yourselves are witnesses this day.

Mosiah 2:15 Yet, my brethren, I have not done these things that I might boast, neither do I tell these things that thereby I might accuse you; but I tell you these things that ye may know that I can answer a clear conscience before God this day.

Mosiah 2:16 Behold, I say unto you that because I said unto you that I had spent my days in your service, I do not desire to boast, for I have only been in the service of God.

Mosiah 2:17 And behold, I tell you these things that ye may learn wisdom; that ye may learn that when ye are in the service of your fellow beings ye are only in the service of your God.

Mosiah 2:18 Behold, ye have called me your king; and if I, whom ye call your king, do labor to serve you, then ought not ye to labor to serve one another?

Mosiah 2:19 And behold also, if I, whom ye call your king, who has spent his days in your service, and yet has been in the service of God, do merit any thanks from you, O how you ought to thank your heavenly King!

Mosiah 2:20 I say unto you, my brethren, that if you should render all the thanks and praise which your whole soul has power to possess, to that God who has created you, and has kept and preserved you, and has caused that ye should rejoice, and has granted that ye should live in peace one with another—

Mosiah 2:21 I say unto you that if ye should serve him who has created you from the beginning, and is preserving you from day to day, by lending you breath, that ye may live and move and do according to your own will, and even supporting you from one moment to another—I say, if ye should serve him with all your whole souls yet ye would be unprofitable servants.

Mosiah 2:22 And behold, all that he requires of you is to keep his commandments; and he has promised you that if ye would keep his commandments ye should prosper in the land; and he never doth vary from that which he hath said; therefore, if ye do keep his commandments he doth bless you and prosper you.

Mosiah 2:23 And now, in the first place, he hath created you, and granted unto you your lives, for which ye are indebted unto him.

Mosiah 2:24 And secondly, he doth require that ye should do as he hath commanded you; for which if ye do, he doth immediately bless you; and therefore he hath paid you. And ye are still indebted unto him, and are, and will be, forever and ever; therefore, of what have ye to boast?

Mosiah 2:25 And now I ask, can ye say aught of yourselves? I answer you, Nay. Ye cannot say that ye are even as much as the dust of the earth; yet ye were created of the dust of the earth; but behold, it belongeth to him who created you.

Mosiah 2:26 And I, even I, whom ye call your king, am no better than ye yourselves are; for I am also of the dust. And ye behold that I am old, and am about to yield up this mortal frame to its mother earth.

Mosiah 2:27 Therefore, as I said unto you that I had served you, walking with a clear conscience before God, even so I at this time have caused that ye should assemble yourselves together, that I might be found blameless, and that your blood should not come upon me, when I shall stand to be judged of God of the things whereof he hath commanded me concerning you.

Mosiah 2:28 I say unto you that I have caused that ye should assemble yourselves together that I might rid my garments of your blood, at this period of time when I am about to go down to my grave, that I might go down in peace, and my immortal spirit may join the choirs above in singing the praises of a just God.

Mosiah 2:29 And moreover, I say unto you that I have caused that ye should assemble yourselves together, that I might declare unto you that I can no longer be your teacher, nor your king;

Mosiah 2:30 For even at this time, my whole frame doth tremble exceedingly while attempting to speak unto you; but the Lord God doth support me, and hath suffered me that I should speak unto you, and hath commanded me that I should declare unto you this day, that my son Mosiah is a king and a ruler over you.

Mosiah 2:31 And now, my brethren, I would that ye should do as ye have hitherto done. As ye have kept my commandments, and also the commandments of my father, and have prospered, and have been kept from falling into the hands of your enemies, even so if ye shall keep the commandments of my son, or the commandments of God which shall be delivered unto you by him, ye shall prosper in the land, and your enemies shall have no power over you.

Mosiah 2:32 But, O my people, beware lest there shall arise contentions among you, and ye list to obey the evil spirit, which was spoken of by my father Mosiah.

Mosiah 2:33 For behold, there is a wo pronounced upon him who listeth to obey that spirit; for if he listeth to obey him, and remaineth and dieth in his sins, the same drinketh damnation to his own soul; for he receiveth for his wages an everlasting punishment, having transgressed the law of God contrary to his own knowledge.

Mosiah 2:34 I say unto you, that there are not any among you, except it be your little children that have not been taught concerning these things, but what knoweth that ye are eternally indebted to your heavenly Father, to render to him all that you have and are; and also have been taught concerning the records which contain the prophecies which have been spoken by the holy prophets, even down to the time our father, Lehi, left Jerusalem;

Mosiah 2:35 And also, all that has been spoken by our fathers until now. And behold, also, they spake that which was commanded them of the Lord; therefore, they are just and true.

Mosiah 2:36 And now, I say unto you, my brethren, that after ye have known and have been taught all these things, if ye should transgress and go contrary to that which has been spoken, that ye do withdraw yourselves from the Spirit of the Lord, that it may have no place in you to guide you in wisdom’s paths that ye may be blessed, prospered, and preserved—

Mosiah 2:37 I say unto you, that the man that doeth this, the same cometh out in open rebellion against God; therefore he listeth to obey the evil spirit, and becometh an enemy to all righteousness; therefore, the Lord has no place in him, for he dwelleth not in unholy temples.

Mosiah 2:38 Therefore if that man repenteth not, and remaineth and dieth an enemy to God, the demands of divine justice do awaken his immortal soul to a lively sense of his own guilt, which doth cause him to shrink from the presence of the Lord, and doth fill his breast with guilt, and pain, and anguish, which is like an unquenchable fire, whose flame ascendeth up forever and ever.

Mosiah 2:39 And now I say unto you, that mercy hath no claim on that man; therefore his final doom is to endure a never-ending torment.

Mosiah 2:40 O, all ye old men, and also ye young men, and you little children who can understand my words, for I have spoken plainly unto you that ye might understand, I pray that ye should awake to a remembrance of the awful situation of those that have fallen into transgression.

Mosiah 2:41 And moreover, I would desire that ye should consider on the blessed and happy state of those that keep the commandments of God. For behold, they are blessed in all things, both temporal and spiritual; and if they hold out faithful to the end they are received into heaven, that thereby they may dwell with God in a state of never-ending happiness. O remember, remember that these things are true; for the Lord God hath spoken it.
