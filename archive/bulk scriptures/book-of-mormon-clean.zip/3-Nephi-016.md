# 3 Nephi 16

3 Nephi 16 (summary): Jesus will visit others of the lost sheep of Israel—In the latter days the gospel will go to the Gentiles and then to the house of Israel—The Lord’s people will see eye to eye when He brings again Zion. About A.D. 34.

3 Nephi 16:1 And verily, verily, I say unto you that I have other sheep, which are not of this land, neither of the land of Jerusalem, neither in any parts of that land round about whither I have been to minister.

3 Nephi 16:2 For they of whom I speak are they who have not as yet heard my voice; neither have I at any time manifested myself unto them.

3 Nephi 16:3 But I have received a commandment of the Father that I shall go unto them, and that they shall hear my voice, and shall be numbered among my sheep, that there may be one fold and one shepherd; therefore I go to show myself unto them.

3 Nephi 16:4 And I command you that ye shall write these sayings after I am gone, that if it so be that my people at Jerusalem, they who have seen me and been with me in my ministry, do not ask the Father in my name, that they may receive a knowledge of you by the Holy Ghost, and also of the other tribes whom they know not of, that these sayings which ye shall write shall be kept and shall be manifested unto the Gentiles, that through the fulness of the Gentiles, the remnant of their seed, who shall be scattered forth upon the face of the earth because of their unbelief, may be brought in, or may be brought to a knowledge of me, their Redeemer.

3 Nephi 16:5 And then will I gather them in from the four quarters of the earth; and then will I fulfil the covenant which the Father hath made unto all the people of the house of Israel.

3 Nephi 16:6 And blessed are the Gentiles, because of their belief in me, in and of the Holy Ghost, which witnesses unto them of me and of the Father.

3 Nephi 16:7 Behold, because of their belief in me, saith the Father, and because of the unbelief of you, O house of Israel, in the latter day shall the truth come unto the Gentiles, that the fulness of these things shall be made known unto them.

3 Nephi 16:8 But wo, saith the Father, unto the unbelieving of the Gentiles—for notwithstanding they have come forth upon the face of this land, and have scattered my people who are of the house of Israel; and my people who are of the house of Israel have been cast out from among them, and have been trodden under feet by them;

3 Nephi 16:9 And because of the mercies of the Father unto the Gentiles, and also the judgments of the Father upon my people who are of the house of Israel, verily, verily, I say unto you, that after all this, and I have caused my people who are of the house of Israel to be smitten, and to be afflicted, and to be slain, and to be cast out from among them, and to become hated by them, and to become a hiss and a byword among them—

3 Nephi 16:10 And thus commandeth the Father that I should say unto you: At that day when the Gentiles shall sin against my gospel, and shall reject the fulness of my gospel, and shall be lifted up in the pride of their hearts above all nations, and above all the people of the whole earth, and shall be filled with all manner of lyings, and of deceits, and of mischiefs, and all manner of hypocrisy, and murders, and priestcrafts, and whoredoms, and of secret abominations; and if they shall do all those things, and shall reject the fulness of my gospel, behold, saith the Father, I will bring the fulness of my gospel from among them.

3 Nephi 16:11 And then will I remember my covenant which I have made unto my people, O house of Israel, and I will bring my gospel unto them.

3 Nephi 16:12 And I will show unto thee, O house of Israel, that the Gentiles shall not have power over you; but I will remember my covenant unto you, O house of Israel, and ye shall come unto the knowledge of the fulness of my gospel.

3 Nephi 16:13 But if the Gentiles will repent and return unto me, saith the Father, behold they shall be numbered among my people, O house of Israel.

3 Nephi 16:14 And I will not suffer my people, who are of the house of Israel, to go through among them, and tread them down, saith the Father.

3 Nephi 16:15 But if they will not turn unto me, and hearken unto my voice, I will suffer them, yea, I will suffer my people, O house of Israel, that they shall go through among them, and shall tread them down, and they shall be as salt that hath lost its savor, which is thenceforth good for nothing but to be cast out, and to be trodden under foot of my people, O house of Israel.

3 Nephi 16:16 Verily, verily, I say unto you, thus hath the Father commanded me—that I should give unto this people this land for their inheritance.

3 Nephi 16:17 And then the words of the prophet Isaiah shall be fulfilled, which say:

3 Nephi 16:18 Thy watchmen shall lift up the voice; with the voice together shall they sing, for they shall see eye to eye when the Lord shall bring again Zion.

3 Nephi 16:19 Break forth into joy, sing together, ye waste places of Jerusalem; for the Lord hath comforted his people, he hath redeemed Jerusalem.

3 Nephi 16:20 The Lord hath made bare his holy arm in the eyes of all the nations; and all the ends of the earth shall see the salvation of God.
