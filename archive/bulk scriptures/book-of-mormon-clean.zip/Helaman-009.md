# Helaman 9

Helaman 9 (summary): Messengers find the chief judge dead at the judgment seat—They are imprisoned and later released—By inspiration Nephi identifies Seantum as the murderer—Nephi is accepted by some as a prophet. About 23–21 B.C.

Helaman 9:1 Behold, now it came to pass that when Nephi had spoken these words, certain men who were among them ran to the judgment-seat; yea, even there were five who went, and they said among themselves, as they went:

Helaman 9:2 Behold, now we will know of a surety whether this man be a prophet and God hath commanded him to prophesy such marvelous things unto us. Behold, we do not believe that he hath; yea, we do not believe that he is a prophet; nevertheless, if this thing which he has said concerning the chief judge be true, that he be dead, then will we believe that the other words which he has spoken are true.

Helaman 9:3 And it came to pass that they ran in their might, and came in unto the judgment-seat; and behold, the chief judge had fallen to the earth, and did lie in his blood.

Helaman 9:4 And now behold, when they saw this they were astonished exceedingly, insomuch that they fell to the earth; for they had not believed the words which Nephi had spoken concerning the chief judge.

Helaman 9:5 But now, when they saw they believed, and fear came upon them lest all the judgments which Nephi had spoken should come upon the people; therefore they did quake, and had fallen to the earth.

Helaman 9:6 Now, immediately when the judge had been murdered—he being stabbed by his brother by a garb of secrecy, and he fled, and the servants ran and told the people, raising the cry of murder among them;

Helaman 9:7 And behold the people did gather themselves together unto the place of the judgment-seat—and behold, to their astonishment they saw those five men who had fallen to the earth.

Helaman 9:8 And now behold, the people knew nothing concerning the multitude who had gathered together at the garden of Nephi; therefore they said among themselves: These men are they who have murdered the judge, and God has smitten them that they could not flee from us.

Helaman 9:9 And it came to pass that they laid hold on them, and bound them and cast them into prison. And there was a proclamation sent abroad that the judge was slain, and that the murderers had been taken and were cast into prison.

Helaman 9:10 And it came to pass that on the morrow the people did assemble themselves together to mourn and to fast, at the burial of the great chief judge who had been slain.

Helaman 9:11 And thus also those judges who were at the garden of Nephi, and heard his words, were also gathered together at the burial.

Helaman 9:12 And it came to pass that they inquired among the people, saying: Where are the five who were sent to inquire concerning the chief judge whether he was dead? And they answered and said: Concerning this five whom ye say ye have sent, we know not; but there are five who are the murderers, whom we have cast into prison.

Helaman 9:13 And it came to pass that the judges desired that they should be brought; and they were brought, and behold they were the five who were sent; and behold the judges inquired of them to know concerning the matter, and they told them all that they had done, saying:

Helaman 9:14 We ran and came to the place of the judgment-seat, and when we saw all things even as Nephi had testified, we were astonished insomuch that we fell to the earth; and when we were recovered from our astonishment, behold they cast us into prison.

Helaman 9:15 Now, as for the murder of this man, we know not who has done it; and only this much we know, we ran and came according as ye desired, and behold he was dead, according to the words of Nephi.

Helaman 9:16 And now it came to pass that the judges did expound the matter unto the people, and did cry out against Nephi, saying: Behold, we know that this Nephi must have agreed with some one to slay the judge, and then he might declare it unto us, that he might convert us unto his faith, that he might raise himself to be a great man, chosen of God, and a prophet.

Helaman 9:17 And now behold, we will detect this man, and he shall confess his fault and make known unto us the true murderer of this judge.

Helaman 9:18 And it came to pass that the five were liberated on the day of the burial. Nevertheless, they did rebuke the judges in the words which they had spoken against Nephi, and did contend with them one by one, insomuch that they did confound them.

Helaman 9:19 Nevertheless, they caused that Nephi should be taken and bound and brought before the multitude, and they began to question him in divers ways that they might cross him, that they might accuse him to death—

Helaman 9:20 Saying unto him: Thou art confederate; who is this man that hath done this murder? Now tell us, and acknowledge thy fault; saying, Behold here is money; and also we will grant unto thee thy life if thou wilt tell us, and acknowledge the agreement which thou hast made with him.

Helaman 9:21 But Nephi said unto them: O ye fools, ye uncircumcised of heart, ye blind, and ye stiffnecked people, do ye know how long the Lord your God will suffer you that ye shall go on in this your way of sin?

Helaman 9:22 O ye ought to begin to howl and mourn, because of the great destruction which at this time doth await you, except ye shall repent.

Helaman 9:23 Behold ye say that I have agreed with a man that he should murder Seezoram, our chief judge. But behold, I say unto you, that this is because I have testified unto you that ye might know concerning this thing; yea, even for a witness unto you, that I did know of the wickedness and abominations which are among you.

Helaman 9:24 And because I have done this, ye say that I have agreed with a man that he should do this thing; yea, because I showed unto you this sign ye are angry with me, and seek to destroy my life.

Helaman 9:25 And now behold, I will show unto you another sign, and see if ye will in this thing seek to destroy me.

Helaman 9:26 Behold I say unto you: Go to the house of Seantum, who is the brother of Seezoram, and say unto him—

Helaman 9:27 Has Nephi, the pretended prophet, who doth prophesy so much evil concerning this people, agreed with thee, in the which ye have murdered Seezoram, who is your brother?

Helaman 9:28 And behold, he shall say unto you, Nay.

Helaman 9:29 And ye shall say unto him: Have ye murdered your brother?

Helaman 9:30 And he shall stand with fear, and wist not what to say. And behold, he shall deny unto you; and he shall make as if he were astonished; nevertheless, he shall declare unto you that he is innocent.

Helaman 9:31 But behold, ye shall examine him, and ye shall find blood upon the skirts of his cloak.

Helaman 9:32 And when ye have seen this, ye shall say: From whence cometh this blood? Do we not know that it is the blood of your brother?

Helaman 9:33 And then shall he tremble, and shall look pale, even as if death had come upon him.

Helaman 9:34 And then shall ye say: Because of this fear and this paleness which has come upon your face, behold, we know that thou art guilty.

Helaman 9:35 And then shall greater fear come upon him; and then shall he confess unto you, and deny no more that he has done this murder.

Helaman 9:36 And then shall he say unto you, that I, Nephi, know nothing concerning the matter save it were given unto me by the power of God. And then shall ye know that I am an honest man, and that I am sent unto you from God.

Helaman 9:37 And it came to pass that they went and did, even according as Nephi had said unto them. And behold, the words which he had said were true; for according to the words he did deny; and also according to the words he did confess.

Helaman 9:38 And he was brought to prove that he himself was the very murderer, insomuch that the five were set at liberty, and also was Nephi.

Helaman 9:39 And there were some of the Nephites who believed on the words of Nephi; and there were some also, who believed because of the testimony of the five, for they had been converted while they were in prison.

Helaman 9:40 And now there were some among the people, who said that Nephi was a prophet.

Helaman 9:41 And there were others who said: Behold, he is a god, for except he was a god he could not know of all things. For behold, he has told us the thoughts of our hearts, and also has told us things; and even he has brought unto our knowledge the true murderer of our chief judge.
