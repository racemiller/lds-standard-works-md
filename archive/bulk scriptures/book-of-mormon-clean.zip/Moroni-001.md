# Moroni 1

Moroni 1 (summary): Moroni writes for the benefit of the Lamanites—The Nephites who will not deny Christ are put to death. About A.D. 401–21.

Moroni 1:1 Now I, Moroni, after having made an end of abridging the account of the people of Jared, I had supposed not to have written more, but I have not as yet perished; and I make not myself known to the Lamanites lest they should destroy me.

Moroni 1:2 For behold, their wars are exceedingly fierce among themselves; and because of their hatred they put to death every Nephite that will not deny the Christ.

Moroni 1:3 And I, Moroni, will not deny the Christ; wherefore, I wander whithersoever I can for the safety of mine own life.

Moroni 1:4 Wherefore, I write a few more things, contrary to that which I had supposed; for I had supposed not to have written any more; but I write a few more things, that perhaps they may be of worth unto my brethren, the Lamanites, in some future day, according to the will of the Lord.
