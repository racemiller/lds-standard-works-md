# Alma 21

Alma 21 (summary): Aaron teaches the Amalekites about Christ and His Atonement—Aaron and his brethren are imprisoned in Middoni—After their deliverance, they teach in the synagogues and make many converts—Lamoni grants religious freedom to the people in the land of Ishmael. About 90–77 B.C.

Alma 21:1 Now when Ammon and his brethren separated themselves in the borders of the land of the Lamanites, behold Aaron took his journey towards the land which was called by the Lamanites, Jerusalem, calling it after the land of their fathers’ nativity; and it was away joining the borders of Mormon.

Alma 21:2 Now the Lamanites and the Amalekites and the people of Amulon had built a great city, which was called Jerusalem.

Alma 21:3 Now the Lamanites of themselves were sufficiently hardened, but the Amalekites and the Amulonites were still harder; therefore they did cause the Lamanites that they should harden their hearts, that they should wax strong in wickedness and their abominations.

Alma 21:4 And it came to pass that Aaron came to the city of Jerusalem, and first began to preach to the Amalekites. And he began to preach to them in their synagogues, for they had built synagogues after the order of the Nehors; for many of the Amalekites and the Amulonites were after the order of the Nehors.

Alma 21:5 Therefore, as Aaron entered into one of their synagogues to preach unto the people, and as he was speaking unto them, behold there arose an Amalekite and began to contend with him, saying: What is that thou hast testified? Hast thou seen an angel? Why do not angels appear unto us? Behold are not this people as good as thy people?

Alma 21:6 Thou also sayest, except we repent we shall perish. How knowest thou the thought and intent of our hearts? How knowest thou that we have cause to repent? How knowest thou that we are not a righteous people? Behold, we have built sanctuaries, and we do assemble ourselves together to worship God. We do believe that God will save all men.

Alma 21:7 Now Aaron said unto him: Believest thou that the Son of God shall come to redeem mankind from their sins?

Alma 21:8 And the man said unto him: We do not believe that thou knowest any such thing. We do not believe in these foolish traditions. We do not believe that thou knowest of things to come, neither do we believe that thy fathers and also that our fathers did know concerning the things which they spake, of that which is to come.

Alma 21:9 Now Aaron began to open the scriptures unto them concerning the coming of Christ, and also concerning the resurrection of the dead, and that there could be no redemption for mankind save it were through the death and sufferings of Christ, and the atonement of his blood.

Alma 21:10 And it came to pass as he began to expound these things unto them they were angry with him, and began to mock him; and they would not hear the words which he spake.

Alma 21:11 Therefore, when he saw that they would not hear his words, he departed out of their synagogue, and came over to a village which was called Ani-Anti, and there he found Muloki preaching the word unto them; and also Ammah and his brethren. And they contended with many about the word.

Alma 21:12 And it came to pass that they saw that the people would harden their hearts, therefore they departed and came over into the land of Middoni. And they did preach the word unto many, and few believed on the words which they taught.

Alma 21:13 Nevertheless, Aaron and a certain number of his brethren were taken and cast into prison, and the remainder of them fled out of the land of Middoni unto the regions round about.

Alma 21:14 And those who were cast into prison suffered many things, and they were delivered by the hand of Lamoni and Ammon, and they were fed and clothed.

Alma 21:15 And they went forth again to declare the word, and thus they were delivered for the first time out of prison; and thus they had suffered.

Alma 21:16 And they went forth whithersoever they were led by the Spirit of the Lord, preaching the word of God in every synagogue of the Amalekites, or in every assembly of the Lamanites where they could be admitted.

Alma 21:17 And it came to pass that the Lord began to bless them, insomuch that they brought many to the knowledge of the truth; yea, they did convince many of their sins, and of the traditions of their fathers, which were not correct.

Alma 21:18 And it came to pass that Ammon and Lamoni returned from the land of Middoni to the land of Ishmael, which was the land of their inheritance.

Alma 21:19 And king Lamoni would not suffer that Ammon should serve him, or be his servant.

Alma 21:20 But he caused that there should be synagogues built in the land of Ishmael; and he caused that his people, or the people who were under his reign, should assemble themselves together.

Alma 21:21 And he did rejoice over them, and he did teach them many things. And he did also declare unto them that they were a people who were under him, and that they were a free people, that they were free from the oppressions of the king, his father; for that his father had granted unto him that he might reign over the people who were in the land of Ishmael, and in all the land round about.

Alma 21:22 And he also declared unto them that they might have the liberty of worshiping the Lord their God according to their desires, in whatsoever place they were in, if it were in the land which was under the reign of king Lamoni.

Alma 21:23 And Ammon did preach unto the people of king Lamoni; and it came to pass that he did teach them all things concerning things pertaining to righteousness. And he did exhort them daily, with all diligence; and they gave heed unto his word, and they were zealous for keeping the commandments of God.
